# VMS Fill Dates

Admin-only add-on plugin that creates a dedicated **Fill Dates** workspace under VMS.

## Included in this build

- Separate plugin so repairs stay isolated from customer-facing UI
- VMS Planning-integrated Fill Dates workspace
- Date-first board for upcoming Event Plans
- Filters for venue, statuses, planning window, and primary candidate type
- Match workspace for one Event Plan at a time
- Primary vendor assignment
- Multi-select secondary vendor assignment
- Secondary vendor removal
- Availability evaluation using:
  - manual availability
  - weekly pattern availability
  - ICS unavailable dates
  - existing Draft/Ready/Published assignments
- Status labels with source/detail text:
  - Current assignment
  - Available
  - No reply
  - Tentative elsewhere
  - Booked elsewhere
  - Unavailable
- 365-day lookback for **Last Worked**
- Board signal counts for available / no reply / conflict candidates
- Guided help tour registration

## Notes

This is still an operational MVP. It does **not** yet include outreach tracking, holds, drag/drop, or multi-date batch assignment.

Recommended core: VMS 0.2.24.301 or later on the 296 recovery line.
