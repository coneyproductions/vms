<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_fd_i18n_runtime')) {
    function vms_fd_i18n_runtime(string $text): string
    {
        if ($text === '') {
            return '';
        }

        if (doing_action('after_setup_theme') || did_action('after_setup_theme')) {
            return __($text, 'vms-fill-dates');
        }

        return $text;
    }
}

if (!function_exists('vms_fd_register_tours')) {
    function vms_fd_register_tours(array $tours): array
    {
        $registered_hook = function_exists('vms_fd_admin_page_hook') ? vms_fd_admin_page_hook() : '';
        if ($registered_hook === '') {
            return $tours;
        }

        $tours[] = array(
            'id' => 'vms_fill_dates_overview',
            'title' => vms_fd_i18n_runtime('Fill Dates Overview'),
            'version' => 1,
            'contexts' => array(
                array(
                    'context_key' => 'vms-fill-dates',
                    'screen_id' => $registered_hook,
                    'page_hook' => $registered_hook,
                    'url' => 'admin.php?page=vms-fill-dates',
                ),
            ),
            'steps' => array(
                array(
                    'anchor' => 'fill-dates.help',
                    'title' => vms_fd_i18n_runtime('Help'),
                    'content' => vms_fd_i18n_runtime('Use Help to relaunch this walkthrough after the page is already familiar.'),
                    'placement' => 'left',
                ),
                array(
                    'anchor' => 'fill-dates.filters',
                    'title' => vms_fd_i18n_runtime('Filters'),
                    'content' => vms_fd_i18n_runtime('Narrow the board by venue, status, and planning horizon so you only see dates you can act on right now.'),
                    'placement' => 'bottom',
                ),
                array(
                    'anchor' => 'fill-dates.board',
                    'title' => vms_fd_i18n_runtime('Date Board'),
                    'content' => vms_fd_i18n_runtime('Each row is a scheduled Event Plan. Available counts are operational counts, not just raw vendor totals.'),
                    'placement' => 'top',
                ),
                array(
                    'anchor' => 'fill-dates.detail',
                    'title' => vms_fd_i18n_runtime('Match Workspace'),
                    'content' => vms_fd_i18n_runtime('Open a date to see the current assignments plus the candidate vendors for that specific date.'),
                    'placement' => 'top',
                ),
                array(
                    'anchor' => 'fill-dates.primary',
                    'title' => vms_fd_i18n_runtime('Primary Vendor Matching'),
                    'content' => vms_fd_i18n_runtime('Primary matching is intentionally explicit: choose one vendor, review status, then assign.'),
                    'placement' => 'top',
                ),
                array(
                    'anchor' => 'fill-dates.secondary',
                    'title' => vms_fd_i18n_runtime('Secondary Vendor Matching'),
                    'content' => vms_fd_i18n_runtime('Secondary matching supports multi-select so you can attach several vendors to one event in one pass.'),
                    'placement' => 'top',
                ),
            ),
        );

        return $tours;
    }
}
add_filter('vms_register_tours', 'vms_fd_register_tours');
