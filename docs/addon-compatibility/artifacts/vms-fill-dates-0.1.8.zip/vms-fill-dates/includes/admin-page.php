<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_fd_admin_page_hook')) {
    /**
     * Store or retrieve the hook returned by WordPress for the Fill Dates page.
     *
     * @param string|false|null $hook
     */
    function vms_fd_admin_page_hook($hook = null): string
    {
        static $registered_hook = '';

        if (func_num_args() > 0) {
            $registered_hook = is_string($hook) ? $hook : '';
        }

        return $registered_hook;
    }
}

if (!function_exists('vms_fd_is_current_admin_screen')) {
    function vms_fd_is_current_admin_screen(): bool
    {
        $registered_hook = vms_fd_admin_page_hook();
        if ($registered_hook === '') {
            return false;
        }

        $hook_suffix = isset($GLOBALS['hook_suffix']) && is_string($GLOBALS['hook_suffix'])
            ? $GLOBALS['hook_suffix']
            : '';
        if ($hook_suffix === $registered_hook) {
            return true;
        }

        if (!function_exists('get_current_screen')) {
            return false;
        }

        $screen = get_current_screen();
        return is_object($screen)
            && isset($screen->id)
            && is_string($screen->id)
            && $screen->id === $registered_hook;
    }
}

if (!function_exists('vms_fd_register_menu')) {
    function vms_fd_register_menu(): void
    {
        $hook = add_submenu_page(
            'vms-dashboard',
            __('Fill Dates', 'vms-fill-dates'),
            __('Fill Dates', 'vms-fill-dates'),
            'manage_options',
            'vms-fill-dates',
            'vms_fd_render_admin_page'
        );

        vms_fd_admin_page_hook($hook);

        if (is_string($hook) && $hook !== '' && class_exists('VMS_Tours_Service')) {
            $tour_service = VMS_Tours_Service::instance();
            if (method_exists($tour_service, 'refresh_filter_tours')) {
                $tour_service->refresh_filter_tours();
            }
        }
    }
}
add_action('admin_menu', 'vms_fd_register_menu', 46);

if (!function_exists('vms_fd_enqueue_admin_assets')) {
    function vms_fd_enqueue_admin_assets(string $hook): void
    {
        $registered_hook = vms_fd_admin_page_hook();
        if ($registered_hook === '' || $hook !== $registered_hook) {
            return;
        }

        wp_enqueue_style(
            'vms-fill-dates-admin',
            VMS_FILL_DATES_URL . 'assets/admin.css',
            array(),
            VMS_FILL_DATES_VERSION
        );
    }
}
add_action('admin_enqueue_scripts', 'vms_fd_enqueue_admin_assets');

if (!function_exists('vms_fd_render_dependency_notice')) {
    function vms_fd_render_dependency_notice(): void
    {
        if (!current_user_can('manage_options') || vms_fd_vms_ready()) {
            return;
        }

        echo '<div class="notice notice-error"><p>' . esc_html__('Fill Dates requires Backstage Venue Manager (BVM). Activate it before using Fill Dates.', 'vms-fill-dates') . '</p></div>';
    }
}
add_action('admin_notices', 'vms_fd_render_dependency_notice');

if (!function_exists('vms_fd_help_button')) {
    function vms_fd_help_button(): string
    {
        if (function_exists('vms_render_help_button')) {
            return vms_render_help_button(array(
                'tour_id' => 'vms_fill_dates_overview',
                'anchor' => 'fill-dates.help',
                'class' => 'vms-fd-help',
            ));
        }

        return '<button type="button" class="button button-secondary">' . esc_html__('Help', 'vms-fill-dates') . '</button>';
    }
}

if (!function_exists('vms_fd_parse_request_filters')) {
    function vms_fd_parse_request_filters(): array
    {
        $venue_id = isset($_GET['venue_id']) ? absint($_GET['venue_id']) : 0;
        $days = isset($_GET['days']) ? max(14, min(365, absint($_GET['days']))) : 120;
        $open_only = !empty($_GET['open_only']);
        $plan_id = isset($_GET['plan_id']) ? absint($_GET['plan_id']) : 0;
        $primary_type = isset($_GET['primary_type']) ? sanitize_key((string) $_GET['primary_type']) : '';
        $statuses = isset($_GET['statuses']) && is_array($_GET['statuses'])
            ? array_values(array_unique(array_filter(array_map('sanitize_key', (array) $_GET['statuses']))))
            : array('draft', 'ready', 'published');
        if (empty($statuses)) {
            $statuses = array('draft', 'ready', 'published');
        }

        $today = wp_date('Y-m-d', time(), function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC'));
        $end = wp_date('Y-m-d', strtotime('+' . $days . ' days', strtotime($today)), function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC'));
        $history_start = wp_date('Y-m-d', strtotime('-365 days', strtotime($today)), function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC'));

        return array(
            'venue_id' => $venue_id,
            'days' => $days,
            'open_only' => $open_only,
            'plan_id' => $plan_id,
            'primary_type' => $primary_type,
            'statuses' => $statuses,
            'today' => $today,
            'end' => $end,
            'history_start' => $history_start,
        );
    }
}

if (!function_exists('vms_fd_redirect_with_notice')) {
    function vms_fd_redirect_with_notice(array $query, string $notice_key): void
    {
        $query['vms_fd_notice'] = $notice_key;
        wp_safe_redirect(add_query_arg($query, admin_url('admin.php?page=vms-fill-dates')));
        exit;
    }
}

if (!function_exists('vms_fd_process_post_actions')) {
    function vms_fd_process_post_actions(array $filters): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }
        if (!current_user_can('manage_options')) {
            return;
        }
        if (empty($_POST['vms_fd_action'])) {
            return;
        }
        check_admin_referer('vms_fd_action', 'vms_fd_nonce');

        $action = sanitize_key((string) $_POST['vms_fd_action']);
        $plan_id = absint($_POST['plan_id'] ?? 0);
        if ($plan_id <= 0 || get_post_type($plan_id) !== 'vms_event_plan') {
            return;
        }

        $query = array(
            'venue_id' => (int) ($filters['venue_id'] ?? 0),
            'days' => (int) ($filters['days'] ?? 120),
            'plan_id' => $plan_id,
            'primary_type' => (string) ($filters['primary_type'] ?? ''),
        );
        if (!empty($filters['open_only'])) {
            $query['open_only'] = '1';
        }
        $query['statuses'] = array_values(array_filter(array_map('sanitize_key', (array) ($filters['statuses'] ?? array()))));

        if ($action === 'assign_primary') {
            $vendor_id = absint($_POST['primary_vendor_id'] ?? 0);
            if ($vendor_id > 0 && get_post_type($vendor_id) === 'vms_vendor') {
                vms_fd_set_primary_vendor($plan_id, $vendor_id);
                if (function_exists('vms_calendar_feed_cache_bust')) {
                    vms_calendar_feed_cache_bust();
                }
                if (function_exists('vms_event_plan_review_touch')) {
                    vms_event_plan_review_touch($plan_id, 'fill_dates');
                }
                vms_fd_redirect_with_notice($query, 'primary_assigned');
            }
        }

        if ($action === 'clear_primary') {
            vms_fd_set_primary_vendor($plan_id, 0);
            if (function_exists('vms_calendar_feed_cache_bust')) {
                vms_calendar_feed_cache_bust();
            }
            if (function_exists('vms_event_plan_review_touch')) {
                vms_event_plan_review_touch($plan_id, 'fill_dates');
            }
            vms_fd_redirect_with_notice($query, 'primary_cleared');
        }

        if ($action === 'add_secondary') {
            $type_slug = sanitize_key((string) ($_POST['secondary_type'] ?? ''));
            $selected = isset($_POST['secondary_vendor_ids']) && is_array($_POST['secondary_vendor_ids'])
                ? array_values(array_unique(array_filter(array_map('absint', (array) $_POST['secondary_vendor_ids']))))
                : array();
            $current = vms_fd_get_secondary_vendor_ids($plan_id);
            $merged = array_values(array_unique(array_merge($current, $selected)));
            vms_fd_upsert_secondary_vendor_ids($plan_id, $type_slug, $merged);
            if (function_exists('vms_calendar_feed_cache_bust')) {
                vms_calendar_feed_cache_bust();
            }
            if (function_exists('vms_event_plan_review_touch')) {
                vms_event_plan_review_touch($plan_id, 'fill_dates');
            }
            vms_fd_redirect_with_notice($query, 'secondary_added');
        }

        if ($action === 'remove_secondary') {
            $type_slug = sanitize_key((string) ($_POST['secondary_type'] ?? ''));
            $remove = isset($_POST['remove_secondary_vendor_ids']) && is_array($_POST['remove_secondary_vendor_ids'])
                ? array_values(array_unique(array_filter(array_map('absint', (array) $_POST['remove_secondary_vendor_ids']))))
                : array();
            $current = vms_fd_get_secondary_vendor_ids($plan_id);
            $updated = array_values(array_filter($current, static function ($vendor_id) use ($remove) {
                return !in_array((int) $vendor_id, $remove, true);
            }));
            vms_fd_upsert_secondary_vendor_ids($plan_id, $type_slug, $updated);
            if (function_exists('vms_calendar_feed_cache_bust')) {
                vms_calendar_feed_cache_bust();
            }
            if (function_exists('vms_event_plan_review_touch')) {
                vms_event_plan_review_touch($plan_id, 'fill_dates');
            }
            vms_fd_redirect_with_notice($query, 'secondary_removed');
        }
    }
}

if (!function_exists('vms_fd_render_notice')) {
    function vms_fd_render_notice(): void
    {
        if (!current_user_can('manage_options') || !vms_fd_is_current_admin_screen()) {
            return;
        }

        $notice = sanitize_key((string) ($_GET['vms_fd_notice'] ?? ''));
        if ($notice === '') {
            return;
        }

        $map = array(
            'primary_assigned' => __('Primary vendor assigned.', 'vms-fill-dates'),
            'primary_cleared' => __('Primary vendor cleared.', 'vms-fill-dates'),
            'secondary_added' => __('Secondary vendor assignments updated.', 'vms-fill-dates'),
            'secondary_removed' => __('Secondary vendor assignments updated.', 'vms-fill-dates'),
        );
        if (!isset($map[$notice])) {
            return;
        }

        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($map[$notice]) . '</p></div>';
    }
}
add_action('admin_notices', 'vms_fd_render_notice');

if (!function_exists('vms_fd_sort_candidate_rows')) {
    function vms_fd_sort_candidate_rows(array &$rows): void
    {
        $order = array(
            'current' => 0,
            'available' => 1,
            'no-response' => 2,
            'tentative' => 3,
            'booked' => 4,
            'unavailable' => 5,
        );

        usort($rows, static function (array $a, array $b) use ($order): int {
            $sa = $order[$a['availability']['state'] ?? 'no-response'] ?? 99;
            $sb = $order[$b['availability']['state'] ?? 'no-response'] ?? 99;
            if ($sa !== $sb) {
                return $sa <=> $sb;
            }
            return strcasecmp((string) ($a['name'] ?? ''), (string) ($b['name'] ?? ''));
        });
    }
}

if (!function_exists('vms_fd_render_availability_badge')) {
    function vms_fd_render_availability_badge(array $availability): string
    {
        $state = sanitize_key((string) ($availability['state'] ?? 'no-response'));
        $label = (string) ($availability['label'] ?? __('No reply', 'vms-fill-dates'));
        $source = trim((string) ($availability['source'] ?? ''));
        $detail = trim((string) ($availability['detail'] ?? ''));

        $html = '<div class="vms-fd-status-stack">';
        $html .= '<span class="vms-fd-pill is-av-' . esc_attr($state) . '">' . esc_html($label) . '</span>';
        if ($source !== '' || $detail !== '') {
            $bits = array();
            if ($source !== '') {
                $bits[] = $source;
            }
            if ($detail !== '') {
                $bits[] = $detail;
            }
            $html .= '<div class="vms-fd-subtle">' . esc_html(implode(' | ', $bits)) . '</div>';
        }
        $html .= '</div>';

        return $html;
    }
}

if (!function_exists('vms_fd_render_board_signal_line')) {
    function vms_fd_render_board_signal_line(string $label, array $counts): string
    {
        $parts = array();
        $parts[] = sprintf(__('%1$s avail', 'vms-fill-dates'), (int) ($counts['available'] ?? 0));
        $parts[] = sprintf(__('%1$s no reply', 'vms-fill-dates'), (int) ($counts['no-response'] ?? 0));
        if (!empty($counts['conflict'])) {
            $parts[] = sprintf(__('%1$s conflict', 'vms-fill-dates'), (int) $counts['conflict']);
        }

        return '<div><strong>' . esc_html($label) . ':</strong> ' . esc_html(implode(' | ', $parts)) . '</div>';
    }
}

if (!function_exists('vms_fd_render_filters')) {
    function vms_fd_render_filters(array $filters, array $venues_map, array $terms_map): void
    {
        echo '<form method="get" class="vms-fd-panel vms-fd-filters" data-vms-tour="fill-dates.filters">';
        echo '<input type="hidden" name="page" value="vms-fill-dates">';

        echo '<div class="vms-fd-filter-grid">';

        echo '<label class="vms-fd-field"><span>' . esc_html__('Venue', 'vms-fill-dates') . '</span>';
        echo '<select name="venue_id">';
        echo '<option value="0">' . esc_html__('All venues', 'vms-fill-dates') . '</option>';
        foreach ($venues_map as $venue_id => $label) {
            echo '<option value="' . esc_attr((string) $venue_id) . '" ' . selected((int) $filters['venue_id'], (int) $venue_id, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label>';

        echo '<label class="vms-fd-field"><span>' . esc_html__('Planning window', 'vms-fill-dates') . '</span>';
        echo '<select name="days">';
        foreach (array(30, 60, 90, 120, 180, 365) as $days) {
            echo '<option value="' . esc_attr((string) $days) . '" ' . selected((int) $filters['days'], $days, false) . '>' . esc_html(sprintf(_n('%d day', '%d days', $days, 'vms-fill-dates'), $days)) . '</option>';
        }
        echo '</select></label>';

        echo '<label class="vms-fd-field"><span>' . esc_html__('Primary candidate type', 'vms-fill-dates') . '</span>';
        echo '<select name="primary_type">';
        echo '<option value="">' . esc_html__('Auto', 'vms-fill-dates') . '</option>';
        foreach ($terms_map as $slug => $name) {
            echo '<option value="' . esc_attr($slug) . '" ' . selected((string) $filters['primary_type'], $slug, false) . '>' . esc_html($name) . '</option>';
        }
        echo '</select></label>';

        echo '<div class="vms-fd-field"><span>' . esc_html__('Statuses', 'vms-fill-dates') . '</span><div class="vms-fd-checklist">';
        foreach (array('draft', 'ready', 'published') as $status) {
            $id = 'vms-fd-status-' . $status;
            echo '<label for="' . esc_attr($id) . '">';
            echo '<input id="' . esc_attr($id) . '" type="checkbox" name="statuses[]" value="' . esc_attr($status) . '" ' . checked(in_array($status, (array) $filters['statuses'], true), true, false) . '>';
            echo '<span>' . esc_html(vms_fd_status_label($status)) . '</span>';
            echo '</label>';
        }
        echo '</div></div>';

        echo '<label class="vms-fd-field vms-fd-toggle"><span>' . esc_html__('Open dates only', 'vms-fill-dates') . '</span>';
        echo '<input type="checkbox" name="open_only" value="1" ' . checked(!empty($filters['open_only']), true, false) . '>';
        echo '</label>';

        echo '</div>';

        echo '<div class="vms-fd-filter-actions">';
        echo '<button type="submit" class="button button-primary">' . esc_html__('Apply Filters', 'vms-fill-dates') . '</button>';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=vms-fill-dates')) . '">' . esc_html__('Reset', 'vms-fill-dates') . '</a>';
        echo '</div>';

        echo '</form>';
    }
}

if (!function_exists('vms_fd_render_board')) {
    function vms_fd_render_board(array $events, array $filters, array $busy_map, array $terms_map): void
    {
        $query_base = array(
            'page' => 'vms-fill-dates',
            'venue_id' => (int) ($filters['venue_id'] ?? 0),
            'days' => (int) ($filters['days'] ?? 120),
            'primary_type' => (string) ($filters['primary_type'] ?? ''),
        );
        if (!empty($filters['open_only'])) {
            $query_base['open_only'] = '1';
        }
        $query_base['statuses'] = array_values(array_filter(array_map('sanitize_key', (array) ($filters['statuses'] ?? array()))));

        echo '<div class="vms-fd-panel" data-vms-tour="fill-dates.board">';
        echo '<table class="widefat striped vms-fd-board-table">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__('Date', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Venue', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Status', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Primary', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Secondary', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Match Signals', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Actions', 'vms-fill-dates') . '</th>';
        echo '</tr></thead><tbody>';

        if (empty($events)) {
            echo '<tr><td colspan="7">' . esc_html__('No matching Event Plans in this window.', 'vms-fill-dates') . '</td></tr>';
            echo '</tbody></table></div>';
            return;
        }

        $rendered = 0;
        foreach ($events as $event) {
            if (!is_array($event)) {
                continue;
            }
            $plan_id = absint($event['event_plan_id'] ?? 0);
            if ($plan_id <= 0) {
                continue;
            }

            $date = (string) ($event['date_key'] ?? '');
            $venue_name = (string) ($event['venue_name'] ?? '');
            $status = sanitize_key((string) ($event['plan_status'] ?? ''));

            $primary_id = vms_fd_get_primary_vendor_id($plan_id);
            $secondary_ids = vms_fd_get_secondary_vendor_ids($plan_id);
            $secondary_type = vms_fd_get_secondary_vendor_type($plan_id);
            $primary_type = vms_fd_resolve_primary_type_slug($plan_id, (string) ($filters['primary_type'] ?? ''));

            $exclude = array_fill_keys(array_merge(array($primary_id), $secondary_ids), true);

            $primary_pool = array_values(array_filter(vms_fd_get_vendor_pool($primary_type), static function ($vendor_id) use ($exclude) {
                return !isset($exclude[$vendor_id]);
            }));
            $primary_counts = vms_fd_count_candidate_states($primary_pool, $date, $busy_map, $plan_id);

            $secondary_pool = array();
            $secondary_counts = array(
                'available' => 0,
                'no-response' => 0,
                'conflict' => 0,
                'unavailable' => 0,
                'current' => 0,
            );
            if ($secondary_type !== '') {
                $secondary_pool = array_values(array_filter(vms_fd_get_vendor_pool($secondary_type), static function ($vendor_id) use ($exclude) {
                    return !isset($exclude[$vendor_id]);
                }));
                $secondary_counts = vms_fd_count_candidate_states($secondary_pool, $date, $busy_map, $plan_id);
            }

            $open_meta = vms_fd_get_secondary_open_slots($plan_id, absint($event['venue_id'] ?? 0), $secondary_type, count($secondary_ids));
            $is_open = ($primary_id <= 0)
                || ($secondary_type !== '' && (!$open_meta['limited'] ? count($secondary_ids) === 0 : $open_meta['open'] > 0));

            if (!empty($filters['open_only']) && !$is_open) {
                continue;
            }

            $match_url = add_query_arg(array_merge($query_base, array('plan_id' => $plan_id)), admin_url('admin.php'));
            $edit_url = get_edit_post_link($plan_id);

            $rendered++;
            echo '<tr>';
            echo '<td><strong>' . esc_html($date) . '</strong></td>';
            echo '<td>' . esc_html($venue_name !== '' ? $venue_name : __('Unassigned venue', 'vms-fill-dates')) . '</td>';
            echo '<td><span class="vms-fd-pill is-status-' . esc_attr($status) . '">' . esc_html(vms_fd_status_label($status)) . '</span>';
            $review = vms_fd_plan_review_state($plan_id);
            if (!empty($review['count'])) {
                echo '<div class="vms-fd-subtle"><strong>' . esc_html__('Needs Review', 'vms-fill-dates') . '</strong> | ' . esc_html(sprintf(_n('%d change', '%d changes', (int) $review['count'], 'vms-fill-dates'), (int) $review['count'])) . '</div>';
            }
            echo '</td>';
            echo '<td>' . esc_html($primary_id > 0 ? vms_fd_vendor_label($primary_id) : __('Open', 'vms-fill-dates')) . '</td>';

            $secondary_label = __('None set', 'vms-fill-dates');
            if ($secondary_type !== '') {
                $type_name = $terms_map[$secondary_type] ?? $secondary_type;
                if (!empty($open_meta['limited'])) {
                    $secondary_label = sprintf('%s | %d/%d', $type_name, (int) $open_meta['filled'], (int) $open_meta['max']);
                } else {
                    $secondary_label = sprintf('%s | %d assigned', $type_name, (int) count($secondary_ids));
                }
            }
            echo '<td>' . esc_html($secondary_label) . '</td>';
            echo '<td>';
            echo vms_fd_render_board_signal_line(__('Primary', 'vms-fill-dates'), $primary_counts);
            echo vms_fd_render_board_signal_line(__('Secondary', 'vms-fill-dates'), $secondary_counts);
            echo '</td>';
            echo '<td class="vms-fd-actions">';
            echo '<a class="button button-primary" href="' . esc_url($match_url) . '">' . esc_html__('Match', 'vms-fill-dates') . '</a>';
            if ($edit_url) {
                echo '<a class="button" href="' . esc_url($edit_url) . '">' . esc_html__('Edit Plan', 'vms-fill-dates') . '</a>';
            }
            echo '</td>';
            echo '</tr>';
        }

        if ($rendered === 0) {
            echo '<tr><td colspan="7">' . esc_html__('No matching Event Plans in this window.', 'vms-fill-dates') . '</td></tr>';
        }

        echo '</tbody></table></div>';
    }
}

if (!function_exists('vms_fd_render_detail')) {
    function vms_fd_render_detail(int $plan_id, array $filters, array $busy_map, array $events, array $terms_map): void
    {
        if ($plan_id <= 0 || get_post_type($plan_id) !== 'vms_event_plan') {
            return;
        }

        $date = vms_fd_get_plan_date($plan_id);
        $venue_id = vms_fd_get_plan_venue_id($plan_id);
        $status = vms_fd_get_plan_status($plan_id);
        $venue_name = $venue_id > 0 ? (string) get_the_title($venue_id) : '';
        $primary_id = vms_fd_get_primary_vendor_id($plan_id);
        $secondary_ids = vms_fd_get_secondary_vendor_ids($plan_id);
        $secondary_type = vms_fd_get_secondary_vendor_type($plan_id);
        $primary_type = vms_fd_resolve_primary_type_slug($plan_id, (string) ($filters['primary_type'] ?? ''));
        $primary_type_name = $primary_type !== '' ? ($terms_map[$primary_type] ?? $primary_type) : __('Any type', 'vms-fill-dates');
        $secondary_type_name = $secondary_type !== '' ? ($terms_map[$secondary_type] ?? $secondary_type) : __('Not set', 'vms-fill-dates');
        $open_meta = vms_fd_get_secondary_open_slots($plan_id, $venue_id, $secondary_type, count($secondary_ids));

        echo '<div class="vms-fd-panel vms-fd-detail" data-vms-tour="fill-dates.detail">';
        echo '<div class="vms-fd-detail-head">';
        echo '<div>';
        echo '<h2>' . esc_html(get_the_title($plan_id)) . '</h2>';
        echo '<p class="description">' . esc_html(sprintf(__('Date: %1$s | Venue: %2$s | Status: %3$s', 'vms-fill-dates'), $date, $venue_name !== '' ? $venue_name : __('Unassigned venue', 'vms-fill-dates'), vms_fd_status_label($status))) . '</p>';
        $review = vms_fd_plan_review_state($plan_id);
        if (!empty($review['count'])) {
            echo '<div class="notice notice-warning inline"><p><strong>' . esc_html__('Needs Review', 'vms-fill-dates') . '</strong> ' . esc_html(sprintf(_n('%d unpublished change since last publish.', '%d unpublished changes since last publish.', (int) $review['count'], 'vms-fill-dates'), (int) $review['count'])) . '</p>';
            if (!empty($review['meta'])) {
                echo '<p class="description">' . esc_html($review['meta']) . '</p>';
            }
            if (!empty($review['summaries'])) {
                echo '<ul class="vms-fd-review-list">';
                foreach (array_slice((array) $review['summaries'], 0, 4) as $summary) {
                    echo '<li>' . esc_html($summary) . '</li>';
                }
                echo '</ul>';
            }
            echo '</div>';
        }
        echo '</div>';
        echo '<div class="vms-fd-detail-actions">';
        $edit_url = get_edit_post_link($plan_id);
        if ($edit_url) {
            echo '<a class="button" href="' . esc_url($edit_url) . '">' . esc_html__('Open Event Plan', 'vms-fill-dates') . '</a>';
        }
        echo '</div></div>';

        echo '<div class="vms-fd-current-grid">';
        echo '<div class="vms-fd-current-card">';
        echo '<h3>' . esc_html__('Current Assignments', 'vms-fill-dates') . '</h3>';
        echo '<p><strong>' . esc_html__('Primary', 'vms-fill-dates') . ':</strong> ' . esc_html($primary_id > 0 ? vms_fd_vendor_label($primary_id) : __('Open', 'vms-fill-dates')) . '</p>';
        echo '<p><strong>' . esc_html__('Primary candidate type', 'vms-fill-dates') . ':</strong> ' . esc_html($primary_type_name) . '</p>';
        echo '<p><strong>' . esc_html__('Secondary type', 'vms-fill-dates') . ':</strong> ' . esc_html($secondary_type_name) . '</p>';
        if (!empty($open_meta['limited'])) {
            echo '<p><strong>' . esc_html__('Secondary slots', 'vms-fill-dates') . ':</strong> ' . esc_html(sprintf(__('%d of %d filled', 'vms-fill-dates'), (int) $open_meta['filled'], (int) $open_meta['max'])) . '</p>';
        } else {
            echo '<p><strong>' . esc_html__('Secondary assigned', 'vms-fill-dates') . ':</strong> ' . esc_html((string) count($secondary_ids)) . '</p>';
        }
        echo '</div>';

        echo '<div class="vms-fd-current-card">';
        echo '<h3>' . esc_html__('Operational Rules', 'vms-fill-dates') . '</h3>';
        echo '<ul class="vms-fd-rules">';
        echo '<li>' . esc_html__('Published assignments count as Booked.', 'vms-fill-dates') . '</li>';
        echo '<li>' . esc_html__('Draft and Ready assignments count as Tentative.', 'vms-fill-dates') . '</li>';
        echo '<li>' . esc_html__('Manual Available can override pattern or ICS, but not another live assignment on the same date.', 'vms-fill-dates') . '</li>';
        echo '</ul>';
        echo '</div>';
        echo '</div>';

        echo '<div class="vms-fd-match-grid">';
        vms_fd_render_primary_candidates($plan_id, $date, $primary_type, $primary_id, $secondary_ids, $busy_map, $events, $terms_map);
        vms_fd_render_secondary_candidates($plan_id, $date, $secondary_type, $primary_id, $secondary_ids, $busy_map, $events, $terms_map);
        echo '</div>';

        echo '</div>';
    }
}

if (!function_exists('vms_fd_render_primary_candidates')) {
    function vms_fd_render_primary_candidates(int $plan_id, string $date, string $primary_type, int $current_primary_id, array $secondary_ids, array $busy_map, array $events, array $terms_map): void
    {
        $secondary_lookup = array_fill_keys(array_filter($secondary_ids), true);
        $rows = array();
        foreach (vms_fd_get_vendor_pool($primary_type) as $vendor_id) {
            $assigned_here = ($vendor_id === $current_primary_id);
            $availability = vms_fd_vendor_availability($vendor_id, $date, $busy_map, $plan_id, array(
                'assigned_here' => $assigned_here,
                'assigned_role' => __('Primary', 'vms-fill-dates'),
            ));
            $contact = vms_fd_vendor_contact_summary($vendor_id);
            $type = vms_fd_vendor_type_info($vendor_id);
            $rows[] = array(
                'vendor_id' => $vendor_id,
                'name' => vms_fd_vendor_label($vendor_id),
                'availability' => $availability,
                'contact' => $contact,
                'type' => $type,
                'last_worked' => vms_fd_last_worked_date($vendor_id, $events),
                'already_assigned_here' => $assigned_here,
                'blocked_here' => isset($secondary_lookup[$vendor_id]),
            );
        }
        vms_fd_sort_candidate_rows($rows);

        echo '<div class="vms-fd-panel" data-vms-tour="fill-dates.primary">';
        echo '<h3>' . esc_html__('Primary Vendor Candidates', 'vms-fill-dates') . '</h3>';
        echo '<p class="description">' . esc_html__('Choose one candidate and assign them as the primary vendor for this date.', 'vms-fill-dates') . '</p>';

        echo '<form method="post">';
        wp_nonce_field('vms_fd_action', 'vms_fd_nonce');
        echo '<input type="hidden" name="vms_fd_action" value="assign_primary">';
        echo '<input type="hidden" name="plan_id" value="' . esc_attr((string) $plan_id) . '">';
        echo '<table class="widefat striped vms-fd-candidate-table">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__('Pick', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Vendor', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Status', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Location / Contact', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Last Worked', 'vms-fill-dates') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $vendor_id = (int) $row['vendor_id'];
            $state = sanitize_key((string) ($row['availability']['state'] ?? 'no-response'));
            $disabled = empty($row['availability']['assignable']) || !empty($row['already_assigned_here']) || !empty($row['blocked_here']);
            echo '<tr>';
            echo '<td><input type="radio" name="primary_vendor_id" value="' . esc_attr((string) $vendor_id) . '"' . disabled($disabled, true, false) . '></td>';
            echo '<td><strong>' . esc_html((string) $row['name']) . '</strong><div class="vms-fd-subtle">' . esc_html((string) ($row['type']['name'] ?? '')) . '</div>';
            if (!empty($row['already_assigned_here'])) {
                echo '<div class="vms-fd-subtle">' . esc_html__('Currently assigned as primary.', 'vms-fill-dates') . '</div>';
            } elseif (!empty($row['blocked_here'])) {
                echo '<div class="vms-fd-subtle">' . esc_html__('Already assigned here as a secondary vendor.', 'vms-fill-dates') . '</div>';
            }
            echo '</td>';
            echo '<td>' . vms_fd_render_availability_badge((array) $row['availability']) . '</td>';
            $contact_bits = array_filter(array(
                (string) ($row['contact']['city_state'] ?? ''),
                (string) ($row['contact']['phone'] ?? ''),
                (string) ($row['contact']['email'] ?? ''),
            ));
            echo '<td>' . esc_html(implode(' | ', $contact_bits)) . '</td>';
            echo '<td>' . esc_html((string) ($row['last_worked'] ?: '-')) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '<div class="vms-fd-form-actions">';
        echo '<button type="submit" class="button button-primary">' . esc_html__('Assign Selected Primary', 'vms-fill-dates') . '</button>';
        if ($current_primary_id > 0) {
            echo '<button type="submit" name="vms_fd_action" value="clear_primary" class="button">' . esc_html__('Clear Primary', 'vms-fill-dates') . '</button>';
        }
        echo '</div>';
        echo '</form>';
        echo '</div>';
    }
}

if (!function_exists('vms_fd_render_secondary_candidates')) {
    function vms_fd_render_secondary_candidates(int $plan_id, string $date, string $secondary_type, int $primary_id, array $current_secondary_ids, array $busy_map, array $events, array $terms_map): void
    {
        echo '<div class="vms-fd-panel" data-vms-tour="fill-dates.secondary">';
        echo '<h3>' . esc_html__('Secondary Vendor Candidates', 'vms-fill-dates') . '</h3>';

        if ($secondary_type === '') {
            echo '<p class="description">' . esc_html__('This Event Plan does not have a Secondary Vendor Type yet. Set one on the Event Plan first, then this list will become actionable.', 'vms-fill-dates') . '</p>';
            echo '</div>';
            return;
        }

        $rows = array();
        $current_lookup = array_fill_keys($current_secondary_ids, true);
        $exclude_lookup = array_fill_keys(array_filter(array_merge(array($primary_id), $current_secondary_ids)), true);
        foreach (vms_fd_get_vendor_pool($secondary_type) as $vendor_id) {
            $assigned_here = isset($current_lookup[$vendor_id]);
            $availability = vms_fd_vendor_availability($vendor_id, $date, $busy_map, $plan_id, array(
                'assigned_here' => $assigned_here,
                'assigned_role' => __('Secondary', 'vms-fill-dates'),
            ));
            $contact = vms_fd_vendor_contact_summary($vendor_id);
            $type = vms_fd_vendor_type_info($vendor_id);
            $rows[] = array(
                'vendor_id' => $vendor_id,
                'name' => vms_fd_vendor_label($vendor_id),
                'availability' => $availability,
                'contact' => $contact,
                'type' => $type,
                'last_worked' => vms_fd_last_worked_date($vendor_id, $events),
                'already_assigned_here' => $assigned_here,
                'blocked_here' => isset($exclude_lookup[$vendor_id]) && !$assigned_here,
            );
        }
        vms_fd_sort_candidate_rows($rows);

        echo '<p class="description">' . esc_html__('Secondary matching supports multi-select so you can attach several vendors to the same date in one pass.', 'vms-fill-dates') . '</p>';

        if (!empty($current_secondary_ids)) {
            echo '<form method="post" class="vms-fd-current-secondary-form">';
            wp_nonce_field('vms_fd_action', 'vms_fd_nonce');
            echo '<input type="hidden" name="vms_fd_action" value="remove_secondary">';
            echo '<input type="hidden" name="plan_id" value="' . esc_attr((string) $plan_id) . '">';
            echo '<input type="hidden" name="secondary_type" value="' . esc_attr($secondary_type) . '">';
            echo '<div class="vms-fd-current-secondary-list">';
            foreach ($current_secondary_ids as $vendor_id) {
                echo '<label><input type="checkbox" name="remove_secondary_vendor_ids[]" value="' . esc_attr((string) $vendor_id) . '"> <span>' . esc_html(vms_fd_vendor_label((int) $vendor_id)) . '</span></label>';
            }
            echo '</div>';
            echo '<div class="vms-fd-form-actions"><button type="submit" class="button">' . esc_html__('Remove Selected Secondary Vendors', 'vms-fill-dates') . '</button></div>';
            echo '</form>';
        }

        echo '<form method="post">';
        wp_nonce_field('vms_fd_action', 'vms_fd_nonce');
        echo '<input type="hidden" name="vms_fd_action" value="add_secondary">';
        echo '<input type="hidden" name="plan_id" value="' . esc_attr((string) $plan_id) . '">';
        echo '<input type="hidden" name="secondary_type" value="' . esc_attr($secondary_type) . '">';
        echo '<table class="widefat striped vms-fd-candidate-table">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__('Pick', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Vendor', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Status', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Location / Contact', 'vms-fill-dates') . '</th>';
        echo '<th>' . esc_html__('Last Worked', 'vms-fill-dates') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $vendor_id = (int) $row['vendor_id'];
            $state = sanitize_key((string) ($row['availability']['state'] ?? 'no-response'));
            $disabled = empty($row['availability']['assignable']) || !empty($row['already_assigned_here']) || !empty($row['blocked_here']);
            echo '<tr>';
            echo '<td><input type="checkbox" name="secondary_vendor_ids[]" value="' . esc_attr((string) $vendor_id) . '"' . disabled($disabled, true, false) . '></td>';
            echo '<td><strong>' . esc_html((string) $row['name']) . '</strong>';
            if (!empty($row['already_assigned_here'])) {
                echo '<div class="vms-fd-subtle">' . esc_html__('Currently assigned here as secondary.', 'vms-fill-dates') . '</div>';
            } elseif (!empty($row['blocked_here'])) {
                echo '<div class="vms-fd-subtle">' . esc_html__('Already assigned here as primary.', 'vms-fill-dates') . '</div>';
            }
            echo '</td>';
            echo '<td>' . vms_fd_render_availability_badge((array) $row['availability']) . '</td>';
            $contact_bits = array_filter(array(
                (string) ($row['contact']['city_state'] ?? ''),
                (string) ($row['contact']['phone'] ?? ''),
                (string) ($row['contact']['email'] ?? ''),
            ));
            echo '<td>' . esc_html(implode(' | ', $contact_bits)) . '</td>';
            echo '<td>' . esc_html((string) ($row['last_worked'] ?: '-')) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '<div class="vms-fd-form-actions">';
        echo '<button type="submit" class="button button-primary">' . esc_html__('Add Selected Secondary Vendors', 'vms-fill-dates') . '</button>';
        echo '</div>';
        echo '</form>';
        echo '</div>';
    }
}

if (!function_exists('vms_fd_render_admin_page_content')) {
    function vms_fd_render_admin_page_content(): void
    {
        if (!vms_fd_vms_ready()) {
            return;
        }

        $filters = vms_fd_parse_request_filters();
        vms_fd_process_post_actions($filters);

        $venues_map = vms_fd_get_venues_map();
        $terms_map = vms_fd_get_terms_map();
        vms_fd_render_filters($filters, $venues_map, $terms_map);

        $busy_statuses = array('draft', 'ready', 'published', 'tentative', 'confirmed');
        $history_events = vms_fd_collect_events((string) $filters['history_start'], (string) $filters['end'], $busy_statuses);
        $busy_map = vms_fd_build_busy_map($history_events);

        $display_events = array_values(array_filter($history_events, static function ($event) use ($filters) {
            if (!is_array($event)) {
                return false;
            }
            $date = (string) ($event['date_key'] ?? '');
            if ($date === '' || $date < (string) $filters['today']) {
                return false;
            }
            return vms_fd_event_matches_filters($event, (int) $filters['venue_id'], (array) $filters['statuses']);
        }));

        vms_fd_render_board($display_events, $filters, $busy_map, $terms_map);

        if (!empty($filters['plan_id'])) {
            vms_fd_render_detail((int) $filters['plan_id'], $filters, $busy_map, $history_events, $terms_map);
        }
    }
}

if (!function_exists('vms_fd_render_admin_page')) {
    function vms_fd_render_admin_page(): void
    {
        $actions_html = '<div class="vms-fd-header-actions" data-vms-tour="fill-dates.help">' . vms_fd_help_button() . '</div>';

        if (function_exists('vms_admin_ui_render_shell')) {
            vms_admin_ui_render_shell(
                array(
                    'title' => __('Fill Dates', 'vms-fill-dates'),
                    'subtitle' => __('Admin-only date-filling workspace for matching scheduled Event Plans with available vendors. This add-on does not change customer-facing ticket or event UI.', 'vms-fill-dates'),
                    'actions_html' => $actions_html,
                    'shell_id' => 'vms-fill-dates-wrap',
                    'content_class' => 'vms-fd-shell',
                ),
                'vms_fd_render_admin_page_content'
            );
            return;
        }

        echo '<div class="wrap">';
        echo '<div class="vms-fd-header" data-vms-tour="fill-dates.help">';
        echo '<div>';
        echo '<h1>' . esc_html__('Fill Dates', 'vms-fill-dates') . '</h1>';
        echo '<p class="description">' . esc_html__('Admin-only date-filling workspace for matching scheduled Event Plans with available vendors. This add-on does not change customer-facing ticket or event UI.', 'vms-fill-dates') . '</p>';
        echo '</div>';
        echo '<div class="vms-fd-header-actions">' . vms_fd_help_button() . '</div>';
        echo '</div>';
        vms_fd_render_admin_page_content();
        echo '</div>';
    }
}
