<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_fd_vms_ready')) {
    function vms_fd_vms_ready(): bool
    {
        return post_type_exists('vms_event_plan') && post_type_exists('vms_vendor');
    }
}

if (!function_exists('vms_fd_meta_key')) {
    function vms_fd_meta_key(string $entity, string $key, string $fallback): string
    {
        if (function_exists('vms_meta_key')) {
            $resolved = (string) vms_meta_key($entity, $key);
            if ($resolved !== '') {
                return $resolved;
            }
        }
        return $fallback;
    }
}

if (!function_exists('vms_fd_get_primary_vendor_id')) {
    function vms_fd_get_primary_vendor_id(int $plan_id): int
    {
        if (function_exists('vms_calendar_plan_vendor_ids')) {
            $ids = (array) vms_calendar_plan_vendor_ids($plan_id);
            return absint($ids['band_id'] ?? 0);
        }

        $key = vms_fd_meta_key('event_plan', 'band_vendor_id', '_vms_band_vendor_id');
        return absint(get_post_meta($plan_id, $key, true));
    }
}

if (!function_exists('vms_fd_get_secondary_vendor_ids')) {
    function vms_fd_get_secondary_vendor_ids(int $plan_id): array
    {
        if (function_exists('vms_calendar_plan_vendor_ids')) {
            $ids = (array) vms_calendar_plan_vendor_ids($plan_id);
            return array_values(array_unique(array_filter(array_map('absint', (array) ($ids['secondary_ids'] ?? array())))));
        }

        $key = vms_fd_meta_key('event_plan', 'secondary_vendor_ids', '_vms_secondary_vendor_ids');
        $idx = vms_fd_meta_key('event_plan', 'secondary_vendor_id', '_vms_secondary_vendor_id');
        $secondary = get_post_meta($plan_id, $key, true);
        if (!is_array($secondary)) {
            $secondary = get_post_meta($plan_id, $idx, false);
        }
        return array_values(array_unique(array_filter(array_map('absint', (array) $secondary))));
    }
}

if (!function_exists('vms_fd_get_secondary_vendor_type')) {
    function vms_fd_get_secondary_vendor_type(int $plan_id): string
    {
        $key = vms_fd_meta_key('event_plan', 'secondary_vendor_type', '_vms_secondary_vendor_type');
        return sanitize_key((string) get_post_meta($plan_id, $key, true));
    }
}

if (!function_exists('vms_fd_get_plan_date')) {
    function vms_fd_get_plan_date(int $plan_id): string
    {
        $key = vms_fd_meta_key('event_plan', 'date', '_vms_event_date');
        $date = (string) get_post_meta($plan_id, $key, true);
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? $date : '';
    }
}

if (!function_exists('vms_fd_get_plan_venue_id')) {
    function vms_fd_get_plan_venue_id(int $plan_id): int
    {
        $key = vms_fd_meta_key('event_plan', 'venue_id', '_vms_venue_id');
        return absint(get_post_meta($plan_id, $key, true));
    }
}

if (!function_exists('vms_fd_get_plan_status')) {
    function vms_fd_get_plan_status(int $plan_id): string
    {
        if (function_exists('vms_event_plan_get_status')) {
            return sanitize_key((string) vms_event_plan_get_status($plan_id, 'schedule_admin'));
        }
        $key = vms_fd_meta_key('event_plan', 'status', '_vms_event_plan_status');
        return sanitize_key((string) get_post_meta($plan_id, $key, true));
    }
}

if (!function_exists('vms_fd_assignment_status_for_plan')) {
    function vms_fd_assignment_status_for_plan(string $status): string
    {
        if (function_exists('vms_calendar_assignment_status_for_plan')) {
            return (string) (vms_calendar_assignment_status_for_plan($status) ?? '');
        }

        $status = sanitize_key($status);
        if ($status === 'published') {
            return 'booked';
        }
        if (in_array($status, array('draft', 'ready', 'tentative', 'confirmed'), true)) {
            return 'tentative';
        }
        return '';
    }
}

if (!function_exists('vms_fd_status_label')) {
    function vms_fd_status_label(string $status): string
    {
        $status = sanitize_key($status);
        $map = array(
            'draft' => __('Draft', 'vms-fill-dates'),
            'ready' => __('Ready', 'vms-fill-dates'),
            'published' => __('Published', 'vms-fill-dates'),
            'tentative' => __('Tentative', 'vms-fill-dates'),
            'confirmed' => __('Confirmed', 'vms-fill-dates'),
            'cancelled' => __('Cancelled', 'vms-fill-dates'),
            'canceled' => __('Cancelled', 'vms-fill-dates'),
            'archived' => __('Archived', 'vms-fill-dates'),
        );
        return $map[$status] ?? ucfirst($status ?: 'unknown');
    }
}

if (!function_exists('vms_fd_vendor_type_info')) {
    function vms_fd_vendor_type_info(int $vendor_id): array
    {
        if (function_exists('vms_calendar_vendor_primary_type')) {
            $info = (array) vms_calendar_vendor_primary_type($vendor_id);
            return array(
                'slug' => sanitize_key((string) ($info['slug'] ?? 'untyped')),
                'name' => sanitize_text_field((string) ($info['name'] ?? __('Other', 'vms-fill-dates'))),
            );
        }

        $terms = wp_get_post_terms($vendor_id, 'vms_vendor_type');
        if (is_wp_error($terms) || empty($terms)) {
            return array('slug' => 'untyped', 'name' => __('Other', 'vms-fill-dates'));
        }
        $term = $terms[0];
        return array(
            'slug' => sanitize_key((string) ($term->slug ?? 'untyped')),
            'name' => sanitize_text_field((string) ($term->name ?? __('Other', 'vms-fill-dates'))),
        );
    }
}

if (!function_exists('vms_fd_vendor_label')) {
    function vms_fd_vendor_label(int $vendor_id): string
    {
        $title = trim((string) get_the_title($vendor_id));
        return $title !== '' ? $title : sprintf(__('Vendor #%d', 'vms-fill-dates'), $vendor_id);
    }
}

if (!function_exists('vms_fd_vendor_contact_summary')) {
    function vms_fd_vendor_contact_summary(int $vendor_id): array
    {
        $email_key = vms_fd_meta_key('vendor', 'primary_email', '_vms_vendor_primary_email');
        $phone_key = vms_fd_meta_key('vendor', 'primary_phone', '_vms_vendor_primary_phone');
        $city_key  = vms_fd_meta_key('vendor', 'city', '_vms_city');
        $state_key = vms_fd_meta_key('vendor', 'state', '_vms_state');

        $email = (string) get_post_meta($vendor_id, $email_key, true);
        if ($email === '') {
            $email = (string) get_post_meta($vendor_id, '_vms_contact_email', true);
        }

        $phone = (string) get_post_meta($vendor_id, $phone_key, true);
        if ($phone === '') {
            $phone = (string) get_post_meta($vendor_id, '_vms_contact_phone', true);
        }

        $city = (string) get_post_meta($vendor_id, $city_key, true);
        $state = (string) get_post_meta($vendor_id, $state_key, true);
        if ($city === '' && $state === '') {
            $legacy = trim((string) get_post_meta($vendor_id, '_vms_vendor_location', true));
            if ($legacy !== '') {
                $parts = array_map('trim', explode(',', $legacy, 2));
                $city = $parts[0] ?? '';
                $state = $parts[1] ?? '';
            }
        }

        return array(
            'email' => sanitize_email($email),
            'phone' => sanitize_text_field($phone),
            'city_state' => trim(implode(', ', array_filter(array($city, $state)))),
        );
    }
}

if (!function_exists('vms_fd_get_vendor_pool')) {
    function vms_fd_get_vendor_pool(string $type_slug = ''): array
    {
        $type_slug = sanitize_key($type_slug);
        $args = array(
            'post_type' => 'vms_vendor',
            'post_status' => array('publish', 'private'),
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
            'fields' => 'ids',
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => true,
        );
        if ($type_slug !== '') {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'vms_vendor_type',
                    'field' => 'slug',
                    'terms' => array($type_slug),
                ),
            );
        }
        $ids = get_posts($args);
        return array_values(array_unique(array_filter(array_map('absint', (array) $ids))));
    }
}

if (!function_exists('vms_fd_default_primary_type_slug')) {
    function vms_fd_default_primary_type_slug(): string
    {
        $term = get_term_by('slug', 'talent', 'vms_vendor_type');
        if ($term && !is_wp_error($term)) {
            return 'talent';
        }

        $terms = get_terms(array(
            'taxonomy' => 'vms_vendor_type',
            'hide_empty' => false,
            'number' => 1,
            'orderby' => 'name',
            'order' => 'ASC',
        ));
        if (is_array($terms) && !empty($terms) && $terms[0] instanceof WP_Term) {
            return sanitize_key((string) $terms[0]->slug);
        }
        return '';
    }
}

if (!function_exists('vms_fd_resolve_primary_type_slug')) {
    function vms_fd_resolve_primary_type_slug(int $plan_id, string $requested = ''): string
    {
        $requested = sanitize_key($requested);
        if ($requested !== '') {
            return $requested;
        }

        $current_primary = vms_fd_get_primary_vendor_id($plan_id);
        if ($current_primary > 0) {
            $type = vms_fd_vendor_type_info($current_primary);
            if (!empty($type['slug']) && $type['slug'] !== 'untyped') {
                return (string) $type['slug'];
            }
        }

        return vms_fd_default_primary_type_slug();
    }
}

if (!function_exists('vms_fd_get_secondary_open_slots')) {
    function vms_fd_get_secondary_open_slots(int $plan_id, int $venue_id, string $secondary_type, int $filled_count): array
    {
        $secondary_type = sanitize_key($secondary_type);
        $filled_count = max(0, $filled_count);
        $max_slots = 0;
        if ($secondary_type !== '' && function_exists('vms_calendar_get_event_slot_limits')) {
            $limits = (array) vms_calendar_get_event_slot_limits($plan_id, $venue_id);
            $max_slots = max(0, (int) ($limits[$secondary_type] ?? 0));
        }

        return array(
            'filled' => $filled_count,
            'max' => $max_slots,
            'open' => ($max_slots > 0) ? max(0, $max_slots - $filled_count) : 0,
            'limited' => ($max_slots > 0),
        );
    }
}

if (!function_exists('vms_fd_collect_events')) {
    function vms_fd_collect_events(string $start_date, string $end_date, array $statuses = array()): array
    {
        if (!function_exists('vms_get_calendar_events')) {
            return array();
        }

        if (empty($statuses)) {
            $statuses = array('draft', 'ready', 'published', 'tentative', 'confirmed');
        }

        return (array) vms_get_calendar_events(array(
            'start_date' => $start_date,
            'end_date' => $end_date,
            'context' => 'admin',
            'include_past' => true,
            'include_statuses' => $statuses,
        ));
    }
}

if (!function_exists('vms_fd_build_busy_map')) {
    function vms_fd_build_busy_map(array $events): array
    {
        $busy_map = array();

        foreach ($events as $event) {
            if (!is_array($event)) {
                continue;
            }

            $date = (string) ($event['date_key'] ?? '');
            $plan_id = absint($event['event_plan_id'] ?? 0);
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || $plan_id <= 0) {
                continue;
            }

            $busy_status = vms_fd_assignment_status_for_plan((string) ($event['plan_status'] ?? ''));
            if ($busy_status === '') {
                continue;
            }

            $primary_id = vms_fd_get_primary_vendor_id($plan_id);
            $secondary_ids = vms_fd_get_secondary_vendor_ids($plan_id);
            $vendor_ids = array_values(array_unique(array_filter(array_merge(array($primary_id), $secondary_ids))));

            foreach ($vendor_ids as $vendor_id) {
                if (!isset($busy_map[$date])) {
                    $busy_map[$date] = array();
                }
                if (!isset($busy_map[$date][$vendor_id])) {
                    $busy_map[$date][$vendor_id] = array(
                        'booked' => array(),
                        'tentative' => array(),
                    );
                }
                $busy_map[$date][$vendor_id][$busy_status][$plan_id] = $plan_id;
            }
        }

        return $busy_map;
    }
}


if (!function_exists('vms_fd_normalize_manual_availability')) {
    function vms_fd_normalize_manual_availability(int $vendor_id): array
    {
        $manual = get_post_meta($vendor_id, '_vms_availability_manual', true);
        if (!is_array($manual)) {
            $manual = array();
        }

        $normalized = array();
        foreach ($manual as $date => $state) {
            $date = sanitize_text_field((string) $date);
            $state = sanitize_key((string) $state);
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                continue;
            }
            if (!in_array($state, array('available', 'unavailable'), true)) {
                continue;
            }
            $normalized[$date] = $state;
        }

        return $normalized;
    }
}

if (!function_exists('vms_fd_normalize_pattern_days')) {
    function vms_fd_normalize_pattern_days(int $vendor_id): array
    {
        $pattern_days = get_post_meta($vendor_id, '_vms_pattern_days', true);
        if (!is_array($pattern_days)) {
            $pattern_days = array();
        }

        $pattern_days = array_values(array_unique(array_filter(array_map('intval', $pattern_days), static function ($d) {
            return $d >= 0 && $d <= 6;
        })));
        sort($pattern_days);

        return $pattern_days;
    }
}

if (!function_exists('vms_fd_normalize_ics_unavailable')) {
    function vms_fd_normalize_ics_unavailable(int $vendor_id): array
    {
        $ics_unavailable = get_post_meta($vendor_id, '_vms_ics_unavailable', true);
        if (!is_array($ics_unavailable)) {
            $ics_unavailable = array();
        }

        $is_list = (array_keys($ics_unavailable) === range(0, max(0, count($ics_unavailable) - 1)));
        if (!$is_list && !empty($ics_unavailable)) {
            $ics_unavailable = array_keys($ics_unavailable);
        } elseif (empty($ics_unavailable)) {
            $ics_layer = get_post_meta($vendor_id, '_vms_availability_ics', true);
            if (is_array($ics_layer) && !empty($ics_layer)) {
                $ics_unavailable = array_keys($ics_layer);
            }
        }

        return array_values(array_unique(array_filter(array_map('sanitize_text_field', $ics_unavailable), static function ($date) {
            return preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $date);
        })));
    }
}

if (!function_exists('vms_fd_vendor_has_availability_setup')) {
    function vms_fd_vendor_has_availability_setup(int $vendor_id): bool
    {
        $manual = vms_fd_normalize_manual_availability($vendor_id);
        $pattern_enabled = (int) get_post_meta($vendor_id, '_vms_pattern_enabled', true);
        $pattern_days = vms_fd_normalize_pattern_days($vendor_id);
        $ics_url = trim((string) get_post_meta($vendor_id, '_vms_ics_url', true));
        $ics_unavailable = vms_fd_normalize_ics_unavailable($vendor_id);

        return !empty($manual)
            || ($pattern_enabled && !empty($pattern_days))
            || $ics_url !== ''
            || !empty($ics_unavailable);
    }
}

if (!function_exists('vms_fd_availability_source_label')) {
    function vms_fd_availability_source_label(string $reason): string
    {
        $reason = sanitize_key($reason);
        $map = array(
            'assigned_here' => __('Current assignment', 'vms-fill-dates'),
            'manual' => __('Manual', 'vms-fill-dates'),
            'pattern' => __('Pattern', 'vms-fill-dates'),
            'ics' => __('ICS', 'vms-fill-dates'),
            'assigned_elsewhere' => __('Conflict', 'vms-fill-dates'),
            'no_response' => __('No reply', 'vms-fill-dates'),
            'invalid' => __('Unknown', 'vms-fill-dates'),
        );
        return $map[$reason] ?? __('Unknown', 'vms-fill-dates');
    }
}

if (!function_exists('vms_fd_vendor_availability')) {
    function vms_fd_vendor_availability(int $vendor_id, string $date, array $busy_map = array(), int $current_plan_id = 0, array $context = array()): array
    {
        $vendor_id = absint($vendor_id);
        $current_plan_id = absint($current_plan_id);
        if ($vendor_id <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return array(
                'state' => 'no-response',
                'label' => __('No reply', 'vms-fill-dates'),
                'reason' => 'invalid',
                'detail' => __('Date or vendor record is invalid.', 'vms-fill-dates'),
                'source' => vms_fd_availability_source_label('invalid'),
                'conflict' => false,
                'assignable' => false,
            );
        }

        $assigned_here = !empty($context['assigned_here']);
        $assigned_role = sanitize_text_field((string) ($context['assigned_role'] ?? ''));
        if ($assigned_here) {
            $detail = $assigned_role !== ''
                ? sprintf(__('Assigned on this Event Plan as %s.', 'vms-fill-dates'), strtolower($assigned_role))
                : __('Assigned on this Event Plan.', 'vms-fill-dates');

            return array(
                'state' => 'current',
                'label' => __('Current assignment', 'vms-fill-dates'),
                'reason' => 'assigned_here',
                'detail' => $detail,
                'source' => vms_fd_availability_source_label('assigned_here'),
                'conflict' => false,
                'assignable' => false,
            );
        }

        $busy = $busy_map[$date][$vendor_id] ?? array('booked' => array(), 'tentative' => array());
        $except = ($current_plan_id > 0) ? array($current_plan_id => true) : array();
        $booked = array_diff_key((array) ($busy['booked'] ?? array()), $except);
        $tentative = array_diff_key((array) ($busy['tentative'] ?? array()), $except);

        if (!empty($booked)) {
            return array(
                'state' => 'booked',
                'label' => __('Booked elsewhere', 'vms-fill-dates'),
                'reason' => 'assigned_elsewhere',
                'detail' => __('Booked on another Event Plan for this same date.', 'vms-fill-dates'),
                'source' => vms_fd_availability_source_label('assigned_elsewhere'),
                'conflict' => true,
                'assignable' => false,
            );
        }
        if (!empty($tentative)) {
            return array(
                'state' => 'tentative',
                'label' => __('Tentative elsewhere', 'vms-fill-dates'),
                'reason' => 'assigned_elsewhere',
                'detail' => __('Tentatively assigned on another Event Plan for this same date.', 'vms-fill-dates'),
                'source' => vms_fd_availability_source_label('assigned_elsewhere'),
                'conflict' => true,
                'assignable' => false,
            );
        }

        $manual = vms_fd_normalize_manual_availability($vendor_id);
        $manual_state = isset($manual[$date]) ? sanitize_key((string) $manual[$date]) : '';
        if ($manual_state === 'available') {
            return array(
                'state' => 'available',
                'label' => __('Available', 'vms-fill-dates'),
                'reason' => 'manual',
                'detail' => __('Marked available manually for this date.', 'vms-fill-dates'),
                'source' => vms_fd_availability_source_label('manual'),
                'conflict' => false,
                'assignable' => true,
            );
        }
        if ($manual_state === 'unavailable') {
            return array(
                'state' => 'unavailable',
                'label' => __('Unavailable', 'vms-fill-dates'),
                'reason' => 'manual',
                'detail' => __('Marked unavailable manually for this date.', 'vms-fill-dates'),
                'source' => vms_fd_availability_source_label('manual'),
                'conflict' => false,
                'assignable' => false,
            );
        }

        $pattern_enabled = (int) get_post_meta($vendor_id, '_vms_pattern_enabled', true);
        $pattern_days = vms_fd_normalize_pattern_days($vendor_id);
        $pattern_matches = false;
        if ($pattern_enabled && !empty($pattern_days)) {
            try {
                $dt = new DateTimeImmutable($date . ' 12:00:00', function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC'));
                $dow = (int) $dt->format('w');
                if (!in_array($dow, $pattern_days, true)) {
                    return array(
                        'state' => 'unavailable',
                        'label' => __('Unavailable', 'vms-fill-dates'),
                        'reason' => 'pattern',
                        'detail' => __('Outside the vendor\'s weekly availability pattern.', 'vms-fill-dates'),
                        'source' => vms_fd_availability_source_label('pattern'),
                        'conflict' => false,
                        'assignable' => false,
                    );
                }
                $pattern_matches = true;
            } catch (Exception $e) {
                $pattern_matches = false;
            }
        }

        $ics_unavailable = vms_fd_normalize_ics_unavailable($vendor_id);
        if (in_array($date, $ics_unavailable, true)) {
            return array(
                'state' => 'unavailable',
                'label' => __('Unavailable', 'vms-fill-dates'),
                'reason' => 'ics',
                'detail' => __('Blocked by synced calendar (ICS).', 'vms-fill-dates'),
                'source' => vms_fd_availability_source_label('ics'),
                'conflict' => false,
                'assignable' => false,
            );
        }

        if ($pattern_matches) {
            return array(
                'state' => 'available',
                'label' => __('Available', 'vms-fill-dates'),
                'reason' => 'pattern',
                'detail' => __('Matches the vendor\'s weekly availability pattern.', 'vms-fill-dates'),
                'source' => vms_fd_availability_source_label('pattern'),
                'conflict' => false,
                'assignable' => true,
            );
        }

        $detail = vms_fd_vendor_has_availability_setup($vendor_id)
            ? __('No explicit availability signal was found for this date.', 'vms-fill-dates')
            : __('Vendor has not set availability yet.', 'vms-fill-dates');

        return array(
            'state' => 'no-response',
            'label' => __('No reply', 'vms-fill-dates'),
            'reason' => 'no_response',
            'detail' => $detail,
            'source' => vms_fd_availability_source_label('no_response'),
            'conflict' => false,
            'assignable' => true,
        );
    }
}

if (!function_exists('vms_fd_last_worked_date')) {
    function vms_fd_last_worked_date(int $vendor_id, array $events): string
    {
        $vendor_id = absint($vendor_id);
        if ($vendor_id <= 0) {
            return '';
        }

        $today = wp_date('Y-m-d', time(), function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC'));
        $last = '';
        foreach ($events as $event) {
            if (!is_array($event)) {
                continue;
            }
            $date = (string) ($event['date_key'] ?? '');
            if ($date === '' || $date > $today) {
                continue;
            }
            $plan_id = absint($event['event_plan_id'] ?? 0);
            if ($plan_id <= 0) {
                continue;
            }
            $ids = array_merge(array(vms_fd_get_primary_vendor_id($plan_id)), vms_fd_get_secondary_vendor_ids($plan_id));
            if (in_array($vendor_id, array_filter(array_map('absint', $ids)), true) && $date > $last) {
                $last = $date;
            }
        }
        return $last;
    }
}

if (!function_exists('vms_fd_count_candidate_states')) {
    function vms_fd_count_candidate_states(array $vendor_ids, string $date, array $busy_map, int $plan_id, array $context_map = array()): array
    {
        $counts = array(
            'available' => 0,
            'no-response' => 0,
            'conflict' => 0,
            'unavailable' => 0,
            'current' => 0,
        );

        foreach ($vendor_ids as $vendor_id) {
            $vendor_id = absint($vendor_id);
            if ($vendor_id <= 0) {
                continue;
            }
            $availability = vms_fd_vendor_availability($vendor_id, $date, $busy_map, $plan_id, (array) ($context_map[$vendor_id] ?? array()));
            $state = sanitize_key((string) ($availability['state'] ?? 'no-response'));
            if (in_array($state, array('booked', 'tentative'), true) || !empty($availability['conflict'])) {
                $counts['conflict']++;
                continue;
            }
            if (isset($counts[$state])) {
                $counts[$state]++;
            }
        }

        return $counts;
    }
}

if (!function_exists('vms_fd_get_terms_map')) {
    function vms_fd_get_terms_map(): array
    {
        $terms = get_terms(array(
            'taxonomy' => 'vms_vendor_type',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ));
        $map = array();
        if (is_array($terms)) {
            foreach ($terms as $term) {
                if ($term instanceof WP_Term) {
                    $map[sanitize_key((string) $term->slug)] = sanitize_text_field((string) $term->name);
                }
            }
        }
        return $map;
    }
}

if (!function_exists('vms_fd_get_venues_map')) {
    function vms_fd_get_venues_map(): array
    {
        $posts = get_posts(array(
            'post_type' => 'vms_venue',
            'post_status' => array('publish', 'private', 'draft'),
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        $map = array();
        foreach ((array) $posts as $post) {
            if ($post instanceof WP_Post) {
                $map[(int) $post->ID] = (string) $post->post_title;
            }
        }
        return $map;
    }
}

if (!function_exists('vms_fd_upsert_secondary_vendor_ids')) {
    function vms_fd_upsert_secondary_vendor_ids(int $plan_id, string $type_slug, array $vendor_ids): void
    {
        $plan_id = absint($plan_id);
        if ($plan_id <= 0) {
            return;
        }

        $type_slug = sanitize_key($type_slug);
        $vendor_ids = array_values(array_unique(array_filter(array_map('absint', $vendor_ids))));

        if (function_exists('vms_event_plan_set_secondary_vendors')) {
            vms_event_plan_set_secondary_vendors($plan_id, $type_slug, $vendor_ids);
            return;
        }

        $key = vms_fd_meta_key('event_plan', 'secondary_vendor_ids', '_vms_secondary_vendor_ids');
        $idx = vms_fd_meta_key('event_plan', 'secondary_vendor_id', '_vms_secondary_vendor_id');
        update_post_meta($plan_id, $key, $vendor_ids);
        delete_post_meta($plan_id, $idx);
        foreach ($vendor_ids as $vendor_id) {
            add_post_meta($plan_id, $idx, $vendor_id, false);
        }
    }
}

if (!function_exists('vms_fd_set_primary_vendor')) {
    function vms_fd_set_primary_vendor(int $plan_id, int $vendor_id): void
    {
        $key = vms_fd_meta_key('event_plan', 'band_vendor_id', '_vms_band_vendor_id');
        update_post_meta($plan_id, $key, absint($vendor_id));
    }
}

if (!function_exists('vms_fd_event_matches_filters')) {
    function vms_fd_event_matches_filters(array $event, int $venue_id, array $statuses): bool
    {
        $event_venue = absint($event['venue_id'] ?? 0);
        $event_status = sanitize_key((string) ($event['plan_status'] ?? ''));

        if ($venue_id > 0 && $event_venue !== $venue_id) {
            return false;
        }
        if (!empty($statuses) && !in_array($event_status, $statuses, true)) {
            return false;
        }
        return true;
    }
}

if (!function_exists('vms_fd_clean_text')) {
    function vms_fd_clean_text(string $text): string
    {
        if (function_exists('vms_event_plan_review_clean_text')) {
            return (string) vms_event_plan_review_clean_text($text);
        }

        $text = wp_strip_all_tags((string) $text);
        $text = str_replace(
            array('\u2192', 'u2192', '→', 'Â·', '·', 'â€¢', '—', '–', 'â€”', 'â€“', 'Â'),
            array(' to ', ' to ', ' to ', ' | ', ' | ', ' * ', ' - ', ' - ', ' - ', ' - ', ''),
            $text
        );
        $text = preg_replace('/\s+/', ' ', $text);
        return trim((string) $text);
    }
}


if (!function_exists('vms_fd_plan_review_state')) {
    function vms_fd_plan_review_state(int $plan_id): array
    {
        if (!function_exists('vms_event_plan_review_get_changes')) {
            return array(
                'count' => 0,
                'summaries' => array(),
                'meta' => '',
            );
        }

        $changes = (array) vms_event_plan_review_get_changes($plan_id);
        $items = isset($changes['changes']) && is_array($changes['changes']) ? (array) $changes['changes'] : array();
        $count = max(0, (int) ($changes['count'] ?? count($items)));
        $summaries = array();
        foreach ($items as $change) {
            $summary = trim((string) ($change['summary'] ?? ''));
            if ($summary !== '') {
                $summaries[] = vms_fd_clean_text($summary);
            }
        }

        $meta_bits = array();
        $changed_at = (string) get_post_meta($plan_id, '_vms_unpublished_changes_at', true);
        $changed_by = absint(get_post_meta($plan_id, '_vms_unpublished_changes_by', true));
        $changed_source = sanitize_key((string) get_post_meta($plan_id, '_vms_unpublished_changes_source', true));
        if ($changed_at !== '') {
            $meta_bits[] = sprintf(__('Updated: %s', 'vms-fill-dates'), $changed_at);
        }
        if ($changed_by > 0) {
            $user = get_userdata($changed_by);
            if ($user instanceof WP_User && $user->display_name !== '') {
                $meta_bits[] = sprintf(__('By: %s', 'vms-fill-dates'), $user->display_name);
            }
        }
        if ($changed_source !== '') {
            $source_label = function_exists('vms_event_plan_review_source_label')
                ? (string) vms_event_plan_review_source_label($changed_source)
                : ucwords(str_replace(array('_', '-'), ' ', $changed_source));
            $meta_bits[] = sprintf(__('Source: %s', 'vms-fill-dates'), $source_label);
        }

        return array(
            'count' => $count,
            'summaries' => $summaries,
            'meta' => implode(' | ', $meta_bits),
        );
    }
}
