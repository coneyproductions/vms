<?php
/**
 * Plugin Name: VMS Fill Dates
 * Description: Admin-only date-filling workspace for matching VMS event plans with available vendors.
 * Version: 0.1.8
 * Author: OpenAI
 * Text Domain: vms-fill-dates
 */

defined('ABSPATH') || exit;

define('VMS_FILL_DATES_VERSION', '0.1.8');
define('VMS_FILL_DATES_FILE', __FILE__);
define('VMS_FILL_DATES_PATH', plugin_dir_path(__FILE__));
define('VMS_FILL_DATES_URL', plugin_dir_url(__FILE__));

require_once VMS_FILL_DATES_PATH . 'includes/helpers.php';
require_once VMS_FILL_DATES_PATH . 'includes/tours.php';
require_once VMS_FILL_DATES_PATH . 'includes/admin-page.php';

if (!function_exists('vms_fd_load_textdomain')) {
    function vms_fd_load_textdomain(): void
    {
        load_plugin_textdomain('vms-fill-dates', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
}
add_action('init', 'vms_fd_load_textdomain', 1);

if (!function_exists('vms_fd_boot')) {
    function vms_fd_boot(): void
    {
        if (function_exists('vms_register_module')) {
            vms_register_module(array(
                'slug' => 'fill_dates',
                'name' => 'Fill Dates',
                'version' => VMS_FILL_DATES_VERSION,
                'premium' => false,
                'description' => 'Admin-only workspace for matching open event dates with available vendors.',
                'source' => 'addon',
            ));
        }
    }
}
add_action('plugins_loaded', 'vms_fd_boot', 20);


if (!function_exists('vms_fd_register_vms_admin_nav')) {
    /**
     * Wire Fill Dates into the compact VMS top-nav IA without growing the left rail.
     *
     * @param array<string,array<string,mixed>> $clusters
     * @return array<string,array<string,mixed>>
     */
    function vms_fd_register_vms_admin_nav(array $clusters): array
    {
        $fill_dates_url = admin_url('admin.php?page=vms-fill-dates');

        if (!isset($clusters['planning']) || !is_array($clusters['planning'])) {
            return $clusters;
        }

        if (!isset($clusters['planning']['items']) || !is_array($clusters['planning']['items'])) {
            $clusters['planning']['items'] = array();
        }

        foreach ((array) $clusters['planning']['items'] as $item) {
            $url = is_array($item) ? (string) ($item['url'] ?? '') : '';
            if ($url === $fill_dates_url) {
                return $clusters;
            }
        }

        $items = (array) $clusters['planning']['items'];
        $insert_at = null;
        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }
            $url = (string) ($item['url'] ?? '');
            if (strpos($url, 'page=vms-schedule') !== false || strpos($url, 'post_type=vms_event_plan') !== false) {
                $insert_at = $index + 1;
            }
        }

        $new_item = array(
            'label' => 'Fill Dates',
            'url'   => $fill_dates_url,
        );

        if ($insert_at === null || $insert_at >= count($items)) {
            $items[] = $new_item;
        } else {
            array_splice($items, $insert_at, 0, array($new_item));
        }

        $clusters['planning']['items'] = $items;
        return $clusters;
    }
}
add_filter('vms_admin_ui_nav_clusters', 'vms_fd_register_vms_admin_nav', 20);

if (!function_exists('vms_fd_register_vms_shell_page')) {
    /**
     * @param string[] $pages
     * @return string[]
     */
    function vms_fd_register_vms_shell_page(array $pages): array
    {
        if (!in_array('vms-fill-dates', $pages, true)) {
            $pages[] = 'vms-fill-dates';
        }
        return $pages;
    }
}
add_filter('vms_admin_ui_shell_pages', 'vms_fd_register_vms_shell_page', 20);

if (!function_exists('vms_fd_register_active_cluster')) {
    function vms_fd_register_active_cluster(string $cluster, string $page, string $post_type): string
    {
        unset($post_type);
        if ($cluster !== '') {
            return $cluster;
        }
        if ($page === 'vms-fill-dates') {
            return 'planning';
        }
        return $cluster;
    }
}
add_filter('vms_admin_ui_active_cluster', 'vms_fd_register_active_cluster', 20, 3);
