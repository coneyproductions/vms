# VMS Fill Dates 0.1.7 Test Plan

1. Confirm plugin header reports `0.1.7`.
2. Confirm `VMS_FILL_DATES_VERSION` reports `0.1.7`.
3. Confirm `vms-build.txt` reports `Version: 0.1.7`.
4. Clear `debug.log`.
5. Load **VMS > Fill Dates**.
6. Confirm no fresh early `vms-fill-dates` translation notices are logged.
7. Launch the Fill Dates guided tour and confirm labels/content still render normally.
