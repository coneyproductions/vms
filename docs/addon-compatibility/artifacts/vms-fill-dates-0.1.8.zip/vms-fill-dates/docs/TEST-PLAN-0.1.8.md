# VMS Fill Dates 0.1.8 Test Plan

1. Confirm the plugin header and `VMS_FILL_DATES_VERSION` report `0.1.8`.
2. Confirm `vms-build.txt` reports `Version: 0.1.8`.
3. Run the returned menu-hook compatibility test against the exact release tree.
4. Run the native admin-notice placement test against the exact release tree.
5. Run the official-five BVM-only runtime suite against the exact release tree.
6. Confirm Fill Dates registers one BVM submenu in both load orders.
7. Confirm its assets and guided tour use the hook returned by WordPress.
8. Confirm the missing-BVM warning appears once in the native admin-notice area.
9. Confirm action-result notices appear only on the Fill Dates screen.
10. Confirm activation state is preserved and no database migration runs during replacement.
