var loadingText = 'Loading event details… Please wait.';
(function () {
  'use strict';

  var builder = document.getElementById('vms-ma-ads-builder-wrap');
  if (!builder || typeof window.VMS_MA === 'undefined') {
    return;
  }

  var defaults = window.vmsMaDefaults || (window.VMS_MA && window.VMS_MA.prefillDefaults) || {};
  var builderPerf = window.vmsMaBuilderPerf || {};
  window.vmsMaDefaults = defaults;
  var audienceCatalog = (window.VMS_MA && VMS_MA.audienceCatalog && typeof VMS_MA.audienceCatalog === 'object') ? VMS_MA.audienceCatalog : {};

  var notices = document.getElementById('vms-ma-builder-notices');
  var toastRoot = document.getElementById('vms-ma-toast-root');
  var buildIdInput = document.getElementById('vms-ma-build-id');
  var lastEventContext = null;
  var loadingOverlay = null;
  var overlayMessage = null;
  var loadingCounter = 0;
  var templateCache = [];
  var buildCache = [];
  var activeBuildId = '';
  var buildHydrationSeq = 0;
  var buildInteractionSeq = 0;
  var buildHydrationState = {
    buildId: '',
    ok: true,
    mismatches: [],
    expectedSignature: '',
    actualSignature: ''
  };
  var metaStatusState = {
    hasIds: false,
    anyActive: false,
    loaded: false,
    lastError: '',
    inFlight: false
  };
  var dirtyState = {
    savedPayloadSignature: '',
    currentPayloadSignature: '',
    isDirty: false
  };
  var recipeAdsetState = {};
  var audienceState = null;
  var lastDryRunResponse = null;
  var perfLoggingEnabled = false;
  try {
    perfLoggingEnabled = !!(
      (builderPerf && builderPerf.debug) ||
      /(?:^|[?&])vms_ma_perf=1(?:&|$)/.test(String(window.location && window.location.search || '')) ||
      String(window.localStorage && window.localStorage.getItem('vms_ma_perf') || '') === '1'
    );
  } catch (perfErr) {
    perfLoggingEnabled = !!(builderPerf && builderPerf.debug);
  }
  if (!Array.isArray(window.vmsMaBuilderPerfLog)) {
    window.vmsMaBuilderPerfLog = [];
  }

  function recordPerf(label, detail) {
    if (!perfLoggingEnabled) {
      return detail || {};
    }
    var entry = Object.assign({
      label: String(label || 'event'),
      at: new Date().toISOString()
    }, detail && typeof detail === 'object' ? detail : {});
    window.vmsMaBuilderPerfLog.push(entry);
    if (window.console && typeof window.console.info === 'function') {
      window.console.info('[MAB perf]', entry.label, entry);
    }
    return entry;
  }

  function startPerfTimer(label, detail) {
    var start = (window.performance && typeof window.performance.now === 'function') ? window.performance.now() : Date.now();
    return function finishPerfTimer(extra) {
      var end = (window.performance && typeof window.performance.now === 'function') ? window.performance.now() : Date.now();
      return recordPerf(label, Object.assign({}, detail && typeof detail === 'object' ? detail : {}, extra && typeof extra === 'object' ? extra : {}, {
        duration_ms: Math.round((end - start) * 10) / 10
      }));
    };
  }

  function getActiveBuildId() {
    var select = byId('vms-ma-build-select');
    return String(activeBuildId || value('vms-ma-build-id') || (select ? select.value : '') || '').trim();
  }

  function setActiveBuildId(id) {
    activeBuildId = String(id || '').trim();
    if (buildIdInput) {
      buildIdInput.value = activeBuildId;
    }
    var select = byId('vms-ma-build-select');
    if (select && select.value !== activeBuildId) {
      select.value = activeBuildId;
    }
  }

  var analyticsState = {
    preset: 'last_7',
    loading: false,
    payload: null
  };

  var placementLabelMap = {
    fb_feed: 'Facebook Feed',
    fb_profile_feed: 'Facebook Profile Feed',
    fb_right_column: 'Facebook Right Column',
    fb_search: 'Facebook Search Results',
    fb_story: 'Facebook Stories',
    fb_reels: 'Facebook Reels',
    ig_feed: 'Instagram Feed',
    ig_search: 'Instagram Search Results',
    ig_explore: 'Instagram Explore Home',
    ig_story: 'Instagram Stories',
    ig_reels: 'Instagram Reels'
  };

  var campaignStrategies = {
    custom: {
      label: 'Custom / manual controls',
      status: 'Custom mode leaves strategy decisions to the operator.'
    },
    direct_create_safe_ticket_push: {
      label: 'Simple one-ad test / troubleshooting recipe',
      preset: 'simple_14_day',
      cta: 'BUY_TICKETS',
      forceBuyTickets: true,
      goal: 'sales',
      optimization: 'purchase_conversions',
      placementsMode: 'manual',
      placements: ['fb_feed', 'fb_profile_feed', 'fb_search', 'fb_story', 'fb_reels', 'ig_feed', 'ig_search', 'ig_explore', 'ig_story', 'ig_reels'],
      creativePolicy: 'off',
      multiAdvertiser: false,
      ageMin: 30,
      ageMax: 65,
      status: 'Use this only when you intentionally want a single ad set for troubleshooting, payload comparison, or a narrow paused-create test. It is not the default concert build path.'
    },
    clean_room_full_push_v2: {
      label: 'Clean-Room Concert Campaign - Full Push v2',
      preset: 'flat_run',
      cta: 'BUY_TICKETS',
      forceBuyTickets: true,
      goal: 'sales',
      optimization: 'purchase_conversions',
      placementsMode: 'manual',
      placements: ['fb_feed', 'ig_feed', 'fb_reels', 'ig_reels', 'fb_story', 'ig_story'],
      creativePolicy: 'off',
      multiAdvertiser: false,
      ageMin: 30,
      ageMax: 65,
      rightColumnDefault: false,
      recipeKey: 'clean_room_full_push_v2',
      status: 'Builds a clean paused campaign recipe from VMS with separate static Feed, Feed 1:1 Video, and Reels/Stories vertical-video ad sets. Right Column is optional, not a default campaign pillar.'
    },
    clean_room_full_push: {
      label: 'Clean-Room Concert Campaign - Full Push (legacy)',
      preset: 'flat_run',
      cta: 'BUY_TICKETS',
      forceBuyTickets: true,
      goal: 'sales',
      optimization: 'purchase_conversions',
      placementsMode: 'manual',
      placements: ['fb_feed', 'ig_feed', 'fb_reels', 'ig_reels', 'fb_story', 'ig_story', 'fb_right_column'],
      creativePolicy: 'off',
      multiAdvertiser: false,
      ageMin: 30,
      ageMax: 65,
      rightColumnDefault: true,
      recipeKey: 'clean_room_full_push',
      status: 'Legacy clean-room recipe with the dedicated Facebook Right Column ad set still included for saved-build compatibility.'
    },
    ticketed_video_local: {
      label: 'Ticketed Concert - Video-Led Local Push',
      preset: 'video_tribute_push',
      cta: 'BUY_TICKETS',
      forceBuyTickets: true,
      goal: 'sales',
      optimization: 'purchase_conversions',
      placementsMode: 'auto',
      creativePolicy: 'off',
      multiAdvertiser: false,
      status: 'Runs video/main creative across the campaign, reserves final-week pressure, and locks the concert CTA to Buy Tickets.'
    },
    standard_ticket_push: {
      label: 'Standard Ticket Push',
      preset: 'promo_bundle_30_14_7',
      cta: 'BUY_TICKETS',
      forceBuyTickets: true,
      goal: 'sales',
      optimization: 'purchase_conversions',
      placementsMode: 'auto',
      creativePolicy: 'off',
      multiAdvertiser: false,
      status: 'General ticketed-event strategy with 30/14/7 pacing and Buy Tickets intent.'
    },
    last_minute_push: {
      label: 'Last-Minute Push',
      preset: 'simple_7_day',
      cta: 'BUY_TICKETS',
      forceBuyTickets: true,
      optimization: 'link_clicks',
      placementsMode: 'auto',
      creativePolicy: 'off',
      multiAdvertiser: false,
      status: 'Compresses spend into the remaining window with simple urgency and a locked Buy Tickets CTA.'
    },
    low_budget_reminder: {
      label: 'Low-Budget Local Reminder',
      preset: 'flat_run',
      cta: 'BUY_TICKETS',
      forceBuyTickets: true,
      optimization: 'link_clicks',
      placementsMode: 'auto',
      creativePolicy: 'off',
      multiAdvertiser: false,
      status: 'Keeps the campaign simple for small budgets: one clean run, clear ticket intent, minimal Meta creative changes.'
    }
  };


  function isCleanRoomStrategyKey(key) {
    key = String(key || '');
    return key === 'clean_room_full_push_v2' || key === 'clean_room_full_push';
  }

  function getCleanRoomRecipeKey() {
    var key = value('vms-ma-strategy-template') || '';
    if (key === 'clean_room_full_push') {
      return 'clean_room_full_push';
    }
    if (key === 'clean_room_full_push_v2') {
      return 'clean_room_full_push_v2';
    }
    return '';
  }

  function isRightColumnSupportEnabled() {
    var strategyKey = value('vms-ma-strategy-template') || '';
    if (strategyKey === 'clean_room_full_push') {
      return true;
    }
    var el = byId('vms-ma-include-right-column');
    return !!(el && el.checked);
  }

  function isOuterTownsAdsetEnabled() {
    var strategyKey = value('vms-ma-strategy-template') || '';
    if (!isCleanRoomStrategyKey(strategyKey)) {
      return false;
    }
    var el = byId('vms-ma-include-outer-towns-adset');
    return !el || !!el.checked;
  }

  function getOuterTownsMode() {
    var select = byId('vms-ma-outer-towns-mode');
    var mode = select ? String(select.value || '').trim() : '';
    return mode === 'expanded_radius' ? 'expanded_radius' : 'listed_only';
  }

  function getOuterTownsDefaultRadius() {
    return Math.max(1, parseIntSafe(value('vms-ma-outer-default-radius'), 15));
  }

  function getOuterTownsLocationsPreview() {
    var raw = value('vms-ma-outer-locations');
    var defaultRadius = getOuterTownsDefaultRadius();
    var rows = String(raw || '').split(/\r\n|\r|\n/).map(function (line) {
      line = String(line || '').trim();
      if (!line || line.charAt(0) === '#') {
        return null;
      }
      var parts = line.split('|');
      var label = String(parts.shift() || '').trim();
      var radius = defaultRadius;
      if (parts.length) {
        var parsed = parseIntSafe(parts.join('|').replace(/[^0-9]/g, ''), 0);
        if (parsed > 0) {
          radius = parsed;
        }
      }
      return label ? (label + ' +' + radius + 'mi') : null;
    }).filter(Boolean);
    return rows.length ? rows.join(', ') : 'No Outer Towns locations entered';
  }

  function hasOuterTownsLocations() {
    var raw = value('vms-ma-outer-locations');
    return String(raw || '').split(/\r\n|\r|\n/).some(function (line) {
      line = String(line || '').trim();
      return !!line && line.charAt(0) !== '#';
    });
  }

  function isCreativeLockdownLocalClean() {
    return (value('vms-ma-creative-automation-policy') || 'off') === 'off' && !(byId('vms-ma-multi-advertiser-ads') && byId('vms-ma-multi-advertiser-ads').checked);
  }

  function getLaunchQaItems() {
    return [
      ['vms-ma-qa-website-highlights', 'Confirm Website Highlights / Web Highlight / Show Spotlights are off in every ad.'],
      ['vms-ma-qa-advantage-off', 'Confirm Advantage+ creative enhancements are off in every ad.'],
      ['vms-ma-qa-multi-off', 'In Meta Edit view, confirm Multi-advertiser ads is unchecked for every ad.'],
      ['vms-ma-qa-placements', 'Confirm only the intended placements are present in Meta Review / targeting.'],
      ['vms-ma-qa-media-match', 'Confirm each ad preview uses only the intended MAB image/video.'],
      ['vms-ma-qa-destination-utm', 'Confirm the clickable preview opens the intended ticket URL and UTM tags are present on every ad.'],
      ['vms-ma-qa-schedule', 'Confirm ad-set start/end schedule is correct in Meta.']
    ];
  }

  function getDsaReadiness() {
    var beneficiary = String(VMS_MA.metaDsaBeneficiary || '').trim();
    var payor = String(VMS_MA.metaDsaPayor || '').trim();
    return {
      beneficiary: beneficiary,
      payor: payor,
      ready: !!(beneficiary && payor)
    };
  }

  function getDsaBlockingMessage() {
    var dsa = getDsaReadiness();
    if (dsa.ready) {
      return '';
    }
    return 'DSA beneficiary and payor are blank in Settings. Add them before any Go Live step.';
  }

  function getPlacementModeWarning() {
    if (getPlacementsMode() === 'manual') {
      return '';
    }
    return 'Automatic placements are enabled. Meta may imply broader placement coverage in edit UI, so recheck actual placements before any Go Live step.';
  }

  function getLaunchQaMissingMessages() {
    return getLaunchQaItems().filter(function (item) {
      var el = byId(item[0]);
      return !(el && el.checked);
    }).map(function (item) { return item[1]; });
  }

  function syncLaunchQaState() {
    var status = byId('vms-ma-launch-qa-status');
    var missing = getLaunchQaMissingMessages();
    if (status) {
      status.textContent = missing.length ? (missing.length + ' manual launch check' + (missing.length === 1 ? '' : 's') + ' still need confirmation.') : 'Manual launch QA complete.';
      status.classList.toggle('vms-ma-inline-warning', !!missing.length);
    }
    resolveApiButtonsState();
  }

  function getVideoFormatSelection() {
    return value('vms-ma-video-format') || 'unknown';
  }

  function hasVerticalVideoSignal() {
    var fmt = getVideoFormatSelection();
    if (fmt === 'tall_9_16' || fmt === 'meta_direct_vertical') {
      return true;
    }
    if (fmt === 'square_1_1' || fmt === 'wide_16_9') {
      return false;
    }
    var variants = collectAdVariants();
    return variants.some(function (variant) {
      return String((variant && variant.media_mode) || '') === 'video' || String((variant && variant.media_mode) || '') === 'video_placeholder';
    });
  }

  function hasVideoPlaceholderSignal() {
    return collectAdVariants().some(function (variant) {
      return String((variant && variant.media_mode) || '') === 'video_placeholder';
    });
  }

  function isVerticalVideoRequired() {
    var el = byId('vms-ma-require-vertical-video');
    return !!(el && el.checked);
  }

  function getCreativeRequirementRows() {
    var strategyKey = value('vms-ma-strategy-template') || 'custom';
    var placements = collectPlacementSelections();
    var placementsMode = getPlacementsMode();
    var includesReels = placementsMode !== 'manual' || placements.indexOf('fb_reels') !== -1 || placements.indexOf('ig_reels') !== -1;
    var includesStories = placementsMode !== 'manual' || placements.indexOf('fb_story') !== -1 || placements.indexOf('ig_story') !== -1;
    var rightColumn = isCleanRoomStrategyKey(strategyKey) && isRightColumnSupportEnabled();
    var squareReady = parseIntSafe(value('vms-ma-image-square-id'), 0) > 0 || parseIntSafe(value('vms-ma-post-id'), 0) > 0;
    var verticalImageReady = parseIntSafe(value('vms-ma-image-vertical-id'), 0) > 0;
    var verticalVideoReady = hasVerticalVideoSignal();
    var videoPlaceholder = hasVideoPlaceholderSignal();
    var strict = isVerticalVideoRequired();
    var rows = [];

    rows.push({
      key: 'square_static',
      label: 'Square image / poster',
      required: 'Feed, video placeholder, optional Right Column',
      status: squareReady ? 'ready' : 'warning',
      badge: squareReady ? 'Ready' : 'Uses event image fallback',
      note: 'Use a clean 1:1 image with text large enough for small previews.'
    });

    rows.push({
      key: 'vertical_video',
      label: 'Tall video',
      required: 'Reels and Stories',
      status: verticalVideoReady ? 'ready' : (strict && (includesReels || includesStories) ? 'blocked' : 'warning'),
      badge: verticalVideoReady ? 'Ready' : (strict ? 'Missing vertical video' : 'Review in Meta'),
      note: verticalVideoReady ? 'Marked as tall/vertical or a video asset is selected.' : 'Add or mark a 9:16 video so Meta does not crop the sides in Reels/Stories.'
    });

    rows.push({
      key: 'feed_video_or_image',
      label: 'Feed creative',
      required: 'Feed/Reels support',
      status: (squareReady || verticalImageReady || verticalVideoReady || videoPlaceholder) ? 'ready' : 'warning',
      badge: (squareReady || verticalImageReady || verticalVideoReady || videoPlaceholder) ? 'Ready' : 'Needs creative',
      note: 'Square/static is safe for feed. Video can be swapped directly in Meta when using a placeholder.'
    });

    rows.push({
      key: 'right_column_static',
      label: 'Right-column image',
      required: rightColumn ? 'Optional Right Column test' : 'Only if optional test is enabled',
      status: !rightColumn ? 'ready' : (squareReady && String(value('vms-ma-headline') || '').trim() ? 'ready' : 'blocked'),
      badge: !rightColumn ? 'Not enabled' : (squareReady ? 'Ready' : 'Missing static image'),
      note: rightColumn ? 'Static image and short headline only. Treat this as a small desktop reminder.' : 'Right Column is off by default in v2.'
    });

    return rows;
  }

  function renderCreativeFormatRequirements() {
    var node = byId('vms-ma-creative-format-slots');
    if (!node) {
      return;
    }
    var rows = getCreativeRequirementRows();
    node.innerHTML = '<div class="vms-ma-format-slot-grid">' + rows.map(function (row) {
      return '<article class="vms-ma-format-slot">' +
        '<strong>' + escapeHtml(row.label) + '</strong>' +
        '<span class="vms-ma-status-badge vms-ma-status-' + escapeHtml(row.status) + '">' + escapeHtml(row.badge) + '</span>' +
        '<small><b>Needed for:</b> ' + escapeHtml(row.required) + '</small>' +
        '<small>' + escapeHtml(row.note) + '</small>' +
      '</article>';
    }).join('') + '</div>';
  }

  function hasFeedSquareVideoVariant() {
    return collectAdVariants().some(function (variant) {
      var mode = normalizeVariantMediaMode((variant && variant.media_mode) || 'shared');
      var slot = normalizeVariantPlacementSlot((variant && variant.placement_slot) || 'auto');
      return (mode === 'video' || mode === 'video_placeholder') && slot === 'feed_square_video';
    });
  }

  function getCurrentAgeRangeLabel() {
    var ageMin = value('vms-ma-age-min');
    var ageMax = value('vms-ma-age-max');
    return (ageMin || '?') + '-' + (ageMax === '65' ? '65+' : (ageMax || '?'));
  }

  function normalizeRecipePercentValue(raw) {
    var percent = parseFloatSafe(raw, 0);
    if (!Number.isFinite(percent)) {
      return 0;
    }
    return Math.max(0, Math.round(percent * 100) / 100);
  }

  function normalizeRecipeBudgetMinorValue(raw) {
    if (raw == null || raw === '') {
      return null;
    }
    return Math.max(0, parseIntSafe(raw, 0));
  }

  function parseRecipeBudgetInputMinor(raw) {
    var dollars = parseFloatSafe(raw, 0);
    if (!Number.isFinite(dollars)) {
      return 0;
    }
    return Math.max(0, Math.round(dollars * 100));
  }

  function formatBudgetInputMinor(minor) {
    return (Math.max(0, parseIntSafe(minor, 0)) / 100).toFixed(2).replace(/\.00$/, '').replace(/(\.\d)0$/, '$1');
  }

  function escapeRecipeSelectorValue(value) {
    var safeValue = String(value || '');
    if (window.CSS && typeof window.CSS.escape === 'function') {
      return window.CSS.escape(safeValue);
    }
    return safeValue.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  }

  function captureRecipeBudgetInputState() {
    var active = document.activeElement;
    if (!active || !active.hasAttribute || !active.hasAttribute('data-recipe-adset-budget')) {
      return null;
    }
    var state = {
      key: String(active.getAttribute('data-recipe-adset-budget') || '').trim(),
      value: String(active.value || '')
    };
    if (!state.key) {
      return null;
    }
    try {
      state.selectionStart = active.selectionStart;
      state.selectionEnd = active.selectionEnd;
    } catch (err) {
      state.selectionStart = null;
      state.selectionEnd = null;
    }
    return state;
  }

  function restoreRecipeBudgetInputState(state) {
    if (!state || !state.key) {
      return;
    }
    var input = builder.querySelector('[data-recipe-adset-budget="' + escapeRecipeSelectorValue(state.key) + '"]');
    if (!input || input.disabled) {
      return;
    }
    input.value = String(state.value || '');
    input.focus();
    try {
      if (state.selectionStart != null && state.selectionEnd != null) {
        input.setSelectionRange(state.selectionStart, state.selectionEnd);
      } else {
        var end = String(input.value || '').length;
        input.setSelectionRange(end, end);
      }
    } catch (err) {
      // Text inputs should support selection, but failing here is not fatal.
    }
  }

  function getRecipeTotalBudgetMinor() {
    return Math.round(parseFloatSafe(value('vms-ma-budget-total'), 0) * 100);
  }

  function formatRecipeRowLabels(rows) {
    var list = Array.isArray(rows) ? rows : [];
    return list.map(function (row) {
      return String(row && row.label ? row.label : '').trim();
    }).filter(Boolean).join(', ');
  }

  function getRecipeZeroBudgetBlockerMessage(rows, includeNames) {
    var message = 'Included ad sets need a budget before Meta can create them paused. Enter a budget or exclude the row.';
    var labels = formatRecipeRowLabels(rows);
    if (includeNames && labels) {
      message += ' Affected: ' + labels + '.';
    }
    return message;
  }

  function getRecipeOverBudgetMessage(allocation) {
    var safeAllocation = allocation && typeof allocation === 'object' ? allocation : {};
    return 'Ad-set budgets total ' + formatBudgetMinor(safeAllocation.allocatedMinor) + ', but campaign budget is ' + formatBudgetMinor(safeAllocation.totalBudgetMinor) + '.';
  }

  function getRecipeFloorMessage() {
    return 'Some included ad sets are below the floor. Increase those ad-set budgets, shorten the run, or exclude them.';
  }

  function allocateRecipeBudgetMinor(totalBudgetMinor, items, weightGetter) {
    var safeTotal = Math.max(0, parseIntSafe(totalBudgetMinor, 0));
    var list = Array.isArray(items) ? items.filter(function (item) {
      return item && String(item.key || '').trim();
    }) : [];
    var allocations = {};
    var totalWeight = list.reduce(function (sum, item) {
      return sum + Math.max(0, parseFloatSafe(weightGetter(item), 0));
    }, 0);

    list.forEach(function (item) {
      allocations[item.key] = 0;
    });
    if (!list.length || safeTotal < 1 || totalWeight <= 0) {
      return allocations;
    }

    var allocated = 0;
    list.forEach(function (item, index) {
      var weight = Math.max(0, parseFloatSafe(weightGetter(item), 0));
      var amount = index === list.length - 1
        ? Math.max(0, safeTotal - allocated)
        : Math.floor(safeTotal * (weight / totalWeight));
      allocations[item.key] = amount;
      allocated += amount;
    });
    return allocations;
  }

  function normalizeRecipeAdsetState(raw) {
    var source = raw && typeof raw === 'object' ? raw : {};
    var out = {};
    Object.keys(source).forEach(function (key) {
      var safeKey = String(key || '').trim();
      if (!safeKey) {
        return;
      }
      var row = source[key];
      if (!row || typeof row !== 'object') {
        return;
      }
      var budgetMinor = null;
      if (Object.prototype.hasOwnProperty.call(row, 'budget_minor')) {
        budgetMinor = normalizeRecipeBudgetMinorValue(row.budget_minor);
      } else if (Object.prototype.hasOwnProperty.call(row, 'budgetMinor')) {
        budgetMinor = normalizeRecipeBudgetMinorValue(row.budgetMinor);
      } else if (Object.prototype.hasOwnProperty.call(row, 'budget_amount_minor')) {
        budgetMinor = normalizeRecipeBudgetMinorValue(row.budget_amount_minor);
      } else if (Object.prototype.hasOwnProperty.call(row, 'budgetAmountMinor')) {
        budgetMinor = normalizeRecipeBudgetMinorValue(row.budgetAmountMinor);
      }
      out[safeKey] = {
        enabled: row.enabled == null ? true : (row.enabled === true || row.enabled === 1 || row.enabled === '1'),
        budgetMinor: budgetMinor,
        percent: normalizeRecipePercentValue(row.percent != null ? row.percent : row.allocation_percent)
      };
    });
    return out;
  }

  function getRecipeStateAliases(key) {
    var safeKey = String(key || '').trim();
    if (safeKey === 'promo_video_reels') {
      return ['vertical_video_reels_stories'];
    }
    if (safeKey === 'vertical_video_reels_stories') {
      return ['promo_video_reels'];
    }
    if (safeKey === 'fb_right_column') {
      return ['fb_right_column_support'];
    }
    if (safeKey === 'fb_right_column_support') {
      return ['fb_right_column'];
    }
    return [];
  }

  function replaceRecipeAdsetState(raw) {
    recipeAdsetState = normalizeRecipeAdsetState(raw);
  }

  function clearRecipeAdsetState() {
    recipeAdsetState = {};
  }

  function setRecipeAdsetEnabled(key, enabled) {
    var safeKey = String(key || '').trim();
    if (!safeKey) {
      return;
    }
    var next = normalizeRecipeAdsetState(recipeAdsetState);
    if (!next[safeKey]) {
      var currentRow = null;
      getRecipeRows().forEach(function (row) {
        if (!currentRow && row && row.key === safeKey) {
          currentRow = row;
        }
      });
      next[safeKey] = {
        enabled: !!enabled,
        budgetMinor: normalizeRecipeBudgetMinorValue(currentRow && currentRow.budgetMinor != null ? currentRow.budgetMinor : 0),
        percent: normalizeRecipePercentValue(currentRow && currentRow.percent != null ? currentRow.percent : 0)
      };
    }
    next[safeKey].enabled = !!enabled;
    recipeAdsetState = next;
  }

  function materializeRecipeAdsetBudgets() {
    var rows = getRecipeRows();
    if (!rows.length) {
      return;
    }
    var next = normalizeRecipeAdsetState(recipeAdsetState);
    var changed = false;
    rows.forEach(function (row) {
      var current = next[row.key];
      if (current && current.budgetMinor != null) {
        return;
      }
      next[row.key] = {
        enabled: current && typeof current.enabled !== 'undefined' ? !!current.enabled : !!row.enabled,
        budgetMinor: Math.max(0, parseIntSafe(row.budgetMinor, 0)),
        percent: normalizeRecipePercentValue(row.percent)
      };
      changed = true;
    });
    if (changed) {
      recipeAdsetState = next;
    }
  }

  function setRecipeAdsetBudgetMinor(key, budgetMinor) {
    var safeKey = String(key || '').trim();
    if (!safeKey) {
      return;
    }
    materializeRecipeAdsetBudgets();
    var next = normalizeRecipeAdsetState(recipeAdsetState);
    if (!next[safeKey]) {
      next[safeKey] = {
        enabled: true,
        budgetMinor: 0,
        percent: 0
      };
    }
    next[safeKey].budgetMinor = Math.max(0, parseIntSafe(budgetMinor, 0));
    recipeAdsetState = next;
  }

  function collectRecipeAdsetState() {
    var rows = getRecipeRows();
    var totalBudgetMinor = getRecipeTotalBudgetMinor();
    var out = {};
    rows.forEach(function (row) {
      var budgetMinor = Math.max(0, parseIntSafe(row.budgetMinor, 0));
      out[row.key] = {
        enabled: !!row.enabled,
        budget_minor: budgetMinor,
        percent: totalBudgetMinor > 0 ? normalizeRecipePercentValue((budgetMinor / totalBudgetMinor) * 100) : 0
      };
    });
    return out;
  }

  function getRecipeStateForKey(key) {
    if (recipeAdsetState && recipeAdsetState[key] && typeof recipeAdsetState[key] === 'object') {
      return recipeAdsetState[key];
    }
    var aliases = getRecipeStateAliases(key);
    for (var i = 0; i < aliases.length; i += 1) {
      var aliasKey = aliases[i];
      if (recipeAdsetState && recipeAdsetState[aliasKey] && typeof recipeAdsetState[aliasKey] === 'object') {
        return recipeAdsetState[aliasKey];
      }
    }
    return null;
  }

  function formatPercent(value) {
    var normalized = normalizeRecipePercentValue(value);
    return normalized.toFixed(2).replace(/\.00$/, '').replace(/(\.\d)0$/, '$1');
  }

  function getRecommendedRecipeWeights() {
    var strategyKey = value('vms-ma-strategy-template') || 'custom';
    var isV2 = strategyKey === 'clean_room_full_push_v2';
    if (!isCleanRoomStrategyKey(strategyKey)) {
      return null;
    }
    var includeRightColumn = isRightColumnSupportEnabled();
    var includeOuterTowns = isOuterTownsAdsetEnabled();
    var includeFeedVideo = isV2;
    var weights;
    if (isV2 && includeFeedVideo) {
      weights = includeOuterTowns ? {
        core_feed_reels: includeRightColumn ? 40 : 45,
        feed_square_video: 15,
        vertical_video_reels_stories: 20,
        outer_towns_50_plus: 20
      } : {
        core_feed_reels: includeRightColumn ? 55 : 60,
        feed_square_video: 20,
        vertical_video_reels_stories: 20
      };
      if (includeRightColumn) {
        weights.fb_right_column_support = 5;
      }
    } else if (isV2) {
      weights = includeOuterTowns ? {
        core_feed_reels: includeRightColumn ? 50 : 55,
        vertical_video_reels_stories: 25,
        outer_towns_50_plus: 20
      } : {
        core_feed_reels: includeRightColumn ? 65 : 70,
        vertical_video_reels_stories: 30
      };
      if (includeRightColumn) {
        weights.fb_right_column_support = 5;
      }
    } else {
      weights = includeOuterTowns ? {
        core_feed_reels: 50,
        promo_video_reels: 20,
        outer_towns_50_plus: 25
      } : {
        core_feed_reels: 65,
        promo_video_reels: 30
      };
      if (includeRightColumn) {
        weights.fb_right_column = 5;
      }
    }
    return {
      strategyKey: strategyKey,
      isV2: isV2,
      includeRightColumn: includeRightColumn,
      includeOuterTowns: includeOuterTowns,
      hasExplicitFeedVideo: hasFeedSquareVideoVariant(),
      weights: weights
    };
  }

  function getBaseRecipeRows() {
    var recommended = getRecommendedRecipeWeights();
    if (!recommended) {
      return [];
    }
    var keys = Object.keys(recommended.weights);
    var rows = [];
    var requirements = getCreativeRequirementRows();
    var verticalRequirement = requirements.filter(function (row) { return row.key === 'vertical_video'; })[0] || {};
    var rightColumnRequirement = requirements.filter(function (row) { return row.key === 'right_column_static'; })[0] || {};
    var outerAgeRangeLabel = getCurrentAgeRangeLabel();
    keys.forEach(function (key) {
      var percent = recommended.weights[key];
      var row = {
        key: key,
        recommendedPercent: percent,
        percent: percent,
        budgetMinor: 0,
        enabled: true,
        status: 'ready',
        statusLabel: 'Ready'
      };
      if (key === 'core_feed_reels') {
        row.label = recommended.isV2 ? 'Core Radius - Feeds' : 'Core Radius - Feed/Reels';
        row.audience = 'Primary radius, broad local audience';
        row.placements = recommended.isV2 ? 'Facebook Feed, Instagram Feed' : 'Facebook Feed, Instagram Feed, Facebook Reels, Instagram Reels';
        row.creative = recommended.isV2 ? 'Square/feed creative only' : 'Square/static plus optional video variant';
      } else if (key === 'feed_square_video') {
        row.label = 'Feed Video - Square 1:1';
        row.audience = 'Primary radius, same ticket intent';
        row.placements = 'Facebook Feed, Instagram Feed';
        if (recommended.hasExplicitFeedVideo) {
          row.creative = 'Square 1:1 video variant / placeholder';
        } else {
          row.creative = 'Auto placeholder; swap/upload 1:1 video in Meta';
          row.status = 'warning';
          row.statusLabel = 'Placeholder';
        }
      } else if (key === 'vertical_video_reels_stories' || key === 'promo_video_reels') {
        row.label = recommended.isV2 ? 'Vertical Video - Reels/Stories' : 'Promo Video/Reels';
        row.audience = 'Primary radius, same ticket intent';
        row.placements = 'Facebook Reels, Instagram Reels, Facebook Stories, Instagram Stories';
        row.creative = recommended.isV2 ? 'Tall 9:16 video' : 'Tall 9:16 video preferred for Reels/Stories';
        if (verticalRequirement.status === 'blocked') {
          row.status = 'blocked';
          row.statusLabel = 'Blocked';
        } else if (verticalRequirement.status === 'warning') {
          row.status = 'warning';
          row.statusLabel = 'Warning';
        }
      } else if (key === 'outer_towns_50_plus') {
        row.label = recommended.isV2 ? 'Outer Towns - Feeds (' + outerAgeRangeLabel + ')' : 'Outer Towns - Ages ' + outerAgeRangeLabel;
        row.audience = recommended.isV2 ? (getOuterTownsMode() === 'listed_only' ? getOuterTownsLocationsPreview() + ', ages ' + outerAgeRangeLabel : 'Expanded outer radius, ages ' + outerAgeRangeLabel) : 'Outer radius / added towns, ages ' + outerAgeRangeLabel;
        row.placements = recommended.isV2 ? 'Facebook Feed, Instagram Feed' : 'Facebook Feed, Instagram Feed, Facebook Reels, Instagram Reels';
        row.creative = recommended.isV2 ? 'Square/feed creative only' : 'Static or video variant';
        if (getOuterTownsMode() === 'listed_only' && !hasOuterTownsLocations()) {
          row.status = 'blocked';
          row.statusLabel = 'Missing towns';
        }
      } else {
        row.label = recommended.isV2 ? 'Facebook Right Column Support Test' : 'Facebook Right Column';
        row.audience = 'Primary radius, desktop reminder';
        row.placements = 'Facebook Right Column only';
        row.creative = 'Static 1:1 image and short headline';
        if (rightColumnRequirement.status === 'blocked') {
          row.status = 'blocked';
          row.statusLabel = 'Blocked';
        }
      }
      rows.push(row);
    });
    return rows;
  }

  function getRecipeAllocationState(rows) {
    var totalBudgetMinor = getRecipeTotalBudgetMinor();
    var enabledRows = rows.filter(function (row) { return row.enabled; });
    var allocatedMinor = enabledRows.reduce(function (sum, row) {
      return sum + Math.max(0, parseIntSafe(row.budgetMinor, 0));
    }, 0);
    var differenceMinor = totalBudgetMinor - allocatedMinor;
    var zeroBudgetRows = enabledRows.filter(function (row) {
      return Math.max(0, parseIntSafe(row.budgetMinor, 0)) < 1;
    });
    return {
      enabledCount: enabledRows.length,
      fundedCount: enabledRows.filter(function (row) { return Math.max(0, parseIntSafe(row.budgetMinor, 0)) > 0; }).length,
      totalBudgetMinor: totalBudgetMinor,
      allocatedMinor: allocatedMinor,
      differenceMinor: differenceMinor,
      unallocatedMinor: differenceMinor > 0 ? differenceMinor : 0,
      overBudgetMinor: differenceMinor < 0 ? Math.abs(differenceMinor) : 0,
      zeroBudgetRows: zeroBudgetRows,
      exact: enabledRows.length > 0 && differenceMinor === 0,
      ok: enabledRows.length > 0 && differenceMinor === 0 && !zeroBudgetRows.length
    };
  }

  function getRecipeAllocationDifferenceLabel(allocation) {
    if (!allocation || typeof allocation !== 'object') {
      return '';
    }
    if (allocation.zeroBudgetRows && allocation.zeroBudgetRows.length) {
      return 'Included row with $0 needs a budget';
    }
    if (allocation.unallocatedMinor > 0) {
      return formatBudgetMinor(allocation.unallocatedMinor) + ' unallocated';
    }
    if (allocation.overBudgetMinor > 0) {
      return getRecipeOverBudgetMessage(allocation);
    }
    return 'Allocated exactly';
  }

  function applyRecipeBudgets(rows) {
    rows.forEach(function (row) {
      if (!row.enabled) {
        row.displayStatus = 'disabled';
        row.displayStatusLabel = 'Excluded';
      } else {
        row.displayStatus = row.status;
        row.displayStatusLabel = row.statusLabel;
      }
    });
    return rows;
  }

  function getRecipeRows() {
    var totalBudgetMinor = getRecipeTotalBudgetMinor();
    var rows = getBaseRecipeRows().map(function (row) {
      var next = Object.assign({}, row);
      var stored = getRecipeStateForKey(next.key);
      if (stored) {
        next.enabled = !!stored.enabled;
      } else {
        next.enabled = !!next.enabled;
      }
      next.budgetMinor = null;
      next.percent = 0;
      return next;
    });
    var explicitTotalMinor = 0;
    var fallbackRows = [];
    rows.forEach(function (row) {
      var stored = getRecipeStateForKey(row.key);
      if (stored && stored.budgetMinor != null) {
        row.budgetMinor = Math.max(0, parseIntSafe(stored.budgetMinor, 0));
        explicitTotalMinor += row.budgetMinor;
        return;
      }
      fallbackRows.push({
        key: row.key,
        weight: stored ? normalizeRecipePercentValue(stored.percent) : normalizeRecipePercentValue(row.recommendedPercent)
      });
    });
    var remainingMinor = Math.max(0, totalBudgetMinor - explicitTotalMinor);
    var distributed = allocateRecipeBudgetMinor(remainingMinor, fallbackRows, function (item) {
      return item.weight;
    });
    rows.forEach(function (row) {
      if (row.budgetMinor == null) {
        row.budgetMinor = Math.max(0, parseIntSafe(distributed[row.key], 0));
      }
      row.percent = totalBudgetMinor > 0 ? normalizeRecipePercentValue((row.budgetMinor / totalBudgetMinor) * 100) : 0;
    });
    return applyRecipeBudgets(rows);
  }

  function getRecipeBlockingMessage() {
    var rows = getRecipeRows();
    if (!rows.length) {
      return '';
    }
    var allocation = getRecipeAllocationState(rows);
    if (!allocation.enabledCount) {
      return 'Include at least one clean-room ad set before sending this recipe to Meta.';
    }
    if (allocation.zeroBudgetRows.length) {
      return getRecipeZeroBudgetBlockerMessage(allocation.zeroBudgetRows, true);
    }
    if (!allocation.exact) {
      if (allocation.unallocatedMinor > 0) {
        return 'Included clean-room ad-set budgets must match the campaign total. ' + formatBudgetMinor(allocation.unallocatedMinor) + ' is still unallocated.';
      }
      return getRecipeOverBudgetMessage(allocation) + ' Lower the included row budgets or update the campaign total budget.';
    }
    var blocked = rows.filter(function (row) { return row.enabled && row.status === 'blocked'; });
    if (!blocked.length) {
      return '';
    }
    return 'Recipe needs attention before Create in Meta: ' + blocked.map(function (row) { return row.label; }).join(', ') + '.';
  }

  function formatCountLabel(count, singular, plural) {
    var n = Math.max(0, parseIntSafe(count, 0));
    return n + ' ' + (n === 1 ? singular : plural);
  }

  function formatObjectCountSummary(counts) {
    var safe = counts && typeof counts === 'object' ? counts : {};
    return [
      formatCountLabel(safe.campaigns, 'campaign', 'campaigns'),
      formatCountLabel(safe.adsets, 'ad set', 'ad sets'),
      formatCountLabel(safe.creatives, 'creative', 'creatives'),
      formatCountLabel(safe.ads, 'ad', 'ads')
    ].join(' / ');
  }

  function getStructurePreviewData() {
    var strategyKey = value('vms-ma-strategy-template') || 'custom';
    var strategy = campaignStrategies[strategyKey] || campaignStrategies.custom;
    var recipeRows = getRecipeRows();
    if (recipeRows.length) {
      var enabledRows = recipeRows.filter(function (row) { return row.enabled; });
      var fundedEnabledRows = enabledRows.filter(function (row) { return Math.max(0, parseIntSafe(row.budgetMinor, 0)) > 0; });
      var disabledRows = recipeRows.filter(function (row) { return !row.enabled; });
      var unfundedRows = enabledRows.filter(function (row) { return Math.max(0, parseIntSafe(row.budgetMinor, 0)) < 1; });
      return {
        strategyKey: strategyKey,
        strategyLabel: strategy.label || strategyKey,
        counts: {
          campaigns: 1,
          adsets: fundedEnabledRows.length,
          creatives: fundedEnabledRows.length,
          ads: fundedEnabledRows.length
        },
        adsetNames: fundedEnabledRows.map(function (row) { return row.label; }),
        disabledAdsetNames: disabledRows.map(function (row) { return row.label; }),
        unfundedAdsetNames: unfundedRows.map(function (row) { return row.label; }),
        rows: recipeRows,
        createsSingleAdset: fundedEnabledRows.length === 1
      };
    }

    var tiers = buildTierSchedule();
    var singleLabel = (tiers[0] && tiers[0].label) ? String(tiers[0].label) : 'Single ad set';
    return {
      strategyKey: strategyKey,
      strategyLabel: strategy.label || strategyKey,
      counts: {
        campaigns: 1,
        adsets: 1,
        creatives: 1,
        ads: 1
      },
      adsetNames: [singleLabel],
      disabledAdsetNames: [],
      rows: [],
      createsSingleAdset: true
    };
  }

  function isValidHttpUrl(raw) {
    var url = String(raw || '').trim();
    if (!url) {
      return false;
    }
    try {
      var parsed = new URL(url);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch (err) {
      return false;
    }
  }

  function getLoadedBuildId() {
    return parseIntSafe(getActiveBuildId(), 0);
  }

  function getCreatePausedBlockers() {
    var blockers = [];
    var apiEnabled = !!parseIntSafe(VMS_MA.apiEnabled, 0);
    var apiReady = !!parseIntSafe(VMS_MA.apiReady, 0);
    var eventPlanId = getCurrentEventPlanId();
    var loadedBuildId = getLoadedBuildId();
    var selectedBuild = getSelectedBuildItem();
    var creativeMode = getCurrentCreativeMode();
    var destinationUrl = value('vms-ma-destination-url');
    var ctaType = value('vms-ma-cta-type');
    var totalBudgetMinor = Math.round(parseFloatSafe(value('vms-ma-budget-total'), 0) * 100);
    var lifetimeClamp = parseIntSafe(VMS_MA.budgetMaxLifetimeMinor, 0);
    var tiers = buildTierSchedule();
    var lastTier = tiers.length ? tiers[tiers.length - 1] : null;
    var scheduleSupport = getDirectCreateScheduleSupport();
    var budgetAssessment = getBudgetFloorAssessment();
    var recipeBlockingMessage = getRecipeBlockingMessage();

    function push(code, message) {
      if (!message) {
        return;
      }
      if (blockers.some(function (item) { return item.code === code; })) {
        return;
      }
      blockers.push({
        code: String(code || 'blocked'),
        message: String(message)
      });
    }

    if (!apiEnabled) {
      push('api_disabled', 'Meta API create is off in Settings. The owner must enable it before Create Paused can run.');
    } else if (!apiReady) {
      push('api_not_ready', 'Meta API create is enabled, but the connection is not ready yet. Run Save Settings and Test Connection first.');
    }
    if (lifetimeClamp > 0 && totalBudgetMinor > lifetimeClamp) {
      push('budget_over_clamp', 'Campaign budget exceeds the configured lifetime clamp of ' + formatBudgetMinor(lifetimeClamp) + '. Lower the total budget before Create Paused can run.');
    }
    if (!eventPlanId) {
      push('no_event_plan', 'Choose an Event Plan first.');
    }
    if (loadedBuildId < 1 || !selectedBuild) {
      push('no_loaded_build', 'Load a saved campaign draft first. Create Paused only uses the build currently loaded in the builder.');
    }
    if (selectedBuild && String(selectedBuild.status || '').trim().toLowerCase() === 'archived') {
      push('archived_build', 'This build is archived. Duplicate it as a Fresh Draft before creating paused Meta drafts.');
    }
    if (hasBlockingBuildHydrationMismatch()) {
      push('hydration_mismatch', getBuildHydrationGuardMessage('creating paused Meta drafts'));
    }
    if (selectedBuild && buildHasMetaIds(selectedBuild)) {
      push('linked_meta_ids', 'This loaded build already has Meta IDs or stale Meta links. Duplicate as Fresh Draft, Scrap / Archive Build, or Reset Meta Link before creating a new paused campaign.');
    }
    if (creativeMode && creativeMode !== 'dark_post') {
      push('creative_mode', 'Create Paused currently supports Dark Post Link Ad only.');
    }
    if (!isValidHttpUrl(destinationUrl)) {
      push('destination_url', 'Destination URL is missing or invalid.');
    }
    if (['BUY_TICKETS', 'GET_TICKETS', 'LEARN_MORE'].indexOf(ctaType) === -1) {
      push('cta_invalid', 'CTA is invalid for this build.');
    }
    if (totalBudgetMinor < 1) {
      push('budget_missing', 'Total budget must be greater than $0.00.');
    }
    if (!tiers.length || !lastTier || !String(tiers[0].start || '').trim() || !String(lastTier.end || '').trim()) {
      push('schedule_missing', 'Schedule is incomplete. Finish Step E before creating paused drafts.');
    }
    if (scheduleSupport.blocked) {
      push('schedule_strategy', scheduleSupport.message);
    }
    if (!budgetAssessment.ok) {
      push('budget_floor', budgetAssessment.message || 'Budget is likely too low for this schedule. Increase budget or shorten the run window.');
    }
    if (isCleanRoomStrategyKey(value('vms-ma-strategy-template')) && isOuterTownsAdsetEnabled() && getOuterTownsMode() === 'listed_only' && !hasOuterTownsLocations()) {
      push('outer_towns_missing', 'Outer Towns is included in listed-only mode, but no outer towns are entered. Add towns or exclude that ad set.');
    }
    if (recipeBlockingMessage) {
      push('recipe_blocked', recipeBlockingMessage);
    }

    return blockers;
  }

  function buildCreateBlockerActionsHtml() {
    var build = getSelectedBuildItem();
    if (!build || !build.id || !buildHasMetaIds(build)) {
      return '';
    }
    return '<div class="vms-ma-blocker-actions">' +
      '<button type="button" class="button button-secondary vms-ma-duplicate-build" data-build-id="' + escapeAttribute(String(build.id)) + '">Duplicate as Fresh Draft</button>' +
      '<button type="button" class="button button-secondary vms-ma-archive-build" data-build-id="' + escapeAttribute(String(build.id)) + '">Scrap / Archive Build</button>' +
      '<button type="button" class="button button-secondary vms-ma-reset-meta-link-inline">Reset Meta Link</button>' +
    '</div>';
  }

  function renderCreateStructurePreview() {
    var node = byId('vms-ma-create-structure-preview');
    if (!node) {
      return;
    }
    var structure = getStructurePreviewData();
    var selectedBuild = getSelectedBuildItem();
    var adsetList = structure.adsetNames.map(function (name) {
      return '<li>' + escapeHtml(name) + '</li>';
    }).join('');
    var html = '<strong>Paused-create structure preview</strong>';
    html += '<div class="vms-ma-create-structure-preview__meta">';
    html += '<div><strong>Loaded build:</strong> ' + escapeHtml(selectedBuild && selectedBuild.id ? ('Build #' + selectedBuild.id) : 'None loaded') + '</div>';
    html += '<div><strong>Strategy:</strong> ' + escapeHtml(structure.strategyLabel) + '</div>';
    html += '<div><strong>Expected create:</strong> ' + escapeHtml(formatObjectCountSummary(structure.counts)) + '</div>';
    html += '</div>';
    if (structure.adsetNames.length) {
      html += '<div class="vms-ma-create-structure-preview__adsets"><strong>Included funded ad sets</strong><ul>' + adsetList + '</ul></div>';
    } else if (structure.rows.length) {
      html += '<div class="vms-ma-create-structure-preview__adsets"><strong>Included funded ad sets</strong><p class="description">None yet. Include at least one clean-room ad set and assign budget before creating paused drafts.</p></div>';
    } else {
      html += '<div class="vms-ma-create-structure-preview__adsets"><strong>Ad sets</strong><ul>' + adsetList + '</ul></div>';
    }
    if (structure.disabledAdsetNames && structure.disabledAdsetNames.length) {
      html += '<p class="description">Excluded ad sets will not be created in Meta: ' + escapeHtml(structure.disabledAdsetNames.join(', ')) + '.</p>';
    }
    if (structure.unfundedAdsetNames && structure.unfundedAdsetNames.length) {
      html += '<p class="description">' + escapeHtml(getRecipeZeroBudgetBlockerMessage(structure.rows.filter(function (row) { return row.enabled && Math.max(0, parseIntSafe(row.budgetMinor, 0)) < 1; }), true)) + '</p>';
    }
    if (structure.rows.length && !structure.adsetNames.length) {
      html += '<p class="description">Clean-room concert builds need at least one included ad set with budget before Meta create can run.</p>';
    } else if (structure.createsSingleAdset) {
      html += '<p class="description">This strategy creates only 1 ad set. Use the clean-room concert default when you want the full multi-ad-set concert structure.</p>';
    } else {
      html += '<p class="description">Clean-room concert builds should show the full paused draft structure here before you create anything in Meta.</p>';
    }
    if (!(selectedBuild && selectedBuild.id)) {
      html += '<p class="description">Create Paused stays blocked until a saved build is loaded from Step A.</p>';
    }
    node.innerHTML = html;
  }

  function renderRecipePreview() {
    var node = byId('vms-ma-recipe-preview');
    if (!node) {
      renderCreateStructurePreview();
      return;
    }
    var rows = getRecipeRows();
    if (!rows.length) {
      node.classList.add('vms-ma-hidden');
      node.innerHTML = '';
      renderCreateStructurePreview();
      return;
    }
    var allocation = getRecipeAllocationState(rows);
    var html = '<h3>Recipe preview before Meta creation</h3>' +
      '<p class="description">This is what MAB will create as paused assets for review. Included rows become paused Meta ad sets if create succeeds; excluded rows are omitted. v2 always creates separate static Feed, Feed 1:1 Video, and Reels/Stories ad sets so the square and portrait videos do not get blended.</p>' +
      '<table><thead><tr><th>Ad set</th><th>Budget</th><th>Audience</th><th>Placements</th><th>Creative needed</th><th>Status</th></tr></thead><tbody>';
    rows.forEach(function (row) {
      var budgetLabel = row.enabled
        ? (formatBudgetMinor(row.budgetMinor) + ' / ' + formatPercent(row.percent) + '%')
        : ('Excluded');
      html += '<tr>' +
        '<td><strong>' + escapeHtml(row.label) + '</strong></td>' +
        '<td>' + escapeHtml(budgetLabel) + '</td>' +
        '<td>' + escapeHtml(row.audience) + '</td>' +
        '<td>' + escapeHtml(row.placements) + '</td>' +
        '<td>' + escapeHtml(row.creative) + '</td>' +
        '<td><span class="vms-ma-recipe-status vms-ma-recipe-status--' + escapeHtml(row.displayStatus || row.status) + '">' + escapeHtml(row.displayStatusLabel || row.statusLabel) + '</span></td>' +
      '</tr>';
    });
    html += '</tbody></table>';
    if (!allocation.enabledCount) {
      html += '<p class="description vms-ma-inline-warning">All recipe ad sets are excluded. Include at least one before Create Paused can continue.</p>';
    } else if (allocation.zeroBudgetRows.length) {
      html += '<p class="description vms-ma-inline-warning">' + escapeHtml(getRecipeZeroBudgetBlockerMessage(allocation.zeroBudgetRows, true)) + '</p>';
    } else if (allocation.overBudgetMinor > 0) {
      html += '<p class="description vms-ma-inline-warning">' + escapeHtml(getRecipeOverBudgetMessage(allocation)) + '</p>';
    } else if (!allocation.exact) {
      html += '<p class="description vms-ma-inline-warning">Allocated ' + escapeHtml(formatBudgetMinor(allocation.allocatedMinor)) + ' of ' + escapeHtml(formatBudgetMinor(allocation.totalBudgetMinor)) + '. ' + escapeHtml(getRecipeAllocationDifferenceLabel(allocation)) + '.</p>';
    }
    node.innerHTML = html;
    node.classList.remove('vms-ma-hidden');
    renderCreateStructurePreview();
  }

  function byId(id) {
    return document.getElementById(id);
  }

  function value(id) {
    var el = byId(id);
    return el ? String(el.value || '') : '';
  }

  function getPlacementsMode() {
    var el = byId('vms-ma-placements-mode');
    if (el) {
      return String(el.value || 'auto');
    }
    var radio = document.querySelector('input[name="vms_ma_placements_mode"]:checked');
    return radio ? String(radio.value || 'auto') : 'auto';
  }

  function setPlacementsMode(mode) {
    var el = byId('vms-ma-placements-mode');
    if (el) {
      el.value = mode;
      return;
    }
    var radio = document.querySelector('input[name="vms_ma_placements_mode"][value="' + mode + '"]');
    if (radio) {
      radio.checked = true;
    }
  }

  function parseIntSafe(raw, fallback) {
    var n = parseInt(String(raw || ''), 10);
    return Number.isFinite(n) ? n : fallback;
  }

  function parseFloatSafe(raw, fallback) {
    var n = parseFloat(String(raw || ''));
    return Number.isFinite(n) ? n : fallback;
  }

  function escapeHtml(raw) {
    return String(raw || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function escapeAttribute(raw) {
    return escapeHtml(raw);
  }

  function resolveFieldElement(target) {
    if (!target) {
      return null;
    }
    if (typeof target === 'string') {
      return document.querySelector(target);
    }
    if (target instanceof Element) {
      return target;
    }
    return null;
  }

  function fieldHasNonDefault(target, defaultValue) {
    var el = resolveFieldElement(target);
    if (!el) {
      return false;
    }

    var value = '';
    if (el.type === 'checkbox') {
      value = el.checked ? '1' : '0';
    } else if (el.type === 'radio') {
      var checked = el.checked ? el : builder.querySelector('input[type="radio"][name="' + (el.name || '') + '"]:checked');
      if (!checked) {
        value = '';
      } else {
        value = String(checked.value || '').trim();
      }
    } else {
      if (typeof el.value !== 'undefined') {
        value = String(el.value || '').trim();
      } else {
        value = String(el.textContent || '').trim();
      }
    }

    var normalizedDefault = defaultValue;
    if (normalizedDefault === null || typeof normalizedDefault === 'undefined') {
      normalizedDefault = '';
    }

    if (typeof normalizedDefault === 'number') {
      var numeric = parseFloat(value);
      return Number.isFinite(numeric) && numeric !== normalizedDefault;
    }

    return value !== String(normalizedDefault).trim();
  }

  window.vmsMaFieldHasNonDefault = fieldHasNonDefault;

  function clearNotice() {
    if (!notices) {
      return;
    }
    notices.classList.add('vms-ma-hidden');
    notices.innerHTML = '';
  }

  function dismissToast(toast) {
    if (!toast || !toast.parentNode) {
      return;
    }
    toast.parentNode.removeChild(toast);
  }

  function showNotice(message, type) {
    if (!notices) {
      return;
    }
    notices.className = 'notice is-dismissible vms-ma-builder-notices notice-' + (type || 'info');
    notices.innerHTML = '<p>' + String(message || '') + '</p><button type="button" class="notice-dismiss" aria-label="Dismiss notice"><span class="screen-reader-text">Dismiss this notice.</span></button>';
    notices.classList.remove('vms-ma-hidden');
  }

  function showToast(type, message) {
    if (!toastRoot || !message) {
      return;
    }
    var normalized = String(message);
    var duplicate = null;
    toastRoot.querySelectorAll('.vms-ma-toast').forEach(function (node) {
      if (!duplicate && String(node.getAttribute('data-message') || '') === normalized) {
        duplicate = node;
      }
    });
    if (duplicate) {
      return;
    }
    var toast = document.createElement('div');
    toast.className = 'vms-ma-toast vms-ma-toast-' + (type || 'info');
    toast.setAttribute('data-message', normalized);

    var text = document.createElement('div');
    text.className = 'vms-ma-toast-text';
    text.textContent = normalized;

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'vms-ma-toast-dismiss';
    closeBtn.setAttribute('aria-label', 'Dismiss notification');
    closeBtn.textContent = '×';
    closeBtn.addEventListener('click', function () {
      dismissToast(toast);
    });

    toast.appendChild(text);
    toast.appendChild(closeBtn);
    toastRoot.appendChild(toast);
  }

  function ensureLoadingOverlay() {
    if (loadingOverlay) {
      return;
    }
    loadingOverlay = document.createElement('div');
    loadingOverlay.className = 'vms-ma-load-overlay';
    var inner = document.createElement('div');
    inner.className = 'vms-ma-load-overlay__card';
    var spinner = document.createElement('div');
    spinner.className = 'vms-ma-load-overlay__spinner';
    spinner.setAttribute('aria-hidden', 'true');
    overlayMessage = document.createElement('p');
    inner.appendChild(spinner);
    inner.appendChild(overlayMessage);
    loadingOverlay.appendChild(inner);
    builder.appendChild(loadingOverlay);
  }

  function setLoadingOverlayMessage(message) {
    ensureLoadingOverlay();
    overlayMessage.textContent = String(message || loadingText);
  }

  function showLoadingOverlay(message) {
    ensureLoadingOverlay();
    loadingCounter++;
    setLoadingOverlayMessage(message);
    loadingOverlay.classList.add('is-visible');
    builder.classList.add('vms-ma-loading');
    builder.setAttribute('aria-busy', 'true');
  }

  function hideLoadingOverlay() {
    loadingCounter = Math.max(0, loadingCounter - 1);
    if (loadingOverlay && loadingCounter === 0) {
      loadingOverlay.classList.remove('is-visible');
      builder.classList.remove('vms-ma-loading');
      builder.removeAttribute('aria-busy');
    }
  }

  function withLoadingOverlay(promise, message) {
    showLoadingOverlay(message);
    if (!promise || typeof promise.then !== 'function') {
      hideLoadingOverlay();
      return promise;
    }
    return promise.finally(hideLoadingOverlay);
  }

  function setStepStatus(stepKey, message) {
    var key = String(stepKey || '').toLowerCase();
    var row = byId('vms-ma-step-' + key + '-status');
    if (!row) {
      return;
    }
    row.textContent = String(message || '');
  }

  function emitFeedback(type, message, stepKey) {
    showNotice(message, type);
    showToast(type, message);
    if (stepKey) {
      setStepStatus(stepKey, message);
    }
  }

  function request(path, method, body) {
    return fetch(VMS_MA.restRoot + path, {
      method: method,
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': VMS_MA.nonce
      },
      body: body ? JSON.stringify(body) : undefined
    }).then(function (res) {
      return res.json().then(function (json) {
        if (!res.ok) {
          var err = new Error((json && json.message) ? json.message : 'Request failed');
          err.code = json && json.code ? String(json.code) : '';
          err.data = (json && json.data && typeof json.data === 'object') ? json.data : {};
          err.responseJson = json || null;
          throw err;
        }
        return json;
      });
    });
  }

  function requestAbsolute(url) {
    return fetch(url, {
      method: 'GET',
      headers: {
        'X-WP-Nonce': VMS_MA.nonce
      }
    }).then(function (res) {
      return res.json().then(function (json) {
        if (!res.ok) {
          throw new Error((json && json.message) ? json.message : 'Request failed');
        }
        return json;
      });
    });
  }


  // Media helpers (image pickers)
  function getImageActionButton(kind, action) {
    var safeKind = String(kind || '').toLowerCase();
    var safeAction = String(action || '').toLowerCase();
    return byId('vms-ma-image-' + safeKind + '-' + safeAction) || document.querySelector('.vms-ma-image-picker[data-image-kind="' + safeKind + '"] .vms-ma-' + safeAction + '-image');
  }

  function setImageSelection(kind, attachmentId, url, options) {
    var safeKind = String(kind || '').toLowerCase();
    var idField = byId('vms-ma-image-' + safeKind + '-id');
    var preview = byId('vms-ma-image-' + safeKind + '-preview');
    var chooseBtn = getImageActionButton(safeKind, 'choose');
    var clearBtn = getImageActionButton(safeKind, 'clear');
    var idVal = parseIntSafe(attachmentId, 0);
    var silent = !!(options && options.silent);

    if (idField) {
      idField.value = String(idVal || 0);
      if (!silent) {
        dispatchFieldEvents(idField);
      }
    }

    if (preview) {
      if (url) {
        preview.src = String(url);
        preview.classList.remove('vms-ma-hidden');
      } else {
        preview.removeAttribute('src');
        preview.classList.add('vms-ma-hidden');
      }
    }

    if (chooseBtn) {
      chooseBtn.textContent = (idVal > 0) ? 'Change' : 'Choose';
    }
    if (clearBtn) {
      clearBtn.disabled = !(idVal > 0);
    }
  }

  function fetchMediaDetails(attachmentId) {
    var idVal = parseIntSafe(attachmentId, 0);
    if (!idVal || !VMS_MA.wpMediaUrlBase) {
      return Promise.resolve({
        id: 0,
        url: '',
        title: '',
        mimeType: '',
        mediaType: ''
      });
    }
    return requestAbsolute(VMS_MA.wpMediaUrlBase + encodeURIComponent(idVal)).then(function (json) {
      if (!json) {
        return {
          id: idVal,
          url: '',
          title: '',
          mimeType: '',
          mediaType: ''
        };
      }
      var sizes = json.media_details && json.media_details.sizes ? json.media_details.sizes : null;
      var url = '';
      if (sizes && sizes.large && sizes.large.source_url) {
        url = String(sizes.large.source_url);
      } else if (sizes && sizes.medium_large && sizes.medium_large.source_url) {
        url = String(sizes.medium_large.source_url);
      } else if (json.source_url) {
        url = String(json.source_url);
      }
      var title = '';
      if (json.title && typeof json.title === 'object' && json.title.rendered) {
        title = String(json.title.rendered);
      } else if (json.title) {
        title = String(json.title);
      }
      return {
        id: idVal,
        url: url,
        title: title,
        mimeType: String(json.mime_type || ''),
        mediaType: String(json.media_type || '')
      };
    }).catch(function () {
      return {
        id: idVal,
        url: '',
        title: '',
        mimeType: '',
        mediaType: ''
      };
    });
  }

  function fetchMediaUrl(attachmentId) {
    return fetchMediaDetails(attachmentId).then(function (details) {
      return String((details && details.url) || '');
    });
  }

  function normalizeVariantMediaMode(mode) {
    var safe = String(mode || 'shared').trim().toLowerCase();
    if (safe === 'image' || safe === 'video' || safe === 'video_placeholder') {
      return safe;
    }
    return 'shared';
  }

  function normalizeVariantPlacementSlot(slot) {
    var safe = String(slot || 'auto').trim().toLowerCase();
    if (safe === 'feed_square_video' || safe === 'reels_stories_video') {
      return safe;
    }
    return 'auto';
  }

  function isMetaDirectVideoPlaceholder(mode) {
    return normalizeVariantMediaMode(mode) === 'video_placeholder';
  }

  function syncImagePreviewFromId(kind) {
    var safeKind = String(kind || '').toLowerCase();
    var idField = byId('vms-ma-image-' + safeKind + '-id');
    if (!idField) {
      return;
    }
    var idVal = parseIntSafe(idField.value, 0);
    if (!idVal) {
      setImageSelection(safeKind, 0, '');
      return;
    }
    fetchMediaUrl(idVal).then(function (url) {
      setImageSelection(safeKind, idVal, url);
    });
  }

  function setVariantMediaSelection(index, mediaType, attachmentId, meta, options) {
    var safeIndex = parseIntSafe(index, 0);
    var safeType = String(mediaType || '').toLowerCase() === 'video' ? 'video' : 'image';
    var idField = byId('vms-ma-variant-' + safeIndex + '-' + safeType + '-id');
    var nameNode = byId('vms-ma-variant-' + safeIndex + '-' + safeType + '-name');
    var clearBtn = builder.querySelector('.vms-ma-clear-variant-media[data-variant="' + safeIndex + '"][data-media-type="' + safeType + '"]');
    var chooseBtn = builder.querySelector('.vms-ma-pick-variant-media[data-variant="' + safeIndex + '"][data-media-type="' + safeType + '"]');
    var idVal = parseIntSafe(attachmentId, 0);
    var details = meta && typeof meta === 'object' ? meta : {};
    var label = '';
    var silent = !!(options && options.silent);

    if (idVal > 0) {
      label = String(details.title || details.url || (safeType === 'video' ? 'Selected video' : 'Selected image')).trim();
    } else {
      label = safeType === 'video' ? 'No video selected.' : 'No custom image selected.';
    }

    if (idField) {
      idField.value = String(idVal || 0);
      if (!silent) {
        dispatchFieldEvents(idField);
      }
    }
    if (nameNode) {
      nameNode.textContent = label;
    }
    if (clearBtn) {
      clearBtn.disabled = !(idVal > 0);
    }
    if (chooseBtn) {
      chooseBtn.textContent = (idVal > 0) ? (safeType === 'video' ? 'Change Video' : 'Change Image') : (safeType === 'video' ? 'Choose Video' : 'Choose Image');
    }
  }

  function syncVariantMediaPreview(index, mediaType, options) {
    var safeIndex = parseIntSafe(index, 0);
    var safeType = String(mediaType || '').toLowerCase() === 'video' ? 'video' : 'image';
    var idField = byId('vms-ma-variant-' + safeIndex + '-' + safeType + '-id');
    if (!idField) {
      return;
    }
    var idVal = parseIntSafe(idField.value, 0);
    if (!idVal) {
      setVariantMediaSelection(safeIndex, safeType, 0, {}, options);
      return;
    }
    fetchMediaDetails(idVal).then(function (details) {
      setVariantMediaSelection(safeIndex, safeType, idVal, details || {}, options);
    });
  }

  function syncVariantMediaUi(index) {
    var safeIndex = parseIntSafe(index, 0);
    var modeField = byId('vms-ma-variant-' + safeIndex + '-media-mode');
    var mode = normalizeVariantMediaMode(modeField && modeField.value ? modeField.value : 'shared');
    var imageWrap = byId('vms-ma-variant-' + safeIndex + '-image-wrap');
    var videoWrap = byId('vms-ma-variant-' + safeIndex + '-video-wrap');
    var note = byId('vms-ma-variant-' + safeIndex + '-media-note');
    var card = modeField ? modeField.closest('.vms-ma-variant-card') : null;

    if (imageWrap) {
      imageWrap.classList.toggle('vms-ma-hidden', mode !== 'image');
    }
    if (videoWrap) {
      videoWrap.classList.toggle('vms-ma-hidden', mode !== 'video');
    }

    if (card) {
      card.classList.toggle('is-shared-media', mode === 'shared');
      card.classList.toggle('is-image-media', mode === 'image');
      card.classList.toggle('is-video-media', mode === 'video' || mode === 'video_placeholder');
      card.classList.toggle('is-video-placeholder-media', mode === 'video_placeholder');
    }

    if (note) {
      if (mode === 'image') {
        note.textContent = 'This variant overrides the shared media with its own image.';
      } else if (mode === 'video_placeholder') {
        note.textContent = 'Creates the ad with the shared placeholder image. Upload or swap the actual video directly in Meta Ads Manager after the ad exists.';
      } else if (mode === 'video') {
        note.textContent = 'Legacy mode: uploads the selected WordPress video to Meta. Prefer Video placeholder to avoid website storage/bandwidth.';
      } else if (safeIndex === 1) {
        note.textContent = 'Uses Default Shared Media above.';
      } else {
        note.textContent = 'Uses Default Shared Media above unless you switch it.';
      }
    }

    if (mode === 'image') {
      syncVariantMediaPreview(safeIndex, 'image');
    } else if (mode === 'video') {
      syncVariantMediaPreview(safeIndex, 'video');
    }
  }

  function openVariantMediaPicker(index, mediaType) {
    if (!window.wp || !wp.media) {
      emitFeedback('error', 'WordPress media library not available on this screen.', 'c');
      return;
    }
    var safeIndex = parseIntSafe(index, 0);
    var safeType = String(mediaType || '').toLowerCase() === 'video' ? 'video' : 'image';
    var frame = wp.media({
      title: safeType === 'video' ? 'Select video' : 'Select image',
      button: { text: safeType === 'video' ? 'Use this video' : 'Use this image' },
      library: { type: safeType },
      multiple: false
    });
    frame.on('select', function () {
      var selection = frame.state().get('selection');
      var attachment = selection && selection.first ? selection.first() : null;
      if (!attachment) {
        return;
      }
      var data = attachment.toJSON ? attachment.toJSON() : {};
      var idVal = parseIntSafe(data.id, 0);
      var title = String(data.title || data.filename || data.url || '').trim();
      if (!title && safeType === 'video') {
        title = 'Selected video';
      } else if (!title) {
        title = 'Selected image';
      }
      setVariantMediaSelection(safeIndex, safeType, idVal, {
        title: title,
        url: String(data.url || '')
      });
      renderCopyPackPanel();
      emitFeedback('success', safeType === 'video' ? 'Video selected.' : 'Image selected.', 'c');
    });
    frame.open();
  }

  function openMediaPicker(kind) {
    if (!window.wp || !wp.media) {
      emitFeedback('error', 'WordPress media library not available on this screen.', 'c');
      return;
    }
    var safeKind = String(kind || '').toLowerCase();
    var frame = wp.media({
      title: 'Select image',
      button: { text: 'Use this image' },
      library: { type: 'image' },
      multiple: false
    });
    frame.on('select', function () {
      var selection = frame.state().get('selection');
      var attachment = selection && selection.first ? selection.first() : null;
      if (!attachment) {
        return;
      }
      var data = attachment.toJSON ? attachment.toJSON() : {};
      var idVal = parseIntSafe(data.id, 0);
      var url = '';
      if (data.sizes && data.sizes.large && data.sizes.large.url) {
        url = data.sizes.large.url;
      } else if (data.sizes && data.sizes.medium_large && data.sizes.medium_large.url) {
        url = data.sizes.medium_large.url;
      } else if (data.url) {
        url = data.url;
      }
      setImageSelection(safeKind, idVal, url);
      renderCopyPackPanel();
      emitFeedback('success', 'Image selected.', 'c');
    });
    frame.open();
  }

  function dispatchFieldEvents(el) {
    if (!el) {
      return;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function normalizeCtaType(value) {
    var cta = String(value || '').trim().toUpperCase();
    if (!cta || cta === 'BUY_NOW') {
      return 'LEARN_MORE';
    }
    return cta;
  }

  function isBuyTicketsLocked() {
    var lock = byId('vms-ma-force-buy-tickets');
    return !!(lock && lock.checked);
  }

  function syncCtaLockUi() {
    var cta = byId('vms-ma-cta-type');
    var status = byId('vms-ma-cta-lock-status');
    var locked = isBuyTicketsLocked();
    if (cta) {
      if (locked && cta.value !== 'BUY_TICKETS') {
        cta.value = 'BUY_TICKETS';
      }
      cta.disabled = locked;
      cta.setAttribute('aria-disabled', locked ? 'true' : 'false');
      cta.classList.toggle('vms-ma-field-locked', locked);
    }
    if (status) {
      if (locked) {
        status.textContent = 'CTA: Buy Tickets. Locked by the current ticketed-concert strategy.';
      } else {
        status.textContent = 'Advanced CTA override is on. Confirm the dropdown value before any later Meta use.';
      }
      status.classList.remove('vms-ma-hidden');
    }
  }

  function setChecked(id, checked, options) {
    var el = byId(id);
    if (!el) {
      return;
    }
    el.checked = !!checked;
    if (!(options && options.silent)) {
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  function deepClone(value) {
    try {
      return JSON.parse(JSON.stringify(value == null ? {} : value));
    } catch (e) {
      return value && typeof value === 'object' ? value : {};
    }
  }

  function audienceCatalogModes() {
    return Array.isArray(audienceCatalog.modes) ? audienceCatalog.modes : [];
  }

  function audienceCatalogPresets() {
    return Array.isArray(audienceCatalog.presets) ? audienceCatalog.presets : [];
  }

  function audienceCatalogSuggestions() {
    return Array.isArray(audienceCatalog.suggestions) ? audienceCatalog.suggestions : [];
  }

  function getAudienceDefaultState() {
    var defaultState = audienceCatalog.default_state && typeof audienceCatalog.default_state === 'object'
      ? audienceCatalog.default_state
      : {
          version: 1,
          mode: 'broad_local',
          gender: 'all',
          event_type_hint: 'ticketed_concert',
          preset_key: '',
          preset_label: '',
          advantage_audience: 0,
          advantage_detailed_targeting: 0,
          artist_inspirations: [],
          terms: [],
          exclusions: []
        };
    return deepClone(defaultState);
  }

  function normalizeAudienceMode(value) {
    var safe = String(value || '').trim().toLowerCase();
    if (safe === 'interest_guided' || safe === 'retargeting' || safe === 'lookalike') {
      return safe;
    }
    return 'broad_local';
  }

  function normalizeAudienceGender(value) {
    var safe = String(value || '').trim().toLowerCase();
    if (safe === 'women' || safe === 'men') {
      return safe;
    }
    return 'all';
  }

  function normalizeAudienceEventType(value) {
    var safe = String(value || '').trim().toLowerCase();
    if (safe === 'tribute_show' || safe === 'festival' || safe === 'family_community' || safe === 'venue_awareness' || safe === 'other') {
      return safe;
    }
    return 'ticketed_concert';
  }

  function normalizeAudienceTermType(value) {
    var safe = String(value || '').trim().toLowerCase();
    return safe === 'behavior' ? 'behavior' : 'interest';
  }

  function normalizeAudienceValidationStatus(value) {
    var safe = String(value || '').trim().toLowerCase();
    if (safe === 'valid' || safe === 'deprecated' || safe === 'unavailable') {
      return safe;
    }
    return 'unvalidated';
  }

  function normalizeAudienceSource(value) {
    var safe = String(value || '').trim().toLowerCase();
    if (safe === 'preset' || safe === 'manual' || safe === 'legacy' || safe === 'lookup') {
      return safe;
    }
    return 'suggestion';
  }

  function normalizeAudienceStringList(items, limit) {
    var maxItems = Math.max(1, parseIntSafe(limit, 12));
    var list = [];
    var seen = {};
    var source = Array.isArray(items) ? items : (String(items || '').trim() ? String(items).split(/\s*,\s*/) : []);
    source.forEach(function (item) {
      var label = String(item || '').trim();
      var signature = label.toLowerCase();
      if (!label || seen[signature]) {
        return;
      }
      seen[signature] = true;
      if (list.length < maxItems) {
        list.push(label);
      }
    });
    return list;
  }

  function normalizeAudienceTerm(raw) {
    var item = raw && typeof raw === 'object' ? raw : {};
    var label = String(item.label || '').trim();
    var key = String(item.key || '').trim().toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '');
    var metaId = String(item.meta_targeting_id || '').replace(/\D+/g, '');
    var status = normalizeAudienceValidationStatus(item.validation_status || (metaId ? 'valid' : 'unvalidated'));
    if (!key && label) {
      key = String(label).trim().toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '');
    }
    return {
      key: key,
      label: label,
      targeting_type: normalizeAudienceTermType(item.targeting_type || 'interest'),
      group: String(item.group || 'manual').trim().toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, ''),
      provider: String(item.provider || 'meta').trim().toLowerCase() || 'meta',
      meta_targeting_id: metaId,
      validation_status: status,
      source: normalizeAudienceSource(item.source || 'suggestion'),
      note: String(item.note || '').trim()
    };
  }

  function normalizeAudienceTerms(items) {
    var list = [];
    var seen = {};
    (Array.isArray(items) ? items : []).forEach(function (item) {
      var term = normalizeAudienceTerm(item);
      if (!term.label) {
        return;
      }
      var signature = [term.key || term.label.toLowerCase(), term.targeting_type, term.source].join('|');
      if (seen[signature]) {
        return;
      }
      seen[signature] = true;
      list.push(term);
    });
    list.sort(function (a, b) {
      return String(a.label || '').localeCompare(String(b.label || ''));
    });
    return list.slice(0, 30);
  }

  function normalizeAudienceState(raw) {
    var defaults = getAudienceDefaultState();
    var item = raw && typeof raw === 'object' ? raw : {};
    var next = {
      version: parseIntSafe(item.version, parseIntSafe(defaults.version, 1)),
      mode: normalizeAudienceMode(item.mode || defaults.mode),
      gender: normalizeAudienceGender(item.gender || defaults.gender),
      event_type_hint: normalizeAudienceEventType(item.event_type_hint || defaults.event_type_hint),
      preset_key: String(item.preset_key || '').trim().toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, ''),
      preset_label: String(item.preset_label || '').trim(),
      advantage_audience: item.advantage_audience ? 1 : 0,
      advantage_detailed_targeting: item.advantage_detailed_targeting ? 1 : 0,
      artist_inspirations: normalizeAudienceStringList(item.artist_inspirations || [], 12),
      terms: normalizeAudienceTerms(item.terms || []),
      exclusions: normalizeAudienceTerms(item.exclusions || [])
    };
    return next;
  }

  function ensureAudienceState() {
    if (!audienceState) {
      audienceState = normalizeAudienceState(getAudienceDefaultState());
    }
    return audienceState;
  }

  function audienceModeLabel(mode) {
    var label = '';
    audienceCatalogModes().forEach(function (entry) {
      if (!label && String(entry.key || '') === String(mode || '')) {
        label = String(entry.label || '').trim();
      }
    });
    if (label) {
      return label;
    }
    if (String(mode || '') === 'interest_guided') {
      return 'Interest-guided audience';
    }
    if (String(mode || '') === 'retargeting') {
      return 'Past-engagement / retargeting audience';
    }
    if (String(mode || '') === 'lookalike') {
      return 'Lookalike audience';
    }
    return 'Broad/local audience';
  }

  function audienceGenderLabel(gender) {
    if (String(gender || '') === 'women') {
      return 'Women';
    }
    if (String(gender || '') === 'men') {
      return 'Men';
    }
    return 'All genders';
  }

  function audienceEventTypeLabel(eventType) {
    var key = String(eventType || '').trim();
    var select = byId('vms-ma-audience-event-type');
    if (select) {
      var option = select.querySelector('option[value="' + key + '"]');
      if (option) {
        return String(option.textContent || '').trim();
      }
    }
    if (key === 'tribute_show') {
      return 'Tribute / themed show';
    }
    if (key === 'festival') {
      return 'Festival / seasonal event';
    }
    if (key === 'family_community') {
      return 'Family / community event';
    }
    if (key === 'venue_awareness') {
      return 'Venue awareness';
    }
    if (key === 'other') {
      return 'Other';
    }
    return 'Ticketed concert';
  }

  function findAudiencePreset(key) {
    var target = String(key || '').trim();
    var found = null;
    audienceCatalogPresets().forEach(function (preset) {
      if (!found && String(preset && preset.key || '') === target) {
        found = preset;
      }
    });
    return found;
  }

  function findAudienceSuggestionTerm(termKey) {
    var target = String(termKey || '').trim();
    var found = null;
    audienceCatalogSuggestions().forEach(function (group) {
      if (found || !group || !Array.isArray(group.items)) {
        return;
      }
      group.items.forEach(function (item) {
        if (!found && String(item && item.key || '') === target) {
          found = item;
        }
      });
    });
    return found;
  }

  function readAudienceModeFromForm() {
    var selected = document.querySelector('input[name="vms_ma_audience_mode"]:checked');
    return normalizeAudienceMode(selected ? selected.value : 'broad_local');
  }

  function readManualAudienceTerms() {
    var labels = normalizeAudienceStringList(value('vms-ma-interests'), 20);
    return labels.map(function (label) {
      return normalizeAudienceTerm({
        key: label,
        label: label,
        targeting_type: 'interest',
        group: 'manual',
        provider: 'meta',
        meta_targeting_id: '',
        validation_status: 'unvalidated',
        source: 'manual'
      });
    });
  }

  function syncAudienceStateFromForm() {
    var next = normalizeAudienceState(ensureAudienceState());
    next.mode = readAudienceModeFromForm();
    next.gender = normalizeAudienceGender(value('vms-ma-gender') || next.gender);
    next.event_type_hint = normalizeAudienceEventType(value('vms-ma-audience-event-type') || next.event_type_hint);
    next.preset_key = String(value('vms-ma-audience-preset') || next.preset_key || '').trim();
    next.advantage_audience = (byId('vms-ma-advantage-audience') && byId('vms-ma-advantage-audience').checked) ? 1 : 0;
    next.advantage_detailed_targeting = (byId('vms-ma-advantage-detailed-targeting') && byId('vms-ma-advantage-detailed-targeting').checked) ? 1 : 0;

    var preset = findAudiencePreset(next.preset_key);
    if (preset) {
      next.preset_label = String(preset.label || next.preset_label || '').trim();
    } else if (!next.preset_key) {
      next.preset_label = '';
    }

    var preservedTerms = next.terms.filter(function (term) {
      return String((term && term.source) || '') !== 'manual';
    });
    next.terms = normalizeAudienceTerms(preservedTerms.concat(readManualAudienceTerms()));
    audienceState = next;
    return audienceState;
  }

  function syncAudienceStateToForm() {
    var state = normalizeAudienceState(ensureAudienceState());
    var manualLabels = state.terms.filter(function (term) {
      return String((term && term.source) || '') === 'manual';
    }).map(function (term) {
      return String(term.label || '').trim();
    }).filter(Boolean);

    document.querySelectorAll('input[name="vms_ma_audience_mode"]').forEach(function (radio) {
      radio.checked = String(radio.value || '') === state.mode;
    });
    if (byId('vms-ma-gender')) {
      byId('vms-ma-gender').value = state.gender;
    }
    if (byId('vms-ma-audience-event-type')) {
      byId('vms-ma-audience-event-type').value = state.event_type_hint;
    }
    if (byId('vms-ma-audience-preset')) {
      byId('vms-ma-audience-preset').value = state.preset_key;
    }
    if (byId('vms-ma-advantage-audience')) {
      byId('vms-ma-advantage-audience').checked = !!state.advantage_audience;
    }
    if (byId('vms-ma-advantage-detailed-targeting')) {
      byId('vms-ma-advantage-detailed-targeting').checked = !!state.advantage_detailed_targeting;
    }
    if (byId('vms-ma-interests')) {
      byId('vms-ma-interests').value = manualLabels.join(', ');
    }
  }

  function setAudienceState(nextState, options) {
    audienceState = normalizeAudienceState(nextState);
    syncAudienceStateToForm();
    renderAudienceTargetingUi();
    if (!(options && options.skipDerived)) {
      renderCopyPackPanel();
    }
  }

  function updateAudienceState(mutator, options) {
    var current = normalizeAudienceState(ensureAudienceState());
    var draft = normalizeAudienceState(typeof mutator === 'function' ? (mutator(deepClone(current)) || current) : current);
    setAudienceState(draft, options || {});
  }

  function audienceTermIsSelected(termKey) {
    var state = syncAudienceStateFromForm();
    return state.terms.some(function (term) {
      return String((term && term.key) || '') === String(termKey || '');
    });
  }

  function toggleAudienceSuggestionTerm(termKey) {
    var suggestion = findAudienceSuggestionTerm(termKey);
    if (!suggestion) {
      return;
    }
    updateAudienceState(function (next) {
      var key = String(termKey || '');
      var exists = next.terms.some(function (term) {
        return String((term && term.key) || '') === key;
      });
      if (exists) {
        next.terms = next.terms.filter(function (term) {
          return String((term && term.key) || '') !== key;
        });
      } else {
        next.terms = next.terms.concat([normalizeAudienceTerm(suggestion)]);
      }
      return next;
    });
  }

  function addAudienceArtistInspiration(label) {
    var valueToAdd = String(label || '').trim();
    if (!valueToAdd) {
      return;
    }
    updateAudienceState(function (next) {
      next.artist_inspirations = normalizeAudienceStringList(next.artist_inspirations.concat([valueToAdd]), 12);
      return next;
    });
    if (byId('vms-ma-artist-inspiration-input')) {
      byId('vms-ma-artist-inspiration-input').value = '';
    }
  }

  function removeAudienceArtistInspiration(label) {
    updateAudienceState(function (next) {
      next.artist_inspirations = next.artist_inspirations.filter(function (item) {
        return String(item || '').toLowerCase() !== String(label || '').toLowerCase();
      });
      return next;
    });
  }

  function removeAudienceSelectedTerm(termKey) {
    updateAudienceState(function (next) {
      var removed = null;
      next.terms = next.terms.filter(function (term) {
        var keep = String((term && term.key) || '') !== String(termKey || '');
        if (!keep) {
          removed = term;
        }
        return keep;
      });
      if (removed && String((removed && removed.source) || '') === 'manual') {
        var manualInput = byId('vms-ma-interests');
        if (manualInput) {
          var labels = normalizeAudienceStringList(manualInput.value || '', 20).filter(function (label) {
            return String(label || '').toLowerCase() !== String((removed && removed.label) || '').toLowerCase();
          });
          manualInput.value = labels.join(', ');
        }
      }
      return next;
    });
  }

  function applyAudiencePresetSelection() {
    var presetKey = value('vms-ma-audience-preset');
    var preset = findAudiencePreset(presetKey);
    var status = byId('vms-ma-audience-preset-status');
    if (!preset) {
      if (status) {
        status.textContent = 'Choose a preset first.';
      }
      return;
    }
    updateAudienceState(function (next) {
      next.mode = normalizeAudienceMode(preset.mode || next.mode);
      next.gender = normalizeAudienceGender(preset.gender || next.gender);
      next.event_type_hint = normalizeAudienceEventType(preset.event_type_hint || next.event_type_hint);
      next.preset_key = String(preset.key || '').trim();
      next.preset_label = String(preset.label || '').trim();
      next.terms = normalizeAudienceTerms((preset.terms || []).map(function (termKey) {
        var suggestion = findAudienceSuggestionTerm(termKey);
        if (suggestion) {
          var clone = deepClone(suggestion);
          clone.source = 'preset';
          return clone;
        }
        return {
          key: termKey,
          label: termKey,
          targeting_type: 'interest',
          source: 'preset',
          validation_status: 'unvalidated'
        };
      }));
      next.artist_inspirations = normalizeAudienceStringList(preset.artist_inspirations || [], 12);
      return next;
    });
    if (preset.radius_miles != null) {
      setField('vms-ma-radius', preset.radius_miles);
    }
    if (preset.age_min != null) {
      setField('vms-ma-age-min', preset.age_min);
    }
    if (preset.age_max != null) {
      setField('vms-ma-age-max', preset.age_max);
    }
    if (status) {
      status.textContent = String(preset.description || 'Preset applied. You can edit the audience immediately.');
    }
    emitFeedback('info', 'Audience preset applied. Review and adjust before saving.', 'd');
  }

  function buildAudienceStateFromIncoming(rawState, gender, legacyInterests) {
    var sourceState = (rawState && typeof rawState === 'object') ? rawState : {};
    var next = normalizeAudienceState(Object.assign({}, sourceState, {
      gender: normalizeAudienceGender((sourceState && sourceState.gender) || gender || 'all')
    }));
    if (next.terms.length) {
      return next;
    }

    var legacyLabels = normalizeAudienceStringList(legacyInterests, 20);
    if (!legacyLabels.length) {
      return next;
    }

    next.mode = next.mode === 'broad_local' ? 'interest_guided' : next.mode;
    next.terms = normalizeAudienceTerms(legacyLabels.map(function (label) {
      return {
        key: label,
        label: label,
        targeting_type: 'interest',
        group: 'legacy',
        provider: 'meta',
        meta_targeting_id: '',
        validation_status: 'unvalidated',
        source: 'legacy'
      };
    }));
    return next;
  }

  function buildAudienceHydrationTermSnapshot(items) {
    return normalizeAudienceTerms(items || []).map(function (term) {
      return {
        key: String(term.key || '').trim(),
        label: String(term.label || '').trim(),
        targeting_type: normalizeAudienceTermType(term.targeting_type || 'interest'),
        source: normalizeAudienceSource(term.source || 'suggestion'),
        group: String(term.group || '').trim(),
        meta_targeting_id: String(term.meta_targeting_id || '').replace(/\D+/g, ''),
        validation_status: normalizeAudienceValidationStatus(term.validation_status),
        note: String(term.note || '').trim()
      };
    });
  }

  function buildAudienceHydrationSnapshot(state, targetingFields) {
    var normalizedState = normalizeAudienceState(state || {});
    var fields = targetingFields && typeof targetingFields === 'object' ? targetingFields : {};
    return {
      targeting_address: String(fields.targeting_address || '').trim(),
      radius_miles: parseIntSafe(fields.radius_miles, parseIntSafe(defaults.radius, 15)),
      age_min: parseIntSafe(fields.age_min, parseIntSafe(defaults.age_min, 21)),
      age_max: parseIntSafe(fields.age_max, parseIntSafe(defaults.age_max, 65)),
      gender: normalizeAudienceGender(normalizedState.gender || 'all'),
      mode: normalizeAudienceMode(normalizedState.mode || 'broad_local'),
      preset_key: String(normalizedState.preset_key || '').trim(),
      event_type_hint: normalizeAudienceEventType(normalizedState.event_type_hint || 'ticketed_concert'),
      advantage_audience: normalizedState.advantage_audience ? 1 : 0,
      advantage_detailed_targeting: normalizedState.advantage_detailed_targeting ? 1 : 0,
      artist_inspirations: normalizeAudienceStringList(normalizedState.artist_inspirations || [], 12),
      terms: buildAudienceHydrationTermSnapshot(normalizedState.terms || []),
      exclusions: buildAudienceHydrationTermSnapshot(normalizedState.exclusions || [])
    };
  }

  function buildAudienceHydrationSnapshotFromBuild(build) {
    var targeting = (build && build.targeting_payload && typeof build.targeting_payload === 'object') ? build.targeting_payload : {};
    var state = buildAudienceStateFromIncoming(
      targeting.audience_targeting,
      targeting.gender,
      Array.isArray(targeting.interests) ? targeting.interests : String(targeting.interests || '')
    );
    return buildAudienceHydrationSnapshot(state, {
      targeting_address: targeting.targeting_address,
      radius_miles: targeting.radius_miles,
      age_min: targeting.age_min,
      age_max: targeting.age_max
    });
  }

  function buildAudienceHydrationSnapshotFromForm() {
    var state = normalizeAudienceState(syncAudienceStateFromForm());
    return buildAudienceHydrationSnapshot(state, {
      targeting_address: value('vms-ma-targeting-address') || '',
      radius_miles: value('vms-ma-radius'),
      age_min: value('vms-ma-age-min'),
      age_max: value('vms-ma-age-max')
    });
  }

  function buildAudienceHydrationSignature(snapshot) {
    try {
      return JSON.stringify(snapshot || {});
    } catch (err) {
      return '';
    }
  }

  function compareAudienceHydrationSnapshots(expected, actual) {
    var mismatches = [];
    if (parseIntSafe(expected.age_min, 0) !== parseIntSafe(actual.age_min, 0)) {
      mismatches.push('age min');
    }
    if (parseIntSafe(expected.age_max, 0) !== parseIntSafe(actual.age_max, 0)) {
      mismatches.push('age max');
    }
    if (parseIntSafe(expected.radius_miles, 0) !== parseIntSafe(actual.radius_miles, 0)) {
      mismatches.push('radius');
    }
    if (String(expected.gender || '') !== String(actual.gender || '')) {
      mismatches.push('gender');
    }
    if (String(expected.mode || '') !== String(actual.mode || '')) {
      mismatches.push('audience mode');
    }
    if (String(expected.preset_key || '') !== String(actual.preset_key || '')) {
      mismatches.push('preset');
    }
    if (String(expected.event_type_hint || '') !== String(actual.event_type_hint || '')) {
      mismatches.push('event type');
    }
    if (!!expected.advantage_audience !== !!actual.advantage_audience) {
      mismatches.push('Advantage audience');
    }
    if (!!expected.advantage_detailed_targeting !== !!actual.advantage_detailed_targeting) {
      mismatches.push('detailed targeting expansion');
    }
    if (buildAudienceHydrationSignature(expected.artist_inspirations) !== buildAudienceHydrationSignature(actual.artist_inspirations)) {
      mismatches.push('artist inspirations');
    }

    var expectedTermKeys = (expected.terms || []).map(function (term) {
      return [term.key, term.label, term.targeting_type, term.source, term.group].join('|');
    });
    var actualTermKeys = (actual.terms || []).map(function (term) {
      return [term.key, term.label, term.targeting_type, term.source, term.group].join('|');
    });
    if (buildAudienceHydrationSignature(expectedTermKeys) !== buildAudienceHydrationSignature(actualTermKeys)) {
      mismatches.push('selected terms');
    } else {
      var expectedTermStates = (expected.terms || []).map(function (term) {
        return [term.key, term.validation_status, term.meta_targeting_id, term.note].join('|');
      });
      var actualTermStates = (actual.terms || []).map(function (term) {
        return [term.key, term.validation_status, term.meta_targeting_id, term.note].join('|');
      });
      if (buildAudienceHydrationSignature(expectedTermStates) !== buildAudienceHydrationSignature(actualTermStates)) {
        mismatches.push('validation states');
      }
    }

    if (buildAudienceHydrationSignature(expected.exclusions || []) !== buildAudienceHydrationSignature(actual.exclusions || [])) {
      mismatches.push('exclusions');
    }

    return mismatches;
  }

  function resetBuildHydrationState() {
    buildHydrationState = {
      buildId: '',
      ok: true,
      mismatches: [],
      expectedSignature: '',
      actualSignature: ''
    };
  }

  function hasBlockingBuildHydrationMismatch() {
    var activeId = String(getActiveBuildId() || '').trim();
    return !!(activeId && String(buildHydrationState.buildId || '') === activeId && buildHydrationState.ok === false);
  }

  function getBuildHydrationGuardMessage(actionLabel) {
    if (!hasBlockingBuildHydrationMismatch()) {
      return '';
    }
    var action = String(actionLabel || 'saving').trim() || 'saving';
    var mismatchText = buildHydrationState.mismatches.length ? buildHydrationState.mismatches.join(', ') : 'saved audience values';
    return 'Loaded draft #' + String(buildHydrationState.buildId || '') + ' did not hydrate Step D correctly (' + mismatchText + '). Reload this draft before ' + action + ' so saved targeting is not overwritten.';
  }

  function guardLoadedBuildHydration(actionLabel) {
    var message = getBuildHydrationGuardMessage(actionLabel);
    if (!message) {
      return true;
    }
    emitFeedback('error', message, 'd');
    return false;
  }

  function auditLoadedBuildHydration(build) {
    resetBuildHydrationState();
    if (!build || !build.id) {
      return true;
    }
    var expected = buildAudienceHydrationSnapshotFromBuild(build);
    var actual = buildAudienceHydrationSnapshotFromForm();
    var mismatches = compareAudienceHydrationSnapshots(expected, actual);
    buildHydrationState = {
      buildId: String(build.id || '').trim(),
      ok: mismatches.length === 0,
      mismatches: mismatches,
      expectedSignature: buildAudienceHydrationSignature(expected),
      actualSignature: buildAudienceHydrationSignature(actual)
    };
    if (!buildHydrationState.ok) {
      emitFeedback('error', getBuildHydrationGuardMessage('saving'), 'd');
    }
    return buildHydrationState.ok;
  }

  function audienceTermStatusLabel(term) {
    var statuses = audienceCatalog.statuses && typeof audienceCatalog.statuses === 'object' ? audienceCatalog.statuses : {};
    var key = normalizeAudienceValidationStatus(term && term.validation_status);
    return String(statuses[key] || (key === 'valid' ? 'Validated Meta ID' : (key === 'deprecated' ? 'Deprecated in Meta' : (key === 'unavailable' ? 'Unavailable in Meta' : 'Needs Meta validation'))));
  }

  function buildAudiencePreviewSnapshot() {
    var state = syncAudienceStateFromForm();
    var ageMin = parseIntSafe(value('vms-ma-age-min'), parseIntSafe(defaults.age_min, 21));
    var ageMax = parseIntSafe(value('vms-ma-age-max'), parseIntSafe(defaults.age_max, 65));
    var radius = parseIntSafe(value('vms-ma-radius'), parseIntSafe(defaults.radius, 15));
    var anchor = String(value('vms-ma-targeting-address') || getDefaultTargetingAddress() || '').trim();
    var locations = String(value('vms-ma-locations') || '').trim();
    var outerLocations = String(value('vms-ma-outer-locations') || '').trim();
    var activeTerms = state.terms.filter(function (term) {
      var status = normalizeAudienceValidationStatus(term && term.validation_status);
      return status !== 'deprecated' && status !== 'unavailable';
    });
    var pendingTerms = activeTerms.filter(function (term) {
      return normalizeAudienceValidationStatus(term && term.validation_status) !== 'valid' || !String(term && term.meta_targeting_id || '').trim();
    });
    var deprecatedTerms = state.terms.filter(function (term) {
      return normalizeAudienceValidationStatus(term && term.validation_status) === 'deprecated';
    });
    var unavailableTerms = state.terms.filter(function (term) {
      return normalizeAudienceValidationStatus(term && term.validation_status) === 'unavailable';
    });
    var warnings = [];

    if (state.mode === 'broad_local' && activeTerms.length) {
      warnings.push('Detailed targeting ideas are saved, but Broad/local mode keeps them inactive until you switch to Interest-guided.');
    }
    if (pendingTerms.length) {
      warnings.push(String(pendingTerms.length) + ' selected targeting idea' + (pendingTerms.length === 1 ? ' needs' : 's need') + ' Meta validation before it can be sent as a live targeting ID.');
    }
    if (state.artist_inspirations.length) {
      warnings.push('Artist and band inspirations are stored as lookup seeds only. They are not sent to Meta until matched to validated targeting IDs.');
    }
    if (deprecatedTerms.length) {
      warnings.push('Deprecated targeting labels saved for review: ' + deprecatedTerms.map(function (term) { return term.label; }).join(', ') + '.');
    }
    if (unavailableTerms.length) {
      warnings.push('Unavailable targeting labels saved for review: ' + unavailableTerms.map(function (term) { return term.label; }).join(', ') + '.');
    }
    if (state.advantage_detailed_targeting) {
      warnings.push('Detailed targeting expansion intent is saved, but its exact Marketing API write shape should be revalidated before live use.');
    }

    return {
      mode: state.mode,
      modeLabel: audienceModeLabel(state.mode),
      gender: state.gender,
      genderLabel: audienceGenderLabel(state.gender),
      presetLabel: String(state.preset_label || '').trim(),
      eventType: state.event_type_hint,
      anchor: anchor,
      locations: locations,
      outerLocations: outerLocations,
      radius: radius,
      ageMin: ageMin,
      ageMax: ageMax,
      placementsSummary: getCreatePlacementSummary(),
      activeTerms: activeTerms,
      exclusions: state.exclusions,
      artistInspirations: state.artist_inspirations.slice(),
      advantageAudience: !!state.advantage_audience,
      advantageDetailedTargeting: !!state.advantage_detailed_targeting,
      warnings: warnings
    };
  }

  function renderAudiencePresetStatus() {
    var status = byId('vms-ma-audience-preset-status');
    if (!status) {
      return;
    }
    var preset = findAudiencePreset(value('vms-ma-audience-preset'));
    if (!preset) {
      status.textContent = '';
      return;
    }
    status.textContent = String(preset.description || '').trim();
  }

  function renderAudienceSuggestionGroups() {
    var wrap = byId('vms-ma-audience-suggestion-groups');
    if (!wrap) {
      return;
    }
    var selectedKeys = {};
    syncAudienceStateFromForm().terms.forEach(function (term) {
      selectedKeys[String((term && term.key) || '')] = true;
    });
    var html = '';
    audienceCatalogSuggestions().forEach(function (group) {
      if (!group || !Array.isArray(group.items) || !group.items.length) {
        return;
      }
      html += '<section class="vms-ma-audience-suggestion-group">';
      html += '<h4>' + escapeHtml(String(group.label || 'Suggestions')) + '</h4>';
      if (group.description) {
        html += '<p class="description">' + escapeHtml(String(group.description)) + '</p>';
      }
      html += '<div class="vms-ma-audience-chip-grid">';
      group.items.forEach(function (item) {
        var key = String(item && item.key || '');
        var active = !!selectedKeys[key];
        html += '<button type="button" class="button-link vms-ma-audience-chip' + (active ? ' is-active' : '') + '" data-audience-term-key="' + escapeAttribute(key) + '">' +
          '<span>' + escapeHtml(String(item && item.label || key)) + '</span>' +
          '<small>Suggested label</small>' +
        '</button>';
      });
      html += '</div></section>';
    });
    wrap.innerHTML = html;
  }

  function renderAudienceTokenLists() {
    var state = syncAudienceStateFromForm();
    var termWrap = byId('vms-ma-audience-selected-terms');
    var artistWrap = byId('vms-ma-artist-inspiration-list');
    if (artistWrap) {
      if (!state.artist_inspirations.length) {
        artistWrap.innerHTML = '<span class="vms-ma-audience-token-empty">No artist or band inspiration saved yet.</span>';
      } else {
        artistWrap.innerHTML = state.artist_inspirations.map(function (label) {
          return '<span class="vms-ma-audience-token">' +
            '<span>' + escapeHtml(label) + '</span>' +
            '<button type="button" class="vms-ma-audience-token-remove" data-audience-remove-artist="' + escapeAttribute(label) + '" aria-label="Remove inspiration">×</button>' +
          '</span>';
        }).join('');
      }
    }
    if (termWrap) {
      if (!state.terms.length) {
        termWrap.innerHTML = '<span class="vms-ma-audience-token-empty">No saved targeting terms yet.</span>';
      } else {
        termWrap.innerHTML = state.terms.map(function (term) {
          var typeLabel = normalizeAudienceTermType(term && term.targeting_type) === 'behavior' ? 'Suggested behavior label' : 'Suggested label';
          var statusLabel = audienceTermStatusLabel(term);
          var statusClass = 'is-' + normalizeAudienceValidationStatus(term && term.validation_status);
          return '<span class="vms-ma-audience-token">' +
            '<span>' + escapeHtml(String(term.label || '')) + '</span>' +
            '<small class="vms-ma-audience-token-type">' + escapeHtml(typeLabel) + '</small>' +
            '<small class="vms-ma-audience-token-status ' + escapeAttribute(statusClass) + '">' + escapeHtml(statusLabel) + '</small>' +
            '<button type="button" class="vms-ma-audience-token-remove" data-audience-remove-term="' + escapeAttribute(String(term.key || '')) + '" aria-label="Remove targeting term">×</button>' +
          '</span>';
        }).join('');
      }
    }
  }

  function renderAudiencePreviewPanel() {
    var snapshot = buildAudiencePreviewSnapshot();
    var panel = byId('vms-ma-targeting-preview');
    var warningPanel = byId('vms-ma-targeting-preview-warnings');
    if (panel) {
      var locationsSummary = [];
      if (snapshot.anchor) {
        locationsSummary.push('Primary anchor: ' + snapshot.anchor);
      }
      if (snapshot.locations) {
        locationsSummary.push('Additional locations: ' + snapshot.locations.replace(/\n+/g, '; '));
      }
      if (snapshot.outerLocations) {
        locationsSummary.push('Outer Towns: ' + snapshot.outerLocations.replace(/\n+/g, '; '));
      }
      panel.innerHTML = [
        '<div><strong>Audience mode:</strong> ' + escapeHtml(snapshot.modeLabel) + '</div>',
        '<div><strong>Audience style:</strong> ' + escapeHtml(audienceEventTypeLabel(snapshot.eventType)) + '</div>',
        '<div><strong>Location:</strong> ' + escapeHtml(locationsSummary.length ? locationsSummary.join(' | ') : 'No targeting anchor entered yet') + '</div>',
        '<div><strong>Radius / age / gender:</strong> ' + escapeHtml(snapshot.radius + ' miles • ages ' + snapshot.ageMin + '-' + (snapshot.ageMax === 65 ? '65+' : snapshot.ageMax) + ' • ' + snapshot.genderLabel) + '</div>',
        '<div><strong>Placements:</strong> ' + escapeHtml(snapshot.placementsSummary) + '</div>',
        '<div><strong>Saved targeting ideas:</strong> ' + escapeHtml(snapshot.activeTerms.length ? snapshot.activeTerms.map(function (term) { return term.label; }).join(', ') : 'None selected') + '</div>',
        '<div><strong>Artist / band inspiration:</strong> ' + escapeHtml(snapshot.artistInspirations.length ? snapshot.artistInspirations.join(', ') : 'None saved') + '</div>',
        '<div><strong>Exclusions:</strong> ' + escapeHtml(snapshot.exclusions.length ? snapshot.exclusions.map(function (term) { return term.label; }).join(', ') : 'None in Phase 1') + '</div>',
        '<div><strong>Advantage / expansion intent:</strong> ' + escapeHtml('Advantage+ audience ' + (snapshot.advantageAudience ? 'stored on' : 'off') + '; detailed targeting expansion ' + (snapshot.advantageDetailedTargeting ? 'stored on' : 'off')) + '</div>',
        snapshot.presetLabel ? ('<div><strong>Audience preset:</strong> ' + escapeHtml(snapshot.presetLabel) + '</div>') : ''
      ].join('');
    }
    if (warningPanel) {
      if (!snapshot.warnings.length) {
        warningPanel.innerHTML = '<p class="description">No audience warnings right now.</p>';
      } else {
        warningPanel.innerHTML = '<ul>' + snapshot.warnings.map(function (warning) {
          return '<li>' + escapeHtml(warning) + '</li>';
        }).join('') + '</ul>';
      }
    }
  }

  function renderAudienceTargetingUi() {
    renderAudiencePresetStatus();
    renderAudienceSuggestionGroups();
    renderAudienceTokenLists();
    renderAudiencePreviewPanel();
  }

  function buildLegacyInterestStringFromAudienceState() {
    return syncAudienceStateFromForm().terms.map(function (term) {
      return String(term && term.label || '').trim();
    }).filter(Boolean).join(', ');
  }

  function initAudienceTargetingUi() {
    var presetSelect = byId('vms-ma-audience-preset');
    var artistInput = byId('vms-ma-artist-inspiration-input');
    var addArtistBtn = byId('vms-ma-artist-inspiration-add');

    audienceState = normalizeAudienceState(getAudienceDefaultState());

    if (presetSelect) {
      var options = ['<option value="">Choose an editable preset</option>'];
      audienceCatalogPresets().forEach(function (preset) {
        options.push('<option value="' + escapeAttribute(String(preset && preset.key || '')) + '">' + escapeHtml(String(preset && preset.label || 'Preset')) + '</option>');
      });
      presetSelect.innerHTML = options.join('');
    }

    if (presetSelect) {
      presetSelect.addEventListener('change', function (evt) {
        if (!evt || !evt.isTrusted) {
          renderAudiencePresetStatus();
          return;
        }
        if (!String(presetSelect.value || '').trim()) {
          renderAudiencePresetStatus();
          return;
        }
        applyAudiencePresetSelection();
      });
    }

    if (addArtistBtn) {
      addArtistBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        addAudienceArtistInspiration(value('vms-ma-artist-inspiration-input'));
      });
    }

    if (artistInput) {
      artistInput.addEventListener('keydown', function (evt) {
        if (evt.key === 'Enter') {
          evt.preventDefault();
          addAudienceArtistInspiration(value('vms-ma-artist-inspiration-input'));
        }
      });
    }

    syncAudienceStateToForm();
    renderAudienceTargetingUi();
  }

  function getPresetModeLabel(preset) {
    var key = String(preset || '').trim();
    var select = byId('vms-ma-preset-mode');
    if (select) {
      var option = select.querySelector('option[value="' + key + '"]');
      if (option) {
        return String(option.textContent || '').trim();
      }
    }
    return key ? key.replace(/_/g, ' ') : 'Flat run';
  }

  function getDirectCreateScheduleSupport() {
    var preset = value('vms-ma-preset-mode') || 'flat_run';
    var presetLabel = getPresetModeLabel(preset);
    var tiers = buildTierSchedule();
    if (!Array.isArray(tiers) || !tiers.length) {
      return {
        blocked: false,
        message: '',
        preset: preset,
        presetLabel: presetLabel,
        tierCount: 0
      };
    }
    if (tiers.length <= 1) {
      return {
        blocked: false,
        message: '',
        preset: preset,
        presetLabel: presetLabel,
        tierCount: tiers.length
      };
    }
    return {
      blocked: true,
      message: 'Direct Meta create/update currently supports a single schedule window only. ' + presetLabel + ' is generating ' + tiers.length + ' windows. Dry run can still preview the first remaining window, but Create in Meta requires Flat run, Simple 7 day, Simple 14 day, Simple 30 day, Manual dates, or a calendar short enough to collapse to one window. Save Draft after switching.',
      preset: preset,
      presetLabel: presetLabel,
      tierCount: tiers.length
    };
  }


  function renderStrategyStatus() {
    var status = byId('vms-ma-strategy-status');
    if (!status) {
      return;
    }
    var key = value('vms-ma-strategy-template') || 'custom';
    var strategy = campaignStrategies[key] || campaignStrategies.custom;
    var preset = value('vms-ma-preset-mode') || '';
    var scheduleSupport = getDirectCreateScheduleSupport();
    var placementSummary = getCreatePlacementSummary();
    var scheduleSummary = getPresetModeLabel(preset || 'flat_run');
    if (scheduleSupport.tierCount > 0) {
      scheduleSummary += ' • ' + String(scheduleSupport.tierCount) + ' window' + (scheduleSupport.tierCount === 1 ? '' : 's');
    }
    var ctaSummary = isBuyTicketsLocked()
      ? 'CTA stays on Buy Tickets for ticketed-concert strategy.'
      : 'CTA override review is on in Advanced.';
    var warningHtml = scheduleSupport.blocked
      ? '<div class="vms-ma-strategy-summary__warning"><strong>Heads up:</strong> ' + escapeHtml(scheduleSupport.message) + '</div>'
      : '';
    status.innerHTML = [
      '<div class="vms-ma-strategy-summary__grid">',
      '<div class="vms-ma-strategy-summary__item"><span class="vms-ma-strategy-summary__eyebrow">Strategy selected</span><strong>' + escapeHtml(strategy.label || 'Campaign strategy') + '</strong></div>',
      '<div class="vms-ma-strategy-summary__item"><span class="vms-ma-strategy-summary__eyebrow">What this means</span><p>' + escapeHtml(strategy.status || 'Safe defaults are applied for pacing, CTA, and placements.') + '</p></div>',
      '<div class="vms-ma-strategy-summary__item"><span class="vms-ma-strategy-summary__eyebrow">Schedule / pacing</span><p>' + escapeHtml(scheduleSummary) + '</p></div>',
      '<div class="vms-ma-strategy-summary__item"><span class="vms-ma-strategy-summary__eyebrow">CTA / placements</span><p>' + escapeHtml(ctaSummary + ' ' + placementSummary) + '</p></div>',
      '</div>',
      warningHtml
    ].join('');
    renderCleanRoomRecipeChecklist();
    renderRecipePreview();
    renderCreativeFormatRequirements();
  }


  function renderCleanRoomRecipeChecklist() {
    var panel = byId('vms-ma-clean-room-checklist');
    var options = byId('vms-ma-clean-room-options');
    if (!panel) {
      return;
    }
    var key = value('vms-ma-strategy-template') || 'custom';
    if (!isCleanRoomStrategyKey(key)) {
      panel.classList.add('vms-ma-hidden');
      panel.innerHTML = '';
      if (options) {
        options.classList.add('vms-ma-hidden');
      }
      return;
    }
    if (options) {
      options.classList.toggle('vms-ma-hidden', key !== 'clean_room_full_push_v2');
    }
    var manual = getPlacementsMode() === 'manual';
    var placements = collectPlacementSelections();
    var includeRightColumn = isRightColumnSupportEnabled();
    var includeOuterTowns = isOuterTownsAdsetEnabled();
    var hasRightColumn = placements.indexOf('fb_right_column') !== -1;
    var hasFeed = placements.indexOf('fb_feed') !== -1 || placements.indexOf('ig_feed') !== -1;
    var hasReels = placements.indexOf('fb_reels') !== -1 || placements.indexOf('ig_reels') !== -1;
    var hasStories = placements.indexOf('fb_story') !== -1 || placements.indexOf('ig_story') !== -1;
    var rows = [
      ['Campaign is built from the VMS recipe, not Meta duplicate defaults', true],
      ['Any later Meta create stays paused for operator review first', true],
      ['Feed static, Feed 1:1 video, and Reels/Stories portrait video run as separate ad sets', key === 'clean_room_full_push_v2'],
      [includeOuterTowns ? 'Outer Towns feed ad set is included in this build' : 'Outer Towns feed ad set is intentionally excluded from this build', true],
      ['Advantage+ creative/catalog style automation stays off', (value('vms-ma-creative-automation-policy') || 'off') === 'off'],
      ['Multi-advertiser ads stay off', !(byId('vms-ma-multi-advertiser-ads') && byId('vms-ma-multi-advertiser-ads').checked)],
      ['Manual placement recipe is selected for Feed/Reels' + (hasStories ? '/Stories' : ''), manual && hasFeed && hasReels],
      [includeRightColumn ? 'Right Column support test is intentionally enabled' : 'Right Column stays off by default', includeRightColumn ? hasRightColumn : !hasRightColumn],
      ['Buy Tickets CTA lock is on', isBuyTicketsLocked()]
    ];
    var recipeLabel = key === 'clean_room_full_push' ? 'legacy recipe' : 'v2 recipe';
    var outerAgeRangeLabel = getCurrentAgeRangeLabel();
    var layoutParts = [
      'Core Feeds',
      'Feed Square Video',
      'Vertical Video Reels/Stories'
    ];
    if (includeOuterTowns) {
      layoutParts.push('Outer Towns Feeds (' + outerAgeRangeLabel + ')');
    }
    if (includeRightColumn) {
      layoutParts.push('optional Facebook Right Column Support Test');
    }
    var layout = 'Recipe layout: ' + layoutParts.join(', ') + '.';
    if (!includeRightColumn) {
      layout += ' Right Column is not created unless you enable the support test.';
    }
    panel.innerHTML = '<div class="vms-ma-clean-room-checklist__head"><strong>Clean-room ' + escapeHtml(recipeLabel) + ' summary</strong><span>Separate paused ad sets will be created from the saved VMS recipe when Meta creation is enabled later.</span></div>' +
      '<ul>' + rows.map(function (row) {
        return '<li class="' + (row[1] ? 'is-ok' : 'is-warn') + '"><span>' + (row[1] ? '✓' : '⚠') + '</span>' + escapeHtml(row[0]) + '</li>';
      }).join('') + '</ul>' +
      '<p class="description">' + escapeHtml(layout) + ' Before any later Go Live step, manually confirm Website Highlights / Show Spotlights and Multi-advertiser ads are still off for each ad in Meta.</p>';
    panel.classList.remove('vms-ma-hidden');
  }

  function applyCampaignStrategy(key, announce) {
    key = String(key || 'custom');
    var strategy = campaignStrategies[key] || campaignStrategies.custom;
    if (key === 'custom') {
      syncCtaLockUi();
      syncGoalOptimizationVisibility();
      renderStrategyStatus();
      renderCopyPackPanel();
      return;
    }
    if (strategy.preset) {
      setField('vms-ma-preset-mode', strategy.preset);
    }
    if (strategy.goal) {
      setField('vms-ma-goal', strategy.goal);
    }
    if (strategy.cta) {
      setField('vms-ma-cta-type', strategy.cta);
    }
    if (typeof strategy.forceBuyTickets !== 'undefined') {
      setChecked('vms-ma-force-buy-tickets', !!strategy.forceBuyTickets);
    }
    if (strategy.optimization) {
      setField('vms-ma-optimization', strategy.optimization);
    }
    if (strategy.placementsMode) {
      setPlacementsMode(strategy.placementsMode);
      if (Array.isArray(strategy.placements)) {
        document.querySelectorAll('.vms-ma-placement').forEach(function (el) {
          el.checked = strategy.placements.indexOf(String(el.value || '')) !== -1;
        });
      }
      syncPlacementsUi();
    }
    if (typeof strategy.rightColumnDefault !== 'undefined') {
      setChecked('vms-ma-include-right-column', !!strategy.rightColumnDefault);
      var rightColumnPlacement = builder.querySelector('.vms-ma-placement[value="fb_right_column"]');
      if (rightColumnPlacement) {
        rightColumnPlacement.checked = !!strategy.rightColumnDefault;
      }
    }
    if (strategy.ageMin) {
      setField('vms-ma-age-min', strategy.ageMin);
    }
    if (strategy.ageMax) {
      setField('vms-ma-age-max', strategy.ageMax);
    }
    if (strategy.creativePolicy) {
      setField('vms-ma-creative-automation-policy', strategy.creativePolicy);
    }
    if (typeof strategy.multiAdvertiser !== 'undefined') {
      setChecked('vms-ma-multi-advertiser-ads', !!strategy.multiAdvertiser);
    }
    syncCtaLockUi();
    syncGoalOptimizationVisibility();
    renderStrategyStatus();
    renderCopyPackPanel();
    if (announce) {
      emitFeedback('info', 'Applied strategy: ' + (strategy.label || key) + '.', 'b');
    }
  }

  function resolveStrategyTemplateKey(strategyTemplate, campaignRecipe) {
    var key = String(strategyTemplate || campaignRecipe || '').trim();
    if (String(campaignRecipe || '').trim() === 'clean_room_full_push_v2') {
      return 'clean_room_full_push_v2';
    }
    if (String(campaignRecipe || '').trim() === 'clean_room_full_push') {
      return 'clean_room_full_push';
    }
    return key;
  }

  function applySavedStrategyTemplate(strategyKey) {
    var key = String(strategyKey || '').trim();
    if (!key) {
      return;
    }
    setField('vms-ma-strategy-template', key, { silent: true });
    applyCampaignStrategy(key, false);
  }

  function getDefaultTargetingAddress() {
    if (!lastEventContext) {
      return '';
    }
    return String(lastEventContext.location_targeting_anchor || '').trim();
  }

  function classifyTargetingAddress(raw) {
    var value = String(raw || '').trim();
    if (!value) {
      return { valid: false, kind: 'missing', message: '' };
    }
    if (/^\d{5}(?:-\d{4})?$/.test(value)) {
      return { valid: true, kind: 'zip', message: 'ZIP anchor looks usable.' };
    }
    if (/[A-Za-z]/.test(value) && /\d/.test(value) && value.length >= 8) {
      return { valid: true, kind: 'address', message: 'Street-address anchor looks usable.' };
    }
    return { valid: false, kind: 'weak', message: 'Enter a full street address or ZIP. Venue names and city/state labels are not reliable Meta anchors.' };
  }

  function updateTargetingAddressStatus() {
    var field = byId('vms-ma-targeting-address');
    var status = byId('vms-ma-targeting-address-status');
    if (!field || !status) {
      return true;
    }

    var raw = String(field.value || '').trim();
    var fallback = getDefaultTargetingAddress();
    status.className = 'description';

    if (!raw) {
      if (fallback) {
        status.textContent = 'Using Event Plan venue address from VMS: ' + fallback;
        status.classList.add('vms-ma-inline-info');
        return true;
      }
      status.textContent = 'Enter a full street address or ZIP for the primary radius anchor.';
      status.classList.add('vms-ma-inline-warning');
      return false;
    }

    var classification = classifyTargetingAddress(raw);
    status.textContent = classification.message;
    status.classList.add(classification.valid ? 'vms-ma-inline-success' : 'vms-ma-inline-warning');
    return classification.valid;
  }

  function toSiteDateTime(localValue) {
    if (!localValue) {
      return '';
    }
    return String(localValue).replace('T', ' ') + ':00';
  }

  function toLocalDateTime(valueRaw) {
    if (!valueRaw) {
      return '';
    }
    var valueLocal = String(valueRaw).trim().replace(' ', 'T');
    if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(valueLocal)) {
      return valueLocal;
    }
    var dt = new Date(valueRaw);
    if (Number.isNaN(dt.getTime())) {
      return '';
    }
    var y = dt.getFullYear();
    var m = String(dt.getMonth() + 1).padStart(2, '0');
    var d = String(dt.getDate()).padStart(2, '0');
    var h = String(dt.getHours()).padStart(2, '0');
    var min = String(dt.getMinutes()).padStart(2, '0');
    return y + '-' + m + '-' + d + 'T' + h + ':' + min;
  }

  function parseDateInput(input) {
    if (!input) {
      return null;
    }
    var dt = new Date(input);
    return Number.isNaN(dt.getTime()) ? null : dt;
  }

  function toDisplayDate(dt) {
    if (!dt || Number.isNaN(dt.getTime())) {
      return '';
    }
    return dt.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: 'numeric',
      minute: '2-digit'
    });
  }

  function getRuntimeMs(start, end) {
    if (!start || !end || Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
      return 0;
    }
    return Math.max(0, end.getTime() - start.getTime());
  }

  function runtimeDays(ms) {
    if (!ms) {
      return 0;
    }
    return ms / (24 * 60 * 60 * 1000);
  }

  function formatApproxDays(ms) {
    var days = runtimeDays(ms);
    if (!days) {
      return '0';
    }
    if (days >= 1) {
      return days.toFixed(1).replace(/\.0$/, '');
    }
    return '< 1';
  }

  function formatRunTime(ms) {
    if (!ms) {
      return '0h';
    }
    var totalMinutes = Math.max(1, Math.round(ms / 60000));
    var days = Math.floor(totalMinutes / 1440);
    var hours = Math.floor((totalMinutes % 1440) / 60);
    var minutes = totalMinutes % 60;
    var parts = [];
    if (days > 0) {
      parts.push(days + 'd');
    }
    if (hours > 0) {
      parts.push(hours + 'h');
    }
    if (!days && !hours) {
      parts.push(Math.max(1, minutes) + 'm');
    }
    return parts.join(' ');
  }

  function formatBudgetPerDay(budgetMinor, ms) {
    var days = runtimeDays(ms);
    if (!budgetMinor || days <= 0) {
      return '$0.00';
    }
    return '$' + ((budgetMinor / 100) / days).toFixed(2);
  }


  function getCurrentRunWindowMs() {
    var tiers = buildTierSchedule();
    if (!tiers.length) {
      return 0;
    }
    return getRuntimeMs(tiers[0].start, tiers[tiers.length - 1].end);
  }

  function getRecipeBudgetAssessment() {
    var rows = getRecipeRows();
    var runWindowMs = getCurrentRunWindowMs();
    var days = runtimeDays(runWindowMs);
    var floorMinorPerDay = 100;
    var totalBudgetMinor = getRecipeTotalBudgetMinor();
    var allocation = getRecipeAllocationState(rows);
    if (!rows.length || days <= 0) {
      return {
        hasRecipe: false,
        ok: true,
        rows: [],
        totalBudgetMinor: totalBudgetMinor,
        minimumTotalMinor: 0,
        floorMinorPerDay: floorMinorPerDay,
        days: days,
        weakestRow: null,
        zeroBudgetRows: [],
        floorBlockedRows: [],
        enabledCount: allocation.enabledCount,
        allocation: allocation
      };
    }

    var minimumTotalMinor = 0;
    var weakestRow = null;
    var zeroBudgetRows = [];
    var floorBlockedRows = [];
    var assessedRows = rows.map(function (row) {
      if (!row.enabled) {
        return {
          key: row.key,
          label: row.label,
          enabled: false,
          percent: normalizeRecipePercentValue(row.percent),
          budgetMinor: Math.max(0, parseIntSafe(row.budgetMinor, 0)),
          avgMinorPerDay: 0,
          minimumAdsetMinor: 0,
          requiredTotalMinor: 0,
          statusKey: 'disabled',
          statusLabel: 'Excluded',
          note: 'Excluded. This ad set will not be created in Meta or counted in budget math, validation, or review.'
        };
      }
      var percent = Math.max(0, parseFloatSafe(row.percent, 0));
      var budgetMinor = parseIntSafe(row.budgetMinor, 0);
      var minimumAdsetMinor = Math.ceil(days * floorMinorPerDay);
      if (budgetMinor < 1) {
        var emptyAssessed = {
          key: row.key,
          label: row.label,
          enabled: true,
          percent: percent,
          budgetMinor: 0,
          avgMinorPerDay: 0,
          minimumAdsetMinor: minimumAdsetMinor,
          requiredTotalMinor: 0,
          statusKey: 'blocked',
          statusLabel: 'No budget assigned',
          note: 'Included ad sets need a budget before Meta can create them paused. Enter a budget or exclude the row.'
        };
        zeroBudgetRows.push(emptyAssessed);
        return emptyAssessed;
      }
      var avgMinorPerDay = days > 0 ? (budgetMinor / days) : 0;
      var requiredTotalForRow = percent > 0 ? Math.ceil((minimumAdsetMinor * 100) / percent) : 0;
      minimumTotalMinor = Math.max(minimumTotalMinor, requiredTotalForRow);

      var statusKey = 'comfortable';
      var statusLabel = 'Comfortable';
      var note = 'Healthy cushion for testing.';
      if (avgMinorPerDay < floorMinorPerDay) {
        statusKey = 'blocked';
        statusLabel = 'Below minimum';
        note = 'Increase this ad-set budget, shorten the run, or exclude it.';
      } else if (avgMinorPerDay < floorMinorPerDay * 1.5) {
        statusKey = 'thin';
        statusLabel = 'Thin';
        note = 'Allowed, but little learning room.';
      } else if (avgMinorPerDay < floorMinorPerDay * 3) {
        statusKey = 'workable';
        statusLabel = 'Workable';
        note = 'Meets the floor.';
      }

      var assessed = {
        key: row.key,
        label: row.label,
        enabled: true,
        percent: percent,
        budgetMinor: budgetMinor,
        avgMinorPerDay: avgMinorPerDay,
        minimumAdsetMinor: minimumAdsetMinor,
        requiredTotalMinor: requiredTotalForRow,
        statusKey: statusKey,
        statusLabel: statusLabel,
        note: note
      };
      if (statusKey === 'blocked') {
        floorBlockedRows.push(assessed);
        if (!weakestRow || avgMinorPerDay < weakestRow.avgMinorPerDay) {
          weakestRow = assessed;
        }
      }
      return assessed;
    });

    // Round the helper target up to the next whole dollar so the one-click fix is easy to read.
    minimumTotalMinor = Math.ceil(minimumTotalMinor / 100) * 100;

    return {
      hasRecipe: true,
      ok: !weakestRow && !zeroBudgetRows.length,
      rows: assessedRows,
      totalBudgetMinor: totalBudgetMinor,
      minimumTotalMinor: minimumTotalMinor,
      floorMinorPerDay: floorMinorPerDay,
      days: days,
      weakestRow: weakestRow,
      zeroBudgetRows: zeroBudgetRows,
      floorBlockedRows: floorBlockedRows,
      enabledCount: allocation.enabledCount,
      allocation: allocation
    };
  }

  function renderBudgetMinimumNote() {
    var note = byId('vms-ma-budget-minimum-note');
    if (!note) {
      return;
    }
    var assessment = getRecipeBudgetAssessment();
    if (!assessment.hasRecipe) {
      note.textContent = 'Minimum for current allocation will appear after the recipe and schedule are available.';
      note.classList.remove('is-ok', 'is-warning');
      return;
    }
    if (!assessment.enabledCount) {
      note.textContent = 'Include at least one clean-room ad set to calculate the minimum budget.';
      note.classList.add('is-warning');
      note.classList.remove('is-ok');
      return;
    }
    if (assessment.allocation.zeroBudgetRows.length) {
      note.textContent = getRecipeZeroBudgetBlockerMessage(assessment.allocation.zeroBudgetRows, true);
      note.classList.add('is-warning');
      note.classList.remove('is-ok');
      return;
    }
    if (assessment.allocation.overBudgetMinor > 0) {
      note.textContent = getRecipeOverBudgetMessage(assessment.allocation) + ' Lower the included row budgets or update the campaign total budget.';
      note.classList.add('is-warning');
      note.classList.remove('is-ok');
      return;
    }
    if (!assessment.allocation.exact) {
      note.textContent = 'Allocated ' + formatBudgetMinor(assessment.allocation.allocatedMinor) + ' of ' + formatBudgetMinor(assessment.allocation.totalBudgetMinor) + '. ' + getRecipeAllocationDifferenceLabel(assessment.allocation) + '.';
      note.classList.add('is-warning');
      note.classList.remove('is-ok');
      return;
    }
    if (!assessment.minimumTotalMinor) {
      note.textContent = 'Minimum for current allocation will appear after the recipe and schedule are available.';
      note.classList.remove('is-ok', 'is-warning');
      return;
    }
    var min = formatBudgetMinor(assessment.minimumTotalMinor);
    if (assessment.ok) {
      note.textContent = 'Minimum for current allocation: ' + min + '. Current budget meets all recipe ad-set minimums.';
      note.classList.add('is-ok');
      note.classList.remove('is-warning');
      return;
    }
    note.textContent = 'Minimum for current allocation: ' + min + '. ' + getRecipeFloorMessage();
    note.classList.add('is-warning');
    note.classList.remove('is-ok');
  }

  function buildRecipeBudgetMessagesHtml(assessment) {
    var html = '';
    var hasBudgetWarnings = false;
    if (!assessment.enabledCount) {
      html += '<p class="description vms-ma-inline-warning">All clean-room ad sets are excluded. Include at least one ad set before saving this recipe to Meta.</p>';
      hasBudgetWarnings = true;
    } else {
      if (assessment.allocation.zeroBudgetRows.length) {
        html += '<p class="description vms-ma-inline-warning">' + escapeHtml(getRecipeZeroBudgetBlockerMessage(assessment.allocation.zeroBudgetRows, true)) + '</p>';
        hasBudgetWarnings = true;
      }
      if (assessment.allocation.overBudgetMinor > 0) {
        html += '<p class="description vms-ma-inline-warning">' + escapeHtml(getRecipeOverBudgetMessage(assessment.allocation)) + '</p>';
        html += '<p><button type="button" class="button button-secondary" id="vms-ma-match-budget-total">Update total budget to ' + escapeHtml(formatBudgetMinor(assessment.allocation.allocatedMinor)) + '</button></p>';
        hasBudgetWarnings = true;
      } else if (!assessment.allocation.exact) {
        html += '<p class="description vms-ma-inline-warning">Included ad-set budgets must match the campaign budget before Create Paused can run. ' + escapeHtml(getRecipeAllocationDifferenceLabel(assessment.allocation)) + '.</p>';
        hasBudgetWarnings = true;
      }
      if (assessment.allocation.exact && !assessment.allocation.zeroBudgetRows.length && !assessment.ok) {
        html += '<p class="description vms-ma-inline-warning">' + escapeHtml(getRecipeFloorMessage()) + '</p>';
        hasBudgetWarnings = true;
      }
      if (assessment.allocation.exact && !assessment.allocation.zeroBudgetRows.length && !assessment.ok && assessment.minimumTotalMinor > assessment.totalBudgetMinor) {
        html += '<p><button type="button" class="button button-secondary" id="vms-ma-raise-budget-minimum">Increase budget to ' + escapeHtml(formatBudgetMinor(assessment.minimumTotalMinor)) + '</button></p>';
      }
    }
    if (!hasBudgetWarnings) {
      html += '<p class="description vms-ma-inline-success">Current budget meets the calculated minimum for the current recipe split and run window.</p>';
    }
    return html;
  }

  function bindRecipeBudgetQuickActionButtons(assessment) {
    var raise = byId('vms-ma-raise-budget-minimum');
    if (raise) {
      raise.addEventListener('click', function () {
        var budgetInput = byId('vms-ma-budget-total');
        if (!budgetInput) {
          return;
        }
        budgetInput.value = (assessment.minimumTotalMinor / 100).toFixed(2);
        dispatchFieldEvents(budgetInput);
        emitFeedback('success', 'Budget raised to ' + formatBudgetMinor(assessment.minimumTotalMinor) + ' for the current recipe split.', 'e');
      });
    }
    var matchBudgetBtn = byId('vms-ma-match-budget-total');
    if (matchBudgetBtn) {
      matchBudgetBtn.addEventListener('click', function () {
        var budgetInput = byId('vms-ma-budget-total');
        if (!budgetInput) {
          return;
        }
        budgetInput.value = (assessment.allocation.allocatedMinor / 100).toFixed(2);
        dispatchFieldEvents(budgetInput);
        emitFeedback('success', 'Campaign total budget updated to ' + formatBudgetMinor(assessment.allocation.allocatedMinor) + '.', 'e');
      });
    }
  }

  function refreshRecipeBudgetPreviewInline() {
    var node = byId('vms-ma-recipe-budget-preview');
    if (!node || node.classList.contains('vms-ma-hidden')) {
      return;
    }
    var assessment = getRecipeBudgetAssessment();
    if (!assessment.hasRecipe) {
      return;
    }

    var minimumNode = byId('vms-ma-recipe-minimum-total');
    if (minimumNode) {
      minimumNode.textContent = formatBudgetMinor(assessment.minimumTotalMinor);
    }

    var allocatedNode = byId('vms-ma-recipe-budget-total-allocated');
    if (allocatedNode) {
      allocatedNode.innerHTML = 'Allocated: <strong>' + escapeHtml(formatBudgetMinor(assessment.allocation.allocatedMinor)) + '</strong> of ' + escapeHtml(formatBudgetMinor(assessment.allocation.totalBudgetMinor));
      allocatedNode.classList.toggle('is-valid', assessment.allocation.ok);
      allocatedNode.classList.toggle('is-invalid', !assessment.allocation.ok);
    }

    var differenceNode = byId('vms-ma-recipe-budget-total-difference');
    if (differenceNode) {
      differenceNode.textContent = getRecipeAllocationDifferenceLabel(assessment.allocation);
      var differenceInvalid = assessment.allocation.unallocatedMinor > 0 || assessment.allocation.overBudgetMinor > 0 || assessment.allocation.zeroBudgetRows.length;
      differenceNode.classList.toggle('is-valid', !differenceInvalid);
      differenceNode.classList.toggle('is-invalid', !!differenceInvalid);
    }

    assessment.rows.forEach(function (row) {
      var input = builder.querySelector('[data-recipe-adset-budget="' + escapeRecipeSelectorValue(row.key) + '"]');
      if (!input) {
        return;
      }
      var tableRow = input.closest('tr');
      if (tableRow) {
        tableRow.className = 'vms-ma-recipe-budget-row vms-ma-recipe-budget-row--' + row.statusKey;
      }
      var cells = tableRow ? tableRow.querySelectorAll('td') : [];
      if (cells[3]) {
        cells[3].innerHTML = '<span class="vms-ma-recipe-derived-percent">' + escapeHtml(formatPercent(row.percent)) + '%</span>';
      }
      if (cells[4]) {
        cells[4].textContent = row.enabled ? ('$' + ((row.avgMinorPerDay / 100).toFixed(2))) : 'Excluded';
      }
      if (cells[5]) {
        cells[5].innerHTML = '<span class="vms-ma-budget-health vms-ma-budget-health--' + escapeHtml(row.statusKey) + '">' + escapeHtml(row.statusLabel) + '</span>';
      }
      if (cells[6]) {
        cells[6].textContent = row.note;
      }
    });

    var messagesNode = byId('vms-ma-recipe-budget-messages');
    if (messagesNode) {
      messagesNode.innerHTML = buildRecipeBudgetMessagesHtml(assessment);
      bindRecipeBudgetQuickActionButtons(assessment);
    }
  }

  function renderRecipeBudgetPreview() {
    var node = byId('vms-ma-recipe-budget-preview');
    if (!node) {
      return;
    }
    var activeBudgetInputState = captureRecipeBudgetInputState();
    var assessment = getRecipeBudgetAssessment();
    if (!assessment.hasRecipe) {
      node.innerHTML = '';
      node.classList.add('vms-ma-hidden');
      return;
    }

    var html = '<div class="vms-ma-recipe-budget-card">' +
      '<div class="vms-ma-recipe-budget-head">' +
        '<div><h3>Budget allocation preview</h3><p class="description">Enter dollar budgets for each included ad set. Included rows become paused Meta ad sets if create succeeds; excluded rows are omitted. Percentages are derived from the campaign total budget.</p></div>' +
        '<div class="vms-ma-recipe-budget-minimum">Minimum for current split: <strong id="vms-ma-recipe-minimum-total">' + escapeHtml(formatBudgetMinor(assessment.minimumTotalMinor)) + '</strong></div>' +
      '</div>' +
      '<div class="vms-ma-recipe-budget-controls">' +
        '<div class="vms-ma-recipe-budget-total ' + (assessment.allocation.ok ? 'is-valid' : 'is-invalid') + '" id="vms-ma-recipe-budget-total-allocated">Allocated: <strong>' + escapeHtml(formatBudgetMinor(assessment.allocation.allocatedMinor)) + '</strong> of ' + escapeHtml(formatBudgetMinor(assessment.allocation.totalBudgetMinor)) + '</div>' +
        '<div class="vms-ma-recipe-budget-total ' + ((assessment.allocation.unallocatedMinor > 0 || assessment.allocation.overBudgetMinor > 0 || assessment.allocation.zeroBudgetRows.length) ? 'is-invalid' : 'is-valid') + '" id="vms-ma-recipe-budget-total-difference">' + escapeHtml(getRecipeAllocationDifferenceLabel(assessment.allocation)) + '</div>' +
        '<div class="vms-ma-inline-actions">' +
          '<button type="button" class="button button-secondary" id="vms-ma-recipe-normalize">Distribute included budget evenly</button>' +
          '<button type="button" class="button vms-ma-button-ghost" id="vms-ma-recipe-reset">Reset to recommended split</button>' +
        '</div>' +
      '</div>' +
      '<table class="widefat striped"><thead><tr><th>Include</th><th>Ad set</th><th>Budget</th><th>Allocation</th><th>Avg/day</th><th>Status</th><th>Note</th></tr></thead><tbody>';
    assessment.rows.forEach(function (row) {
      html += '<tr class="vms-ma-recipe-budget-row vms-ma-recipe-budget-row--' + escapeHtml(row.statusKey) + '" data-recipe-budget-row="' + escapeAttribute(row.key) + '">' +
        '<td><label class="vms-ma-recipe-toggle"><input type="checkbox" data-recipe-adset-enabled="' + escapeAttribute(row.key) + '"' + (row.enabled ? ' checked' : '') + ' /> <span>' + escapeHtml(row.enabled ? 'Included' : 'Excluded') + '</span></label></td>' +
        '<td><strong>' + escapeHtml(row.label) + '</strong></td>' +
        '<td><label class="vms-ma-recipe-budget-field"><span>$</span><input type="text" inputmode="decimal" autocomplete="off" data-recipe-adset-budget="' + escapeAttribute(row.key) + '" value="' + escapeAttribute(formatBudgetInputMinor(row.budgetMinor)) + '"' + (row.enabled ? '' : ' disabled') + ' /></label></td>' +
        '<td><span class="vms-ma-recipe-derived-percent">' + escapeHtml(formatPercent(row.percent)) + '%</span></td>' +
        '<td>' + (row.enabled ? ('$' + escapeHtml((row.avgMinorPerDay / 100).toFixed(2))) : 'Excluded') + '</td>' +
        '<td><span class="vms-ma-budget-health vms-ma-budget-health--' + escapeHtml(row.statusKey) + '">' + escapeHtml(row.statusLabel) + '</span></td>' +
        '<td>' + escapeHtml(row.note) + '</td>' +
      '</tr>';
    });
    html += '</tbody></table>';
    html += '<div id="vms-ma-recipe-budget-messages">' + buildRecipeBudgetMessagesHtml(assessment) + '</div>';
    html += '</div>';

    node.innerHTML = html;
    node.classList.remove('vms-ma-hidden');
    bindRecipeBudgetQuickActionButtons(assessment);
    var normalizeBtn = byId('vms-ma-recipe-normalize');
    if (normalizeBtn) {
      normalizeBtn.addEventListener('click', function () {
        var rows = getRecipeRows().filter(function (row) { return row.enabled; });
        if (!rows.length) {
          emitFeedback('warning', 'Include at least one ad set before distributing budget.', 'e');
          return;
        }
        var allocation = allocateRecipeBudgetMinor(getRecipeTotalBudgetMinor(), rows, function () {
          return 1;
        });
        rows.forEach(function (row, index) {
          setRecipeAdsetBudgetMinor(row.key, allocation[row.key] || 0);
        });
        syncDerivedState({ forceAgeClamp: false });
        updateDirtyState();
        emitFeedback('success', 'Included ad-set budgets distributed across the full campaign total.', 'e');
      });
    }
    var resetBtn = byId('vms-ma-recipe-reset');
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        var rows = getBaseRecipeRows();
        if (!rows.length) {
          return;
        }
        var totalBudgetMinor = getRecipeTotalBudgetMinor();
        var recommendedBudgets = allocateRecipeBudgetMinor(totalBudgetMinor, rows, function (row) {
          return row.recommendedPercent;
        });
        var nextState = {};
        rows.forEach(function (row) {
          nextState[row.key] = {
            enabled: true,
            budgetMinor: recommendedBudgets[row.key] || 0,
            percent: normalizeRecipePercentValue(row.recommendedPercent)
          };
        });
        replaceRecipeAdsetState(nextState);
        syncDerivedState({ forceAgeClamp: false });
        updateDirtyState();
        emitFeedback('success', 'Recipe budgets reset to the recommended default split.', 'e');
      });
    }
    restoreRecipeBudgetInputState(activeBudgetInputState);
  }

  function setInlineWarning(message) {
    var warning = byId('vms-ma-event-picker-warning');
    if (!warning) {
      return;
    }
    if (!message) {
      warning.classList.add('vms-ma-hidden');
      warning.textContent = '';
      return;
    }
    warning.textContent = message;
    warning.classList.remove('vms-ma-hidden');
  }


  function getBudgetFloorAssessment() {
    var tiers = buildTierSchedule();
    var floorMinorPerDay = 100;
    if (!tiers.length) {
      return {
        ok: true,
        message: '',
        tierKey: '',
        tierLabel: '',
        avgPerDay: 0,
        floorMinorPerDay: floorMinorPerDay
      };
    }

    for (var i = 0; i < tiers.length; i += 1) {
      var tier = tiers[i] || {};
      var runtimeMs = getRuntimeMs(tier.start, tier.end);
      var days = runtimeDays(runtimeMs);
      var budgetMinor = parseIntSafe(tier.budgetMinor, 0);
      if (days <= 0 || budgetMinor <= 0) {
        continue;
      }
      var avgMinorPerDay = budgetMinor / days;
      if (avgMinorPerDay < floorMinorPerDay) {
        return {
          ok: false,
          message: 'Budget is likely too low for this schedule. Meta often rejects ad sets below about $1.00/day. Increase budget or shorten the run window.',
          tierKey: String(tier.key || ''),
          tierLabel: String(tier.label || 'Current window'),
          avgPerDay: avgMinorPerDay / 100,
          floorMinorPerDay: floorMinorPerDay
        };
      }
    }

    var recipeAssessment = getRecipeBudgetAssessment();
    if (recipeAssessment.hasRecipe && recipeAssessment.enabledCount > 0 && recipeAssessment.allocation.exact && !recipeAssessment.zeroBudgetRows.length && !recipeAssessment.ok) {
      var weak = recipeAssessment.weakestRow || {};
      return {
        ok: false,
        message: getRecipeFloorMessage(),
        tierKey: String(weak.key || ''),
        tierLabel: String(weak.label || 'Recipe ad set'),
        avgPerDay: parseFloatSafe(weak.avgMinorPerDay, 0) / 100,
        floorMinorPerDay: floorMinorPerDay
      };
    }

    return {
      ok: true,
      message: '',
      tierKey: '',
      tierLabel: '',
      avgPerDay: 0,
      floorMinorPerDay: floorMinorPerDay
    };
  }

  function renderBudgetFloorWarning() {
    var warning = byId('vms-ma-budget-floor-warning');
    if (!warning) {
      return;
    }
    var assessment = getBudgetFloorAssessment();
    if (assessment.ok) {
      warning.classList.add('vms-ma-hidden');
      warning.textContent = '';
      return;
    }
    var tierPrefix = assessment.tierLabel ? (assessment.tierLabel + ': ') : '';
    warning.textContent = tierPrefix + assessment.message + (assessment.avgPerDay > 0 ? (' Current average is about $' + assessment.avgPerDay.toFixed(2) + '/day.') : '');
    warning.classList.remove('vms-ma-hidden');
  }

  function ensureBudgetFloorForMetaAction(actionLabel) {
    var assessment = getBudgetFloorAssessment();
    if (assessment.ok) {
      return true;
    }
    var prefix = actionLabel ? (actionLabel + ' blocked. ') : '';
    var message = prefix + assessment.message;
    emitFeedback('warning', message, 'e');
    setMetaInline(message);
    return false;
  }

  function ensureEventSelectionState() {
    var eventPlanId = parseIntSafe(value('vms-ma-event-plan-id'), 0);
    if (!eventPlanId) {
      setInlineWarning('Choose an Event Plan first. This fills the rest automatically.');
      return false;
    }
    setInlineWarning('');
    return true;
  }

  function getRampWeights() {
    var w30 = parseIntSafe(value('vms-ma-weight_30'), 30);
    var w14 = parseIntSafe(value('vms-ma-weight_14'), 30);
    var w7 = parseIntSafe(value('vms-ma-weight_7'), 40);
    var total = w30 + w14 + w7;
    if (total !== 100) {
      return null;
    }
    return { d30: w30, d14: w14, d7: w7 };
  }

  function normalizeScheduleWindows(preset, eventStart, now, endDate) {
    if (preset === 'video_tribute_push') {
      return [
        {
          key: 'v30',
          label: 'Early video/main awareness',
          start: new Date(Math.max(now.getTime(), eventStart.getTime() - (30 * 24 * 60 * 60 * 1000))),
          end: new Date(eventStart.getTime() - (15 * 24 * 60 * 60 * 1000)),
          weight: 20
        },
        {
          key: 'v14',
          label: 'Mid-campaign momentum',
          start: new Date(Math.max(now.getTime(), eventStart.getTime() - (14 * 24 * 60 * 60 * 1000))),
          end: new Date(eventStart.getTime() - (8 * 24 * 60 * 60 * 1000)),
          weight: 30
        },
        {
          key: 'v7',
          label: 'Final-week video push',
          start: new Date(Math.max(now.getTime(), eventStart.getTime() - (7 * 24 * 60 * 60 * 1000))),
          end: new Date(Math.min(endDate.getTime(), eventStart.getTime() - (2 * 24 * 60 * 60 * 1000))),
          weight: 30
        },
        {
          key: 'v48',
          label: 'Last 48 hours',
          start: new Date(Math.max(now.getTime(), eventStart.getTime() - (2 * 24 * 60 * 60 * 1000))),
          end: endDate,
          weight: 20
        }
      ].filter(function (tier) {
        return tier.end.getTime() > now.getTime() && tier.end.getTime() > tier.start.getTime();
      });
    }
    if (preset === 'simple_7_day') {
      return [{ key: 'simple_7', label: 'Simple 7 day', start: new Date(Math.max(now.getTime(), eventStart.getTime() - 7 * 24 * 60 * 60 * 1000)), end: endDate, weight: 100 }];
    }
    if (preset === 'simple_14_day') {
      return [{ key: 'simple_14', label: 'Simple 14 day', start: new Date(Math.max(now.getTime(), eventStart.getTime() - 14 * 24 * 60 * 60 * 1000)), end: endDate, weight: 100 }];
    }
    if (preset === 'simple_30_day') {
      return [{ key: 'simple_30', label: 'Simple 30 day', start: new Date(Math.max(now.getTime(), eventStart.getTime() - 30 * 24 * 60 * 60 * 1000)), end: endDate, weight: 100 }];
    }
    if (preset === 'flat_run') {
      return [{ key: 'flat_run', label: 'Flat run', start: now, end: endDate, weight: 100 }];
    }

    var weights = getRampWeights();
    if (!weights) {
      emitFeedback('error', 'Custom 30/14/7 weights must add up to 100%.', 'b');
      return [];
    }

    return [
      {
        key: 'd30',
        label: '30 day',
        start: new Date(Math.max(now.getTime(), eventStart.getTime() - (30 * 24 * 60 * 60 * 1000))),
        end: new Date(eventStart.getTime() - (15 * 24 * 60 * 60 * 1000)),
        weight: weights.d30
      },
      {
        key: 'd14',
        label: '14 day',
        start: new Date(Math.max(now.getTime(), eventStart.getTime() - (14 * 24 * 60 * 60 * 1000))),
        end: new Date(eventStart.getTime() - (8 * 24 * 60 * 60 * 1000)),
        weight: weights.d14
      },
      {
        key: 'd7',
        label: '7 day',
        start: new Date(Math.max(now.getTime(), eventStart.getTime() - (7 * 24 * 60 * 60 * 1000))),
        end: endDate,
        weight: weights.d7
      }
    ].filter(function (tier) {
      return tier.end.getTime() > now.getTime();
    });
  }

  function buildTierSchedule() {
    var preset = value('vms-ma-preset-mode') || 'flat_run';
    var eventStart = parseDateInput(value('vms-ma-event-start'));
    var totalBudgetMinor = Math.round(parseFloatSafe(value('vms-ma-budget-total'), 0) * 100);
    if (!eventStart || totalBudgetMinor < 1) {
      return [];
    }

    var now = new Date();

    if (preset === 'manual_dates') {
      var manualStart = parseDateInput(value('vms-ma-manual-start'));
      var manualEnd = parseDateInput(value('vms-ma-manual-end'));
      if (!manualStart || !manualEnd || manualEnd.getTime() <= manualStart.getTime()) {
        return [];
      }
      return [{
        key: 'manual',
        label: 'Manual window',
        start: manualStart,
        end: manualEnd,
        budgetMinor: totalBudgetMinor,
        weight: 100
      }];
    }

    var endBuffer = Math.max(0, parseIntSafe(value('vms-ma-end_buffer_hours'), 2));
    var endDate = new Date(eventStart.getTime() - (endBuffer * 60 * 60 * 1000));
    if (endDate.getTime() <= now.getTime()) {
      return [];
    }

    var tiers = normalizeScheduleWindows(preset, eventStart, now, endDate);
    if (!tiers.length) {
      return [];
    }

    var totalWeight = tiers.reduce(function (sum, tier) {
      return sum + (tier.weight || 0);
    }, 0);
    if (totalWeight < 1) {
      return [];
    }

    var remaining = totalBudgetMinor;
    tiers.forEach(function (tier, idx) {
      var alloc = idx === tiers.length - 1
        ? remaining
        : Math.floor(totalBudgetMinor * ((tier.weight || 0) / totalWeight));
      tier.budgetMinor = alloc;
      remaining -= alloc;
      if (tier.end.getTime() > endDate.getTime()) {
        tier.end = new Date(endDate.getTime());
      }
    });

    return tiers;
  }

  function getCopySeed(eventItem) {
    var eventName = (eventItem && eventItem.title) || value('vms-ma-event-name') || 'Live Music';
    var venueName = (eventItem && eventItem.venue_name) || value('vms-ma-venue-name') || 'the venue';
    var startInput = (eventItem && (eventItem.start_input || eventItem.start_local)) || value('vms-ma-event-start');
    var eventDate = parseDateInput(toLocalDateTime(startInput)) || parseDateInput(value('vms-ma-event-start'));

    var dow = eventDate ? eventDate.toLocaleDateString(undefined, { weekday: 'short' }) : 'Soon';
    var mon = eventDate ? eventDate.toLocaleDateString(undefined, { month: 'short' }) : '';
    var day = eventDate ? eventDate.toLocaleDateString(undefined, { day: 'numeric' }) : '';
    var time = eventDate ? eventDate.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }) : '';

    return {
      primary: 'Live music at ' + venueName + ' on ' + dow + ', ' + mon + ' ' + day + '. ' + eventName + '. Get tickets now.',
      headline: eventName,
      description: venueName + ' | ' + time
    };
  }

  function applyDefaultCopyFromEvent(eventItem, force, options) {
    var primaryEl = byId('vms-ma-primary-text');
    var headlineEl = byId('vms-ma-headline');
    var descriptionEl = byId('vms-ma-description');
    if (!primaryEl || !headlineEl || !descriptionEl) {
      return;
    }

    var seed = getCopySeed(eventItem || lastEventContext || null);
    var silent = !!(options && options.silent);
    if (force || !String(primaryEl.value || '').trim()) {
      primaryEl.value = seed.primary;
      if (!silent) {
        dispatchFieldEvents(primaryEl);
      }
    }
    if (force || !String(headlineEl.value || '').trim()) {
      headlineEl.value = seed.headline;
      if (!silent) {
        dispatchFieldEvents(headlineEl);
      }
    }
    if (force || !String(descriptionEl.value || '').trim()) {
      descriptionEl.value = seed.description;
      if (!silent) {
        dispatchFieldEvents(descriptionEl);
      }
    }
  }

  function clearVariantOverridesPreservingPrimaryCopy(options) {
    var silent = !!(options && options.silent);
    setField('vms-ma-variant-1-media-mode', 'shared', { silent: silent });
    setField('vms-ma-variant-1-placement-slot', 'auto', { silent: silent });
    setField('vms-ma-variant-1-image-id', 0, { silent: silent });
    setField('vms-ma-variant-1-video-id', 0, { silent: silent });
    syncVariantMediaUi(1);
    syncVariantMediaPreview(1, 'image', { silent: silent });
    syncVariantMediaPreview(1, 'video', { silent: silent });

    [2, 3].forEach(function (index) {
      setField('vms-ma-variant-' + index + '-label', 'Variant ' + index, { silent: silent });
      setField('vms-ma-variant-' + index + '-primary', '', { silent: silent });
      setField('vms-ma-variant-' + index + '-headline', '', { silent: silent });
      setField('vms-ma-variant-' + index + '-description', '', { silent: silent });
      setField('vms-ma-variant-' + index + '-media-mode', 'shared', { silent: silent });
      setField('vms-ma-variant-' + index + '-placement-slot', 'auto', { silent: silent });
      setField('vms-ma-variant-' + index + '-image-id', 0, { silent: silent });
      setField('vms-ma-variant-' + index + '-video-id', 0, { silent: silent });
      syncVariantMediaUi(index);
      syncVariantMediaPreview(index, 'image', { silent: silent });
      syncVariantMediaPreview(index, 'video', { silent: silent });
    });
  }

  function clearEventScopedCreativeFields(options) {
    var silent = !!(options && options.silent);
    setActiveBuildId('');
    setField('vms-ma-post-id', '', { silent: silent });
    setField('vms-ma-fb-event-id', '', { silent: silent });
    setImageSelection('square', 0, '', { silent: silent });
    setImageSelection('vertical', 0, '', { silent: silent });
    setImageSelection('wide', 0, '', { silent: silent });
    clearVariantOverridesPreservingPrimaryCopy({ silent: silent });
    applyDefaultCopyFromEvent(lastEventContext || null, true, { silent: silent });
  }

  function renderTierPreview() {
    var table = byId('vms-ma-tier-table');
    var summary = byId('vms-ma-budget-summary');
    var schedStart = byId('vms-ma-sched-start');
    var schedEnd = byId('vms-ma-sched-end');
    if (!table || !summary || !schedStart || !schedEnd) {
      return;
    }

    var tiers = buildTierSchedule();
    if (!tiers.length) {
      schedStart.value = '';
      schedEnd.value = '';
      summary.innerHTML = '<p class="description">Set event start and budget to see run length and average daily spend.</p>';
      table.innerHTML = '<p class="description">Set event start and budget to preview schedule.</p>';
      renderBudgetMinimumNote();
      renderRecipeBudgetPreview();
      return;
    }

    schedStart.value = toDisplayDate(tiers[0].start);
    schedEnd.value = toDisplayDate(tiers[tiers.length - 1].end);

    var totalBudgetMinor = tiers.reduce(function (sum, tier) {
      return sum + parseIntSafe(tier.budgetMinor, 0);
    }, 0);
    var totalRuntimeMs = getRuntimeMs(tiers[0].start, tiers[tiers.length - 1].end);

    summary.innerHTML = [
      '<div class="vms-ma-budget-summary-grid">',
        '<div class="vms-ma-budget-stat"><span>Run time</span><strong>' + escapeHtml(formatRunTime(totalRuntimeMs)) + '</strong></div>',
        '<div class="vms-ma-budget-stat"><span>Approx. days</span><strong>' + escapeHtml(formatApproxDays(totalRuntimeMs)) + '</strong></div>',
        '<div class="vms-ma-budget-stat"><span>Avg/day</span><strong>' + escapeHtml(formatBudgetPerDay(totalBudgetMinor, totalRuntimeMs)) + '</strong></div>',
      '</div>'
    ].join('');

    var html = '<table class="widefat striped"><thead><tr><th>Tier</th><th>Start</th><th>End</th><th>Run time</th><th>Budget</th><th>Avg/day</th></tr></thead><tbody>';
    tiers.forEach(function (tier) {
      var tierRuntimeMs = getRuntimeMs(tier.start, tier.end);
      html += '<tr><td>' + escapeHtml(tier.label) + '</td><td>' + escapeHtml(toDisplayDate(tier.start)) + '</td><td>' + escapeHtml(toDisplayDate(tier.end)) + '</td><td>' + escapeHtml(formatRunTime(tierRuntimeMs)) + '</td><td>$' + (tier.budgetMinor / 100).toFixed(2) + '</td><td>' + escapeHtml(formatBudgetPerDay(tier.budgetMinor, tierRuntimeMs)) + '</td></tr>';
    });
    html += '</tbody></table>';
    table.innerHTML = html;
    renderBudgetMinimumNote();
    renderRecipeBudgetPreview();
  }

  function syncCreativeFields() {
    var mode = (document.querySelector('input[name="vms_ma_creative_mode"]:checked') || {}).value || 'dark_post';
    builder.querySelectorAll('.vms-ma-creative-fields[data-mode]').forEach(function (group) {
      group.style.display = group.getAttribute('data-mode') === mode ? '' : 'none';
    });
  }

  function syncGoalOptimizationVisibility() {
    var wrap = byId('vms-ma-optimization-wrap');
    var help = byId('vms-ma-optimization-help');
    var salesCard = byId('vms-ma-sales-goal-card');
    var salesWarning = byId('vms-ma-sales-goal-warning');
    var goal = value('vms-ma-goal') || 'traffic';
    var optimization = byId('vms-ma-optimization');
    if (wrap) {
      wrap.classList.toggle('vms-ma-hidden', goal !== 'traffic' && goal !== 'sales');
    }
    if (goal === 'sales') {
      if (optimization && optimization.value !== 'purchase_conversions') {
        // Do not use setField() here. syncGoalOptimizationVisibility() is called from
        // the global input/change handlers, and dispatching another field event from
        // this sync routine can recurse until the browser reports the page as
        // unresponsive.
        optimization.value = 'purchase_conversions';
      }
      if (optimization) {
        Array.prototype.forEach.call(optimization.options || [], function (option) {
          option.disabled = option.value !== 'purchase_conversions';
        });
      }
      if (help) {
        help.textContent = 'Sales uses the saved Meta Pixel/Dataset ID and the Purchase conversion event.';
      }
      if (salesCard) {
        salesCard.classList.remove('vms-ma-hidden');
      }
      if (salesWarning) {
        var hasPixel = !!String((window.VMS_MA && VMS_MA.metaPixelId) || '').trim();
        salesWarning.textContent = hasPixel ? '' : 'Set the Meta Pixel / Dataset ID in MAB Settings before creating a Sales campaign in Meta.';
        salesWarning.classList.toggle('vms-ma-hidden', hasPixel);
      }
    } else {
      if (optimization) {
        Array.prototype.forEach.call(optimization.options || [], function (option) {
          option.disabled = false;
        });
        if (optimization.value === 'purchase_conversions') {
          optimization.value = 'landing_page_views';
        }
      }
      if (help) {
        help.textContent = goal === 'traffic' ? 'Traffic is the goal. Landing page views is usually better than raw link clicks when available.' : 'This goal does not use traffic optimization controls.';
      }
      if (salesCard) {
        salesCard.classList.add('vms-ma-hidden');
      }
    }
  }

  function updateApiAssistVisibility() {
    var apiReady = !!parseIntSafe(VMS_MA.apiReady, 0);
    var postPickerWrap = byId('vms-ma-post-picker-wrap');
    var postUrlWrap = byId('vms-ma-post-url-wrap');
    var eventPickerWrap = byId('vms-ma-fb-event-picker-wrap');
    var eventUrlWrap = byId('vms-ma-fb-event-url-wrap');
    if (postPickerWrap) {
      postPickerWrap.classList.toggle('vms-ma-hidden', !apiReady);
    }
    if (postUrlWrap) {
      postUrlWrap.classList.toggle('vms-ma-hidden', apiReady);
    }
    if (eventPickerWrap) {
      eventPickerWrap.classList.toggle('vms-ma-hidden', !apiReady);
    }
    if (eventUrlWrap) {
      eventUrlWrap.classList.toggle('vms-ma-hidden', apiReady);
    }
  }

  function clampAudienceInputs(forceAgeClamp) {
    var maxRadius = Math.max(1, parseIntSafe(VMS_MA.maxRadiusMiles, 100));
    var radiusEl = byId('vms-ma-radius');
    var radiusWarn = byId('vms-ma-radius-warning');
    if (radiusEl) {
      var radius = parseIntSafe(radiusEl.value, 15);
      radius = Math.max(1, Math.min(maxRadius, radius));
      radiusEl.value = String(radius);
      if (radiusWarn) {
        if (radius === maxRadius) {
          radiusWarn.textContent = 'Meta may clamp radius depending on targeting. VMS limited this to ' + maxRadius + ' miles.';
          radiusWarn.classList.remove('vms-ma-hidden');
        } else {
          radiusWarn.textContent = '';
          radiusWarn.classList.add('vms-ma-hidden');
        }
      }
    }

    if (!forceAgeClamp) {
      return;
    }

    var ageMinEl = byId('vms-ma-age-min');
    var ageMaxEl = byId('vms-ma-age-max');
    if (ageMinEl && ageMaxEl) {
      var rawMin = String(ageMinEl.value || '').trim();
      var min = Math.max(13, parseIntSafe(rawMin, 21));
      var max = Math.max(min, parseIntSafe(ageMaxEl.value, 65));
      ageMinEl.value = String(min);
      ageMaxEl.value = String(max);
    }
  }

  function buildDestinationUtm(urlRaw, eventTitle) {
    var raw = String(urlRaw || '').trim();
    if (!raw) {
      return '';
    }
    try {
      var url = new URL(raw);
      url.searchParams.set('utm_source', 'meta');
      url.searchParams.set('utm_medium', 'paid_social');
      url.searchParams.set('utm_campaign', String(eventTitle || 'event').toLowerCase().replace(/[^a-z0-9]+/g, '_'));
      return url.toString();
    } catch (e) {
      return raw;
    }
  }

  function isPackReady() {
    if (!value('vms-ma-event-plan-id')) {
      return false;
    }
    if (!value('vms-ma-event-start')) {
      return false;
    }
    if (!value('vms-ma-destination-url')) {
      return false;
    }
    return buildTierSchedule().length > 0;
  }


  function collectAdVariants() {
    var variants = [];
    var firstMode = normalizeVariantMediaMode(value('vms-ma-variant-1-media-mode') || 'shared');
    variants.push({
      variant_key: 'v1',
      label: 'Variant 1',
      primary_text: value('vms-ma-primary-text'),
      headline: value('vms-ma-headline'),
      description: value('vms-ma-description'),
      media_mode: firstMode,
      placement_slot: normalizeVariantPlacementSlot(value('vms-ma-variant-1-placement-slot') || 'auto'),
      media_image_id: firstMode === 'image' ? parseIntSafe(value('vms-ma-variant-1-image-id'), 0) : 0,
      media_video_id: firstMode === 'video' ? parseIntSafe(value('vms-ma-variant-1-video-id'), 0) : 0
    });

    [2, 3].forEach(function (index) {
      var label = value('vms-ma-variant-' + index + '-label') || ('Variant ' + index);
      var primary = value('vms-ma-variant-' + index + '-primary');
      var headline = value('vms-ma-variant-' + index + '-headline');
      var description = value('vms-ma-variant-' + index + '-description');
        var mediaMode = normalizeVariantMediaMode(value('vms-ma-variant-' + index + '-media-mode') || 'shared');
      var mediaImageId = parseIntSafe(value('vms-ma-variant-' + index + '-image-id'), 0);
      var mediaVideoId = parseIntSafe(value('vms-ma-variant-' + index + '-video-id'), 0);
      var hasText = !!(String(primary || '').trim() || String(headline || '').trim() || String(description || '').trim());
      var hasMediaOverride = (mediaMode === 'image' && mediaImageId > 0) || (mediaMode === 'video' && mediaVideoId > 0) || mediaMode === 'video_placeholder';
      if (!hasText && !hasMediaOverride) {
        return;
      }
      variants.push({
        variant_key: 'v' + index,
        label: label,
        primary_text: primary,
        headline: headline,
        description: description,
        media_mode: mediaMode,
        placement_slot: normalizeVariantPlacementSlot(value('vms-ma-variant-' + index + '-placement-slot') || 'auto'),
        media_image_id: mediaMode === 'image' ? mediaImageId : 0,
        media_video_id: mediaMode === 'video' ? mediaVideoId : 0
      });
    });

    var deduped = [];
    var seen = {};
    variants.forEach(function (variant, index) {
      var normalized = {
        variant_key: String(variant.variant_key || ('v' + (index + 1))),
        label: String(variant.label || ('Variant ' + (index + 1))),
        primary_text: String(variant.primary_text || ''),
        headline: String(variant.headline || ''),
        description: String(variant.description || ''),
        media_mode: normalizeVariantMediaMode(variant.media_mode || 'shared'),
        placement_slot: normalizeVariantPlacementSlot(variant.placement_slot || 'auto'),
        media_image_id: normalizeVariantMediaMode(variant.media_mode || 'shared') === 'image' ? parseIntSafe(variant.media_image_id, 0) : 0,
        media_video_id: normalizeVariantMediaMode(variant.media_mode || 'shared') === 'video' ? parseIntSafe(variant.media_video_id, 0) : 0
      };
      var signature = [normalized.primary_text, normalized.headline, normalized.description, normalized.media_mode, normalized.placement_slot, normalized.media_image_id, normalized.media_video_id].join('||');
      if (index > 0 && signature && seen[signature]) {
        return;
      }
      seen[signature] = true;
      deduped.push(normalized);
    });
    return deduped;
  }

  function applyAdVariants(variants) {
    var list = Array.isArray(variants) ? variants : [];
    var first = list[0] || {};
    setField('vms-ma-primary-text', first.primary_text || '');
    setField('vms-ma-headline', first.headline || '');
    setField('vms-ma-description', first.description || '');
    setField('vms-ma-variant-1-media-mode', first.media_mode || 'shared');
    setField('vms-ma-variant-1-placement-slot', first.placement_slot || 'auto');
    setField('vms-ma-variant-1-image-id', parseIntSafe(first.media_image_id, 0));
    setField('vms-ma-variant-1-video-id', parseIntSafe(first.media_video_id, 0));
    syncVariantMediaUi(1);
    syncVariantMediaPreview(1, 'image');
    syncVariantMediaPreview(1, 'video');

    [2, 3].forEach(function (index) {
      var item = list[index - 1] || {};
      setField('vms-ma-variant-' + index + '-label', item.label || ('Variant ' + index));
      setField('vms-ma-variant-' + index + '-primary', item.primary_text || '');
      setField('vms-ma-variant-' + index + '-headline', item.headline || '');
      setField('vms-ma-variant-' + index + '-description', item.description || '');
      setField('vms-ma-variant-' + index + '-media-mode', item.media_mode || 'shared');
      setField('vms-ma-variant-' + index + '-placement-slot', item.placement_slot || 'auto');
      setField('vms-ma-variant-' + index + '-image-id', parseIntSafe(item.media_image_id, 0));
      setField('vms-ma-variant-' + index + '-video-id', parseIntSafe(item.media_video_id, 0));
      syncVariantMediaUi(index);
      syncVariantMediaPreview(index, 'image');
      syncVariantMediaPreview(index, 'video');
    });
  }

  function renderMetaVariantSummary(resp) {
    var summaryNode = byId('vms-ma-meta-variant-summary');
    var detailsNode = byId('vms-ma-meta-variant-details');
    if (!summaryNode || !detailsNode) {
      return;
    }
    var variants = (resp && Array.isArray(resp.ad_variants)) ? resp.ad_variants : [];
    var count = parseIntSafe(resp && resp.ad_variant_count, variants.length || 0);
    if (!count && !variants.length) {
      summaryNode.textContent = buildHasMetaIds(getSelectedBuildItem()) ? 'Meta variant status has not been refreshed yet.' : 'No Meta campaign has been created yet.';
      detailsNode.textContent = buildHasMetaIds(getSelectedBuildItem()) ? 'Linked Meta IDs are saved. Refresh Status to load per-variant details.' : 'Load a saved build first. Create Paused uses the build currently loaded in the builder.';
      return;
    }
    summaryNode.textContent = count + ' ad variant' + (count === 1 ? '' : 's') + ' linked.';
    detailsNode.textContent = variants.map(function (row, index) {
      var label = String((row && row.label) || ('Variant ' + (index + 1)));
      var effective = String((row && row.effective_status) || (row && row.configured_status) || 'UNKNOWN').toUpperCase();
      return label + ': ' + effective;
    }).join(' • ') || 'Variant data loaded.';
  }

  function formatMetaStatusText(status, hasMetaIds) {
    var normalized = String(status || 'UNKNOWN').toUpperCase();
    if (!normalized || normalized === 'UNKNOWN') {
      return hasMetaIds ? 'Needs refresh' : 'Not created yet';
    }
    return normalized;
  }

  function normalizeSpecKey(key) {
    return String(key || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  }

  function parseSpecBudgetToMinor(rawValue, treatAsMinor) {
    var textValue = String(rawValue || '').replace(/[$,]/g, '').trim();
    if (!textValue) {
      return 0;
    }
    if (treatAsMinor) {
      return parseIntSafe(textValue, 0);
    }
    return Math.round(parseFloatSafe(textValue, 0) * 100);
  }

  function parseSimpleSpec(rawText) {
    var payload = {};
    var variants = {};
    String(rawText || '').split(/\r?\n/).forEach(function (line) {
      var trimmed = String(line || '').trim();
      if (!trimmed || /^#/.test(trimmed) || /^\/\//.test(trimmed)) {
        return;
      }
      var parts = trimmed.split(/:(.+)/);
      if (!parts || parts.length < 2) {
        return;
      }
      var rawKey = String(parts[0] || '').trim();
      var rawValue = String(parts[1] || '').trim();
      if (!rawKey) {
        return;
      }
      var variantMatch = rawKey.match(/^variant\s*(\d+)\s*[- ]\s*(label|primary text|headline|description)$/i);
      if (!variantMatch && /^(primary text|headline|description)$/i.test(rawKey)) {
        variantMatch = ['', '1', rawKey];
      }
      if (variantMatch) {
        var idx = parseIntSafe(variantMatch[1], 1);
        if (!variants[idx]) {
          variants[idx] = { variant_key: 'v' + idx, label: 'Variant ' + idx, primary_text: '', headline: '', description: '' };
        }
        var fieldKey = normalizeSpecKey(variantMatch[2]);
        if (fieldKey === 'primary_text') {
          variants[idx].primary_text = rawValue;
        } else if (fieldKey === 'headline') {
          variants[idx].headline = rawValue;
        } else if (fieldKey === 'description') {
          variants[idx].description = rawValue;
        } else if (fieldKey === 'label') {
          variants[idx].label = rawValue || ('Variant ' + idx);
        }
        return;
      }

      switch (normalizeSpecKey(rawKey)) {
        case 'event_name':
        case 'event':
          payload.event_name = rawValue;
          break;
        case 'venue_name':
        case 'venue':
          payload.venue_name = rawValue;
          break;
        case 'destination_url':
        case 'url':
        case 'link':
          payload.destination_url = rawValue;
          break;
        case 'creative_mode':
        case 'mode':
          payload.creative_mode = rawValue;
          break;
        case 'cta':
        case 'cta_type':
        case 'call_to_action':
          payload.cta_type = rawValue;
          break;
        case 'targeting_address':
        case 'address':
          payload.targeting_address = rawValue;
          break;
        case 'locations':
        case 'cities':
          payload.locations = rawValue.replace(/\s*,\s*/g, '\n');
          break;
        case 'radius':
        case 'radius_miles':
          payload.radius_miles = parseIntSafe(rawValue, 0);
          break;
        case 'age_min':
        case 'min_age':
          payload.age_min = parseIntSafe(rawValue, 0);
          break;
        case 'age_max':
        case 'max_age':
          payload.age_max = parseIntSafe(rawValue, 0);
          break;
        case 'interests':
          payload.interests = rawValue;
          break;
        case 'preset':
        case 'preset_mode':
          payload.preset_mode = rawValue;
          break;
        case 'manual_start':
          payload.manual_start = rawValue;
          break;
        case 'manual_end':
          payload.manual_end = rawValue;
          break;
        case 'end_buffer_hours':
          payload.end_buffer_hours = parseIntSafe(rawValue, 0);
          break;
        case 'budget':
        case 'total_budget':
        case 'daily_budget':
          payload.total_budget_minor = parseSpecBudgetToMinor(rawValue, false);
          break;
        case 'total_budget_minor':
        case 'budget_minor':
          payload.total_budget_minor = parseSpecBudgetToMinor(rawValue, true);
          break;
      }
    });

    var variantList = Object.keys(variants).map(function (key) {
      return variants[key];
    }).sort(function (a, b) {
      return parseIntSafe(String(a.variant_key || '').replace('v', ''), 0) - parseIntSafe(String(b.variant_key || '').replace('v', ''), 0);
    });
    if (variantList.length) {
      payload.ad_variants = variantList;
    }
    return payload;
  }

  function parseAdSpec(rawText) {
    var textValue = String(rawText || '').trim();
    if (!textValue) {
      throw new Error('Paste a spec first.');
    }
    try {
      var parsed = JSON.parse(textValue);
      if (!parsed || typeof parsed !== 'object') {
        throw new Error('JSON spec must be an object.');
      }
      return parsed;
    } catch (jsonErr) {
      var simple = parseSimpleSpec(textValue);
      if (simple && Object.keys(simple).length) {
        return simple;
      }
      throw jsonErr;
    }
  }

  function setSpecStatus(message) {
    var node = byId('vms-ma-spec-status');
    if (node) {
      node.textContent = String(message || '');
    }
  }

  function bindSpecTools() {
    var specEl = byId('vms-ma-spec-input');
    var applyBtn = byId('vms-ma-apply-spec');
    var exportBtn = byId('vms-ma-export-spec');
    var copyBtn = byId('vms-ma-copy-spec');
    var clearBtn = byId('vms-ma-clear-spec');
    if (!specEl) {
      return;
    }
    if (applyBtn) {
      applyBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        try {
          var payload = parseAdSpec(specEl.value);
          applyTemplatePayload(payload);
          setSpecStatus('Pasted spec applied.');
          emitFeedback('success', 'Pasted spec applied.', 'g');
        } catch (err) {
          var message = (err && err.message) ? err.message : 'Unable to parse ad spec.';
          setSpecStatus(message);
          emitFeedback('error', message, 'g');
        }
      });
    }
    if (exportBtn) {
      exportBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        specEl.value = JSON.stringify(collectPayload(), null, 2);
        setSpecStatus('Current builder settings exported to the box.');
      });
    }
    if (copyBtn) {
      copyBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        if (!String(specEl.value || '').trim()) {
          specEl.value = JSON.stringify(collectPayload(), null, 2);
        }
        copyText(specEl.value).then(function () {
          setSpecStatus('Export copied.');
          emitFeedback('success', 'Export copied.', 'g');
        });
      });
    }
    if (clearBtn) {
      clearBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        specEl.value = '';
        setSpecStatus('');
      });
    }
  }


  function buildCopyPackText() {
    var eventName = value('vms-ma-event-name');
    var venueName = value('vms-ma-venue-name');
    var eventStart = value('vms-ma-event-start');
    var destination = value('vms-ma-destination-url');
    var utmUrl = buildDestinationUtm(destination, eventName);
    var mode = (document.querySelector('input[name="vms_ma_creative_mode"]:checked') || {}).value || 'dark_post';
    var ctaType = value('vms-ma-cta-type') || 'LEARN_MORE';
    var targetingAddress = value('vms-ma-targeting-address') || getDefaultTargetingAddress();
    var locations = value('vms-ma-locations');
    var placementsMode = getPlacementsMode();
    var placements = collectPlacementSelections();
    var radius = value('vms-ma-radius');
    var ageMin = value('vms-ma-age-min');
    var ageMax = value('vms-ma-age-max') === '65' ? '65+' : value('vms-ma-age-max');
    var audiencePreview = buildAudiencePreviewSnapshot();
    var budget = value('vms-ma-budget-total');
    var goal = value('vms-ma-goal') || 'traffic';
    var optimization = value('vms-ma-optimization') || (goal === 'sales' ? 'purchase_conversions' : 'link_clicks');
    var preset = value('vms-ma-preset-mode') || 'flat_run';
    var tiers = buildTierSchedule();
    var variants = collectAdVariants();

    var lines = [];
    lines.push('Event: ' + (eventName || '(missing event)'));
    lines.push('Venue: ' + (venueName || '(missing venue)'));
    lines.push('Date/Time: ' + (eventStart || '(missing event start)'));
    lines.push('Destination URL: ' + (destination || '(missing destination URL)'));
    lines.push('UTM URL: ' + (utmUrl || '(missing destination URL)'));
    var strategyKey = value('vms-ma-strategy-template') || 'custom';
    lines.push('Strategy: ' + ((campaignStrategies[strategyKey] || {}).label || strategyKey || 'Custom'));
    if (isCleanRoomStrategyKey(strategyKey)) {
      lines.push('Recipe: 1 clean campaign → placement/audience-specific paused ad sets. Static Feed, 1:1 Feed Video, and Reels/Stories portrait video are separated. Right Column support test: ' + (isRightColumnSupportEnabled() ? 'enabled' : 'off by default') + '.');
    }
    lines.push('Preset: ' + preset);
    lines.push('Goal: ' + goal + ((goal === 'traffic' || goal === 'sales') ? (' | Optimization: ' + optimization) : ''));
    if (goal === 'sales') {
      lines.push('Conversion event: Purchase' + (String((window.VMS_MA && VMS_MA.metaPixelId) || '').trim() ? ' | Pixel/Dataset configured' : ' | Pixel/Dataset missing in MAB Settings'));
    }
    lines.push('Creative mode: ' + mode);
    lines.push('Ad variants: ' + variants.length);
    variants.forEach(function (variant, index) {
      var mediaMode = String(variant.media_mode || 'shared').trim().toLowerCase();
      var mediaLabel = 'shared images';
      if (mediaMode === 'image') {
        mediaLabel = 'custom image #' + parseIntSafe(variant.media_image_id, 0);
      } else if (mediaMode === 'video_placeholder') {
        mediaLabel = 'Meta-direct video placeholder (uses shared image until video is uploaded/swapped in Meta)';
      } else if (mediaMode === 'video') {
        mediaLabel = 'WordPress video upload #' + parseIntSafe(variant.media_video_id, 0);
      }
      lines.push('Variant ' + (index + 1) + ' label: ' + (variant.label || ('Variant ' + (index + 1))));
      lines.push('Variant ' + (index + 1) + ' media: ' + mediaLabel);
      lines.push('Variant ' + (index + 1) + ' primary text: ' + (variant.primary_text || '(empty)'));
      lines.push('Variant ' + (index + 1) + ' headline: ' + (variant.headline || '(empty)'));
      lines.push('Variant ' + (index + 1) + ' description: ' + (variant.description || '(empty)'));
    });
    lines.push('Video shape: ' + getVideoFormatSelection().replace(/_/g, ' '));
    lines.push('Strict vertical-video check: ' + (isVerticalVideoRequired() ? 'on' : 'off'));
    lines.push('Call to action: ' + ctaType + (isBuyTicketsLocked() ? ' (locked)' : ''));
    lines.push('Advantage+ creative policy: ' + (value('vms-ma-creative-automation-policy') || 'off'));
    lines.push('Creative Lockdown: use only the selected MAB creative assets; reject Meta-added website images/enhancements during manual QA.');
    lines.push('Multi-advertiser ads: ' + ((byId('vms-ma-multi-advertiser-ads') && byId('vms-ma-multi-advertiser-ads').checked) ? 'allowed' : 'off by default'));
    lines.push('Manual Meta QA: turn off Website Highlights / Web Highlight / Show Spotlights before publishing so Meta does not inject random website images.');
    lines.push('Primary targeting anchor: ' + (targetingAddress || '(missing exact address/ZIP anchor)'));
    if (locations) {
      lines.push('Additional locations: ' + locations.replace(/\n+/g, '; '));
    }
    lines.push('Placements: ' + (placementsMode === 'manual' ? ('manual (' + (placements.length ? placements.join(', ') : 'none selected') + ')') : 'automatic'));
    lines.push('Audience: ' + [
      audiencePreview.modeLabel,
      'radius ' + (radius || '0') + ' miles',
      'ages ' + (ageMin || '?') + '-' + (ageMax || '?'),
      audiencePreview.genderLabel.toLowerCase(),
      audiencePreview.activeTerms.length ? ('terms ' + audiencePreview.activeTerms.map(function (term) { return term.label; }).join(', ')) : 'no active detailed targeting terms'
    ].join(', '));
    if (audiencePreview.artistInspirations.length) {
      lines.push('Artist inspiration seeds: ' + audiencePreview.artistInspirations.join(', '));
    }
    if (audiencePreview.warnings.length) {
      audiencePreview.warnings.forEach(function (warning) {
        lines.push('Audience warning: ' + warning);
      });
    }
    lines.push('Budget total: $' + (budget || '0.00'));
    if (tiers.length) {
      var packRuntimeMs = getRuntimeMs(tiers[0].start, tiers[tiers.length - 1].end);
      var packBudgetMinor = tiers.reduce(function (sum, tier) { return sum + parseIntSafe(tier.budgetMinor, 0); }, 0);
      lines.push('Run time: ' + formatRunTime(packRuntimeMs) + ' (~' + formatApproxDays(packRuntimeMs) + ' days)');
      lines.push('Average per day: ' + formatBudgetPerDay(packBudgetMinor, packRuntimeMs));
    }
    lines.push('Schedule:');
    tiers.forEach(function (tier) {
      var tierRuntimeMs = getRuntimeMs(tier.start, tier.end);
      lines.push('- ' + tier.label + ': ' + toDisplayDate(tier.start) + ' -> ' + toDisplayDate(tier.end) + ' | ' + formatRunTime(tierRuntimeMs) + ' | $' + (tier.budgetMinor / 100).toFixed(2) + ' | ' + formatBudgetPerDay(tier.budgetMinor, tierRuntimeMs) + '/day');
    });

    return {
      text: lines.join('\n'),
      utmUrl: utmUrl
    };
  }

  function isCopyPackPanelOpen() {
    var details = byId('vms-ma-copy-pack-details');
    return !!(details && details.open);
  }

  function renderCopyPackPanel(options) {
    var warning = byId('vms-ma-copy-pack-warning');
    var pre = byId('vms-ma-copy-pack');
    var force = !!(options && options.force);
    if (!pre) {
      return;
    }

    if (!isPackReady()) {
      pre.textContent = 'Finish Steps A-E to generate your copy pack.';
      if (warning) {
        warning.textContent = '';
        warning.classList.add('vms-ma-hidden');
      }
      return;
    }

    if (!force && !isCopyPackPanelOpen()) {
      pre.textContent = 'Copy Pack is ready when you need it. Open Advanced / Export, Copy Pack + Templates to generate the text bundle.';
      if (warning) {
        warning.textContent = '';
        warning.classList.add('vms-ma-hidden');
      }
      return;
    }

    var pack = buildCopyPackText();
    pre.textContent = pack.text;

    if (!value('vms-ma-destination-url')) {
      if (warning) {
        warning.textContent = 'Missing Destination URL. Paste it in Step A.';
        warning.classList.remove('vms-ma-hidden');
      }
    } else if (warning) {
      warning.textContent = '';
      warning.classList.add('vms-ma-hidden');
    }
  }

  function collectPlacementSelections() {
    var out = [];
    document.querySelectorAll('.vms-ma-placement:checked').forEach(function (el) {
      if (el && el.value) {
        out.push(String(el.value));
      }
    });
    return out;
  }

  function syncPlacementsUi() {
    var mode = getPlacementsMode();
    var block = byId('vms-ma-placements-manual');
    if (!block) {
      return;
    }
    if (mode === 'manual') {
      block.classList.remove('vms-ma-hidden');
    } else {
      block.classList.add('vms-ma-hidden');
    }
  }

  function collectPayload() {
    var normalizedAudience = normalizeAudienceState(syncAudienceStateFromForm());
    var tiers = buildTierSchedule();
    var tierBudgets = {};
    var targetingAddress = value('vms-ma-targeting-address');
    var locationsValue = value('vms-ma-locations');
    var outerLocationsValue = value('vms-ma-outer-locations');
    var outerTownsMode = getOuterTownsMode();
    if (!targetingAddress && lastEventContext && lastEventContext.location_targeting_anchor) {
      targetingAddress = String(lastEventContext.location_targeting_anchor || '').trim();
    }
    tiers.forEach(function (tier) {
      tierBudgets[tier.key] = tier.budgetMinor;
    });

    var preset = value('vms-ma-preset-mode') || 'flat_run';
    var mode = (preset === 'promo_bundle_30_14_7' || preset === 'video_tribute_push') ? 'autoramp' : 'simple';

    return {
      id: parseIntSafe(value('vms-ma-build-id'), 0),
      event_plan_id: parseIntSafe(value('vms-ma-event-plan-id'), 0),
      venue_id: parseIntSafe(value('vms-ma-venue-id'), 0),
      event_name: value('vms-ma-event-name'),
      venue_name: value('vms-ma-venue-name'),
      event_start: toSiteDateTime(value('vms-ma-event-start')),
      destination_url: value('vms-ma-destination-url'),
      mode: mode,
      goal: value('vms-ma-goal') || 'traffic',
      optimization: value('vms-ma-optimization') || ((value('vms-ma-goal') || 'traffic') === 'sales' ? 'purchase_conversions' : 'link_clicks'),
      strategy_template: value('vms-ma-strategy-template') || 'custom',
      campaign_recipe: getCleanRoomRecipeKey(),
      include_right_column_support: isRightColumnSupportEnabled() ? 1 : 0,
      include_outer_towns_adset: isOuterTownsAdsetEnabled() ? 1 : 0,
      video_format: getVideoFormatSelection(),
      require_vertical_video: isVerticalVideoRequired() ? 1 : 0,
      force_buy_tickets_cta: isBuyTicketsLocked() ? 1 : 0,
      creative_automation_policy: value('vms-ma-creative-automation-policy') || 'off',
      multi_advertiser_ads: (byId('vms-ma-multi-advertiser-ads') && byId('vms-ma-multi-advertiser-ads').checked) ? 1 : 0,
      preset_mode: preset,
      manual_start: toSiteDateTime(value('vms-ma-manual-start')),
      manual_end: toSiteDateTime(value('vms-ma-manual-end')),
      creative_mode: (document.querySelector('input[name="vms_ma_creative_mode"]:checked') || {}).value || 'dark_post',
      post_asset_id: parseIntSafe(value('vms-ma-post-id'), 0),
      fb_event_id: value('vms-ma-fb-event-id'),
      primary_text: value('vms-ma-primary-text'),
      headline: value('vms-ma-headline'),
      description: value('vms-ma-description'),
      ad_variants: collectAdVariants(),
      cta_type: value('vms-ma-cta-type') || 'LEARN_MORE',
      targeting_address: targetingAddress,
      locations: locationsValue,
      outer_towns_locations: outerLocationsValue,
      outer_towns_mode: outerTownsMode,
      outer_towns_default_radius: getOuterTownsDefaultRadius(),
      placements_mode: getPlacementsMode(),
      placements: (getPlacementsMode() === 'manual') ? collectPlacementSelections() : [],
      image_square_id: parseIntSafe(value('vms-ma-image-square-id'), 0),
      image_vertical_id: parseIntSafe(value('vms-ma-image-vertical-id'), 0),
      image_wide_id: parseIntSafe(value('vms-ma-image-wide-id'), 0),
      radius_miles: parseIntSafe(value('vms-ma-radius'), 15),
      age_min: parseIntSafe(value('vms-ma-age-min'), 21),
      age_max: parseIntSafe(value('vms-ma-age-max'), 65),
      gender: normalizedAudience.gender,
      interests: buildLegacyInterestStringFromAudienceState(),
      audience_targeting: normalizedAudience,
      total_budget_minor: Math.round(parseFloatSafe(value('vms-ma-budget-total'), 0) * 100),
      recipe_adset_state: collectRecipeAdsetState(),
      auto_sync_budget_enabled: !!(byId('vms-ma-auto-budget-sync') && byId('vms-ma-auto-budget-sync').checked),
      tier_budgets: tierBudgets,
      end_buffer_hours: parseIntSafe(value('vms-ma-end_buffer_hours'), 2)
    };
  }

  function normalizePayloadForSignature(payload) {
    var src = payload && typeof payload === 'object' ? payload : {};
    var tierBudgets = {};
    var recipeAdsets = {};
    var totalBudgetMinor = Math.max(0, parseIntSafe(src.total_budget_minor, 0));
    var normalizedRecipeState = normalizeRecipeAdsetState(src.recipe_adset_state);
    var explicitTotalMinor = 0;
    var fallbackRows = [];
    Object.keys(src.tier_budgets || {}).sort().forEach(function (key) {
      tierBudgets[key] = parseIntSafe(src.tier_budgets[key], 0);
    });
    Object.keys(normalizedRecipeState || {}).sort().forEach(function (key) {
      var row = normalizedRecipeState[key] || {};
      if (row.budgetMinor != null) {
        explicitTotalMinor += Math.max(0, parseIntSafe(row.budgetMinor, 0));
      } else {
        fallbackRows.push({
          key: key,
          weight: normalizeRecipePercentValue(row.percent)
        });
      }
    });
    var distributed = allocateRecipeBudgetMinor(Math.max(0, totalBudgetMinor - explicitTotalMinor), fallbackRows, function (item) {
      return item.weight;
    });
    Object.keys(normalizedRecipeState || {}).sort().forEach(function (key) {
      var row = normalizedRecipeState[key] || {};
      var budgetMinor = row.budgetMinor != null
        ? Math.max(0, parseIntSafe(row.budgetMinor, 0))
        : Math.max(0, parseIntSafe(distributed[key], 0));
      recipeAdsets[key] = {
        enabled: !!row.enabled,
        budget_minor: budgetMinor,
        percent: totalBudgetMinor > 0 ? normalizeRecipePercentValue((budgetMinor / totalBudgetMinor) * 100) : normalizeRecipePercentValue(row.percent)
      };
    });
    var variants = Array.isArray(src.ad_variants) ? src.ad_variants.map(function (variant, index) {
      return {
        variant_key: String((variant && variant.variant_key) || ('v' + (index + 1))),
        label: String((variant && variant.label) || ('Variant ' + (index + 1))).trim(),
        primary_text: String((variant && variant.primary_text) || '').trim(),
        headline: String((variant && variant.headline) || '').trim(),
        description: String((variant && variant.description) || '').trim(),
        media_mode: normalizeVariantMediaMode((variant && variant.media_mode) || 'shared'),
        placement_slot: normalizeVariantPlacementSlot((variant && variant.placement_slot) || 'auto'),
        media_image_id: normalizeVariantMediaMode((variant && variant.media_mode) || 'shared') === 'image' ? parseIntSafe(variant && variant.media_image_id, 0) : 0,
        media_video_id: normalizeVariantMediaMode((variant && variant.media_mode) || 'shared') === 'video' ? parseIntSafe(variant && variant.media_video_id, 0) : 0
      };
    }) : [];
    return {
      event_plan_id: parseIntSafe(src.event_plan_id, 0),
      venue_id: parseIntSafe(src.venue_id, 0),
      event_name: String(src.event_name || '').trim(),
      venue_name: String(src.venue_name || '').trim(),
      event_start: String(src.event_start || '').trim(),
      destination_url: String(src.destination_url || '').trim(),
      mode: String(src.mode || '').trim(),
      goal: String(src.goal || '').trim(),
      optimization: String(src.optimization || '').trim(),
      strategy_template: String(src.strategy_template || '').trim(),
      campaign_recipe: String(src.campaign_recipe || '').trim(),
      include_right_column_support: !!src.include_right_column_support,
      include_outer_towns_adset: !!src.include_outer_towns_adset,
      video_format: String(src.video_format || 'unknown').trim(),
      require_vertical_video: !!src.require_vertical_video,
      preset_mode: String(src.preset_mode || '').trim(),
      manual_start: String(src.manual_start || '').trim(),
      manual_end: String(src.manual_end || '').trim(),
      creative_mode: String(src.creative_mode || '').trim(),
      post_asset_id: parseIntSafe(src.post_asset_id, 0),
      fb_event_id: String(src.fb_event_id || '').trim(),
      primary_text: String(src.primary_text || '').trim(),
      headline: String(src.headline || '').trim(),
      description: String(src.description || '').trim(),
      ad_variants: variants,
      cta_type: String(src.cta_type || '').trim(),
      targeting_address: String(src.targeting_address || '').trim(),
      locations: String(src.locations || '').trim(),
      outer_towns_locations: String(src.outer_towns_locations || '').trim(),
      outer_towns_mode: String(src.outer_towns_mode || 'listed_only').trim(),
      outer_towns_default_radius: parseIntSafe(src.outer_towns_default_radius, 15),
      placements_mode: String(src.placements_mode || '').trim(),
      placements: Array.isArray(src.placements) ? src.placements.map(function (placement) { return String(placement || '').trim(); }).filter(Boolean).sort() : [],
      image_square_id: parseIntSafe(src.image_square_id, 0),
      image_vertical_id: parseIntSafe(src.image_vertical_id, 0),
      image_wide_id: parseIntSafe(src.image_wide_id, 0),
      radius_miles: parseIntSafe(src.radius_miles, 0),
      age_min: parseIntSafe(src.age_min, 0),
      age_max: parseIntSafe(src.age_max, 0),
      gender: normalizeAudienceGender(src.gender || 'all'),
      interests: String(src.interests || '').trim(),
      audience_targeting: normalizeAudienceState(Object.assign({}, (src.audience_targeting && typeof src.audience_targeting === 'object') ? src.audience_targeting : {}, {
        gender: src.gender || ((src.audience_targeting && src.audience_targeting.gender) ? src.audience_targeting.gender : 'all')
      })),
      total_budget_minor: parseIntSafe(src.total_budget_minor, 0),
      recipe_adset_state: recipeAdsets,
      auto_sync_budget_enabled: !!src.auto_sync_budget_enabled,
      tier_budgets: tierBudgets,
      end_buffer_hours: parseIntSafe(src.end_buffer_hours, 0)
    };
  }

  function buildPayloadSignature(payload) {
    try {
      return JSON.stringify(normalizePayloadForSignature(payload));
    } catch (e) {
      return '';
    }
  }

  function renderDirtyStateNotice() {
    var notice = byId('vms-ma-dirty-state');
    if (!notice) {
      return;
    }
    var hasEventPlan = !!getCurrentEventPlanId();
    if (!hasEventPlan) {
      notice.textContent = '';
      notice.classList.add('vms-ma-hidden');
      return;
    }
    if (hasBlockingBuildHydrationMismatch()) {
      notice.textContent = getBuildHydrationGuardMessage('saving');
      notice.classList.remove('vms-ma-hidden');
      return;
    }
    if (!dirtyState.savedPayloadSignature) {
      notice.textContent = 'This Event Plan does not have a saved draft yet. Save Draft first, then use Preview / Troubleshooting Dry Run for a local-only check.';
      notice.classList.remove('vms-ma-hidden');
      return;
    }
    if (dirtyState.isDirty) {
      notice.textContent = 'Unsaved changes detected. Save Draft before Create, Update, Sync, or Go Live so Meta actions use the latest settings.';
      notice.classList.remove('vms-ma-hidden');
      return;
    }
    notice.textContent = '';
    notice.classList.add('vms-ma-hidden');
  }

  function setSavedDraftStateFromPayload(payload) {
    dirtyState.savedPayloadSignature = buildPayloadSignature(payload);
    dirtyState.currentPayloadSignature = dirtyState.savedPayloadSignature;
    dirtyState.isDirty = false;
    renderDirtyStateNotice();
    resolveApiButtonsState();
  }

  function updateDirtyState() {
    var payload = collectPayload();
    var hasEventPlan = !!parseIntSafe(payload.event_plan_id, 0);
    dirtyState.currentPayloadSignature = buildPayloadSignature(payload);
    if (!hasEventPlan) {
      dirtyState.isDirty = false;
    } else if (!dirtyState.savedPayloadSignature) {
      dirtyState.isDirty = true;
    } else {
      dirtyState.isDirty = dirtyState.currentPayloadSignature !== dirtyState.savedPayloadSignature;
    }
    renderDirtyStateNotice();
    resolveApiButtonsState();
  }

  function copyText(text) {
    if (!navigator.clipboard) {
      return Promise.resolve();
    }
    return navigator.clipboard.writeText(String(text || ''));
  }

  function downloadText(filename, text) {
    var blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function modalOpen(message) {
    var modal = byId('vms-ma-gated-modal');
    var body = byId('vms-ma-gated-message');
    if (!modal) {
      return;
    }
    if (body && message) {
      body.textContent = message;
    }
    modal.classList.remove('vms-ma-hidden');
  }

  function modalClose() {
    var modal = byId('vms-ma-gated-modal');
    if (!modal) {
      return;
    }
    modal.classList.add('vms-ma-hidden');
  }

  function setMetaInline(message) {
    var line = byId('vms-ma-meta-status-inline');
    if (!line) {
      return;
    }
    line.textContent = String(message || '');
  }

  function clearMetaCreateGuidance() {
    var panel = byId('vms-ma-meta-create-guidance');
    if (!panel) {
      return;
    }
    panel.innerHTML = '';
    panel.classList.add('vms-ma-hidden');
  }

  function renderMetaCreateGuidance(details) {
    var panel = byId('vms-ma-meta-create-guidance');
    if (!panel) {
      return;
    }
    if (!details || typeof details !== 'object') {
      clearMetaCreateGuidance();
      return;
    }

    var knownIds = (details.known_meta_ids && typeof details.known_meta_ids === 'object') ? details.known_meta_ids : {};
    var guidance = Array.isArray(details.cleanup_guidance) ? details.cleanup_guidance : [];
    var snapshot = (details.status_snapshot && typeof details.status_snapshot === 'object') ? details.status_snapshot : {};
    var hasIds = !!(String(knownIds.campaign_id || '').trim() || (Array.isArray(knownIds.adset_ids) && knownIds.adset_ids.length) || (Array.isArray(knownIds.creative_ids) && knownIds.creative_ids.length) || (Array.isArray(knownIds.ad_ids) && knownIds.ad_ids.length));
    var html = '<strong>Manual Meta review is required before retrying.</strong>';

    if (hasIds) {
      html += '<div class="vms-ma-meta-guidance-grid">';
      if (knownIds.campaign_id) {
        html += '<div><strong>Campaign ID:</strong> ' + escapeHtml(String(knownIds.campaign_id)) + '</div>';
      }
      if (Array.isArray(knownIds.adset_ids) && knownIds.adset_ids.length) {
        html += '<div><strong>Ad Set IDs:</strong> ' + escapeHtml(knownIds.adset_ids.join(', ')) + '</div>';
      }
      if (Array.isArray(knownIds.creative_ids) && knownIds.creative_ids.length) {
        html += '<div><strong>Creative IDs:</strong> ' + escapeHtml(knownIds.creative_ids.join(', ')) + '</div>';
      }
      if (Array.isArray(knownIds.ad_ids) && knownIds.ad_ids.length) {
        html += '<div><strong>Ad IDs:</strong> ' + escapeHtml(knownIds.ad_ids.join(', ')) + '</div>';
      }
      html += '</div>';
    }

    if (snapshot.campaign || (Array.isArray(snapshot.adsets) && snapshot.adsets.length) || (Array.isArray(snapshot.ads) && snapshot.ads.length)) {
      html += '<div class="vms-ma-meta-guidance-status">';
      if (snapshot.campaign && typeof snapshot.campaign === 'object' && snapshot.campaign.configured_status) {
        html += '<div><strong>Campaign status:</strong> ' + escapeHtml(String(snapshot.campaign.configured_status || 'UNKNOWN')) + ' / ' + escapeHtml(String(snapshot.campaign.effective_status || snapshot.campaign.configured_status || 'UNKNOWN')) + '</div>';
      }
      if (Array.isArray(snapshot.adsets) && snapshot.adsets.length) {
        html += '<div><strong>Ad Set status:</strong> ' + escapeHtml(snapshot.adsets.map(function (row) {
          return String((row && row.id) || 'unknown') + ' (' + String((row && row.configured_status) || 'UNKNOWN') + '/' + String((row && row.effective_status) || (row && row.configured_status) || 'UNKNOWN') + ')';
        }).join(', ')) + '</div>';
      }
      if (Array.isArray(snapshot.ads) && snapshot.ads.length) {
        html += '<div><strong>Ad status:</strong> ' + escapeHtml(snapshot.ads.map(function (row) {
          return String((row && row.id) || 'unknown') + ' (' + String((row && row.configured_status) || 'UNKNOWN') + '/' + String((row && row.effective_status) || (row && row.configured_status) || 'UNKNOWN') + ')';
        }).join(', ')) + '</div>';
      }
      html += '</div>';
    }

    if (guidance.length) {
      html += '<ul>';
      guidance.forEach(function (item) {
        html += '<li>' + escapeHtml(String(item || '')) + '</li>';
      });
      html += '</ul>';
    }

    if (details.reset_meta_link_warning) {
      html += '<p class="description">' + escapeHtml(String(details.reset_meta_link_warning)) + '</p>';
    }
    if (details.open_in_meta_url) {
      html += '<p><a class="button button-secondary" target="_blank" rel="noopener noreferrer" href="' + escapeAttribute(String(details.open_in_meta_url)) + '">Open Ads Manager</a></p>';
    }

    panel.innerHTML = html;
    panel.classList.remove('vms-ma-hidden');
  }

  function closeCreatePreflightModal() {
    var modal = byId('vms-ma-create-preflight-modal');
    if (!modal) {
      return;
    }
    modal.classList.add('vms-ma-hidden');
  }

  function syncCreatePreflightConfirmState() {
    var check = byId('vms-ma-create-confirm-paused');
    var confirmBtn = byId('vms-ma-create-preflight-confirm');
    if (!confirmBtn) {
      return;
    }
    confirmBtn.disabled = !(check && check.checked);
  }

  function resolveCreatePlacementKeys() {
    if (getPlacementsMode() === 'manual') {
      return collectPlacementSelections();
    }
    var keys = ['fb_feed', 'fb_profile_feed', 'fb_right_column', 'fb_search', 'fb_story', 'fb_reels'];
    if (String(VMS_MA.metaIgActorId || '').trim()) {
      keys = keys.concat(['ig_feed', 'ig_search', 'ig_explore', 'ig_story', 'ig_reels']);
    }
    return keys;
  }

  function getCreatePlacementSummary() {
    var keys = resolveCreatePlacementKeys();
    var labels = keys.map(formatPlacementLabel).filter(Boolean);
    if (!labels.length) {
      return getPlacementsMode() === 'manual' ? 'Manual placements: none selected' : 'Automatic placements';
    }
    return (getPlacementsMode() === 'manual' ? 'Manual placements: ' : 'Automatic placements (review before Go Live): ') + labels.join(', ');
  }

  function buildExpectedCampaignName() {
    var venueName = String(value('vms-ma-venue-name') || '').trim();
    var eventName = String(value('vms-ma-event-name') || '').trim();
    var eventStart = String(value('vms-ma-event-start') || '').trim();
    var dateLabel = '';
    if (eventStart) {
      try {
        dateLabel = new Date(eventStart).toISOString().slice(0, 10);
      } catch (err) {
        dateLabel = eventStart.slice(0, 10);
      }
    }
    var parts = [];
    if (venueName) {
      parts.push(venueName);
    }
    if (eventName) {
      parts.push(eventName);
    }
    if (dateLabel) {
      parts.push(dateLabel);
    }
    return parts.length ? parts.join(' — ') : 'Campaign name will be derived from the saved Event Plan';
  }

  function collectCreatePausedSummaryHtml(payload) {
    payload = payload && typeof payload === 'object' ? payload : collectPayload();
    var selectedBuild = getSelectedBuildItem();
    var structure = getStructurePreviewData();
    var eventName = String(payload.event_name || value('vms-ma-event-name') || '').trim();
    var eventPlanId = parseIntSafe(payload.event_plan_id || value('vms-ma-event-plan-id'), 0);
    var destination = String(payload.destination_url || value('vms-ma-destination-url') || '').trim();
    var totalBudgetMinor = parseIntSafe(payload.total_budget_minor, 0);
    var scheduleSupport = getDirectCreateScheduleSupport();
    var tiers = buildTierSchedule();
    var firstTier = tiers.length ? tiers[0] : null;
    var lastTier = tiers.length ? tiers[tiers.length - 1] : null;
    var account = String(VMS_MA.adAccountId || '').replace(/^act_/, '').trim();
    var pageId = String(VMS_MA.metaPageId || '').trim();
    var pixelId = String(VMS_MA.metaPixelId || '').trim();
    var dsaBeneficiary = String(VMS_MA.metaDsaBeneficiary || '').trim();
    var dsaPayor = String(VMS_MA.metaDsaPayor || '').trim();
    var rows = [];

    rows.push('<div><strong>Build ID:</strong> ' + escapeHtml(selectedBuild && selectedBuild.id ? String(selectedBuild.id) : 'Not loaded') + '</div>');
    rows.push('<div><strong>Event:</strong> ' + escapeHtml(eventName || ('Event Plan #' + eventPlanId)) + '</div>');
    rows.push('<div><strong>Campaign name:</strong> ' + escapeHtml(buildExpectedCampaignName()) + '</div>');
    rows.push('<div><strong>Strategy:</strong> ' + escapeHtml(structure.strategyLabel) + '</div>');
    rows.push('<div><strong>Expected object counts:</strong> ' + escapeHtml(formatObjectCountSummary(structure.counts)) + '</div>');
    rows.push('<div><strong>Ad sets:</strong> ' + escapeHtml(structure.adsetNames.length ? structure.adsetNames.join(' | ') : 'None included yet') + '</div>');
    if (structure.disabledAdsetNames && structure.disabledAdsetNames.length) {
      rows.push('<div><strong>Excluded ad sets not created:</strong> ' + escapeHtml(structure.disabledAdsetNames.join(' | ')) + '</div>');
    }
    rows.push('<div><strong>Budget:</strong> ' + escapeHtml(formatBudgetMinor(totalBudgetMinor)) + '</div>');
    if (firstTier && lastTier) {
      rows.push('<div><strong>Schedule:</strong> ' + escapeHtml(String(firstTier.label || scheduleSupport.presetLabel || 'Schedule')) + ' • ' + escapeHtml(toDisplayDate(firstTier.start)) + ' to ' + escapeHtml(toDisplayDate(lastTier.end)) + ' • ' + escapeHtml(String(tiers.length)) + ' window' + (tiers.length === 1 ? '' : 's') + '</div>');
    } else {
      rows.push('<div><strong>Schedule:</strong> ' + escapeHtml(String(scheduleSupport.presetLabel || 'Not set')) + '</div>');
    }
    rows.push('<div><strong>Destination URL:</strong> ' + escapeHtml(destination || 'Missing destination URL') + '</div>');
    rows.push('<div><strong>CTA:</strong> ' + escapeHtml(value('vms-ma-cta-type') || 'Missing CTA') + '</div>');
    rows.push('<div><strong>Placements:</strong> ' + escapeHtml(getCreatePlacementSummary()) + '</div>');
    rows.push('<div><strong>Meta account/page/pixel:</strong> ' + escapeHtml(account ? ('act_' + account) : 'Unknown ad account') + ' • Page ' + escapeHtml(pageId || 'Missing') + ' • Pixel ' + escapeHtml(pixelId || 'Missing') + '</div>');
    rows.push('<div><strong>DSA beneficiary/payor:</strong> ' + escapeHtml(dsaBeneficiary || 'Missing') + ' • ' + escapeHtml(dsaPayor || 'Missing') + '</div>');
    rows.push('<div><strong>Expected status:</strong> PAUSED</div>');
    rows.push('<div><strong>Warning:</strong> This creates paused Meta drafts only. It does not publish or go live.</div>');
    return rows.join('');
  }

  function openCreatePreflightModal(payload) {
    var modal = byId('vms-ma-create-preflight-modal');
    var summary = byId('vms-ma-create-preflight-summary');
    var check = byId('vms-ma-create-confirm-paused');
    if (!modal || !summary) {
      return false;
    }
    summary.innerHTML = collectCreatePausedSummaryHtml(payload);
    if (check) {
      check.checked = false;
    }
    syncCreatePreflightConfirmState();
    modal.classList.remove('vms-ma-hidden');
    return true;
  }

  function setMetaChip(kind, configured, effective) {
    var c = String(configured || 'UNKNOWN').toUpperCase();
    var e = String(effective || c).toUpperCase();
    var primary = (e && e !== 'UNKNOWN') ? e : c;
    var hasMetaIds = buildHasMetaIds(getSelectedBuildItem()) || metaStatusState.hasIds;
    var chip = builder.querySelector('.vms-ma-meta-chip[data-meta-kind="' + kind + '"]');
    if (chip) {
      chip.textContent = formatMetaStatusText(primary, hasMetaIds);
      chip.classList.remove('is-active', 'is-paused', 'is-warning', 'is-error', 'is-idle');
      if (primary === 'ACTIVE') {
        chip.classList.add('is-active');
      } else if (primary === 'PAUSED') {
        chip.classList.add('is-paused');
      } else if (['PENDING_REVIEW', 'IN_PROCESS', 'PREAPPROVED', 'CAMPAIGN_PAUSED', 'ADSET_PAUSED', 'MIXED'].indexOf(primary) !== -1) {
        chip.classList.add('is-warning');
      } else if (primary === 'UNKNOWN') {
        chip.classList.add('is-idle');
      } else if (['ERROR', 'DISAPPROVED', 'REJECTED', 'WITH_ISSUES', 'PENDING_BILLING_INFO', 'ARCHIVED', 'DELETED'].indexOf(primary) !== -1) {
        chip.classList.add('is-error');
      }
    }
    var configuredNode = byId('vms-ma-meta-' + kind + '-configured');
    var effectiveNode = byId('vms-ma-meta-' + kind + '-effective');
    if (configuredNode) {
      configuredNode.textContent = c && c !== 'UNKNOWN' ? c : 'Not checked yet';
    }
    if (effectiveNode) {
      effectiveNode.textContent = e && e !== 'UNKNOWN' ? e : 'Not checked yet';
    }
  }

  function getActiveStatusesFromResponse(resp) {
    var campaign = String((resp && resp.campaign && resp.campaign.effective_status) || (resp && resp.campaign && resp.campaign.configured_status) || '').toUpperCase();
    var adset = String((resp && resp.adset && resp.adset.effective_status) || (resp && resp.adset && resp.adset.configured_status) || '').toUpperCase();
    var ad = String((resp && resp.ad && resp.ad.effective_status) || (resp && resp.ad && resp.ad.configured_status) || '').toUpperCase();
    var variantActive = Array.isArray(resp && resp.ad_variants) && resp.ad_variants.some(function (row) {
      var status = String((row && row.effective_status) || (row && row.configured_status) || '').toUpperCase();
      return status === 'ACTIVE';
    });
    return campaign === 'ACTIVE' || adset === 'ACTIVE' || ad === 'ACTIVE' || variantActive;
  }

  function updateMetaLink(resp) {
    var link = byId('vms-ma-open-meta-link');
    if (!link) {
      return;
    }
    var account = String((resp && resp.ad_account_id) || VMS_MA.adAccountId || '').replace(/^act_/, '').trim();
    if (resp && resp.open_in_meta_url) {
      link.href = String(resp.open_in_meta_url);
      link.textContent = 'Open in Ads Manager';
      return;
    }
    if (account) {
      link.href = 'https://adsmanager.facebook.com/adsmanager/manage/campaigns?act=' + encodeURIComponent(account);
      link.textContent = 'Open in Ads Manager';
      return;
    }
    link.href = 'https://adsmanager.facebook.com/';
    link.textContent = 'Open Meta';
  }

  function formatBudgetMinor(minor) {
    var cents = parseIntSafe(minor, 0);
    return '$' + (cents / 100).toFixed(2);
  }

  function renderBudgetSyncState(resp) {
    var statusNode = byId('vms-ma-budget-sync-status');
    var detailsNode = byId('vms-ma-budget-sync-details');
    if (!statusNode || !detailsNode) {
      return;
    }
    var sync = (resp && resp.budget_sync && typeof resp.budget_sync === 'object') ? resp.budget_sync : null;
    if (!sync) {
      statusNode.textContent = buildHasMetaIds(getSelectedBuildItem()) ? 'Meta budget sync has not been refreshed yet.' : 'No Meta budget sync yet.';
      detailsNode.textContent = buildHasMetaIds(getSelectedBuildItem()) ? 'Linked Meta IDs are saved. Refresh Status to review the current Meta budget.' : 'Load a saved build first. Budget sync only works after paused Meta assets exist for that build.';
      return;
    }

    var draft = formatBudgetMinor(sync.draft_budget_minor);
    var meta = sync.meta_budget_minor != null ? formatBudgetMinor(sync.meta_budget_minor) : 'Unknown';
    var parts = [];
    parts.push('Draft ' + draft);
    parts.push('Meta ' + meta);
    parts.push(sync.matches ? 'in sync' : 'not in sync');
    if (sync.auto_enabled) {
      parts.push('auto-sync on');
    }
    statusNode.textContent = parts.join(' • ');

    var detailParts = [];
    if (sync.field_name) {
      detailParts.push('Field: ' + String(sync.field_name));
    }
    if (sync.last_sync_local) {
      detailParts.push('Last sync: ' + String(sync.last_sync_local));
    }
    if (sync.message) {
      detailParts.push(String(sync.message));
    }
    detailsNode.textContent = detailParts.join(' • ') || 'Budget sync ready.';
  }


  function renderMetaAdsetDetails(resp) {
    var node = byId('vms-ma-meta-adset-details');
    if (!node) {
      return;
    }
    var adsets = (resp && Array.isArray(resp.adsets)) ? resp.adsets : [];
    if (!adsets.length) {
      node.textContent = buildHasMetaIds(getSelectedBuildItem()) ? 'Linked Meta IDs are saved. Refresh Status to load ad-set details.' : 'No Meta campaign has been created yet.';
      return;
    }
    var count = parseIntSafe(resp && resp.adset_count, adsets.length);
    var html = '<strong>Ad set review status:</strong> ' + escapeHtml(String(count)) + ' ad set' + (count === 1 ? '' : 's') + ' checked.';
    html += '<ul>';
    adsets.forEach(function (row, index) {
      var label = String((row && row.label) || ('Ad Set ' + (index + 1)));
      var configured = String((row && row.configured_status) || 'UNKNOWN').toUpperCase();
      var effective = String((row && row.effective_status) || configured || 'UNKNOWN').toUpperCase();
      var issueText = '';
      if (row && row.issues_info) {
        issueText = ' • Review warning returned by Meta';
      }
      html += '<li><strong>' + escapeHtml(label) + ':</strong> configured ' + escapeHtml(configured) + ' / effective ' + escapeHtml(effective) + escapeHtml(issueText) + '</li>';
    });
    html += '</ul>';
    node.innerHTML = html;
  }

  function renderMetaReadiness(resp) {
    var node = byId('vms-ma-meta-readiness');
    if (!node) {
      return;
    }
    var readiness = (resp && resp.readiness && typeof resp.readiness === 'object') ? resp.readiness : null;
    if (!readiness || !Array.isArray(readiness.items) || !readiness.items.length) {
      node.innerHTML = '';
      node.classList.add('vms-ma-hidden');
      return;
    }
    var state = String(readiness.state || '').toLowerCase();
    var cards = readiness.items.map(function (item) {
      item = item && typeof item === 'object' ? item : {};
      var itemState = String(item.state || 'warning').toLowerCase();
      var detail = String(item.detail || '').trim();
      return '<li class="vms-ma-meta-readiness-item is-' + escapeAttribute(itemState) + '">' +
        '<strong>' + escapeHtml(String(item.label || 'Readiness item')) + ':</strong> ' +
        '<span>' + escapeHtml(String(item.summary || '')) + '</span>' +
        (detail ? '<small>' + escapeHtml(detail) + '</small>' : '') +
      '</li>';
    }).join('');
    var notes = Array.isArray(readiness.notes) && readiness.notes.length
      ? '<div class="vms-ma-meta-readiness-notes"><strong>Notes:</strong><ul>' + readiness.notes.map(function (note) {
          return '<li>' + escapeHtml(String(note || '')) + '</li>';
        }).join('') + '</ul></div>'
      : '';
    var summaryBits = [];
    if (resp && resp.local_meta_label) {
      summaryBits.push(String(resp.local_meta_label));
    }
    if (state === 'error') {
      summaryBits.push('Some publish-readiness checks need attention.');
    } else if (state === 'warning') {
      summaryBits.push('Review warnings are present before any Go Live step.');
    } else {
      summaryBits.push('Read-only readiness checks look clean.');
    }
    node.className = 'vms-ma-meta-readiness is-' + escapeAttribute(state || 'warning');
    node.innerHTML = '<strong>Post-create readiness</strong><p class="description">' + escapeHtml(summaryBits.join(' ')) + '</p><ul class="vms-ma-meta-readiness-list">' + cards + '</ul>' + notes;
    node.classList.remove('vms-ma-hidden');
  }

  function renderDriftState(resp) {
    var panel = byId('vms-ma-drift-panel');
    if (!panel) {
      return;
    }
    var drift = resp && resp.drift && typeof resp.drift === 'object' ? resp.drift : null;
    if (!drift) {
      panel.classList.add('vms-ma-hidden');
      panel.innerHTML = '';
      return;
    }
    var items = Array.isArray(drift.items) ? drift.items : [];
    var status = String(drift.status || '').toLowerCase();
    var cls = status === 'drift' ? 'vms-ma-drift-panel--warning' : (status === 'clean' ? 'vms-ma-drift-panel--clean' : 'vms-ma-drift-panel--unknown');
    panel.className = 'vms-ma-drift-panel ' + cls;
    var html = '<strong>Meta drift check:</strong> ' + escapeHtml(String(drift.summary || 'No drift details available.'));
    if (items.length) {
      html += '<ul>';
      items.forEach(function (item) {
        html += '<li><strong>' + escapeHtml(String(item.field || 'Field')) + ':</strong> saved ' + escapeHtml(String(item.expected || '—')) + ' / Meta ' + escapeHtml(String(item.live || '—')) + '</li>';
      });
      html += '</ul>';
    }
    panel.innerHTML = html;
  }

  function applyMetaStatusResponse(resp, message) {
    setMetaChip('campaign', resp && resp.campaign ? resp.campaign.configured_status : 'UNKNOWN', resp && resp.campaign ? resp.campaign.effective_status : 'UNKNOWN');
    setMetaChip('adset', resp && resp.adset ? resp.adset.configured_status : 'UNKNOWN', resp && resp.adset ? resp.adset.effective_status : 'UNKNOWN');
    setMetaChip('ad', resp && resp.ad ? resp.ad.configured_status : 'UNKNOWN', resp && resp.ad ? resp.ad.effective_status : 'UNKNOWN');
    renderMetaAdsetDetails(resp || {});
    renderMetaReadiness(resp || {});
    renderMetaVariantSummary(resp || {});
    renderBudgetSyncState(resp || {});
    renderDriftState(resp || {});
    updateMetaLink(resp || {});
    metaStatusState.loaded = true;
    metaStatusState.hasIds = !!(resp && resp.campaign && resp.adset && (resp.ad || ((resp && resp.ad_variant_count) > 0)));
    metaStatusState.anyActive = getActiveStatusesFromResponse(resp || {});
    metaStatusState.lastError = '';
    if (message) {
      setMetaInline(message);
    } else if (resp && resp.updated_local) {
      setMetaInline('Status updated at ' + String(resp.updated_local) + '.');
    }
  }

  function setActionBusy(button, busy, busyLabel, defaultLabel) {
    if (!button) {
      return;
    }
    if (busy) {
      button.dataset.defaultLabel = button.textContent;
      button.textContent = busyLabel;
      button.classList.add('is-busy');
      button.disabled = true;
      return;
    }
    button.classList.remove('is-busy');
    button.disabled = false;
    button.textContent = defaultLabel || button.dataset.defaultLabel || button.textContent;
  }

  function isConnectionFresh() {
    var raw = String(VMS_MA.lastTestOkGmt || '').trim();
    if (!raw) {
      return false;
    }
    var ts = Date.parse(raw.replace(' ', 'T') + 'Z');
    if (!Number.isFinite(ts)) {
      return false;
    }
    return (Date.now() - ts) <= (24 * 60 * 60 * 1000);
  }
 
  function getCurrentCreativeMode() {
    var checked = builder.querySelector('input[name="vms_ma_creative_mode"]:checked');
    return checked ? String(checked.value || '') : '';
  }

  function getCurrentEventPlanId() {
    return parseIntSafe(value('vms-ma-event-plan-id'), 0);
  }

  function resolveApiButtonsState() {
    var apiEnabled = !!parseIntSafe(VMS_MA.apiEnabled, 0);
    var apiReady = !!parseIntSafe(VMS_MA.apiReady, 0);
    var createBtn = byId('vms-ma-create-paused');
    var goLiveBtn = byId('vms-ma-go-live');
    var updateBtn = byId('vms-ma-update-existing');
    var syncBudgetBtn = byId('vms-ma-sync-budget');
    var pauseBtn = byId('vms-ma-pause-all');
    var reason = byId('vms-ma-api-gating-reason');
    var creativeMode = getCurrentCreativeMode();
    var buildId = value('vms-ma-build-id');
    var hasSavedDraft = !!buildId;
    var draftDirty = !!dirtyState.isDirty;
    var budgetAssessment = getBudgetFloorAssessment();
    var budgetFloorBlocked = !budgetAssessment.ok;
    var budgetFloorTitle = budgetFloorBlocked ? String(budgetAssessment.message || 'Budget is likely too low for this schedule. Increase budget or shorten the run window.') : '';
    var dsaBlockingMessage = getDsaBlockingMessage();
    var placementModeWarning = getPlacementModeWarning();
    var selectedBuild = getSelectedBuildItem();
    var scheduleSupport = getDirectCreateScheduleSupport();
    var presetBlockingMessage = scheduleSupport.blocked ? scheduleSupport.message : '';
    var presetBlocked = !!presetBlockingMessage;
    var recipeBlockingMessage = getRecipeBlockingMessage();
    var recipeBlocked = !!recipeBlockingMessage;
    var buildAlreadyLinkedInMeta = buildHasMetaIds(selectedBuild);
    var metaSourceOfTruth = buildIsMetaSourceOfTruth(selectedBuild);
    var effectiveHasMetaIds = metaStatusState.hasIds || buildAlreadyLinkedInMeta;
    var createBlockers = getCreatePausedBlockers();
    var goLiveReasons = [];
    goLiveReasons.push('Go Live is not part of the 0.1.107 self-service paused-create release.');
    if (!hasSavedDraft) {
      goLiveReasons.push('Load a saved build first.');
    }
    if (draftDirty) {
      goLiveReasons.push('Save Draft so any future Meta actions use the latest settings.');
    }
    if (creativeMode && creativeMode !== 'dark_post') {
      goLiveReasons.push('Go Live currently supports Dark Post Link Ad only.');
    }
    if (budgetFloorBlocked) {
      goLiveReasons.push(budgetFloorTitle);
    }
    if (recipeBlocked) {
      goLiveReasons.push(recipeBlockingMessage);
    }
    if (!isCreativeLockdownLocalClean()) {
      goLiveReasons.push('Creative Lockdown requires Advantage+ creative policy Off and Multi-advertiser ads Off.');
    }
    if (dsaBlockingMessage) {
      goLiveReasons.push(dsaBlockingMessage);
    }
    var launchQaMissing = getLaunchQaMissingMessages();
    if (launchQaMissing.length) {
      goLiveReasons.push('Complete manual launch QA checklist.');
    }
    if (!effectiveHasMetaIds) {
      goLiveReasons.push('Create Paused Campaign in Meta first.');
    }
    if (placementModeWarning) {
      goLiveReasons.push(placementModeWarning);
    }
    var liveGated = true;

    if (createBtn) {
      var createDisabled = metaStatusState.inFlight || createBlockers.length > 0;
      createBtn.setAttribute('data-gated', createDisabled ? '1' : '0');
      createBtn.classList.toggle('button-disabled', createDisabled);
      createBtn.setAttribute('aria-disabled', createDisabled ? 'true' : 'false');
      createBtn.disabled = createDisabled;
      createBtn.title = createDisabled
        ? createBlockers.map(function (item) { return item.message; }).join(' ')
        : 'Create will save the latest loaded build first, then create paused Meta assets only for that build.';
    }
    if (goLiveBtn) {
      goLiveBtn.setAttribute('data-gated', liveGated ? '1' : '0');
      goLiveBtn.classList.toggle('button-disabled', liveGated);
      goLiveBtn.setAttribute('aria-disabled', liveGated ? 'true' : 'false');
      goLiveBtn.disabled = liveGated;
      goLiveBtn.title = liveGated ? goLiveReasons.join(' ') : '';
    }
    if (updateBtn) {
      var updateDisabled = !effectiveHasMetaIds || metaStatusState.inFlight || !hasSavedDraft || draftDirty || budgetFloorBlocked || presetBlocked || recipeBlocked;
      updateBtn.disabled = updateDisabled;
      updateBtn.setAttribute('aria-disabled', updateDisabled ? 'true' : 'false');
      updateBtn.classList.toggle('button-disabled', updateDisabled);
      updateBtn.title = draftDirty ? 'Save Draft first so Update Existing Meta Ad uses the latest settings.' : (!effectiveHasMetaIds ? 'Create Paused Campaign in Meta first.' : (!hasSavedDraft ? 'Save Draft first.' : (budgetFloorBlocked ? budgetFloorTitle : (presetBlocked ? presetBlockingMessage : (recipeBlocked ? recipeBlockingMessage : (metaSourceOfTruth ? 'Linked to existing Meta campaign. Review drift before pushing changes.' : ''))))));
    }
    if (syncBudgetBtn) {
      var syncBudgetDisabled = !effectiveHasMetaIds || metaStatusState.inFlight || !hasSavedDraft || draftDirty || budgetFloorBlocked;
      syncBudgetBtn.disabled = syncBudgetDisabled;
      syncBudgetBtn.setAttribute('aria-disabled', syncBudgetDisabled ? 'true' : 'false');
      syncBudgetBtn.classList.toggle('button-disabled', syncBudgetDisabled);
      syncBudgetBtn.title = draftDirty ? 'Save Draft first so budget sync uses the latest settings.' : (!hasSavedDraft ? 'Save Draft first.' : (budgetFloorBlocked ? budgetFloorTitle : ''));
    }
    if (pauseBtn) {
      var pauseDisabled = !metaStatusState.anyActive || metaStatusState.inFlight;
      pauseBtn.disabled = pauseDisabled;
      pauseBtn.setAttribute('aria-disabled', pauseDisabled ? 'true' : 'false');
      pauseBtn.classList.toggle('button-disabled', pauseDisabled);
    }

    renderActionBlockerSummary({
      dryRun: lastDryRunResponse
    });

    if (!reason) {
      return;
    }
    if (createBlockers.length) {
      var safeActions = ' Save Draft and Preview / Troubleshooting Dry Run are still safe to use.';
      if (!apiEnabled || !apiReady) {
        reason.innerHTML = escapeHtml(createBlockers[0].message) + safeActions + ' <a href="' + (VMS_MA.settingsUrl || '#') + '">Open Settings</a>.';
      } else {
        reason.textContent = createBlockers[0].message + safeActions;
      }
      return;
    }
    if (metaSourceOfTruth) {
      reason.textContent = 'This build is linked to an existing Meta campaign. Review drift before pushing any builder changes to Meta.';
      return;
    }
    reason.textContent = 'Create Paused is ready for the loaded build. Go Live remains disabled in this release.';
  }

  function bindModal() {
    var closeBtn = byId('vms-ma-gated-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        modalClose();
      });
    }

    var createCancel = byId('vms-ma-create-preflight-cancel');
    var createConfirm = byId('vms-ma-create-preflight-confirm');
    var createCheck = byId('vms-ma-create-confirm-paused');
    var preflightCancel = byId('vms-ma-live-preflight-cancel');
    var preflightContinue = byId('vms-ma-live-preflight-continue');
    var finalCancel = byId('vms-ma-live-final-cancel');
    var finalConfirm = byId('vms-ma-live-final-confirm');
    var checkSpend = byId('vms-ma-live-confirm-spend');
    var checkReview = byId('vms-ma-live-confirm-review');
    var refreshBtn = byId('vms-ma-refresh-status');
    var updateBtn = byId('vms-ma-update-existing');
    var syncBudgetBtn = byId('vms-ma-sync-budget');
    var resetBtn = byId('vms-ma-reset-meta-link');
    var pauseBtn = byId('vms-ma-pause-all');

    if (createCancel) {
      createCancel.addEventListener('click', function (evt) {
        evt.preventDefault();
        closeCreatePreflightModal();
      });
    }
    if (createConfirm) {
      createConfirm.addEventListener('click', function (evt) {
        evt.preventDefault();
        submitCreatePaused();
      });
    }
    if (createCheck) {
      createCheck.addEventListener('change', syncCreatePreflightConfirmState);
    }
    if (preflightCancel) {
      preflightCancel.addEventListener('click', function (evt) {
        evt.preventDefault();
        closeLiveModals();
      });
    }
    if (preflightContinue) {
      preflightContinue.addEventListener('click', function (evt) {
        evt.preventDefault();
        var preflightModal = byId('vms-ma-live-preflight-modal');
        if (preflightModal) {
          preflightModal.classList.add('vms-ma-hidden');
        }
        openGoLiveFinalModal();
      });
    }
    if (finalCancel) {
      finalCancel.addEventListener('click', function (evt) {
        evt.preventDefault();
        closeLiveModals();
      });
    }
    if (finalConfirm) {
      finalConfirm.addEventListener('click', function (evt) {
        evt.preventDefault();
        submitGoLive();
      });
    }
    if (checkSpend) {
      checkSpend.addEventListener('change', syncLivePreflightContinueState);
    }
    if (checkReview) {
      checkReview.addEventListener('change', syncLivePreflightContinueState);
    }
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        refreshMetaStatus(false);
      });
    }
    if (updateBtn) {
      updateBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        updateExistingMetaAd();
      });
    }
    if (syncBudgetBtn) {
      syncBudgetBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        syncBudget();
      });
    }
    if (pauseBtn) {
      pauseBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        pauseAll();
      });
    }
  }

  function applyEventData(item, source) {
    var planInput = byId('vms-ma-event-plan-id');
    var venueInput = byId('vms-ma-venue-id');
    var eventName = byId('vms-ma-event-name');
    var venueName = byId('vms-ma-venue-name');
    var eventStart = byId('vms-ma-event-start');
    var destination = byId('vms-ma-destination-url');
    var targetingAddress = byId('vms-ma-targeting-address');
    if (!item || !planInput) {
      return;
    }
    var finishPerf = startPerfTimer('event_plan_apply', {
      source: String(source || 'picker'),
      event_plan_id: parseIntSafe(item.id, 0),
      venue_id: parseIntSafe(item.venue_id, 0)
    });

    lastEventContext = item;

    planInput.value = String(item.id || '');
    if (venueInput) {
      venueInput.value = String(item.venue_id || '');
    }
    if (eventName) {
      eventName.value = String(item.title || '');
    }
    if (venueName) {
      venueName.value = String(item.venue_name || '');
    }
    if (eventStart) {
      eventStart.value = toLocalDateTime(String(item.start_input || item.start_local || ''));
    }

    if (destination) {
      var ticket = String(item.ticket_url || '').trim();
      var fallback = String(item.event_permalink || '').trim();
      destination.value = ticket || fallback;
    }
    if (targetingAddress) {
      var eventTargetingAnchor = String(item.location_targeting_anchor || item.location_address || '').trim();
      if (!String(targetingAddress.value || '').trim() && eventTargetingAnchor) {
        targetingAddress.value = eventTargetingAnchor;
      } else if (!eventTargetingAnchor && !String(targetingAddress.value || '').trim()) {
        emitFeedback('warning', 'This Event Plan does not have an exact venue address or ZIP for automatic radius targeting. Enter an address or ZIP manually in Step D.', 'd');
      }
    }

    clearEventScopedCreativeFields({ silent: true });
    clearRecipeAdsetState();
    dispatchFieldEvents(planInput);
    renderTierPreview();
    renderCopyPackPanel();
    clearAnalyticsPanels('Select or save a linked build, then refresh analytics when you need them.');
    recordPerf('event_plan_applied', {
      source: String(source || 'picker'),
      event_plan_id: parseIntSafe(item.id, 0),
      venue_id: parseIntSafe(item.venue_id, 0)
    });

    if (source === 'manual') {
      emitFeedback('info', 'Event Plan loaded from manual entry.', 'a');
    }
    syncCtaLockUi();
    renderRecipePreview();
    renderCreativeFormatRequirements();
    syncDerivedState({ forceAgeClamp: true });
    updateDirtyState();
    ensureEventSelectionState();
    finishPerf({
      copy_pack_open: isCopyPackPanelOpen(),
      build_selected: !!String(getActiveBuildId() || '').trim()
    });
    resolveApiButtonsState();
  }

  function applyServerPrefill() {
    var prefill = window.vmsMaPrefill;
    if (!prefill || !prefill.id) {
      return false;
    }
    var picker = byId('vms-ma-event-plan-picker');
    if (picker) {
      if (picker.querySelector('option[value="' + prefill.id + '"]') === null) {
        picker.add(buildEventPlanOption(prefill, true));
      }
      picker.value = String(prefill.id);
    }
    applyEventData(prefill, 'server');
    var prefillBuildId = prefill.build && prefill.build.id ? String(prefill.build.id) : '';
    if (Array.isArray(prefill.builds) && prefill.builds.length) {
      buildCache = prefill.builds.slice();
      renderBuildSelect(buildCache, prefillBuildId);
      var cachedPrefillBuild = prefillBuildId ? findBuildItem(prefillBuildId) : buildCache[0];
      if (cachedPrefillBuild) {
        applyBuildData(cachedPrefillBuild);
        renderCurrentMetaLinkedState(cachedPrefillBuild);
      }
      emitFeedback('info', 'Prefilled Event Plan draft loaded.', 'g');
      loadBuildsForEventPlan(prefill.id, {
        skipOverlay: true,
        selectedId: prefillBuildId,
        skipAutoloadLatest: false
      });
    } else if (prefill.build && typeof prefill.build === 'object') {
      emitFeedback('info', 'Prefilled Event Plan draft loaded.', 'g');
      loadBuildsForEventPlan(prefill.id, {
        skipOverlay: true,
        selectedId: prefillBuildId,
        fallbackBuild: prefill.build,
        skipAutoloadLatest: false
      });
    } else {
      loadBuildsForEventPlan(prefill.id, { skipOverlay: true, skipAutoloadLatest: true });
    }
    return true;
  }

  function setField(id, nextValue, options) {
    var el = byId(id);
    if (!el) {
      return;
    }
    el.value = String(nextValue == null ? '' : nextValue);
    if (!(options && options.silent)) {
      dispatchFieldEvents(el);
    }
  }

  function setCreativeMode(mode) {
    var radio = builder.querySelector('input[name="vms_ma_creative_mode"][value="' + String(mode || '') + '"]');
    if (!radio) {
      return;
    }
    radio.checked = true;
    dispatchFieldEvents(radio);
  }

  function inferPresetFromBuild(build) {
    var schedule = (build && build.schedule_payload && typeof build.schedule_payload === 'object') ? build.schedule_payload : {};
    var savedPreset = String(schedule.preset_mode || '').trim();
    if (savedPreset) {
      return savedPreset;
    }

    var tiers = Array.isArray(build && build.tiers) ? build.tiers : [];
    if (!tiers.length) {
      return 'flat_run';
    }
    var key = String((tiers[0] && tiers[0].tier_key) || '');
    if (key === 'manual') {
      return 'manual_dates';
    }
    if (key === 'flat_run') {
      return 'flat_run';
    }
    if (key === 'simple_7') {
      return 'simple_7_day';
    }
    if (key === 'simple_14') {
      return 'simple_14_day';
    }
    if (key === 'simple_30') {
      return 'simple_30_day';
    }
    return 'promo_bundle_30_14_7';
  }

  function extractRecipeAdsetStateFromRecipePayload(recipePayload) {
    var payload = recipePayload && typeof recipePayload === 'object' ? recipePayload : {};
    var rows = Array.isArray(payload.adsets) ? payload.adsets : [];
    var out = {};
    rows.forEach(function (row) {
      if (!row || typeof row !== 'object') {
        return;
      }
      var key = String(row.key || '').trim();
      if (!key) {
        return;
      }
      out[key] = {
        enabled: row.enabled == null ? true : (row.enabled === true || row.enabled === '1' || row.enabled === 1),
        budgetMinor: normalizeRecipeBudgetMinorValue(row.budget_amount_minor != null ? row.budget_amount_minor : row.budget_minor),
        percent: normalizeRecipePercentValue(row.allocation_percent != null ? row.allocation_percent : row.percent)
      };
    });
    return out;
  }

  function extractRecipeAdsetStateFromBuild(build) {
    var budget = (build && build.budget_payload && typeof build.budget_payload === 'object') ? build.budget_payload : {};
    var copy = (build && build.copy_payload && typeof build.copy_payload === 'object') ? build.copy_payload : {};
    if (budget.recipe_adset_state && typeof budget.recipe_adset_state === 'object') {
      return normalizeRecipeAdsetState(budget.recipe_adset_state);
    }
    return extractRecipeAdsetStateFromRecipePayload(copy.campaign_recipe_payload);
  }

  function templateTouchesRecipePlanning(payload) {
    var source = payload && typeof payload === 'object' ? payload : {};
    return [
      'total_budget_minor',
      'strategy_template',
      'campaign_recipe',
      'include_right_column_support',
      'include_outer_towns_adset',
      'video_format',
      'require_vertical_video'
    ].some(function (key) {
      return Object.prototype.hasOwnProperty.call(source, key);
    });
  }

  function applyBuildData(build) {
    if (!build || typeof build !== 'object') {
      return;
    }

    resetBuildHydrationState();
    if (build.id) {
      setActiveBuildId(build.id);
    }
    if (buildHasMetaIds(build)) {
      metaStatusState.hasIds = true;
      metaStatusState.loaded = metaStatusState.loaded || buildIsMetaSourceOfTruth(build);
    }
    if (build.venue_id) {
      setField('vms-ma-venue-id', build.venue_id);
    }
    if (build.event_name) {
      setField('vms-ma-event-name', build.event_name);
    }
    if (build.venue_name) {
      setField('vms-ma-venue-name', build.venue_name);
    }
    if (build.event_start) {
      setField('vms-ma-event-start', toLocalDateTime(build.event_start));
    }
    if (build.destination_url) {
      setField('vms-ma-destination-url', build.destination_url);
    }

    if (build.post_asset_id) {
      setField('vms-ma-post-id', build.post_asset_id);
    }
    if (build.fb_event_id) {
      setField('vms-ma-fb-event-id', build.fb_event_id);
    }
    if (build.creative_mode) {
      setCreativeMode(build.creative_mode);
    }

    var copy = (build.copy_payload && typeof build.copy_payload === 'object') ? build.copy_payload : {};
    applySavedStrategyTemplate(resolveStrategyTemplateKey(copy.strategy_template, copy.campaign_recipe));

    if (build.goal) {
      setField('vms-ma-goal', build.goal);
    }
    if (build.optimization) {
      setField('vms-ma-optimization', build.optimization);
    }

    var targeting = (build.targeting_payload && typeof build.targeting_payload === 'object') ? build.targeting_payload : {};
    if (targeting.targeting_address != null) {
      var savedTargetingAddress = String(targeting.targeting_address || '').trim();
      if (savedTargetingAddress) {
        setField('vms-ma-targeting-address', savedTargetingAddress);
      } else {
        var fallbackTargetingAddress = getDefaultTargetingAddress();
        setField('vms-ma-targeting-address', fallbackTargetingAddress || '');
      }
    }
    if (targeting.radius_miles != null) {
      setField('vms-ma-radius', targeting.radius_miles);
    }
    if (targeting.age_min != null) {
      setField('vms-ma-age-min', targeting.age_min);
    }
    if (targeting.age_max != null) {
      setField('vms-ma-age-max', targeting.age_max);
    }
    setAudienceState(buildAudienceStateFromIncoming(
      targeting.audience_targeting,
      targeting.gender,
      Array.isArray(targeting.interests) ? targeting.interests : String(targeting.interests || '')
    ), { skipDerived: true });

    if (targeting.outer_towns_mode) {
      setField('vms-ma-outer-towns-mode', targeting.outer_towns_mode);
    }
    if (targeting.outer_towns_default_radius != null) {
      setField('vms-ma-outer-default-radius', targeting.outer_towns_default_radius);
    }
    if (typeof targeting.outer_towns_locations === 'string' && targeting.outer_towns_locations.trim()) {
      setField('vms-ma-outer-locations', targeting.outer_towns_locations);
    }
    if (typeof targeting.locations === 'string' && targeting.locations.trim()) {
      setField('vms-ma-locations', targeting.locations);
    } else if (Array.isArray(targeting.locations) && targeting.locations.length) {
      var lines = targeting.locations.map(function (loc) {
        if (!loc) {
          return '';
        }
        var label = String(loc.label || loc.query || '').trim();
        var miles = parseIntSafe(loc.radius_miles != null ? loc.radius_miles : targeting.radius_miles, 0);
        if (!label) {
          return '';
        }
        if (miles > 0) {
          return label + ' | ' + miles;
        }
        return label;
      }).filter(Boolean);
      setField('vms-ma-locations', lines.join('\n'));
    }

    var budget = (build.budget_payload && typeof build.budget_payload === 'object') ? build.budget_payload : {};
    if (budget.total_budget_minor != null) {
      setField('vms-ma-budget-total', (parseIntSafe(budget.total_budget_minor, 0) / 100).toFixed(2));
    }
    if (budget.auto_sync_budget_enabled != null) {
      var autoBudgetSync = byId('vms-ma-auto-budget-sync');
      if (autoBudgetSync) {
        autoBudgetSync.checked = !!parseIntSafe(budget.auto_sync_budget_enabled, 0);
      }
    }

    var schedule = (build.schedule_payload && typeof build.schedule_payload === 'object') ? build.schedule_payload : {};
    setField('vms-ma-preset-mode', inferPresetFromBuild(build));
    if (schedule.end_buffer_hours != null) {
      setField('vms-ma-end_buffer_hours', schedule.end_buffer_hours);
    }
    if (schedule.manual_start) {
      setField('vms-ma-manual-start', toLocalDateTime(schedule.manual_start));
    }
    if (schedule.manual_end) {
      setField('vms-ma-manual-end', toLocalDateTime(schedule.manual_end));
    }

    replaceRecipeAdsetState(extractRecipeAdsetStateFromBuild(build));

    if (Array.isArray(copy.ad_variants) && copy.ad_variants.length) {
      applyAdVariants(copy.ad_variants);
    } else {
      applyAdVariants([{
        label: 'Variant 1',
        primary_text: Array.isArray(copy.primary_text_variants) && copy.primary_text_variants[0] ? copy.primary_text_variants[0] : '',
        headline: Array.isArray(copy.headline_variants) && copy.headline_variants[0] ? copy.headline_variants[0] : '',
        description: Array.isArray(copy.description_variants) && copy.description_variants[0] ? copy.description_variants[0] : ''
      }]);
    }

    if (copy.include_right_column_support != null) {
      setChecked('vms-ma-include-right-column', !!parseIntSafe(copy.include_right_column_support, 0));
    }
    if (copy.include_outer_towns_adset != null) {
      setChecked('vms-ma-include-outer-towns-adset', !!parseIntSafe(copy.include_outer_towns_adset, 0));
    }
    if (copy.video_format) {
      setField('vms-ma-video-format', copy.video_format);
    }
    if (copy.require_vertical_video != null) {
      setChecked('vms-ma-require-vertical-video', !!parseIntSafe(copy.require_vertical_video, 0));
    }
    if (copy.cta_type || copy.cta_suggestion) {
      setField('vms-ma-cta-type', normalizeCtaType(copy.cta_type || copy.cta_suggestion));
    }
    if (copy.force_buy_tickets_cta != null) {
      setChecked('vms-ma-force-buy-tickets', !!parseIntSafe(copy.force_buy_tickets_cta, 0));
    }
    if (copy.creative_automation_policy) {
      setField('vms-ma-creative-automation-policy', copy.creative_automation_policy);
    }
    if (copy.multi_advertiser_ads != null) {
      setChecked('vms-ma-multi-advertiser-ads', !!parseIntSafe(copy.multi_advertiser_ads, 0));
    }
    syncCtaLockUi();

    // Images (attachment IDs may be stored at top level or inside creative_assets).
    var creativeAssets = (copy.creative_assets && typeof copy.creative_assets === 'object') ? copy.creative_assets : {};
    var squareImageId = copy.image_square_id != null ? copy.image_square_id : creativeAssets.image_square_id;
    var verticalImageId = copy.image_vertical_id != null ? copy.image_vertical_id : creativeAssets.image_vertical_id;
    var wideImageId = copy.image_wide_id != null ? copy.image_wide_id : creativeAssets.image_wide_id;

    if (squareImageId != null) {
      setField('vms-ma-image-square-id', squareImageId);
      syncImagePreviewFromId('square');
    }
    if (verticalImageId != null) {
      setField('vms-ma-image-vertical-id', verticalImageId);
      syncImagePreviewFromId('vertical');
    }
    if (wideImageId != null) {
      setField('vms-ma-image-wide-id', wideImageId);
      syncImagePreviewFromId('wide');
    }

    var placements = (build.placements_payload && typeof build.placements_payload === 'object') ? build.placements_payload : {};
    var placementsMode = placements.mode || 'auto';
    setPlacementsMode(placementsMode);
    if (Array.isArray(placements.placements)) {
      document.querySelectorAll('.vms-ma-placement').forEach(function (el) {
        el.checked = placements.placements.indexOf(String(el.value)) !== -1;
      });
    }
    syncPlacementsUi();

    syncCreativeFields();
    syncDerivedState();
    if (auditLoadedBuildHydration(build)) {
      setSavedDraftStateFromPayload(collectPayload());
    } else {
      dirtyState.savedPayloadSignature = '__hydration_failed__';
      dirtyState.currentPayloadSignature = buildPayloadSignature(collectPayload());
      dirtyState.isDirty = true;
      renderDirtyStateNotice();
      resolveApiButtonsState();
    }
  }

  function fetchLatestDraftForEventPlan(eventPlanId, options) {
    var id = parseIntSafe(eventPlanId, 0);
    if (id < 1) {
      return Promise.resolve(null);
    }
    var promise = request('/ad-builds?event_plan_id=' + encodeURIComponent(id) + '&limit=1', 'GET')
      .then(function (json) {
        var items = (json && Array.isArray(json.items)) ? json.items : [];
        return items.length ? items[0] : null;
      })
      .catch(function () {
        return null;
      });
    var showOverlay = !(options && options.skipOverlay);
    if (showOverlay) {
      var message = (options && options.message) ? options.message : loadingText;
      return withLoadingOverlay(promise, message);
    }
    return promise;
  }

  function hydrateLatestDraft(eventPlanId) {
    return fetchLatestDraftForEventPlan(eventPlanId, { message: loadingText }).then(function (draft) {
      if (!draft) {
        setActiveBuildId('');
        dirtyState.savedPayloadSignature = '';
        updateDirtyState();
        refreshMetaStatus(true);
        return;
      }
      applyBuildData(draft);
      emitFeedback('info', 'Loaded latest draft values for this Event Plan.', 'g');
      refreshMetaStatus(true);
    });
  }

  function fetchEventPlanById(planId, options) {
    if (!planId || planId < 1 || !VMS_MA.eventPlansUrl) {
      return Promise.reject(new Error('Invalid Event Plan ID.'));
    }
    var fetchPromise = requestAbsolute(VMS_MA.eventPlansUrl + '/' + encodeURIComponent(planId)).then(function (json) {
      if (!json || !json.item) {
        throw new Error('Event Plan not found.');
      }
      return json.item;
    });
    var showOverlay = !(options && options.skipOverlay);
    if (showOverlay) {
      var message = (options && options.message) ? options.message : loadingText;
      return withLoadingOverlay(fetchPromise, message);
    }
    return fetchPromise;
  }

  function fetchEventPlanCollection(params, options) {
    if (!VMS_MA.eventPlansUrl) {
      return Promise.reject(new Error('Event Plan search is unavailable.'));
    }
    var searchParams = new URLSearchParams();
    var now = new Date();
    searchParams.set('after', String((params && params.after) || now.toISOString().slice(0, 10)));
    searchParams.set('days', String((params && params.days) || 180));
    searchParams.set('limit', String((params && params.limit) || builderPerf.seed_limit || 20));
    if (!params || params.group_meta_activity_last !== 0) {
      searchParams.set('group_meta_activity_last', '1');
    }
    var q = String((params && params.q) || '').trim();
    if (q) {
      searchParams.set('q', q);
    }
    var fetchPromise = requestAbsolute(VMS_MA.eventPlansUrl + '?' + searchParams.toString()).then(function (json) {
      return (json && Array.isArray(json.items)) ? json.items : [];
    });
    if (options && options.showOverlay) {
      return withLoadingOverlay(fetchPromise, (options && options.message) ? options.message : 'Searching Event Plans…');
    }
    return fetchPromise;
  }


  function formatMoney(value) {
    var num = Number(value || 0);
    if (!Number.isFinite(num)) {
      num = 0;
    }
    return '$' + num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function formatInt(value) {
    var num = parseIntSafe(value, 0);
    return num.toLocaleString();
  }

  function formatPct(value) {
    var num = Number(value || 0);
    if (!Number.isFinite(num)) {
      num = 0;
    }
    return num.toFixed(2) + '%';
  }

  function analyticsEl(id) {
    return byId(id);
  }

  function setAnalyticsMessage(message) {
    var meta = analyticsEl('vms-ma-analytics-meta');
    if (meta) {
      meta.textContent = String(message || '');
    }
  }

  function setAnalyticsWarnings(message) {
    var warning = analyticsEl('vms-ma-analytics-warnings');
    if (!warning) {
      return;
    }
    if (message) {
      warning.textContent = String(message);
      warning.classList.remove('vms-ma-hidden');
    } else {
      warning.textContent = '';
      warning.classList.add('vms-ma-hidden');
    }
  }

  function renderAnalyticsCards(summary) {
    var root = analyticsEl('vms-ma-analytics-cards');
    if (!root) {
      return;
    }
    var metrics = summary && typeof summary === 'object' ? summary : {};
    var cards = [
      ['Spend', formatMoney(metrics.spend || 0)],
      ['Impressions', formatInt(metrics.impressions || 0)],
      ['Reach', formatInt(metrics.reach || 0)],
      ['Link Clicks', formatInt(metrics.link_clicks || 0)],
      ['Link CTR', formatPct(metrics.link_ctr || 0)],
      ['Cost / Link Click', formatMoney(metrics.link_cpc || 0)],
      ['CPM', formatMoney(metrics.cpm || 0)],
      ['Frequency', Number(metrics.frequency || 0).toFixed(2)]
    ];
    root.innerHTML = cards.map(function (card) {
      return '<div class="vms-ma-performance-card"><span>' + escapeHtml(card[0]) + '</span><strong>' + escapeHtml(card[1]) + '</strong></div>';
    }).join('');
  }

  function renderAnalyticsTrend(trend) {
    var root = analyticsEl('vms-ma-analytics-trend');
    if (!root) {
      return;
    }
    var points = trend && Array.isArray(trend.points) ? trend.points : [];
    if (!points.length) {
      root.innerHTML = '<p class="description">Not enough recent daily data yet for a trend view.</p>';
      return;
    }
    var maxSpend = points.reduce(function (max, point) {
      return Math.max(max, Number(point && point.spend ? point.spend : 0));
    }, 0);
    root.innerHTML = '<h4>Daily Spend Trend</h4><div class="vms-ma-analytics-trend-points">' + points.slice(-14).map(function (point) {
      var spend = Number(point && point.spend ? point.spend : 0);
      var width = maxSpend > 0 ? Math.max(4, Math.round((spend / maxSpend) * 100)) : 4;
      var date = String(point && point.date ? point.date : '');
      var shortDate = date ? date.slice(5).replace('-', '/') : '';
      return '<div class="vms-ma-analytics-bar"><div class="vms-ma-analytics-bar-track"><div class="vms-ma-analytics-bar-fill" style="height:' + String(width) + '%"></div></div><div class="vms-ma-analytics-bar-meta"><strong>' + escapeHtml(shortDate) + '</strong><br>' + escapeHtml(formatMoney(spend)) + '<br>' + escapeHtml(formatPct(point && point.link_ctr ? point.link_ctr : 0)) + ' CTR</div></div>';
    }).join('') + '</div>';
  }

  function renderAnalyticsRecommendations(items) {
    var root = analyticsEl('vms-ma-analytics-recommendations');
    if (!root) {
      return;
    }
    if (!items || !items.length) {
      root.innerHTML = '<div class="vms-ma-analytics-reco"><strong>No strong strategy calls yet.</strong><span>Let the ad gather a bit more delivery, then refresh again.</span></div>';
      return;
    }
    root.innerHTML = items.map(function (item) {
      var severity = String((item && item.severity) || 'info');
      var title = String((item && item.title) || 'Strategy note');
      var message = String((item && item.message) || '');
      return '<div class="vms-ma-analytics-reco vms-ma-analytics-reco--' + escapeHtml(severity) + '"><strong>' + escapeHtml(title) + '</strong><span>' + escapeHtml(message) + '</span></div>';
    }).join('');
  }

  function renderAnalyticsTable(rootId, section) {
    var root = analyticsEl(rootId);
    if (!root) {
      return;
    }
    var rows = section && Array.isArray(section.rows) ? section.rows : [];
    var note = section && section.warning ? '<div class="vms-ma-analytics-note">' + escapeHtml(section.warning) + '</div>' : '';
    if (!rows.length) {
      root.innerHTML = '<p class="description">No data yet.</p>' + note;
      return;
    }
    root.innerHTML = '<table><thead><tr><th>Slice</th><th>Spend</th><th>Clicks</th><th>CTR</th><th>CPC</th></tr></thead><tbody>' + rows.slice(0, 8).map(function (row) {
      return '<tr><td>' + escapeHtml(String(row.label || '')) + '</td><td>' + escapeHtml(formatMoney(row.spend || 0)) + '</td><td>' + escapeHtml(formatInt(row.link_clicks || 0)) + '</td><td>' + escapeHtml(formatPct(row.link_ctr || 0)) + '</td><td>' + escapeHtml(formatMoney(row.link_cpc || 0)) + '</td></tr>';
    }).join('') + '</tbody></table>' + note;
  }

  function clearAnalyticsPanels(message) {
    setAnalyticsMessage(message || 'Choose an Event Plan and linked build to load analytics.');
    setAnalyticsWarnings('');
    renderAnalyticsCards({});
    renderAnalyticsRecommendations([]);
    renderAnalyticsTrend({ points: [] });
    renderAnalyticsTable('vms-ma-analytics-demographics', { rows: [] });
    renderAnalyticsTable('vms-ma-analytics-regions', { rows: [] });
    renderAnalyticsTable('vms-ma-analytics-placements', { rows: [] });
    renderAnalyticsTable('vms-ma-analytics-devices', { rows: [] });
  }

  function renderAnalyticsPayload(data) {
    analyticsState.payload = data || null;
    if (!data || !data.ok) {
      clearAnalyticsPanels((data && data.error) ? data.error : 'Analytics are not ready yet.');
      return;
    }
    var fetchedAt = data.fetched_at ? new Date(Number(data.fetched_at) * 1000) : null;
    var fetchedText = fetchedAt && !Number.isNaN(fetchedAt.getTime()) ? fetchedAt.toLocaleString() : 'just now';
    var cacheText = data.from_cache ? ' • cached snapshot' : '';
    setAnalyticsMessage('Showing ' + String((data.build && data.build.title) || 'linked Meta build') + ' over ' + String(analyticsState.preset || 'last_7').replace('last_', '').replace('_', ' ') + '. Last pulled ' + fetchedText + cacheText + '.');
    setAnalyticsWarnings(data.warning || data.error || '');
    renderAnalyticsCards(data.summary || {});
    renderAnalyticsRecommendations(Array.isArray(data.recommendations) ? data.recommendations : []);
    renderAnalyticsTrend(data.trend || {});
    renderAnalyticsTable('vms-ma-analytics-demographics', data.demographics || {});
    renderAnalyticsTable('vms-ma-analytics-regions', data.regions || {});
    renderAnalyticsTable('vms-ma-analytics-placements', data.placements || {});
    renderAnalyticsTable('vms-ma-analytics-devices', data.devices || {});
  }

  function loadAnalyticsForCurrentEvent(options) {
    options = options || {};
    var eventPlanId = getCurrentEventPlanId();
    if (!eventPlanId || !VMS_MA.analyticsUrl) {
      clearAnalyticsPanels('Choose an Event Plan and linked build to load analytics.');
      return Promise.resolve(null);
    }
    var buildId = parseIntSafe(getActiveBuildId(), 0);
    var finishPerf = startPerfTimer('analytics_refresh', {
      event_plan_id: eventPlanId,
      build_id: buildId,
      refresh: !!options.refresh
    });
    analyticsState.loading = true;
    setAnalyticsMessage('Loading analytics from Meta…');
    var url = VMS_MA.analyticsUrl + '?event_plan_id=' + encodeURIComponent(eventPlanId) + '&preset=' + encodeURIComponent(analyticsState.preset || 'last_7');
    if (buildId > 0) {
      url += '&build_id=' + encodeURIComponent(buildId);
    }
    if (options.refresh) {
      url += '&refresh=1';
    }
    return requestAbsolute(url).then(function (json) {
      finishPerf({
        ok: !!(json && json.ok),
        from_cache: !!(json && json.from_cache)
      });
      renderAnalyticsPayload(json || {});
      if (!options.silent && json && json.ok) {
        showToast('success', 'Analytics refreshed.');
      }
      return json;
    }).catch(function (err) {
      finishPerf({
        ok: false,
        error: String(err && err.message || 'Analytics could not be loaded.')
      });
      clearAnalyticsPanels((err && err.message) ? err.message : 'Analytics could not be loaded.');
      if (!options.silent) {
        emitFeedback('warning', (err && err.message) ? err.message : 'Analytics could not be loaded.', 'g');
      }
      return null;
    }).finally(function () {
      analyticsState.loading = false;
    });
  }

  function downloadAnalyticsBundle() {
    if (!analyticsState.payload || !analyticsState.payload.ok) {
      emitFeedback('warning', 'Load analytics first.', 'g');
      return;
    }
    var title = String((analyticsState.payload.build && analyticsState.payload.build.title) || 'meta-analytics').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    var filename = (title || 'meta-analytics') + '-' + String(analyticsState.preset || 'last_7') + '.json';
    downloadText(filename, JSON.stringify(analyticsState.payload, null, 2));
    showToast('success', 'Analysis bundle downloaded.');
  }

  function copyAnalyticsNotes() {
    var notes = analyticsState.payload && analyticsState.payload.strategy_notes ? String(analyticsState.payload.strategy_notes) : '';
    if (!notes) {
      emitFeedback('warning', 'No strategy notes available yet.', 'g');
      return;
    }
    copyText(notes).then(function () {
      showToast('success', 'Strategy notes copied.');
    }).catch(function () {
      emitFeedback('warning', 'Copy failed. Select and copy manually.', 'g');
    });
  }

  function initAnalyticsPanel() {
    clearAnalyticsPanels('Choose an Event Plan and linked build to load analytics.');
    builder.querySelectorAll('.vms-ma-analytics-range-btn').forEach(function (button) {
      button.addEventListener('click', function (evt) {
        evt.preventDefault();
        analyticsState.preset = String(button.getAttribute('data-range') || 'last_7');
        builder.querySelectorAll('.vms-ma-analytics-range-btn').forEach(function (node) {
          node.classList.toggle('is-active', node === button);
        });
        loadAnalyticsForCurrentEvent({ refresh: false, silent: true });
      });
    });
    var refreshBtn = analyticsEl('vms-ma-analytics-refresh');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        loadAnalyticsForCurrentEvent({ refresh: true, silent: false });
      });
    }
    var downloadBtn = analyticsEl('vms-ma-analytics-download');
    if (downloadBtn) {
      downloadBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        downloadAnalyticsBundle();
      });
    }
    var copyBtn = analyticsEl('vms-ma-analytics-copy-notes');
    if (copyBtn) {
      copyBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        copyAnalyticsNotes();
      });
    }
  }

  function eventResultText(item) {
    var parts = [];
    var prefix = '';
    if (item && item.meta_ads_picker_label) {
      prefix = '[' + String(item.meta_ads_picker_label) + '] ';
    }
    if (item && item.start_display) {
      parts.push(item.start_display);
    } else if (item && item.start_local) {
      parts.push(item.start_local);
    }
    if (item && item.venue_name) {
      parts.push(item.venue_name);
    }
    return prefix + (item.title || 'Event Plan #' + item.id) + (parts.length ? ' - ' + parts.join(' | ') : '');
  }

  function buildEventPlanOption(item, selected) {
    var option = new Option(eventResultText(item), String((item && item.id) || ''), !!selected, !!selected);
    option.setAttribute('data-event-item', JSON.stringify(item || {}));
    return option;
  }

  function initEventPicker() {
    var picker = byId('vms-ma-event-plan-picker');
    var searchInput = byId('vms-ma-event-plan-search');
    var searchButton = byId('vms-ma-event-plan-search-button');
    var searchReset = byId('vms-ma-event-plan-search-reset');
    var searchStatus = byId('vms-ma-event-plan-search-status');
    var manualId = byId('vms-ma-event-plan-id-manual');
    var manualVenue = byId('vms-ma-venue-id-manual');
    var hiddenPlan = byId('vms-ma-event-plan-id');
    var hiddenVenue = byId('vms-ma-venue-id');
    if (!picker || !hiddenPlan) {
      return;
    }

    function parseOptionItem(optionEl) {
      if (!optionEl) {
        return null;
      }
      var raw = optionEl.getAttribute('data-event-item') || '';
      if (!raw) {
        return null;
      }
      try {
        return JSON.parse(raw);
      } catch (e) {
        return null;
      }
    }

    var initialSeedItems = Array.prototype.slice.call(picker.options || []).map(parseOptionItem).filter(Boolean);

    function setSearchStatus(message, tone) {
      if (!searchStatus) {
        return;
      }
      searchStatus.textContent = String(message || '');
      searchStatus.classList.toggle('vms-ma-inline-warning', tone === 'warning' || tone === 'error');
    }

    function renderPickerItems(items, selectedId) {
      var keepId = String(selectedId || hiddenPlan.value || picker.value || '').trim();
      var preserved = null;
      if (lastEventContext && String(lastEventContext.id || '').trim() === keepId) {
        preserved = lastEventContext;
      }

      while (picker.options.length > 1) {
        picker.remove(1);
      }

      (Array.isArray(items) ? items : []).forEach(function (item) {
        if (!item || !item.id) {
          return;
        }
        picker.add(buildEventPlanOption(item, keepId === String(item.id)));
      });

      if (preserved && picker.querySelector('option[value="' + keepId + '"]') === null) {
        picker.add(buildEventPlanOption(preserved, true));
      }

      if (keepId && picker.querySelector('option[value="' + keepId + '"]')) {
        picker.value = keepId;
      }
    }

    function resetSeedPickerState() {
      renderPickerItems(initialSeedItems, picker.value);
      setSearchStatus('Showing ' + initialSeedItems.length + ' upcoming Event Plans from the read-only seed. Search loads more on demand.', '');
    }

    function loadEventPlanSearch(q) {
      var query = String(q || '').trim();
      if (!query) {
        resetSeedPickerState();
        return Promise.resolve(initialSeedItems);
      }
      setSearchStatus('Searching upcoming Event Plans…', '');
      return fetchEventPlanCollection({
        q: query,
        limit: builderPerf.seed_limit || initialSeedItems.length || 20
      }).then(function (items) {
        renderPickerItems(items, picker.value);
        if (items.length) {
          setSearchStatus('Showing ' + items.length + ' matching Event Plans. Selecting one loads its details read-only.', '');
        } else {
          setSearchStatus('No matching Event Plans found. Try a different search or use manual ID.', 'warning');
        }
        return items;
      }).catch(function () {
        setSearchStatus('Event Plan search failed. Use manual ID or retry the search.', 'error');
        return [];
      });
    }

    picker.addEventListener('change', function () {
      var selectedId = parseIntSafe(picker.value, 0);
      if (!selectedId) {
        hiddenPlan.value = '';
        dispatchFieldEvents(hiddenPlan);
        buildCache = [];
        renderBuildSelect([], '');
        setActiveBuildId('');
        dirtyState.savedPayloadSignature = '';
        ensureEventSelectionState();
        metaStatusState.hasIds = false;
        metaStatusState.anyActive = false;
        setMetaChip('campaign', 'UNKNOWN', 'UNKNOWN');
        setMetaChip('adset', 'UNKNOWN', 'UNKNOWN');
        setMetaChip('ad', 'UNKNOWN', 'UNKNOWN');
        renderMetaReadiness({});
        renderBudgetSyncState({});
        setMetaInline('Select an Event Plan to load Meta status.');
        resolveApiButtonsState();
        return;
      }
      var selectedOption = picker.options[picker.selectedIndex] || null;
      var fromOption = parseOptionItem(selectedOption);
      if (fromOption) {
        applyEventData(fromOption, 'picker');
        loadBuildsForEventPlan(fromOption.id, { skipAutoloadLatest: true });
        return;
      }
      fetchEventPlanById(selectedId, { message: loadingText }).then(function (item) {
        applyEventData(item, 'picker');
        loadBuildsForEventPlan(item.id, { skipAutoloadLatest: true });
      }).catch(function (err) {
        emitFeedback('error', err.message || 'Unable to load selected Event Plan.', 'a');
      });
    });

    if (manualVenue && hiddenVenue) {
      var mirrorVenue = function () {
        hiddenVenue.value = String(manualVenue.value || '').trim();
        dispatchFieldEvents(hiddenVenue);
      };
      manualVenue.addEventListener('change', mirrorVenue);
      manualVenue.addEventListener('blur', mirrorVenue);
    }

    if (manualId) {
      manualId.addEventListener('blur', function () {
        var id = parseIntSafe(manualId.value, 0);
        if (!id) {
          return;
        }
        fetchEventPlanById(id, { message: loadingText }).then(function (item) {
          if (picker.querySelector('option[value="' + item.id + '"]') === null) {
            picker.add(buildEventPlanOption(item, true));
          }
          picker.value = String(item.id);
          applyEventData(item, 'manual');
          loadBuildsForEventPlan(item.id, { skipAutoloadLatest: true });
        }).catch(function (err) {
          emitFeedback('error', err.message || 'Manual Event Plan ID could not be resolved.', 'a');
        });
      });
    }

    if (applyServerPrefill()) {
      ensureEventSelectionState();
      return;
    }

    var prefillId = parseIntSafe(builder.getAttribute('data-prefill-event-plan-id') || '', 0);
    if (prefillId > 0) {
      fetchEventPlanById(prefillId, { message: loadingText }).then(function (item) {
        if (picker.querySelector('option[value="' + item.id + '"]') === null) {
          picker.appendChild(buildEventPlanOption(item, true));
        }
        picker.value = String(item.id);
        applyEventData(item, 'prefill');
        loadBuildsForEventPlan(item.id, { skipAutoloadLatest: true });
      }).catch(function () {
        emitFeedback('warning', 'Could not prefill Event Plan from link. Select one manually.', 'a');
      });
    }

    if (searchButton) {
      searchButton.addEventListener('click', function (evt) {
        evt.preventDefault();
        loadEventPlanSearch(searchInput ? searchInput.value : '');
      });
    }

    if (searchReset) {
      searchReset.addEventListener('click', function (evt) {
        evt.preventDefault();
        if (searchInput) {
          searchInput.value = '';
        }
        resetSeedPickerState();
      });
    }

    if (searchInput) {
      searchInput.addEventListener('keydown', function (evt) {
        if (evt.key === 'Enter') {
          evt.preventDefault();
          loadEventPlanSearch(searchInput.value);
        }
      });
    }

    resetSeedPickerState();
    ensureEventSelectionState();
  }

  function hydratePostAndEventPickers() {
    if (!parseIntSafe(VMS_MA.apiReady, 0)) {
      return;
    }

    var postPicker = byId('vms-ma-post-picker');
    if (postPicker && VMS_MA.postAssetsUrl) {
      requestAbsolute(VMS_MA.postAssetsUrl + '?limit=30').then(function (json) {
        var items = (json && Array.isArray(json.items)) ? json.items : [];
        items.forEach(function (item) {
          var id = String(item.id || '');
          if (!id) {
            return;
          }
          var title = String(item.title || item.source_ref || ('Post #' + id));
          postPicker.appendChild(new Option(title, id));
        });
      }).catch(function () {
        // keep manual fallback
      });
    }

    var eventPicker = byId('vms-ma-fb-event-picker');
    if (eventPicker && VMS_MA.eventPlansUrl) {
      requestAbsolute(VMS_MA.eventPlansUrl + '?after=' + new Date().toISOString().slice(0, 10) + '&days=120&limit=30&group_meta_activity_last=1').then(function (json) {
        var items = (json && Array.isArray(json.items)) ? json.items : [];
        items.forEach(function (item) {
          var fallbackId = String(item.facebook_event_id || item.id || '');
          if (!fallbackId) {
            return;
          }
          eventPicker.appendChild(new Option(eventResultText(item), fallbackId));
        });
      }).catch(function () {
        // keep manual fallback
      });
    }
  }

  function saveDraft() {
    clampAudienceInputs(true);
    if (!guardLoadedBuildHydration('saving')) {
      return;
    }
    var payload = collectPayload();
    if (!payload.event_plan_id) {
      ensureEventSelectionState();
      emitFeedback('warning', 'Choose an Event Plan first so Step A can autofill required fields.', 'a');
      return;
    }

    request('/ad-builds', 'POST', payload).then(function (json) {
      var item = json.item || {};
      if (item.id) {
        buildIdInput.value = String(item.id);
      }
      renderTierPreview();
      renderCopyPackPanel();
      setSavedDraftStateFromPayload(collectPayload());
      emitFeedback('success', 'Draft saved at ' + new Date().toLocaleTimeString() + '.', 'g');
      return loadBuildsForEventPlan(payload.event_plan_id, { skipOverlay: true, selectedId: item.id, skipAutoloadLatest: true }).then(function () {
        return refreshMetaStatus(true);
      }).then(function () {
        return loadAnalyticsForCurrentEvent({ refresh: true, silent: true });
      });
    }).catch(function (err) {
      emitFeedback('error', err.message || 'Draft save failed.', 'g');
    });
  }

  function exportPack() {
    var id = parseIntSafe(value('vms-ma-build-id'), 0);
    if (!id) {
      emitFeedback('warning', 'Save the draft first.', 'g');
      return;
    }
    request('/ad-builds/' + id + '/export', 'POST', {}).then(function () {
      renderCopyPackPanel({ force: true });
      emitFeedback('success', 'Copy pack exported.', 'g');
    }).catch(function (err) {
      emitFeedback('error', err.message || 'Export failed.', 'g');
    });
  }

  function setDryRunStatus(message) {
    var node = byId('vms-ma-dry-run-status');
    if (!node) {
      return;
    }
    node.textContent = String(message || '');
  }

  function formatPlacementLabel(key) {
    key = String(key || '').trim();
    if (!key) {
      return '';
    }
    return placementLabelMap[key] || key.replace(/_/g, ' ');
  }

  function formatPlacementSummary(labels, keys) {
    if (Array.isArray(labels) && labels.length) {
      return labels.map(function (label) { return String(label || '').trim(); }).filter(Boolean).join(', ');
    }
    if (Array.isArray(keys) && keys.length) {
      return keys.map(formatPlacementLabel).filter(Boolean).join(', ');
    }
    return '';
  }

  function collectPlacementPreviewItems(json) {
    var source = Array.isArray(json && json.placements_overview) ? json.placements_overview : [];
    return source.map(function (item, index) {
      item = item && typeof item === 'object' ? item : {};
      var placementLabels = Array.isArray(item.placement_labels) ? item.placement_labels : [];
      var requestedLabels = Array.isArray(item.requested_placement_labels) ? item.requested_placement_labels : [];
      return {
        key: String(item.key || ('adset_' + (index + 1))).trim(),
        label: String(item.label || ('Ad Set ' + (index + 1))).trim(),
        effectiveModeLabel: String(item.effective_mode_label || item.requested_mode_label || '').trim(),
        requestedModeLabel: String(item.requested_mode_label || item.effective_mode_label || '').trim(),
        summary: String(item.summary || '').trim() || formatPlacementSummary(placementLabels, item.placement_keys),
        requestedSummary: String(item.requested_summary || '').trim() || formatPlacementSummary(requestedLabels, item.requested_placement_keys),
        requestedDiffers: !!item.requested_differs,
        count: parseIntSafe(item.count, placementLabels.length || 0)
      };
    }).filter(function (item) {
      return !!item.label;
    });
  }

  function renderDryRunInsights(json) {
    var node = byId('vms-ma-dry-run-insights');
    if (!node) {
      return;
    }
    var schedule = (json && typeof json.schedule_support === 'object' && json.schedule_support) ? json.schedule_support : null;
    var placements = collectPlacementPreviewItems(json || {});
    if (!schedule && !placements.length) {
      node.innerHTML = '';
      node.classList.add('vms-ma-hidden');
      return;
    }

    var cards = [];
    if (schedule) {
      var scheduleBits = [];
      scheduleBits.push(String(schedule.preset_label || schedule.preset_mode || 'Schedule').trim());
      scheduleBits.push(String(parseIntSafe(schedule.tier_count, 0)) + ' window' + (parseIntSafe(schedule.tier_count, 0) === 1 ? '' : 's'));
      scheduleBits.push(schedule.direct_create_supported ? 'Direct create supported' : 'Direct create blocked');
      if (schedule.window_label) {
        scheduleBits.push('Preview window: ' + String(schedule.window_label || '').trim());
      }
      cards.push(
        '<section class="vms-ma-dry-run-card">' +
          '<h4>Schedule support</h4>' +
          '<p>' + escapeHtml(scheduleBits.join(' · ')) + '</p>' +
          (schedule.message ? '<p class="description">' + escapeHtml(String(schedule.message || '')) + '</p>' : '') +
        '</section>'
      );
    }

    if (placements.length) {
      cards.push(
        '<section class="vms-ma-dry-run-card">' +
          '<h4>Placements</h4>' +
          '<ul>' +
            placements.map(function (item) {
              var detail = item.effectiveModeLabel ? (item.effectiveModeLabel + ': ' + (item.summary || 'Not available')) : (item.summary || 'Not available');
              var requested = '';
              if (item.requestedDiffers) {
                requested = '<br><small>Requested ' + escapeHtml(item.requestedModeLabel || 'placements') + ': ' + escapeHtml(item.requestedSummary || 'Not available') + '</small>';
              }
              return '<li><strong>' + escapeHtml(item.label) + ':</strong> ' + escapeHtml(detail) + ' <span class="vms-ma-dry-run-muted">(' + escapeHtml(String(item.count)) + ' placements)</span>' + requested + '</li>';
            }).join('') +
          '</ul>' +
        '</section>'
      );
    }

    node.innerHTML = cards.join('');
    node.classList.remove('vms-ma-hidden');
  }

  function renderMessageCard(nodeId, title, items, footer, tone) {
    var node = byId(nodeId);
    if (!node) {
      return;
    }
    var list = Array.isArray(items) ? items.map(function (item) {
      return String(item || '').trim();
    }).filter(Boolean) : [];
    if (!list.length) {
      node.innerHTML = '';
      node.classList.add('vms-ma-hidden');
      node.classList.remove('is-warning', 'is-info');
      return;
    }
    node.classList.remove('vms-ma-hidden');
    node.classList.toggle('is-warning', tone === 'warning');
    node.classList.toggle('is-info', tone !== 'warning');
    node.innerHTML =
      '<strong>' + escapeHtml(String(title || 'Update')) + '</strong>' +
      '<ul>' + list.map(function (item) {
        return '<li>' + escapeHtml(item) + '</li>';
      }).join('') + '</ul>' +
      (footer ? '<p class="description">' + escapeHtml(String(footer || '')) + '</p>' : '');
  }

  function renderActionBlockerSummary(payload) {
    var card = byId('vms-ma-action-blockers');
    if (!card) {
      return;
    }
    var data = payload && typeof payload === 'object' ? payload : {};
    var createBlockers = getCreatePausedBlockers();
    var dryRun = data.dryRun && typeof data.dryRun === 'object' ? data.dryRun : null;
    var dryRunWarnings = Array.isArray(dryRun && dryRun.warnings) ? dryRun.warnings.filter(Boolean) : [];
    var parts = [];
    card.classList.remove('is-success', 'is-warning', 'is-error');

    if (!createBlockers.length && !dryRunWarnings.length) {
      card.classList.add('is-success');
      card.innerHTML =
        '<strong>Create Paused is ready for the loaded build.</strong>' +
        '<p class="description">The builder will save the loaded build, then open a final confirmation modal before any Meta create call runs. Dry Run remains available as a safe local preview whenever you want troubleshooting detail.</p>';
      return;
    }

    if (!createBlockers.length && dryRunWarnings.length) {
      card.classList.add('is-warning');
      parts.push('<strong>Create Paused is available, but review these warnings first.</strong>');
      parts.push('<p class="description">Latest dry run warnings:</p>');
      parts.push('<ul>' + dryRunWarnings.map(function (warning) {
        return '<li>' + escapeHtml(warning) + '</li>';
      }).join('') + '</ul>');
      parts.push('<p class="description">Dry Run is still safe and does not contact Meta.</p>');
      card.innerHTML = parts.join('');
      return;
    }

    card.classList.add('is-error');
    parts.push('<strong>Create is blocked for the loaded build.</strong>');
    if (createBlockers.length) {
      parts.push('<p class="description">Fix these items before Create Paused can run:</p>');
      parts.push('<ul>' + createBlockers.map(function (item) {
        return '<li>' + escapeHtml(item.message) + '</li>';
      }).join('') + '</ul>');
    }
    if (createBlockers.some(function (item) { return item.code === 'linked_meta_ids'; })) {
      parts.push(buildCreateBlockerActionsHtml());
      parts.push('<p class="description">Duplicate as Fresh Draft keeps the settings but removes Meta IDs and link history from the new working copy. Scrap / Archive hides this build from the normal working list. Reset Meta Link only unlinks the saved Meta IDs from the current build.</p>');
    }
    if (dryRunWarnings.length) {
      parts.push('<p class="description">Latest dry run warnings:</p>');
      parts.push('<ul>' + dryRunWarnings.map(function (warning) {
        return '<li>' + escapeHtml(warning) + '</li>';
      }).join('') + '</ul>');
    }
    parts.push('<p class="description">Preview / Troubleshooting Dry Run is still safe and does not contact Meta.</p>');
    card.innerHTML = parts.join('');
  }

  function renderDryRunPreview(json) {
    var summaryNode = byId('vms-ma-dry-run-summary');
    var outputNode = byId('vms-ma-dry-run-output');
    var panel = byId('vms-ma-dry-run-panel');
    var ready = !!(json && json.create_ready);
    lastDryRunResponse = json && typeof json === 'object' ? json : null;
    if (summaryNode) {
      var summary = (json && typeof json.summary === 'object' && json.summary) ? json.summary : {};
      var blockers = Array.isArray(json && json.blockers) ? json.blockers.length : 0;
      var warnings = Array.isArray(json && json.warnings) ? json.warnings.length : 0;
      var pills = [];
      pills.push('<span class="vms-ma-dry-run-pill ' + (ready ? 'is-ready' : 'is-blocked') + '">' + escapeHtml(ready ? 'Create ready' : 'Create blocked') + '</span>');
      pills.push('<span class="vms-ma-dry-run-pill">Campaigns ' + escapeHtml(String(parseIntSafe(summary.campaign_requests, 0))) + '</span>');
      pills.push('<span class="vms-ma-dry-run-pill">Ad sets ' + escapeHtml(String(parseIntSafe(summary.adset_requests, 0))) + '</span>');
      pills.push('<span class="vms-ma-dry-run-pill">Creatives ' + escapeHtml(String(parseIntSafe(summary.creative_requests, 0))) + '</span>');
      pills.push('<span class="vms-ma-dry-run-pill">Ads ' + escapeHtml(String(parseIntSafe(summary.ad_requests, 0))) + '</span>');
      pills.push('<span class="vms-ma-dry-run-pill">Image uploads ' + escapeHtml(String(parseIntSafe(summary.image_upload_requests, 0))) + '</span>');
      pills.push('<span class="vms-ma-dry-run-pill">Video uploads ' + escapeHtml(String(parseIntSafe(summary.video_upload_requests, 0))) + '</span>');
      pills.push('<span class="vms-ma-dry-run-pill">Blockers ' + escapeHtml(String(blockers)) + '</span>');
      pills.push('<span class="vms-ma-dry-run-pill">Warnings ' + escapeHtml(String(warnings)) + '</span>');
      summaryNode.innerHTML = pills.join('');
    }
    if (outputNode) {
      outputNode.textContent = JSON.stringify(json || {}, null, 2);
    }
    renderMessageCard(
      'vms-ma-dry-run-blockers',
      ready ? 'Create looks ready in this preview.' : 'Cannot create in Meta yet.',
      Array.isArray(json && json.blockers) ? json.blockers : [],
      ready ? 'This preview is still local-only and does not contact Meta.' : 'Dry Run is still safe and does not contact Meta.',
      'warning'
    );
    renderMessageCard(
      'vms-ma-dry-run-warnings',
      'Warnings to review before any later Meta use',
      Array.isArray(json && json.warnings) ? json.warnings : [],
      '',
      'info'
    );
    renderActionBlockerSummary({
      dryRun: lastDryRunResponse
    });
    renderDryRunInsights(json || {});
    if (panel) {
      panel.open = true;
    }
    setDryRunStatus((json && json.message) ? json.message : 'Meta dry run generated. No Meta API calls were made.');
  }

  function previewMetaDryRun() {
    clampAudienceInputs(true);
    if (!guardLoadedBuildHydration('running Meta Dry Run')) {
      setDryRunStatus(getBuildHydrationGuardMessage('running Meta Dry Run'));
      return;
    }
    var latestPayload = collectPayload();
    if (!latestPayload.event_plan_id) {
      ensureEventSelectionState();
      emitFeedback('warning', 'Choose an Event Plan first so Step A can autofill required fields.', 'a');
      return;
    }

    var lifetimeClamp = parseIntSafe(VMS_MA.budgetMaxLifetimeMinor, 0);
    if (latestPayload.total_budget_minor > lifetimeClamp) {
      emitFeedback('error', 'Total budget exceeds configured lifetime clamp.', 'e');
      return;
    }

    var dryRunBtn = byId('vms-ma-meta-dry-run');
    setActionBusy(dryRunBtn, true, 'Building Dry Run…', 'Preview / Troubleshooting Dry Run');
    setDryRunStatus('Saving the latest draft settings before generating the Meta dry run preview…');

    request('/ad-builds', 'POST', latestPayload).then(function (saveJson) {
      var item = (saveJson && saveJson.item) ? saveJson.item : {};
      var id = parseIntSafe(item.id || latestPayload.id, 0);
      if (!id) {
        throw new Error('Draft save returned no build ID.');
      }
      if (buildIdInput) {
        buildIdInput.value = String(id);
      }
      renderTierPreview();
      renderCopyPackPanel();
      setSavedDraftStateFromPayload(collectPayload());
      setDryRunStatus('Generating dry run preview. No Meta API calls will be made.');
      return request('/ad-builds/' + id + '/meta-dry-run', 'POST', {});
    }).then(function (json) {
      renderDryRunPreview(json || {});
      emitFeedback('success', (json && json.message) ? json.message : 'Meta dry run generated.', 'g');
      if (window.dispatchEvent && typeof window.CustomEvent === 'function') {
        window.dispatchEvent(new CustomEvent('vms:api-attempt-updated'));
      }
    }).catch(function (err) {
      setDryRunStatus(err && err.message ? err.message : 'Meta dry run failed.');
      emitFeedback('error', err.message || 'Meta dry run failed.', 'g');
    }).finally(function () {
      setActionBusy(dryRunBtn, false, 'Building Dry Run…', 'Preview / Troubleshooting Dry Run');
    });
  }

  function isActionGated(buttonId) {
    var btn = byId(buttonId);
    if (!btn) {
      return false;
    }
    return btn.getAttribute('data-gated') === '1';
  }

  function createPaused() {
    var blockers = getCreatePausedBlockers();
    if (blockers.length) {
      renderActionBlockerSummary({ dryRun: lastDryRunResponse });
      emitFeedback('warning', blockers[0].message, 'g');
      return;
    }
    if (!ensureBudgetFloorForMetaAction('Create in Meta')) {
      return;
    }

    clampAudienceInputs(true);
    var latestPayload = collectPayload();
    if (!latestPayload.event_plan_id) {
      ensureEventSelectionState();
      emitFeedback('warning', 'Choose an Event Plan first so Step A can autofill required fields.', 'a');
      return;
    }

    var lifetimeClamp = parseIntSafe(VMS_MA.budgetMaxLifetimeMinor, 0);
    if (latestPayload.total_budget_minor > lifetimeClamp) {
      emitFeedback('error', 'Total budget exceeds configured lifetime clamp.', 'e');
      return;
    }

    if (!openCreatePreflightModal(latestPayload)) {
      emitFeedback('warning', 'Create confirmation modal is unavailable on this screen. Reload the builder before creating paused Meta objects.', 'g');
    }
  }

  function submitCreatePaused() {
    var blockers = getCreatePausedBlockers();
    if (blockers.length) {
      closeCreatePreflightModal();
      renderActionBlockerSummary({ dryRun: lastDryRunResponse });
      emitFeedback('warning', blockers[0].message, 'g');
      return;
    }
    var confirmCheck = byId('vms-ma-create-confirm-paused');
    if (!(confirmCheck && confirmCheck.checked)) {
      emitFeedback('warning', 'Confirm that you understand Create in Meta can create real paused Meta objects before continuing.', 'g');
      return;
    }

    clampAudienceInputs(true);
    var latestPayload = collectPayload();
    var expectedBuildId = getLoadedBuildId();
    if (!latestPayload.event_plan_id) {
      ensureEventSelectionState();
      emitFeedback('warning', 'Choose an Event Plan first so Step A can autofill required fields.', 'a');
      return;
    }
    if (expectedBuildId < 1 || parseIntSafe(latestPayload.id, 0) !== expectedBuildId) {
      emitFeedback('warning', 'Load a saved campaign draft first. Create Paused only runs against the build currently loaded in the builder.', 'g');
      return;
    }

    var lifetimeClamp = parseIntSafe(VMS_MA.budgetMaxLifetimeMinor, 0);
    if (latestPayload.total_budget_minor > lifetimeClamp) {
      emitFeedback('error', 'Total budget exceeds configured lifetime clamp.', 'e');
      return;
    }

    var createBtn = byId('vms-ma-create-paused');
    var goLiveBtn = byId('vms-ma-go-live');
    var syncBudgetBtn = byId('vms-ma-sync-budget');
    var pauseBtn = byId('vms-ma-pause-all');
    var refreshBtn = byId('vms-ma-refresh-status');
    var resetBtn = byId('vms-ma-reset-meta-link');
    var createModalConfirmBtn = byId('vms-ma-create-preflight-confirm');
    metaStatusState.inFlight = true;
    setActionBusy(createBtn, true, 'Creating in Meta…', 'Create in Meta (PAUSED)');
    setActionBusy(createModalConfirmBtn, true, 'Creating…', 'Create paused objects');
    if (goLiveBtn) {
      goLiveBtn.disabled = true;
    }
    if (syncBudgetBtn) {
      syncBudgetBtn.disabled = true;
    }
    if (pauseBtn) {
      pauseBtn.disabled = true;
    }
    if (refreshBtn) {
      refreshBtn.disabled = true;
    }
    if (resetBtn) {
      resetBtn.disabled = true;
    }
    closeCreatePreflightModal();
    showLoadingOverlay('Saving the latest draft settings before creating paused Meta assets…');
    setMetaInline('Saving the latest draft settings before creating paused Meta assets…');
    emitFeedback('info', 'Create Paused started. MAB is saving the draft and preparing the paused Meta request now.', 'g');
    clearMetaCreateGuidance();
    resolveApiButtonsState();

    request('/ad-builds', 'POST', latestPayload).then(function (saveJson) {
      var item = (saveJson && saveJson.item) ? saveJson.item : {};
      var id = parseIntSafe(item.id || latestPayload.id, 0);
      if (!id) {
        throw new Error('Draft save returned no build ID.');
      }
      if (id !== expectedBuildId) {
        throw new Error('Create Paused only works from the build currently loaded in the builder. Save or reload that draft, then try again.');
      }
      if (buildIdInput) {
        buildIdInput.value = String(id);
      }
      renderTierPreview();
      renderCopyPackPanel();
      setSavedDraftStateFromPayload(collectPayload());
      setLoadingOverlayMessage('Creating paused campaign, ad sets, creatives, and ads in Meta…');
      setMetaInline('Creating paused campaign, ad sets, creatives, and ads in Meta…');
      return request('/ad-builds/' + id + '/meta-create', 'POST', {
        confirm_create_paused: true
      });
    }).then(function (json) {
      if (json && json.campaign && json.adset && json.ad) {
        applyMetaStatusResponse(json, (json && json.message) ? json.message : 'Create in Meta completed.');
      } else {
        setMetaInline((json && json.message) ? json.message : 'Create in Meta completed.');
      }
      clearMetaCreateGuidance();
      emitFeedback('success', (json && json.message) ? json.message : 'Meta assets created in PAUSED status.', 'g');
      metaStatusState.hasIds = true;
      dirtyState.isDirty = false;
      resolveApiButtonsState();
      return refreshMetaStatus(true).then(function () {
        return loadAnalyticsForCurrentEvent({ refresh: true, silent: true });
      });
    }).catch(function (err) {
      renderMetaCreateGuidance(err && err.data ? err.data : null);
      if (err && err.code === 'confirmation_required') {
        emitFeedback('warning', err.message || 'Create confirmation is required.', 'g');
        return;
      }
      emitFeedback('error', err.message || 'Create request failed.', 'g');
      setMetaInline(err && err.message ? err.message : 'Create request failed.');
    }).finally(function () {
      metaStatusState.inFlight = false;
      hideLoadingOverlay();
      setActionBusy(createBtn, false, 'Creating in Meta…', 'Create in Meta (PAUSED)');
      setActionBusy(createModalConfirmBtn, false, 'Creating…', 'Create paused objects');
      if (refreshBtn) {
        refreshBtn.disabled = false;
      }
      if (resetBtn) {
        resetBtn.disabled = false;
      }
      resolveApiButtonsState();
      if (window.dispatchEvent && typeof window.CustomEvent === 'function') {
        window.dispatchEvent(new CustomEvent('vms:api-attempt-updated'));
      }
    });
  }


  function resetMetaLink() {
    var id = parseIntSafe(value('vms-ma-build-id'), 0);
    if (!id) {
      emitFeedback('warning', 'Save the draft first.', 'g');
      return;
    }
    if (!window.confirm('Forget the saved Meta IDs for this Event Plan and build? This will not delete anything in Meta.')) {
      return;
    }

    var resetBtn = byId('vms-ma-reset-meta-link');
    var createBtn = byId('vms-ma-create-paused');
    var goLiveBtn = byId('vms-ma-go-live');
    var syncBudgetBtn = byId('vms-ma-sync-budget');
    var pauseBtn = byId('vms-ma-pause-all');
    var refreshBtn = byId('vms-ma-refresh-status');
    var resetBtn = byId('vms-ma-reset-meta-link');

    setActionBusy(resetBtn, true, 'Resetting…', 'Reset Meta Link');
    if (createBtn) { createBtn.disabled = true; }
    if (goLiveBtn) { goLiveBtn.disabled = true; }
    if (pauseBtn) { pauseBtn.disabled = true; }
    if (refreshBtn) { refreshBtn.disabled = true; }
    setMetaInline('Resetting saved Meta IDs for this Event Plan…');

    request('/ad-builds/' + id + '/meta-reset', 'POST', {}).then(function (json) {
      clearMetaCreateGuidance();
      applyMetaStatusResponse(json, (json && json.message) ? json.message : 'Meta link reset.');
      metaStatusState.hasIds = false;
      metaStatusState.anyActive = false;
      emitFeedback('success', (json && json.message) ? json.message : 'Meta link reset.', 'g');
      resolveApiButtonsState();
      loadAnalyticsForCurrentEvent({ refresh: true, silent: true });
    }).catch(function (err) {
      emitFeedback('error', err.message || 'Meta link reset failed.', 'g');
      setMetaInline(err && err.message ? err.message : 'Meta link reset failed.');
    }).finally(function () {
      setActionBusy(resetBtn, false, 'Resetting…', 'Reset Meta Link');
      metaStatusState.inFlight = false;
      if (createBtn) { createBtn.disabled = false; }
      if (goLiveBtn) { goLiveBtn.disabled = false; }
      if (pauseBtn) { pauseBtn.disabled = false; }
      if (refreshBtn) { refreshBtn.disabled = false; }
      resolveApiButtonsState();
      if (window.dispatchEvent && typeof window.CustomEvent === 'function') {
        window.dispatchEvent(new CustomEvent('vms:api-attempt-updated'));
      }
    });
  }

  function refreshMetaStatus(silent) {
    var eventPlanId = getCurrentEventPlanId();
    var buildId = parseIntSafe(value('vms-ma-build-id'), 0);
    if (!eventPlanId) {
      metaStatusState.hasIds = false;
      setMetaInline('Choose an Event Plan first.');
      resolveApiButtonsState();
      return Promise.resolve(null);
    }
    if (buildId < 1) {
      clearBuildStatusUi('Select or save a linked build first to load Meta status for it.');
      resolveApiButtonsState();
      return Promise.resolve(null);
    }

    var finishPerf = startPerfTimer('meta_status_refresh', {
      event_plan_id: eventPlanId,
      build_id: buildId,
      silent: !!silent
    });
    return request('/meta-status?build_id=' + encodeURIComponent(buildId) + '&event_plan_id=' + encodeURIComponent(eventPlanId), 'GET').then(function (json) {
      finishPerf({
        ok: true,
        has_ids: !!(json && json.has_ids)
      });
      applyMetaStatusResponse(json, 'Meta status refreshed.');
      if (!silent) {
        emitFeedback('success', 'Meta status refreshed.', 'g');
      }
      resolveApiButtonsState();
      return json;
    }).catch(function (err) {
      finishPerf({
        ok: false,
        error: String(err && err.message || 'Unable to refresh Meta status.')
      });
      metaStatusState.loaded = false;
      metaStatusState.hasIds = false;
      metaStatusState.anyActive = false;
      metaStatusState.lastError = err && err.message ? String(err.message) : 'Unable to refresh Meta status.';
      setMetaInline(metaStatusState.lastError);
      updateMetaLink({});
      setMetaChip('campaign', 'UNKNOWN', 'UNKNOWN');
      setMetaChip('adset', 'UNKNOWN', 'UNKNOWN');
      setMetaChip('ad', 'UNKNOWN', 'UNKNOWN');
      renderMetaReadiness({});
      renderBudgetSyncState({});
      renderDriftState({});
      if (!silent) {
        emitFeedback('warning', metaStatusState.lastError, 'g');
      }
      resolveApiButtonsState();
      return null;
    });
  }

  function collectGoLiveSummaryHtml() {
    var account = String(VMS_MA.adAccountId || '').replace(/^act_/, '').trim();
    var objective = value('vms-ma-goal') || 'traffic';
    var optimization = value('vms-ma-optimization') || (objective === 'sales' ? 'purchase_conversions' : 'link_clicks');
    var scheduleStart = value('vms-ma-sched-start') || 'Not set';
    var scheduleEnd = value('vms-ma-sched-end') || 'Not set';
    var budget = value('vms-ma-budget-total') || '0.00';
    var audienceSnapshot = buildAudiencePreviewSnapshot();
    var audienceSummaryBits = [
      audienceSnapshot.modeLabel,
      audienceSnapshot.radius + 'mi',
      'ages ' + audienceSnapshot.ageMin + '-' + (audienceSnapshot.ageMax === 65 ? '65+' : audienceSnapshot.ageMax),
      audienceSnapshot.genderLabel
    ];
    if (audienceSnapshot.activeTerms.length) {
      audienceSummaryBits.push(audienceSnapshot.activeTerms.map(function (term) {
        return term.label;
      }).join(', '));
    }
    var destination = value('vms-ma-destination-url') || '';

    var rows = [];
    rows.push('<div><strong>Ad Account:</strong> ' + escapeHtml(account ? ('act_' + account) : 'Unknown') + '</div>');
    rows.push('<div><strong>Objective:</strong> ' + escapeHtml(objective + ' / ' + optimization) + '</div>');
    rows.push('<div><strong>Schedule:</strong> ' + escapeHtml(scheduleStart + ' to ' + scheduleEnd) + '</div>');
    rows.push('<div><strong>Total budget:</strong> $' + escapeHtml(budget) + '</div>');
    var liveTiers = buildTierSchedule();
    if (liveTiers.length) {
      var liveRuntimeMs = getRuntimeMs(liveTiers[0].start, liveTiers[liveTiers.length - 1].end);
      var liveBudgetMinor = liveTiers.reduce(function (sum, tier) { return sum + parseIntSafe(tier.budgetMinor, 0); }, 0);
      rows.push('<div><strong>Run time:</strong> ' + escapeHtml(formatRunTime(liveRuntimeMs) + ' (~' + formatApproxDays(liveRuntimeMs) + ' days)') + '</div>');
      rows.push('<div><strong>Avg/day:</strong> ' + escapeHtml(formatBudgetPerDay(liveBudgetMinor, liveRuntimeMs)) + '</div>');
    }
    rows.push('<div><strong>Targeting:</strong> ' + escapeHtml(audienceSummaryBits.join(' • ')) + '</div>');
    if (audienceSnapshot.warnings.length) {
      rows.push('<div><strong>Audience warnings:</strong> ' + escapeHtml(audienceSnapshot.warnings.join(' | ')) + '</div>');
    }
    rows.push('<div><strong>Destination URL:</strong> ' + escapeHtml(destination) + '</div>');
    rows.push('<div class="vms-ma-preflight-manual-checks"><strong>Manual Meta checks before publishing:</strong><ul><li>Confirm Website Highlights / Web Highlight / Show Spotlights are off.</li><li>Confirm Multi-advertiser ads stayed off on each ad.</li><li>Confirm Feed static ads use square images, Feed Video ads use 1:1 video, and Reels/Stories ads use portrait video.</li><li>Confirm the schedule timezone matches the venue/event timezone.</li></ul></div>');
    return rows.join('');
  }

  function closeLiveModals() {
    var preflight = byId('vms-ma-live-preflight-modal');
    var finalModal = byId('vms-ma-live-final-modal');
    if (preflight) {
      preflight.classList.add('vms-ma-hidden');
    }
    if (finalModal) {
      finalModal.classList.add('vms-ma-hidden');
    }
  }

  function syncLivePreflightContinueState() {
    var c1 = byId('vms-ma-live-confirm-spend');
    var c2 = byId('vms-ma-live-confirm-review');
    var continueBtn = byId('vms-ma-live-preflight-continue');
    if (!continueBtn) {
      return;
    }
    continueBtn.disabled = !(c1 && c1.checked && c2 && c2.checked);
  }

  function openGoLivePreflightModal() {
    var modal = byId('vms-ma-live-preflight-modal');
    var summary = byId('vms-ma-live-preflight-summary');
    var c1 = byId('vms-ma-live-confirm-spend');
    var c2 = byId('vms-ma-live-confirm-review');
    if (!modal || !summary) {
      return;
    }
    summary.innerHTML = collectGoLiveSummaryHtml();
    if (c1) {
      c1.checked = false;
    }
    if (c2) {
      c2.checked = false;
    }
    syncLivePreflightContinueState();
    modal.classList.remove('vms-ma-hidden');
  }

  function openGoLiveFinalModal() {
    var modal = byId('vms-ma-live-final-modal');
    if (!modal) {
      return;
    }
    modal.classList.remove('vms-ma-hidden');
  }

  function submitGoLive() {
    var eventPlanId = getCurrentEventPlanId();
    var buildId = parseIntSafe(value('vms-ma-build-id'), 0);
    if (!eventPlanId) {
      emitFeedback('warning', 'Choose an Event Plan first.', 'g');
      return;
    }
    if (buildId < 1) {
      emitFeedback('warning', 'Select or save a linked build first.', 'g');
      return;
    }

    var goLiveBtn = byId('vms-ma-go-live');
    var finalBtn = byId('vms-ma-live-final-confirm');
    var pauseBtn = byId('vms-ma-pause-all');
    var refreshBtn = byId('vms-ma-refresh-status');
    var resetBtn = byId('vms-ma-reset-meta-link');
    metaStatusState.inFlight = true;
    resolveApiButtonsState();
    setActionBusy(goLiveBtn, true, 'Publishing…', 'Go Live');
    setActionBusy(finalBtn, true, 'Publishing…', 'Go Live');
    if (pauseBtn) {
      pauseBtn.disabled = true;
    }
    if (refreshBtn) {
      refreshBtn.disabled = true;
    }
    setMetaInline('Publishing to Meta…');

    request('/go-live', 'POST', {
      event_plan_id: eventPlanId,
      build_id: buildId,
      confirm_spend: true,
      confirm_reviewed: true
    }).then(function (json) {
      applyMetaStatusResponse(json, 'Go Live completed.');
      closeLiveModals();
      if (json && json.ok) {
        emitFeedback('success', 'Ad is LIVE in Meta (Active).', 'g');
      } else if (json && json.rolled_back) {
        emitFeedback('warning', 'Go Live failed and we attempted rollback.', 'g');
      } else {
        emitFeedback('error', (json && json.message) ? json.message : 'Go Live failed.', 'g');
      }
      if (json && json.delivery_warning) {
        emitFeedback('warning', json.delivery_warning, 'g');
      }
      return refreshMetaStatus(true).then(function () {
        return loadAnalyticsForCurrentEvent({ refresh: true, silent: true });
      });
    }).catch(function (err) {
      emitFeedback('error', 'Go Live failed: ' + (err.message || 'Unknown error') + '.', 'g');
      setMetaInline('Go Live failed. Nothing was published or rollback was attempted.');
    }).finally(function () {
      metaStatusState.inFlight = false;
      setActionBusy(goLiveBtn, false, 'Publishing…', 'Go Live');
      setActionBusy(finalBtn, false, 'Publishing…', 'Go Live');
      if (refreshBtn) {
        refreshBtn.disabled = false;
      }
      resolveApiButtonsState();
    });
  }

  function goLive() {
    if (isActionGated('vms-ma-go-live')) {
      modalOpen('Go Live is disabled in 0.1.107. This release supports owner-confirmed paused Meta draft creation only.');
      emitFeedback('warning', 'Go Live is disabled in this release.', 'g');
      return;
    }
    if (dirtyState.isDirty) {
      emitFeedback('warning', 'Save Draft first so Go Live uses the latest settings.', 'g');
      return;
    }

    var eventPlanId = getCurrentEventPlanId();
    if (!eventPlanId) {
      emitFeedback('warning', 'Choose an Event Plan first.', 'g');
      return;
    }
    if (!ensureBudgetFloorForMetaAction('Go Live')) {
      return;
    }
    if (!isCreativeLockdownLocalClean()) {
      emitFeedback('warning', 'Creative Lockdown requires Advantage+ creative policy Off and Multi-advertiser ads Off before Go Live.', 'c');
      return;
    }
    var missingQa = getLaunchQaMissingMessages();
    if (missingQa.length) {
      emitFeedback('warning', 'Finish manual launch QA before Go Live: ' + missingQa[0], 'g');
      return;
    }
    openGoLivePreflightModal();
  }

  function updateExistingMetaAd() {
    var id = parseIntSafe(value('vms-ma-build-id'), 0);
    if (!id) {
      emitFeedback('warning', 'Save the draft first.', 'g');
      return;
    }
    if (dirtyState.isDirty) {
      emitFeedback('warning', 'Save Draft first so Update Existing Meta Ad uses the latest settings.', 'g');
      return;
    }
    if (!ensureBudgetFloorForMetaAction('Update Existing Meta Ad')) {
      return;
    }

    var updateBtn = byId('vms-ma-update-existing');
    var refreshBtn = byId('vms-ma-refresh-status');
    var pauseBtn = byId('vms-ma-pause-all');
    var syncBtn = byId('vms-ma-sync-budget');
    var createBtn = byId('vms-ma-create-paused');
    var goLiveBtn = byId('vms-ma-go-live');
    metaStatusState.inFlight = true;
    setActionBusy(updateBtn, true, 'Updating Meta…', 'Update Existing Meta Ad');
    if (refreshBtn) {
      refreshBtn.disabled = true;
    }
    if (pauseBtn) {
      pauseBtn.disabled = true;
    }
    if (syncBtn) {
      syncBtn.disabled = true;
    }
    if (createBtn) {
      createBtn.disabled = true;
    }
    if (goLiveBtn) {
      goLiveBtn.disabled = true;
    }
    setMetaInline('Updating the selected linked Meta build from the latest saved draft…');
    resolveApiButtonsState();

    request('/ad-builds/' + id + '/meta-update', 'POST', {}).then(function (json) {
      applyMetaStatusResponse(json, (json && json.message) ? json.message : 'Linked Meta assets updated.');
      emitFeedback('success', (json && json.message) ? json.message : 'Linked Meta assets updated.', 'g');
      if (json && Array.isArray(json.warnings)) {
        json.warnings.forEach(function (warning) {
          if (warning) {
            emitFeedback('warning', String(warning), 'g');
          }
        });
      }
      return refreshMetaStatus(true).then(function () {
        return loadAnalyticsForCurrentEvent({ refresh: true, silent: true });
      });
    }).catch(function (err) {
      emitFeedback('error', err.message || 'Meta update failed.', 'g');
    }).finally(function () {
      metaStatusState.inFlight = false;
      setActionBusy(updateBtn, false, 'Updating Meta…', 'Update Existing Meta Ad');
      if (refreshBtn) {
        refreshBtn.disabled = false;
      }
      resolveApiButtonsState();
    });
  }

  function syncBudget() {
    var id = parseIntSafe(value('vms-ma-build-id'), 0);
    if (!id) {
      emitFeedback('warning', 'Save the draft first.', 'g');
      return;
    }
    if (dirtyState.isDirty) {
      emitFeedback('warning', 'Save Draft first so budget sync uses the latest settings.', 'g');
      return;
    }
    if (!ensureBudgetFloorForMetaAction('Sync Budget')) {
      return;
    }

    var syncBtn = byId('vms-ma-sync-budget');
    var refreshBtn = byId('vms-ma-refresh-status');
    var pauseBtn = byId('vms-ma-pause-all');
    metaStatusState.inFlight = true;
    setActionBusy(syncBtn, true, 'Syncing Budget…', 'Sync Budget to Meta');
    if (refreshBtn) {
      refreshBtn.disabled = true;
    }
    if (pauseBtn) {
      pauseBtn.disabled = true;
    }
    setMetaInline('Syncing the selected build budget to Meta…');
    resolveApiButtonsState();

    request('/ad-builds/' + id + '/meta-sync-budget', 'POST', {}).then(function (json) {
      applyMetaStatusResponse(json, (json && json.message) ? json.message : 'Budget sync completed.');
      if (json && json.changed) {
        emitFeedback('success', (json && json.message) ? json.message : 'Budget synced to Meta.', 'g');
      } else {
        emitFeedback('info', (json && json.message) ? json.message : 'Budget already matched Meta.', 'g');
      }
      return refreshMetaStatus(true).then(function () {
        return loadAnalyticsForCurrentEvent({ refresh: true, silent: true });
      });
    }).catch(function (err) {
      emitFeedback('error', err.message || 'Budget sync failed.', 'g');
    }).finally(function () {
      metaStatusState.inFlight = false;
      setActionBusy(syncBtn, false, 'Syncing Budget…', 'Sync Budget to Meta');
      if (refreshBtn) {
        refreshBtn.disabled = false;
      }
      resolveApiButtonsState();
    });
  }

  function pauseAll() {
    var eventPlanId = getCurrentEventPlanId();
    var buildId = parseIntSafe(value('vms-ma-build-id'), 0);
    if (!eventPlanId) {
      emitFeedback('warning', 'Choose an Event Plan first.', 'g');
      return;
    }
    if (buildId < 1) {
      emitFeedback('warning', 'Select or save a linked build first.', 'g');
      return;
    }
    var pauseBtn = byId('vms-ma-pause-all');
    var refreshBtn = byId('vms-ma-refresh-status');
    var resetBtn = byId('vms-ma-reset-meta-link');
    metaStatusState.inFlight = true;
    setActionBusy(pauseBtn, true, 'Pausing…', 'Pause All');
    if (refreshBtn) {
      refreshBtn.disabled = true;
    }
    setMetaInline('Pausing campaign, ad set, and ad for the selected build…');
    resolveApiButtonsState();
    request('/pause-all', 'POST', { event_plan_id: eventPlanId, build_id: buildId }).then(function (json) {
      applyMetaStatusResponse(json, 'Pause All completed.');
      if (json && json.ok) {
        emitFeedback('success', 'All Meta assets paused.', 'g');
      } else {
        emitFeedback('warning', (json && json.message) ? json.message : 'Pause All completed with issues.', 'g');
      }
      return refreshMetaStatus(true);
    }).catch(function (err) {
      emitFeedback('error', err.message || 'Pause All failed.', 'g');
    }).finally(function () {
      metaStatusState.inFlight = false;
      setActionBusy(pauseBtn, false, 'Pausing…', 'Pause All');
      if (refreshBtn) {
        refreshBtn.disabled = false;
      }
      resolveApiButtonsState();
    });
  }

  function parseNumericId(raw) {
    var v = String(raw || '').trim();
    if (!v) {
      return '';
    }
    if (/^\d+$/.test(v)) {
      return v;
    }
    var eventMatch = v.match(/\/events\/(\d+)/i);
    if (eventMatch && eventMatch[1]) {
      return eventMatch[1];
    }
    var postMatch = v.match(/\/posts\/(\d+)/i);
    if (postMatch && postMatch[1]) {
      return postMatch[1];
    }
    return '';
  }

  function syncDerivedState(options) {
    options = options || {};
    clampAudienceInputs(!!options.forceAgeClamp);
    updateTargetingAddressStatus();
    syncGoalOptimizationVisibility();
    renderTierPreview();
    renderBudgetFloorWarning();
    renderCopyPackPanel();
    syncCtaLockUi();
    renderStrategyStatus();
    renderRecipePreview();
    renderCreativeFormatRequirements();
    renderAudiencePreviewPanel();

    var preset = value('vms-ma-preset-mode') || 'flat_run';
    var customWrap = byId('vms-ma-custom-weight-wrap');
    if (customWrap) {
      customWrap.classList.toggle('vms-ma-advanced-hidden', preset !== 'promo_bundle_30_14_7');
    }
    resolveApiButtonsState();
  }

  function bindCopyButtons() {
    var copyAll = byId('vms-ma-copy-all');
    var copyUrl = byId('vms-ma-copy-url');
    var downloadPack = byId('vms-ma-download-pack');
    var copyPackDetails = byId('vms-ma-copy-pack-details');

    if (copyPackDetails) {
      copyPackDetails.addEventListener('toggle', function () {
        if (copyPackDetails.open) {
          renderCopyPackPanel({ force: true });
        }
      });
    }

    if (copyAll) {
      copyAll.addEventListener('click', function () {
        renderCopyPackPanel({ force: true });
        copyText(buildCopyPackText().text).then(function () {
          emitFeedback('success', 'Copy pack copied.', 'g');
        });
      });
    }
    if (copyUrl) {
      copyUrl.addEventListener('click', function () {
        renderCopyPackPanel({ force: true });
        copyText(buildCopyPackText().utmUrl).then(function () {
          emitFeedback('success', 'URL copied.', 'g');
        });
      });
    }
    if (downloadPack) {
      downloadPack.addEventListener('click', function () {
        renderCopyPackPanel({ force: true });
        downloadText('vms-meta-copy-pack.txt', buildCopyPackText().text);
        emitFeedback('success', 'Copy pack exported.', 'g');
      });
    }
  }

  function bindCreativeHelpers() {
    var postUrl = byId('vms-ma-post-url');
    var postId = byId('vms-ma-post-id');
    var postPicker = byId('vms-ma-post-picker');
    var eventUrl = byId('vms-ma-fb-event-url');
    var eventId = byId('vms-ma-fb-event-id');
    var eventPicker = byId('vms-ma-fb-event-picker');

    if (postUrl && postId) {
      postUrl.addEventListener('blur', function () {
        var parsed = parseNumericId(postUrl.value);
        if (!parsed && String(postUrl.value || '').trim()) {
          emitFeedback('error', 'Could not parse Post ID. Paste a post URL ending in /posts/{id} or the numeric ID.', 'c');
          return;
        }
        postId.value = parsed;
      });
    }
    if (postPicker && postId) {
      postPicker.addEventListener('change', function () {
        postId.value = String(postPicker.value || '');
      });
    }

    if (eventUrl && eventId) {
      eventUrl.addEventListener('blur', function () {
        var parsed = parseNumericId(eventUrl.value);
        if (!parsed && String(eventUrl.value || '').trim()) {
          emitFeedback('error', 'Could not parse Facebook Event ID. Paste an event URL ending in /events/{id} or the numeric ID.', 'c');
          return;
        }
        eventId.value = parsed;
      });
    }
    if (eventPicker && eventId) {
      eventPicker.addEventListener('change', function () {
        eventId.value = String(eventPicker.value || '');
      });
    }
  }

  function bindRegenerate() {
    var regen = byId('vms-ma-copy_regen');
    if (!regen) {
      return;
    }
    regen.addEventListener('click', function (evt) {
      evt.preventDefault();
      applyDefaultCopyFromEvent(lastEventContext || null, true);
      renderCopyPackPanel();
      emitFeedback('info', 'Creative text regenerated from event.', 'c');
    });
  }


  // Templates
  function getTemplateIncludeList() {
    function isChecked(id, fallback) {
      var el = byId(id);
      if (!el) {
        return !!fallback;
      }
      return !!el.checked;
    }
    var include = [];
    if (isChecked('vms-ma-tpl-inc-targeting', true)) include.push('targeting');
    if (isChecked('vms-ma-tpl-inc-placements', true)) include.push('placements');
    if (isChecked('vms-ma-tpl-inc-schedule', true)) include.push('schedule');
    if (isChecked('vms-ma-tpl-inc-budget', true)) include.push('budget');
    if (isChecked('vms-ma-tpl-inc-strategy', true)) include.push('strategy');
    if (isChecked('vms-ma-tpl-inc-cta', true)) include.push('cta');
    return include;
  }

  function formatTemplateStamp(raw) {
    var text = String(raw || '').trim();
    return text ? text.replace(' ', ' ') : '';
  }

  function findTemplateItem(templateId) {
    var needle = String(templateId || '').trim();
    if (!needle) {
      return null;
    }
    var found = null;
    templateCache.forEach(function (item) {
      if (!found && item && String(item.id || '') === needle) {
        found = item;
      }
    });
    return found;
  }

  function renderTemplateMeta(selectedId) {
    var select = byId('vms-ma-template-select');
    var applyBtn = byId('vms-ma-apply-template');
    var deleteBtn = byId('vms-ma-delete-template');
    var metaEl = byId('vms-ma-template-meta');
    var activeId = String(selectedId || (select ? select.value : '') || '').trim();
    var selected = findTemplateItem(activeId);
    var hasSelection = !!selected;

    if (applyBtn) {
      applyBtn.disabled = !hasSelection;
    }
    if (deleteBtn) {
      deleteBtn.disabled = !hasSelection;
    }
    if (!metaEl) {
      return;
    }
    if (!selected) {
      metaEl.textContent = 'Select a template to see when it was saved.';
      return;
    }

    var parts = [];
    parts.push('Template #' + String(selected.id || ''));
    if (selected.updated_at) {
      parts.push('Updated ' + formatTemplateStamp(selected.updated_at));
    }
    if (selected.created_at) {
      parts.push('Created ' + formatTemplateStamp(selected.created_at));
    }
    metaEl.textContent = parts.join(' • ');
  }

  function renderTemplateSelect(items, selectedId) {
    var select = byId('vms-ma-template-select');
    if (!select) {
      return;
    }
    templateCache = Array.isArray(items) ? items.slice() : [];
    var keep = String(selectedId || select.value || '');
    select.innerHTML = '';
    var empty = document.createElement('option');
    empty.value = '';
    empty.textContent = 'No template selected';
    select.appendChild(empty);

    templateCache.forEach(function (item) {
      if (!item) {
        return;
      }
      var opt = document.createElement('option');
      opt.value = String(item.id || '');
      var label = String(item.name || item.template_name || ('Template ' + String(item.id || '')));
      if (item.updated_at) {
        label += ' — updated ' + String(item.updated_at);
      }
      opt.textContent = label;
      if (opt.value && opt.value === keep) {
        opt.selected = true;
      }
      select.appendChild(opt);
    });

    renderTemplateMeta();
  }

  function formatBuildStamp(raw) {
    var text = String(raw || '').trim();
    return text ? text.replace(' ', ' ') : '';
  }

  function findBuildItem(buildId) {
    var needle = String(buildId || '').trim();
    if (!needle) {
      return null;
    }
    var found = null;
    buildCache.forEach(function (item) {
      if (!found && item && String(item.id || '') === needle) {
        found = item;
      }
    });
    return found;
  }

  function buildStatusLabel(item) {
    var status = String((item && item.status) || '').trim().toLowerCase();
    switch (status) {
      case 'live':
        return 'Live';
      case 'meta_created_paused':
        return 'Paused in Meta';
      case 'exported':
        return 'Exported';
      case 'ended':
        return 'Ended';
      case 'error':
        return 'Needs attention';
      default:
        return 'Draft';
    }
  }

  function getAdoptedSummary(item) {
    var metaIds = item && item.meta_ids && typeof item.meta_ids === 'object' ? item.meta_ids : {};
    var summary = metaIds.adopted_summary && typeof metaIds.adopted_summary === 'object' ? metaIds.adopted_summary : null;
    if (!summary) {
      return null;
    }
    var source = String((metaIds.source_of_truth || summary.source_of_truth || '')).toLowerCase();
    var adoption = String((metaIds.adoption_source || summary.adoption_source || '')).toLowerCase();
    if (source !== 'meta' && adoption !== 'existing_meta_campaign') {
      return null;
    }
    return summary;
  }


  function buildHasMetaIds(item) {
    if (!item || typeof item !== 'object') {
      return false;
    }
    var metaIds = item.meta_ids && typeof item.meta_ids === 'object' ? item.meta_ids : {};
    if (String(item.meta_campaign_id || '').trim() || String(metaIds.campaign_id || '').trim() || String(metaIds.adset_id || '').trim() || String(metaIds.ad_id || '').trim()) {
      return true;
    }
    var tiers = Array.isArray(item.tiers) ? item.tiers : [];
    return tiers.some(function (tier) {
      return !!(tier && (String(tier.meta_adset_id || '').trim() || String(tier.meta_ad_id || '').trim() || String(tier.meta_creative_id || '').trim()));
    });
  }

  function buildIsMetaSourceOfTruth(item) {
    if (!buildHasMetaIds(item)) {
      return false;
    }
    var metaIds = item && item.meta_ids && typeof item.meta_ids === 'object' ? item.meta_ids : {};
    var summary = metaIds.adopted_summary && typeof metaIds.adopted_summary === 'object' ? metaIds.adopted_summary : {};
    var source = String(metaIds.source_of_truth || summary.source_of_truth || '').toLowerCase();
    var adoption = String(metaIds.adoption_source || summary.adoption_source || '').toLowerCase();
    return source === 'meta' || adoption === 'existing_meta_campaign';
  }

  function getSelectedBuildItem() {
    var id = String(value('vms-ma-build-id') || '').trim();
    return id ? findBuildItem(id) : null;
  }

  function buildMetaAudienceSummary(item) {
    var summary = getAdoptedSummary(item);
    if (!summary) {
      return '';
    }
    var parts = [];
    var adsetName = String(summary.adset_name || '').trim();
    var audience = String(summary.audience_summary || '').trim();
    var budgetMinor = parseIntSafe(summary.budget_minor, 0);
    var budgetType = String(summary.budget_type || '').trim();
    if (adsetName) {
      parts.push(adsetName);
    }
    if (audience && (!adsetName || adsetName.indexOf(audience) === -1)) {
      parts.push(audience);
    }
    if (budgetMinor > 0) {
      parts.push(formatBudgetMinor(budgetMinor) + (budgetType ? ' ' + budgetType : ''));
    }
    return parts.join(' • ');
  }

  function buildAudienceSummary(item) {
    var targeting = item && item.targeting_payload && typeof item.targeting_payload === 'object' ? item.targeting_payload : {};
    var audience = buildAudienceStateFromIncoming(
      targeting.audience_targeting,
      targeting.gender,
      Array.isArray(targeting.interests) ? targeting.interests : String(targeting.interests || '')
    );
    var parts = [];
    var anchor = String(targeting.targeting_address || '').trim();
    var radius = parseIntSafe(targeting.radius_miles, 0);
    var ageMin = parseIntSafe(targeting.age_min, 0);
    var ageMax = parseIntSafe(targeting.age_max, 0);
    var activeTerms = audience.terms.filter(function (term) {
      var status = normalizeAudienceValidationStatus(term && term.validation_status);
      return status !== 'deprecated' && status !== 'unavailable';
    }).map(function (term) {
      return String(term && term.label || '').trim();
    }).filter(Boolean);

    parts.push(audienceModeLabel(audience.mode));
    if (anchor) {
      parts.push(anchor);
    }
    if (radius > 0) {
      parts.push(radius + 'mi');
    }
    if (ageMin > 0 && ageMax >= ageMin) {
      parts.push('age ' + ageMin + '-' + ageMax);
    }
    if (String(audience.gender || 'all') !== 'all') {
      parts.push(audienceGenderLabel(audience.gender));
    }
    if (activeTerms.length) {
      parts.push(activeTerms.slice(0, 3).join(', '));
    }
    return parts.join(' • ');
  }

  function buildOptionLabel(item) {
    if (!item) {
      return 'Build';
    }
    var label = 'Build #' + String(item.id || '');
    var status = buildStatusLabel(item);
    var metaSummary = buildMetaAudienceSummary(item);
    var audience = metaSummary || buildAudienceSummary(item);
    if (status) {
      label += ' — ' + (metaSummary ? status + ' in Meta' : status);
    }
    if (audience) {
      label += ' — ' + audience;
    }
    return label;
  }

  function buildListStatusClass(item) {
    var status = String((item && item.status) || '').trim().toLowerCase();
    if (buildIsMetaSourceOfTruth(item)) {
      return 'is-meta-source';
    }
    if (status === 'live') {
      return 'is-live';
    }
    if (status === 'meta_created_paused') {
      return 'is-paused';
    }
    if (status === 'error') {
      return 'is-error';
    }
    return 'is-draft';
  }

  function buildListSubline(item) {
    var parts = [];
    var metaSummary = buildMetaAudienceSummary(item);
    var savedAudience = buildAudienceSummary(item);
    if (metaSummary) {
      parts.push('Meta: ' + metaSummary);
      if (savedAudience && savedAudience !== metaSummary) {
        parts.push('Saved draft: ' + savedAudience);
      }
    } else if (savedAudience) {
      parts.push(savedAudience);
    }
    if (item && item.updated_at) {
      parts.push('Updated ' + formatBuildStamp(item.updated_at));
    }
    return parts.join(' • ');
  }

  function mergeIncomingBuildItems(items) {
    var incoming = Array.isArray(items) ? items.filter(Boolean) : [];
    if (!incoming.length) {
      return [];
    }
    var eventPlanId = getCurrentEventPlanId();
    var sameEventCache = eventPlanId > 0 && buildCache.length > 0 && buildCache.every(function (row) {
      return row && parseIntSafe(row.event_plan_id, 0) === eventPlanId;
    });
    var incomingSameEvent = eventPlanId > 0 && incoming.every(function (row) {
      return row && parseIntSafe(row.event_plan_id, 0) === eventPlanId;
    });

    if (sameEventCache && incomingSameEvent && incoming.length === 1 && buildCache.length > 1) {
      var byId = {};
      buildCache.forEach(function (row) {
        if (row && row.id) {
          byId[String(row.id)] = row;
        }
      });
      byId[String(incoming[0].id || '')] = incoming[0];
      return buildCache.map(function (row) {
        return row && byId[String(row.id || '')] ? byId[String(row.id || '')] : row;
      });
    }

    return incoming;
  }

  function renderBuildList(activeId) {
    var list = byId('vms-ma-build-list');
    if (!list) {
      return;
    }
    var eventPlanId = getCurrentEventPlanId();
    if (!eventPlanId || !buildCache.length) {
      list.innerHTML = '';
      return;
    }

    var active = String(activeId || getActiveBuildId() || '').trim();
    var html = '<div class="vms-ma-build-list-head"><strong>Saved campaign drafts for this event (' + escapeHtml(String(buildCache.length)) + ')</strong><span>Newest first. Pick a row to load a different campaign draft.</span></div>';
    html += '<div class="vms-ma-build-cards">';
    buildCache.forEach(function (item) {
      if (!item) {
        return;
      }
      var itemId = String(item.id || '');
      var isActive = itemId && itemId === active;
      var status = buildStatusLabel(item);
      var statusText = buildIsMetaSourceOfTruth(item) ? status + ' in Meta • Meta source of truth' : status;
      html += '<article class="vms-ma-build-card ' + escapeHtml(buildListStatusClass(item)) + (isActive ? ' is-selected' : '') + '">';
      html += '<div class="vms-ma-build-card-main"><strong>' + escapeHtml('Build #' + itemId) + '</strong><span>' + escapeHtml(statusText) + '</span></div>';
      html += '<div class="vms-ma-build-card-subline">' + escapeHtml(buildListSubline(item) || 'No saved audience summary yet.') + '</div>';
      html += '<div class="vms-ma-build-card-actions">';
      if (isActive) {
        html += '<button type="button" class="button button-secondary" disabled>Loaded</button>';
      } else {
        html += '<button type="button" class="button button-secondary vms-ma-load-build-row" data-build-id="' + escapeHtml(itemId) + '">Load</button>';
      }
      html += '<button type="button" class="button button-secondary vms-ma-duplicate-build" data-build-id="' + escapeHtml(itemId) + '">Duplicate as Fresh Draft</button>';
      html += '<button type="button" class="button button-secondary vms-ma-archive-build" data-build-id="' + escapeHtml(itemId) + '">Scrap / Archive Build</button>';
      html += '</div>';
      html += '</article>';
    });
    html += '</div>';
    list.innerHTML = html;
  }

  function duplicateBuildAsFreshDraft(buildId) {
    var id = parseIntSafe(buildId, 0);
    var eventPlanId = getCurrentEventPlanId();
    if (id < 1 || eventPlanId < 1) {
      emitFeedback('warning', 'Load an Event Plan and build first.', 'a');
      return Promise.resolve(null);
    }
    var source = findBuildItem(id);
    var label = source && source.id ? ('Build #' + source.id) : ('Build #' + id);
    return request('/ad-builds/' + encodeURIComponent(id) + '/duplicate', 'POST', {}).then(function (json) {
      var item = json && json.item ? json.item : null;
      emitFeedback('success', (json && json.message) ? json.message : (label + ' duplicated as a fresh draft.'), 'g');
      if (item && item.id) {
        return loadBuildsForEventPlan(eventPlanId, {
          selectedId: item.id,
          skipAutoloadLatest: true
        }).then(function () {
          return applyBuildSelection(item.id, { skipOverlay: true, silent: true });
        }).then(function () {
          renderCreateStructurePreview();
          return item;
        });
      }
      return null;
    }).catch(function (err) {
      emitFeedback('error', err && err.message ? err.message : 'Could not duplicate this build.', 'g');
      return null;
    });
  }

  function archiveBuild(buildId) {
    var id = parseIntSafe(buildId, 0);
    var eventPlanId = getCurrentEventPlanId();
    if (id < 1 || eventPlanId < 1) {
      emitFeedback('warning', 'Load an Event Plan and build first.', 'a');
      return Promise.resolve(null);
    }
    if (!window.confirm('Archive Build #' + String(id) + '? This hides it from the normal working list but keeps its history.')) {
      return Promise.resolve(null);
    }
    var activeId = getLoadedBuildId();
    return request('/ad-builds/' + encodeURIComponent(id) + '/archive', 'POST', {}).then(function (json) {
      emitFeedback('success', (json && json.message) ? json.message : ('Build #' + String(id) + ' archived.'), 'g');
      if (activeId === id) {
        clearSelectedBuild({
          preserveSelect: true,
          message: 'That build was archived. Load another draft or duplicate a fresh one before creating paused Meta drafts.'
        });
      }
      return loadBuildsForEventPlan(eventPlanId, {
        selectedId: activeId === id ? '' : activeId,
        skipAutoloadLatest: true
      }).then(function () {
        renderCreateStructurePreview();
        return json && json.item ? json.item : null;
      });
    }).catch(function (err) {
      emitFeedback('error', err && err.message ? err.message : 'Could not archive this build.', 'g');
      return null;
    });
  }

  function clearBuildStatusUi(message) {
    metaStatusState.loaded = false;
    metaStatusState.hasIds = false;
    metaStatusState.anyActive = false;
    metaStatusState.lastError = '';
    clearMetaCreateGuidance();
    updateMetaLink({});
    setMetaChip('campaign', 'UNKNOWN', 'UNKNOWN');
    setMetaChip('adset', 'UNKNOWN', 'UNKNOWN');
    setMetaChip('ad', 'UNKNOWN', 'UNKNOWN');
    renderMetaReadiness({});
    renderBudgetSyncState({});
    renderDriftState({});
    setMetaInline(message || 'Save this build first to load Meta status.');
  }

  function deferLoadedBuildStatus(build) {
    metaStatusState.loaded = false;
    metaStatusState.anyActive = false;
    metaStatusState.lastError = '';
    metaStatusState.hasIds = !!buildHasMetaIds(build);
    clearMetaCreateGuidance();
    setMetaChip('campaign', 'UNKNOWN', 'UNKNOWN');
    setMetaChip('adset', 'UNKNOWN', 'UNKNOWN');
    setMetaChip('ad', 'UNKNOWN', 'UNKNOWN');
    renderMetaReadiness({});
    renderBudgetSyncState({});
    renderDriftState({});
    clearAnalyticsPanels('Analytics stay deferred until you refresh them or run a later Meta step.');
    var linked = getCurrentLinkedMetaIds();
    updateMetaLink({
      campaign_id: linked.campaign_id,
      adset_id: linked.adset_id,
      ad_id: linked.ad_id
    });
    if (metaStatusState.hasIds) {
      setMetaInline('This draft is linked to Meta. Status checks stay deferred until you click Refresh Status or run a Meta action.');
      return;
    }
    setMetaInline('No Meta campaign has been created yet. Load a saved build, then use Preview / Troubleshooting Dry Run or Create Paused when you are ready.');
  }

  function updateReconcileButtonState() {
    var btn = byId('vms-ma-find-meta-campaigns');
    if (!btn) {
      return;
    }
    btn.disabled = !getCurrentEventPlanId();
  }

  function getCurrentLinkedMetaIds() {
    var buildId = parseIntSafe(getActiveBuildId(), 0);
    var selected = buildId > 0 ? findBuildItem(buildId) : null;
    var metaIds = selected && selected.meta_ids && typeof selected.meta_ids === 'object' ? selected.meta_ids : {};
    return {
      build: selected,
      campaign_id: String(metaIds.campaign_id || selected && selected.meta_campaign_id || '').trim(),
      adset_id: String(metaIds.adset_id || '').trim(),
      ad_id: String(metaIds.ad_id || '').trim()
    };
  }

  function normalizeMetaId(value) {
    return String(value || '').trim();
  }

  function candidateIsCurrentLinked(candidate) {
    var linked = getCurrentLinkedMetaIds();
    if (!candidate || !linked.campaign_id || !linked.adset_id) {
      return false;
    }
    return normalizeMetaId(candidate.campaign_id) === normalizeMetaId(linked.campaign_id) && normalizeMetaId(candidate.adset_id) === normalizeMetaId(linked.adset_id);
  }

  function renderCurrentMetaLinkedState(build) {
    var results = byId('vms-ma-reconcile-results');
    if (!results) {
      return;
    }
    if (results.dataset && results.dataset.candidates && results.dataset.candidates !== '[]') {
      return;
    }
    var summary = getAdoptedSummary(build);
    if (!summary) {
      if (results.dataset && results.dataset.renderedLinked === '1') {
        results.innerHTML = '';
        results.dataset.renderedLinked = '0';
      }
      return;
    }
    var budgetMinor = parseIntSafe(summary.budget_minor, 0);
    var budgetText = budgetMinor > 0 ? formatBudgetMinor(budgetMinor) + (summary.budget_type ? ' ' + escapeHtml(String(summary.budget_type)) : '') : 'Budget unknown';
    var html = '<article class="vms-ma-reconcile-card vms-ma-reconcile-card--linked">';
    html += '<div class="vms-ma-reconcile-card-head"><strong>Linked active Meta campaign</strong><span>Meta source of truth</span></div>';
    html += '<div class="vms-ma-reconcile-details">';
    if (summary.campaign_name || summary.campaign_id) {
      html += '<div><strong>Campaign:</strong> ' + escapeHtml(String(summary.campaign_name || '')) + (summary.campaign_status ? ' • ' + escapeHtml(String(summary.campaign_status)) : '') + (summary.campaign_id ? ' • ' + escapeHtml(String(summary.campaign_id)) : '') + '</div>';
    }
    if (summary.adset_name || summary.adset_id) {
      html += '<div><strong>Ad set:</strong> ' + escapeHtml(String(summary.adset_name || '')) + (summary.adset_status ? ' • ' + escapeHtml(String(summary.adset_status)) : '') + '</div>';
    }
    if (summary.audience_summary) {
      html += '<div><strong>Audience:</strong> ' + escapeHtml(String(summary.audience_summary)) + '</div>';
    }
    html += '<div><strong>Budget:</strong> ' + budgetText + (summary.ad_count ? ' • ads found: ' + escapeHtml(String(summary.ad_count)) : '') + '</div>';
    html += '<div><strong>Saved draft:</strong> Builder settings may still differ from Meta. Review the drift check before pushing any updates.</div>';
    html += '</div>';
    html += '</article>';
    results.innerHTML = html;
    results.dataset.renderedLinked = '1';
  }

  function renderReconcileResults(resp) {
    var results = byId('vms-ma-reconcile-results');
    if (!results) {
      return;
    }
    var candidates = resp && Array.isArray(resp.candidates) ? resp.candidates : [];
    if (!resp) {
      results.innerHTML = '';
      results.dataset.candidates = '[]';
      return;
    }
    if (!candidates.length) {
      results.dataset.candidates = '[]';
      results.innerHTML = '<div class="vms-ma-reconcile-empty">No likely Meta campaigns found. Meta may be using a name or URL this search could not match.</div>';
      return;
    }
    var html = '<div class="vms-ma-reconcile-list">';
    candidates.forEach(function (candidate, index) {
      var budget = candidate.budget_minor ? formatBudgetMinor(candidate.budget_minor) + (candidate.budget_type ? ' ' + escapeHtml(candidate.budget_type) : '') : 'Budget unknown';
      var drift = candidate.drift && typeof candidate.drift === 'object' ? candidate.drift : null;
      var driftText = drift ? String(drift.summary || '') : '';
      var linked = candidateIsCurrentLinked(candidate);
      var driftClass = drift && drift.status === 'drift' ? ' vms-ma-reconcile-card--drift' : '';
      var linkedClass = linked ? ' vms-ma-reconcile-card--linked' : '';
      html += '<article class="vms-ma-reconcile-card' + driftClass + linkedClass + '">';
      html += '<div class="vms-ma-reconcile-card-head"><strong>' + escapeHtml(String(candidate.campaign_name || 'Untitled campaign')) + '</strong><span>' + (linked ? 'Linked • ' : '') + escapeHtml(String(candidate.confidence || '')) + ' match • score ' + escapeHtml(String(candidate.score || 0)) + '</span></div>';
      html += '<div class="vms-ma-reconcile-details">';
      html += '<div><strong>Campaign:</strong> ' + escapeHtml(String(candidate.campaign_status || 'UNKNOWN')) + ' • ' + escapeHtml(String(candidate.campaign_id || '')) + '</div>';
      html += '<div><strong>Ad set:</strong> ' + escapeHtml(String(candidate.adset_name || '')) + ' • ' + escapeHtml(String(candidate.adset_status || 'UNKNOWN')) + '</div>';
      html += '<div><strong>Audience:</strong> ' + escapeHtml(String(candidate.audience_summary || 'Unknown')) + '</div>';
      html += '<div><strong>Budget:</strong> ' + budget + ' • ads found: ' + escapeHtml(String(candidate.ad_count || 0)) + '</div>';
      if (driftText) {
        html += '<div><strong>Drift:</strong> ' + escapeHtml(driftText) + '</div>';
      }
      if (linked) {
        html += '<div class="vms-ma-reconcile-linked-note"><strong>Linked.</strong> Meta is the source of truth for this build until you intentionally push or replace settings.</div>';
      }
      html += '</div>';
      if (linked) {
        html += '<button type="button" class="button button-secondary" disabled>Linked to this build</button>';
      } else {
        html += '<button type="button" class="button button-secondary vms-ma-adopt-meta-candidate" data-candidate-index="' + String(index) + '">Adopt / Link this Meta campaign</button>';
      }
      html += '</article>';
    });
    html += '</div>';
    results.innerHTML = html;
    results.dataset.candidates = JSON.stringify(candidates);
  }

  function getDiscoveryCandidates() {
    var results = byId('vms-ma-reconcile-results');
    if (!results || !results.dataset.candidates) {
      return [];
    }
    try {
      var parsed = JSON.parse(results.dataset.candidates);
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      return [];
    }
  }

  function findExistingMetaCampaigns() {
    var selectedBeforeDiscovery = getActiveBuildId();
    var eventPlanId = getCurrentEventPlanId();
    if (!eventPlanId) {
      emitFeedback('warning', 'Choose an Event Plan first.', 'a');
      return Promise.resolve(null);
    }
    var buildId = parseIntSafe(selectedBeforeDiscovery, 0);
    var path = '/meta-discovery?event_plan_id=' + encodeURIComponent(eventPlanId);
    if (buildId > 0) {
      path += '&build_id=' + encodeURIComponent(buildId);
    }
    var btn = byId('vms-ma-find-meta-campaigns');
    setActionBusy(btn, true, 'Searching Meta…', 'Find Existing Meta Campaigns');
    return request(path, 'GET').then(function (json) {
      if (selectedBeforeDiscovery) {
        setActiveBuildId(selectedBeforeDiscovery);
        renderBuildSelect(buildCache, selectedBeforeDiscovery);
      }
      renderReconcileResults(json || {});
      if (selectedBeforeDiscovery) {
        renderBuildMeta(selectedBeforeDiscovery);
      }
      emitFeedback(json && json.candidates && json.candidates.length ? 'success' : 'info', String((json && json.message) || 'Meta discovery complete.'), 'a');
      return json;
    }).catch(function (err) {
      renderReconcileResults({ candidates: [] });
      emitFeedback('warning', err && err.message ? err.message : 'Meta discovery failed.', 'a');
      return null;
    }).finally(function () {
      setActionBusy(btn, false, 'Searching Meta…', 'Find Existing Meta Campaigns');
      updateReconcileButtonState();
    });
  }

  function adoptMetaCandidate(candidate) {
    var buildId = parseIntSafe(value('vms-ma-build-id'), 0);
    if (buildId < 1) {
      emitFeedback('warning', 'Save or select a linked build before adopting a Meta campaign.', 'g');
      return Promise.resolve(null);
    }
    if (!candidate || !candidate.campaign_id || !candidate.adset_id) {
      emitFeedback('warning', 'Selected Meta campaign is missing required IDs.', 'g');
      return Promise.resolve(null);
    }
    var label = String(candidate.campaign_name || candidate.campaign_id || 'this campaign');
    if (!window.confirm('Link Build #' + String(buildId) + ' to "' + label + '" in Meta? This does not publish anything, but it makes the builder track those live Meta IDs.')) {
      return Promise.resolve(null);
    }
    var payload = {
      confirm_adopt: true,
      campaign_id: candidate.campaign_id,
      adset_id: candidate.adset_id,
      ad_id: candidate.ad_id || (candidate.ad_ids && candidate.ad_ids[0]) || '',
      ad_ids: Array.isArray(candidate.ad_ids) ? candidate.ad_ids : [],
      candidate: {
        campaign_name: candidate.campaign_name || '',
        campaign_status: candidate.campaign_status || '',
        adset_name: candidate.adset_name || '',
        adset_status: candidate.adset_status || '',
        audience_summary: candidate.audience_summary || '',
        budget_minor: candidate.budget_minor || 0,
        budget_type: candidate.budget_type || '',
        ad_count: candidate.ad_count || 0,
        score: candidate.score || 0
      }
    };
    return request('/ad-builds/' + encodeURIComponent(buildId) + '/meta-adopt', 'POST', payload).then(function (json) {
      if (json && json.build) {
        var replaced = false;
        buildCache = buildCache.map(function (row) {
          if (row && String(row.id || '') === String(json.build.id || '')) {
            replaced = true;
            return json.build;
          }
          return row;
        });
        if (!replaced) {
          buildCache.unshift(json.build);
        }
        renderBuildSelect(buildCache, String(json.build.id || ''));
        applyBuildData(json.build);
      }
      applyMetaStatusResponse(json || {}, String((json && json.message) || 'Existing Meta campaign linked.'));
      if (json && json.build) {
        var candidates = getDiscoveryCandidates();
        if (candidates.length) {
          renderReconcileResults({ candidates: candidates });
        } else {
          renderCurrentMetaLinkedState(json.build);
        }
      }
      emitFeedback('success', String((json && json.message) || 'Existing Meta campaign linked.'), 'g');
      return json;
    }).catch(function (err) {
      emitFeedback('error', err && err.message ? err.message : 'Could not link existing Meta campaign.', 'g');
      return null;
    });
  }

  function renderBuildMeta(selectedId) {
    var eventPlanId = getCurrentEventPlanId();
    updateReconcileButtonState();
    var select = byId('vms-ma-build-select');
    var metaEl = byId('vms-ma-build-meta');
    var startBtn = byId('vms-ma-start-new-build');
    var refreshBtn = byId('vms-ma-refresh-builds');
    var activeId = String(selectedId || getActiveBuildId() || (select ? select.value : '') || '').trim();
    var selected = findBuildItem(activeId);
    var hasEvent = !!eventPlanId;
    renderBuildList(activeId);

    if (select) {
      select.disabled = !hasEvent;
    }
    if (startBtn) {
      startBtn.disabled = !hasEvent;
    }
    if (refreshBtn) {
      refreshBtn.disabled = !hasEvent;
    }
    if (!metaEl) {
      return;
    }
    if (!hasEvent) {
      metaEl.textContent = 'Choose an Event Plan to see campaign drafts for it.';
      return;
    }
    if (!buildCache.length) {
      metaEl.textContent = 'No campaign drafts yet for this Event Plan. Fill in your settings, then click Save Draft to create the first draft.';
      return;
    }
    if (!selected) {
      metaEl.textContent = 'Choose a campaign draft to load it. Create Paused will only use the build currently loaded here.';
      return;
    }

    var parts = [];
    parts.push('Build #' + String(selected.id || ''));
    var metaSummary = buildMetaAudienceSummary(selected);
    if (metaSummary) {
      parts.push(buildStatusLabel(selected) + ' in Meta');
      parts.push('Meta source of truth');
      parts.push(metaSummary);
      var savedAudience = buildAudienceSummary(selected);
      if (savedAudience && savedAudience !== metaSummary) {
        parts.push('saved draft: ' + savedAudience);
      }
    } else {
      parts.push(buildStatusLabel(selected));
      var audience = buildAudienceSummary(selected);
      if (audience) {
        parts.push(audience);
      }
    }
    if (selected.updated_at) {
      parts.push('Updated ' + formatBuildStamp(selected.updated_at));
    }
    metaEl.textContent = parts.join(' • ');
    renderCurrentMetaLinkedState(selected);
  }

  function renderBuildSelect(items, selectedId) {
    var select = byId('vms-ma-build-select');
    if (!select) {
      return;
    }
    buildCache = mergeIncomingBuildItems(items);
    var keep = String(selectedId || getActiveBuildId() || '').trim();
    select.innerHTML = '';
    var empty = document.createElement('option');
    empty.value = '';
    empty.textContent = buildCache.length ? 'Choose a campaign draft…' : 'No campaign drafts yet';
    select.appendChild(empty);

    buildCache.forEach(function (item) {
      if (!item) {
        return;
      }
      var opt = document.createElement('option');
      opt.value = String(item.id || '');
      opt.textContent = buildOptionLabel(item);
      if (opt.value && opt.value === keep) {
        opt.selected = true;
      }
      select.appendChild(opt);
    });

    if (keep) {
      setActiveBuildId(keep);
    }
    renderBuildMeta(keep);
    renderCreateStructurePreview();
  }

  function clearSelectedBuild(options) {
    var opts = options && typeof options === 'object' ? options : {};
    if (!opts.internalAutoload) {
      buildInteractionSeq += 1;
    }
    resetBuildHydrationState();
    if (opts.preserveSelect) {
      setActiveBuildId('');
    } else {
      setActiveBuildId('');
    }
    dirtyState.savedPayloadSignature = '';
    updateDirtyState();
    clearBuildStatusUi(opts.message || 'This will save as a new linked build for this Event Plan.');
    clearAnalyticsPanels('Select or save a linked build to load analytics.');
    renderBuildMeta('');
    renderCreateStructurePreview();
    resolveApiButtonsState();
  }

  function applyBuildSelection(buildId, options) {
    var id = parseIntSafe(buildId, 0);
    if (id < 1) {
      clearSelectedBuild({
        message: 'This will save as a new linked build for this Event Plan.'
      });
      return Promise.resolve(null);
    }

    var opts = options && typeof options === 'object' ? options : {};
    if (!opts.internalAutoload) {
      buildInteractionSeq += 1;
    }
    var applyItem = function (item) {
      if (!item || typeof item !== 'object') {
        return null;
      }
      applyBuildData(item);
      setActiveBuildId(item.id || '');
      renderBuildMeta(String(item.id || ''));
      renderCreateStructurePreview();
      deferLoadedBuildStatus(item);
      if (!opts.silent) {
        emitFeedback('info', 'Loaded campaign draft #' + String(item.id || '') + ' for this Event Plan.', 'g');
      }
      recordPerf('build_applied', {
        build_id: parseIntSafe(item.id, 0),
        event_plan_id: getCurrentEventPlanId(),
        has_meta_ids: !!buildHasMetaIds(item)
      });
      return item;
    };

    var cached = findBuildItem(id);
    if (cached) {
      return Promise.resolve(applyItem(cached));
    }

    var promise = request('/ad-builds/' + encodeURIComponent(id), 'GET').then(function (json) {
      var item = json && json.item ? json.item : null;
      if (!item) {
        throw new Error('Build not found.');
      }
      var foundIndex = -1;
      buildCache.forEach(function (row, index) {
        if (foundIndex === -1 && row && String(row.id || '') === String(item.id || '')) {
          foundIndex = index;
        }
      });
      if (foundIndex >= 0) {
        buildCache[foundIndex] = item;
      } else {
        buildCache.unshift(item);
      }
      renderBuildSelect(buildCache, String(item.id || ''));
      return applyItem(item);
    });

    if (opts.skipOverlay) {
      return promise;
    }
    return withLoadingOverlay(promise, 'Loading campaign draft…');
  }

  function buildItemsContainId(items, id) {
    var needle = String(id || '').trim();
    if (!needle || !Array.isArray(items)) {
      return false;
    }
    return items.some(function (row) {
      return row && String(row.id || '') === needle;
    });
  }

  function loadBuildsForEventPlan(eventPlanId, options) {
    var id = parseIntSafe(eventPlanId, 0);
    if (id < 1) {
      buildCache = [];
      renderBuildSelect([], '');
      clearSelectedBuild({
        preserveSelect: true,
        internalAutoload: true,
        message: 'Choose an Event Plan to see or create linked builds.'
      });
      return Promise.resolve([]);
    }

    var opts = options && typeof options === 'object' ? options : {};
    var requestSeq = ++buildHydrationSeq;
    var selectedAtStart = String(opts.selectedId || getActiveBuildId() || '').trim();
    var desiredId = parseIntSafe(selectedAtStart, 0);
    var buildListLimit = Math.max(5, Math.min(20, parseIntSafe(builderPerf.buildListLimit, 12) || 12));
    var finishPerf = startPerfTimer('build_list_load', {
      event_plan_id: id,
      selected_build_id: desiredId,
      requested_limit: buildListLimit,
      skip_autoload_latest: !!opts.skipAutoloadLatest
    });
    var promise = request('/ad-builds?event_plan_id=' + encodeURIComponent(id) + '&limit=' + encodeURIComponent(buildListLimit), 'GET').then(function (json) {
      if (requestSeq !== buildHydrationSeq) {
        finishPerf({
          ok: true,
          cancelled: true,
          build_count: buildCache.length
        });
        return buildCache;
      }
      var items = json && Array.isArray(json.items) ? json.items : [];
      if (!items.length && opts.fallbackBuild && typeof opts.fallbackBuild === 'object') {
        items = [opts.fallbackBuild];
      }

      var activeNow = String(getActiveBuildId() || '').trim();
      var chosenId = desiredId;
      if (chosenId > 0 && !buildItemsContainId(items, chosenId)) {
        chosenId = 0;
      }
      if (chosenId < 1 && activeNow && buildItemsContainId(items, activeNow)) {
        chosenId = parseIntSafe(activeNow, 0);
      }
      finishPerf({
        ok: true,
        build_count: items.length,
        autoload_build_id: chosenId > 0 ? chosenId : 0
      });

      renderBuildSelect(items, chosenId > 0 ? String(chosenId) : '');

      if (chosenId > 0) {
        return applyBuildSelection(chosenId, { skipOverlay: true, silent: true, internalAutoload: true }).then(function () {
          renderBuildSelect(buildCache.length ? buildCache : items, String(chosenId));
          return items;
        });
      }

      clearSelectedBuild({
        preserveSelect: true,
        internalAutoload: true,
        message: items.length
          ? 'Choose a campaign draft or click Create New Campaign Draft to start another setup for this Event Plan.'
          : 'No campaign drafts yet for this Event Plan. Fill in your settings, then click Save Draft to create the first draft.'
      });
      return items;
    }).catch(function () {
      if (requestSeq !== buildHydrationSeq) {
        finishPerf({
          ok: false,
          cancelled: true,
          build_count: buildCache.length
        });
        return buildCache;
      }
      var fallbackItems = opts.fallbackBuild && typeof opts.fallbackBuild === 'object' ? [opts.fallbackBuild] : [];
      finishPerf({
        ok: false,
        build_count: fallbackItems.length
      });
      buildCache = fallbackItems;
      renderBuildSelect(fallbackItems, fallbackItems[0] ? String(fallbackItems[0].id || '') : '');
      if (fallbackItems[0]) {
        applyBuildSelection(fallbackItems[0].id, { skipOverlay: true, silent: true, internalAutoload: true });
      } else {
        clearSelectedBuild({
          preserveSelect: true,
          internalAutoload: true,
          message: 'Could not load campaign drafts right now. You can still create a new draft by filling out the form and saving it.'
        });
      }
      return fallbackItems;
    });

    if (opts.skipOverlay) {
      return promise;
    }
    return withLoadingOverlay(promise, 'Loading linked builds…');
  }

  function bindBuildManager() {
    var select = byId('vms-ma-build-select');
    var newBtn = byId('vms-ma-start-new-build');
    var refreshBtn = byId('vms-ma-refresh-builds');
    var findMetaBtn = byId('vms-ma-find-meta-campaigns');
    var reconcileResults = byId('vms-ma-reconcile-results');
    var buildList = byId('vms-ma-build-list');

    if (select) {
      select.addEventListener('change', function () {
        var id = parseIntSafe(select.value, 0);
        if (id > 0) {
          applyBuildSelection(id);
          return;
        }
        clearSelectedBuild({
          preserveSelect: true,
          message: 'This will save as a new linked build for this Event Plan.'
        });
      });
    }

    if (buildList) {
      buildList.addEventListener('click', function (evt) {
        var target = evt.target;
        if (!target || !target.classList) {
          return;
        }
        if (target.classList.contains('vms-ma-duplicate-build')) {
          evt.preventDefault();
          evt.stopPropagation();
          duplicateBuildAsFreshDraft(target.getAttribute('data-build-id'));
          return;
        }
        if (target.classList.contains('vms-ma-archive-build')) {
          evt.preventDefault();
          evt.stopPropagation();
          archiveBuild(target.getAttribute('data-build-id'));
          return;
        }
        if (!target.classList.contains('vms-ma-load-build-row')) {
          return;
        }
        evt.preventDefault();
        var buildId = parseIntSafe(target.getAttribute('data-build-id'), 0);
        if (buildId > 0) {
          applyBuildSelection(buildId);
        }
      });
    }

    if (newBtn) {
      newBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        if (!getCurrentEventPlanId()) {
          emitFeedback('warning', 'Choose an Event Plan first.', 'a');
          return;
        }
        clearSelectedBuild({
          message: 'New linked build started. Your current form values are still on screen. Click Save Draft when ready to create a separate tracked build.'
        });
        emitFeedback('info', 'Started a new unsaved campaign draft for this Event Plan. Save Draft when ready.', 'g');
      });
    }

    if (refreshBtn) {
      refreshBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        var eventPlanId = getCurrentEventPlanId();
        if (!eventPlanId) {
          emitFeedback('warning', 'Choose an Event Plan first.', 'a');
          return;
        }
        loadBuildsForEventPlan(eventPlanId, {
          selectedId: getActiveBuildId()
        });
      });
    }

    if (findMetaBtn) {
      findMetaBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        findExistingMetaCampaigns();
      });
    }

    if (reconcileResults) {
      reconcileResults.addEventListener('click', function (evt) {
        var target = evt.target;
        if (!target || !target.classList || !target.classList.contains('vms-ma-adopt-meta-candidate')) {
          return;
        }
        evt.preventDefault();
        var index = parseIntSafe(target.getAttribute('data-candidate-index'), -1);
        var candidates = getDiscoveryCandidates();
        if (index < 0 || !candidates[index]) {
          emitFeedback('warning', 'That Meta candidate is no longer available. Run discovery again.', 'a');
          return;
        }
        adoptMetaCandidate(candidates[index]);
      });
    }

    builder.addEventListener('click', function (evt) {
      var target = evt.target;
      if (!target || !target.classList) {
        return;
      }
      if (target.classList.contains('vms-ma-duplicate-build')) {
        evt.preventDefault();
        duplicateBuildAsFreshDraft(target.getAttribute('data-build-id'));
        return;
      }
      if (target.classList.contains('vms-ma-archive-build')) {
        evt.preventDefault();
        archiveBuild(target.getAttribute('data-build-id'));
        return;
      }
      if (target.classList.contains('vms-ma-reset-meta-link-inline')) {
        evt.preventDefault();
        resetMetaLink();
      }
    });

    renderBuildMeta('');
  }

  function loadTemplatesList(options) {
    if (!VMS_MA.templatesUrl) {
      templateCache = [];
      renderTemplateSelect([], '');
      return Promise.resolve([]);
    }
    var selectedId = options && options.selectedId ? options.selectedId : '';
    var promise = request('/templates?limit=200', 'GET').then(function (json) {
      var items = (json && Array.isArray(json.items)) ? json.items : [];
      renderTemplateSelect(items, selectedId);
      return items;
    }).catch(function () {
      renderTemplateSelect([], '');
      return [];
    });

    var showOverlay = !(options && options.skipOverlay);
    if (showOverlay) {
      return withLoadingOverlay(promise, 'Loading templates…');
    }
    return promise;
  }

  function applyTemplatePayload(payload) {
    if (!payload || typeof payload !== 'object') {
      emitFeedback('error', 'Template payload is empty.', 'g');
      return;
    }

    var hasSquareImage = Object.prototype.hasOwnProperty.call(payload, 'image_square_id');
    var hasVerticalImage = Object.prototype.hasOwnProperty.call(payload, 'image_vertical_id');
    var hasWideImage = Object.prototype.hasOwnProperty.call(payload, 'image_wide_id');
    var hasAnyTemplateImage = hasSquareImage || hasVerticalImage || hasWideImage;

    // Saved settings templates intentionally omit event-specific creative images.
    // Clear any previously selected shared images when a template does not provide its own.
    if (!hasAnyTemplateImage) {
      setImageSelection('square', 0, '');
      setImageSelection('vertical', 0, '');
      setImageSelection('wide', 0, '');
    }

    // Legacy and settings-only templates do not carry event-scoped ad variant media.
    // Reset variant-specific media/text overrides first so stale selections from the last
    // event cannot bleed into a new draft when the template only changes audience/budget.
    if (!(payload.ad_variants && Array.isArray(payload.ad_variants))) {
      clearVariantOverridesPreservingPrimaryCopy();
    }

    if (payload.event_name != null) setField('vms-ma-event-name', payload.event_name);
    if (payload.venue_name != null) setField('vms-ma-venue-name', payload.venue_name);
    if (payload.event_start != null) setField('vms-ma-event-start', toLocalDateTime(payload.event_start));
    if (payload.destination_url != null) setField('vms-ma-destination-url', payload.destination_url);
    var templateStrategy = resolveStrategyTemplateKey(payload.strategy_template, payload.campaign_recipe);
    if (templateStrategy) {
      applySavedStrategyTemplate(templateStrategy);
    }
    if (payload.include_right_column_support != null) setChecked('vms-ma-include-right-column', !!parseIntSafe(payload.include_right_column_support, 0));
    if (payload.include_outer_towns_adset != null) setChecked('vms-ma-include-outer-towns-adset', !!parseIntSafe(payload.include_outer_towns_adset, 0));
    if (payload.video_format) setField('vms-ma-video-format', payload.video_format);
    if (payload.require_vertical_video != null) setChecked('vms-ma-require-vertical-video', !!parseIntSafe(payload.require_vertical_video, 0));
    if (payload.creative_automation_policy) setField('vms-ma-creative-automation-policy', payload.creative_automation_policy);
    if (payload.multi_advertiser_ads != null) setChecked('vms-ma-multi-advertiser-ads', !!parseIntSafe(payload.multi_advertiser_ads, 0));
    if (payload.post_asset_id != null) setField('vms-ma-post-id', payload.post_asset_id);
    if (payload.fb_event_id != null) setField('vms-ma-fb-event-id', payload.fb_event_id);

    if (payload.targeting_address != null) setField('vms-ma-targeting-address', payload.targeting_address);
    if (payload.radius_miles != null) setField('vms-ma-radius', payload.radius_miles);
    if (payload.age_min != null) setField('vms-ma-age-min', payload.age_min);
    if (payload.age_max != null) setField('vms-ma-age-max', payload.age_max);
    if (payload.audience_targeting != null || payload.gender != null || payload.interests != null) {
      setAudienceState(buildAudienceStateFromIncoming(
        payload.audience_targeting,
        payload.gender,
        Array.isArray(payload.interests) ? payload.interests : String(payload.interests || '')
      ), { skipDerived: true });
    }
    if (payload.locations != null) setField('vms-ma-locations', String(payload.locations).replace(/\s*,\s*/g, '\n'));
    if (payload.outer_towns_locations != null) setField('vms-ma-outer-locations', String(payload.outer_towns_locations).replace(/\s*,\s*/g, '\n'));
    if (payload.outer_towns_mode != null) setField('vms-ma-outer-towns-mode', payload.outer_towns_mode);
    if (payload.outer_towns_default_radius != null) setField('vms-ma-outer-default-radius', payload.outer_towns_default_radius);
    if (payload.placements_mode) {
      setPlacementsMode(payload.placements_mode);
    }
    if (Array.isArray(payload.placements)) {
      document.querySelectorAll('.vms-ma-placement').forEach(function (el) {
        el.checked = payload.placements.indexOf(String(el.value)) !== -1;
      });
      syncPlacementsUi();
    }

    if (payload.preset_mode) {
      setField('vms-ma-preset-mode', payload.preset_mode);
    }
    if (payload.end_buffer_hours != null) {
      setField('vms-ma-end_buffer_hours', payload.end_buffer_hours);
    }
    if (payload.manual_start) {
      setField('vms-ma-manual-start', toLocalDateTime(payload.manual_start));
    }
    if (payload.manual_end) {
      setField('vms-ma-manual-end', toLocalDateTime(payload.manual_end));
    }

    if (payload.total_budget_minor != null) {
      setField('vms-ma-budget-total', (parseIntSafe(payload.total_budget_minor, 0) / 100).toFixed(2));
    }
    if (payload.recipe_adset_state && typeof payload.recipe_adset_state === 'object') {
      replaceRecipeAdsetState(payload.recipe_adset_state);
    } else if (templateTouchesRecipePlanning(payload)) {
      clearRecipeAdsetState();
    }

    if (payload.ad_variants && Array.isArray(payload.ad_variants)) {
      applyAdVariants(payload.ad_variants);
    } else {
      if (payload.primary_text != null) setField('vms-ma-primary-text', payload.primary_text);
      if (payload.headline != null) setField('vms-ma-headline', payload.headline);
      if (payload.description != null) setField('vms-ma-description', payload.description);
    }

    if (payload.cta_type) {
      setField('vms-ma-cta-type', normalizeCtaType(payload.cta_type));
    }
    if (payload.force_buy_tickets_cta != null) {
      setChecked('vms-ma-force-buy-tickets', !!parseIntSafe(payload.force_buy_tickets_cta, 0));
    }
    syncCtaLockUi();
    if (hasSquareImage) {
      setField('vms-ma-image-square-id', payload.image_square_id || 0);
      syncImagePreviewFromId('square');
    }
    if (hasVerticalImage) {
      setField('vms-ma-image-vertical-id', payload.image_vertical_id || 0);
      syncImagePreviewFromId('vertical');
    }
    if (hasWideImage) {
      setField('vms-ma-image-wide-id', payload.image_wide_id || 0);
      syncImagePreviewFromId('wide');
    }

    renderCopyPackPanel();
    syncDerivedState();
    resolveApiButtonsState();
  }

  function applySelectedTemplate() {
    var select = byId('vms-ma-template-select');
    if (!select || !String(select.value || '').trim()) {
      emitFeedback('error', 'Select a template first.', 'g');
      return Promise.resolve(false);
    }
    var idVal = parseIntSafe(select.value, 0);
    if (!idVal) {
      emitFeedback('error', 'Invalid template selection.', 'g');
      return Promise.resolve(false);
    }
    var promise = request('/templates/' + encodeURIComponent(idVal), 'GET').then(function (json) {
      var item = json && json.item ? json.item : null;
      if (!item || !item.payload) {
        throw new Error('Template not found.');
      }
      applyTemplatePayload(item.payload);
      emitFeedback('success', 'Template applied.', 'g');
      return true;
    }).catch(function (err) {
      emitFeedback('error', (err && err.message) ? err.message : 'Unable to apply template.', 'g');
      return false;
    });
    return withLoadingOverlay(promise, 'Applying template…');
  }

  function saveTemplate() {
    var nameEl = byId('vms-ma-template-name');
    var name = nameEl ? String(nameEl.value || '').trim() : '';
    if (!name) {
      emitFeedback('error', 'Enter a template name first.', 'g');
      return Promise.resolve(false);
    }

    var payload = collectPayload();
    var include = getTemplateIncludeList();

    var promise = request('/templates', 'POST', {
      name: name,
      include: include,
      payload: payload
    }).then(function (json) {
      var item = json && json.item ? json.item : null;
      if (!item || !item.id) {
        throw new Error('Template save failed.');
      }
      emitFeedback('success', 'Template saved.', 'g');
      return loadTemplatesList({ skipOverlay: true, selectedId: item.id }).then(function () {
        return true;
      });
    }).catch(function (err) {
      emitFeedback('error', (err && err.message) ? err.message : 'Unable to save template.', 'g');
      return false;
    });

    return withLoadingOverlay(promise, 'Saving template…');
  }

  function deleteSelectedTemplate() {
    var select = byId('vms-ma-template-select');
    if (!select || !String(select.value || '').trim()) {
      emitFeedback('error', 'Select a template first.', 'g');
      return Promise.resolve(false);
    }
    var item = findTemplateItem(select.value);
    var label = item ? String(item.name || item.template_name || ('Template ' + String(item.id || ''))) : 'this template';
    if (!window.confirm('Delete "' + label + '"? This cannot be undone.')) {
      return Promise.resolve(false);
    }

    var templateId = parseIntSafe(select.value, 0);
    if (!templateId) {
      emitFeedback('error', 'Invalid template selection.', 'g');
      return Promise.resolve(false);
    }

    var promise = request('/templates/' + encodeURIComponent(templateId), 'DELETE').then(function () {
      emitFeedback('success', 'Template deleted.', 'g');
      return loadTemplatesList({ skipOverlay: true, selectedId: '' }).then(function () {
        return true;
      });
    }).catch(function (err) {
      emitFeedback('error', (err && err.message) ? err.message : 'Unable to delete template.', 'g');
      return false;
    });

    return withLoadingOverlay(promise, 'Deleting template…');
  }

  function bindTemplates() {
    var select = byId('vms-ma-template-select');
    var applyBtn = byId('vms-ma-apply-template');
    var deleteBtn = byId('vms-ma-delete-template');
    var refreshBtn = byId('vms-ma-refresh-templates');
    var saveBtn = byId('vms-ma-save-template');
    var clearNameBtn = byId('vms-ma-clear-template-name');

    if (select) {
      select.addEventListener('change', function () {
        renderTemplateMeta();
      });
    }

    if (applyBtn) {
      applyBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        applySelectedTemplate();
      });
    }

    if (deleteBtn) {
      deleteBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        deleteSelectedTemplate();
      });
    }

    if (refreshBtn) {
      refreshBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        loadTemplatesList();
      });
    }

    if (saveBtn) {
      saveBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        saveTemplate();
      });
    }

    if (clearNameBtn) {
      clearNameBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        var nameEl = byId('vms-ma-template-name');
        if (nameEl) {
          nameEl.value = '';
        }
      });
    }

    loadTemplatesList({ skipOverlay: true });
  }

  function initImagePickers() {
    ['square', 'vertical', 'wide'].forEach(function (kind) {
      var chooseBtn = getImageActionButton(kind, 'choose');
      var clearBtn = getImageActionButton(kind, 'clear');

      if (chooseBtn) {
        chooseBtn.addEventListener('click', function (evt) {
          evt.preventDefault();
          openMediaPicker(kind);
        });
      }

      if (clearBtn) {
        clearBtn.addEventListener('click', function (evt) {
          evt.preventDefault();
          setImageSelection(kind, 0, '');
          renderCopyPackPanel();
        });
      }

      // If an ID is already present (draft/template), hydrate the preview.
      syncImagePreviewFromId(kind);
    });
  }

  function initVariantMediaPickers() {
    builder.querySelectorAll('.vms-ma-pick-variant-media').forEach(function (button) {
      button.addEventListener('click', function (evt) {
        evt.preventDefault();
        openVariantMediaPicker(button.getAttribute('data-variant'), button.getAttribute('data-media-type'));
      });
    });

    builder.querySelectorAll('.vms-ma-clear-variant-media').forEach(function (button) {
      button.addEventListener('click', function (evt) {
        evt.preventDefault();
        var index = parseIntSafe(button.getAttribute('data-variant'), 0);
        var mediaType = String(button.getAttribute('data-media-type') || '').toLowerCase() === 'video' ? 'video' : 'image';
        setVariantMediaSelection(index, mediaType, 0, {});
        renderCopyPackPanel();
      });
    });

    [1, 2, 3].forEach(function (index) {
      syncVariantMediaUi(index);
      syncVariantMediaPreview(index, 'image');
      syncVariantMediaPreview(index, 'video');
    });
  }

  function applyDefaultPreset() {
    var presetEl = byId('vms-ma-preset-mode');
    if (!presetEl) {
      return;
    }
    var preset = String(VMS_MA.defaultPreset || 'simple_14_day');
    if (presetEl.querySelector('option[value="' + preset + '"]')) {
      presetEl.value = preset;
      dispatchFieldEvents(presetEl);
    }
  }

  builder.addEventListener('click', function (evt) {
    var target = evt.target;
    if (!target) {
      return;
    }
    var audienceChip = target.closest ? target.closest('.vms-ma-audience-chip') : null;
    if (audienceChip && builder.contains(audienceChip)) {
      evt.preventDefault();
      toggleAudienceSuggestionTerm(audienceChip.getAttribute('data-audience-term-key'));
      updateDirtyState();
      return;
    }
    var removeAudienceTerm = target.closest ? target.closest('[data-audience-remove-term]') : null;
    if (removeAudienceTerm && builder.contains(removeAudienceTerm)) {
      evt.preventDefault();
      removeAudienceSelectedTerm(removeAudienceTerm.getAttribute('data-audience-remove-term'));
      updateDirtyState();
      return;
    }
    var removeAudienceArtist = target.closest ? target.closest('[data-audience-remove-artist]') : null;
    if (removeAudienceArtist && builder.contains(removeAudienceArtist)) {
      evt.preventDefault();
      removeAudienceArtistInspiration(removeAudienceArtist.getAttribute('data-audience-remove-artist'));
      updateDirtyState();
      return;
    }
    if (target.classList && target.classList.contains('notice-dismiss') && notices && notices.contains(target)) {
      evt.preventDefault();
      clearNotice();
      return;
    }
    if (target.id === 'vms-ma-save-draft') {
      evt.preventDefault();
      saveDraft();
      return;
    }
    if (target.id === 'vms-ma-export-pack') {
      evt.preventDefault();
      exportPack();
      return;
    }
    if (target.id === 'vms-ma-meta-dry-run') {
      evt.preventDefault();
      previewMetaDryRun();
      return;
    }
    if (target.id === 'vms-ma-create-paused') {
      evt.preventDefault();
      createPaused();
      return;
    }
    if (target.id === 'vms-ma-go-live') {
      evt.preventDefault();
      goLive();
      return;
    }
    if (target.id === 'vms-ma-reset-meta-link') {
      evt.preventDefault();
      resetMetaLink();
    }
  });

  document.addEventListener('vms-ma-toast', function (evt) {
    var detail = evt && evt.detail ? evt.detail : {};
    if (!detail.message) {
      return;
    }
    emitFeedback(detail.type || 'info', detail.message, detail.stepKey || 'g');
  });

  builder.addEventListener('change', function (evt) {
    var target = evt.target;
    if (!target) {
      return;
    }
    if (target.hasAttribute('data-recipe-adset-budget')) {
      setRecipeAdsetBudgetMinor(target.getAttribute('data-recipe-adset-budget'), parseRecipeBudgetInputMinor(target.value));
    }
    if (target.name === 'vms_ma_audience_mode' || target.id === 'vms-ma-gender' || target.id === 'vms-ma-audience-event-type' || target.id === 'vms-ma-audience-preset' || target.id === 'vms-ma-advantage-audience' || target.id === 'vms-ma-advantage-detailed-targeting' || target.id === 'vms-ma-interests') {
      syncAudienceStateFromForm();
      renderAudienceTargetingUi();
      renderCopyPackPanel();
    }
    if (target.id === 'vms-ma-strategy-template') {
      applyCampaignStrategy(value('vms-ma-strategy-template') || 'custom', true);
    }
    if (target.name === 'vms_ma_creative_mode') {
      syncCreativeFields();
    }
    if (target.name === 'vms_ma_placements_mode') {
      syncPlacementsUi();
      renderCopyPackPanel();
    }
    if (/^vms-ma-variant-[123]-placement-slot$/.test(String(target.id || ''))) {
      renderCopyPackPanel();
      renderRecipePreview();
      renderCreativeFormatRequirements();
    }
    if (/^vms-ma-variant-[123]-media-mode$/.test(String(target.id || ''))) {
      var mediaModeMatch = String(target.id || '').match(/^vms-ma-variant-(\d+)-media-mode$/);
      if (mediaModeMatch) {
        syncVariantMediaUi(mediaModeMatch[1]);
      }
      renderCopyPackPanel();
      renderRecipePreview();
      renderCreativeFormatRequirements();
    }
    if (target.classList && target.classList.contains('vms-ma-placement')) {
      renderCopyPackPanel();
      renderRecipePreview();
      renderCreativeFormatRequirements();
    }
    if (target.id === 'vms-ma-include-right-column') {
      var rightColumnPlacement = builder.querySelector('.vms-ma-placement[value="fb_right_column"]');
      if (rightColumnPlacement) {
        rightColumnPlacement.checked = !!target.checked;
      }
      renderCleanRoomRecipeChecklist();
      renderRecipePreview();
      renderCreativeFormatRequirements();
      renderCopyPackPanel();
    }
    if (target.id === 'vms-ma-include-outer-towns-adset') {
      renderCleanRoomRecipeChecklist();
      renderRecipePreview();
      renderCopyPackPanel();
    }
    if (target.id === 'vms-ma-video-format' || target.id === 'vms-ma-require-vertical-video') {
      renderRecipePreview();
      renderCreativeFormatRequirements();
      renderCopyPackPanel();
    }
    if (String(target.id || '').indexOf('vms-ma-qa-') === 0) {
      syncLaunchQaState();
    }
    if (target.id === 'vms-ma-force-buy-tickets' || target.id === 'vms-ma-creative-automation-policy' || target.id === 'vms-ma-multi-advertiser-ads' || target.id === 'vms-ma-outer-towns-mode' || target.id === 'vms-ma-outer-default-radius') {
      syncCtaLockUi();
      renderCopyPackPanel();
    }
    if (target.id === 'vms-ma-cta-type' || target.id === 'vms-ma-locations' || target.id === 'vms-ma-targeting-address' || target.id === 'vms-ma-outer-towns-mode' || target.id === 'vms-ma-outer-locations' || target.id === 'vms-ma-outer-default-radius' || target.id === 'vms-ma-include-outer-towns-adset') {
      syncCtaLockUi();
      renderRecipePreview();
      renderCopyPackPanel();
    }
    syncDerivedState({ forceAgeClamp: true });
    updateDirtyState();
  });

  builder.addEventListener('input', function (evt) {
    var target = evt.target;
    if (target && target.id === 'vms-ma-interests') {
      syncAudienceStateFromForm();
      renderAudienceTargetingUi();
    }
    if (target && target.hasAttribute && target.hasAttribute('data-recipe-adset-enabled')) {
      setRecipeAdsetEnabled(target.getAttribute('data-recipe-adset-enabled'), !!target.checked);
    }
    if (target && target.hasAttribute && target.hasAttribute('data-recipe-adset-budget')) {
      setRecipeAdsetBudgetMinor(target.getAttribute('data-recipe-adset-budget'), parseRecipeBudgetInputMinor(target.value));
      refreshRecipeBudgetPreviewInline();
      renderBudgetMinimumNote();
      renderCreateStructurePreview();
      renderRecipePreview();
      resolveApiButtonsState();
      updateDirtyState();
      return;
    }
    syncDerivedState({ forceAgeClamp: false });
    updateDirtyState();
  });

  initEventPicker();
  initAudienceTargetingUi();
  bindBuildManager();
  bindTemplates();
  bindSpecTools();
  initImagePickers();
  initVariantMediaPickers();
  bindModal();
  initAnalyticsPanel();
  applyDefaultPreset();
  applyCampaignStrategy(value('vms-ma-strategy-template') || 'clean_room_full_push_v2', false);
  syncCreativeFields();
  bindCopyButtons();
  bindCreativeHelpers();
  bindRegenerate();
  updateApiAssistVisibility();
  hydratePostAndEventPickers();
  updateMetaLink({});
  renderBudgetSyncState({});
  renderMetaAdsetDetails({});
  renderMetaReadiness({});
  renderRecipePreview();
  renderCreativeFormatRequirements();
  syncLaunchQaState();
  setMetaInline('Select an Event Plan to load Meta status.');
  resolveApiButtonsState();
  syncDerivedState({ forceAgeClamp: true });
  updateDirtyState();

  if (builder.getAttribute('data-copy-pack-hint') === '1') {
    emitFeedback('info', 'Copy Pack mode: complete Steps A-E, then open Advanced / Export, Copy Pack + Templates when you need the export tools.', 'g');
    var exportBtn = byId('vms-ma-export-pack');
    if (exportBtn) {
      exportBtn.classList.add('button-primary');
    }
  }
})();
