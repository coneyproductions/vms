<?php
/**
 * Plugin Name: VMS Meta Ads Builder
 * Description: Guided Meta (Facebook + Instagram) ads builder for VMS event plans, featuring copy packs, drift-safe tours, and optional API creation.
 * Version: 0.1.107
 * Author: Serenade Range
 * Text Domain: vms-meta-ads
 */

defined('ABSPATH') || exit;

if (!defined('VMS_MA_PATH')) {
    define('VMS_MA_PATH', plugin_dir_path(__FILE__));
}
if (!defined('VMS_MA_URL')) {
    define('VMS_MA_URL', plugin_dir_url(__FILE__));
}
if (!defined('VMS_MA_VERSION')) {
define('VMS_MA_VERSION', '0.1.107');
}

require_once VMS_MA_PATH . 'includes/core-compat.php';
require_once VMS_MA_PATH . 'includes/bootstrap.php';

register_activation_hook(__FILE__, array('VMS_Meta_Ads', 'activate'));
register_deactivation_hook(__FILE__, array('VMS_Meta_Ads', 'deactivate'));

VMS_Meta_Ads::init();
