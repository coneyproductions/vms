# VMS Refer-a-Friend

## What this build includes
- Ticket-only referral links and codes
- Referral cookie capture via `?vms_ref=CODE`
- Checkout referral field (not coupon-based)
- Qualification on configurable Woo order statuses
- Credits ledger
- Reward catalog
- Reward claims with claim codes
- Admin dashboard, logs, settings, and guided help tour
- Woo My Account endpoint: `Refer a Friend`
- Shortcode: `[vms_refer_a_friend]`

## Important assumptions in this first build
- WooCommerce is active
- Event tickets are Woo products and either:
  - have event-linked product meta, or
  - live inside selected product categories
- Reward fulfillment is manual / staff-verified, not shipped automatically

## Recommended first setup
1. Activate the plugin.
2. Visit **VMS Marketing & Social > Refer-a-Friend > Settings**.
3. Select your ticket product categories.
4. Confirm qualifying statuses.
5. Add a few rewards.
6. Test with two customer accounts.

## Shortcode
Use `[vms_refer_a_friend]` on any page if you want to expose the referral dashboard outside My Account.
