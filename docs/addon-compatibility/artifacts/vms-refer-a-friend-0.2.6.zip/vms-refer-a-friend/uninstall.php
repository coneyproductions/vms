<?php

if (! defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Intentionally conservative: preserve data unless the operator deletes it manually.
