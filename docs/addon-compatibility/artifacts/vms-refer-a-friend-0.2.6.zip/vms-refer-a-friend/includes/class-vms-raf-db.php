<?php

if (! defined('ABSPATH')) {
    exit;
}

class VMS_RAF_DB
{
    public static function maybe_upgrade()
    {
        $stored = get_option('vms_raf_version');
        if ($stored === VMS_RAF_VERSION) {
            return;
        }

        self::create_tables();
        self::seed_defaults();
    }

    public static function activate()
    {
        self::create_tables();
        self::seed_defaults();
        VMS_RAF_Plugin::register_endpoint();
        flush_rewrite_rules();
    }

    public static function deactivate()
    {
        flush_rewrite_rules();
    }

    public static function create_tables()
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $prefix  = $wpdb->prefix . 'vms_raf_';

        $sql = [];

        $sql[] = "CREATE TABLE {$prefix}codes (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            code VARCHAR(64) NOT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_id (user_id),
            UNIQUE KEY code (code)
        ) {$charset};";

        $sql[] = "CREATE TABLE {$prefix}referrals (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            referrer_user_id BIGINT UNSIGNED NOT NULL,
            referred_user_id BIGINT UNSIGNED NULL,
            referred_email VARCHAR(190) NULL,
            referral_code_id BIGINT UNSIGNED NULL,
            referral_code VARCHAR(64) NOT NULL,
            order_id BIGINT UNSIGNED NOT NULL,
            event_post_id BIGINT UNSIGNED NULL,
            qualifying_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
            status VARCHAR(32) NOT NULL DEFAULT 'pending',
            qualified_at DATETIME NULL,
            reversed_at DATETIME NULL,
            reversal_reason VARCHAR(190) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY order_id (order_id),
            KEY referrer_user_id (referrer_user_id),
            KEY referred_user_id (referred_user_id),
            KEY referred_email (referred_email),
            KEY status (status)
        ) {$charset};";

        $sql[] = "CREATE TABLE {$prefix}credits_ledger (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            referral_id BIGINT UNSIGNED NULL,
            delta_credits INT NOT NULL,
            entry_type VARCHAR(32) NOT NULL,
            notes TEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY referral_id (referral_id),
            KEY entry_type (entry_type)
        ) {$charset};";

        $sql[] = "CREATE TABLE {$prefix}rewards (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            description TEXT NULL,
            credit_cost INT NOT NULL DEFAULT 1,
            reward_type VARCHAR(32) NOT NULL DEFAULT 'physical_claim',
            discount_type VARCHAR(32) NOT NULL DEFAULT 'fixed_cart',
            discount_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
            coupon_expiry_days INT NOT NULL DEFAULT 30,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            sort_order INT NOT NULL DEFAULT 0,
            fulfillment_notes TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY is_active (is_active),
            KEY sort_order (sort_order),
            KEY reward_type (reward_type)
        ) {$charset};";

        $sql[] = "CREATE TABLE {$prefix}claims (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            reward_id BIGINT UNSIGNED NOT NULL,
            credits_spent INT NOT NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'pending',
            claim_code VARCHAR(64) NOT NULL,
            redeemed_by_user_id BIGINT UNSIGNED NULL,
            redeemed_at DATETIME NULL,
            notes TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY claim_code (claim_code),
            KEY user_id (user_id),
            KEY reward_id (reward_id),
            KEY status (status)
        ) {$charset};";

        foreach ($sql as $statement) {
            dbDelta($statement);
        }
    }

    public static function seed_defaults()
    {
        $defaults = [
            'enabled'                  => 'yes',
            'credits_per_referral'     => 1,
            'minimum_order_amount'     => 20,
            'cookie_days'              => 30,
            'exclude_free'             => 'yes',
            'require_event_context'    => 'yes',
            'first_purchase_only'      => 'yes',
            'qualifying_statuses'      => ['processing', 'completed'],
            'reverse_statuses'         => ['refunded', 'cancelled'],
            'eligible_categories'      => [],
            'friend_discount_enabled'  => 'yes',
            'friend_discount_type'     => 'fixed_cart',
            'friend_discount_amount'   => 5,
            'friend_discount_label'    => 'Friend referral savings',
            'referral_landing_url'     => home_url('/'),
            'claim_prefix'             => 'RAF',
            'customer_intro'           => 'Invite friends to buy tickets. Your friend can save on a qualifying ticket order, and you earn credits you can redeem for venue rewards or future ticket discounts.',
            'customer_reward_label'    => 'Referral Credits',
            'share_message'            => 'Invite your friends to this venue. When they buy qualifying tickets, you earn referral credits you can redeem later.',
        ];

        $settings = get_option('vms_raf_settings');
        if (false === $settings) {
            add_option('vms_raf_settings', $defaults);
        } else {
            update_option('vms_raf_settings', wp_parse_args((array) $settings, $defaults));
        }

        if (! get_option('vms_raf_version')) {
            add_option('vms_raf_version', VMS_RAF_VERSION);
        } else {
            update_option('vms_raf_version', VMS_RAF_VERSION);
        }
    }
}
