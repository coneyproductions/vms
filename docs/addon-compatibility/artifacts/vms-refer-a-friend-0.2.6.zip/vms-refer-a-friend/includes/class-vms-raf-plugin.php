<?php

if (! defined('ABSPATH')) {
    exit;
}

class VMS_RAF_Plugin
{
    protected static $instance = null;
    protected $screen_tours = [];

    public static function instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        add_action('init', [__CLASS__, 'register_endpoint'], 0);
        add_action('init', [$this, 'capture_referral_from_request']);
        add_action('init', [$this, 'handle_frontend_actions']);

        add_action('admin_menu', [$this, 'register_admin_menu'], 99);
        add_action('vms_admin_register_pages', [$this, 'register_vms_admin_pages'], 20);
        add_action('admin_init', [$this, 'handle_admin_actions']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);

        add_shortcode('vms_refer_a_friend', [$this, 'render_shortcode']);

        add_filter('woocommerce_account_menu_items', [$this, 'add_account_menu_item']);
        add_filter('woocommerce_get_query_vars', [$this, 'add_account_query_var']);
        add_action('woocommerce_account_refer-a-friend_endpoint', [$this, 'render_account_endpoint']);
        add_action('woocommerce_after_checkout_billing_form', [$this, 'render_checkout_referral_field']);
        add_action('woocommerce_register_form', [$this, 'render_registration_referral_field']);
        add_action('woocommerce_created_customer', [$this, 'capture_registration_referral']);
        add_action('woocommerce_checkout_update_order_review', [$this, 'capture_checkout_referral_code_from_update']);
        add_action('woocommerce_after_checkout_validation', [$this, 'validate_checkout_referral'], 20, 2);
        add_action('woocommerce_cart_calculate_fees', [$this, 'maybe_apply_friend_discount'], 20, 1);
        add_action('woocommerce_checkout_create_order', [$this, 'attach_referral_code_to_order'], 20, 2);
        add_action('woocommerce_checkout_order_processed', [$this, 'ensure_pending_referral'], 20, 1);
        add_action('woocommerce_thankyou', [$this, 'render_thankyou_notice'], 15, 1);
        add_action('woocommerce_order_status_changed', [$this, 'maybe_process_order_status_change'], 20, 4);

        add_action('user_register', [$this, 'ensure_user_code']);
    }

    public static function register_endpoint()
    {
        add_rewrite_endpoint('refer-a-friend', EP_ROOT | EP_PAGES);
    }

    public function add_account_query_var($vars)
    {
        $vars['refer-a-friend'] = 'refer-a-friend';
        return $vars;
    }

    public function add_account_menu_item($items)
    {
        if (! is_user_logged_in()) {
            return $items;
        }

        $logout = [];
        if (isset($items['customer-logout'])) {
            $logout['customer-logout'] = $items['customer-logout'];
            unset($items['customer-logout']);
        }

        $items['refer-a-friend'] = __('Refer a Friend', 'vms-refer-a-friend');

        return array_merge($items, $logout);
    }

    public function enqueue_admin_assets($hook_suffix)
    {
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        if (false === strpos((string) $hook_suffix, 'vms-raf') && 0 !== strpos($page, 'vms-raf')) {
            return;
        }

        wp_enqueue_style('vms-raf-admin', VMS_RAF_URL . 'assets/css/admin.css', [], VMS_RAF_VERSION);
        wp_enqueue_script('vms-raf-admin', VMS_RAF_URL . 'assets/js/admin.js', [], VMS_RAF_VERSION, true);
        wp_enqueue_script('vms-raf-admin-tour', VMS_RAF_URL . 'assets/js/admin-tour.js', [], VMS_RAF_VERSION, true);

        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $tour   = [];
        if ($screen && isset($this->screen_tours[$screen->id])) {
            $tour = $this->screen_tours[$screen->id];
        }
        if (! $tour && $page) {
            $tour = $this->get_admin_tour_steps_for_page($page);
        }

        wp_localize_script('vms-raf-admin-tour', 'vmsRafTour', [
            'steps'  => $tour,
            'labels' => [
                'start' => __('Start tour', 'vms-refer-a-friend'),
                'next'  => __('Next', 'vms-refer-a-friend'),
                'done'  => __('Done', 'vms-refer-a-friend'),
                'skip'  => __('Skip', 'vms-refer-a-friend'),
            ],
        ]);
    }

    public function enqueue_frontend_assets()
    {
        wp_enqueue_style('vms-raf-frontend', VMS_RAF_URL . 'assets/css/frontend.css', [], VMS_RAF_VERSION);
        wp_enqueue_script('vms-raf-frontend', VMS_RAF_URL . 'assets/js/frontend.js', [], VMS_RAF_VERSION, true);

        wp_localize_script('vms-raf-frontend', 'vmsRafFrontend', [
            'copySuccess' => __('Copied.', 'vms-refer-a-friend'),
            'copyFailure' => __('Copy failed. Please copy the link manually.', 'vms-refer-a-friend'),
        ]);
    }

    public function render_shortcode()
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return '<div class="vms-raf-card"><p>' . esc_html__('Refer-a-Friend is not active right now.', 'vms-refer-a-friend') . '</p></div>';
        }

        if (! is_user_logged_in()) {
            return '<div class="vms-raf-card"><p>' . esc_html__('Please log in to access your referral link and rewards.', 'vms-refer-a-friend') . '</p></div>';
        }

        return $this->get_frontend_dashboard_html(get_current_user_id());
    }

    public function render_account_endpoint()
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            echo '<p>' . esc_html__('Refer-a-Friend is not active right now.', 'vms-refer-a-friend') . '</p>';
            return;
        }

        if (! is_user_logged_in()) {
            echo '<p>' . esc_html__('Please log in to access your referral link and rewards.', 'vms-refer-a-friend') . '</p>';
            return;
        }

        echo $this->get_frontend_dashboard_html(get_current_user_id());
    }

    protected function get_frontend_dashboard_html($user_id)
    {
        $settings                = $this->get_settings();
        $reward_label            = $settings['customer_reward_label'];
        $code                    = $this->get_or_create_user_code($user_id);
        $link                    = $this->build_referral_link($code, $settings);
        $available               = $this->get_available_credits($user_id);
        $lifetime                = $this->get_lifetime_credits($user_id);
        $pending                 = $this->get_pending_referrals_count($user_id);
        $rewards                 = $this->sort_frontend_rewards($this->get_rewards(['active_only' => true]), $available);
        $claims                  = $this->get_claims(['user_id' => $user_id, 'limit' => 20]);
        $recent                  = $this->get_referrals(['referrer_user_id' => $user_id, 'limit' => 20]);
        $notice                  = isset($_GET['vms_raf_notice']) ? sanitize_text_field(wp_unslash($_GET['vms_raf_notice'])) : '';
        $link_input_id           = wp_unique_id('vms-raf-link-');
        $copy_feedback_id        = wp_unique_id('vms-raf-copy-feedback-');
        $minimum_order_amount    = (float) $settings['minimum_order_amount'];
        $minimum_order_formatted = $minimum_order_amount > 0 ? $this->format_currency_amount($minimum_order_amount) : '';
        $offer_headline          = $this->get_referral_offer_headline($settings);
        $intro_copy              = ! empty($settings['customer_intro'])
            ? $settings['customer_intro']
            : __('Share your personal invite link with friends headed to the venue. When they buy qualifying tickets, your reward credits are added automatically.', 'vms-refer-a-friend');
        $fine_print_note         = $minimum_order_formatted
            ? sprintf(__('Qualifying paid ticket orders only. Minimum order: %s. Additional venue ticket rules may apply.', 'vms-refer-a-friend'), $minimum_order_formatted)
            : __('Qualifying paid ticket orders only. Additional venue ticket rules may apply.', 'vms-refer-a-friend');

        ob_start();
        ?>
        <div class="vms-raf-grid vms-raf-dashboard">
            <?php if ($notice) : ?>
                <div class="vms-raf-notice"><?php echo esc_html($this->translate_frontend_notice($notice)); ?></div>
            <?php endif; ?>

            <section class="vms-raf-card vms-raf-hero vms-raf-span-full">
                <div class="vms-raf-hero-main">
                    <h2><?php esc_html_e('Refer a Friend', 'vms-refer-a-friend'); ?></h2>
                    <p class="vms-raf-offer"><?php echo esc_html($offer_headline); ?></p>
                    <p class="vms-raf-hero-copy"><?php echo esc_html($intro_copy); ?></p>
                    <div class="vms-raf-link-wrap">
                        <label class="vms-raf-link-label" for="<?php echo esc_attr($link_input_id); ?>"><?php esc_html_e('Your invite link', 'vms-refer-a-friend'); ?></label>
                        <div class="vms-raf-link-controls">
                            <input
                                type="text"
                                readonly
                                id="<?php echo esc_attr($link_input_id); ?>"
                                value="<?php echo esc_attr($link); ?>"
                                class="vms-raf-link-input"
                                data-vms-raf-copy-source="true"
                            >
                            <button
                                type="button"
                                class="button button-primary vms-raf-copy-button"
                                data-copy-target="<?php echo esc_attr($link_input_id); ?>"
                                data-copy-feedback="<?php echo esc_attr($copy_feedback_id); ?>"
                            ><?php esc_html_e('Copy invite link', 'vms-refer-a-friend'); ?></button>
                        </div>
                        <p id="<?php echo esc_attr($copy_feedback_id); ?>" class="vms-raf-copy-feedback" aria-live="polite" hidden></p>
                    </div>
                    <p class="vms-raf-code-inline">
                        <span><?php esc_html_e('Referral code:', 'vms-refer-a-friend'); ?></span>
                        <strong><?php echo esc_html($code); ?></strong>
                    </p>
                </div>
            </section>

            <div class="vms-raf-card vms-raf-stat-card">
                <h3><?php echo esc_html($reward_label); ?></h3>
                <div class="vms-raf-stat"><?php echo esc_html((string) $available); ?></div>
                <p class="vms-raf-muted"><?php esc_html_e('Available to spend now', 'vms-refer-a-friend'); ?></p>
            </div>

            <div class="vms-raf-card vms-raf-stat-card">
                <h3><?php esc_html_e('Lifetime earned', 'vms-refer-a-friend'); ?></h3>
                <div class="vms-raf-stat"><?php echo esc_html((string) $lifetime); ?></div>
                <p class="vms-raf-muted"><?php esc_html_e('All time credits earned', 'vms-refer-a-friend'); ?></p>
            </div>

            <div class="vms-raf-card vms-raf-stat-card">
                <h3><?php esc_html_e('Pending referrals', 'vms-refer-a-friend'); ?></h3>
                <div class="vms-raf-stat"><?php echo esc_html((string) $pending); ?></div>
                <p class="vms-raf-muted"><?php esc_html_e('Friends who have started but not yet qualified', 'vms-refer-a-friend'); ?></p>
            </div>

            <section class="vms-raf-card vms-raf-span-full">
                <div class="vms-raf-section-heading">
                    <div>
                        <h2><?php esc_html_e('How it works', 'vms-refer-a-friend'); ?></h2>
                        <p class="vms-raf-muted"><?php esc_html_e('A simple overview of what happens after you share your invite link.', 'vms-refer-a-friend'); ?></p>
                    </div>
                </div>
                <div class="vms-raf-steps">
                    <article class="vms-raf-step">
                        <span class="vms-raf-step-number">1</span>
                        <h3><?php esc_html_e('Share your invite link', 'vms-refer-a-friend'); ?></h3>
                        <p><?php esc_html_e('Send your personal link anywhere friends are planning their next visit.', 'vms-refer-a-friend'); ?></p>
                    </article>
                    <article class="vms-raf-step">
                        <span class="vms-raf-step-number">2</span>
                        <h3><?php esc_html_e('Your friend saves on tickets', 'vms-refer-a-friend'); ?></h3>
                        <p><?php esc_html_e('They use your link while checking out and get the current referral offer when their order qualifies.', 'vms-refer-a-friend'); ?></p>
                    </article>
                    <article class="vms-raf-step">
                        <span class="vms-raf-step-number">3</span>
                        <h3><?php esc_html_e('You earn reward credits', 'vms-refer-a-friend'); ?></h3>
                        <p><?php esc_html_e('Once the order qualifies, your credits are added automatically and can be redeemed below.', 'vms-refer-a-friend'); ?></p>
                    </article>
                </div>
                <p class="vms-raf-fine-print"><?php echo esc_html($fine_print_note); ?></p>
            </section>

            <section class="vms-raf-card vms-raf-span-full">
                <h2><?php esc_html_e('Redeem rewards', 'vms-refer-a-friend'); ?></h2>
                <?php if (empty($rewards)) : ?>
                    <div class="vms-raf-empty-state">
                        <h3><?php esc_html_e('Rewards are coming soon', 'vms-refer-a-friend'); ?></h3>
                        <p><?php esc_html_e('Keep sharing your invite link. Active rewards will appear here as soon as they are available.', 'vms-refer-a-friend'); ?></p>
                    </div>
                <?php else : ?>
                    <div class="vms-raf-reward-grid">
                        <?php foreach ($rewards as $reward) : ?>
                            <?php
                            $reward_cost      = max(1, (int) $reward->credit_cost);
                            $progress_value   = max(0, min(max(0, $available), $reward_cost));
                            $credits_needed   = max(0, $reward_cost - $available);
                            $progress_caption = sprintf(__('%1$s / %2$s', 'vms-refer-a-friend'), number_format_i18n($progress_value), $this->format_reward_credit_count($reward_cost));
                            $progress_detail  = $credits_needed > 0
                                ? sprintf(_n('Need %s more credit.', 'Need %s more credits.', $credits_needed, 'vms-refer-a-friend'), number_format_i18n($credits_needed))
                                : __('Ready to redeem.', 'vms-refer-a-friend');
                            ?>
                            <article class="vms-raf-reward-item">
                                <div class="vms-raf-reward-header">
                                    <strong><?php echo esc_html($reward->name); ?></strong>
                                    <span class="vms-raf-pill"><?php echo esc_html($this->format_reward_credit_count($reward_cost)); ?></span>
                                </div>
                                <div class="vms-raf-reward-main">
                                    <?php if (! empty($reward->description)) : ?>
                                        <p class="vms-raf-reward-description"><?php echo esc_html($reward->description); ?></p>
                                    <?php endif; ?>
                                    <div class="vms-raf-progress-copy">
                                        <strong><?php echo esc_html($progress_caption); ?></strong>
                                        <span class="vms-raf-muted"><?php echo esc_html($progress_detail); ?></span>
                                    </div>
                                    <progress class="vms-raf-progress" max="<?php echo esc_attr((string) $reward_cost); ?>" value="<?php echo esc_attr((string) $progress_value); ?>">
                                        <?php echo esc_html((string) $progress_value); ?>
                                    </progress>
                                </div>
                                <?php if ($available >= $reward_cost) : ?>
                                    <div class="vms-raf-reward-actions">
                                        <form method="post">
                                            <?php wp_nonce_field('vms_raf_redeem_reward', 'vms_raf_nonce'); ?>
                                            <input type="hidden" name="vms_raf_action" value="redeem_reward">
                                            <input type="hidden" name="reward_id" value="<?php echo esc_attr((string) $reward->id); ?>">
                                            <button type="submit" class="button button-secondary"><?php esc_html_e('Redeem', 'vms-refer-a-friend'); ?></button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>

            <section class="vms-raf-card">
                <h2><?php esc_html_e('My claims', 'vms-refer-a-friend'); ?></h2>
                <?php if (empty($claims)) : ?>
                    <div class="vms-raf-empty-state"><p><?php esc_html_e('No claims yet. Redeemed rewards will show up here with their code or coupon details.', 'vms-refer-a-friend'); ?></p></div>
                <?php else : ?>
                    <div class="vms-raf-table-wrap">
                        <table class="vms-raf-table">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Reward', 'vms-refer-a-friend'); ?></th>
                                    <th><?php esc_html_e('Code', 'vms-refer-a-friend'); ?></th>
                                    <th><?php esc_html_e('Status', 'vms-refer-a-friend'); ?></th>
                                    <th><?php esc_html_e('Details', 'vms-refer-a-friend'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($claims as $claim) : ?>
                                    <tr>
                                        <td><?php echo esc_html($claim->reward_name); ?></td>
                                        <td><?php echo esc_html($claim->claim_code); ?></td>
                                        <td><span class="vms-raf-pill vms-raf-pill-status"><?php echo esc_html(ucfirst($claim->status)); ?></span></td>
                                        <td><?php echo ! empty($claim->notes) ? esc_html($claim->notes) : '-'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>

            <section class="vms-raf-card">
                <h2><?php esc_html_e('Referral activity', 'vms-refer-a-friend'); ?></h2>
                <?php if (empty($recent)) : ?>
                    <div class="vms-raf-empty-state"><p><?php esc_html_e('No referrals yet. Share your invite link above and qualifying friend purchases will appear here.', 'vms-refer-a-friend'); ?></p></div>
                <?php else : ?>
                    <div class="vms-raf-table-wrap">
                        <table class="vms-raf-table">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Friend', 'vms-refer-a-friend'); ?></th>
                                    <th><?php esc_html_e('Status', 'vms-refer-a-friend'); ?></th>
                                    <th><?php esc_html_e('Credits', 'vms-refer-a-friend'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent as $referral) : ?>
                                    <tr>
                                        <td><?php echo esc_html($this->get_frontend_referral_customer_label($referral)); ?></td>
                                        <td><span class="vms-raf-pill vms-raf-pill-status"><?php echo esc_html(ucfirst($referral->status)); ?></span></td>
                                        <td><?php echo esc_html($this->format_reward_credit_count((int) $settings['credits_per_referral'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    protected function build_referral_link($code, $settings = null)
    {
        if (null === $settings) {
            $settings = $this->get_settings();
        }

        return add_query_arg('vms_ref', $code, $this->get_referral_landing_url($settings));
    }

    protected function get_referral_landing_url($settings = null)
    {
        if (null === $settings) {
            $settings = $this->get_settings();
        }

        return $this->normalize_referral_landing_url($settings['referral_landing_url'] ?? '', $this->get_default_referral_landing_url());
    }

    protected function get_default_referral_landing_url()
    {
        $candidates = [];

        if (vms_raf_has_core_function('vms_get_public_event_calendar_url')) {
            $candidates[] = (string) vms_raf_call_core_function('vms_get_public_event_calendar_url');
        }

        if (function_exists('tribe_get_events_link')) {
            $candidates[] = (string) tribe_get_events_link();
        }

        $candidates[] = home_url('/');

        foreach ($candidates as $candidate) {
            $normalized = $this->sanitize_referral_landing_candidate($candidate);
            if ('' !== $normalized) {
                return $normalized;
            }
        }

        return home_url('/');
    }

    protected function normalize_referral_landing_url($raw_url, $fallback_url = null)
    {
        $fallback = $this->sanitize_referral_landing_candidate($fallback_url);
        if ('' === $fallback) {
            $fallback = home_url('/');
        }

        $candidate = $this->sanitize_referral_landing_candidate($raw_url);
        return '' !== $candidate ? $candidate : $fallback;
    }

    protected function sanitize_referral_landing_candidate($raw_url)
    {
        $raw_url = is_string($raw_url) ? trim($raw_url) : '';
        if ('' === $raw_url) {
            return '';
        }

        if (preg_match('#^https?://#i', $raw_url)) {
            $candidate = esc_url_raw($raw_url);
        } else {
            if (0 === strpos($raw_url, '//')) {
                return '';
            }

            $candidate = esc_url_raw(home_url('/' . ltrim($raw_url, '/')));
        }

        if (! $candidate) {
            return '';
        }

        $candidate = $this->strip_url_fragment($candidate);

        if (! $this->is_same_site_url($candidate) || $this->is_unsafe_referral_landing_url($candidate)) {
            return '';
        }

        return $candidate;
    }

    protected function strip_url_fragment($url)
    {
        $url = is_string($url) ? $url : '';
        if (false === strpos($url, '#')) {
            return $url;
        }

        list($base) = explode('#', $url, 2);
        return $base;
    }

    protected function is_same_site_url($url)
    {
        $home_host      = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
        $candidate_host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));

        return '' !== $home_host && '' !== $candidate_host && $home_host === $candidate_host;
    }

    protected function is_unsafe_referral_landing_url($url)
    {
        $path = (string) wp_parse_url($url, PHP_URL_PATH);
        $path = '' !== $path ? $path : '/';
        $path = '/' . ltrim($path, '/');
        $path_for_match = untrailingslashit($path);

        $blocked_paths = [
            (string) wp_parse_url(admin_url('/'), PHP_URL_PATH),
            (string) wp_parse_url(network_admin_url('/'), PHP_URL_PATH),
            (string) wp_parse_url(wp_login_url(), PHP_URL_PATH),
            (string) wp_parse_url(wp_registration_url(), PHP_URL_PATH),
        ];

        foreach ($blocked_paths as $blocked_path) {
            $blocked_path = $blocked_path ? '/' . ltrim($blocked_path, '/') : '';
            $blocked_path = untrailingslashit($blocked_path);
            if ('' !== $blocked_path && 0 === strpos($path_for_match, $blocked_path)) {
                return true;
            }
        }

        return in_array(basename($path), ['wp-login.php', 'wp-signup.php', 'wp-activate.php'], true);
    }

    protected function urls_share_path($left, $right)
    {
        if (! $this->is_same_site_url($left) || ! $this->is_same_site_url($right)) {
            return false;
        }

        $left_path  = untrailingslashit((string) wp_parse_url($left, PHP_URL_PATH));
        $right_path = untrailingslashit((string) wp_parse_url($right, PHP_URL_PATH));

        return $left_path === $right_path;
    }

    protected function matches_known_public_calendar_url($url)
    {
        $candidates = [];

        if (vms_raf_has_core_function('vms_get_public_event_calendar_url')) {
            $candidates[] = (string) vms_raf_call_core_function('vms_get_public_event_calendar_url');
        }

        if (function_exists('tribe_get_events_link')) {
            $candidates[] = (string) tribe_get_events_link();
        }

        foreach ($candidates as $candidate) {
            $candidate = $this->sanitize_referral_landing_candidate($candidate);
            if ('' !== $candidate && $this->urls_share_path($url, $candidate)) {
                return true;
            }
        }

        return false;
    }

    protected function url_points_to_live_public_destination($url)
    {
        if ($this->urls_share_path($url, home_url('/')) || $this->matches_known_public_calendar_url($url)) {
            return true;
        }

        $post_id = url_to_postid($url);
        if ($post_id > 0 && 'publish' === get_post_status($post_id)) {
            return true;
        }

        $query = [];
        parse_str((string) wp_parse_url($url, PHP_URL_QUERY), $query);
        foreach (['page_id', 'p'] as $query_key) {
            $candidate_id = absint($query[$query_key] ?? 0);
            if ($candidate_id > 0 && 'publish' === get_post_status($candidate_id)) {
                return true;
            }
        }

        $path = trim((string) wp_parse_url($url, PHP_URL_PATH), '/');
        if ('' === $path) {
            return true;
        }

        $public_post_types = array_values((array) get_post_types(['public' => true], 'names'));
        if (empty($public_post_types)) {
            return false;
        }

        $page = get_page_by_path($path, OBJECT, $public_post_types);
        return $page && 'publish' === get_post_status($page);
    }

    protected function get_referral_landing_url_warning($settings = null)
    {
        $landing_url = $this->get_referral_landing_url($settings);
        if ($this->url_points_to_live_public_destination($landing_url)) {
            return '';
        }

        return __('This landing URL does not match a published page or the detected public calendar/events URL. If this is a custom archive or route, manually confirm it loads for visitors before sharing invite links.', 'vms-refer-a-friend');
    }

    protected function format_currency_amount($amount)
    {
        if (function_exists('wc_price')) {
            return trim(wp_strip_all_tags(wc_price((float) $amount)));
        }

        return number_format_i18n((float) $amount, 2);
    }

    protected function format_discount_amount_for_customer($type, $amount)
    {
        if ('percent' === $type) {
            return rtrim(rtrim(number_format_i18n((float) $amount, 2), '0'), '.') . '%';
        }

        return $this->format_currency_amount($amount);
    }

    protected function format_reward_credit_count($count)
    {
        $count = absint($count);

        return sprintf(
            _n('%s credit', '%s credits', $count, 'vms-refer-a-friend'),
            number_format_i18n($count)
        );
    }

    protected function sort_frontend_rewards($rewards, $available)
    {
        $rewards   = is_array($rewards) ? array_values($rewards) : [];
        $available = (int) $available;

        usort($rewards, static function ($left, $right) use ($available) {
            $left_cost      = max(1, (int) ($left->credit_cost ?? 0));
            $right_cost     = max(1, (int) ($right->credit_cost ?? 0));
            $left_claimable = $available >= $left_cost ? 1 : 0;
            $right_claimable = $available >= $right_cost ? 1 : 0;

            if ($left_claimable !== $right_claimable) {
                return $right_claimable <=> $left_claimable;
            }

            $left_missing  = max(0, $left_cost - $available);
            $right_missing = max(0, $right_cost - $available);
            if ($left_missing !== $right_missing) {
                return $left_missing <=> $right_missing;
            }

            $left_sort  = (int) ($left->sort_order ?? 0);
            $right_sort = (int) ($right->sort_order ?? 0);
            if ($left_sort !== $right_sort) {
                return $left_sort <=> $right_sort;
            }

            if ($left_cost !== $right_cost) {
                return $left_cost <=> $right_cost;
            }

            return strcasecmp((string) ($left->name ?? ''), (string) ($right->name ?? ''));
        });

        return $rewards;
    }

    protected function get_credit_term($count, $settings, $lowercase = true)
    {
        $label = trim((string) ($settings['customer_reward_label'] ?? ''));
        if ('' === $label) {
            $label = __('Referral Credits', 'vms-refer-a-friend');
        }

        $term = 1 === absint($count) ? preg_replace('/s$/i', '', $label) : $label;
        $term = trim((string) $term);

        if ('' === $term) {
            $term = 1 === absint($count) ? __('referral credit', 'vms-refer-a-friend') : __('referral credits', 'vms-refer-a-friend');
        }

        return $lowercase ? strtolower($term) : $term;
    }

    protected function format_credit_count_label($count, $settings, $lowercase = true)
    {
        return trim(number_format_i18n(absint($count)) . ' ' . $this->get_credit_term($count, $settings, $lowercase));
    }

    protected function get_referral_offer_headline($settings)
    {
        $credit_copy = $this->format_reward_credit_count((int) $settings['credits_per_referral']);

        if ('yes' === $settings['friend_discount_enabled'] && (float) $settings['friend_discount_amount'] > 0) {
            return sprintf(
                __('Give friends %1$s off tickets. Earn %2$s when they buy.', 'vms-refer-a-friend'),
                $this->format_discount_amount_for_customer($settings['friend_discount_type'], (float) $settings['friend_discount_amount']),
                $credit_copy
            );
        }

        return sprintf(
            __('Invite friends to buy qualifying tickets. Earn %s when they buy.', 'vms-refer-a-friend'),
            $credit_copy
        );
    }

    protected function get_frontend_referral_customer_label($referral)
    {
        $email = ! empty($referral->referred_email) ? sanitize_email((string) $referral->referred_email) : '';
        if ($email) {
            return $this->mask_email_address($email);
        }

        return __('Friend/customer', 'vms-refer-a-friend');
    }

    protected function mask_email_address($email)
    {
        $email = sanitize_email($email);
        if (! $email || false === strpos($email, '@')) {
            return __('Friend/customer', 'vms-refer-a-friend');
        }

        list($local, $domain) = explode('@', $email, 2);
        $domain_parts         = explode('.', $domain);
        $domain_name          = array_shift($domain_parts);
        $domain_suffix        = ! empty($domain_parts) ? '.' . implode('.', $domain_parts) : '';
        $local_mask           = substr($local, 0, 1) . str_repeat('*', max(2, strlen($local) - 1));
        $domain_mask          = substr((string) $domain_name, 0, 1) . str_repeat('*', max(2, strlen((string) $domain_name) - 1));

        return $local_mask . '@' . $domain_mask . $domain_suffix;
    }

    protected function translate_frontend_notice($notice)
    {
        $map = [
            'reward-redeemed'        => __('Reward claim created. Show your claim code to staff when you are ready to redeem it.', 'vms-refer-a-friend'),
            'discount-reward-issued' => __('Your discount reward is ready. Use the code shown in My Claims on your next ticket order.', 'vms-refer-a-friend'),
            'insufficient-credits'   => __('You do not have enough credits for that reward yet.', 'vms-refer-a-friend'),
            'invalid-reward'         => __('That reward is not available.', 'vms-refer-a-friend'),
        ];

        return isset($map[$notice]) ? $map[$notice] : $notice;
    }

    public function render_checkout_referral_field($checkout)
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        if (! function_exists('woocommerce_form_field')) {
            return;
        }

        $current = $this->get_active_referral_code();

        echo '<div class="vms-raf-checkout-box">';
        echo '<h3>' . esc_html__('Have a referral code?', 'vms-refer-a-friend') . '</h3>';
        woocommerce_form_field('vms_raf_referral_code', [
            'type'        => 'text',
            'class'       => ['form-row-wide'],
            'label'       => __('Referral code', 'vms-refer-a-friend'),
            'placeholder' => __('Enter a friend’s referral code', 'vms-refer-a-friend'),
            'required'    => false,
        ], $current);
        echo '<p class="vms-raf-muted">' . esc_html__('Use a friend’s referral code to unlock the current friend discount on qualifying ticket orders.', 'vms-refer-a-friend') . '</p>';
        echo '</div>';
    }

    public function render_registration_referral_field()
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        $current = isset($_COOKIE['vms_raf_code']) ? sanitize_text_field(wp_unslash($_COOKIE['vms_raf_code'])) : '';
        ?>
        <p class="form-row form-row-wide">
            <label for="vms_raf_referral_code_register"><?php esc_html_e('Referral code', 'vms-refer-a-friend'); ?></label>
            <input type="text" class="input-text" name="vms_raf_referral_code_register" id="vms_raf_referral_code_register" value="<?php echo esc_attr($current); ?>" placeholder="<?php echo esc_attr__('Enter a friend’s referral code', 'vms-refer-a-friend'); ?>">
        </p>
        <?php
    }

    public function capture_registration_referral($customer_id)
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        if (empty($_POST['vms_raf_referral_code_register'])) {
            return;
        }

        $code = sanitize_text_field(wp_unslash($_POST['vms_raf_referral_code_register']));
        if (! $this->get_code_row($code)) {
            return;
        }

        update_user_meta($customer_id, '_vms_raf_referred_by_code', $code);
        $this->set_referral_cookie($code);
    }

    public function capture_checkout_referral_code_from_update($posted_data)
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        parse_str((string) $posted_data, $data);
        if (isset($data['vms_raf_referral_code'])) {
            $code = sanitize_text_field((string) $data['vms_raf_referral_code']);
            if ($code && $this->get_code_row($code)) {
                $this->set_referral_cookie($code);
            }
        }
    }

    protected function get_active_referral_code()
    {
        if (! empty($_POST['vms_raf_referral_code'])) {
            $code = sanitize_text_field(wp_unslash($_POST['vms_raf_referral_code']));
            if ($code) {
                return $code;
            }
        }

        if (function_exists('WC') && WC()->session) {
            $session_code = WC()->session->get('vms_raf_code');
            if ($session_code) {
                return sanitize_text_field((string) $session_code);
            }
        }

        if (! empty($_COOKIE['vms_raf_code'])) {
            return sanitize_text_field(wp_unslash($_COOKIE['vms_raf_code']));
        }

        if (is_user_logged_in()) {
            $user_code = get_user_meta(get_current_user_id(), '_vms_raf_referred_by_code', true);
            if ($user_code) {
                return sanitize_text_field((string) $user_code);
            }
        }

        return '';
    }

    protected function get_active_referral_row()
    {
        $code = $this->get_active_referral_code();
        if (! $code) {
            return null;
        }

        return $this->get_code_row($code);
    }

    public function validate_checkout_referral($data, $errors)
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        $code = '';
        if (! empty($data['vms_raf_referral_code'])) {
            $code = sanitize_text_field((string) $data['vms_raf_referral_code']);
        } else {
            $code = $this->get_active_referral_code();
        }

        if (! $code) {
            return;
        }

        $row = $this->get_code_row($code);
        if (! $row) {
            $errors->add('vms_raf_invalid_code', __('That referral code is not valid.', 'vms-refer-a-friend'));
            return;
        }

        $referred_user_id = get_current_user_id();
        $referred_email   = sanitize_email((string) ($data['billing_email'] ?? ''));
        $validation       = $this->validate_referral_identity((int) $row->user_id, $referred_user_id, $referred_email);

        if (! $validation['valid']) {
            $errors->add('vms_raf_invalid_identity', $validation['message']);
        }
    }

    protected function validate_referral_identity($referrer_user_id, $referred_user_id, $referred_email)
    {
        $settings = $this->get_settings();
        $referrer = get_user_by('id', (int) $referrer_user_id);

        if (! $referrer) {
            return [
                'valid'   => false,
                'message' => __('That referral is no longer available.', 'vms-refer-a-friend'),
            ];
        }

        if (($referred_user_id && (int) $referred_user_id === (int) $referrer_user_id) || ($referred_email && strtolower($referred_email) === strtolower((string) $referrer->user_email))) {
            return [
                'valid'   => false,
                'message' => __('You cannot use your own referral code.', 'vms-refer-a-friend'),
            ];
        }

        if ('yes' === $settings['first_purchase_only'] && $this->has_existing_qualified_referral_identity_any($referred_user_id, $referred_email)) {
            return [
                'valid'   => false,
                'message' => __('This referral offer has already been used for this customer.', 'vms-refer-a-friend'),
            ];
        }

        return [
            'valid'   => true,
            'message' => '',
        ];
    }

    public function maybe_apply_friend_discount($cart)
    {
        if (is_admin() && ! wp_doing_ajax()) {
            return;
        }

        if (! $cart || ! is_a($cart, 'WC_Cart')) {
            return;
        }

        $settings = $this->get_settings();
        if ('yes' !== $settings['enabled'] || 'yes' !== $settings['friend_discount_enabled']) {
            return;
        }

        $row = $this->get_active_referral_row();
        if (! $row) {
            return;
        }

        if (is_user_logged_in() && (int) $row->user_id === (int) get_current_user_id()) {
            return;
        }

        $qualifying_total = $this->get_cart_qualifying_subtotal($cart);
        if ($qualifying_total <= 0 || $qualifying_total < (float) $settings['minimum_order_amount']) {
            return;
        }

        $discount = $this->calculate_friend_discount_amount($qualifying_total);
        if ($discount <= 0) {
            return;
        }

        $label = ! empty($settings['friend_discount_label']) ? $settings['friend_discount_label'] : __('Friend referral savings', 'vms-refer-a-friend');
        $cart->add_fee($label, 0 - $discount, false);
    }

    protected function calculate_friend_discount_amount($qualifying_total)
    {
        $settings = $this->get_settings();
        $type     = $settings['friend_discount_type'];
        $amount   = (float) $settings['friend_discount_amount'];

        if ($amount <= 0 || $qualifying_total <= 0) {
            return 0.0;
        }

        if ('percent' === $type) {
            $discount = ($qualifying_total * $amount) / 100;
        } else {
            $discount = min($amount, $qualifying_total);
        }

        return round(max(0, $discount), 2);
    }

    protected function get_cart_qualifying_subtotal($cart)
    {
        $settings      = $this->get_settings();
        $eligible_cats = array_map('intval', (array) $settings['eligible_categories']);
        $require_event = 'yes' === $settings['require_event_context'];
        $exclude_free  = 'yes' === $settings['exclude_free'];
        $total         = 0.0;

        foreach ($cart->get_cart() as $cart_item) {
            $product_id = ! empty($cart_item['product_id']) ? (int) $cart_item['product_id'] : 0;
            if (! $product_id) {
                continue;
            }

            $line_total = isset($cart_item['line_total']) ? (float) $cart_item['line_total'] : ((float) $cart_item['data']->get_price() * (int) ($cart_item['quantity'] ?? 1));
            if ($exclude_free && $line_total <= 0) {
                continue;
            }

            $terms = wp_get_post_terms($product_id, 'product_cat', ['fields' => 'ids']);
            $terms = is_wp_error($terms) ? [] : array_map('intval', $terms);
            if (! empty($eligible_cats) && empty(array_intersect($eligible_cats, $terms))) {
                continue;
            }

            $maybe_event = $this->detect_event_post_id($product_id);
            if ($require_event && ! $maybe_event) {
                continue;
            }

            $total += $line_total;
        }

        return round($total, 2);
    }

    public function attach_referral_code_to_order($order, $data)
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        if (! is_a($order, 'WC_Order')) {
            return;
        }

        $code = $this->get_active_referral_code();

        if (! $code) {
            return;
        }

        $row = $this->get_code_row($code);
        if (! $row) {
            return;
        }

        $order->update_meta_data('_vms_raf_code', $code);
        $order->update_meta_data('_vms_raf_referrer_user_id', (int) $row->user_id);

        if ('yes' === $this->get_settings()['friend_discount_enabled']) {
            $friend_discount = $this->calculate_friend_discount_amount($this->get_qualifying_order_context($order)['qualifying_total']);
            if ($friend_discount > 0) {
                $order->update_meta_data('_vms_raf_friend_discount_total', $friend_discount);
            }
        }

        $this->set_referral_cookie($code);
    }

    public function ensure_pending_referral($order_id)
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        $order = wc_get_order($order_id);
        if (! $order) {
            return;
        }

        $code = (string) $order->get_meta('_vms_raf_code');
        if (! $code) {
            return;
        }

        $existing = $this->get_referral_by_order_id($order_id);
        if ($existing) {
            return;
        }

        $code_row = $this->get_code_row($code);
        if (! $code_row) {
            return;
        }

        $qualifying = $this->get_qualifying_order_context($order);
        $now        = current_time('mysql');

        global $wpdb;
        $wpdb->insert(
            $this->table('referrals'),
            [
                'referrer_user_id' => (int) $code_row->user_id,
                'referred_user_id' => $order->get_customer_id() ? (int) $order->get_customer_id() : null,
                'referred_email'   => sanitize_email((string) $order->get_billing_email()),
                'referral_code_id' => (int) $code_row->id,
                'referral_code'    => $code,
                'order_id'         => (int) $order_id,
                'event_post_id'    => $qualifying['event_post_id'] ?: null,
                'qualifying_total' => $qualifying['qualifying_total'],
                'status'           => 'pending',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            ['%d', '%d', '%s', '%d', '%s', '%d', '%d', '%f', '%s', '%s', '%s']
        );
    }

    public function render_thankyou_notice($order_id)
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        $order = wc_get_order($order_id);
        if (! $order) {
            return;
        }

        $code = (string) $order->get_meta('_vms_raf_code');
        if (! $code) {
            return;
        }

        $message = __('Referral noted.', 'vms-refer-a-friend');
        if ('yes' === $this->get_settings()['friend_discount_enabled']) {
            $message = __('Referral noted. Your friend discount has been applied if this order qualifies, and the friend who referred you can earn credits once the order is paid.', 'vms-refer-a-friend');
        } else {
            $message = __('Referral noted. If this order qualifies, the friend who referred you will earn referral credits automatically.', 'vms-refer-a-friend');
        }

        echo '<div class="woocommerce-message">' . esc_html($message) . '</div>';
    }

    public function maybe_process_order_status_change($order_id, $from_status, $to_status, $order)
    {
        $settings = $this->get_settings();
        if ('yes' !== $settings['enabled']) {
            return;
        }
        $to       = sanitize_key($to_status);

        if (in_array($to, (array) $settings['qualifying_statuses'], true)) {
            $this->qualify_referral_for_order($order_id);
            return;
        }

        if (in_array($to, (array) $settings['reverse_statuses'], true)) {
            $this->reverse_referral_for_order($order_id, $to);
        }
    }

    protected function qualify_referral_for_order($order_id)
    {
        $order = wc_get_order($order_id);
        if (! $order) {
            return;
        }

        $settings = $this->get_settings();
        $referral = $this->get_referral_by_order_id($order_id);
        $code     = (string) $order->get_meta('_vms_raf_code');

        if (! $referral && $code) {
            $this->ensure_pending_referral($order_id);
            $referral = $this->get_referral_by_order_id($order_id);
        }

        if (! $referral) {
            return;
        }

        $code_row = $this->get_code_row($referral->referral_code);
        if (! $code_row) {
            $this->update_referral_status($referral->id, 'blocked', ['reversal_reason' => 'Invalid referral code']);
            return;
        }

        $referrer_id   = (int) $code_row->user_id;
        $referred_user = (int) $order->get_customer_id();
        $referred_mail = sanitize_email((string) $order->get_billing_email());
        $referrer      = get_user_by('id', $referrer_id);

        if (! $referrer) {
            $this->update_referral_status($referral->id, 'blocked', ['reversal_reason' => 'Referrer account missing']);
            return;
        }

        if (($referred_user && $referred_user === $referrer_id) || (strtolower($referred_mail) === strtolower((string) $referrer->user_email))) {
            $this->update_referral_status($referral->id, 'blocked', ['reversal_reason' => 'Self-referral blocked']);
            return;
        }

        if ('yes' === $settings['first_purchase_only'] && $this->has_existing_qualified_referral_for_referred_identity($referral->id, $referred_user, $referred_mail)) {
            $this->update_referral_status($referral->id, 'blocked', ['reversal_reason' => 'Referred customer already qualified previously']);
            return;
        }

        $qualifying = $this->get_qualifying_order_context($order);
        if (! $qualifying['is_qualifying']) {
            $this->update_referral_status($referral->id, 'blocked', ['reversal_reason' => $qualifying['reason']]);
            return;
        }

        if ((float) $qualifying['qualifying_total'] < (float) $settings['minimum_order_amount']) {
            $this->update_referral_status($referral->id, 'blocked', ['reversal_reason' => 'Order total below qualifying minimum']);
            return;
        }

        global $wpdb;

        $wpdb->update(
            $this->table('referrals'),
            [
                'referrer_user_id' => $referrer_id,
                'referred_user_id' => $referred_user ?: null,
                'referred_email'   => $referred_mail,
                'event_post_id'    => $qualifying['event_post_id'] ?: null,
                'qualifying_total' => $qualifying['qualifying_total'],
                'status'           => 'rewarded',
                'qualified_at'     => current_time('mysql'),
                'updated_at'       => current_time('mysql'),
                'reversal_reason'  => null,
            ],
            ['id' => (int) $referral->id],
            ['%d', '%d', '%s', '%d', '%f', '%s', '%s', '%s', '%s'],
            ['%d']
        );

        if (! $this->has_ledger_entry_for_referral((int) $referral->id, 'earn')) {
            $this->add_ledger_entry($referrer_id, (int) $referral->id, (int) $settings['credits_per_referral'], 'earn', sprintf('Order #%d qualified for referral credits.', (int) $order_id));
        }
    }

    protected function reverse_referral_for_order($order_id, $reason)
    {
        $referral = $this->get_referral_by_order_id($order_id);
        if (! $referral) {
            return;
        }

        if ('reversed' === $referral->status) {
            return;
        }

        if (! $this->has_ledger_entry_for_referral((int) $referral->id, 'reverse') && $this->has_ledger_entry_for_referral((int) $referral->id, 'earn')) {
            $earned = $this->get_total_earned_for_referral((int) $referral->id);
            if ($earned > 0) {
                $this->add_ledger_entry((int) $referral->referrer_user_id, (int) $referral->id, 0 - $earned, 'reverse', sprintf('Referral reversed because order status changed to %s.', sanitize_text_field($reason)));
            }
        }

        $this->update_referral_status((int) $referral->id, 'reversed', [
            'reversed_at'      => current_time('mysql'),
            'reversal_reason'  => sanitize_text_field($reason),
        ]);
    }

    protected function get_qualifying_order_context($order)
    {
        $settings          = $this->get_settings();
        $eligible_cats     = array_map('intval', (array) $settings['eligible_categories']);
        $require_event     = 'yes' === $settings['require_event_context'];
        $exclude_free      = 'yes' === $settings['exclude_free'];
        $qualifying_total  = 0.0;
        $event_post_id     = 0;
        $qualifying_items  = 0;

        foreach ($order->get_items('line_item') as $item) {
            $product_id = $item->get_product_id();
            if (! $product_id) {
                continue;
            }

            $line_total = (float) $item->get_total();
            if ($exclude_free && $line_total <= 0) {
                continue;
            }

            $terms = wp_get_post_terms($product_id, 'product_cat', ['fields' => 'ids']);
            $terms = is_wp_error($terms) ? [] : array_map('intval', $terms);
            if (! empty($eligible_cats) && empty(array_intersect($eligible_cats, $terms))) {
                continue;
            }

            $maybe_event = $this->detect_event_post_id($product_id, $item);
            if ($require_event && ! $maybe_event) {
                continue;
            }

            if ($maybe_event && ! $event_post_id) {
                $event_post_id = $maybe_event;
            }

            $qualifying_total += $line_total;
            $qualifying_items++;
        }

        if ($qualifying_items < 1) {
            return [
                'is_qualifying'    => false,
                'qualifying_total' => 0,
                'event_post_id'    => 0,
                'reason'           => 'No qualifying paid ticket items found',
            ];
        }

        return [
            'is_qualifying'    => true,
            'qualifying_total' => round($qualifying_total, 2),
            'event_post_id'    => (int) $event_post_id,
            'reason'           => '',
        ];
    }

    protected function detect_event_post_id($product_id, $item = null)
    {
        $keys = [
            '_tribe_wooticket_for_event',
            '_tribe_rsvp_for_event',
            '_event_id',
            'event_id',
        ];

        foreach ($keys as $key) {
            $value = (int) get_post_meta($product_id, $key, true);
            if ($value > 0) {
                return $value;
            }
        }

        if ($item && method_exists($item, 'get_meta')) {
            foreach ($keys as $key) {
                $value = (int) $item->get_meta($key, true);
                if ($value > 0) {
                    return $value;
                }
            }
        }

        return 0;
    }

    protected function has_existing_qualified_referral_identity_any($referred_user_id, $referred_email)
    {
        global $wpdb;

        if ($referred_user_id) {
            $count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table('referrals')} WHERE referred_user_id = %d AND status IN ('rewarded','qualified')",
                (int) $referred_user_id
            ));
            if ($count > 0) {
                return true;
            }
        }

        if ($referred_email) {
            $count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table('referrals')} WHERE referred_email = %s AND status IN ('rewarded','qualified')",
                sanitize_email($referred_email)
            ));
            if ($count > 0) {
                return true;
            }
        }

        return false;
    }

    public function capture_referral_from_request()
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        if (is_admin()) {
            return;
        }

        if (empty($_GET['vms_ref'])) {
            return;
        }

        $code = sanitize_text_field(wp_unslash($_GET['vms_ref']));
        if (! $this->get_code_row($code)) {
            return;
        }

        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            $self    = $this->get_or_create_user_code($user_id);
            if ($self === $code) {
                return;
            }
        }

        $this->set_referral_cookie($code);
    }

    protected function set_referral_cookie($code)
    {
        $settings = $this->get_settings();
        $expires  = time() + (DAY_IN_SECONDS * absint($settings['cookie_days']));

        if (function_exists('WC') && WC()->session) {
            WC()->session->set('vms_raf_code', $code);
        }

        $cookie_set = setcookie('vms_raf_code', $code, $expires, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true);
        if ($cookie_set) {
            $_COOKIE['vms_raf_code'] = $code;
        }
    }

    public function handle_frontend_actions()
    {
        if ('yes' !== $this->get_settings()['enabled']) {
            return;
        }

        if (! is_user_logged_in() || empty($_POST['vms_raf_action'])) {
            return;
        }

        $action = sanitize_key(wp_unslash($_POST['vms_raf_action']));

        if ('redeem_reward' !== $action) {
            return;
        }

        if (empty($_POST['vms_raf_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vms_raf_nonce'])), 'vms_raf_redeem_reward')) {
            return;
        }

        $reward_id = isset($_POST['reward_id']) ? absint($_POST['reward_id']) : 0;
        $notice    = $this->redeem_reward_for_user(get_current_user_id(), $reward_id);

        wp_safe_redirect(add_query_arg('vms_raf_notice', $notice, wc_get_account_endpoint_url('refer-a-friend')));
        exit;
    }

    protected function redeem_reward_for_user($user_id, $reward_id)
    {
        $reward = $this->get_reward($reward_id);
        if (! $reward || ! (int) $reward->is_active) {
            return 'invalid-reward';
        }

        $available = $this->get_available_credits($user_id);
        if ($available < (int) $reward->credit_cost) {
            return 'insufficient-credits';
        }

        if ('discount_coupon' === ($reward->reward_type ?? 'physical_claim')) {
            $issued = $this->issue_discount_reward_for_user($user_id, $reward);
            if (! $issued) {
                return 'invalid-reward';
            }

            $this->add_ledger_entry($user_id, null, 0 - (int) $reward->credit_cost, 'redeem_adjustment', sprintf('Redeemed discount reward: %s (%s)', $reward->name, $issued['coupon_code']));
            return 'discount-reward-issued';
        }

        global $wpdb;
        $now        = current_time('mysql');
        $claim_code = $this->generate_claim_code();

        $wpdb->insert(
            $this->table('claims'),
            [
                'user_id'       => $user_id,
                'reward_id'     => (int) $reward->id,
                'credits_spent' => (int) $reward->credit_cost,
                'status'        => 'pending',
                'claim_code'    => $claim_code,
                'notes'         => sanitize_text_field((string) ($reward->fulfillment_notes ?? '')),
                'created_at'    => $now,
                'updated_at'    => $now,
            ],
            ['%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s']
        );

        $this->add_ledger_entry($user_id, null, 0 - (int) $reward->credit_cost, 'redeem_adjustment', sprintf('Redeemed reward: %s (%s)', $reward->name, $claim_code));

        return 'reward-redeemed';
    }

    protected function issue_discount_reward_for_user($user_id, $reward)
    {
        if (! function_exists('wc_get_coupon_id_by_code')) {
            return null;
        }

        $user = get_user_by('id', (int) $user_id);
        if (! $user) {
            return null;
        }

        $settings    = $this->get_settings();
        $coupon_code = $this->generate_discount_coupon_code();
        $coupon      = new WC_Coupon();

        $coupon->set_code($coupon_code);
        $coupon->set_discount_type('percent' === ($reward->discount_type ?? 'fixed_cart') ? 'percent' : 'fixed_cart');
        $coupon->set_amount((float) ($reward->discount_amount ?? 0));
        $coupon->set_description(sprintf('Referral reward coupon: %s', $reward->name));
        $coupon->set_individual_use(true);
        $coupon->set_usage_limit(1);
        $coupon->set_usage_limit_per_user(1);
        $coupon->set_email_restrictions([$user->user_email]);

        if (! empty($settings['eligible_categories'])) {
            $coupon->set_product_categories(array_map('intval', (array) $settings['eligible_categories']));
        }

        $expiry_days = absint($reward->coupon_expiry_days ?? 0);
        if ($expiry_days > 0) {
            $expires = new WC_DateTime();
            $expires->setTimestamp(time() + ($expiry_days * DAY_IN_SECONDS));
            $coupon->set_date_expires($expires);
        }

        $coupon_id = $coupon->save();

        if (! $coupon_id) {
            return null;
        }

        global $wpdb;
        $now   = current_time('mysql');
        $notes = __('Use this code on your next qualifying ticket order.', 'vms-refer-a-friend');
        if ($expiry_days > 0) {
            $notes .= ' ' . sprintf(__('Expires in %d days.', 'vms-refer-a-friend'), $expiry_days);
        }

        $wpdb->insert(
            $this->table('claims'),
            [
                'user_id'       => (int) $user_id,
                'reward_id'     => (int) $reward->id,
                'credits_spent' => (int) $reward->credit_cost,
                'status'        => 'issued',
                'claim_code'    => $coupon_code,
                'notes'         => $notes,
                'created_at'    => $now,
                'updated_at'    => $now,
            ],
            ['%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s']
        );

        return [
            'coupon_id'   => $coupon_id,
            'coupon_code' => $coupon_code,
        ];
    }

    /**
     * Register RAF admin screens with the VMS admin registry when VMS core is active.
     *
     * This is the plug-and-play contract: RAF declares its VMS section once and
     * VMS owns the left launcher, top navigation, All VMS Pages directory, and
     * direct URL routing from there. The standalone menu below remains only as a
     * fallback for sites that run the add-on without a registry-capable VMS core.
     */
    public function register_vms_admin_pages()
    {
        if (! vms_raf_has_core_function('vms_register_admin_page')) {
            return;
        }

        foreach ($this->get_admin_page_definitions() as $page) {
            vms_raf_call_core_function('vms_register_admin_page', [
                'id'          => $page['slug'],
                'slug'        => $page['slug'],
                'page_title'  => $page['page_title'],
                'menu_title'  => $page['menu_title'],
                'capability'  => 'manage_woocommerce',
                'callback'    => $page['callback'],
                'section'     => 'marketing_sales',
                'order'       => $page['order'],
                'source'      => 'vms-refer-a-friend',
                'description' => $page['description'],
                'left_menu'   => false,
                'top_nav'     => ! empty($page['top_nav']),
                'directory'   => true,
                'shell'       => false,
                'register'    => true,
            ]);
        }
    }

    protected function get_admin_page_definitions()
    {
        return [
            [
                'slug'        => 'vms-raf',
                'page_title'  => __('VMS Refer-a-Friend', 'vms-refer-a-friend'),
                'menu_title'  => __('Refer-a-Friend', 'vms-refer-a-friend'),
                'tab_label'   => __('Dashboard', 'vms-refer-a-friend'),
                'callback'    => [$this, 'render_admin_dashboard'],
                'order'       => 40,
                'top_nav'     => true,
                'description' => __('Ticket-only referral dashboard for customer referral credits, friend discounts, and reward activity.', 'vms-refer-a-friend'),
            ],
            [
                'slug'        => 'vms-raf-rewards',
                'page_title'  => __('Refer-a-Friend Rewards', 'vms-refer-a-friend'),
                'menu_title'  => __('Rewards', 'vms-refer-a-friend'),
                'tab_label'   => __('Rewards', 'vms-refer-a-friend'),
                'callback'    => [$this, 'render_admin_rewards'],
                'order'       => 41,
                'top_nav'     => false,
                'description' => __('Configure referral-credit rewards, claim rewards, and future ticket-discount reward coupons.', 'vms-refer-a-friend'),
            ],
            [
                'slug'        => 'vms-raf-claims',
                'page_title'  => __('Refer-a-Friend Claims', 'vms-refer-a-friend'),
                'menu_title'  => __('Claims', 'vms-refer-a-friend'),
                'tab_label'   => __('Claims', 'vms-refer-a-friend'),
                'callback'    => [$this, 'render_admin_claims'],
                'order'       => 42,
                'top_nav'     => false,
                'description' => __('Review and fulfill customer reward claims created from referral credits.', 'vms-refer-a-friend'),
            ],
            [
                'slug'        => 'vms-raf-referrals',
                'page_title'  => __('Refer-a-Friend Referral Log', 'vms-refer-a-friend'),
                'menu_title'  => __('Referral Log', 'vms-refer-a-friend'),
                'tab_label'   => __('Referral Log', 'vms-refer-a-friend'),
                'callback'    => [$this, 'render_admin_referrals'],
                'order'       => 43,
                'top_nav'     => false,
                'description' => __('Audit referral activity, qualifying orders, earned credits, reversals, and referral status.', 'vms-refer-a-friend'),
            ],
            [
                'slug'        => 'vms-raf-settings',
                'page_title'  => __('Refer-a-Friend Settings', 'vms-refer-a-friend'),
                'menu_title'  => __('Settings', 'vms-refer-a-friend'),
                'tab_label'   => __('Settings', 'vms-refer-a-friend'),
                'callback'    => [$this, 'render_admin_settings'],
                'order'       => 44,
                'top_nav'     => false,
                'description' => __('Control referral eligibility, friend checkout discounts, qualifying statuses, and customer-facing copy.', 'vms-refer-a-friend'),
            ],
            [
                'slug'        => 'vms-raf-help',
                'page_title'  => __('Refer-a-Friend Guided Help', 'vms-refer-a-friend'),
                'menu_title'  => __('Guided Help', 'vms-refer-a-friend'),
                'tab_label'   => __('Guided Help', 'vms-refer-a-friend'),
                'callback'    => [$this, 'render_admin_help'],
                'order'       => 45,
                'top_nav'     => false,
                'description' => __('Plain-English walkthrough of the referral flow from customer sharing through reward redemption.', 'vms-refer-a-friend'),
            ],
        ];
    }

    protected function get_admin_subnav_pages()
    {
        $tabs = [];

        foreach ($this->get_admin_page_definitions() as $page) {
            $tabs[] = [
                'slug'  => $page['slug'],
                'label' => $page['tab_label'] ?? $page['menu_title'],
            ];
        }

        return $tabs;
    }

    protected function get_admin_page_url($slug, $args = [])
    {
        return add_query_arg(array_merge(['page' => $slug], $args), admin_url('admin.php'));
    }

    protected function render_admin_subnav($current_page)
    {
        echo '<nav class="vms-pass-tabs vms-raf-admin-tabs" aria-label="' . esc_attr__('Refer-a-Friend sections', 'vms-refer-a-friend') . '">';
        foreach ($this->get_admin_subnav_pages() as $tab) {
            $class = 'vms-pass-tab vms-raf-admin-tab';
            if ($tab['slug'] === $current_page) {
                $class .= ' is-current';
            }

            echo '<a class="' . esc_attr($class) . '" href="' . esc_url($this->get_admin_page_url($tab['slug'])) . '">' . esc_html($tab['label']) . '</a>';
        }
        echo '</nav>';
    }

    protected function render_admin_shell($current_page, $title, $subtitle, callable $content_callback)
    {
        $body = function () use ($current_page, $content_callback) {
            echo '<div class="vms-raf-admin-wrap">';
            $this->render_admin_subnav($current_page);
            call_user_func($content_callback);
            echo '</div>';
        };

        if (vms_raf_has_core_function('vms_admin_ui_render_shell')) {
            vms_raf_call_core_function('vms_admin_ui_render_shell', [
                'title'    => $title,
                'subtitle' => $subtitle,
                'shell_id' => 'vms-raf-admin-shell',
            ], $body);
            return;
        }

        echo '<div class="wrap">';
        echo '<h1>' . esc_html($title) . '</h1>';
        if ($subtitle !== '') {
            echo '<p class="description">' . esc_html($subtitle) . '</p>';
        }
        $body();
        echo '</div>';
    }

    protected function get_admin_tour_steps_for_page($page)
    {
        switch ($page) {
            case 'vms-raf':
                return [
                    ['selector' => '.vms-raf-admin-summary', 'title' => 'Summary cards', 'text' => 'Use these quick totals to see credits issued, available, pending referrals, and open claims at a glance.'],
                    ['selector' => '.vms-raf-admin-panel-referrals', 'title' => 'Recent referrals', 'text' => 'This panel shows the newest referrals first so you can confirm that orders are qualifying the way you expect.'],
                    ['selector' => '.vms-raf-admin-panel-claims', 'title' => 'Open claims', 'text' => 'Pending reward claims live here until a staff member or admin marks them redeemed.'],
                ];
            case 'vms-raf-rewards':
                return [
                    ['selector' => '.vms-raf-admin-reward-form', 'title' => 'Reward setup', 'text' => 'Create simple venue rewards here. Each reward costs a fixed number of referral credits.'],
                    ['selector' => '.vms-raf-admin-reward-table', 'title' => 'Reward list', 'text' => 'Use this list to confirm which rewards are live, how many credits they cost, and whether they need staff notes.'],
                ];
            case 'vms-raf-claims':
                return [
                    ['selector' => '.vms-raf-admin-claims-table', 'title' => 'Claim fulfillment', 'text' => 'Each row is a customer reward claim. Mark it redeemed when staff hands over the item or perk.'],
                ];
            case 'vms-raf-referrals':
                return [
                    ['selector' => '.vms-raf-admin-referrals-table', 'title' => 'Referral log', 'text' => 'This is the audit trail. It shows who referred whom, which order counted, and whether credits were earned or reversed.'],
                ];
            case 'vms-raf-settings':
                return [
                    ['selector' => '.vms-raf-admin-settings-form', 'title' => 'Referral rules', 'text' => 'Use these settings to decide what counts as a qualifying purchase, which order statuses count, and which products are eligible.'],
                ];
            case 'vms-raf-help':
                return [
                    ['selector' => '.vms-raf-help-grid', 'title' => 'Guided help', 'text' => 'This screen explains the whole workflow from sharing a link to qualifying a referral and redeeming a reward.'],
                ];
        }

        return [];
    }

    public function register_admin_menu()
    {
        if (vms_raf_has_core_function('vms_register_admin_page')) {
            return;
        }

        $parent_slug = $this->detect_vms_parent_slug();
        $menu_parent = 'vms-raf';

        if ($parent_slug && 'vms-raf' !== $parent_slug) {
            $menu_parent    = $parent_slug;
            $dashboard_hook = add_submenu_page($menu_parent, __('Refer-a-Friend', 'vms-refer-a-friend'), __('Refer-a-Friend', 'vms-refer-a-friend'), 'manage_woocommerce', 'vms-raf', [$this, 'render_admin_dashboard']);
        } else {
            $dashboard_hook = add_menu_page(
                __('VMS Refer-a-Friend', 'vms-refer-a-friend'),
                __('VMS Referrals', 'vms-refer-a-friend'),
                'manage_woocommerce',
                'vms-raf',
                [$this, 'render_admin_dashboard'],
                'dashicons-megaphone',
                58
            );
        }

        $rewards_hook  = add_submenu_page($menu_parent, __('Rewards', 'vms-refer-a-friend'), __('Rewards', 'vms-refer-a-friend'), 'manage_woocommerce', 'vms-raf-rewards', [$this, 'render_admin_rewards']);
        $claims_hook   = add_submenu_page($menu_parent, __('Claims', 'vms-refer-a-friend'), __('Claims', 'vms-refer-a-friend'), 'manage_woocommerce', 'vms-raf-claims', [$this, 'render_admin_claims']);
        $ref_hook      = add_submenu_page($menu_parent, __('Referral Log', 'vms-refer-a-friend'), __('Referral Log', 'vms-refer-a-friend'), 'manage_woocommerce', 'vms-raf-referrals', [$this, 'render_admin_referrals']);
        $settings_hook = add_submenu_page($menu_parent, __('Settings', 'vms-refer-a-friend'), __('Settings', 'vms-refer-a-friend'), 'manage_woocommerce', 'vms-raf-settings', [$this, 'render_admin_settings']);
        $help_hook     = add_submenu_page($menu_parent, __('Guided Help', 'vms-refer-a-friend'), __('Guided Help', 'vms-refer-a-friend'), 'manage_woocommerce', 'vms-raf-help', [$this, 'render_admin_help']);

        $this->screen_tours[$dashboard_hook] = [
            ['selector' => '.vms-raf-admin-summary', 'title' => 'Summary cards', 'text' => 'Use these quick totals to see credits issued, available, pending referrals, and open claims at a glance.'],
            ['selector' => '.vms-raf-admin-panel-referrals', 'title' => 'Recent referrals', 'text' => 'This panel shows the newest referrals first so you can confirm that orders are qualifying the way you expect.'],
            ['selector' => '.vms-raf-admin-panel-claims', 'title' => 'Open claims', 'text' => 'Pending reward claims live here until a staff member or admin marks them redeemed.'],
        ];

        $this->screen_tours[$rewards_hook] = [
            ['selector' => '.vms-raf-admin-reward-form', 'title' => 'Reward setup', 'text' => 'Create simple venue rewards here. Each reward costs a fixed number of referral credits.'],
            ['selector' => '.vms-raf-admin-reward-table', 'title' => 'Reward list', 'text' => 'Use this list to confirm which rewards are live, how many credits they cost, and whether they need staff notes.'],
        ];

        $this->screen_tours[$claims_hook] = [
            ['selector' => '.vms-raf-admin-claims-table', 'title' => 'Claim fulfillment', 'text' => 'Each row is a customer reward claim. Mark it redeemed when staff hands over the item or perk.'],
        ];

        $this->screen_tours[$ref_hook] = [
            ['selector' => '.vms-raf-admin-referrals-table', 'title' => 'Referral log', 'text' => 'This is the audit trail. It shows who referred whom, which order counted, and whether credits were earned or reversed.'],
        ];

        $this->screen_tours[$settings_hook] = [
            ['selector' => '.vms-raf-admin-settings-form', 'title' => 'Referral rules', 'text' => 'Use these settings to decide what counts as a qualifying purchase, which order statuses count, and which products are eligible.'],
        ];

        $this->screen_tours[$help_hook] = [
            ['selector' => '.vms-raf-help-grid', 'title' => 'Guided help', 'text' => 'This screen explains the whole workflow from sharing a link to qualifying a referral and redeeming a reward.'],
        ];
    }

    protected function detect_vms_parent_slug()
    {
        global $admin_page_hooks;

        $candidates = [
            'vms-dashboard',
            'vms',
            'vms-settings',
            'vms-main',
            'vms-admin',
            'vms-event-plans',
            'vms-vendors',
            'edit.php?post_type=vms_event_plan',
        ];

        foreach ($candidates as $candidate) {
            if (isset($admin_page_hooks[$candidate])) {
                return $candidate;
            }
        }

        return null;
    }

    public function handle_admin_actions()
    {
        if (! is_admin() || ! current_user_can('manage_woocommerce')) {
            return;
        }

        $action = isset($_REQUEST['vms_raf_admin_action']) ? sanitize_key(wp_unslash($_REQUEST['vms_raf_admin_action'])) : '';
        if (! $action) {
            return;
        }

        switch ($action) {
            case 'save_settings':
                $this->save_settings();
                break;
            case 'save_reward':
                $this->save_reward();
                break;
            case 'delete_reward':
                $this->delete_reward();
                break;
            case 'redeem_claim':
                $this->mark_claim_redeemed();
                break;
        }
    }

    protected function save_settings()
    {
        check_admin_referer('vms_raf_save_settings');

        $posted = isset($_POST['vms_raf']) ? (array) wp_unslash($_POST['vms_raf']) : [];

        $settings = [
            'enabled'                 => ! empty($posted['enabled']) ? 'yes' : 'no',
            'credits_per_referral'    => max(1, absint($posted['credits_per_referral'] ?? 1)),
            'minimum_order_amount'    => max(0, (float) ($posted['minimum_order_amount'] ?? 0)),
            'cookie_days'             => max(1, absint($posted['cookie_days'] ?? 30)),
            'exclude_free'            => ! empty($posted['exclude_free']) ? 'yes' : 'no',
            'require_event_context'   => ! empty($posted['require_event_context']) ? 'yes' : 'no',
            'first_purchase_only'     => ! empty($posted['first_purchase_only']) ? 'yes' : 'no',
            'qualifying_statuses'     => array_values(array_filter(array_map('sanitize_key', (array) ($posted['qualifying_statuses'] ?? [])))),
            'reverse_statuses'        => array_values(array_filter(array_map('sanitize_key', (array) ($posted['reverse_statuses'] ?? [])))),
            'eligible_categories'     => array_values(array_map('absint', (array) ($posted['eligible_categories'] ?? []))),
            'friend_discount_enabled' => ! empty($posted['friend_discount_enabled']) ? 'yes' : 'no',
            'friend_discount_type'    => in_array(($posted['friend_discount_type'] ?? 'fixed_cart'), ['fixed_cart', 'percent'], true) ? $posted['friend_discount_type'] : 'fixed_cart',
            'friend_discount_amount'  => max(0, (float) ($posted['friend_discount_amount'] ?? 5)),
            'friend_discount_label'   => sanitize_text_field($posted['friend_discount_label'] ?? 'Friend referral savings'),
            'referral_landing_url'    => $this->normalize_referral_landing_url($posted['referral_landing_url'] ?? '', $this->get_default_referral_landing_url()),
            'claim_prefix'            => strtoupper(sanitize_text_field($posted['claim_prefix'] ?? 'RAF')),
            'customer_intro'          => sanitize_textarea_field($posted['customer_intro'] ?? ''),
            'customer_reward_label'   => sanitize_text_field($posted['customer_reward_label'] ?? 'Referral Credits'),
            'share_message'           => sanitize_textarea_field($posted['share_message'] ?? ''),
        ];

        update_option('vms_raf_settings', $settings);
        wp_safe_redirect(add_query_arg(['page' => 'vms-raf-settings', 'updated' => '1'], admin_url('admin.php')));
        exit;
    }

    protected function save_reward()
    {
        check_admin_referer('vms_raf_save_reward');

        global $wpdb;

        $reward_id     = isset($_POST['reward_id']) ? absint($_POST['reward_id']) : 0;
        $reward_type   = sanitize_key($_POST['reward_type'] ?? 'physical_claim');
        $reward_type   = in_array($reward_type, ['physical_claim', 'discount_coupon'], true) ? $reward_type : 'physical_claim';
        $discount_type = sanitize_key($_POST['discount_type'] ?? 'fixed_cart');
        $discount_type = in_array($discount_type, ['fixed_cart', 'percent'], true) ? $discount_type : 'fixed_cart';

        $data = [
            'name'               => sanitize_text_field($_POST['name'] ?? ''),
            'description'        => sanitize_textarea_field($_POST['description'] ?? ''),
            'credit_cost'        => max(1, absint($_POST['credit_cost'] ?? 1)),
            'reward_type'        => $reward_type,
            'discount_type'      => $discount_type,
            'discount_amount'    => max(0, (float) ($_POST['discount_amount'] ?? 0)),
            'coupon_expiry_days' => max(0, absint($_POST['coupon_expiry_days'] ?? 30)),
            'is_active'          => ! empty($_POST['is_active']) ? 1 : 0,
            'sort_order'         => absint($_POST['sort_order'] ?? 0),
            'fulfillment_notes'  => sanitize_textarea_field($_POST['fulfillment_notes'] ?? ''),
            'updated_at'         => current_time('mysql'),
        ];

        if ($reward_id > 0) {
            $wpdb->update($this->table('rewards'), $data, ['id' => $reward_id], ['%s', '%s', '%d', '%s', '%s', '%f', '%d', '%d', '%d', '%s', '%s'], ['%d']);
        } else {
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($this->table('rewards'), $data, ['%s', '%s', '%d', '%s', '%s', '%f', '%d', '%d', '%d', '%s', '%s', '%s']);
        }

        wp_safe_redirect(add_query_arg(['page' => 'vms-raf-rewards', 'updated' => '1'], admin_url('admin.php')));
        exit;
    }

    protected function delete_reward()
    {
        $reward_id = isset($_GET['reward_id']) ? absint($_GET['reward_id']) : 0;
        check_admin_referer('vms_raf_delete_reward_' . $reward_id);

        if ($reward_id > 0) {
            global $wpdb;
            $wpdb->delete($this->table('rewards'), ['id' => $reward_id], ['%d']);
        }

        wp_safe_redirect(add_query_arg(['page' => 'vms-raf-rewards', 'deleted' => '1'], admin_url('admin.php')));
        exit;
    }

    protected function mark_claim_redeemed()
    {
        $claim_id = isset($_GET['claim_id']) ? absint($_GET['claim_id']) : 0;
        check_admin_referer('vms_raf_redeem_claim_' . $claim_id);

        if ($claim_id > 0) {
            global $wpdb;
            $wpdb->update(
                $this->table('claims'),
                [
                    'status'              => 'redeemed',
                    'redeemed_by_user_id' => get_current_user_id(),
                    'redeemed_at'         => current_time('mysql'),
                    'updated_at'          => current_time('mysql'),
                ],
                ['id' => $claim_id],
                ['%s', '%d', '%s', '%s'],
                ['%d']
            );
        }

        wp_safe_redirect(add_query_arg(['page' => 'vms-raf-claims', 'updated' => '1'], admin_url('admin.php')));
        exit;
    }

    public function render_admin_dashboard()
    {
        global $wpdb;

        $credits_issued = (int) $wpdb->get_var("SELECT COALESCE(SUM(delta_credits), 0) FROM {$this->table('credits_ledger')} WHERE entry_type = 'earn'");
        $credits_live   = (int) $wpdb->get_var("SELECT COALESCE(SUM(delta_credits), 0) FROM {$this->table('credits_ledger')}");
        $pending_refs   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table('referrals')} WHERE status = 'pending'");
        $open_claims    = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table('claims')} WHERE status = 'pending'");
        $recent_refs    = $this->get_referrals(['limit' => 10]);
        $claims         = $this->get_claims(['status' => 'pending', 'limit' => 10]);

        $this->render_admin_shell(
            'vms-raf',
            __('Refer-a-Friend', 'vms-refer-a-friend'),
            __('Track referral performance, customer rewards, and open claims from one place.', 'vms-refer-a-friend'),
            function () use ($credits_issued, $credits_live, $pending_refs, $open_claims, $recent_refs, $claims) {
                ?>
                <div class="notice notice-info"><p><?php esc_html_e('This add-on is built for ticket referrals only. Friends can receive an immediate ticket discount on qualifying orders, while referrers earn credits they can later spend on prizes or future ticket-discount rewards.', 'vms-refer-a-friend'); ?></p></div>

                <div class="vms-raf-admin-summary">
                    <div class="vms-raf-admin-card"><h3><?php esc_html_e('Credits issued', 'vms-refer-a-friend'); ?></h3><div class="vms-raf-admin-stat"><?php echo esc_html((string) $credits_issued); ?></div></div>
                    <div class="vms-raf-admin-card"><h3><?php esc_html_e('Net live credits', 'vms-refer-a-friend'); ?></h3><div class="vms-raf-admin-stat"><?php echo esc_html((string) $credits_live); ?></div></div>
                    <div class="vms-raf-admin-card"><h3><?php esc_html_e('Pending referrals', 'vms-refer-a-friend'); ?></h3><div class="vms-raf-admin-stat"><?php echo esc_html((string) $pending_refs); ?></div></div>
                    <div class="vms-raf-admin-card"><h3><?php esc_html_e('Open claims', 'vms-refer-a-friend'); ?></h3><div class="vms-raf-admin-stat"><?php echo esc_html((string) $open_claims); ?></div></div>
                </div>

                <div class="vms-raf-admin-two-col">
                    <div class="vms-raf-admin-panel vms-raf-admin-panel-referrals">
                        <h2><?php esc_html_e('Recent referrals', 'vms-refer-a-friend'); ?></h2>
                        <?php $this->render_referrals_table($recent_refs); ?>
                    </div>
                    <div class="vms-raf-admin-panel vms-raf-admin-panel-claims">
                        <h2><?php esc_html_e('Pending claims', 'vms-refer-a-friend'); ?></h2>
                        <?php $this->render_claims_table($claims, false); ?>
                    </div>
                </div>
                <?php
            }
        );
    }

    public function render_admin_rewards()
    {
        $editing = null;
        if (! empty($_GET['edit_reward'])) {
            $editing = $this->get_reward(absint($_GET['edit_reward']));
        }

        $rewards = $this->get_rewards();
        $editing_reward_type = ($editing && 'discount_coupon' === ($editing->reward_type ?? 'physical_claim')) ? 'discount_coupon' : 'physical_claim';
        $settings_page_url   = admin_url('admin.php?page=vms-raf-settings');
        $this->render_admin_shell(
            'vms-raf-rewards',
            __('Refer-a-Friend Rewards', 'vms-refer-a-friend'),
            __('Create and manage the rewards customers can unlock with referral credits.', 'vms-refer-a-friend'),
            function () use ($editing, $rewards, $editing_reward_type, $settings_page_url) {
                ?>
                <div class="vms-raf-admin-two-col vms-raf-admin-reward-form">
                    <div class="vms-raf-admin-panel">
                        <h2><?php echo $editing ? esc_html__('Edit reward', 'vms-refer-a-friend') : esc_html__('Add reward', 'vms-refer-a-friend'); ?></h2>
                        <div class="vms-raf-admin-callout">
                            <p><?php echo wp_kses_post(sprintf(__('The friend checkout discount is controlled in <a href="%s">RAF Settings</a>, not on individual rewards.', 'vms-refer-a-friend'), esc_url($settings_page_url))); ?></p>
                        </div>
                        <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=vms-raf-rewards')); ?>">
                            <?php wp_nonce_field('vms_raf_save_reward'); ?>
                            <input type="hidden" name="vms_raf_admin_action" value="save_reward">
                            <input type="hidden" name="reward_id" value="<?php echo esc_attr($editing ? (string) $editing->id : '0'); ?>">
                            <table class="form-table">
                                <tr><th><label for="name"><?php esc_html_e('Reward name', 'vms-refer-a-friend'); ?></label></th><td><input type="text" name="name" id="name" class="regular-text" value="<?php echo esc_attr($editing->name ?? ''); ?>" required></td></tr>
                                <tr><th><label for="reward_type"><?php esc_html_e('Reward type', 'vms-refer-a-friend'); ?></label></th><td>
                                    <select name="reward_type" id="reward_type" data-vms-raf-reward-type-control>
                                        <option value="physical_claim" <?php selected(($editing->reward_type ?? 'physical_claim'), 'physical_claim'); ?>><?php esc_html_e('Prize / claim', 'vms-refer-a-friend'); ?></option>
                                        <option value="discount_coupon" <?php selected(($editing->reward_type ?? ''), 'discount_coupon'); ?>><?php esc_html_e('Future ticket discount coupon', 'vms-refer-a-friend'); ?></option>
                                    </select>
                                    <p class="description vms-raf-admin-type-help" data-vms-raf-reward-type-help="physical_claim" <?php echo 'physical_claim' === $editing_reward_type ? '' : 'hidden'; ?>><?php esc_html_e('Customers redeem credits for a manual prize or claim handled by staff.', 'vms-refer-a-friend'); ?></p>
                                    <p class="description vms-raf-admin-type-help" data-vms-raf-reward-type-help="discount_coupon" <?php echo 'discount_coupon' === $editing_reward_type ? '' : 'hidden'; ?>><?php esc_html_e('Customers redeem credits for a future ticket discount coupon.', 'vms-refer-a-friend'); ?></p>
                                </td></tr>
                                <tr><th><label for="description"><?php esc_html_e('Description', 'vms-refer-a-friend'); ?></label></th><td><textarea name="description" id="description" rows="3" class="large-text"><?php echo esc_textarea($editing->description ?? ''); ?></textarea></td></tr>
                                <tr><th><label for="credit_cost"><?php esc_html_e('Credit cost', 'vms-refer-a-friend'); ?></label></th><td><input type="number" min="1" name="credit_cost" id="credit_cost" value="<?php echo esc_attr(isset($editing->credit_cost) ? (string) $editing->credit_cost : '1'); ?>"><p class="description"><?php esc_html_e('How many referral credits are required to redeem this reward.', 'vms-refer-a-friend'); ?></p></td></tr>
                                <tr data-vms-raf-coupon-field="1" <?php echo 'discount_coupon' === $editing_reward_type ? '' : 'hidden'; ?>><th><label for="discount_type"><?php esc_html_e('Discount type', 'vms-refer-a-friend'); ?></label></th><td>
                                    <select name="discount_type" id="discount_type">
                                        <option value="fixed_cart" <?php selected(($editing->discount_type ?? 'fixed_cart'), 'fixed_cart'); ?>><?php esc_html_e('Fixed amount', 'vms-refer-a-friend'); ?></option>
                                        <option value="percent" <?php selected(($editing->discount_type ?? ''), 'percent'); ?>><?php esc_html_e('Percent', 'vms-refer-a-friend'); ?></option>
                                    </select>
                                    <p class="description"><?php esc_html_e('Only used when the reward type is a future ticket discount coupon.', 'vms-refer-a-friend'); ?></p>
                                </td></tr>
                                <tr data-vms-raf-coupon-field="1" <?php echo 'discount_coupon' === $editing_reward_type ? '' : 'hidden'; ?>><th><label for="discount_amount"><?php esc_html_e('Discount amount', 'vms-refer-a-friend'); ?></label></th><td><input type="number" min="0" step="0.01" name="discount_amount" id="discount_amount" value="<?php echo esc_attr(isset($editing->discount_amount) ? (string) $editing->discount_amount : '5'); ?>"><p class="description"><?php esc_html_e('For example: 5 = $5 off, or 5 = 5% if Percent is selected.', 'vms-refer-a-friend'); ?></p></td></tr>
                                <tr data-vms-raf-coupon-field="1" <?php echo 'discount_coupon' === $editing_reward_type ? '' : 'hidden'; ?>><th><label for="coupon_expiry_days"><?php esc_html_e('Coupon expiry days', 'vms-refer-a-friend'); ?></label></th><td><input type="number" min="0" name="coupon_expiry_days" id="coupon_expiry_days" value="<?php echo esc_attr(isset($editing->coupon_expiry_days) ? (string) $editing->coupon_expiry_days : '30'); ?>"><p class="description"><?php esc_html_e('Only used for future ticket discount coupon rewards. Use 0 for no expiration.', 'vms-refer-a-friend'); ?></p></td></tr>
                                <tr><th><label for="sort_order"><?php esc_html_e('Sort order', 'vms-refer-a-friend'); ?></label></th><td><input type="number" min="0" name="sort_order" id="sort_order" value="<?php echo esc_attr(isset($editing->sort_order) ? (string) $editing->sort_order : '0'); ?>"></td></tr>
                                <tr><th><label for="fulfillment_notes"><?php esc_html_e('Fulfillment notes', 'vms-refer-a-friend'); ?></label></th><td><textarea name="fulfillment_notes" id="fulfillment_notes" rows="3" class="large-text"><?php echo esc_textarea($editing->fulfillment_notes ?? ''); ?></textarea><p class="description"><?php esc_html_e('For prize rewards, this can tell staff how to fulfill it. For discount rewards, this is optional.', 'vms-refer-a-friend'); ?></p></td></tr>
                                <tr><th><?php esc_html_e('Active', 'vms-refer-a-friend'); ?></th><td><label><input type="checkbox" name="is_active" value="1" <?php checked(! isset($editing->is_active) || (int) $editing->is_active === 1); ?>> <?php esc_html_e('Reward is available to redeem', 'vms-refer-a-friend'); ?></label></td></tr>
                            </table>
                            <p><button type="submit" class="button button-primary"><?php esc_html_e('Save reward', 'vms-refer-a-friend'); ?></button></p>
                        </form>
                    </div>
                    <div class="vms-raf-admin-panel vms-raf-admin-reward-table">
                        <h2><?php esc_html_e('Current rewards', 'vms-refer-a-friend'); ?></h2>
                        <?php if (empty($rewards)) : ?>
                            <p><?php esc_html_e('No rewards created yet.', 'vms-refer-a-friend'); ?></p>
                        <?php else : ?>
                            <table class="widefat striped">
                                <thead><tr><th><?php esc_html_e('Reward', 'vms-refer-a-friend'); ?></th><th><?php esc_html_e('Type', 'vms-refer-a-friend'); ?></th><th><?php esc_html_e('Credits', 'vms-refer-a-friend'); ?></th><th><?php esc_html_e('Status', 'vms-refer-a-friend'); ?></th><th><?php esc_html_e('Actions', 'vms-refer-a-friend'); ?></th></tr></thead>
                                <tbody>
                                    <?php foreach ($rewards as $reward) : ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo esc_html($reward->name); ?></strong>
                                                <?php if (! empty($reward->description)) : ?><div class="vms-raf-muted"><?php echo esc_html($reward->description); ?></div><?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ('discount_coupon' === ($reward->reward_type ?? 'physical_claim')) : ?>
                                                    <?php echo esc_html__('Discount coupon', 'vms-refer-a-friend'); ?>
                                                    <div class="vms-raf-muted">
                                                        <?php echo esc_html(('percent' === ($reward->discount_type ?? 'fixed_cart')) ? rtrim(rtrim(number_format((float) ($reward->discount_amount ?? 0), 2), '0'), '.') . '%' : '$' . number_format((float) ($reward->discount_amount ?? 0), 2)); ?>
                                                    </div>
                                                <?php else : ?>
                                                    <?php esc_html_e('Prize / claim', 'vms-refer-a-friend'); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo esc_html((string) $reward->credit_cost); ?></td>
                                            <td><?php echo (int) $reward->is_active ? esc_html__('Active', 'vms-refer-a-friend') : esc_html__('Inactive', 'vms-refer-a-friend'); ?></td>
                                            <td>
                                                <a class="button button-small" href="<?php echo esc_url(add_query_arg(['page' => 'vms-raf-rewards', 'edit_reward' => (int) $reward->id], admin_url('admin.php'))); ?>"><?php esc_html_e('Edit', 'vms-refer-a-friend'); ?></a>
                                                <a class="button button-small" href="<?php echo esc_url(wp_nonce_url(add_query_arg(['page' => 'vms-raf-rewards', 'vms_raf_admin_action' => 'delete_reward', 'reward_id' => (int) $reward->id], admin_url('admin.php')), 'vms_raf_delete_reward_' . (int) $reward->id)); ?>"><?php esc_html_e('Delete', 'vms-refer-a-friend'); ?></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
                <?php
            }
        );
    }

    public function render_admin_claims()
    {
        $claims = $this->get_claims(['limit' => 100]);
        $this->render_admin_shell(
            'vms-raf-claims',
            __('Reward Claims', 'vms-refer-a-friend'),
            __('Review claim codes and mark pending rewards redeemed when staff fulfills them.', 'vms-refer-a-friend'),
            function () use ($claims) {
                ?>
                <div class="vms-raf-admin-panel vms-raf-admin-claims-table">
                    <?php $this->render_claims_table($claims); ?>
                </div>
                <?php
            }
        );
    }

    public function render_admin_referrals()
    {
        $referrals = $this->get_referrals(['limit' => 200]);
        $this->render_admin_shell(
            'vms-raf-referrals',
            __('Referral Log', 'vms-refer-a-friend'),
            __('Audit qualifying totals, referred customers, reversals, and current referral status.', 'vms-refer-a-friend'),
            function () use ($referrals) {
                ?>
                <div class="vms-raf-admin-panel vms-raf-admin-referrals-table">
                    <?php $this->render_referrals_table($referrals); ?>
                </div>
                <?php
            }
        );
    }

    public function render_admin_settings()
    {
        $settings   = $this->get_settings();
        $statuses   = function_exists('wc_get_order_statuses') ? wc_get_order_statuses() : [];
        $categories = get_terms([
            'taxonomy'   => 'product_cat',
            'hide_empty' => false,
        ]);
        $referral_preview_code   = 'sample-code';
        $resolved_landing_url    = $this->get_referral_landing_url($settings);
        $preview_referral_link   = $this->build_referral_link($referral_preview_code, $settings);
        $landing_url_default     = $this->get_default_referral_landing_url();
        $landing_url_warning     = $this->get_referral_landing_url_warning($settings);
        $this->render_admin_shell(
            'vms-raf-settings',
            __('Refer-a-Friend Settings', 'vms-refer-a-friend'),
            __('Control eligibility rules, friend discounts, landing URLs, and customer-facing copy.', 'vms-refer-a-friend'),
            function () use ($settings, $statuses, $categories, $referral_preview_code, $resolved_landing_url, $preview_referral_link, $landing_url_default, $landing_url_warning) {
                ?>
                <div class="vms-raf-admin-panel vms-raf-admin-settings-form">
                    <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=vms-raf-settings')); ?>">
                        <?php wp_nonce_field('vms_raf_save_settings'); ?>
                        <input type="hidden" name="vms_raf_admin_action" value="save_settings">
                        <table class="form-table">
                        <tr><th><?php esc_html_e('Enable referrals', 'vms-refer-a-friend'); ?></th><td><label><input type="checkbox" name="vms_raf[enabled]" value="1" <?php checked('yes', $settings['enabled']); ?>> <?php esc_html_e('Turn the referral system on', 'vms-refer-a-friend'); ?></label></td></tr>
                        <tr><th><label for="credits_per_referral"><?php esc_html_e('Credits per referral', 'vms-refer-a-friend'); ?></label></th><td><input type="number" min="1" name="vms_raf[credits_per_referral]" id="credits_per_referral" value="<?php echo esc_attr((string) $settings['credits_per_referral']); ?>"></td></tr>
                        <tr><th><label for="minimum_order_amount"><?php esc_html_e('Minimum qualifying amount', 'vms-refer-a-friend'); ?></label></th><td><input type="number" min="0" step="0.01" name="vms_raf[minimum_order_amount]" id="minimum_order_amount" value="<?php echo esc_attr((string) $settings['minimum_order_amount']); ?>"></td></tr>
                        <tr><th><label for="cookie_days"><?php esc_html_e('Referral cookie days', 'vms-refer-a-friend'); ?></label></th><td><input type="number" min="1" name="vms_raf[cookie_days]" id="cookie_days" value="<?php echo esc_attr((string) $settings['cookie_days']); ?>"></td></tr>
                        <tr><th><?php esc_html_e('Friend checkout discount', 'vms-refer-a-friend'); ?></th><td><label><input type="checkbox" name="vms_raf[friend_discount_enabled]" value="1" <?php checked('yes', $settings['friend_discount_enabled']); ?>> <?php esc_html_e('Give the referred friend an immediate discount on qualifying ticket orders', 'vms-refer-a-friend'); ?></label></td></tr>
                        <tr><th><label for="friend_discount_type"><?php esc_html_e('Friend discount type', 'vms-refer-a-friend'); ?></label></th><td>
                            <select name="vms_raf[friend_discount_type]" id="friend_discount_type">
                                <option value="fixed_cart" <?php selected($settings['friend_discount_type'], 'fixed_cart'); ?>><?php esc_html_e('Fixed amount', 'vms-refer-a-friend'); ?></option>
                                <option value="percent" <?php selected($settings['friend_discount_type'], 'percent'); ?>><?php esc_html_e('Percent', 'vms-refer-a-friend'); ?></option>
                            </select>
                        </td></tr>
                        <tr><th><label for="friend_discount_amount"><?php esc_html_e('Friend discount amount', 'vms-refer-a-friend'); ?></label></th><td><input type="number" min="0" step="0.01" name="vms_raf[friend_discount_amount]" id="friend_discount_amount" value="<?php echo esc_attr((string) $settings['friend_discount_amount']); ?>"></td></tr>
                        <tr><th><label for="friend_discount_label"><?php esc_html_e('Friend discount label', 'vms-refer-a-friend'); ?></label></th><td><input type="text" name="vms_raf[friend_discount_label]" id="friend_discount_label" class="regular-text" value="<?php echo esc_attr($settings['friend_discount_label']); ?>"><p class="description"><?php esc_html_e('This is the line-item label shown in cart and checkout when the friend discount is applied.', 'vms-refer-a-friend'); ?></p></td></tr>
                        <tr><th><label for="referral_landing_url"><?php esc_html_e('Referral landing URL', 'vms-refer-a-friend'); ?></label></th><td>
                            <input type="text" name="vms_raf[referral_landing_url]" id="referral_landing_url" class="regular-text code" value="<?php echo esc_attr($settings['referral_landing_url']); ?>">
                            <p class="description"><?php esc_html_e('Choose the page friends should land on after clicking an invite link. Use a live ticket/calendar page, not an admin URL.', 'vms-refer-a-friend'); ?></p>
                            <p class="description"><?php echo esc_html(sprintf(__('If blank or unsafe, RAF falls back to %s.', 'vms-refer-a-friend'), $landing_url_default)); ?></p>
                            <?php if ($landing_url_warning) : ?>
                                <div class="vms-raf-admin-callout vms-raf-admin-callout-warning"><p><?php echo esc_html($landing_url_warning); ?></p></div>
                            <?php endif; ?>
                            <div class="vms-raf-admin-preview">
                                <label for="vms-raf-referral-link-preview"><strong><?php esc_html_e('Invite link preview', 'vms-refer-a-friend'); ?></strong></label>
                                <input type="text" readonly id="vms-raf-referral-link-preview" class="regular-text code" value="<?php echo esc_attr($preview_referral_link); ?>">
                                <p class="description"><?php echo esc_html(sprintf(__('Sample code: %s', 'vms-refer-a-friend'), $referral_preview_code)); ?></p>
                                <p class="description"><?php echo esc_html(sprintf(__('Resolved landing page: %s', 'vms-refer-a-friend'), $resolved_landing_url)); ?></p>
                                <p class="vms-raf-admin-preview-actions"><a class="button button-secondary" href="<?php echo esc_url($preview_referral_link); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Test referral link', 'vms-refer-a-friend'); ?></a></p>
                            </div>
                        </td></tr>
                        <tr><th><?php esc_html_e('Exclude free tickets', 'vms-refer-a-friend'); ?></th><td><label><input type="checkbox" name="vms_raf[exclude_free]" value="1" <?php checked('yes', $settings['exclude_free']); ?>> <?php esc_html_e('Ignore free/zero-dollar ticket items', 'vms-refer-a-friend'); ?></label></td></tr>
                        <tr><th><?php esc_html_e('Require event-linked products', 'vms-refer-a-friend'); ?></th><td><label><input type="checkbox" name="vms_raf[require_event_context]" value="1" <?php checked('yes', $settings['require_event_context']); ?>> <?php esc_html_e('Only count products that are linked to an event ticket context', 'vms-refer-a-friend'); ?></label></td></tr>
                        <tr><th><?php esc_html_e('First purchase only', 'vms-refer-a-friend'); ?></th><td><label><input type="checkbox" name="vms_raf[first_purchase_only]" value="1" <?php checked('yes', $settings['first_purchase_only']); ?>> <?php esc_html_e('Allow a referred customer to qualify only once', 'vms-refer-a-friend'); ?></label></td></tr>
                        <tr><th><?php esc_html_e('Qualifying order statuses', 'vms-refer-a-friend'); ?></th><td>
                            <?php foreach ($statuses as $status_key => $label) : $slug = str_replace('wc-', '', $status_key); ?>
                                <label class="vms-raf-inline-check"><input type="checkbox" name="vms_raf[qualifying_statuses][]" value="<?php echo esc_attr($slug); ?>" <?php checked(in_array($slug, (array) $settings['qualifying_statuses'], true)); ?>> <?php echo esc_html($label); ?></label><br>
                            <?php endforeach; ?>
                        </td></tr>
                        <tr><th><?php esc_html_e('Reverse on statuses', 'vms-refer-a-friend'); ?></th><td>
                            <?php foreach ($statuses as $status_key => $label) : $slug = str_replace('wc-', '', $status_key); ?>
                                <label class="vms-raf-inline-check"><input type="checkbox" name="vms_raf[reverse_statuses][]" value="<?php echo esc_attr($slug); ?>" <?php checked(in_array($slug, (array) $settings['reverse_statuses'], true)); ?>> <?php echo esc_html($label); ?></label><br>
                            <?php endforeach; ?>
                        </td></tr>
                        <tr><th><?php esc_html_e('Eligible ticket categories', 'vms-refer-a-friend'); ?></th><td>
                            <select name="vms_raf[eligible_categories][]" multiple size="8" class="vms-raf-multiselect">
                                <?php if (! is_wp_error($categories)) : ?>
                                    <?php foreach ($categories as $category) : ?>
                                        <option value="<?php echo esc_attr((string) $category->term_id); ?>" <?php selected(in_array((int) $category->term_id, (array) $settings['eligible_categories'], true)); ?>><?php echo esc_html($category->name); ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                            <p class="description"><?php esc_html_e('Leave empty to allow any event-linked paid ticket products. Select categories to lock referrals to specific ticket categories.', 'vms-refer-a-friend'); ?></p>
                        </td></tr>
                        <tr><th><label for="claim_prefix"><?php esc_html_e('Claim code prefix', 'vms-refer-a-friend'); ?></label></th><td><input type="text" name="vms_raf[claim_prefix]" id="claim_prefix" value="<?php echo esc_attr($settings['claim_prefix']); ?>" maxlength="8"></td></tr>
                        <tr><th><label for="customer_reward_label"><?php esc_html_e('Customer reward label', 'vms-refer-a-friend'); ?></label></th><td><input type="text" name="vms_raf[customer_reward_label]" id="customer_reward_label" class="regular-text" value="<?php echo esc_attr($settings['customer_reward_label']); ?>"></td></tr>
                        <tr><th><label for="customer_intro"><?php esc_html_e('Customer intro text', 'vms-refer-a-friend'); ?></label></th><td><textarea name="vms_raf[customer_intro]" id="customer_intro" rows="3" class="large-text"><?php echo esc_textarea($settings['customer_intro']); ?></textarea></td></tr>
                        <tr><th><label for="share_message"><?php esc_html_e('Share message', 'vms-refer-a-friend'); ?></label></th><td><textarea name="vms_raf[share_message]" id="share_message" rows="3" class="large-text"><?php echo esc_textarea($settings['share_message']); ?></textarea></td></tr>
                        </table>
                        <p><button type="submit" class="button button-primary"><?php esc_html_e('Save settings', 'vms-refer-a-friend'); ?></button></p>
                    </form>
                </div>
                <?php
            }
        );
    }

    public function render_admin_help()
    {
        $this->render_admin_shell(
            'vms-raf-help',
            __('Guided Help', 'vms-refer-a-friend'),
            __('Plain-English reference for how customer sharing, qualification, rewards, and claims fit together.', 'vms-refer-a-friend'),
            function () {
                ?>
                <div class="vms-raf-help-grid">
                    <div class="vms-raf-admin-panel">
                        <h2><?php esc_html_e('How it works', 'vms-refer-a-friend'); ?></h2>
                        <ol>
                            <li><?php esc_html_e('A customer gets a referral link and code from My Account.', 'vms-refer-a-friend'); ?></li>
                            <li><?php esc_html_e('Their friend uses the link or enters the code while shopping for event tickets.', 'vms-refer-a-friend'); ?></li>
                            <li><?php esc_html_e('If enabled, the friend sees an immediate checkout discount on qualifying ticket orders.', 'vms-refer-a-friend'); ?></li>
                            <li><?php esc_html_e('When the order reaches one of your qualifying statuses, the referrer earns credits automatically.', 'vms-refer-a-friend'); ?></li>
                            <li><?php esc_html_e('The referrer can redeem credits either for venue prizes or for a future ticket discount coupon.', 'vms-refer-a-friend'); ?></li>
                        </ol>
                    </div>
                    <div class="vms-raf-admin-panel">
                        <h2><?php esc_html_e('What counts', 'vms-refer-a-friend'); ?></h2>
                        <p><?php esc_html_e('This add-on is intentionally ticket-only. It ignores general store products unless you deliberately blur that line by selecting broad product categories.', 'vms-refer-a-friend'); ?></p>
                        <p><?php esc_html_e('For a clean setup, keep your ticket products in dedicated product categories and leave merch outside those categories.', 'vms-refer-a-friend'); ?></p>
                    </div>
                    <div class="vms-raf-admin-panel">
                        <h2><?php esc_html_e('Why claims exist', 'vms-refer-a-friend'); ?></h2>
                        <p><?php esc_html_e('Prize rewards become claims that staff can fulfill on site. Discount rewards create a one-time Woo coupon tied to that customer’s email.', 'vms-refer-a-friend'); ?></p>
                    </div>
                    <div class="vms-raf-admin-panel">
                        <h2><?php esc_html_e('Edge cases', 'vms-refer-a-friend'); ?></h2>
                        <p><?php esc_html_e('If a qualifying order is refunded or canceled, the earned credits are reversed automatically. If a user already spent those credits, the ledger can go negative so the math stays honest.', 'vms-refer-a-friend'); ?></p>
                    </div>
                </div>
                <?php
            }
        );
    }

    protected function render_referrals_table($referrals)
    {
        if (empty($referrals)) {
            echo '<p>' . esc_html__('No referrals found yet.', 'vms-refer-a-friend') . '</p>';
            return;
        }
        ?>
        <table class="widefat striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Referrer', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Friend', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Order', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Event', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Total', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Status', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Updated', 'vms-refer-a-friend'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($referrals as $referral) :
                    $referrer = get_user_by('id', (int) $referral->referrer_user_id);
                    $event    = $referral->event_post_id ? get_the_title((int) $referral->event_post_id) : '—';
                    ?>
                    <tr>
                        <td><?php echo esc_html($referrer ? $referrer->display_name : ('#' . (int) $referral->referrer_user_id)); ?></td>
                        <td><?php echo esc_html($referral->referred_email ?: __('Customer account', 'vms-refer-a-friend')); ?></td>
                        <td><?php echo esc_html('#' . (int) $referral->order_id); ?></td>
                        <td><?php echo esc_html($event); ?></td>
                        <td><?php echo esc_html(function_exists('wc_price') ? wp_strip_all_tags(wc_price((float) $referral->qualifying_total)) : number_format_i18n((float) $referral->qualifying_total, 2)); ?></td>
                        <td><span class="vms-raf-pill vms-raf-pill-status"><?php echo esc_html(ucfirst($referral->status)); ?></span></td>
                        <td><?php echo esc_html($referral->updated_at); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    protected function render_claims_table($claims, $show_actions = true)
    {
        if (empty($claims)) {
            echo '<p>' . esc_html__('No claims found.', 'vms-refer-a-friend') . '</p>';
            return;
        }
        ?>
        <table class="widefat striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Customer', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Reward', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Code', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Credits', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Status', 'vms-refer-a-friend'); ?></th>
                    <th><?php esc_html_e('Details', 'vms-refer-a-friend'); ?></th>
                    <?php if ($show_actions) : ?><th><?php esc_html_e('Actions', 'vms-refer-a-friend'); ?></th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($claims as $claim) :
                    $user = get_user_by('id', (int) $claim->user_id);
                    ?>
                    <tr>
                        <td><?php echo esc_html($user ? $user->display_name : ('#' . (int) $claim->user_id)); ?></td>
                        <td><?php echo esc_html($claim->reward_name); ?></td>
                        <td><?php echo esc_html($claim->claim_code); ?></td>
                        <td><?php echo esc_html((string) $claim->credits_spent); ?></td>
                        <td><span class="vms-raf-pill vms-raf-pill-status"><?php echo esc_html(ucfirst($claim->status)); ?></span></td>
                        <td><?php echo ! empty($claim->notes) ? esc_html($claim->notes) : '—'; ?></td>
                        <?php if ($show_actions) : ?>
                            <td>
                                <?php if ('pending' === $claim->status) : ?>
                                    <a class="button button-small" href="<?php echo esc_url(wp_nonce_url(add_query_arg(['page' => 'vms-raf-claims', 'vms_raf_admin_action' => 'redeem_claim', 'claim_id' => (int) $claim->id], admin_url('admin.php')), 'vms_raf_redeem_claim_' . (int) $claim->id)); ?>"><?php esc_html_e('Mark redeemed', 'vms-refer-a-friend'); ?></a>
                                <?php else : ?>
                                    <span class="vms-raf-muted"><?php esc_html_e('No action needed', 'vms-refer-a-friend'); ?></span>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    protected function get_settings()
    {
        $settings = wp_parse_args((array) get_option('vms_raf_settings', []), [
            'enabled'                 => 'yes',
            'credits_per_referral'    => 1,
            'minimum_order_amount'    => 20,
            'cookie_days'             => 30,
            'exclude_free'            => 'yes',
            'require_event_context'   => 'yes',
            'first_purchase_only'     => 'yes',
            'qualifying_statuses'     => ['processing', 'completed'],
            'reverse_statuses'        => ['refunded', 'cancelled'],
            'eligible_categories'     => [],
            'friend_discount_enabled' => 'yes',
            'friend_discount_type'    => 'fixed_cart',
            'friend_discount_amount'  => 5,
            'friend_discount_label'   => 'Friend referral savings',
            'referral_landing_url'    => $this->get_default_referral_landing_url(),
            'claim_prefix'            => 'RAF',
            'customer_intro'          => '',
            'customer_reward_label'   => 'Referral Credits',
            'share_message'           => '',
        ]);

        $settings['referral_landing_url'] = $this->normalize_referral_landing_url($settings['referral_landing_url'] ?? '', $this->get_default_referral_landing_url());

        return $settings;
    }

    protected function table($name)
    {
        global $wpdb;
        return $wpdb->prefix . 'vms_raf_' . $name;
    }

    protected function get_or_create_user_code($user_id)
    {
        $existing = $this->get_code_for_user($user_id);
        if ($existing) {
            return $existing;
        }

        $this->ensure_user_code($user_id);
        return (string) $this->get_code_for_user($user_id);
    }

    public function ensure_user_code($user_id)
    {
        $user_id = absint($user_id);
        if (! $user_id || $this->get_code_for_user($user_id)) {
            return;
        }

        global $wpdb;
        $now = current_time('mysql');
        $code = $this->generate_unique_code();
        $wpdb->insert(
            $this->table('codes'),
            [
                'user_id'    => $user_id,
                'code'       => $code,
                'is_active'  => 1,
                'created_at' => $now,
                'updated_at' => $now,
            ],
            ['%d', '%s', '%d', '%s', '%s']
        );
    }

    protected function generate_unique_code()
    {
        do {
            $code = strtolower(wp_generate_password(8, false, false));
        } while ($this->get_code_row($code));

        return $code;
    }

    protected function generate_claim_code()
    {
        $settings = $this->get_settings();
        do {
            $code = strtoupper($settings['claim_prefix']) . '-' . strtoupper(wp_generate_password(6, false, false));
        } while ($this->claim_code_exists($code));

        return $code;
    }

    protected function generate_discount_coupon_code()
    {
        do {
            $code = 'RAF-' . strtoupper(wp_generate_password(8, false, false));
        } while (wc_get_coupon_id_by_code($code));

        return $code;
    }

    protected function claim_code_exists($code)
    {
        global $wpdb;
        return (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table('claims')} WHERE claim_code = %s LIMIT 1", $code));
    }

    protected function get_code_for_user($user_id)
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("SELECT code FROM {$this->table('codes')} WHERE user_id = %d LIMIT 1", $user_id));
    }

    protected function get_code_row($code)
    {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('codes')} WHERE code = %s AND is_active = 1 LIMIT 1", $code));
    }

    protected function get_referral_by_order_id($order_id)
    {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('referrals')} WHERE order_id = %d LIMIT 1", $order_id));
    }

    protected function get_rewards($args = [])
    {
        global $wpdb;
        $where = '1=1';
        if (! empty($args['active_only'])) {
            $where .= ' AND is_active = 1';
        }
        return $wpdb->get_results("SELECT * FROM {$this->table('rewards')} WHERE {$where} ORDER BY sort_order ASC, name ASC");
    }

    protected function get_reward($reward_id)
    {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('rewards')} WHERE id = %d LIMIT 1", $reward_id));
    }

    protected function get_claims($args = [])
    {
        global $wpdb;
        $limit = ! empty($args['limit']) ? absint($args['limit']) : 50;
        $where = '1=1';

        if (! empty($args['user_id'])) {
            $where .= $wpdb->prepare(' AND c.user_id = %d', absint($args['user_id']));
        }
        if (! empty($args['status'])) {
            $where .= $wpdb->prepare(' AND c.status = %s', sanitize_text_field($args['status']));
        }

        $sql = "SELECT c.*, r.name AS reward_name
            FROM {$this->table('claims')} c
            LEFT JOIN {$this->table('rewards')} r ON r.id = c.reward_id
            WHERE {$where}
            ORDER BY c.created_at DESC
            LIMIT {$limit}";

        return $wpdb->get_results($sql);
    }

    protected function get_referrals($args = [])
    {
        global $wpdb;
        $limit = ! empty($args['limit']) ? absint($args['limit']) : 50;
        $where = '1=1';

        if (! empty($args['referrer_user_id'])) {
            $where .= $wpdb->prepare(' AND referrer_user_id = %d', absint($args['referrer_user_id']));
        }

        return $wpdb->get_results("SELECT * FROM {$this->table('referrals')} WHERE {$where} ORDER BY created_at DESC LIMIT {$limit}");
    }

    protected function add_ledger_entry($user_id, $referral_id, $delta, $type, $notes)
    {
        global $wpdb;
        $wpdb->insert(
            $this->table('credits_ledger'),
            [
                'user_id'       => (int) $user_id,
                'referral_id'   => $referral_id ? (int) $referral_id : null,
                'delta_credits' => (int) $delta,
                'entry_type'    => sanitize_key($type),
                'notes'         => sanitize_textarea_field($notes),
                'created_at'    => current_time('mysql'),
            ],
            ['%d', '%d', '%d', '%s', '%s', '%s']
        );
    }

    protected function has_ledger_entry_for_referral($referral_id, $type)
    {
        global $wpdb;
        return (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table('credits_ledger')} WHERE referral_id = %d AND entry_type = %s LIMIT 1", $referral_id, sanitize_key($type)));
    }

    protected function get_total_earned_for_referral($referral_id)
    {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(delta_credits), 0) FROM {$this->table('credits_ledger')} WHERE referral_id = %d AND entry_type = 'earn'", $referral_id));
    }

    protected function has_existing_qualified_referral_for_referred_identity($current_referral_id, $referred_user_id, $referred_email)
    {
        global $wpdb;
        $statuses = ['rewarded', 'qualified'];

        if ($referred_user_id) {
            $count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table('referrals')} WHERE id != %d AND referred_user_id = %d AND status IN ('rewarded','qualified')",
                $current_referral_id,
                $referred_user_id
            ));
            if ($count > 0) {
                return true;
            }
        }

        if ($referred_email) {
            $count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table('referrals')} WHERE id != %d AND referred_email = %s AND status IN ('rewarded','qualified')",
                $current_referral_id,
                sanitize_email($referred_email)
            ));
            if ($count > 0) {
                return true;
            }
        }

        return false;
    }

    protected function update_referral_status($referral_id, $status, $extra = [])
    {
        global $wpdb;
        $data = array_merge([
            'status'     => sanitize_key($status),
            'updated_at' => current_time('mysql'),
        ], $extra);

        $formats = [];
        foreach ($data as $key => $value) {
            if (is_int($value)) {
                $formats[] = '%d';
            } elseif (is_float($value)) {
                $formats[] = '%f';
            } else {
                $formats[] = '%s';
            }
        }

        $wpdb->update($this->table('referrals'), $data, ['id' => (int) $referral_id], $formats, ['%d']);
    }

    protected function get_available_credits($user_id)
    {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(delta_credits), 0) FROM {$this->table('credits_ledger')} WHERE user_id = %d", $user_id));
    }

    protected function get_lifetime_credits($user_id)
    {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(delta_credits), 0) FROM {$this->table('credits_ledger')} WHERE user_id = %d AND delta_credits > 0", $user_id));
    }

    protected function get_pending_referrals_count($user_id)
    {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table('referrals')} WHERE referrer_user_id = %d AND status = 'pending'", $user_id));
    }
}
