<?php
defined('ABSPATH') || exit;

function vms_raf_core_function(string $legacy_name): string
{
    $public_name = strpos($legacy_name, 'vms_') === 0
        ? 'bvmgr_' . substr($legacy_name, 4)
        : $legacy_name;

    if (function_exists($public_name)) {
        return $public_name;
    }

    return function_exists($legacy_name) ? $legacy_name : '';
}

function vms_raf_has_core_function(string $legacy_name): bool
{
    return vms_raf_core_function($legacy_name) !== '';
}

function vms_raf_call_core_function(string $legacy_name, ...$args)
{
    $function = vms_raf_core_function($legacy_name);
    return $function !== '' ? $function(...$args) : null;
}
