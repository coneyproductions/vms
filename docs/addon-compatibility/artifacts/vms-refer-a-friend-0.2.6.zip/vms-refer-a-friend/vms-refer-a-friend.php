<?php
/**
 * Plugin Name: VMS Refer-a-Friend
 * Plugin URI: https://example.com/
 * Description: Ticket-only refer-a-friend add-on for VMS-powered venues. Earn referral credits from qualifying ticket purchases and redeem them for venue-defined rewards.
 * Version: 0.2.6
 * Author: OpenAI
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Text Domain: vms-refer-a-friend
 */

if (! defined('ABSPATH')) {
    exit;
}

if (! defined('VMS_RAF_VERSION')) {
    define('VMS_RAF_VERSION', '0.2.6');
}

if (! defined('VMS_RAF_FILE')) {
    define('VMS_RAF_FILE', __FILE__);
}

if (! defined('VMS_RAF_DIR')) {
    define('VMS_RAF_DIR', plugin_dir_path(__FILE__));
}

if (! defined('VMS_RAF_URL')) {
    define('VMS_RAF_URL', plugin_dir_url(__FILE__));
}

require_once VMS_RAF_DIR . 'includes/core-compat.php';
require_once VMS_RAF_DIR . 'includes/class-vms-raf-db.php';
require_once VMS_RAF_DIR . 'includes/class-vms-raf-plugin.php';

register_activation_hook(__FILE__, ['VMS_RAF_DB', 'activate']);
register_deactivation_hook(__FILE__, ['VMS_RAF_DB', 'deactivate']);

function vms_raf_bootstrap()
{
    VMS_RAF_DB::maybe_upgrade();
    VMS_RAF_Plugin::instance();
}

add_action('plugins_loaded', 'vms_raf_bootstrap');
