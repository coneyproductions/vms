# VMS Refer-a-Friend 0.2.2 Test Plan — VMS Registry Integration

🚨 **Codex/browser verification required.** This pass specifically tests whether RAF behaves like a plug-and-play VMS module under the new VMS admin registry.

## Baseline

- WordPress admin site with VMS core **0.2.24.600 or newer** active.
- WooCommerce active.
- VMS Refer-a-Friend 0.2.2 active.
- Log in as an admin with `manage_woocommerce` access.

## 1. WordPress left menu stays compact

1. Open `/wp-admin/`.
2. Hover the VMS item in the WordPress left admin menu.
3. Confirm the VMS flyout still shows only the primary launchers:
   - Dashboard
   - Planning
   - Vendors & Staff
   - Marketing & Social
   - Venues
   - Settings
   - Tools
4. Confirm there is **no separate top-level “VMS Referrals” menu** when VMS registry is active.
5. Confirm RAF does **not** add RAF Dashboard / Rewards / Claims / Referral Log / Settings / Help to the WordPress left flyout.

## 2. RAF appears inside VMS navigation

1. Open `/wp-admin/admin.php?page=vms-raf`.
2. Confirm the page loads with HTTP 200 and no permission error.
3. Confirm the global VMS top nav renders.
4. Confirm Marketing & Social / Marketing & Sales is the active VMS area.
5. Confirm the active category list includes:
   - Refer-a-Friend
   - RAF Rewards
   - RAF Claims
   - RAF Referral Log
   - RAF Settings
   - RAF Guided Help

## 3. Direct URL checks

Open each URL and confirm HTTP 200, no “Sorry, you are not allowed to access this page,” and the VMS top nav is present:

- `/wp-admin/admin.php?page=vms-raf`
- `/wp-admin/admin.php?page=vms-raf-rewards`
- `/wp-admin/admin.php?page=vms-raf-claims`
- `/wp-admin/admin.php?page=vms-raf-referrals`
- `/wp-admin/admin.php?page=vms-raf-settings`
- `/wp-admin/admin.php?page=vms-raf-help`

## 4. All VMS Pages registry discovery

1. Open `/wp-admin/admin.php?page=vms-admin-pages`.
2. Search for `RAF` or `Refer-a-Friend`.
3. Confirm all six RAF admin pages are listed.
4. Confirm their source is `vms-refer-a-friend`.
5. Confirm there are no missing callbacks for RAF pages.
6. Confirm the RAF pages are classified under Marketing & Sales, not unclassified.

## 5. Guided help / assets

1. Open each RAF admin page.
2. Confirm RAF admin CSS loads.
3. Confirm the guided help/tour button still appears where expected.
4. Confirm the tour has page-specific steps, especially:
   - Dashboard summary cards
   - Rewards form/table
   - Claims table
   - Referral log table
   - Settings form
   - Guided Help grid

## 6. Standalone fallback smoke test

Only run this on a disposable local site or with VMS temporarily disabled.

1. Disable VMS core.
2. Keep WooCommerce and RAF active.
3. Confirm the standalone top-level **VMS Referrals** admin menu appears.
4. Confirm RAF Dashboard, Rewards, Claims, Referral Log, Settings, and Guided Help are reachable from the standalone menu.
5. Re-enable VMS core after the test.

## Pass criteria

- RAF behaves like a VMS module when VMS registry is present.
- RAF does not lengthen the WordPress left VMS flyout.
- RAF is discoverable through VMS internal navigation and All VMS Pages.
- RAF direct URLs work.
- RAF remains usable as a standalone fallback when the VMS registry is unavailable.
