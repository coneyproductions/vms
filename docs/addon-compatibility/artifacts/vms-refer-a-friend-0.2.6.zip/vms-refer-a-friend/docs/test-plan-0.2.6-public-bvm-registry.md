# VMS Refer-a-Friend 0.2.6 Test Plan

- Load with public Backstage Venue Manager 1.2.0 and no active historical VMS plugin.
- Confirm all Refer-a-Friend admin pages enter the public BVM registry without duplicate standalone menus.
- Confirm the BVM shell and public event-calendar URL resolve through public APIs.
- Confirm referral, reward, claim, settings, and existing database data remain unchanged.
