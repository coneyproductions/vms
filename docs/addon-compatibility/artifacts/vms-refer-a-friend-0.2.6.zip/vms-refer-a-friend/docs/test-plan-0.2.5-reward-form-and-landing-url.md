# VMS Refer-a-Friend 0.2.5 Test Plan

## Baseline

- WordPress with WooCommerce active.
- VMS Refer-a-Friend 0.2.5 installed.
- At least one admin user exists.
- RAF rewards and settings pages are accessible.

## 1. Reward form clarity

1. Open `VMS Marketing & Social > Refer-a-Friend > Rewards`.
2. Start a new reward with `Reward type` set to `Prize / claim`.
3. Confirm these coupon-only fields are hidden:
   - Discount type
   - Discount amount
   - Coupon expiry days
4. Confirm the helper copy under `Reward type` says the reward is a manual prize or claim handled by staff.
5. Confirm `Credit cost` shows helper copy explaining it is the number of referral credits required.
6. Switch `Reward type` to `Future ticket discount coupon`.
7. Confirm the coupon-only fields appear and the helper copy updates.
8. Enter coupon values, switch back to `Prize / claim`, then switch to `Future ticket discount coupon` again.
9. Confirm the previously entered coupon values are still present.

## 2. Landing URL preview and warning

1. Open `VMS Marketing & Social > Refer-a-Friend > Settings`.
2. Confirm `Referral landing URL` helper copy explains that the field should point to a live ticket/calendar page and not an admin URL.
3. Confirm the settings page shows:
   - an invite-link preview using a sample code
   - a `Test referral link` button or link that opens in a new tab
4. Save the landing URL as the site home URL and confirm the preview link works.
5. Save the landing URL as `/calendar/`.
6. If `/calendar/` does not map to a live page on the site, confirm a soft warning appears.
7. Save the landing URL as the real live public calendar/events URL and confirm the warning disappears.

## 3. Query-string handling

1. Save the landing URL with an existing query string, such as the live calendar/events URL plus `?view=list`.
2. Confirm the preview invite link appends `vms_ref` with `&vms_ref=` instead of breaking the existing query string.

## 4. PHP lint

1. Run `php -l` against every RAF PHP file.
2. Confirm no RAF PHP syntax errors are reported.

## Pass criteria

- Prize / claim rewards no longer show coupon-specific fields until the coupon reward type is selected.
- Reward helper text clearly distinguishes manual prizes from future ticket discount coupons.
- The referral landing URL preview and test link are visible in settings.
- The settings page warns when a configured same-site landing path appears missing or non-live.
- Query-string landing URLs append `vms_ref` correctly.
- All RAF PHP files pass `php -l`.
