# VMS Refer-a-Friend 0.2.4 Test Plan

## Baseline

- WordPress with WooCommerce active.
- VMS Refer-a-Friend 0.2.4 installed.
- A WooCommerce My Account page is available at `/my-account/`.
- At least one admin user and one customer test account exist.

## 1. Activation and endpoint behavior

1. Deactivate VMS Refer-a-Friend.
2. Activate VMS Refer-a-Friend again.
3. Open `/my-account/refer-a-friend/`.
4. Confirm the endpoint loads without a 404 and without manually saving permalinks.

## 2. Customer dashboard hero and sharing

1. Log in as a customer with zero referral credits.
2. Open `/my-account/refer-a-friend/`.
3. Confirm the hero shows one dynamic offer headline generated from saved settings.
4. Confirm there is only one visible invite-link display: the input plus the `Copy invite link` button.
5. Confirm the referral code is still visible but secondary.
6. Click `Copy invite link` and confirm a temporary `Copied.` message appears.
7. Paste the copied value into a text field and confirm the URL includes `vms_ref=`.
8. Confirm the friend discount, credit amount, and minimum-order detail are not repeated across multiple cards.

## 3. Rewards and empty states

1. View the dashboard for a customer with zero credits and no claims.
2. Confirm the no-referrals and no-claims states feel present and compact rather than broken.
3. Make sure multiple active rewards exist in RAF admin.
4. View the dashboard for a customer with some credits.
5. Confirm rewards render in a responsive grid/list and show:
   - reward name
   - credit cost
   - progress bar
   - `X / Y credits`
   - `Need N more credits` when not yet eligible
6. Confirm claimable rewards sort above non-claimable rewards.
7. Confirm only eligible rewards show a redeem action.

## 4. Referral privacy

1. View the customer dashboard for an account with referral activity.
2. Confirm the referral activity table still renders.
3. Confirm no full referred customer email address is exposed on the public dashboard.

## 5. Admin navigation

1. Open the main VMS Marketing & Social admin page.
2. Confirm the main button row shows only one RAF entry: `Refer-a-Friend`.
3. Open Refer-a-Friend.
4. Confirm the internal RAF subnav includes:
   - Dashboard
   - Rewards
   - Claims
   - Referral Log
   - Settings
   - Guided Help
5. Confirm each RAF page is reachable from the internal subnav and direct routing still works.

## Pass criteria

- `/my-account/refer-a-friend/` returns successfully immediately after deactivate/activate.
- The customer dashboard shows one clear offer and one visible share-link display.
- Reward progress and sorting display correctly for multiple rewards.
- Copied referral links preserve `vms_ref`.
- Public referral activity does not expose full customer email addresses.
- The VMS Marketing & Social button row is reduced to one RAF entry and RAF pages remain reachable through the internal subnav.
