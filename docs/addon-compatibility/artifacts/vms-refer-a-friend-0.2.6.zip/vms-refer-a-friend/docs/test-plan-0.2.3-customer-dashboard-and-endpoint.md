# VMS Refer-a-Friend 0.2.3 Test Plan

## Baseline

- WordPress site with WooCommerce active.
- VMS Refer-a-Friend 0.2.3 installed.
- A My Account page is available at `/my-account/`.
- At least one test customer account exists.

## 1. Activation and endpoint behavior

1. Deactivate VMS Refer-a-Friend.
2. Activate VMS Refer-a-Friend again.
3. Open `/my-account/refer-a-friend/`.
4. Confirm the endpoint loads without a 404 and without manually saving permalinks.

## 2. Zero-credit dashboard

1. Log in as a customer with no referral activity and no claims.
2. Open `/my-account/refer-a-friend/`.
3. Confirm the hero card explains the current offer using the saved settings.
4. Confirm the primary action is `Copy invite link`.
5. Confirm the referral code is visible but secondary.
6. Confirm the page shows encouraging empty states for:
   - no referrals
   - no claims

## 3. Reward progress and active rewards

1. Make sure at least one active reward exists in RAF admin.
2. View the customer dashboard for an account with credits available or with a reward cost higher than available credits.
3. Confirm each reward shows progress in the format `X / Y ... earned`.
4. Confirm the helper copy explains either:
   - how many more credits are needed, or
   - that the reward is unlocked

## 4. Referral link behavior

1. Click `Copy invite link`.
2. Paste the copied value into a text field.
3. Confirm the copied URL includes `vms_ref=`.
4. If `Referral landing URL` is set to a custom path such as `/calendar/`, confirm the copied URL uses that landing page and still includes `vms_ref=`.

## 5. Referral activity privacy

1. View the customer dashboard for an account that already has referral activity.
2. Confirm the referral activity table still renders.
3. Confirm no full referred customer email address is shown on the public dashboard.

## Pass criteria

- Activation immediately enables `/my-account/refer-a-friend/`.
- The customer dashboard feels promotional and complete at zero credits.
- Reward progress displays correctly.
- Copied referral links preserve `vms_ref`.
- Public referral activity does not expose full referred customer email addresses.
