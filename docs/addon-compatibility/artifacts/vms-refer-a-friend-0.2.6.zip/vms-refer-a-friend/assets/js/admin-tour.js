(function () {
  const config = window.vmsRafTour || {};
  const steps = Array.isArray(config.steps) ? config.steps : [];
  if (!steps.length) {
    return;
  }

  const labels = Object.assign({ start: 'Start tour', next: 'Next', done: 'Done', skip: 'Skip' }, config.labels || {});
  const wrap = document.querySelector('.wrap h1');
  if (!wrap) {
    return;
  }

  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'button vms-raf-tour-launch';
  button.textContent = labels.start;
  wrap.insertAdjacentElement('afterend', button);

  let current = 0;
  let overlay = null;
  let popover = null;
  let activeNode = null;

  function cleanup() {
    if (activeNode) {
      activeNode.classList.remove('vms-raf-tour-highlight');
      activeNode = null;
    }
    if (overlay) {
      overlay.remove();
      overlay = null;
    }
    if (popover) {
      popover.remove();
      popover = null;
    }
  }

  function closeTour() {
    cleanup();
    current = 0;
  }

  function stepNode(step) {
    return document.querySelector(step.selector);
  }

  function renderStep() {
    cleanup();
    if (!steps[current]) {
      closeTour();
      return;
    }

    const step = steps[current];
    const node = stepNode(step);
    if (!node) {
      current += 1;
      renderStep();
      return;
    }

    activeNode = node;
    activeNode.classList.add('vms-raf-tour-highlight');

    overlay = document.createElement('div');
    overlay.className = 'vms-raf-tour-overlay';
    overlay.addEventListener('click', closeTour);
    document.body.appendChild(overlay);

    popover = document.createElement('div');
    popover.className = 'vms-raf-tour-popover';
    popover.innerHTML = [
      '<h3>' + (step.title || '') + '</h3>',
      '<p>' + (step.text || '') + '</p>',
      '<div class="vms-raf-tour-actions">',
      '  <button type="button" class="button button-secondary" data-tour-skip>' + labels.skip + '</button>',
      '  <button type="button" class="button button-primary" data-tour-next>' + (current === steps.length - 1 ? labels.done : labels.next) + '</button>',
      '</div>'
    ].join('');
    document.body.appendChild(popover);

    const rect = node.getBoundingClientRect();
    const popRect = popover.getBoundingClientRect();
    let top = window.scrollY + rect.bottom + 12;
    let left = window.scrollX + rect.left;

    if (left + popRect.width > window.innerWidth - 16) {
      left = window.innerWidth - popRect.width - 16;
    }
    if (top + popRect.height > window.scrollY + window.innerHeight - 16) {
      top = window.scrollY + rect.top - popRect.height - 12;
    }
    if (top < window.scrollY + 16) {
      top = window.scrollY + 16;
    }
    if (left < 16) {
      left = 16;
    }

    popover.style.top = top + 'px';
    popover.style.left = left + 'px';

    const next = popover.querySelector('[data-tour-next]');
    const skip = popover.querySelector('[data-tour-skip]');
    next.addEventListener('click', function () {
      current += 1;
      renderStep();
    });
    skip.addEventListener('click', closeTour);
  }

  button.addEventListener('click', renderStep);
})();
