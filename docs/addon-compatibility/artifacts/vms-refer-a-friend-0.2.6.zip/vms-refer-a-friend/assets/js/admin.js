(function () {
  function syncRewardTypeForm() {
    const control = document.querySelector('[data-vms-raf-reward-type-control]');
    if (!control) {
      return;
    }

    const couponFields = Array.from(document.querySelectorAll('[data-vms-raf-coupon-field]'));
    const helpBlocks = Array.from(document.querySelectorAll('[data-vms-raf-reward-type-help]'));

    function applyState() {
      const rewardType = control.value === 'discount_coupon' ? 'discount_coupon' : 'physical_claim';
      const showCouponFields = rewardType === 'discount_coupon';

      couponFields.forEach(function (row) {
        row.hidden = !showCouponFields;
        row.setAttribute('aria-hidden', showCouponFields ? 'false' : 'true');
      });

      helpBlocks.forEach(function (block) {
        const show = block.getAttribute('data-vms-raf-reward-type-help') === rewardType;
        block.hidden = !show;
        block.setAttribute('aria-hidden', show ? 'false' : 'true');
      });
    }

    control.addEventListener('change', applyState);
    applyState();
  }

  function init() {
    syncRewardTypeForm();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
    return;
  }

  init();
})();
