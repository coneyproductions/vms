(function () {
  const config = window.vmsRafFrontend || {};
  const copySuccess = config.copySuccess || 'Copied.';
  const copyFailure = config.copyFailure || 'Copy failed. Please copy the link manually.';

  function selectInput(input) {
    if (!input) {
      return;
    }
    input.focus();
    input.select();
    if (typeof input.setSelectionRange === 'function') {
      input.setSelectionRange(0, input.value.length);
    }
  }

  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }

    const helper = document.createElement('textarea');
    helper.value = text;
    helper.setAttribute('readonly', 'readonly');
    helper.style.position = 'fixed';
    helper.style.top = '-9999px';
    helper.style.left = '-9999px';
    document.body.appendChild(helper);
    helper.focus();
    helper.select();

    let copied = false;
    try {
      copied = document.execCommand('copy');
    } catch (error) {
      copied = false;
    }

    helper.remove();
    return copied;
  }

  function showCopyFeedback(copyButton, message) {
    const feedbackId = copyButton.getAttribute('data-copy-feedback');
    const feedback = feedbackId ? document.getElementById(feedbackId) : null;
    if (!feedback) {
      return;
    }

    if (feedback._vmsRafTimer) {
      window.clearTimeout(feedback._vmsRafTimer);
    }

    feedback.textContent = message;
    feedback.hidden = false;
    feedback._vmsRafTimer = window.setTimeout(function () {
      feedback.textContent = '';
      feedback.hidden = true;
    }, 1800);
  }

  document.addEventListener('click', async function (event) {
    const copyButton = event.target.closest('.vms-raf-copy-button');
    if (!copyButton) {
      return;
    }

    const targetId = copyButton.getAttribute('data-copy-target');
    const input = targetId ? document.getElementById(targetId) : null;
    if (!input) {
      return;
    }

    selectInput(input);

    try {
      const copied = await copyText(input.value);
      if (!copied) {
        throw new Error('copy-failed');
      }
      showCopyFeedback(copyButton, copySuccess);
    } catch (error) {
      window.alert(copyFailure);
    }
  });

  document.addEventListener('click', function (event) {
    const input = event.target.closest('[data-vms-raf-copy-source="true"]');
    if (!input) {
      return;
    }

    selectInput(input);
  });
})();
