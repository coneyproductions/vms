(function () {
  function initSlider(container) {
    var slides = Array.prototype.slice.call(
      container.querySelectorAll(".vms-events-slider__slide")
    );
    if (!slides.length) return;

    var dotsContainer = container.querySelector(".vms-events-slider__dots");
    var prevBtn = container.querySelector(".vms-events-slider__prev");
    var nextBtn = container.querySelector(".vms-events-slider__next");
    var autoplayDelay = parseInt(container.getAttribute("data-autoplay"), 10) || 5000;

    var current = 0;
    var timer = null;

    if (dotsContainer) {
      slides.forEach(function (_, index) {
        var dot = document.createElement("button");
        dot.type = "button";
        dot.className = "vms-events-slider__dot";
        dot.setAttribute("data-index", index);
        dot.setAttribute("aria-label", "Go to slide " + (index + 1));
        dotsContainer.appendChild(dot);
      });
    }

    var dots = dotsContainer
      ? Array.prototype.slice.call(dotsContainer.querySelectorAll(".vms-events-slider__dot"))
      : [];

    function showSlide(index) {
      slides.forEach(function (slide, i) {
        slide.classList.toggle("is-active", i === index);
      });
      dots.forEach(function (dot, i) {
        dot.classList.toggle("is-active", i === index);
      });
      current = index;
    }

    function nextSlide() {
      showSlide((current + 1) % slides.length);
    }

    function prevSlide() {
      showSlide((current - 1 + slides.length) % slides.length);
    }

    function startAutoplay() {
      if (timer) clearInterval(timer);
      timer = setInterval(nextSlide, autoplayDelay);
    }

    function stopAutoplay() {
      if (timer) clearInterval(timer);
      timer = null;
    }

    if (nextBtn) {
      nextBtn.addEventListener("click", function () {
        stopAutoplay();
        nextSlide();
        startAutoplay();
      });
    }

    if (prevBtn) {
      prevBtn.addEventListener("click", function () {
        stopAutoplay();
        prevSlide();
        startAutoplay();
      });
    }

    dots.forEach(function (dot) {
      dot.addEventListener("click", function () {
        var index = parseInt(dot.getAttribute("data-index"), 10);
        stopAutoplay();
        showSlide(index);
        startAutoplay();
      });
    });

    showSlide(0);
    startAutoplay();
  }

  document.addEventListener("DOMContentLoaded", function () {
    var sliders = document.querySelectorAll(".vms-events-slider");
    sliders.forEach(initSlider);
  });
})();
