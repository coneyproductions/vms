# VMS Events Slider 1.0.10 Test Plan

- Load with public Backstage Venue Manager 1.2.0 and no active historical VMS plugin.
- Confirm both slider shortcodes register and resolve public calendar/status/reschedule/cancellation/ticketing APIs.
- Request the exact anonymous canonical homepage twice and confirm the expected slider markup and identical cached response.
- Confirm cancelled/rescheduled filtering and existing slider cache keys remain intact.
