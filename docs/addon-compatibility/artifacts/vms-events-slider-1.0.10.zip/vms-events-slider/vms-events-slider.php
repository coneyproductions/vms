<?php
/**
 * Plugin Name: VMS Events Slider
 * Description: Cached slider that shows upcoming visible event featured images from The Events Calendar.
 * Author: VMS
 * Version: 1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'VMS_EVENTS_SLIDER_VERSION' ) ) {
    define( 'VMS_EVENTS_SLIDER_VERSION', '1.0.10' );
}

if ( ! defined( 'VMS_EVENTS_SLIDER_CACHE_TTL' ) ) {
    define( 'VMS_EVENTS_SLIDER_CACHE_TTL', 10 * MINUTE_IN_SECONDS );
}

if ( ! defined( 'VMS_EVENTS_SLIDER_CACHE_BUST_OPTION' ) ) {
    define( 'VMS_EVENTS_SLIDER_CACHE_BUST_OPTION', 'vms_events_slider_cache_bust' );
}

if ( ! defined( 'VMS_EVENTS_SLIDER_IMAGE_SIZE' ) ) {
    define( 'VMS_EVENTS_SLIDER_IMAGE_SIZE', 'vms-events-slider' );
}

if ( ! defined( 'VMS_EVENTS_SLIDER_SHORTCODE' ) ) {
    define( 'VMS_EVENTS_SLIDER_SHORTCODE', 'vms_events_slider' );
}

if ( ! defined( 'VMS_EVENTS_SLIDER_LEGACY_SHORTCODE' ) ) {
    define( 'VMS_EVENTS_SLIDER_LEGACY_SHORTCODE', 'serenade_events_slider' );
}

if ( ! defined( 'VMS_EVENTS_SLIDER_STYLE_HANDLE' ) ) {
    define( 'VMS_EVENTS_SLIDER_STYLE_HANDLE', 'vms-events-slider' );
}

if ( ! defined( 'VMS_EVENTS_SLIDER_SCRIPT_HANDLE' ) ) {
    define( 'VMS_EVENTS_SLIDER_SCRIPT_HANDLE', 'vms-events-slider' );
}

/**
 * Resolve public BVM runtime symbols while retaining legacy VMS fallback.
 */
function vms_events_slider_core_function( $legacy_name ) {
    $public_name = 0 === strpos( $legacy_name, 'vms_' )
        ? 'bvmgr_' . substr( $legacy_name, 4 )
        : $legacy_name;

    if ( function_exists( $public_name ) ) {
        return $public_name;
    }

    return function_exists( $legacy_name ) ? $legacy_name : '';
}

function vms_events_slider_has_core_function( $legacy_name ) {
    return '' !== vms_events_slider_core_function( $legacy_name );
}

function vms_events_slider_call_core_function( $legacy_name, ...$args ) {
    $function = vms_events_slider_core_function( $legacy_name );
    return '' !== $function ? $function( ...$args ) : null;
}

function vms_events_slider_core_constant( $legacy_name, $default = null ) {
    $public_name = 0 === strpos( $legacy_name, 'VMS_' )
        ? 'BVMGR_' . substr( $legacy_name, 4 )
        : $legacy_name;

    if ( defined( $public_name ) ) {
        return constant( $public_name );
    }
    if ( defined( $legacy_name ) ) {
        return constant( $legacy_name );
    }

    return $default;
}

/**
 * Register the dedicated slider image size.
 */
function vms_events_slider_register_image_size() {
    $dimensions = (array) apply_filters(
        'vms_events_slider_image_dimensions',
        array(
            'width'  => 1600,
            'height' => 900,
            'crop'   => true,
        )
    );

    $width  = isset( $dimensions['width'] ) ? absint( $dimensions['width'] ) : 1600;
    $height = isset( $dimensions['height'] ) ? absint( $dimensions['height'] ) : 900;
    $crop   = ! empty( $dimensions['crop'] );

    add_image_size( VMS_EVENTS_SLIDER_IMAGE_SIZE, $width, $height, $crop );
}
add_action( 'after_setup_theme', 'vms_events_slider_register_image_size', 20 );

/**
 * Return the shortcode tags that should resolve to this slider.
 *
 * @return string[]
 */
function vms_events_slider_shortcode_tags() {
    $tags = array(
        VMS_EVENTS_SLIDER_SHORTCODE,
        VMS_EVENTS_SLIDER_LEGACY_SHORTCODE,
    );

    $tags = array_values(
        array_unique(
            array_filter(
                array_map( 'sanitize_key', $tags )
            )
        )
    );

    return $tags;
}

/**
 * Check whether a content string contains the slider shortcode.
 *
 * @param mixed $content Content string.
 * @return bool
 */
function vms_events_slider_content_has_shortcode( $content ) {
    if ( ! is_string( $content ) || '' === $content ) {
        return false;
    }

    foreach ( vms_events_slider_shortcode_tags() as $tag ) {
        if ( has_shortcode( $content, $tag ) ) {
            return true;
        }
    }

    return false;
}

/**
 * Check whether the current request is expected to render the slider shortcode.
 *
 * @return bool
 */
function vms_events_slider_current_request_uses_shortcode() {
    if ( is_admin() ) {
        return false;
    }

    $queried_object = get_queried_object();
    if ( $queried_object instanceof WP_Post && vms_events_slider_content_has_shortcode( $queried_object->post_content ) ) {
        return true;
    }

    global $wp_query;

    if ( $wp_query instanceof WP_Query && ! empty( $wp_query->posts ) ) {
        foreach ( $wp_query->posts as $candidate ) {
            if ( $candidate instanceof WP_Post && vms_events_slider_content_has_shortcode( $candidate->post_content ) ) {
                return true;
            }
        }
    }

    if ( is_front_page() ) {
        $front_page_id = absint( get_option( 'page_on_front' ) );
        if ( $front_page_id > 0 ) {
            $front_page = get_post( $front_page_id );
            if ( $front_page instanceof WP_Post && vms_events_slider_content_has_shortcode( $front_page->post_content ) ) {
                return true;
            }
        }
    }

    return false;
}

/**
 * Mark slider assets as required for the current request.
 *
 * @param bool $required Whether the current request needs slider assets.
 */
function vms_events_slider_mark_assets_required( $required = true ) {
    if ( $required ) {
        $GLOBALS['vms_events_slider_should_enqueue_assets'] = true;
    }
}

/**
 * Flag whether slider assets should be enqueued for the current request.
 */
function vms_events_slider_flag_asset_requirement() {
    vms_events_slider_mark_assets_required( vms_events_slider_current_request_uses_shortcode() );
}
add_action( 'wp', 'vms_events_slider_flag_asset_requirement', 20 );

/**
 * Read the current asset-enqueue flag.
 *
 * @return bool
 */
function vms_events_slider_should_enqueue_assets() {
    return ! empty( $GLOBALS['vms_events_slider_should_enqueue_assets'] );
}

/**
 * Register slider CSS/JS.
 */
function vms_events_slider_register_assets() {
    if ( is_admin() ) {
        return;
    }

    wp_register_style(
        VMS_EVENTS_SLIDER_STYLE_HANDLE,
        plugin_dir_url( __FILE__ ) . 'assets/vms-events-slider.css',
        array(),
        VMS_EVENTS_SLIDER_VERSION
    );

    wp_register_script(
        VMS_EVENTS_SLIDER_SCRIPT_HANDLE,
        plugin_dir_url( __FILE__ ) . 'assets/vms-events-slider.js',
        array(),
        VMS_EVENTS_SLIDER_VERSION,
        true
    );
}

/**
 * Enqueue slider CSS/JS for the current request.
 */
function vms_events_slider_enqueue_assets() {
    if ( is_admin() ) {
        return;
    }

    vms_events_slider_mark_assets_required( true );
    vms_events_slider_register_assets();

    wp_enqueue_style( VMS_EVENTS_SLIDER_STYLE_HANDLE );
    wp_enqueue_script( VMS_EVENTS_SLIDER_SCRIPT_HANDLE );
}

/**
 * Register slider CSS/JS and enqueue only when the current request needs them.
 */
function vms_events_slider_assets() {
    if ( is_admin() ) {
        return;
    }

    vms_events_slider_register_assets();

    if ( ! vms_events_slider_should_enqueue_assets() ) {
        return;
    }

    vms_events_slider_enqueue_assets();
}
add_action( 'wp_enqueue_scripts', 'vms_events_slider_assets' );

/**
 * Provide a one-time inline CSS fallback when the shortcode is rendered after wp_head.
 *
 * @return string
 */
function vms_events_slider_inline_style_fallback() {
    if ( ! did_action( 'wp_head' ) ) {
        return '';
    }

    if ( ! vms_events_slider_should_enqueue_assets() ) {
        return '';
    }

    if ( ! empty( $GLOBALS['vms_events_slider_inline_css_printed'] ) || wp_style_is( VMS_EVENTS_SLIDER_STYLE_HANDLE, 'done' ) ) {
        return '';
    }

    $path = plugin_dir_path( __FILE__ ) . 'assets/vms-events-slider.css';
    if ( ! is_readable( $path ) ) {
        return '';
    }

    $css = trim( (string) file_get_contents( $path ) );
    if ( '' === $css ) {
        return '';
    }

    $GLOBALS['vms_events_slider_inline_css_printed'] = true;

    return "<style id=\"vms-events-slider-inline-css\">\n{$css}\n</style>\n";
}

/**
 * Resolve the best available image size for the slider.
 *
 * Prefer the dedicated slider size when it already exists on the attachment.
 * Fall back to core intermediate sizes before using the full original.
 *
 * @param int $attachment_id Attachment ID.
 * @return string
 */
function vms_events_slider_resolve_image_size( $attachment_id ) {
    $attachment_id = absint( $attachment_id );
    if ( $attachment_id <= 0 ) {
        return 'large';
    }

    $metadata        = wp_get_attachment_metadata( $attachment_id );
    $available_sizes = array_keys( (array) ( $metadata['sizes'] ?? array() ) );
    $preferred_sizes = array(
        VMS_EVENTS_SLIDER_IMAGE_SIZE,
        'large',
        'medium_large',
        'medium',
    );

    foreach ( $preferred_sizes as $size_name ) {
        if ( in_array( $size_name, $available_sizes, true ) ) {
            return $size_name;
        }
    }

    return 'full';
}

/**
 * Normalize shortcode attributes before using them in a cache key.
 *
 * @param array|string $atts Raw shortcode attributes.
 * @return array<string,int>
 */
function vms_events_slider_normalize_atts( $atts ) {
    $normalized = shortcode_atts(
        array(
            'limit' => 10,
        ),
        is_array( $atts ) ? $atts : array(),
        VMS_EVENTS_SLIDER_SHORTCODE
    );

    $normalized['limit'] = absint( $normalized['limit'] );
    if ( $normalized['limit'] <= 0 ) {
        $normalized['limit'] = 10;
    }

    ksort( $normalized );

    return $normalized;
}

/**
 * Return event-plan meta keys that should invalidate the slider when changed.
 *
 * @return string[]
 */
function vms_events_slider_plan_meta_keys() {
    $keys = array(
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'status' ) : '_vms_event_plan_status',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'date' ) : '_vms_event_date',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'tec_event_id' ) : '_vms_tec_event_id',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancel_policy' ) : '_vms_cancel_policy',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancel_reason_code' ) : '_vms_cancel_reason_code',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancel_reason_note' ) : '_vms_cancel_reason_note',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancel_vendor_message' ) : '_vms_cancel_vendor_message',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancelled_at_gmt' ) : '_vms_cancelled_at_gmt',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancelled_by_user_id' ) : '_vms_cancelled_by_user_id',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancel_job_id' ) : '_vms_cancel_job_id',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancel_job_state' ) : '_vms_cancel_job_state',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancel_job_summary' ) : '_vms_cancel_job_summary',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'cancel_requires_operator_review' ) : '_vms_cancel_requires_operator_review',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'rescheduled_from_plan_id' ) : '_vms_rescheduled_from_plan_id',
        vms_events_slider_has_core_function( 'vms_meta_key' ) ? (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'rescheduled_to_plan_ids' ) : '_vms_rescheduled_to_plan_ids',
    );

    return array_values(
        array_unique(
            array_filter(
                array_map( 'strval', $keys )
            )
        )
    );
}

/**
 * Build the version tokens used in the slider cache key.
 *
 * @return array<string,string>
 */
function vms_events_slider_cache_version_tokens() {
    $tokens = array(
        'plugin' => VMS_EVENTS_SLIDER_VERSION,
        'local'  => (string) get_option( VMS_EVENTS_SLIDER_CACHE_BUST_OPTION, '1' ),
    );

    $shared_option = (string) vms_events_slider_core_constant(
        'VMS_CALENDAR_FEED_CACHE_BUST_OPTION',
        'vms_calendar_feed_cache_bust'
    );

    $shared_value = (string) get_option( $shared_option, '' );
    if ( '' !== $shared_value ) {
        $tokens['shared'] = $shared_value;
    }

    return $tokens;
}

/**
 * Build the transient key for a rendered slider snapshot.
 *
 * @param array<string,int> $atts Normalized shortcode attributes.
 * @return string
 */
function vms_events_slider_cache_key( $atts ) {
    $payload = array(
        'atts'    => $atts,
        'blog_id' => function_exists( 'get_current_blog_id' ) ? (int) get_current_blog_id() : 0,
        'version' => vms_events_slider_cache_version_tokens(),
    );

    return 'vms_evt_slider_' . md5( wp_json_encode( $payload ) );
}

/**
 * Append a lightweight cache note for admins only.
 *
 * @param string $html Slider HTML.
 * @param string $state Cache state label.
 * @param string $cache_key Cache key.
 * @return string
 */
function vms_events_slider_with_debug_comment( $html, $state, $cache_key ) {
    if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
        return $html;
    }

    $suffix = substr( md5( $cache_key ), 0, 8 );

    return $html . "\n" . sprintf(
        '<!-- VMS Events Slider cache: %1$s (%2$s) -->',
        esc_html( strtoupper( sanitize_key( $state ) ) ),
        esc_html( $suffix )
    );
}

/**
 * Advance the slider cache version and, when available, the shared VMS event/feed version.
 */
function vms_events_slider_bust_cache() {
    update_option( VMS_EVENTS_SLIDER_CACHE_BUST_OPTION, sprintf( '%.6F', microtime( true ) ), false );

    if ( vms_events_slider_has_core_function( 'vms_calendar_feed_cache_bust' ) ) {
        vms_events_slider_call_core_function('vms_calendar_feed_cache_bust');
    }
}

/**
 * Get VMS Event Plan IDs linked to a TEC event.
 *
 * @param int $event_id TEC event post ID.
 * @return int[]
 */
function vms_events_slider_get_linked_plan_ids( $event_id ) {
    $event_id = absint( $event_id );

    if ( ! $event_id ) {
        return array();
    }

    $plan_ids = array();

    if ( vms_events_slider_has_core_function( 'vms_get_event_plan_for_tec_event' ) ) {
        $maybe = absint( vms_events_slider_call_core_function('vms_get_event_plan_for_tec_event',  $event_id ) );
        if ( $maybe > 0 && 'vms_event_plan' === get_post_type( $maybe ) ) {
            $plan_ids[] = $maybe;
        }
    }

    if ( vms_events_slider_has_core_function( 'vms_resolve_event_plan_for_tec_event' ) ) {
        $maybe = absint( vms_events_slider_call_core_function('vms_resolve_event_plan_for_tec_event',  $event_id ) );
        if ( $maybe > 0 && 'vms_event_plan' === get_post_type( $maybe ) ) {
            $plan_ids[] = $maybe;
        }
    }

    if ( vms_events_slider_has_core_function( 'vms_ticketing_v2_find_plan_id_by_tec_event_id' ) ) {
        $maybe = absint( vms_events_slider_call_core_function('vms_ticketing_v2_find_plan_id_by_tec_event_id',  $event_id ) );
        if ( $maybe > 0 && 'vms_event_plan' === get_post_type( $maybe ) ) {
            $plan_ids[] = $maybe;
        }
    }

    foreach ( array( '_vms_event_plan_id', 'vms_event_plan_id' ) as $event_meta_key ) {
        $maybe = absint( get_post_meta( $event_id, $event_meta_key, true ) );
        if ( $maybe > 0 && 'vms_event_plan' === get_post_type( $maybe ) ) {
            $plan_ids[] = $maybe;
        }
    }

    $tec_meta_keys = array( '_vms_tec_event_id' );
    if ( vms_events_slider_has_core_function( 'vms_meta_key' ) ) {
        $key = (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'tec_event_id' );
        if ( '' !== $key ) {
            $tec_meta_keys[] = $key;
        }
    }
    if ( vms_events_slider_has_core_function( 'vms_ticketing_b_meta_key' ) ) {
        $key = (string) vms_events_slider_call_core_function('vms_ticketing_b_meta_key',  'tec_event_id', '_vms_tec_event_id' );
        if ( '' !== $key ) {
            $tec_meta_keys[] = $key;
        }
    }

    foreach ( array_values( array_unique( $tec_meta_keys ) ) as $tec_meta_key ) {
        $found = get_posts(
            array(
                'post_type'      => 'vms_event_plan',
                'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
                'posts_per_page' => 10,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    array(
                        'key'     => $tec_meta_key,
                        'value'   => array( (string) $event_id, $event_id ),
                        'compare' => 'IN',
                    ),
                ),
            )
        );

        foreach ( (array) $found as $maybe ) {
            $maybe = absint( $maybe );
            if ( $maybe > 0 ) {
                $plan_ids[] = $maybe;
            }
        }
    }

    return array_values( array_unique( array_filter( array_map( 'absint', $plan_ids ) ) ) );
}

/**
 * Resolve the primary VMS event plan for a TEC event.
 *
 * Prefer the canonical VMS resolver so stale linked plans do not suppress
 * current public events.
 *
 * @param int $event_id TEC event post ID.
 * @return int
 */
function vms_events_slider_get_primary_plan_id( $event_id ) {
    $event_id = absint( $event_id );

    if ( ! $event_id ) {
        return 0;
    }

    if ( vms_events_slider_has_core_function( 'vms_resolve_event_plan_for_tec_event' ) ) {
        $plan_id = absint( vms_events_slider_call_core_function('vms_resolve_event_plan_for_tec_event',  $event_id ) );
        if ( $plan_id > 0 && 'vms_event_plan' === get_post_type( $plan_id ) ) {
            return $plan_id;
        }
    }

    if ( vms_events_slider_has_core_function( 'vms_get_event_plan_for_tec_event' ) ) {
        $plan_id = absint( vms_events_slider_call_core_function('vms_get_event_plan_for_tec_event',  $event_id ) );
        if ( $plan_id > 0 && 'vms_event_plan' === get_post_type( $plan_id ) ) {
            return $plan_id;
        }
    }

    if ( vms_events_slider_has_core_function( 'vms_ticketing_v2_find_plan_id_by_tec_event_id' ) ) {
        $plan_id = absint( vms_events_slider_call_core_function('vms_ticketing_v2_find_plan_id_by_tec_event_id',  $event_id ) );
        if ( $plan_id > 0 && 'vms_event_plan' === get_post_type( $plan_id ) ) {
            return $plan_id;
        }
    }

    $linked = vms_events_slider_get_linked_plan_ids( $event_id );

    return ! empty( $linked ) ? absint( $linked[0] ) : 0;
}

/**
 * Determine whether the event is hidden from upcoming views.
 *
 * @param int $event_id Event post ID.
 * @return bool
 */
function vms_events_slider_is_hidden_from_upcoming( $event_id ) {
    $event_id = absint( $event_id );

    if ( ! $event_id ) {
        return false;
    }

    $value = get_post_meta( $event_id, '_EventHideFromUpcoming', true );

    return '' !== $value && '0' !== (string) $value;
}

/**
 * Resolve the canonical plan status for a linked VMS event plan.
 *
 * @param int $plan_id Event plan post ID.
 * @return string
 */
function vms_events_slider_get_plan_status( $plan_id ) {
    $plan_id = absint( $plan_id );

    if ( ! $plan_id ) {
        return '';
    }

    $status = '';

    if ( vms_events_slider_has_core_function( 'vms_event_plan_get_status' ) ) {
        $status = (string) vms_events_slider_call_core_function('vms_event_plan_get_status',  $plan_id, 'generic' );
    }

    if ( '' === $status ) {
        $status_key = '_vms_event_plan_status';
        if ( vms_events_slider_has_core_function( 'vms_meta_key' ) ) {
            $maybe_key = (string) vms_events_slider_call_core_function('vms_meta_key',  'event_plan', 'status' );
            if ( '' !== $maybe_key ) {
                $status_key = $maybe_key;
            }
        }
        $status = (string) get_post_meta( $plan_id, $status_key, true );
    }

    if ( 'canceled' === $status ) {
        $status = 'cancelled';
    }

    return sanitize_key( $status );
}

/**
 * Determine whether a linked plan has a public reschedule destination.
 *
 * @param int $plan_id Event plan post ID.
 * @return bool
 */
function vms_events_slider_plan_has_public_reschedule_destination( $plan_id ) {
    $plan_id = absint( $plan_id );

    if ( ! $plan_id || ! vms_events_slider_has_core_function( 'vms_event_plan_get_public_reschedule_destination' ) ) {
        return false;
    }

    $destination = (array) vms_events_slider_call_core_function('vms_event_plan_get_public_reschedule_destination',  $plan_id );

    return ! empty( $destination['url'] );
}

/**
 * Determine whether an event should be treated as cancelled.
 *
 * This checks TEC, then VMS's own cancellation helper, then the linked VMS Event Plan status/meta.
 *
 * @param int $event_id Event post ID.
 * @return bool
 */
function vms_events_slider_is_cancelled_event( $event_id ) {
    $event_id = absint( $event_id );

    if ( ! $event_id ) {
        return false;
    }

    if ( vms_events_slider_has_core_function( 'vms_tec_is_cancelled_event' ) && vms_events_slider_call_core_function('vms_tec_is_cancelled_event',  $event_id ) ) {
        return true;
    }

    if ( function_exists( 'tribe_is_event_cancelled' ) && tribe_is_event_cancelled( $event_id ) ) {
        return true;
    }

    if ( function_exists( 'tribe_event_is_cancelled' ) && tribe_event_is_cancelled( $event_id ) ) {
        return true;
    }

    $post_status = strtolower( (string) get_post_status( $event_id ) );
    if ( in_array( $post_status, array( 'cancelled', 'canceled', 'tribe-ea-cancelled', 'tribe-ea-canceled' ), true ) ) {
        return true;
    }

    $status_meta_keys = array(
        '_tribe_events_status',
        '_tribe_events_event_status',
        '_EventStatus',
        '_vms_event_status',
        'vms_event_status',
        '_vms_plan_status',
        'vms_plan_status',
        '_vms_event_plan_status',
    );

    foreach ( $status_meta_keys as $meta_key ) {
        $value = get_post_meta( $event_id, $meta_key, true );

        if ( '' === $value || null === $value ) {
            continue;
        }

        $normalized = sanitize_key( (string) $value );
        if ( in_array( $normalized, array( 'cancelled', 'canceled' ), true ) ) {
            return true;
        }
    }

    $plan_id = vms_events_slider_get_primary_plan_id( $event_id );
    if ( $plan_id > 0 ) {
        $status = vms_events_slider_get_plan_status( $plan_id );
        if ( in_array( $status, array( 'cancelled', 'canceled' ), true ) ) {
            return true;
        }

        if ( '' !== (string) get_post_meta( $plan_id, '_vms_cancelled_at_gmt', true ) ) {
            return true;
        }
    }

    return false;
}

/**
 * Determine whether an event should be treated as rescheduled and excluded from the slider.
 *
 * @param int $event_id Event post ID.
 * @return bool
 */
function vms_events_slider_is_rescheduled_event( $event_id ) {
    $event_id = absint( $event_id );

    if ( ! $event_id ) {
        return false;
    }

    $status_meta_keys = array(
        '_tribe_events_status',
        '_tribe_events_event_status',
        '_EventStatus',
    );

    foreach ( $status_meta_keys as $meta_key ) {
        $value = sanitize_key( (string) get_post_meta( $event_id, $meta_key, true ) );
        if ( in_array( $value, array( 'postponed', 'rescheduled' ), true ) ) {
            return true;
        }
    }

    $plan_id = vms_events_slider_get_primary_plan_id( $event_id );
    if ( $plan_id > 0 ) {
        $status = vms_events_slider_get_plan_status( $plan_id );

        if ( in_array( $status, array( 'postponed', 'rescheduled' ), true ) ) {
            return true;
        }

        if ( 'cancelled' === $status && vms_events_slider_plan_has_public_reschedule_destination( $plan_id ) ) {
            return true;
        }
    }

    return false;
}

/**
 * Determine whether an event should be excluded from the slider.
 *
 * @param int $event_id Event post ID.
 * @return bool
 */
function vms_events_slider_should_skip_event( $event_id ) {
    return vms_events_slider_is_hidden_from_upcoming( $event_id )
        || vms_events_slider_is_cancelled_event( $event_id )
        || vms_events_slider_is_rescheduled_event( $event_id );
}

/**
 * Bust the slider cache after a TEC event save.
 *
 * @param int     $post_id Event ID.
 * @param WP_Post $post Event post.
 * @param bool    $update Whether this is an update.
 */
function vms_events_slider_on_save_tribe_event( $post_id, $post, $update ) {
    unset( $update );

    if ( empty( $post ) || 'tribe_events' !== $post->post_type ) {
        return;
    }

    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
        return;
    }

    vms_events_slider_bust_cache();
}
add_action( 'save_post_tribe_events', 'vms_events_slider_on_save_tribe_event', 20, 3 );

/**
 * Bust the slider cache after an event plan save.
 *
 * @param int     $post_id Plan ID.
 * @param WP_Post $post Plan post.
 * @param bool    $update Whether this is an update.
 */
function vms_events_slider_on_save_event_plan( $post_id, $post, $update ) {
    unset( $update );

    if ( empty( $post ) || 'vms_event_plan' !== $post->post_type ) {
        return;
    }

    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
        return;
    }

    vms_events_slider_bust_cache();
}
add_action( 'save_post_vms_event_plan', 'vms_events_slider_on_save_event_plan', 20, 3 );

/**
 * Bust the slider cache when relevant post statuses change.
 *
 * @param string  $new_status New post status.
 * @param string  $old_status Old post status.
 * @param WP_Post $post Post object.
 */
function vms_events_slider_on_status_transition( $new_status, $old_status, $post ) {
    if ( $new_status === $old_status || ! ( $post instanceof WP_Post ) ) {
        return;
    }

    if ( in_array( $post->post_type, array( 'tribe_events', 'vms_event_plan' ), true ) ) {
        vms_events_slider_bust_cache();
    }
}
add_action( 'transition_post_status', 'vms_events_slider_on_status_transition', 20, 3 );

/**
 * Bust the slider cache when relevant TEC or VMS event-plan metadata changes.
 *
 * @param mixed  $meta_ids Meta identifier or identifiers.
 * @param int    $post_id Post ID.
 * @param string $meta_key Meta key.
 * @param mixed  $meta_value Meta value.
 */
function vms_events_slider_on_post_meta_change( $meta_ids, $post_id, $meta_key, $meta_value ) {
    unset( $meta_ids, $meta_value );

    $post_id = absint( $post_id );
    if ( $post_id <= 0 || '' === $meta_key ) {
        return;
    }

    $post_type = get_post_type( $post_id );

    if ( 'tribe_events' === $post_type ) {
        $tec_keys = array(
            '_thumbnail_id',
            '_EventHideFromUpcoming',
            '_EventStartDate',
            '_EventStartDateUTC',
            '_EventEndDate',
            '_EventEndDateUTC',
            '_EventStatus',
            '_tribe_events_status',
            '_tribe_events_event_status',
            '_tribe_events_control_status_canceled_reason',
            '_tribe_events_control_status_postponed_reason',
        );

        if ( in_array( $meta_key, $tec_keys, true ) ) {
            vms_events_slider_bust_cache();
        }

        return;
    }

    if ( 'vms_event_plan' === $post_type && in_array( $meta_key, vms_events_slider_plan_meta_keys(), true ) ) {
        vms_events_slider_bust_cache();
    }
}
add_action( 'added_post_meta', 'vms_events_slider_on_post_meta_change', 20, 4 );
add_action( 'updated_post_meta', 'vms_events_slider_on_post_meta_change', 20, 4 );
add_action( 'deleted_post_meta', 'vms_events_slider_on_post_meta_change', 20, 4 );

/**
 * Bust the slider cache when TEC writes its event status payload.
 *
 * @param int   $post_id Event ID.
 * @param array $data TEC status payload.
 */
function vms_events_slider_on_tec_event_status_meta( $post_id, $data ) {
    unset( $data );

    if ( absint( $post_id ) <= 0 ) {
        return;
    }

    vms_events_slider_bust_cache();
}
add_action( 'tribe_events_event_status_update_post_meta', 'vms_events_slider_on_tec_event_status_meta', 20, 2 );

/**
 * Shortcode: [vms_events_slider limit="5"]
 *
 * @param array|string $atts Shortcode attributes.
 * @return string
 */
function vms_events_slider_shortcode( $atts ) {
    if ( ! post_type_exists( 'tribe_events' ) ) {
        return '<!-- VMS Events Slider: tribe_events post type not found -->';
    }

    vms_events_slider_enqueue_assets();

    $atts       = vms_events_slider_normalize_atts( $atts );
    $cache_key  = vms_events_slider_cache_key( $atts );
    $cached     = get_transient( $cache_key );
    $style_fall = vms_events_slider_inline_style_fallback();

    if ( false !== $cached ) {
        return $style_fall . vms_events_slider_with_debug_comment( (string) $cached, 'hit', $cache_key );
    }

    $limit       = max( 1, (int) $atts['limit'] );
    $query_limit = min( 50, max( $limit, $limit * 3 ) );
    $today       = current_time( 'mysql' );

    $query = new WP_Query(
        array(
            'post_type'              => 'tribe_events',
            'post_status'            => 'publish',
            'posts_per_page'         => $query_limit,
            'meta_key'               => '_EventStartDate',
            'orderby'                => 'meta_value',
            'order'                  => 'ASC',
            'ignore_sticky_posts'    => true,
            'no_found_rows'          => true,
            'update_post_meta_cache' => true,
            'update_post_term_cache' => false,
            'meta_query'             => array(
                'relation' => 'AND',
                array(
                    'key'     => '_EventStartDate',
                    'value'   => $today,
                    'compare' => '>=',
                    'type'    => 'DATETIME',
                ),
                array(
                    'key'     => '_thumbnail_id',
                    'compare' => 'EXISTS',
                ),
            ),
        )
    );

    if ( ! $query->have_posts() ) {
        $html = '<!-- VMS Events Slider: no upcoming events -->';
        set_transient( $cache_key, $html, VMS_EVENTS_SLIDER_CACHE_TTL );

        return $style_fall . vms_events_slider_with_debug_comment( $html, 'miss', $cache_key );
    }

    $slides     = array();
    $sizes_attr = (string) apply_filters(
        'vms_events_slider_image_sizes_attr',
        '(max-width: 767px) 100vw, (max-width: 1200px) 90vw, 1200px'
    );

    while ( $query->have_posts() ) :
        $query->the_post();

        $event_id = get_the_ID();
        if ( vms_events_slider_should_skip_event( $event_id ) ) {
            continue;
        }

        $thumbnail_id = get_post_thumbnail_id( $event_id );
        if ( $thumbnail_id <= 0 ) {
            continue;
        }

        $slide_index = count( $slides );
        $title       = get_the_title( $event_id );
        $permalink   = get_permalink( $event_id );
        $image_html  = wp_get_attachment_image(
            $thumbnail_id,
            vms_events_slider_resolve_image_size( $thumbnail_id ),
            false,
            array(
                'class'         => 'vms-events-slider__image',
                'alt'           => $title,
                'sizes'         => $sizes_attr,
                'loading'       => 0 === $slide_index ? 'eager' : 'lazy',
                'decoding'      => 'async',
                'fetchpriority' => 0 === $slide_index ? 'high' : 'auto',
            )
        );

        if ( '' === $image_html ) {
            continue;
        }

        $slides[] = sprintf(
            '<div class="vms-events-slider__slide"><a href="%1$s">%2$s</a></div>',
            esc_url( $permalink ),
            $image_html
        );

        if ( count( $slides ) >= $limit ) {
            break;
        }
    endwhile;
    wp_reset_postdata();

    if ( empty( $slides ) ) {
        $html = '<!-- VMS Events Slider: no upcoming visible events with featured images -->';
        set_transient( $cache_key, $html, VMS_EVENTS_SLIDER_CACHE_TTL );

        return $style_fall . vms_events_slider_with_debug_comment( $html, 'miss', $cache_key );
    }

    ob_start();
    ?>
    <div class="vms-events-slider" data-autoplay="5000">
        <div class="vms-events-slider__slides">
            <?php foreach ( $slides as $slide_html ) : ?>
                <?php echo $slide_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php endforeach; ?>
        </div>

        <button class="vms-events-slider__nav vms-events-slider__prev" type="button" aria-label="Previous slide">&#10094;</button>
        <button class="vms-events-slider__nav vms-events-slider__next" type="button" aria-label="Next slide">&#10095;</button>

        <div class="vms-events-slider__dots"></div>
    </div>
    <?php
    $html = trim( ob_get_clean() );

    set_transient( $cache_key, $html, VMS_EVENTS_SLIDER_CACHE_TTL );

    return $style_fall . vms_events_slider_with_debug_comment( $html, 'miss', $cache_key );
}
add_shortcode( VMS_EVENTS_SLIDER_SHORTCODE, 'vms_events_slider_shortcode' );
add_shortcode( VMS_EVENTS_SLIDER_LEGACY_SHORTCODE, 'vms_events_slider_shortcode' );
