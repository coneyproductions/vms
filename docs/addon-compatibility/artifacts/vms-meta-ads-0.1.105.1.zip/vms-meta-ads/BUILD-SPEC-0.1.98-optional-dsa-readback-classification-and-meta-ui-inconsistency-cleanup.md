# VMS Meta Ads Builder 0.1.98

## Scope
- Reclassify post-create DSA readiness when values are configured and sent but Meta does not return them in ad-set readback.
- Keep blank DSA settings as a warning.
- Keep actual Meta `issues_info` entries blocking.
- Clarify Multi-advertiser / Advantage+ stale-checkbox guidance in readiness copy.

## Runtime Changes
- Dry-run DSA note now warns that Meta may not echo optional DSA fields back in read-only ad-set API responses.
- Post-create readiness now classifies DSA as advisory when:
  - MAB settings are configured
  - create payload was prepared with DSA values
  - Meta ad-set readback omitted those fields
  - Meta returned no blocking `issues_info`
- Post-create readiness now treats:
  - `issues_info > 0` as `error`
  - `recommendations > 0` with no `issues_info` as `warning`
- Paused-create persistence now stores a local `dsa_payload` marker in `meta_ids` so future readback can distinguish configured-and-sent payloads from blank settings.
- Multi-advertiser / Advantage+ readiness cards now explicitly warn not to save manual edits unless Meta Review still shows both Off.

## Safety
- No schema change.
- No VMS core dependency change.
- No Meta mutation behavior change in no-spend mode.
- No change to Go Live enablement.
