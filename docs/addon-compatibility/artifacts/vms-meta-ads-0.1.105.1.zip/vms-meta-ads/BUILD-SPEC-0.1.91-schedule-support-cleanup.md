# MAB 0.1.91 Build Spec — Schedule Support Cleanup

## Goal

Remove the stale literal `Flat run` requirement from dry-run/create validation, keep no-spend behavior intact, and make new builds start from a direct-create-safe single-window schedule by default.

## Changes

- Replace the hard-coded `flat_run` validator with schedule-window support helpers:
  - infer the saved schedule preset from `schedule_payload` / tiers
  - count saved schedule windows from the hydrated build tiers
  - treat direct Meta create/update support as `true` only when the saved build currently resolves to one window
- Keep `Preview Meta Dry Run` local-only and no-spend:
  - still logs to `wp_vms_api_attempts`
  - still makes zero calls to `graph.facebook.com`
  - now warns, rather than blocks, when the saved build still expands into multiple schedule windows
  - still previews only the first remaining window that direct create would use today
- Keep direct Meta create/update blocked for multi-window builds:
  - `flat_run`, `simple_7_day`, `simple_14_day`, `simple_30_day`, and `manual_dates` remain create-compatible when the saved build resolves to one window
  - tiered multi-window presets remain available for preview/export/manual planning
- Expose `schedule_support` metadata in dry-run responses:
  - preset key/label
  - saved tier count
  - `direct_create_supported`
  - current preview window key/label
  - create/update support message when blocked
- Fix the residual default UX issue:
  - add a new builder default strategy `direct_create_safe_ticket_push`
  - start new builds on `simple_14_day`
  - keep `BUY_TICKETS`, sales intent, 30-65 audience, and safe Meta control defaults
  - align the settings-side default preset fallback to `simple_14_day`
- Expand the tier storage schema for saved builds:
  - bump `VMS Meta Ads` DB version to `4`
  - widen `wp_vms_meta_ads_tiers.tier_key` from `varchar(8)` to `varchar(16)`
  - ensure `simple_14` / `simple_30` single-window tiers can be saved without DB write failures

## Companion requirement

- This package still requires VMS core `0.2.24.711` or newer.
- No new VMS core package is required for this pass.

## Non-goals

- Do not reconnect Meta.
- Do not enable live Meta create/publish.
- Do not create or publish real campaigns.
- Do not change production behavior beyond safer schedule validation/defaults for no-spend operation.
