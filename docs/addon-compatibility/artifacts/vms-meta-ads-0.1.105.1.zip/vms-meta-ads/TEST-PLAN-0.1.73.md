# Test Plan — VMS Meta Ads Builder 0.1.73

## Scope

This test plan verifies the first clean-room campaign recipe pass. The priority is making sure the Builder can save a multi-ad-set recipe and create paused Meta assets without breaking existing single-ad-set workflows.

## Pre-flight

1. Install `vms-meta-ads` 0.1.73 into the canonical plugin folder.
2. Confirm `vms-build.txt` reports `Version: 0.1.73`.
3. Confirm the Meta API connection is valid in MAB settings.
4. Use a future Event Plan with a valid ticket URL, event date, venue address/ZIP targeting anchor, budget, image creative, and at least one copy variant.

## UI / save regression

1. Open the Meta Ads Builder for a future Event Plan.
2. Select **Clean-Room Concert Campaign - Full Push**.
3. Confirm the strategy applies:
   - Preset mode: Flat run
   - CTA: Buy Tickets
   - Buy Tickets lock: enabled
   - Optimization: Landing Page Views
   - Manual placement mode
   - Feed/Reels/Stories/Right Column placement selections
   - Creative automation: Off
   - Multi-advertiser ads: Off
   - Age default: 45–65+
4. Confirm the clean-room checklist appears.
5. Toggle one related control, such as Multi-advertiser ads, and confirm the checklist changes from pass to warning.
6. Restore the control and confirm the checklist returns to pass.
7. Click **Save Draft**.
8. Reload the Builder and confirm the clean-room strategy/build selection persists.
9. Confirm the copy pack includes a Campaign Recipe section with four ad sets.

## Backend payload check

After Save Draft, inspect the saved build payload through the Builder API/debug tools if available.

Expected:

- `strategy_template` is `clean_room_full_push`.
- `campaign_recipe` is `clean_room_full_push`.
- `copy_payload.campaign_recipe_payload.recipe_key` is `clean_room_full_push`.
- Four ad sets exist:
  - `core_feed_reels`
  - `promo_video_reels`
  - `outer_towns_50_plus`
  - `fb_right_column`

## Meta create test — PAUSED only

⚠️ This test creates real paused Meta assets. Do not click Go Live until review is complete.

1. With the saved clean-room build selected, click **Create in Meta (PAUSED)**.
2. Expected success message mentions a campaign, multiple ad sets, and multiple ads created paused.
3. Confirm the build remains linked to the returned Meta IDs.
4. In Meta Ads Manager, confirm:
   - One campaign was created.
   - Four ad sets were created.
   - All campaign/ad-set/ad assets are paused.
   - Ad-set names match the recipe labels.
   - Right Column ad set only uses Facebook right column placement.
   - Feed/Reels ad sets use their intended placements.
   - Destination URL is the event/ticket URL.
   - CTA is Buy Tickets if Meta accepts it for the configuration; otherwise confirm the plugin warning/fallback behavior is understandable.
   - Advantage+ catalog ads are not enabled by the plugin.
   - Multi-advertiser ads are off unless deliberately changed.

## Status / action regression

1. Click **Refresh Meta Status**.
2. Confirm the Builder still shows a linked/paused status and lists multiple variants without errors.
3. Click **Update Existing Meta Ad**.
4. Expected: update is blocked with a clear message explaining multi-ad-set recipe updates are not supported in this pass.
5. Optional after full human review: click **Go Live**.
   - Confirm all created ad sets and ads are activated, not just the first ad set/ad.
6. Optional after go-live: click **Pause All**.
   - Confirm all created ads, all ad sets, and the campaign are paused.

## Existing workflow regression

Using a separate future Event Plan/build:

1. Select **Ticketed Concert - Video-Led Local Push** or another non-clean-room strategy.
2. Save Draft.
3. Confirm existing single-ad-set Create in Meta behavior still works.
4. Confirm existing Update Existing Meta Ad behavior is not blocked for normal single-ad-set builds.
5. Confirm adopted Meta campaigns still show source-of-truth/drift messaging as before.

## Rollback

If clean-room create produces unexpected Meta structure:

1. Pause the affected campaign in Meta Ads Manager.
2. In MAB, use Reset Meta Link for the test build if needed.
3. Reinstall the previous known-good MAB zip.
4. Verify normal single-ad-set create/update workflows still function.
