# TEST PLAN — VMS Meta Ads Builder 0.1.69

## Scope

Validate that first-load build hydration, build selection preservation, refresh behavior, and Meta discovery context are stable for Event Plan 2515 or another Event Plan with multiple saved builds.

## Safety

Do **not** invoke live-changing Meta actions during this test:

- Create in Meta
- Update Existing Meta Ad
- Go Live
- Pause
- Budget Sync

Adopt/link may be used only if explicitly needed for a non-mutating reconciliation test, but the preferred regression path is to use the already linked build.

## Setup

1. Install `vms-meta-ads-0.1.69-hydration-selection-hardening.zip` on staging.
2. Confirm `wp-content/plugins/vms-meta-ads/vms-build.txt` reports 0.1.69.
3. Open the Ads Builder with a prefilled Event Plan URL, preferably Buffet Beach Event Plan 2515.

## Tests

### 1. Guided tour does not auto-launch

1. Fresh-load the builder with `prefill=1` and `tour=0` or no `tour` param.
2. Confirm the guided tour does not open by itself or intercept clicks.
3. Click Start tour manually.
4. Confirm the tour opens.

### 2. First-load saved-build list hydration

1. Fresh-load the builder with Event Plan 2515 prefilled.
2. Confirm the visible saved-build list shows all builds returned by the API, not only one currently selected build.
3. Confirm newest-first order matches the API response.
4. Repeat at least three fresh reloads.

Expected: the list remains fully populated on each fresh load.

### 3. Refresh Builds preserves selected build

1. Load the already-adopted/live build, such as build #25 if still available.
2. Confirm the dropdown, hidden build ID, detail line, and visible card all show the same selected build.
3. Click Refresh builds.
4. Confirm the full build list remains visible.
5. Confirm the selected build remains the same build, not the latest draft.

Expected: Refresh updates list data without switching selection.

### 4. Save Draft + reload does not collapse visible list

1. Load a draft build.
2. Make a harmless copy-only change.
3. Click Save Draft.
4. Refresh the page.
5. Confirm the saved-build list still shows the full collection.
6. Confirm the expected saved/current build is visible and loadable.

Expected: a real page reload does not collapse the UI to one build.

### 5. Meta discovery preserves selected build context

1. Load the adopted/live build.
2. Confirm it shows Live in Meta / Meta source of truth.
3. Click Find Existing Meta Campaigns.
4. Confirm the active build does not switch to the latest draft.
5. Confirm the matching Meta campaign is shown as linked/current when IDs match.

Expected: discovery results do not reset build selection or show the already-linked campaign as adoptable for the wrong build.

### 6. Build card loading still works

1. From the visible saved-build list, load several builds in sequence: draft, live/adopted, draft again.
2. Confirm dropdown, hidden build ID, detail line, and visible card all remain synchronized.

## Pass criteria

- Tour does not auto-launch on prefilled builder loads unless explicitly requested.
- First load shows the full saved-build list consistently.
- Refresh builds preserves active selection.
- Save Draft + reload does not collapse to a one-build list.
- Meta discovery preserves the active build and linked/adoptable state.
- No live-changing Meta actions are invoked.
