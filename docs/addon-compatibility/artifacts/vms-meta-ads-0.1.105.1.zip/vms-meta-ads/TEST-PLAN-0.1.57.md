# TEST PLAN 0.1.57

Goal: confirm website-link image creatives stop showing Facebook Event as the destination in Ads Manager.

## Steps
1. Install `vms-meta-ads-0.1.57-website-destination-hard-fix.zip`.
2. Open a linked build that uses Dark Post Link Ad and Default Shared Media.
3. Save Draft, then click **Update Existing Meta Ad**.
4. Open the ad in Ads Manager.
5. Confirm **Destination** shows **Website**, not **Facebook event**.
6. Confirm the website URL is the Serenade Range event page.
7. Confirm previews still render the correct shared image(s).
8. If a vertical shared image is present, confirm Instagram placements still use the vertical asset.
