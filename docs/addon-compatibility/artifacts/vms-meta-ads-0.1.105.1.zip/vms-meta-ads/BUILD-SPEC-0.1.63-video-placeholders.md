# VMS Meta Ads Builder 0.1.63 — Meta-Direct Video Placeholder Build Spec

## Goal

Support video-led ad strategies without requiring operators to upload large video files to WordPress first.

The Ads Builder should allow the operator to mark an ad variant as a video ad concept, create/export the ad structure with a placeholder/static image, and then upload or swap the actual video directly inside Meta Ads Manager.

## Operator Problem

Uploading promo video to the venue website and then sending it to Meta creates unnecessary:

- website storage usage
- server bandwidth usage
- media-library clutter
- upload time
- failure surface area

For the current workflow, Meta Ads Manager is the right place to upload the final video asset.

## Scope Implemented

### Variant Media Mode

Add a new media mode:

```text
video_placeholder
```

Label in the UI:

```text
Video placeholder - upload video in Meta
```

### Behavior

When a variant uses `video_placeholder`:

1. The variant is preserved as its own ad variant.
2. No WordPress video attachment is required.
3. No video file is uploaded from WordPress to Meta.
4. The ad creative initially uses the selected/shared image creative as the placeholder.
5. The copy pack identifies the variant as a Meta-direct video placeholder.
6. Meta create preflight warnings tell the operator to upload or swap the real video directly in Meta before going live.

### Legacy Mode Preserved

The existing WordPress-video upload path remains available as:

```text
Upload WordPress video to Meta (legacy)
```

This avoids breaking old drafts while clearly steering operators toward the Meta-direct placeholder workflow.

## Out of Scope for This Pass

- Full Meta campaign reconciliation/adoption.
- Direct upload of local video files from the browser to Meta.
- Automatic video swap after the ad exists.
- Full Meta API health monitor.
- Active Buffett Beach campaign syncing.

Those should be handled in the next Meta safety/reconciliation pass.

## Recommended Current Workflow

For this weekend's Buffett Beach ad, use Meta Ads Manager as the source of truth unless/until reconciliation is implemented.

For a new video-led ad from the builder:

1. Build strategy and copy in Ads Builder.
2. Choose `Video placeholder - upload video in Meta` for the video variant.
3. Choose a clean placeholder image/poster frame in Default Shared Media.
4. Create/export the ad.
5. Open the draft/live ad in Meta Ads Manager.
6. Upload or swap in the final video directly in Meta.
7. Confirm CTA remains `Buy tickets`.
8. Publish only after preview looks correct.

## Follow-Up Requirement

The next major safety pass should add:

- Find Existing Meta Campaigns for This Event.
- Adopt/link existing Meta campaigns.
- Drift detection between builder payload and live Meta settings.
- Safe Mode when local settings do not match active Meta ads.
- Meta API health/preflight checks.
