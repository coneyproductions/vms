# VMS Meta Ads Builder 0.1.60 — Test Plan

## Focus
1. New **Get Tickets** CTA option behaves safely for offsite website ads.
2. Facebook **Right column** now uses the **1:1 square** image.

## Builder checks
- Open Meta Ads Builder.
- In Step C, verify CTA dropdown shows:
  - Learn More
  - Get Tickets
  - Buy Tickets (Facebook Event)
- Save a draft with **Get Tickets** selected.
- Reload the build and confirm the CTA persists.

## Meta create checks
- Use an event with an external Serenade Range website URL.
- Save Draft.
- Reset Meta Link.
- Create in Meta (PAUSED).
- Open the new ad in Ads Manager.
- Confirm the ad creates successfully.
- Confirm the website destination is still the Serenade Range event URL.

## Placement/image checks
- Provide both a square 1:1 image and a vertical 9:16 image.
- Include Facebook right column placement.
- Create a paused ad.
- In Ads Manager preview, inspect the **Right column** rendering.
- Confirm the image used is the **square 1:1** creative, not the wide asset.

## Regression checks
- Existing Learn More builds still save and create normally.
- Facebook Event / Promote Facebook Event flows are unaffected.
