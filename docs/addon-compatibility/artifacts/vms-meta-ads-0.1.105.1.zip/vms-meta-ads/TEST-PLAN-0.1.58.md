# TEST PLAN 0.1.58

Goal: confirm website-click creatives stop showing Facebook Event as the destination in Ads Manager.

1. Install `vms-meta-ads-0.1.58-destination-hydration-fix.zip`.
2. Open the affected linked build and Save Draft once.
3. Best clean retest: click **Reset Meta Link** and then **Create in Meta (PAUSED)** to force a fresh ad object.
4. Open the new ad in Ads Manager.
5. Confirm **Destination = Website** and the destination URL is the Serenade Range event page.
6. Also confirm the ad preview still shows the intended image(s), copy, and CTA.

If the destination still shows Facebook Event after a fresh create, capture the new create_creative diagnostic bundle and the new ad/creative JSON so the next pass can compare what Ads Manager hydrated from Meta.
