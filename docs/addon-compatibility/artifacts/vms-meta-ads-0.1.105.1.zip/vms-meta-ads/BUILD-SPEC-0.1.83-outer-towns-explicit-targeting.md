# VMS Meta Ads Builder 0.1.83 — Outer Towns Explicit Targeting

## Goal
Prevent Clean-Room recipe Outer Towns ad sets from silently inheriting stale or hardcoded audience behavior.

## Changes

### Explicit Outer Towns input
- Adds a dedicated Step D field: **Outer Towns ZIPs/full addresses**.
- The old Additional Locations field remains for legacy/non-recipe audience use.
- Listed-only mode now points to the dedicated field instead of vague “above” copy.

### Audience inheritance
- Outer Towns now inherits the main campaign age range.
- The Clean-Room recipe no longer forces Outer Towns to 50+ when the operator entered a different Step D age range.
- Outer Towns labels/names no longer imply 50+.

### Listed-only guardrail
- Listed-only mode requires at least one exact ZIP or full street address before a clean-room build can save/create.
- The Meta preflight marks listed-only Outer Towns targeting as explicit-only.
- If explicit locations cannot be resolved, MAB returns an error instead of falling back to the Event Plan venue radius.

### Fresh create payload
- Create in Meta now saves the current draft payload immediately before the Meta create call.
- This reduces stale Step D audience state after failed submissions, navigation, or browser state mismatch.
- The Create button copy/gating now reflects that the latest draft is saved automatically before paused assets are created.

## Operator impact
- Existing manually corrected paused Meta ads should not be overwritten.
- For the next campaign, enter Outer Towns ZIPs/full addresses in the dedicated field and create paused assets for review.
- If Listed-only is selected with no explicit Outer Towns locations, creation is blocked before Meta receives the request.
