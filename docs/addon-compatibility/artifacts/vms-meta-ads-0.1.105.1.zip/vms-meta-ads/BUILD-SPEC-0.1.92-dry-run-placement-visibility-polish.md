# MAB 0.1.92 Build Spec — Dry-Run Placement Visibility Polish

## Goal

Keep the existing no-spend dry-run path intact while making active placements explicit and easy to inspect for both automatic/default and manual placement flows.

## Root cause

- Dry-run previews already resolved placement behavior for create-time use.
- Manual placement flows surfaced placement arrays inside the targeting payload because the targeting spec explicitly includes `publisher_platforms`, `facebook_positions`, and `instagram_positions`.
- Automatic/default flows do not inject those placement arrays into the targeting payload, so the visible preview looked like placements were missing unless the operator inferred them from nested creative rules or knew the default behavior.
- The UI only rendered dry-run summary pills plus raw JSON, so there was no first-class readable placement section.

## Changes

- Add explicit dry-run placement preview data to the Meta client response:
  - requested placement mode
  - effective placement mode
  - active placement labels
  - grouped placement labels by platform
  - requested-vs-effective summary when create-time fallback changes the placement set
- Add per-ad-set placement preview objects and a top-level `placements_overview` collection for the dry-run response.
- Add a readable placement card to the dry-run UI above the raw JSON preview.
- Keep placement behavior unchanged:
  - no placement broadening
  - no placement narrowing
  - no live create/publish changes
- Preserve all current defaults:
  - strategy `direct_create_safe_ticket_push`
  - preset `simple_14_day`
  - age `30-65`
  - CTA `BUY_TICKETS`
  - destination = website event URL

## Companion requirement

- Still requires VMS core `0.2.24.711`.
- No new VMS core package is required for this pass.

## Non-goals

- Do not reconnect Meta.
- Do not enable live Meta create/publish.
- Do not create or publish real campaigns.
- Do not change MAB DB schema or DB version.
