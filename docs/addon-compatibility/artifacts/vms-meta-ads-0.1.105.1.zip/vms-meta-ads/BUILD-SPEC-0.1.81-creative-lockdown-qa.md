# VMS Meta Ads Builder 0.1.81 — Creative Lockdown + Launch QA

## Purpose

Patch `0.1.81` is a pre-launch safety hardening build focused on preventing Meta from quietly changing the campaign creative that MAB intended to create.

This patch was driven by live campaign issues where Meta-side settings such as Dynamic/Flexible Creative behavior, Website Highlights / Show Spotlights, Advantage+ creative enhancements, and multi-advertiser controls caused ads to either fail delivery or show unintended website images.

## Goals

- Keep the operator-created MAB ad plan as the source of truth.
- Make creative automation opt-outs the default instead of an optional setting.
- Add a visible manual QA gate for the Meta-only settings that cannot be fully trusted through API responses.
- Reduce accidental Outer Towns overlap with the core venue radius.
- Surface destination / UTM drift after linked Meta ads are refreshed.

## Changes

### Version markers

- Plugin header bumped to `0.1.81`.
- `VMS_MA_VERSION` bumped to `0.1.81`.
- `module.json` bumped to `0.1.81`.
- `vms-build.txt` bumped to `0.1.81`.

### Creative Lockdown Mode

Added a Creative Lockdown card to Step C explaining that MAB expects the selected image/video, ticket URL, UTM tags, disabled enhancement settings, and placement plan to remain unchanged.

The default Advantage+ creative policy is now:

- `Off / preserve creative`

The builder now blocks Meta create / publish preflight when the saved build attempts to use:

- creative automation policy other than `off`
- Multi-advertiser ads enabled

### Manual Meta QA Gate

Added a Step G QA checklist that must be completed before Go Live:

- Website Highlights / Web Highlight / Show Spotlights are off for every ad.
- Advantage+ creative enhancements are off for every ad.
- Multi-advertiser ads stayed off for every ad.
- Every preview uses only the intended MAB image/video.
- Ticket URL and UTM tags are present on every ad.
- Ad-set schedule start/end is correct in Meta.

The Go Live button remains disabled until this checklist is complete.

### Outer Towns targeting mode

Added an advanced Step D selector:

- `Listed towns/ZIPs only` — default
- `Expanded outer radius`

When `Listed towns/ZIPs only` is selected and additional locations are provided, the Outer Towns audience does not use the primary venue radius anchor. This helps keep the Outer Towns set from silently overlapping the Tyler/Whitehouse/core radius area.

### Drift review

The Meta drift report now attempts to inspect linked ad creatives and warn when:

- the live creative destination does not match the saved MAB destination host/path
- expected `utm_campaign` tracking is not visible on the live creative URL or URL tags

These warnings are intentionally conservative and should be treated as QA prompts, not proof that Meta delivery is broken.

### Copy pack guardrails

The copy pack now includes Creative Lockdown language reminding operators to reject Meta-added website images and enhancements during manual QA.

## Notes

Some Meta settings are still only reliably visible inside Ads Manager. This patch does not claim to disable every enhancement in every account/UI. It instead makes the risky defaults harder to select, blocks obvious non-lockdown settings, and forces a manual review before Go Live.
