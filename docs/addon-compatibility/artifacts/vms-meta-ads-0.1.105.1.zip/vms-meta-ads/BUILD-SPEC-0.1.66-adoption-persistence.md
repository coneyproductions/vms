# VMS Meta Ads Builder 0.1.66 — Adoption Persistence Hardening

## Goal

Fix the adoption persistence problem where an existing Meta campaign could appear linked in the UI, then disappear or revert after a page refresh, Continue, or Save Draft.

## Problem Observed

After linking the existing Buffett Beach Meta campaign:

- the green reconciliation card appeared,
- the UI said the campaign was linked,
- but the linked build dropdown/title still favored stale saved-builder details,
- refreshing the page lost the linked state,
- clicking Continue or Save Draft could leave Build #15 showing as Draft again.

## Implementation Requirements

### 1. Preserve Meta links on Save Draft

When updating an existing build that already has Meta IDs, Save Draft must preserve:

- `meta_campaign_id`
- `meta_ids`
- linked Meta status such as `live` or `meta_created_paused`
- adopted summary/source-of-truth metadata

Save Draft may update local builder settings, but it must not silently downgrade a linked live Meta campaign to an ordinary draft.

### 2. Re-associate tier rows after Save Draft

Because Save Draft rebuilds tier rows, the first new tier row must be re-associated with the existing Meta ad set/ad/creative IDs when the build is already linked.

### 3. Flush stale prefill cache

Flush the builder prefill transient after:

- Save Draft
- Adopt / Link existing Meta campaign

This prevents the page from reloading an older cached pre-adoption build.

### 4. Verify adoption persistence

After Adopt / Link, reload the build server-side and verify the campaign/ad set IDs persisted before returning success.

### 5. Improve server prefill behavior

On page load with a server-prefilled Event Plan, immediately render the prefilled build and then refresh the full linked build list so the dropdown and source-of-truth card reflect current data.

## Non-goals

This pass does not create, pause, publish, edit, or sync any Meta campaign. It only hardens local persistence and display of already-linked Meta IDs.
