# VMS Meta Ads Builder 0.1.54 — Test Plan

## Focus
Fix invalid Instagram Search placement value during replacement ad set creation.

## Test 1 — Update existing linked ad with Instagram Search enabled
1. Open an event with an existing linked Meta build.
2. In Placements, choose Manual.
3. Enable Instagram Search Results (and Instagram Feed if not auto-added by the UI).
4. Click **Update Existing Meta Ad**.
5. Confirm no API error appears for `instagram_positions`.

## Test 2 — Refresh and verify status
1. Click **Refresh Status**.
2. Confirm linked assets still resolve and status panel loads normally.

## Test 3 — Variant/shared-media sanity check
1. Leave one variant on shared media and set another to a custom override.
2. Save Draft.
3. Confirm the UI still hides/shows the correct media controls.

## Expected result
- No `Invalid Instagram Position` / `instagram_positions` API error when Instagram Search is selected.
- Replacement ad set update succeeds or fails for a different reason if another unrelated Meta constraint exists.
