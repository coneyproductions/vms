# VMS Meta Ads Builder — Test Plan 0.1.48

## Goal
Verify creative updates no longer hard-fail when Meta rejects `asset_customization_rules` inside `asset_feed_spec`.

## Install
1. Install `0.1.48`.
2. Confirm the plugin updates in place inside the canonical `vms-meta-ads` folder.

## Test 1 — Existing linked ad creative update
1. Open an Event Plan that already has a linked Meta campaign/ad set/ad.
2. Change audience, budget, and at least one creative image.
3. Click **Save Draft**.
4. Click **Update Existing Meta Ad**.
5. Expected: the update should not die on `Asset Customization Rules field is not supported in asset feed`.
6. Expected: either the richer asset-feed creative lands, or the plugin falls back and still updates the linked ad instead of stopping cold.

## Test 2 — Ads Manager verification
1. Open Ads Manager from the builder.
2. Confirm the linked ad still exists and is still tied to the same campaign/ad set path expected by the update flow.
3. Confirm the newest creative is present.
4. Confirm the audience and budget changes also landed.

## Test 3 — Safety behavior
1. Trigger a creative-only update on another linked ad if available.
2. Confirm the builder does not force a recreate from scratch unless the Meta link is intentionally reset.
3. Confirm no blank-screen failure occurs.

## Notes
- This build adds creative fallback handling for Meta creative creation/update requests.
- First fallback removes `asset_customization_rules` from the asset-feed payload.
- Second fallback drops to a standard single-image story-spec creative so the update can finish instead of fully rejecting the edit.
