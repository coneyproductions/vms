# VMS Meta Ads Builder 0.1.74 — Placement-Aware Recipes v2

## Goal

Turn the current clean-room recipe into a more durable, placement-aware campaign builder.

The Facebook Right Column-only experiment should be treated as a useful signal: it is too narrow to rely on as a standalone strategy. MAB should still support it as an optional low-budget static support test, but it should no longer be a default required ad set in the main clean-room recipe.

This pass should make MAB safer and more practical by adding:

1. Placement-aware creative requirements.
2. A revised Clean-Room Full Push recipe that does not depend on a dedicated side-column-only ad set.
3. A visible pre-create recipe preview table.
4. Better post-create Meta status/review visibility.
5. Clear operator warnings when creative does not fit selected placements.

## Current context

The uploaded plugin is `vms-meta-ads` version `0.1.73`.

Current 0.1.73 behavior:

- Adds **Clean-Room Concert Campaign - Full Push**.
- Creates one paused campaign with four ad sets:
  - Core Radius - Feed/Reels — 50%
  - Promo Video/Reels — 20%
  - Outer Towns - Ages 50+ — 25%
  - Facebook Right Column — 5%
- Blocks multi-ad-set update for this recipe.
- Creates the full recipe paused for Meta review.

## Problem this pass solves

The dedicated Facebook Right Column strategy did not appear to work reliably and may not have been approved. Even if approved, it is too narrow to treat as a default campaign pillar.

Also, video creative needs to be placement-aware. One video asset is not enough. A square or feed-oriented video can look cropped and unprofessional in Reels/Stories, while a tall video is not ideal everywhere. MAB should make the needed creative formats obvious before the campaign is created.

## Strategy decision

### Do not delete Right Column support

Keep Facebook Right Column as an optional experimental/static support placement because it can still be useful as a cheap desktop reminder placement.

### Do remove it from the default recipe structure

The main clean-room recipe should not spend budget on a required standalone Right Column ad set by default.

### New default clean-room allocation

For `clean_room_full_push_v2`, default budget split should be:

| Ad set | Default share | Placement group | Creative expectation |
|---|---:|---|---|
| Core Radius - Feed/Reels | 55% | Facebook Feed, Instagram Feed, Facebook Reels, Instagram Reels | Square/static plus optional video variant |
| Vertical Video - Reels/Stories | 25% | Facebook Reels, Instagram Reels, Facebook Stories, Instagram Stories | 9:16 vertical video required/recommended |
| Outer Towns - Ages 50+ | 20% | Facebook Feed, Instagram Feed, Facebook Reels, Instagram Reels | Static or video variant, broader radius/older age |
| Facebook Right Column Support Test | 0% default / optional 5% | Facebook Right Column, static only | 1:1 static image, short headline |

If the operator enables the optional Right Column support test, MAB should carve its budget from Core Radius by default:

- Core Radius: 50%
- Vertical Video: 25%
- Outer Towns 50+: 20%
- Right Column Support Test: 5%

If the total budget or run window makes the Right Column slice too small for Meta minimums, MAB should not create that ad set. It should show a friendly warning and redistribute budget to the default three-ad-set recipe.

## Feature 1 — Creative format requirements panel

Add a new card in Step C / Creative Assets called **Creative formats needed**.

The card should show simple, operator-friendly asset slots:

| Slot | Label | Required for | Notes |
|---|---|---|---|
| `square_static` | Square image / poster | Feed, Right Column, video placeholder | 1:1 image. Keep text large enough for small previews. |
| `vertical_video` | Tall video | Reels, Stories | 9:16 vertical video. This prevents the side-cropping problem. |
| `feed_video_or_image` | Feed creative | Feed/Reels support | Square or feed-safe asset. For now, use existing shared image behavior if no dedicated feed video exists. |
| `right_column_static` | Right-column image | Optional Right Column test | 1:1 static image only. No video placeholder here unless Meta confirms it is safe. |

### UX requirements

- Keep wording extremely simple.
- Do not require JSON or technical placement fields from the operator.
- Use badges such as:
  - `Ready`
  - `Missing vertical video`
  - `Uses placeholder image`
  - `Review in Meta before go-live`
- When Reels/Stories placements are selected and no vertical video is provided, show a warning:
  - “Tall video is missing. Meta may crop the creative in Reels/Stories. Add a 9:16 video or turn off those placements.”
- When Right Column is enabled and no static square image/headline exists, block creation with a friendly message.
- Do not auto-crop or auto-generate new videos in this pass.

## Feature 2 — Recipe preview table before Create in Meta

Add a visible pre-create recipe preview under the strategy/checklist area.

For multi-ad-set recipes, show:

| Column | Purpose |
|---|---|
| Ad set | Human-readable ad set label |
| Budget | Dollar amount and percentage |
| Audience | Radius / towns / age summary |
| Placements | Friendly placement labels |
| Creative needed | Square, vertical video, static support, etc. |
| Status | Ready / warning / blocked |

This should update live when the operator changes:

- Total budget
- Schedule/preset
- Creative assets
- Strategy
- Optional Right Column support toggle
- Placements
- Age/radius/location inputs

## Feature 3 — Clean-room recipe key/versioning

Add a new recipe key:

```text
clean_room_full_push_v2
```

Keep reading older saved builds with:

```text
clean_room_full_push
```

### Migration behavior

- Old saved builds should still display correctly.
- New saves should use `clean_room_full_push_v2` when the revised recipe is selected.
- Do not silently mutate an existing `clean_room_full_push` build into v2 unless the operator intentionally saves a new draft or clones/resets.
- Preserve backwards-compatible fields for single-campaign/adset status refresh.

## Feature 4 — Optional Right Column support test

Add a checkbox inside the Clean-Room recipe panel:

```text
Include optional Facebook Right Column support test
```

Default: unchecked.

When unchecked:

- Do not create a dedicated Right Column ad set.
- Do not allocate budget to Right Column.
- Do not make the clean-room checklist warn about missing Right Column.

When checked:

- Create a paused Right Column support ad set only if budget and creative checks pass.
- Require static image creative.
- Use a short headline-oriented ad variant.
- Label it clearly as an experiment/support test, not a primary strategy.

Suggested ad set label:

```text
Facebook Right Column Support Test
```

Suggested operator copy:

```text
Use this as a small desktop reminder placement only. Do not rely on it as the main campaign driver.
```

## Feature 5 — Meta review / delivery status panel

After Create in Meta, the refresh/status area should show status at three levels:

1. Campaign
2. Ad set
3. Ad

For each object, show:

- Configured status
- Effective status / delivery status when available
- Review/policy warning if returned by Meta
- Last refreshed timestamp
- Direct Meta object ID, but keep the ID visually secondary

### Operator-facing status copy

Use plain language:

| Condition | Copy |
|---|---|
| Created but paused | Created in Meta, paused for review. |
| Pending/in review | Created, but not delivering yet. Meta may still be reviewing it. |
| Rejected/disapproved | Meta did not approve this ad. Open Meta Ads Manager to review the policy message. |
| Active/delivering | Live in Meta. |
| Unknown | Status could not be confirmed. Refresh again or check Ads Manager. |

## Feature 6 — Guardrails for video format mismatch

Before allowing Create in Meta for recipes that include Reels/Stories:

- If the selected video asset is not marked as vertical, show a warning.
- If the system cannot inspect video dimensions, allow the operator to mark the asset as:
  - `Tall / 9:16`
  - `Square / 1:1`
  - `Wide / 16:9`
  - `Unknown`
- If unknown and Reels/Stories are selected, warn but do not hard-block unless the recipe requires vertical video.

For `clean_room_full_push_v2`, the Vertical Video ad set should be:

- `Ready` only when a 9:16 video or explicit Meta-direct vertical video placeholder is set.
- `Warning` when only a static/shared image exists.
- `Blocked` only if the operator has chosen a strict “Require vertical video before create” toggle.

## Feature 7 — Copy pack / saved build output

The generated copy pack should include a concise placement/creative section:

```text
Creative formats:
- Square/static: Ready
- Vertical video: Missing / Ready / Meta-direct placeholder
- Right Column support: Off / Ready / Blocked
```

The saved `campaign_recipe_payload` should include:

- `recipe_key`
- `recipe_version`
- `include_right_column_support_test`
- `creative_requirements`
- `adsets`
- `guardrails`
- `warnings`

## Do not include in this pass

Do not add these yet:

- Automatic video cropping/resizing/transcoding.
- Analytics-driven campaign restructuring.
- Full multi-ad-set update/reconcile UI.
- Automatic live publishing.
- Custom audience/retargeting creation.
- Sales/conversion objective switch tied to Pixel purchases.

Those belong in later passes after this recipe/creative foundation is stable.

## Files likely touched

Expected files:

- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `assets/ads-builder.js`
- `assets/admin.css`
- `includes/admin/screens/ads-builder.php`
- `includes/services-ad-builds.php`
- `includes/meta-api/client.php`
- `includes/rest/controllers/class-ad-builds-controller.php` if saved payload/schema changes require it

Add docs:

- `BUILD-SPEC-0.1.74-placement-aware-recipes-v2.md`
- `TEST-PLAN-0.1.74.md`

## Versioning requirement

Bump all version markers to `0.1.74`:

- Plugin header version
- `VMS_MA_VERSION`
- `module.json`
- `vms-build.txt`
- Asset enqueue versions if hardcoded or derived from version constants
- Package filename

## Acceptance criteria

This pass is successful when:

1. Clean-Room Full Push v2 defaults to three primary ad sets and no required Right Column-only ad set.
2. The operator can optionally enable a Right Column support test.
3. MAB warns clearly when a vertical video is missing for Reels/Stories.
4. The pre-create preview table shows budget, audience, placements, creative needs, and status per ad set.
5. Saved/reloaded builds preserve the recipe version and optional Right Column setting.
6. Create in Meta still creates everything paused.
7. Post-create status refresh shows campaign/ad set/ad-level status clearly enough that the operator can tell whether the ad is approved, paused, active, rejected, or still unknown.
8. Existing single-ad-set and existing-ad adoption workflows still work.
