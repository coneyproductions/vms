# VMS Meta Ads Builder 0.1.70 — Tour + Discovery Regression Fix

## Objective

Close the two remaining 0.1.69 staging regressions without touching live Meta campaign state.

## Fixes

### 1. Guided tour auto-launch suppression

The Meta Ads Builder now keeps its tour workflow local/manual by default instead of registering the builder/settings/performance tours with the global VMS tour catalog. This prevents the core tour runner from auto-launching an undismissed tour before the Ads Builder's `data-tour-autorun`, `prefill`, and `tour=0` guards can run.

Manual guided tours remain available through the Ads Builder **Start tour** button. A filter remains available for future debugging or explicit integration:

```php
add_filter('vms_ma_register_with_global_tour_catalog', '__return_true');
```

The default is intentionally `false`.

### 2. Meta discovery linked-state rendering

`Find Existing Meta Campaigns` now restores the active build before rendering reconciliation candidates. This lets candidate rendering compare candidates against the correct selected/adopted build metadata.

Expected behavior from an adopted/live build:

- selected build remains selected
- hidden build ID remains unchanged
- dropdown/card/detail line remain synchronized
- the already-linked Meta campaign renders as **Linked to this build**
- it does not offer **Adopt / Link this Meta campaign** for the current linked campaign

## Not in scope

- No Meta create/update/go-live/pause/budget-sync behavior changes.
- No API health check / safe-mode implementation yet.
- No cleanup of old staging test builds.
