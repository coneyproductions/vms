# VMS Meta Ads Builder 0.1.62 — Strategy Templates + Ticket Intent Build Spec

## Purpose

Turn one-off Meta Ads Manager campaign setup into reusable, event-based campaign strategy templates. The builder should help an operator choose a proven strategy, auto-fill safe defaults, keep ticketed concerts positioned as ticketed events, and make Meta's easy-to-miss automation choices visible before export or publish.

## Guiding product rules

1. **Campaign strategies are templates, not hardcoded behavior.** The Buffett/ELO-style campaign becomes one reusable strategy, not the only way the builder works.
2. **Ticketed concerts default to `Buy Tickets`.** For paid concerts, the CTA is part of the event positioning and should not silently drift to a vague button.
3. **Video is a primary creative asset.** The default tribute/concert strategy should treat video as full-duration creative with optional final-week pressure, not only as a last-minute add-on.
4. **Budget pacing is phase-based.** The builder should translate one total budget into date-based windows and rebalance when early windows have already passed.
5. **Meta automation choices must be intentional.** Advantage+ creative policy, multi-advertiser ads, placement behavior, and CTA assumptions should be surfaced in the builder and copy pack.

## Implemented scope in 0.1.62

### 1. Strategy template selector

Added a **Campaign strategy** selector in Step B.

Built-in v1 strategies:

| Strategy | Default preset | CTA | Optimization | Meta creative policy | Multi-advertiser ads |
|---|---|---|---|---|---|
| Ticketed Concert — Video-Led Local Push | Video-Led Ticket Push | Buy Tickets locked | Landing page views | Conservative review | Off |
| Standard Ticket Push | Promo Bundle 30/14/7 | Buy Tickets locked | Landing page views | Conservative review | Off |
| Last-Minute Push | Simple 7 day | Buy Tickets locked | Link clicks | Off / preserve creative | Off |
| Low-Budget Local Reminder | Flat run | Buy Tickets locked | Link clicks | Off / preserve creative | Off |
| Custom / manual controls | Operator-selected | Operator-selected | Operator-selected | Operator-selected | Operator-selected |

Selecting a strategy applies safe defaults while still allowing manual adjustment afterward.

### 2. Video-Led Ticket Push pacing preset

Added `video_tribute_push` as a first-class preset.

Default allocation:

| Tier key | Label | Window | Share |
|---|---|---|---:|
| `v30` | Early Video/Main Awareness | 30–15 days out | 20% |
| `v14` | Mid-Campaign Momentum | 14–8 days out | 30% |
| `v7` | Final Week Video Push | 7–3/2 days out | 30% |
| `v48` | Last 48 Hours | Final 48 hours | 20% |

The existing tier normalization skips expired windows and redistributes the remaining budget across active tiers.

### 3. CTA lock for ticketed concerts

Added a Step C **Lock CTA to Buy Tickets for ticketed concerts** control.

Behavior:

- When enabled, the UI forces the CTA field to `BUY_TICKETS`.
- Save/build normalization also forces `BUY_TICKETS` server-side.
- Saved builds/templates preserve the CTA lock state.
- Copy pack now shows whether CTA lock is on or off.
- Meta API CTA mapping no longer downgrades `BUY_TICKETS` to `LEARN_MORE` for offsite URLs.
- `GET_TICKETS` is treated as an operator-facing alias and maps to `BUY_TICKETS` for Meta creation.

### 4. Meta intent controls

Added advanced Step C controls:

- **Advantage+ creative policy**
  - Off / preserve creative
  - Conservative review
  - Allow Meta-optimized
- **Allow multi-advertiser ads**
  - Default off for ticketed concert strategies

These values are stored in build payloads, template payloads, placement payload metadata, and copy-pack output so the operator can review the intended settings before Meta publish/export.

### 5. Server/client preset parity

Aligned the default Promo Bundle 30/14/7 fallback to `30 / 30 / 40` server-side, matching the builder preview defaults.

### 6. Template persistence

Reusable builder templates now preserve:

- Strategy template
- CTA lock
- Creative automation policy
- Multi-advertiser ad preference

### 7. Build metadata and output

Copy pack output now includes:

- Strategy
- CTA lock status
- Advantage+ creative policy
- Multi-advertiser ad status
- Budget schedule using the selected pacing preset
- Audience summary noting manual placement and CTA-lock context when relevant

## Deliberately not completed in this pass

These are intentionally left as follow-up work so this patch remains low-risk:

1. **True Meta-side tiered campaign creation remains export-only for non-flat presets.** The existing Meta API create path still requires `flat_run` for direct creation.
2. **Meta API enforcement of Advantage+ creative and multi-advertiser settings is not guaranteed yet.** This pass records and displays the intended policy so the operator can verify it in Ads Manager.
3. **Purchase optimization is not made the default yet.** Pixel/CAPI signals look promising, but strategy templates keep `landing_page_views` or `link_clicks` until purchase attribution and value reporting are fully proven.
4. **Strategy templates are built-in JavaScript presets for v1.** A later version can move them into cloneable database records with custom user-defined strategy templates.

## Future follow-up candidates

- Clone a successful past campaign strategy into a new event.
- Convert strategy templates into saved/cloneable records.
- Add full pre-publish validation for CTA, placements, creative automation, Instagram identity, Pixel readiness, and URL tracking.
- Add direct Meta API support for multi-phase/tiered campaign creation.
- Add a Pixel/Dataset health card and purchase-readiness mode.
- Add strategy-specific creative requirements: square, vertical, side-column, video, thumbnail.
