# TEST PLAN — VMS Meta Ads Builder 0.1.53

## Goal
Confirm the Step C creative/media UI is clearer and that hidden variant media controls now behave correctly.

## Environment
- WordPress admin
- VMS Meta Ads Builder 0.1.53
- Existing event plan with creative fields available

## Tests

### 1) Shared media reads naturally
1. Open Meta Ads Builder.
2. Go to Step C.
3. Confirm **Default Shared Media** appears before the variant cards.
4. Confirm the helper copy explains that shared variants use those assets.

**Pass:** The shared-media section is visually introduced before the per-variant overrides.

### 2) Hidden controls stay hidden for shared mode
1. Leave Variant 1 on **Use default shared media**.
2. Leave Variant 2 or 3 on **Use default shared media**.
3. Confirm no custom image/video picker buttons are visible inside those cards.

**Pass:** Cards in shared mode show only the media-source note, not the hidden pickers.

### 3) Image override only shows image controls
1. Change Variant 2 media source to **Use a different single image**.
2. Confirm the image picker appears.
3. Confirm the video picker stays hidden.
4. Confirm the helper note updates to say the variant overrides shared media with its own image.

**Pass:** Only the image UI is shown.

### 4) Video override only shows video controls
1. Change Variant 3 media source to **Use a video**.
2. Confirm the video picker appears.
3. Confirm the image picker stays hidden.
4. Confirm the helper note updates to say the variant overrides shared media with its own video.

**Pass:** Only the video UI is shown.

### 5) Save + reload behavior
1. Save a draft with:
   - shared square + vertical images
   - Variant 2 = image override
   - Variant 3 = video override
2. Reload the builder.
3. Confirm:
   - shared media previews reload
   - each variant retains its selected media mode
   - the correct helper note and picker visibility return

**Pass:** UI state survives reload correctly.

### 6) Meta creation sanity check
1. Create in Meta (paused) using:
   - Variant 1 shared
   - Variant 2 image override
   - Variant 3 video override
2. Confirm no Step C UI regressions block creation.

**Pass:** Build still creates normally.

## Regression notes
- Reconfirm CTA still saves/loads.
- Reconfirm template apply does not reintroduce stale shared images from a prior event.
- Reconfirm Variant 1 can still use shared media while Variant 2/3 override it.
