# 🚨 Codex Test Plan — VMS Meta Ads Builder 0.1.62

Codex role: **testing, verification, troubleshooting, and edge-case validation only.** Do not rewrite the implementation unless a specific defect is found and a separate patch request is made.

## Build under test

- Plugin: VMS Meta Ads Builder
- Version: 0.1.62
- Primary files changed:
  - `vms-meta-ads.php`
  - `module.json`
  - `vms-build.txt`
  - `includes/admin/screens/ads-builder.php`
  - `assets/ads-builder.js`
  - `includes/services-ad-builds.php`
  - `includes/services-templates.php`
  - `includes/meta-api/client.php`
  - `includes/admin/screens/settings.php`
  - `includes/utils.php`

## 1. Version and activation smoke

- Confirm plugin header shows `0.1.62`.
- Confirm `VMS_MA_VERSION` is `0.1.62`.
- Confirm `module.json` is `0.1.62`.
- Confirm `vms-build.txt` is `0.1.62`.
- Activate plugin on staging/local.
- Load the Ads Builder screen with no PHP fatal errors.
- Browser console should not show JavaScript syntax/reference errors.

## 2. Strategy template UI

Open Ads Builder and verify Step B contains **Campaign strategy**.

Test each built-in strategy:

| Strategy | Expected preset | Expected CTA | CTA lock | Optimization | Creative policy | Multi-advertiser |
|---|---|---|---|---|---|---|
| Ticketed Concert — Video-Led Local Push | Video-Led Ticket Push | Buy Tickets | On | Landing page views | Conservative review | Off |
| Standard Ticket Push | Promo Bundle 30/14/7 | Buy Tickets | On | Landing page views | Conservative review | Off |
| Last-Minute Push | Simple 7 day | Buy Tickets | On | Link clicks | Off / preserve creative | Off |
| Low-Budget Local Reminder | Flat run | Buy Tickets | On | Link clicks | Off / preserve creative | Off |
| Custom / manual controls | No auto-overwrite | Manual | Manual | Manual | Manual | Manual |

Verify the strategy status text updates when switching templates.

## 3. CTA lock behavior

- With CTA lock enabled, change CTA to `Learn More`.
- Expected: the UI immediately returns the CTA to `Buy Tickets`.
- Save draft.
- Reload the draft.
- Expected: CTA remains `Buy Tickets`, CTA lock remains enabled.
- Turn CTA lock off.
- Change CTA to `Learn More`.
- Save draft and reload.
- Expected: CTA can remain `Learn More` only when lock is off.

## 4. Server-side CTA enforcement

Using a saved build or REST/ajax save flow:

- Submit `cta_type=LEARN_MORE` and `force_buy_tickets_cta=1`.
- Expected normalized build copy payload stores `cta_type=BUY_TICKETS` and `cta_suggestion=BUY_TICKETS`.
- Submit `cta_type=GET_TICKETS`.
- Expected Meta preflight/create mapping resolves to `BUY_TICKETS`.
- Confirm offsite URLs are not downgraded to `LEARN_MORE` solely because they are non-Facebook URLs.

## 5. Budget pacing preview

Use an event with a known future date and total budget `$100`.

### Event roughly 30+ days away

Expected Video-Led Ticket Push tiers:

- Early Video/Main Awareness: about `$20`
- Mid-Campaign Momentum: about `$30`
- Final Week Video Push: about `$30`
- Last 48 Hours: about `$20`

### Event roughly 14–18 days away

Expected: early tier may be absent or shortened depending on current date; remaining budget should rebalance across active tiers and total exactly `$100`.

### Event roughly 6 days away

Expected: early/mid tiers skipped; final-week and last-48-hour tiers receive the remaining budget.

### Event roughly 2 days away

Expected: last-48-hour/last-minute tier carries the remaining active budget.

Verify total tier allocation always equals total budget and no tier has a zero/negative budget.

## 6. Saved builder template persistence

- Configure Ticketed Concert strategy.
- Save as a reusable builder template.
- Switch fields to other values.
- Apply the saved template.
- Expected restored fields:
  - Strategy template
  - Video-Led Ticket Push preset
  - Buy Tickets CTA
  - CTA lock on
  - Creative automation policy
  - Multi-advertiser ads off

## 7. Copy pack output

Export/copy the pack and verify it includes:

- Strategy label
- CTA lock status
- Advantage+ creative policy
- Multi-advertiser ad status
- Budget schedule with video-led tier names
- Audience summary including CTA locked to Buy Tickets when enabled

## 8. Regression checks

- Existing flat run builds still save/export as before.
- Existing Promo Bundle 30/14/7 builds still save/export as before.
- Manual Dates preset still respects manual start/end.
- Existing Meta-linked builds still load.
- Existing analytics panel still loads and refreshes.
- Existing image/media variant controls still work.
- Existing template list/save/apply/delete still works.

## 9. Known limitation verification

Attempt direct Meta creation with `Video-Led Ticket Push`.

Expected for now:

- Non-flat/tiered presets may still be export-only.
- The plugin should show the existing friendly limitation message rather than failing silently.

## Pass/fail report format

Report:

1. Build/version checked.
2. Browser console status.
3. PHP error log status.
4. Strategy UI results.
5. CTA lock results.
6. Budget pacing matrix results.
7. Template save/apply results.
8. Copy pack result.
9. Any regressions or defects with exact steps/screenshots.
