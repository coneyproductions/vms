# VMS Meta Ads Builder — Test Plan 0.1.52

## Goal
Verify that templates are less intrusive on open and that one Event Plan can now hold multiple separately tracked linked builds without the builder silently snapping back to the latest one.

## Install / setup
1. Install `0.1.52`.
2. Confirm the plugin reports `0.1.52` in WordPress.
3. Use one Event Plan that already has at least one saved Meta ad draft/build.
4. If possible, also use an Event Plan with no prior builds yet.

## Test A — templates panel is collapsed and less intrusive
1. Open the Meta Ads Builder fresh.
2. Confirm the top `Templates + Ad Spec` area is collapsed by default.
3. Confirm Step A is the first main thing you naturally see.
4. Expand the Templates area manually.
5. Confirm template load / delete / refresh and spec tools still work.

### Expected
- Templates are no longer the giant first thing in your face.
- You can still expand and use them normally.

## Test B — linked build picker loads existing builds for an Event Plan
1. Select an Event Plan that already has a saved draft/build.
2. Confirm a `Linked build` selector appears under Step A.
3. Confirm the most recent build autoloads.
4. Change the selector to a different saved build if more than one exists.
5. Confirm the builder fields update to that selected build.
6. Click `Refresh Status`.

### Expected
- The selected build loads correctly.
- Refresh Status follows the selected build, not just the newest one.

## Test C — start a second linked build for the same Event Plan
1. Select an Event Plan with an existing saved build.
2. Click `Start New Linked Build`.
3. Confirm the current form values stay on screen.
4. Change something obvious, like radius, age range, or budget.
5. Click `Save Draft`.
6. Confirm the `Linked build` selector now shows a new additional build for that same Event Plan.
7. Switch between the old build and the new build.

### Expected
- The old build still exists.
- The new build saves separately.
- Switching between them reloads the correct settings each time.

## Test D — build-specific Meta actions
1. Pick one saved build that is already linked to Meta.
2. Run `Refresh Status` and confirm it behaves normally.
3. Switch to a different linked build for the same Event Plan.
4. Run `Refresh Status` again.
5. If safe in your environment, test `Pause All` or `Go Live` only on the intended selected build.

### Expected
- The builder actions follow the selected build.
- They do not silently jump to whichever build is newest.

## Test E — no-build Event Plan still works
1. Select an Event Plan with no saved builds yet.
2. Confirm the linked build area explains that no saved builds exist yet.
3. Fill the form and click `Save Draft`.
4. Confirm the first linked build appears in the selector.

### Expected
- First-save behavior still works normally.
- The linked build selector begins tracking the new build immediately.
