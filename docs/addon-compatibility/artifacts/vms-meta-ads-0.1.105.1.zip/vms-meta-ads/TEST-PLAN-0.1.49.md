# VMS Meta Ads Builder — Test Plan 0.1.49

## Goal
Verify linked-ad updates recover when Meta rejects a dynamic creative inside a non-dynamic ad set.

## Install
1. Install `0.1.49`.
2. Confirm the plugin updates in place inside the canonical `vms-meta-ads` folder.

## Test 1 — Reproduce the prior failure path
1. Open an Event Plan with an already linked Meta campaign/ad set/ad.
2. Change audience, budget, and creative images.
3. Click **Save Draft**.
4. Click **Update Existing Meta Ad**.
5. Expected: the update does **not** stop on `Cannot Create Dynamic Creative ad In Non-Dynamic Creative Ad Set`.
6. Expected: the builder either uses the richer compatible creative path or falls back to a standard single-image creative and still completes the update.

## Test 2 — Verify builder warnings
1. After the update finishes, review the on-screen notices/status area.
2. Expected: if the fallback was needed, the builder warns that Meta required a standard single-image creative on this ad set.

## Test 3 — Ads Manager verification
1. Open Ads Manager from the builder.
2. Confirm the linked campaign/ad set/ad still exist.
3. Confirm the audience change landed.
4. Confirm the budget state matches the builder rules.
5. Confirm the ad is using the updated compatible creative.

## Test 4 — No blank-screen / no recreate confusion
1. Trigger another update on the same linked ad.
2. Expected: the builder does not blank-screen and does not require `Create in Meta (PAUSED)` unless you intentionally reset the link.

## Notes
- 0.1.49 keeps the 0.1.48 creative-payload fallback.
- 0.1.49 adds a new ad-create/ad-update fallback for Meta error subcode `1885998`.
- If the fallback is used, Meta may end up with a standard single-image creative rather than the richer multi-image dynamic creative on that specific ad set.