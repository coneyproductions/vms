# VMS Meta Ads Builder 0.1.82 — Meta Enhancements Fallback + Diagnostics Download

## Purpose

Patch `0.1.82` fixes a live Meta API regression found during the `0.1.81` runtime test. Meta rejected creative creation with:

> Including standard enhancements field in creative has been deprecated. Please choose to set individual features instead.

The previous fallback path retried some creative payloads without placement rules but still re-added the deprecated `standard_enhancements` feature opt-out, causing creation to fail before the campaign could be reviewed in Ads Manager.

## Changes

### 1. Creative creation fallback hardening

- Adds a shared creative-post helper that tries the requested creative payload with the current feature opt-outs first.
- If Meta rejects the feature opt-out/degrees-of-freedom payload, it retries with the reduced feature payload where applicable.
- If Meta still rejects those fields, it retries the same creative payload without `degrees_of_freedom_spec` / feature opt-out fields.
- Applies the same fallback behavior to:
  - primary asset-feed creative creation
  - asset-feed-without-rules fallback
  - single-image fallback
  - video creative creation

### 2. Meta error detection

- Expands feature-field rejection detection to catch Meta's new wording:
  - `standard enhancements`
  - `enhancements field in creative has been deprecated`
  - `choose to set individual features`

### 3. Diagnostics usability

- Adds **Download Last Failure** and **Download Bundle** buttons to the diagnostics panel.
- Keeps copy buttons, but adds a fallback copy method when `navigator.clipboard.writeText()` is blocked by browser permissions policy.
- Adds per-row Download links for recent attempts.

### 4. QA gate polish

- Enlarges Manual Meta QA Gate checkboxes and improves label alignment.

### 5. Preset error clarity

- Updates the tiered/export-only create error to explain that the saved draft still has an export-only schedule and must be switched to Flat run and saved before creating in Meta.

## Version markers

- Plugin header: `0.1.82`
- `VMS_MA_VERSION`: `0.1.82`
- `module.json`: `0.1.82`
- `vms-build.txt`: `0.1.82`

## Notes

This patch does not remove the Manual Meta QA Gate. If Meta requires MAB to omit the deprecated feature opt-out fields in order to create the ad, the operator must still verify in Ads Manager that Website Highlights, Advantage+ creative enhancements, and Multi-advertiser ads are off before Go Live.
