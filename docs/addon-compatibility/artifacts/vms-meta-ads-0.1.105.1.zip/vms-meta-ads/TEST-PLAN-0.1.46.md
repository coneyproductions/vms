# VMS Meta Ads Builder — Test Plan 0.1.46

## Goal
Fix Update Existing Meta Ad for already-started ad sets so it stops sending immutable `start_time` values and avoids resending unchanged lifetime budgets that can trigger Meta rejection on running ads.

## What changed
- Running or already-started ad sets now omit `start_time` from the Update Existing payload.
- Update Existing no longer resends unchanged lifetime budgets on already-started ad sets.
- If the saved draft budget differs from a running ad set budget, Update Existing leaves budget alone and warns the operator to use **Sync Budget to Meta**.
- Step-level error wording is now generic `failed` instead of awkward `create failed` text during update actions.

## Primary smoke test
1. Install `0.1.46`.
2. Open a linked Event Plan whose Meta ad set has already started.
3. Change non-budget content such as one of the following:
   - primary text
   - headline
   - description
   - audience targeting
4. Click **Save Draft**.
5. Click **Update Existing Meta Ad**.
6. Confirm all of the following:
   - the button enters a busy state
   - the inline Step G message changes to an updating message
   - the update completes without a Meta `start_time cannot be edited` failure
   - the update completes without a Meta minimum-budget failure when the budget was already in sync
   - diagnostics show a real `update_adset` / update request and not just status fetches

## Budget separation test
1. On an already-started linked ad set, change only the total budget.
2. Click **Save Draft**.
3. Click **Update Existing Meta Ad**.
4. Confirm the builder shows a warning that budget was left unchanged on the running ad set and should be pushed with **Sync Budget to Meta**.
5. Confirm the budget sync row shows draft/meta out of sync after Update Existing.
6. Click **Sync Budget to Meta**.
7. Confirm the sync succeeds and the budget row returns to in sync.

## Pre-start ad set test
1. Use a linked ad set that has not started yet, or create a future-start test case if available.
2. Change schedule and/or budget.
3. Save Draft.
4. Click **Update Existing Meta Ad**.
5. Confirm pre-start ad sets can still receive schedule start and budget fields through the general update flow.

## Regression checks
1. Refresh Status still works.
2. Pause All still works.
3. Reset Meta Link still works.
4. Sync Budget to Meta still works independently of Update Existing.
5. Existing 0.1.44 fixes still hold:
   - Age Min can be changed normally
   - too-low budget windows still warn/block Meta-facing actions

🚨 Focus checkpoint: on a live or already-started ad set, Update Existing must stop failing on immutable `start_time` and unchanged budget payloads.
