# VMS Meta Ads Builder 0.1.86 Test Plan

## A. Package/version
1. Confirm one canonical top-level folder: `vms-meta-ads/`.
2. Confirm plugin version is `0.1.86`.
3. Confirm `VMS_MA_VERSION` is `0.1.86`.
4. Confirm `module.json` reports `0.1.86`.
5. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.86`.

## B. Static validation
```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/admin/api-diagnostics.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.86-outer-towns-city-lookup-fallback.zip
```

## C. City/state regression
In Step D Outer Towns locations, test:

```text
Athens, TX | 15
Athens, Texas | 15
Henderson, TX | 15
Jacksonville, TX | 15
```

Expected:
- Create paused no longer fails because the resolver submitted the full `City, ST` text as the Meta query.
- The diagnostic entry for `targeting_city_search` should show `q=Athens` rather than `q=Athens, TX`.
- The resolved Outer Towns ad set does not fall back to Whitehouse/Tyler/venue radius.
- Outer Towns age still inherits Step D.

## D. Fallback regression
If the global `/search` endpoint fails, confirm the plugin attempts `act_<ad_account_id>/targetingsearch` before failing the row.

## E. Existing regression checks
- Advantage+ creative remains off.
- Multi-advertiser ads remain off or are caught by manual QA.
- Manual QA Gate still works.
- Outer Towns listed-only mode still requires explicit locations.
- UTMs remain on every ad URL.
