# VMS Meta Ads Builder 0.1.67 — Timestamp + Adopted Action State Hardening

## Purpose

Harden the Meta Ads Builder after the 0.1.66 adoption-persistence pass. Codex verified that adoption now persists, but found three follow-up issues:

1. New/updated builds could return `0000-00-00 00:00:00` timestamps.
2. Build ordering could become unreliable when timestamps are zero.
3. Adopted/live Meta builds could still show contradictory action states, such as **Create in Meta (PAUSED)** being enabled while **Update Existing Meta Ad** implied the ad had not been created yet.

This pass focuses on those safety and clarity issues.

## Changes

### 1. Fixed build save timestamp formats

The build save row format list now includes a format for `updated_at`. This keeps new build inserts and updates from losing the timestamp value or storing a zero-date placeholder.

### 2. Added zero-timestamp repair

`VMS_Meta_Ads_Builds_Service` now performs a lightweight idempotent repair when build tables are confirmed available:

- Repairs zero `created_at` values from valid `updated_at` when possible.
- Repairs zero `updated_at` values from valid `created_at` when possible.
- Falls back to the current UTC timestamp only when both are missing/zero.
- Applies the same repair to tier rows.

This is intentionally conservative and does not affect Meta state.

### 3. Hardened build ordering

Build listing now orders by valid `created_at` first, then `created_at DESC`, then `id DESC`. This keeps legacy zero-date rows from winning the top of the dropdown and gives a stable fallback if timestamps are invalid.

### 4. Improved adopted/live Meta action state

The builder now detects when the selected build already has Meta IDs, including adopted existing Meta campaigns. For those builds:

- **Create in Meta (PAUSED)** is disabled because the build already points to Meta objects.
- **Update Existing Meta Ad** no longer says “Create in Meta first” when the build already has saved Meta IDs.
- The action guidance says the build is linked to an existing Meta campaign and drift should be reviewed before pushing changes.
- Variant summary text distinguishes between “not created yet” and “linked IDs saved; refresh status to load variant statuses.”

### 5. Guided tour auto-launch suppression

Guided tours remain available from the **Start tour** button, but default auto-launch is now off. This prevents the guided-tour overlay from intercepting admin/testing clicks unless the operator intentionally enables auto tour or opens the page with `tour=1`.

## Files changed

- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `includes/services-ad-builds.php`
- `includes/utils.php`
- `assets/ads-builder.js`
- `assets/tours.js`
- `BUILD-SPEC-0.1.67-timestamp-action-hardening.md`
- `TEST-PLAN-0.1.67.md`

## Non-goals

This pass does not add new Meta API health checks, preflight validation-only calls, safe mode, or access-tier monitoring. Those remain a separate planned safety layer.
