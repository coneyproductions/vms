# VMS Meta Ads Builder 0.1.64 — Meta Reconciliation + Drift Detection

## Goal

Make the Ads Builder safer when a campaign exists or has been edited in Meta Ads Manager outside the builder.

The builder should no longer assume its saved build is the only source of truth. It should help the operator discover likely Meta campaigns, review them, adopt/link the correct one, and see differences between the saved build and live Meta settings.

## Scope implemented

### 1. Meta reconciliation panel

Added a Step A panel under Linked Build:

- Find Existing Meta Campaigns
- Human-readable explanation that this is for ads edited or created directly in Meta Ads Manager
- Candidate results area

### 2. Discovery endpoint

Added REST endpoint:

```http
GET /wp-json/vms-ma/v1/meta-discovery?event_plan_id={id}&build_id={optional_id}
```

The endpoint:

- Loads Event Plan context
- Uses the saved Meta connection settings
- Searches recent Meta campaigns in the configured ad account
- Scores likely matches using Event Plan title, meaningful tokens, event date strings, campaign/ad set/ad names, and destination URLs where available
- Fetches likely campaign ad sets and ads
- Returns reviewable candidates only; no Meta objects are created, paused, or published

### 3. Candidate cards

Each candidate card shows:

- Match confidence and score
- Campaign name/status/ID
- Ad set name/status
- Audience summary where Meta exposes it
- Budget summary
- Number of ads found
- Drift summary when a saved build is selected
- Adopt / Link button

### 4. Adopt / Link action

Added REST action:

```http
POST /wp-json/vms-ma/v1/ad-builds/{build_id}/meta-adopt
```

The action:

- Requires nonce/capability checks
- Requires explicit confirmation in payload
- Stores campaign/ad set/ad IDs on the selected saved build
- Updates Event Plan Meta Ads status metadata
- Refreshes campaign/ad set/ad status
- Logs an `adopt_existing_meta_campaign` event
- Does not create, publish, pause, or edit live Meta objects

### 5. Drift detection

The Meta Status refresh now includes a drift report comparing selected saved build values to the live Meta ad set when readable:

- Audience age range
- Radius
- Budget
- Optimization goal

The builder displays the drift result under the Meta Status card.

## Intentional limitations

- This pass does not overwrite Meta values from the builder.
- This pass does not create a full two-way sync engine.
- Discovery is best-effort because Meta naming, URL exposure, and campaign history vary.
- Adoption links IDs only. The operator still decides whether to keep Meta values, update from builder, or create a new build.
- Deep creative/CTA drift is not fully compared yet because creative payloads can vary by ad format and placement.

## Safety rules

- Discovery is read-only.
- Adoption requires an existing saved build.
- Adoption requires explicit confirmation.
- Adoption does not publish anything.
- The builder should treat active Meta campaigns as the source of truth until the operator intentionally updates them.
