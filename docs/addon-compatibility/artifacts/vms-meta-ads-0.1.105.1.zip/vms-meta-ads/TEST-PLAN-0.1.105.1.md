# VMS Meta Ads Builder 0.1.105.1 Test Plan

- Load with public Backstage Venue Manager 1.2.0 and no active historical VMS plugin.
- Confirm `meta_ads_builder` registers and is enabled through the public module registry.
- Confirm builder, promote, performance, logs, and settings screens plus REST, tour, and cron hooks register.
- Confirm the legacy core-unavailable/reactivation notice is absent.
- Confirm Meta settings, build/template/tier/audit row counts, and campaign behavior remain unchanged.
