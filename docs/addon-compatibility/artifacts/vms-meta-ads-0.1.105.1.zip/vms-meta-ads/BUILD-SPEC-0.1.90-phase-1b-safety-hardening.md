# MAB 0.1.90 Build Spec — Phase 1B Safety Hardening

## Goal

Harden Meta Ads Builder so no privileged admin/runtime behavior can load accidentally, while preserving a no-spend local dry-run path for payload inspection and operator QA.

## Changes

- Add a fail-closed MAB bootstrap gate:
  - defer module boot until the VMS module system is loaded
  - require `meta_ads_builder` to be both registered and enabled before privileged/admin functionality loads
  - keep the plugin locked when VMS core is missing, the premium list is empty, or the module is explicitly disabled
- Add a local-only `Preview Meta Dry Run` flow:
  - save the current draft first
  - build the intended campaign / ad set / ad creative / ad request structure
  - log the preview to `wp_vms_api_attempts`
  - make zero calls to `graph.facebook.com`
- Change clean-room default age targeting from `45-65` to the current `30-65+` baseline while keeping per-campaign overrides intact.
- Add explicit dry-run UI copy making it clear that dry run does not contact Meta and does not spend money.
- Contain empty Meta status lookups so a builder page with no created Meta objects returns a safe empty-state payload instead of surfacing a browser console error.

## Companion requirement

- This package expects the companion VMS core package `0.2.24.711` or newer.
- Reason: the fail-closed gate now relies on VMS core treating unregistered premium modules as disabled and exposing an explicit registration check.

## Non-goals

- Do not reconnect Meta.
- Do not enable live Meta create/publish.
- Do not create or publish real campaigns.
- Do not change production defaults beyond the gate/copy/preview hardening in this package.
