# BUILD SPEC — MAB 0.1.76 Sales Goal UI Sync Hotfix

## Summary
0.1.75 added Sales / Ticket Purchases and forced the optimization field to `purchase_conversions` when Sales was selected. The sync routine used the shared `setField()` helper, which dispatches input/change events. Because the sync routine itself runs from global input/change handlers, this could recurse while the Builder page was rendering and cause the browser to report the page as unresponsive.

## Fix
When Sales is selected, `syncGoalOptimizationVisibility()` now sets the optimization field value directly without dispatching another input/change event.

## Non-goals
- No change to Meta create/update behavior.
- No live Meta asset mutations.
- No schema changes.

## Validation
See `TEST-PLAN-0.1.76-hotfix.md`.
