# VMS Meta Ads Builder — Test Plan 0.1.45

## Scope
Fix the inert **Update Existing Meta Ad** button so clicking it actually triggers the existing update flow.

## What changed
- Wired the Step G **Update Existing Meta Ad** button to the existing `updateExistingMetaAd()` front-end action.
- No API or Meta update logic changed in this pass; this is a front-end binding repair so the existing route can finally fire.

## Manual test
1. Open an Event Plan that already has linked Meta IDs.
2. Change something safe like headline, primary text, audience radius, or age range.
3. Confirm **Update Existing Meta Ad** stays disabled until **Save Draft** is clicked.
4. Click **Save Draft**.
5. Click **Update Existing Meta Ad**.
6. Confirm the button shows a busy state and the inline Step G status changes from idle text to an updating message.
7. Confirm a success or failure notice appears.
8. Open **Meta API Diagnostics** and confirm a fresh `meta_update` / update-related attempt is recorded instead of only status fetches.
9. Click **Refresh Status** and verify the linked ad still reports correctly.

🚨 Test this build before production use: the key checkpoint is that clicking **Update Existing Meta Ad** must now create a real update request and visible UI activity.
