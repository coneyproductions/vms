# TEST PLAN 0.1.96

## Static
- `php -l` on changed PHP files
- `node --check` on changed JS files

## Unit-like / classification checks
- campaign `PAUSED` + ad set `PAUSED` + ad `PENDING_REVIEW` => local/event status becomes `paused_reviewing`, not `error`
- all `PAUSED` => local/event status `paused`
- any `ACTIVE` => local/event status `live`
- `DISAPPROVED` / `REJECTED` / `WITH_ISSUES` => local/event status `error`
- unknown or unreadable status rows => local/event status `error`
- `meta-create` without `confirm_create_paused` => `confirmation_required`
- multi-window direct create still blocked

## Local no-spend smoke
- locked state still returns `403`
- builder loads with direct-create-safe defaults:
  - strategy `direct_create_safe_ticket_push`
  - preset `simple_14_day`
  - manual FB/IG placements
  - age `30-65`
- dry run remains local-only
- status panel remains read-only
- create confirmation gates still hold
- zero Meta mutation calls
- no JS console errors or page errors

## Staging no-spend smoke
- Deploy `vms-meta-ads 0.1.96` only
- Keep VMS core `0.2.24.711`
- Keep `enable_api_create=0`
- Keep `vms_ma_phase=1`
- Dry run only
- Status panel only
- No Go Live
- No activation
- Zero Meta mutation calls
- No new MAB fatal
