# MAB 0.1.89 Test Plan — Budget Allocation Preview

## A. Package/version

1. Confirm the release ZIP contains one canonical top-level folder: `vms-meta-ads/`.
2. Confirm plugin header version is `0.1.89`.
3. Confirm `VMS_MA_VERSION` is `0.1.89`.
4. Confirm `module.json` is `0.1.89`.
5. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.89`.

## B. Static validation

Run from the unpacked plugin directory:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/admin/api-diagnostics.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.89-budget-allocation-preview.zip
```

## C. Step E budget UI

1. Select Clean-Room Concert Campaign - Full Push v2.
2. Use Flat run and a multi-week schedule.
3. Enter a low total budget such as `$100`.
4. Confirm the Total budget field shows a minimum-total-budget note.
5. Confirm Step E shows a Budget allocation preview table.
6. Confirm each recipe ad set shows allocation percentage, budget, avg/day, status, and note.
7. Confirm at least the under-funded ad set shows `Below minimum` when avg/day is below `$1.00`.
8. Click the `Increase budget to $X` helper and confirm Total budget updates to the calculated minimum.

## D. Live recalculation

1. Change total budget and confirm the minimum note/table update immediately.
2. Change schedule/run window and confirm the minimum note/table update immediately.
3. Enable Right Column support and confirm the split and minimum recalculates.
4. Switch to a non-clean-room strategy and confirm the recipe allocation preview hides.

## E. Regression

1. Existing tier schedule preview still renders.
2. Existing budget floor warning still blocks Create/Go Live if an ad set falls below `$1/day`.
3. Recipe preview in Step B still renders.
4. Create in Meta remains paused-first.
5. Manual QA Gate still blocks Go Live until checked.
6. Outer Towns listed-only still does not fall back to venue radius.
