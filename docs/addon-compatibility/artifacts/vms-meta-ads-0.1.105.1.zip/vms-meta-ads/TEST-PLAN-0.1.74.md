# VMS Meta Ads Builder 0.1.74 Test Plan — Placement-Aware Recipes v2

## Scope

Validate the revised Clean-Room Full Push v2 recipe, creative format guardrails, optional Right Column support test, recipe preview table, and post-create Meta status visibility.

Codex should test on staging only unless explicitly instructed otherwise.

## Preconditions

- Install `vms-meta-ads` build `0.1.74` into the canonical `vms-meta-ads/` plugin folder.
- Confirm `vms-build.txt` reports `Version: 0.1.74`.
- Use a future Event Plan with a valid destination URL, event date, image/poster, and budget.
- Do not publish live ads unless the user explicitly asks.

## Test 1 — Version/package integrity

1. Inspect `vms-meta-ads.php`.
2. Inspect `module.json`.
3. Inspect `vms-build.txt`.
4. Load the Builder admin page and inspect asset versions if visible in source.

Expected:

- All version markers show `0.1.74`.
- Plugin installs into `vms-meta-ads/`, not a parallel folder.
- No PHP fatal errors.

## Test 2 — Clean-Room Full Push v2 default recipe

1. Open MAB for a future Event Plan.
2. Select `Clean-Room Concert Campaign - Full Push` or the updated v2 label.
3. Leave optional Right Column support unchecked.
4. Enter a valid budget and schedule.
5. Save Draft.

Expected:

- Saved build uses the v2 recipe key/version.
- Preview table shows three default ad sets:
  - Core Radius - Feed/Reels
  - Vertical Video - Reels/Stories
  - Outer Towns - Ages 50+
- No dedicated Right Column ad set is shown by default.
- Budget percentages total 100%.
- No Right Column warning appears unless the optional test is enabled.

## Test 3 — Optional Right Column support test disabled by default

1. Reload the saved v2 build.
2. Confirm the optional Right Column support checkbox is unchecked.
3. Review copy pack / preview output.

Expected:

- Right Column support displays as `Off` or not included.
- Create preview does not include Right Column ad set.
- Checklist does not require Right Column.

## Test 4 — Enable optional Right Column support with valid creative/budget

1. Check `Include optional Facebook Right Column support test`.
2. Provide a square/static image.
3. Use a budget/run window large enough for each ad set to satisfy Meta minimums.
4. Save Draft.

Expected:

- Preview table now shows four ad sets.
- Right Column ad set receives approximately 5% of budget.
- Core Radius budget is reduced accordingly.
- Right Column row says `Ready`.
- Copy clearly labels it as a support test, not a primary strategy.

## Test 5 — Enable optional Right Column with insufficient budget

1. Keep Right Column support enabled.
2. Lower budget or lengthen run window so the Right Column slice likely falls below Meta minimums.
3. Attempt Save Draft and/or Create in Meta.

Expected:

- MAB warns clearly that the Right Column slice is too small.
- MAB either blocks only the Right Column support test and redistributes budget, or blocks Create in Meta with friendly guidance.
- No vague Meta/API error is shown to the operator.

## Test 6 — Vertical video missing warning

1. Select Clean-Room v2.
2. Ensure Reels/Stories placements are included.
3. Provide only a square/static image or non-video placeholder.
4. Save Draft.

Expected:

- Creative formats card shows `Missing vertical video` or equivalent.
- Vertical Video ad set row is warning/needs review.
- Warning explains that Meta may crop creative in Reels/Stories.
- The warning is understandable to a non-technical operator.

## Test 7 — Vertical video marked ready

1. Add/select a vertical video or mark a Meta-direct video placeholder as vertical/9:16.
2. Save Draft.
3. Reload the build.

Expected:

- Creative formats card persists the vertical video/placeholder status.
- Vertical Video row changes to Ready or Review in Meta before go-live.
- Reload does not lose the selected creative format state.

## Test 8 — Create in Meta remains paused

Only run if staging Meta credentials are safe and the user has approved test creation.

1. Use a valid Clean-Room v2 build.
2. Click Create in Meta (PAUSED).
3. Do not click Go Live.
4. Refresh status.

Expected:

- One paused campaign is created.
- Three ad sets are created when Right Column is off.
- Four ad sets are created when Right Column is on and valid.
- Ads are created paused.
- Created IDs persist on reload.
- Status panel shows campaign/ad set/ad level status.

## Test 9 — Post-create status/review visibility

1. Use an existing created paused build.
2. Click Refresh Status.
3. Compare status panel to Meta Ads Manager.

Expected:

- MAB distinguishes at least:
  - Created but paused
  - Active/live
  - Pending/in review where available
  - Rejected/disapproved where available
  - Unknown/error
- Object IDs remain visible but secondary.
- The operator can tell whether the campaign is actually live or merely created/paused.

## Test 10 — Older 0.1.73 builds still load

1. Open an older saved build using `clean_room_full_push`.
2. Reload the page.
3. Save only if intentionally testing migration behavior.

Expected:

- Older build does not break.
- Older recipe details remain visible.
- MAB does not silently mutate the old build to v2 unless the operator intentionally saves/clones/resets.

## Test 11 — Single-ad-set workflows unaffected

1. Use `Ticketed Concert - Video-Led Local Push` or another non-clean-room strategy.
2. Save Draft.
3. Load/reload.
4. Test existing adoption/search flow without creating live changes.

Expected:

- Existing single-ad-set behavior still works.
- Adoption IDs persist.
- No Clean-Room v2 UI warnings leak into custom/single-ad-set strategies.

## Test 12 — No accidental live mutations

Throughout testing, verify:

- Create actions create paused assets only.
- Refresh/status calls do not modify live Meta objects.
- Save Draft does not unlink adopted Meta IDs.
- Go Live is only triggered when explicitly clicked.

## Regression notes to watch

- Guided tour must not auto-launch and block controls.
- Build dropdown should continue showing all saved builds.
- Save/reload should preserve active build selection.
- `Update Existing Meta Ad` should remain blocked/guarded for multi-ad-set recipes until the dedicated multi-ad-set update workflow exists.
