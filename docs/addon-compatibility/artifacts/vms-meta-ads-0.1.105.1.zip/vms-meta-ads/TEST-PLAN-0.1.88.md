# VMS Meta Ads Builder 0.1.88 Test Plan

## A. Package/version validation

1. Confirm one canonical top-level plugin directory:
   - `vms-meta-ads/`
2. Confirm plugin header reports `0.1.88`.
3. Confirm `VMS_MA_VERSION` resolves to `0.1.88`.
4. Confirm `module.json` reports `0.1.88`.
5. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.88`.

## B. Static validation

Run from the unpacked plugin directory:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/admin/api-diagnostics.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.88-outer-towns-city-lookup-diagnostics.zip
```

## C. City lookup diagnostics

1. Enter Outer Towns locations:

```text
Athens, Texas | 15
Henderson, Texas | 15
```

2. Attempt paused create.
3. Confirm diagnostics show each targeting city lookup endpoint/query in the recent rows, not just the operation name.
4. If Meta returns `Provide valid app ID`, confirm the operator-facing message explains the App ID/auth cause and recommends ZIP fallback or app authentication configuration.

## D. State matcher regression

Mock or inspect Meta search rows to confirm:

1. `name: Athens, TX`, blank `region`, blank `canonical_name` is accepted for `Athens, Texas`.
2. `name: Athens, Georgia` or `name: Athens, GA` is rejected for `Athens, Texas`.
3. Rows with `region: Texas` or `canonical_name: Athens, Texas` still pass.

## E. Safe fallback behavior

Confirm listed-only Outer Towns:

1. Does not fall back to the venue radius when city lookup fails.
2. Still blocks create when no explicit Outer Towns locations are entered.
3. Still inherits the main Step D age range.

## F. Regression checks

Confirm existing behaviors still hold:

1. Advantage+ creative policy remains off/preserve creative by default.
2. Multi-advertiser ads are blocked or flagged by QA.
3. Manual Meta QA Gate still works.
4. Outer Towns accepts ZIP rows as a safe fallback.
5. UTMs remain present on every generated ad URL.
