# VMS Meta Ads Builder 0.1.77 Test Plan

## Purpose

Validate that Clean-Room Full Push v2 creates a safer placement-separated structure and that Website Highlights reminders appear before the operator publishes.

## Setup

- Install `vms-meta-ads` 0.1.77 over the existing `vms-meta-ads` plugin folder.
- Use a staging event plan with a destination URL, event date, budget, and Meta settings configured.
- Do not publish/go-live during this test unless the operator intentionally approves live spend.

## Smoke checks

1. Confirm plugin version markers:
   - `vms-meta-ads.php` shows `0.1.77`.
   - `module.json` shows `0.1.77`.
   - `vms-build.txt` begins with build `0.1.77`.
2. Open the Ads Builder and confirm no browser unresponsive/spinning behavior from the Sales goal UI.
3. Select `Clean-Room Concert Campaign - Full Push v2`.

## UI checks

1. Confirm the recipe preview shows:
   - `Core Radius - Feeds`
   - `Vertical Video - Reels/Stories`
   - `Outer Towns - Feeds 50+`
2. Confirm Core Radius placements display only:
   - Facebook Feed
   - Instagram Feed
3. Confirm Vertical Video placements display only:
   - Facebook Reels
   - Instagram Reels
   - Facebook Stories
   - Instagram Stories
4. Confirm Outer Towns placements display only:
   - Facebook Feed
   - Instagram Feed
5. Confirm the clean-room checklist/reminder mentions manual review for Website Highlights / Show Spotlights.
6. Mark the video shape as `Square / 1:1` and confirm Tall video is not shown as fully ready.
7. Mark the video shape as `Tall / 9:16` or `Meta-direct vertical placeholder` and confirm the Tall video requirement improves to Ready.

## Save/export checks

1. Save Draft.
2. Confirm the generated copy pack includes:
   - Feed/Square and Reels/Stories separation language.
   - Manual Meta QA reminder for Website Highlights / Show Spotlights.
3. Confirm no legacy build/adoption IDs are removed when saving a draft that already has Meta IDs.

## Create-in-Meta checks — paused only

Only run if staging API credentials are safe and the operator intends to create paused Meta assets.

1. Click Create in Meta.
2. Confirm assets are created PAUSED.
3. Refresh Meta status and confirm the expected number of ad sets and ads is shown.
4. In Meta Ads Manager, verify:
   - Feed ad sets do not include Reels/Stories placements.
   - Reels/Stories ad set does not include Feed placements.
   - Website Highlights / Web Highlight / Show Spotlights are disabled manually before publish.
   - Multi-advertiser ads are disabled manually before publish.
   - Schedule timezone matches the venue/event timezone.

## Go Live preflight checks

1. Open Go Live preflight without confirming live spend.
2. Confirm the manual checklist mentions:
   - Website Highlights / Web Highlight / Show Spotlights off.
   - Multi-advertiser ads off.
   - Feed creative vs Reels/Stories creative review.
   - Schedule timezone review.
3. Cancel the modal unless intentionally publishing.

## Regression checks

1. Legacy `clean_room_full_push` saved builds remain readable.
2. Right Column Support Test remains optional for v2.
3. Sales / Ticket Purchases still maps to Purchase conversions and requires a Pixel/Dataset ID before create.
4. Existing single-ad-set/custom strategies still save drafts and export copy packs.
