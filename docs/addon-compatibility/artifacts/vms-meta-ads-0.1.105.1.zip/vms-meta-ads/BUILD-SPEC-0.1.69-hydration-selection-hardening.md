# VMS Meta Ads Builder 0.1.69 — Hydration + Selection Hardening

## Purpose

0.1.68 exposed that the saved-build data layer was correct, but the builder UI could still collapse to a single currently selected build on first page load or after Save Draft/reload. Refresh and Meta discovery could also reset the active build back to the latest draft instead of preserving the build the operator was actually reviewing.

This pass hardens the front-end hydration and selection model so the UI treats the actively loaded build as durable state and does not let late async responses or server prefill fallbacks override it.

## Changes

### 1. Active build state

- Adds a dedicated `activeBuildId` front-end state variable.
- Keeps the hidden build ID, dropdown value, and visible card selection synchronized through a single setter.
- Uses the active build state for refresh, discovery, analytics, linked Meta detection, and build-list rendering.

### 2. Full saved-build hydration on prefill loads

- Server prefill payload now includes up to 50 saved builds for the Event Plan, not only the latest build.
- First-load prefill no longer intentionally seeds the UI with a one-build-only cache as the final visible state.
- If the full API list fails, the old single-build fallback can still be used so the page is not blank.

### 3. Preserve selected build during refresh

- Refresh Builds now uses the durable active build ID rather than relying only on whatever value happens to be in the hidden input at that moment.
- If the selected build exists in the returned list, it remains selected.
- The latest build is only auto-loaded when no active build is selected.

### 4. Protect against async reset/race conditions

- Adds lightweight hydration and interaction sequence guards.
- Late first-load or background hydration should no longer override a build the operator selected afterward.
- Build list hydration may update the visible card collection, but it should not silently switch the active build back to the newest draft.

### 5. Meta discovery context preservation

- Find Existing Meta Campaigns captures the active build before the API call.
- After discovery results render, the builder restores the selected build/card/dropdown context.
- Already-linked campaigns should continue to render as linked for the current build rather than adoptable due to context reset.

### 6. Guided tour autorun hardening

- Tour autorun now honors the builder wrapper’s `data-tour-autorun="0"` ahead of any stale user preference/config payload.
- Prefill URLs should not auto-launch the tour unless `tour=1` is explicitly present.
- The manual Start tour button remains available.

## Non-goals

- No Meta create/update/go-live/pause/budget-sync behavior changed.
- No new strategy template behavior added.
- No cleanup/archive action for old test builds yet.
