# VMS Meta Ads Builder 0.1.98 Test Plan

## Static
- `php -l` on changed PHP files

## Local No-Spend
- Confirm builder remains locked with premium gate absent.
- Confirm dry run stays local-only.
- Confirm blank DSA settings still produce DSA warnings.
- Confirm configured DSA settings remove dry-run DSA warnings and keep DSA note visible.
- Confirm create gate still rejects:
  - missing confirmation
  - confirmed create while `enable_api_create=0`
- Confirm no browser `graph.facebook.com` requests and no page errors during smoke.

## Readiness Classification
- Synthetic/advisory check:
  - configured DSA + no readback + no `issues_info` => advisory warning, not error
  - configured DSA + no readback + `issues_info` => DSA advisory plus blocking Meta issues item
  - blank DSA settings => warning
  - readback present => ok

## Staging No-Spend
- Deploy MAB only to staging.
- Keep core `0.2.24.711`.
- Clamp `enable_api_create=0`, `vms_ma_phase=1`.
- Confirm status panel remains read-only.
- Confirm dry run remains local-only.
- Confirm no Meta create/update/delete/publish calls.
