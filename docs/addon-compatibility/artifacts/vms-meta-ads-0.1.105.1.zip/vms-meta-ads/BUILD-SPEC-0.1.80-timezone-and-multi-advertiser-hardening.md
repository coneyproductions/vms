# VMS Meta Ads Builder 0.1.80 — Timezone + Multi-Advertiser Hardening

## Goal

Fix two live-review problems seen after 0.1.79:

1. Event ads were ending at the wrong displayed time in Meta when the site/event timezone differed from the Meta ad-account timezone.
2. MAB showed Multi-advertiser ads as off, but Meta Ads Manager still opened some created ads with the Multi-advertiser ads checkbox enabled.

## Changes

### 1. Site-local schedule to Meta-account timezone conversion

Previously, `to_meta_iso8601()` parsed saved schedule strings directly in the Meta account timezone. That caused a site-local cutoff like `2026-05-15 18:00:00` to become `6:00 PM Pacific` when the site intended `6:00 PM Central`.

0.1.80 now:

- Parses saved schedule values using `wp_timezone()` / the site timezone.
- Converts that real-world instant into the Meta ad-account timezone.
- Sends the converted ISO-8601 value to Meta.

Example intent:

- Site/event cutoff: `6:00 PM America/Chicago`
- Meta account timezone: `America/Los_Angeles`
- Meta should display: `4:00 PM Pacific`, not `6:00 PM Pacific`.

### 2. Meta timezone detection before create

Create-in-Meta now runs the connection verification path before schedule conversion and refreshes settings afterward. If no manual or detected Meta timezone is stored, the lightweight connection check asks Meta for `timezone_name` and saves it as `meta_account_timezone_detected`.

### 3. Go Live validation timezone parity

Go Live schedule validation now parses event start/end values as site-local time before converting to Meta timezone for comparison. This prevents false matches caused by comparing the same clock value in the wrong timezone.

### 4. Multi-advertiser / enhancement suppression attempt

When the operator leaves Multi-advertiser ads off, MAB now adds a creative feature opt-out payload when creating ad creatives:

- Attempts to opt out of `standard_enhancements`.
- Attempts to opt out of Meta's contextual multi-advertiser feature.
- Applies this to image/link creatives and video creatives.

Because Meta API support varies by account/API version, the create flow includes fallbacks:

1. Try standard enhancements + contextual multi-ads opt-out.
2. If Meta rejects that structure, retry standard enhancements only.
3. If Meta rejects that too, retry without the feature opt-out payload so the ad build does not fail.

## Files changed

- `includes/meta-api/client.php`
- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`

## Version markers

- Plugin header: `0.1.80`
- `VMS_MA_VERSION`: `0.1.80`
- `module.json`: `0.1.80`
- `vms-build.txt`: `0.1.80`
