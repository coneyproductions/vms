# TEST PLAN — VMS Meta Ads Builder 0.1.72

## Scope

Focused regression test for the Meta Ads Builder tour behavior after the local fallback fix.

Do **not** invoke live-changing Meta actions during this test:

- Create in Meta
- Update Existing Meta Ad
- Go Live
- Pause
- Budget Sync

## Target

- Site: staging
- Plugin: `vms-meta-ads`
- Event Plan: Buffet Beach / Event Plan `2515`
- Known linked campaign/ad set for build #25:
  - Campaign: `6935199138516`
  - Ad set: `6935199142316`

---

## 1. Confirm version

Open:

```text
/wp-content/plugins/vms-meta-ads/vms-build.txt
```

Expected:

- Version reports `0.1.72`.

---

## 2. Confirm no auto-tour with explicit opt-out

Open the Builder with:

```text
admin.php?page=vms-ma-ads-builder&event_plan_id=2515&prefill=1&tour=0
```

Expected:

- No tour opens automatically.
- No overlay intercepts clicks.
- Builder controls are clickable immediately.

---

## 3. Confirm no auto-tour with normal prefill

Open the Builder with:

```text
admin.php?page=vms-ma-ads-builder&event_plan_id=2515&prefill=1
```

Expected:

- No tour opens automatically.
- No overlay intercepts clicks.
- Builder controls are clickable immediately.

---

## 4. Confirm manual Start tour works

From the prefilled Builder page, click:

```text
Start tour
```

Expected:

- A tour popover/overlay opens.
- The first step is visible and references picking/selecting an event.
- The operator can close the tour.
- If `window.VMS_Tour` is absent, the local fallback tour is acceptable as long as a visible tour opens and controls work.

Optional console checks:

```js
window.VMS_MA && Array.isArray(window.VMS_MA.tourSteps) && window.VMS_MA.tourSteps.length
window.vmsMaTours && window.vmsMaTours.builder
```

Expected:

- `VMS_MA.tourSteps` exists and has steps.
- `vmsMaTours.builder` exists after page load or after clicking Start tour.

---

## 5. Confirm explicit tour=1 works

Open:

```text
admin.php?page=vms-ma-ads-builder&event_plan_id=2515&prefill=1&tour=1
```

Expected:

- Tour opens intentionally.
- Tour can be closed.
- No page crash or console fatal prevents Builder controls after close.

---

## 6. Confirm saved-build hydration remains intact

Open the Builder for Event Plan `2515` and compare UI saved-build order to the API result.

Expected UI/API newest-first order:

```text
27, 26, 25, 24, 23, 22, 15
```

Expected:

- Full saved-build list remains visible.
- No collapse to only the current build.

---

## 7. Confirm discovery linked state remains intact

Load build #25 and run:

```text
Find Existing Meta Campaigns
```

Expected:

- Build #25 remains selected.
- Hidden build ID, dropdown, detail line, and selected card stay synchronized.
- Campaign `6935199138516` / ad set `6935199142316` renders as **Linked to this build**, not adoptable.

---

## 8. Safety confirmation

Confirm no live-changing Meta actions were invoked.

Expected:

- No Create in Meta.
- No Update Existing Meta Ad.
- No Go Live.
- No Pause.
- No Budget Sync.
- Linked Meta campaign/ad set IDs did not change.
