# VMS Meta Ads Builder 0.1.86 — Outer Towns City Lookup Fallback

## Goal
Fix Outer Towns city/state entries such as `Athens, TX` failing during Meta paused-create.

## Root Cause
The 0.1.85 resolver submitted the full `City, ST` string as the Meta geolocation search query. Meta targeting search is more reliable when searching the locality/city name only and then filtering the returned results by state/country.

## Changes
- Search Meta using only the parsed city/locality name.
- Filter candidates locally by city, state code/state name, and country.
- Try the global `/search` endpoint first.
- Fall back to the ad-account `/targetingsearch` endpoint when available.
- Preserve radius/distance_unit when a Meta city key is used instead of coordinates.
- Keep listed-only behavior: no fallback to the venue radius.

## Version
Bump to `0.1.86`.
