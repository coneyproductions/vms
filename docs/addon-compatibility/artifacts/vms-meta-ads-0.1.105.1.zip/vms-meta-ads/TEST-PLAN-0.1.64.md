# Codex Test Plan — VMS Meta Ads Builder 0.1.64

🚨 Codex should test this before relying on it for a live weekend campaign.

## Primary validation

1. Install 0.1.64 over 0.1.63 in the canonical `vms-meta-ads/` plugin folder.
2. Confirm plugin header, module.json, and vms-build.txt all show 0.1.64.
3. Open VMS > Meta Ads Builder.
4. Select an Event Plan with a saved build.
5. Click **Find Existing Meta Campaigns**.
6. Confirm the request does not create, publish, pause, or edit anything in Meta.
7. Confirm likely candidates render as cards with campaign/ad set IDs, status, audience summary, budget, and ad count.
8. Confirm a no-match result clears prior candidates and cannot adopt stale data.

## Adopt/link validation

1. Choose a known correct Meta candidate.
2. Click **Adopt / Link this Meta campaign**.
3. Confirm the browser confirmation appears.
4. Confirm the selected build receives Meta campaign/ad set/ad IDs.
5. Confirm the Meta Status card refreshes after adoption.
6. Confirm Event Plan metadata reflects live/paused status based on actual Meta effective statuses.
7. Confirm the campaign is not published, paused, renamed, or otherwise changed by adoption.

## Drift detection validation

1. Create or select a build with a known saved radius, age range, budget, and optimization.
2. Manually change one or more of those values in Meta Ads Manager.
3. Refresh status in the builder.
4. Confirm the drift panel identifies the changed field(s).
5. Confirm clean/no-drift cases show a clean result.
6. Confirm failed Meta reads show a warning/unknown state rather than a fatal error.

## Regression validation

1. Existing Refresh Status still works on known linked builds.
2. Create in Meta (PAUSED) still works for a fresh build.
3. Update Existing Meta Ad remains gated to linked builds.
4. Sync Budget to Meta still uses the selected build.
5. Go Live confirmation still appears and requires confirmation.
6. Reset Meta Link still clears local IDs.
7. Video placeholder variants from 0.1.63 still save/reload and produce warnings.
8. Buy Tickets CTA lock from 0.1.62 still forces ticketed concert CTAs.
9. Strategy template and video-led budget pacing still render correctly.

## Edge cases

- API token missing or invalid.
- API create disabled but read settings saved.
- Event Plan has no saved build; discovery can run, adoption should require saving/selecting a build first.
- Meta returns campaigns but no ad sets.
- Meta returns ad sets but no ads.
- Multiple candidate campaigns match one event.
- Candidate has active campaign but paused ad set or mixed ad statuses.
- Build is already linked to a different Meta campaign.

## Expected result

The builder can safely discover and adopt the live Meta campaign for an event without overwriting it, and it clearly warns when the saved build differs from the live Meta ad set.
