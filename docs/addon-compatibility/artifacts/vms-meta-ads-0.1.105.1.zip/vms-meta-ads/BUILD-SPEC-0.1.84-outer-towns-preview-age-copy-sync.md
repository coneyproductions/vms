# VMS Meta Ads Builder 0.1.84 — Outer Towns Preview Age Copy Sync

## Goal
Align the clean-room recipe preview and checklist wording with the actual Step D age range already used by the saved payload and Meta create flow.

## Changes

### Preview copy sync
- Replaces stale `50+` copy in the clean-room recipe preview row for Outer Towns.
- Replaces stale `50+` copy in the clean-room checklist layout summary.
- Uses the live Step D age range, including `65+` display behavior, so operators see the same audience range in preview copy that MAB already saves and sends.

### Behavior preserved from 0.1.83
- Outer Towns listed-only mode still requires at least one precise ZIP or full address.
- Outer Towns payloads still inherit the main campaign age range instead of forcing 50+.
- Create in Meta still auto-saves the latest draft payload before creating paused assets.

## Operator impact
- Clean-room recipe preview text should now match the configured Step D ages.
- No intended change to saved payload structure, Meta targeting logic, or paused-create behavior.
