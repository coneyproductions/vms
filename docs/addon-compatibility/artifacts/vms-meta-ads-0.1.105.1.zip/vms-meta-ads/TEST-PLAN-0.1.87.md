# VMS Meta Ads Builder 0.1.87 Test Plan

## A. Package/version

1. Confirm release zip has one canonical top-level directory: `vms-meta-ads/`.
2. Confirm plugin header version is `0.1.87`.
3. Confirm `VMS_MA_VERSION` is `0.1.87`.
4. Confirm `module.json` is `0.1.87`.
5. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.87`.

## B. Static validation

Run from the plugin directory:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/admin/api-diagnostics.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.87-outer-towns-state-name-normalization.zip
```

## C. UI validation

1. Open MAB Step D.
2. Confirm the Outer Towns placeholder uses full state names, e.g. `Athens, Texas | 15`.
3. Confirm helper text says spelling out the state is recommended while abbreviations are accepted.

## D. Meta paused-create validation

Use these entries first:

```text
Athens, Texas | 15
Henderson, Texas | 15
Jacksonville, Texas | 15
Longview, Texas | 15
Mineola, Texas | 15
Palestine, Texas | 25
```

Expected: Outer Towns resolves through Meta and creates paused without falling back to venue radius.

Then test abbreviation compatibility:

```text
Athens, TX | 15
Henderson, TX | 15
```

Expected: MAB accepts abbreviations, but diagnostics should show full-state lookup variants such as `Athens, Texas` before abbreviation/city-only fallbacks.

## E. Regression checks

- Outer Towns inherits Step D age range.
- Outer Towns listed-only does not use the primary venue radius.
- Manual QA gate still works.
- Advantage+ creative policy remains off/preserve creative.
- Multi-advertiser setting remains opt-out.
- UTMs remain present on ad URLs.
