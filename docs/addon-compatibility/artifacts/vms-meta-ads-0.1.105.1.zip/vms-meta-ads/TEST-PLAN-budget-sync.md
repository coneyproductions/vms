# TEST PLAN — Budget Sync (0.1.39)

## Goal
Confirm the rebuilt 0.1.39 plugin can manually sync an existing Meta ad set budget and optionally auto-sync saved draft budget changes every 15 minutes.

## Preconditions
- Meta API is enabled and working in plugin settings.
- Use an Event Plan that already has a valid Meta ad link, or create one fresh with **Create in Meta (PAUSED)**.
- Prefer testing on a paused ad set first.

## Manual budget sync
1. Open **Meta Ads Builder** and load an Event Plan.
2. Save a draft with a clear budget value, for example **$25.00**.
3. If needed, click **Create in Meta (PAUSED)** so the campaign/ad set/ad IDs exist.
4. Click **Refresh Status**.
5. Confirm the **Budget Sync** row appears in the Meta Status card.
6. Change the budget in Step E to a different value, for example **$40.00**.
7. Click **Save Draft**.
8. Click **Sync Budget to Meta**.
9. Confirm:
   - success message appears
   - Budget Sync row updates
   - Meta Ads Manager shows the updated ad set budget

## No-op sync
1. Without changing the budget again, click **Sync Budget to Meta** a second time.
2. Confirm the UI reports that the budget already matched or no change was needed.

## Auto-sync flag persistence
1. Check **Auto-sync saved draft budget to Meta every 15 minutes**.
2. Click **Save Draft**.
3. Reload the builder page and reload the same Event Plan.
4. Confirm the checkbox remains checked.

## Scheduled auto-sync
1. With auto-sync enabled, change the draft budget again and click **Save Draft**.
2. Wait for WP-Cron to run, or trigger cron manually if your workflow allows.
3. Confirm the Meta budget updates without clicking the manual sync button.
4. Confirm the Budget Sync details show a recent last-sync time.

## Guardrail checks
- Try an Event Plan with no Meta IDs yet and confirm **Sync Budget to Meta** stays unavailable until the Meta link exists.
- Confirm **Pause All**, **Refresh Status**, and **Reset Meta Link** still work.
- Confirm the plugin still installs into the existing `vms-meta-ads` folder and does not create a parallel plugin.

## Expected limitation for this pass
- Budget sync currently targets plugin-created **lifetime-budget** ad sets.
