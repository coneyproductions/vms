# MAB 0.1.89 Build Spec — Budget Allocation Preview

## Goal

Make Step E show whether the current total budget and run window can safely support the selected clean-room recipe allocation split before Meta creation.

## Changes

- Add a live note beside the Total budget field showing the minimum total budget for the current recipe allocation.
- Add a Step E budget allocation preview table with one row per recipe ad set.
- Show allocation percentage, allocated budget, average daily spend, and health status for each row.
- Calculate minimum total budget from the current run-window length, the Meta $1/day practical floor, and the current ad-set percentage split.
- Add a one-click helper to raise the budget to the calculated minimum when the current budget is below the floor.
- Keep server-side Meta creation budget validation unchanged.

## Status labels

- Below minimum: ad set is under the Meta $1/day practical floor.
- Thin: meets the floor, but has little learning room.
- Workable: acceptable.
- Comfortable: healthy cushion for testing.

## Non-goals

- Do not change actual server-side budget allocation percentages.
- Do not change campaign creation, creative lockdown, Outer Towns targeting, or Meta city lookup logic.
