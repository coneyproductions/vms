# VMS Meta Ads Builder 0.1.83 Test Plan

## A. Version/package validation
1. Confirm the installed plugin directory is `vms-meta-ads/`.
2. Confirm plugin header reports `0.1.83`.
3. Confirm `VMS_MA_VERSION` reports `0.1.83`.
4. Confirm `module.json` reports `0.1.83`.
5. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.83`.
6. Confirm release zip contains one canonical top-level directory: `vms-meta-ads/`.

## B. Static validation
1. Run PHP lint across all plugin PHP files.
2. Run `node --check` for:
   - `assets/ads-builder.js`
   - `assets/admin/api-diagnostics.js`
   - `assets/guidance.js`
   - `assets/help-mode.js`
   - `assets/settings.js`
   - `assets/tours.js`
3. Run `zip -T` against the packaged release zip.

## C. Step D UI validation
1. Open MAB in wp-admin.
2. Choose Clean-Room Concert Campaign - Full Push v2.
3. Expand Step D / Advanced.
4. Confirm Step D shows:
   - Primary targeting address or ZIP
   - Additional locations for the core audience (optional)
   - Outer Towns targeting mode
   - Outer Towns ZIPs/full addresses
5. Confirm the Outer Towns mode help text no longer says to use locations “above” ambiguously.

## D. Listed-only blocking validation
1. Select Clean-Room v2.
2. Set Outer Towns targeting mode to `Listed towns/ZIPs only`.
3. Leave Outer Towns ZIPs/full addresses empty.
4. Try Save Draft or Create in Meta.
5. Expected: MAB blocks with an error requiring at least one precise ZIP or full address.

## E. Audience inheritance validation
1. Set Step D age min to `45` and age max to `65+`.
2. Enter at least one Outer Towns ZIP or full address.
3. Save Draft.
4. Inspect the saved copy payload / recipe payload.
5. Expected: Outer Towns ad set uses age `45-65+`, not forced `50-65+`.

## F. Live paused-create validation
1. Use a fresh Event Plan or reset/clone the existing Meta link.
2. Enter explicit Outer Towns ZIPs/full addresses.
3. Click Create in Meta (PAUSED).
4. Expected: MAB first saves the latest draft, then creates paused assets.
5. In Ads Manager, verify Outer Towns does not use the primary venue radius when listed-only is selected.
6. Verify Outer Towns age matches Step D.

## G. Manual Ads Manager verification
For every ad/ad set before publish:
1. Multi-advertiser ads unchecked in Edit view.
2. Advantage+ creative/enhancements off.
3. Website Highlights / Show Spotlights off.
4. Destination preview opens the intended website ticket URL.
5. UTMs are present.
6. Schedule is correct.
7. Outer Towns is using the explicit ZIPs/full addresses and not the venue radius.
