# VMS Meta Ads Builder 0.1.97 Build Spec

## Scope
- Keep DSA dry-run preview output in parity with the real ad-set create payload.
- Preserve no-spend behavior and do not update existing Meta objects.

## Included
- Add `dsa_beneficiary` / `dsa_payor` to the dry-run ad-set request-plan payload when configured in MAB settings.
- Surface a dry-run DSA readiness note clarifying that configured settings affect future creates only.
- Clarify post-create readiness copy when MAB settings are configured but older live Meta objects still lack DSA fields.

## Excluded
- No VMS core changes.
- No DB schema changes.
- No production Meta object update/delete/recreate behavior.
