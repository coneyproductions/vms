# Codex Test Plan — VMS Meta Ads Builder 0.1.68

## Purpose

Verify that saved builds for an Event Plan are visible and selectable in the UI after the 0.1.67 timestamp/order fixes, without invoking any live-changing Meta actions.

## Safety rules

Do **not** click:

- Create in Meta
- Update Existing Meta Ad
- Go Live
- Pause
- Budget Sync

This pass should only inspect UI state, save harmless drafts if needed, and load/select builds.

## Setup

1. Install/activate `vms-meta-ads-0.1.68-build-dropdown-polish.zip` on staging.
2. Confirm version from `wp-content/plugins/vms-meta-ads/vms-build.txt`.
3. Open the Meta Ads Builder for Event Plan 2515, Buffet Beach.

## Tests

### 1. Build list visibility

1. Select the Buffet Beach Event Plan.
2. Confirm the API call to `/ad-builds?event_plan_id=2515&limit=50` returns multiple builds.
3. Confirm Step A shows a visible **Saved builds for this event (N)** list below the linked-build dropdown.
4. Confirm the visible list count matches the API item count.
5. Confirm newest builds appear first.

### 2. Current build marker

1. Load adopted/live build #25 if available.
2. Confirm its card is marked Loaded/current.
3. Confirm it shows Live in Meta / Meta source of truth language.
4. Confirm other builds show a Load button.

### 3. Switch build from card list

1. Click Load on a non-live draft build.
2. Confirm the hidden build ID, dropdown selection, and detail line update to that build.
3. Confirm the selected card changes to Loaded.
4. Load build #25 again and confirm the same behavior.

### 4. Refresh builds does not collapse list

1. With build #25 selected, click Refresh builds.
2. Confirm all builds remain visible.
3. Confirm selected build remains selected.

### 5. Save Draft does not collapse list

1. Make a harmless copy-only text change on a draft build.
2. Click Save Draft.
3. Confirm the full saved-build list remains visible after save.
4. Refresh the page and confirm the list still populates.

### 6. Adoption/reconciliation regression

1. Click Find Existing Meta Campaigns.
2. Confirm linked/adopted candidates are marked Linked when applicable.
3. Do not adopt again unless needed for the test account state.
4. Confirm the saved-build list still remains visible after reconciliation results render.

## Expected result

0.1.68 passes when the full API-returned build collection is visible and selectable in the UI, selected/current build state is obvious, and no live Meta mutations occur.
