# VMS Meta Ads Builder 0.1.97 Test Plan

## Static
- `php -l` on changed PHP files.

## Local
- With blank DSA settings, confirm dry run shows DSA warnings.
- With configured DSA settings, confirm dry run removes DSA warnings and shows `dsa_beneficiary` / `dsa_payor` in the ad-set request-plan payload.
- Confirm dry run remains local-only and adds no Meta mutation calls.

## Staging
- Deploy MAB only.
- Keep `enable_api_create=0` and `vms_ma_phase=1`.
- Confirm read-only status panel still uses GET only.
- Confirm configured DSA values appear in the dry-run request-plan payload.
- Confirm existing paused test objects are not updated.
