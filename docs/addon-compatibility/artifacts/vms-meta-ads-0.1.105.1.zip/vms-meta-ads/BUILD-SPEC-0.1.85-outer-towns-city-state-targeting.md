# VMS Meta Ads Builder 0.1.85 — Outer Towns City/State Targeting

## Goal
Allow operators to enter Outer Towns locations as city/state, ZIP, or full address rows instead of requiring ZIP lookups.

## Changes
- Renamed Step D field to **Outer Towns locations**.
- Added **Outer Towns default radius** with a default of 15 miles.
- Supports one location per line with optional `| miles`, for example `Athens, TX | 15`.
- Accepts city/state, ZIP, and full address rows for the dedicated Outer Towns listed-only field.
- Listed-only Outer Towns keeps using only explicit Outer Towns locations and does not fall back to the venue radius.
- Outer Towns still inherits the main Step D age range.
- Added create-time validation for missing rows, missing labels, invalid radius values, and unresolved/ambiguous city/state rows.
- Added Meta city lookup for city/state rows before creating the ad set. When latitude/longitude is available, MAB creates a radius-based custom location; otherwise it falls back to Meta city-key targeting.
- Updated recipe preview copy so operators can see the planned Outer Towns locations/radii before Create in Meta.

## Files touched
- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `includes/admin/screens/ads-builder.php`
- `assets/ads-builder.js`
- `includes/services-ad-builds.php`
- `includes/meta-api/client.php`

## Version
Bumped to `0.1.85`.
