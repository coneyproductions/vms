# VMS Meta Ads Builder 0.1.78 — Feed Square Video Ad Set Patch

## Purpose

Version 0.1.77 separated Feed placements from Reels/Stories placements, but it did not create a dedicated 1:1 video ad/ad set for Feed placements. It treated Feed ad sets as static/square-image oriented and routed video/video-placeholder variants to the Reels/Stories group.

Version 0.1.78 adds a dedicated optional **Feed Video - Square 1:1** ad set when an ad variant is intentionally marked for square feed video.

## Operator-facing changes

### Ad Variants

Each variant now has a **Placement intent** field:

- `Auto / normal`
- `Feed square video (1:1)`
- `Reels/Stories portrait video (9:16)`

For the clean-room v2 recipe:

- Static/shared/image variants remain in static Feed ad sets.
- Video/video-placeholder variants marked **Feed square video (1:1)** create/use the **Feed Video - Square 1:1** ad set.
- Video/video-placeholder variants marked **Reels/Stories portrait video (9:16)**, or left on Auto, route to the **Vertical Video - Reels/Stories** ad set.

## Recipe behavior

When no Feed square video variant exists, v2 stays close to the 0.1.77 layout:

- Core Radius - Feeds
- Vertical Video - Reels/Stories
- Outer Towns - Feeds 50+
- Optional Facebook Right Column Support Test

When a Feed square video variant exists, v2 adds:

- Feed Video - Square 1:1

Budget weights adjust automatically:

### Without right column support

- Core Radius - Feeds: 45%
- Feed Video - Square 1:1: 15%
- Vertical Video - Reels/Stories: 20%
- Outer Towns - Feeds 50+: 20%

### With right column support

- Core Radius - Feeds: 40%
- Feed Video - Square 1:1: 15%
- Vertical Video - Reels/Stories: 20%
- Outer Towns - Feeds 50+: 20%
- Facebook Right Column Support Test: 5%

## Important limitation

For Meta-direct video placeholders, MAB still creates the paused ad structure using the selected/shared placeholder image. The operator must open Meta Ads Manager and swap/upload the actual square or portrait video before publishing.

## Files changed

- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `assets/ads-builder.js`
- `includes/admin/screens/ads-builder.php`
- `includes/services-ad-builds.php`
- `includes/meta-api/client.php`

## Version markers

- Plugin header: `0.1.78`
- `VMS_MA_VERSION`: `0.1.78`
- `module.json`: `0.1.78`
- `vms-build.txt`: `0.1.78`
