# VMS Meta Ads Builder 0.1.80 Test Plan

## Version verification

1. Confirm plugin header shows `0.1.80`.
2. Confirm `VMS_MA_VERSION` is `0.1.80`.
3. Confirm `module.json` version is `0.1.80`.
4. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.80`.

## Timezone test

Use a site/event in Central Time with a Meta ad account set to Pacific Time.

1. In Settings, either leave Meta account timezone blank and run Test Connection, or set Meta account timezone manually to `America/Los_Angeles`.
2. Create or select an Event Plan with an event start time in Central Time.
3. Use Step E with an end buffer, for example event start `8:00 PM Central` and ad cutoff `6:00 PM Central`.
4. Create the paused Meta campaign/ad sets.
5. Open the ad sets in Meta Ads Manager.
6. Confirm the end time displays as the equivalent Pacific instant, e.g. `4:00 PM Pacific` for `6:00 PM Central`.
7. Confirm the ad does **not** display the same clock time as Central unless the Meta account timezone is also Central.

## Multi-advertiser test

1. Leave the MAB checkbox **Allow multi-advertiser ads** unchecked.
2. Create a paused campaign with at least one static/image ad and one video or video-placeholder ad.
3. Open each ad in Meta Ads Manager.
4. Check the Multi-advertiser ads setting.
5. Preferred result: Meta shows it unchecked.
6. If Meta still shows it checked, manually uncheck before publishing and capture the VMS API diagnostic bundle for the creative create request so the exact Meta response/accepted payload can be inspected.

## Regression checks

1. Clean-Room v2 still creates four ad-set groups: Core Radius - Feeds, Feed Video - Square 1:1, Vertical Video - Reels/Stories, and Outer Towns - Feeds 50+.
2. Feed Video - Square 1:1 remains separate from Vertical Video - Reels/Stories.
3. Website Highlights / Show Spotlights manual warning remains visible before publishing.
4. PHP lint passes.
5. JS syntax check passes.
