(function () {
  'use strict';

  var cfg = window.vmsMaHelp || {};
  var registry = cfg.registry || {};
  var wrap = document.getElementById('vms-ma-ads-builder-wrap') || document.getElementById('vms-ma-settings-wrap');
  if (!wrap) {
    return;
  }
  
  var active = null;
  var activeAnchor = null;
  var activeHelpId = null;
  var guidance = String(cfg.guidanceLevel || wrap.getAttribute('data-guidance-level') || 'beginner').toLowerCase();
  var autoPopupsUseGuidedTourOnly = true;
  var tourActive = false;
  var autoShownByStep = {};
  var autoHelpTimer = null;
  var toursCatalog = window.vmsMaTours || {};
  var screenKey = String(cfg.screen || (wrap.id === 'vms-ma-settings-wrap' ? 'settings' : 'builder')).toLowerCase();

  function resolveHtml(entry) {
    var safe = entry || {};
    // Always prefer full beginner context for info-button popovers.
    if (safe.html_beginner) {
      return linkifyHtml(safe.html_beginner);
    }
    if (guidance === 'expert' && safe.html_expert) {
      return linkifyHtml(safe.html_expert);
    }
    if (safe.html_standard) {
      return linkifyHtml(safe.html_standard);
    }
    if (safe.html_beginner) {
      return linkifyHtml(safe.html_beginner);
    }
    return '';
  }
  
  function linkifyHtml(html) {
    if (!html || typeof html !== 'string') {
      return html;
    }

    var template = document.createElement('template');
    template.innerHTML = html;

    var walker = document.createTreeWalker(
      template.content,
      NodeFilter.SHOW_TEXT,
      null
    );

    var nodes = [];
    var node;
    while ((node = walker.nextNode())) {
      nodes.push(node);
    }

    nodes.forEach(function (textNode) {
      if (!textNode || !textNode.nodeValue) {
        return;
      }

      var parent = textNode.parentElement;
      if (!parent) {
        return;
      }

      if (parent.closest('a,script,style,textarea,code,pre')) {
        return;
      }

      var frag = vmsMaLinkifyTextToFragment(textNode.nodeValue, textNode.ownerDocument || document);
      if (frag) {
        textNode.replaceWith(frag);
      }
    });

    return template.innerHTML;
  }

  function vmsMaLinkifyTextToFragment(text, doc) {
    var re = /(https?:\/\/[^\s<]+)|((?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,})(\/[^\s<]*)?/ig;

    var match;
    var lastIndex = 0;
    var changed = false;

    var frag = doc.createDocumentFragment();

    while ((match = re.exec(text)) !== null) {
      var raw = match[0];
      var start = match.index;

      var charBefore = start > 0 ? text[start - 1] : '';
      if (charBefore === '@') {
        continue;
      }

      if (start > lastIndex) {
        frag.appendChild(doc.createTextNode(text.slice(lastIndex, start)));
      }

      var display = '';
      var href = '';

      if (match[1]) {
        display = match[1];
        href = match[1];
      } else {
        display = match[2] + (match[3] || '');
        href = 'https://' + display;
      }

      var split = vmsMaSplitTrailingPunct(display);
      var displayTrimmed = split.text;
      var trailing = split.trailing;

      var hrefTrimmed = href.endsWith(display)
        ? href.slice(0, href.length - display.length) + displayTrimmed
        : href.replace(display, displayTrimmed);

      var a = doc.createElement('a');
      a.href = hrefTrimmed;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.textContent = displayTrimmed;

      frag.appendChild(a);

      if (trailing) {
        frag.appendChild(doc.createTextNode(trailing));
      }

      lastIndex = start + raw.length;
      changed = true;
    }

    if (!changed) {
      return null;
    }

    if (lastIndex < text.length) {
      frag.appendChild(doc.createTextNode(text.slice(lastIndex)));
    }

    return frag;
  }

  function vmsMaSplitTrailingPunct(str) {
    var punct = ".,;:!?)\\]}>\"'’";
    var trailing = '';
    var text = str;

    while (text.length > 0 && punct.indexOf(text.slice(-1)) !== -1) {
      trailing = text.slice(-1) + trailing;
      text = text.slice(0, -1);
    }

    return { text: text, trailing: trailing };
  }

  function getHelpDismissals() {
    try {
      var raw = sessionStorage.getItem('vmsMaHelpDismissed');
      if (!raw) {
        return {};
      }
      var parsed = JSON.parse(raw);
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch (e) {
      return {};
    }
  }

  function hasDismissedHelp(helpId) {
    if (!helpId) {
      return false;
    }
    var store = getHelpDismissals();
    return !!store[helpId];
  }

  function markHelpDismissed(helpId) {
    if (!helpId) {
      return;
    }
    try {
      var store = getHelpDismissals();
      store[helpId] = true;
      sessionStorage.setItem('vmsMaHelpDismissed', JSON.stringify(store));
    } catch (e) {
      // no-op
    }
  }

  function closePopover() {
    if (!active) {
      return;
    }
    document.removeEventListener('click', handleOutsideClick, true);
    document.removeEventListener('keydown', handleEscape, true);
    window.removeEventListener('scroll', handleReposition, true);
    window.removeEventListener('resize', handleReposition, true);
    active.remove();
    markHelpDismissed(activeHelpId);
    active = null;
    activeAnchor = null;
    activeHelpId = null;
  }

  function handleEscape(evt) {
    if (evt.key === 'Escape') {
      closePopover();
    }
  }

  function handleOutsideClick(evt) {
    if (!active) {
      return;
    }
    if (evt.target.closest('.vms-ma-help-popover') || evt.target.closest('.vms-ma-info')) {
      return;
    }
    closePopover();
  }

  function position(anchor, popover) {
    var rect = anchor.getBoundingClientRect();
    var popRect = popover.getBoundingClientRect();
    var preferAbove = rect.top > (popRect.height + 16);
    var top = preferAbove ? (rect.top - popRect.height - 8) : (rect.bottom + 8);
    var left = rect.left;

    if ((left + popRect.width) > (window.innerWidth - 12)) {
      left = window.innerWidth - popRect.width - 12;
    }
    if (left < 12) {
      left = 12;
    }
    if ((top + popRect.height) > (window.innerHeight - 12)) {
      top = window.innerHeight - popRect.height - 12;
    }
    if (top < 12) {
      top = 12;
    }

    popover.style.top = Math.round(top) + 'px';
    popover.style.left = Math.round(left) + 'px';
  }

  function handleReposition() {
    if (!active || !activeAnchor) {
      return;
    }
    position(activeAnchor, active);
  }

  function openPopover(anchor, entry, helpId) {
    closePopover();

    var pop = document.createElement('div');
    pop.className = 'driver-popover vms-driver-popover vms-ma-help-popover';
    pop.innerHTML = [
      '<button type="button" class="driver-popover-close-btn" aria-label="Close">×</button>',
      '<header class="driver-popover-title">' + String(entry.title || 'Field help') + '</header>',
      '<div class="driver-popover-description">' + resolveHtml(entry) + '</div>'
    ].join('');
    document.body.appendChild(pop);
    position(anchor, pop);
    pop.querySelector('.driver-popover-close-btn').addEventListener('click', function () {
      closePopover();
    });
    document.addEventListener('click', handleOutsideClick, true);
    document.addEventListener('keydown', handleEscape, true);
    window.addEventListener('scroll', handleReposition, true);
    window.addEventListener('resize', handleReposition, true);
    active = pop;
    activeAnchor = anchor;
    activeHelpId = helpId || null;
  }

  function isElementVisible(el) {
    if (!el) {
      return false;
    }
    if (el.hidden) {
      return false;
    }
    var style = window.getComputedStyle ? window.getComputedStyle(el) : null;
    if (style) {
      if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse') {
        return false;
      }
      if (parseFloat(style.opacity || '1') === 0) {
        return false;
      }
    }
    if (!el.getClientRects || el.getClientRects().length === 0) {
      return false;
    }
    return true;
  }

  function isStepLockedOrHidden(icon) {
    var step = icon ? icon.closest('.vms-ma-step') : null;
    if (!step) {
      return false;
    }
    if (step.classList.contains('is-collapsed')) {
      return true;
    }
    var statusEl = step.querySelector('[data-step-status]');
    var statusText = statusEl ? String(statusEl.textContent || '').toLowerCase() : '';
    if (statusText.indexOf('locked') !== -1) {
      return true;
    }
    return false;
  }

  function hasActiveTourPopover() {
    return !!document.querySelector('.driver-popover.vms-driver-popover:not(.vms-ma-help-popover)');
  }

  function getStepKeyForElement(el) {
    var step = el ? el.closest('.vms-ma-step') : null;
    if (!step) {
      return '';
    }
    return String(step.getAttribute('data-step-key') || '').toUpperCase();
  }

  function getExpandedStepKey() {
    var expanded = wrap.querySelector('.vms-ma-step.is-expanded');
    if (!expanded) {
      return '';
    }
    return String(expanded.getAttribute('data-step-key') || '').toUpperCase();
  }

  function getAutoEntry(icon, helpId) {
    var stepKey = getStepKeyForElement(icon);
    var screen = (screenKey === 'settings') ? 'settings' : 'builder';
    var tour = toursCatalog && toursCatalog[screen];
    var steps = tour && Array.isArray(tour.steps) ? tour.steps : [];
    if (stepKey && steps.length) {
      for (var i = 0; i < steps.length; i++) {
        var step = steps[i] || {};
        var candidateKey = String(step.step_key || step.stepKey || '').toUpperCase();
        if (!candidateKey || candidateKey !== stepKey) {
          continue;
        }
        if (step.html_beginner || step.html_standard || step.html || step.title) {
          return {
            title: step.title || (registry[helpId] && registry[helpId].title) || 'Field help',
            html_beginner: step.html_beginner || step.htmlBeginner || '',
            html_standard: step.html_standard || step.htmlStandard || step.html || '',
            html_expert: step.html_expert || step.htmlExpert || ''
          };
        }
      }
    }
    return registry[helpId] || null;
  }

  function scheduleAutoHelp(delayMs) {
    if (autoHelpTimer) {
      window.clearTimeout(autoHelpTimer);
    }
    autoHelpTimer = window.setTimeout(function () {
      initAutoHelp(getExpandedStepKey());
    }, typeof delayMs === 'number' ? delayMs : 160);
  }

  function initAutoHelp(preferredStepKey) {
    if (autoPopupsUseGuidedTourOnly) {
      return;
    }
    if (guidance !== 'beginner') {
      return;
    }
    if (wrap.getAttribute('data-help-mode') !== '1') {
      return;
    }
    if (tourActive || hasActiveTourPopover()) {
      return;
    }
    var icons = wrap.querySelectorAll('.vms-ma-info[data-auto-help="1"]');
    for (var i = 0; i < icons.length; i++) {
      var icon = icons[i];
      if (!icon) {
        continue;
      }
      if (!isElementVisible(icon) || isStepLockedOrHidden(icon)) {
        continue;
      }
      var helpId = icon.getAttribute('data-help-id') || '';
      if (!helpId || !registry[helpId]) {
        continue;
      }
      var stepKey = getStepKeyForElement(icon);
      if (preferredStepKey && stepKey !== preferredStepKey) {
        continue;
      }
      if (stepKey && autoShownByStep[stepKey]) {
        continue;
      }
      var targetSelector = icon.getAttribute('data-auto-help-target') || '';
      if (targetSelector) {
        var target = document.querySelector(targetSelector);
        if (!target || !isElementVisible(target)) {
          continue;
        }
      }
      if (stepKey) {
        autoShownByStep[stepKey] = true;
      }
      var autoEntry = getAutoEntry(icon, helpId);
      if (!autoEntry) {
        continue;
      }
      openPopover(icon, autoEntry, helpId);
      break;
    }
  }

  wrap.addEventListener('click', function (evt) {
    var icon = evt.target.closest('.vms-ma-info');
    if (!icon) {
      return;
    }
    evt.preventDefault();
    var helpId = icon.getAttribute('data-help-id') || '';
    if (!helpId || !registry[helpId]) {
      return;
    }
    openPopover(icon, registry[helpId], helpId);
  });

  window.setTimeout(function () {
    initAutoHelp(getExpandedStepKey());
  }, 180);

  document.addEventListener('vms-ma-guidance-updated', function (evt) {
    var next = evt && evt.detail ? String(evt.detail.level || '') : '';
    if (next === 'beginner' || next === 'standard' || next === 'expert') {
      guidance = next;
      if (guidance === 'beginner') {
        scheduleAutoHelp(120);
      }
    }
  });

  document.addEventListener('vms-ma-tour-opened', function () {
    tourActive = true;
    closePopover();
  });

  document.addEventListener('vms-ma-tour-closed', function () {
    tourActive = false;
    scheduleAutoHelp(180);
  });

  wrap.addEventListener('click', function (evt) {
    if (evt.target.closest('.vms-ma-step-continue') || evt.target.closest('.vms-ma-step-header')) {
      scheduleAutoHelp(160);
    }
  });

  wrap.addEventListener('keydown', function (evt) {
    if ((evt.key === 'Enter' || evt.key === ' ') && evt.target && evt.target.closest('.vms-ma-step-header')) {
      scheduleAutoHelp(160);
    }
  });
})();
