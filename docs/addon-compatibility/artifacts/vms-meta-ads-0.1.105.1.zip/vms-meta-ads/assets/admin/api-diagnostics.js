(function () {
  'use strict';

  function isDebugEnabled() {
    try {
      return /(?:^|[?&])vms_ma_debug=1(?:&|$)/.test(String(window.location && window.location.search || '')) ||
        String(window.localStorage && window.localStorage.getItem('vms_ma_debug') || '') === '1';
    } catch (err) {
      return false;
    }
  }

  function debugLog(message, detail) {
    if (!isDebugEnabled() || !window.console || typeof window.console.error !== 'function') {
      return;
    }
    window.console.error('[MAB diagnostics]', message, detail || '');
  }

  function emitToast(message, type) {
    if (typeof window.CustomEvent !== 'function') {
      return;
    }
    document.dispatchEvent(new CustomEvent('vms-ma-toast', {
      detail: {
        message: String(message || ''),
        type: type || 'info',
        stepKey: 'g'
      }
    }));
  }

  function postAjax(payload) {
    var body = new URLSearchParams();
    Object.keys(payload).forEach(function (key) {
      body.set(key, payload[key] == null ? '' : String(payload[key]));
    });
    return fetch((window.VMS_MA && window.VMS_MA.ajaxUrl) || window.ajaxurl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString()
    }).then(function (r) { return r.json(); });
  }

  function extractPayload(json) {
    if (!json || typeof json !== 'object') {
      return { ok: false, message: 'Invalid response.' };
    }
    if (json.success && json.data && typeof json.data === 'object') {
      return json.data;
    }
    return json;
  }

  function fallbackCopyText(text) {
    return new Promise(function (resolve, reject) {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', 'readonly');
      ta.style.position = 'fixed';
      ta.style.top = '0';
      ta.style.left = '0';
      ta.style.width = '1px';
      ta.style.height = '1px';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      try {
        var ok = document.execCommand('copy');
        if (!ok) {
          throw new Error('Browser copy command was blocked. Use Download Bundle instead.');
        }
        resolve();
      } catch (err) {
        reject(err);
      } finally {
        document.body.removeChild(ta);
      }
    });
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).catch(function () {
        return fallbackCopyText(text);
      });
    }
    return fallbackCopyText(text);
  }

  function safeFilename(value) {
    return String(value || 'vms-meta-api-diagnostic')
      .toLowerCase()
      .replace(/[^a-z0-9._-]+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '') || 'vms-meta-api-diagnostic';
  }

  function downloadText(filename, text) {
    var blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    var url = window.URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = safeFilename(filename) + '.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.setTimeout(function () {
      window.URL.revokeObjectURL(url);
    }, 1000);
  }

  function setStatus(panel, message, isError) {
    var node = panel.querySelector('.vms-api-diag-status');
    if (!node) return;
    node.textContent = message || '';
    node.style.color = isError ? '#b42318' : '';
  }

  function fetchBundle(panel, payload, verb) {
    setStatus(panel, (verb || 'Loading') + '…', false);
    var nonce = panel.getAttribute('data-nonce') || '';
    var action = panel.getAttribute('data-ajax-action') || 'vms_api_copy_bundle';
    return postAjax(Object.assign({ action: action, nonce: nonce }, payload)).then(function (json) {
      var data = extractPayload(json);
      if (!data.ok || !data.bundle_text) {
        var msg = (data && data.message) ? data.message : ((verb || 'Action') + ' failed.');
        throw new Error(msg);
      }
      return data;
    });
  }

  function attemptSuffix(data) {
    if (!data || !data.attempt || !data.attempt.id) {
      return '';
    }
    var op = data.attempt.operation ? String(data.attempt.operation) : 'unknown_operation';
    var when = data.attempt.created_at_local ? String(data.attempt.created_at_local) : '';
    var mode = data.attempt.transport ? String(data.attempt.transport) : '';
    return ' (#' + String(data.attempt.id) + ', ' + op + (mode ? ', ' + mode : '') + (when ? ', ' + when : '') + ')';
  }

  function attemptFilename(data) {
    var id = data && data.attempt && data.attempt.id ? String(data.attempt.id) : 'latest';
    var op = data && data.attempt && data.attempt.operation ? String(data.attempt.operation) : 'diagnostic';
    return 'vms-meta-api-' + id + '-' + op;
  }

  function copyBundle(panel, payload, label) {
    var actionLabel = String(label || 'diagnostic bundle');
    return fetchBundle(panel, payload, 'Copying').then(function (data) {
      return copyText(data.bundle_text).then(function () {
        setStatus(panel, 'Copied ' + actionLabel + attemptSuffix(data), false);
        emitToast('Copied ' + actionLabel, 'success');
      }).catch(function (err) {
        var message = 'Copy failed — open diagnostics and select text manually';
        setStatus(panel, message, true);
        emitToast(message, 'warning');
        debugLog('Copy failed', err && err.message ? err.message : err);
      });
    }).catch(function (err) {
      var message = err && err.message ? String(err.message) : 'Copy failed — open diagnostics and select text manually';
      setStatus(panel, message, true);
      emitToast(message, /No .* logged yet/i.test(message) ? 'info' : 'warning');
      debugLog('Copy bundle unavailable', message);
    });
  }

  function downloadBundle(panel, payload) {
    return fetchBundle(panel, payload, 'Preparing download').then(function (data) {
      downloadText(attemptFilename(data), data.bundle_text);
      setStatus(panel, 'Downloaded' + attemptSuffix(data), false);
    }).catch(function (err) {
      setStatus(panel, err && err.message ? err.message : 'Download failed.', true);
    });
  }

  function refreshPanel(panel) {
    if (!panel || !panel.parentNode) return Promise.resolve();
    var nonce = panel.getAttribute('data-nonce') || '';
    var providerSlug = panel.getAttribute('data-provider-slug') || '';
    var moduleSlug = panel.getAttribute('data-module-slug') || '';
    var context = panel.getAttribute('data-context') || '';
    return postAjax({
      action: 'vms_api_diag_panel_html',
      nonce: nonce,
      provider_slug: providerSlug,
      module_slug: moduleSlug,
      context: context
    }).then(function (json) {
      var data = extractPayload(json);
      if (!data.ok || !data.html) return;
      var container = document.createElement('div');
      container.innerHTML = String(data.html);
      var nextPanel = container.querySelector('.vms-api-diag-panel');
      if (!nextPanel) return;
      panel.parentNode.replaceChild(nextPanel, panel);
      bindPanel(nextPanel);
    }).catch(function () {});
  }

  function bindPanel(panel) {
    if (!panel || panel.getAttribute('data-bound') === '1') {
      return;
    }
    panel.setAttribute('data-bound', '1');
    var providerSlug = panel.getAttribute('data-provider-slug') || '';
    var context = panel.getAttribute('data-context') || '';
    var defaultAttemptId = panel.getAttribute('data-default-attempt-id') || '';
    panel.addEventListener('click', function (evt) {
      var target = evt.target && evt.target.closest ? evt.target.closest('button, .button-link') : null;
      var raw = panel.querySelector('.vms-api-diag-raw');
      if (!target || !panel.contains(target)) {
        return;
      }
      if (target.classList.contains('vms-api-diag-copy-latest-attempt')) {
        evt.preventDefault();
        copyBundle(panel, { attempt_id: target.getAttribute('data-attempt-id') || defaultAttemptId }, 'latest attempt');
        return;
      }
      if (target.classList.contains('vms-api-diag-download-latest-attempt')) {
        evt.preventDefault();
        downloadBundle(panel, { attempt_id: target.getAttribute('data-attempt-id') || defaultAttemptId });
        return;
      }
      if (target.classList.contains('vms-api-diag-copy-latest-failed')) {
        evt.preventDefault();
        copyBundle(panel, { mode: 'latest_failed_meta_call', provider_slug: providerSlug, context: context }, 'latest failed Meta API call');
        return;
      }
      if (target.classList.contains('vms-api-diag-copy-latest-dry-run')) {
        evt.preventDefault();
        copyBundle(panel, { mode: 'latest_dry_run', provider_slug: providerSlug, context: context }, 'latest dry run');
        return;
      }
      if (target.classList.contains('vms-api-diag-copy-row')) {
        evt.preventDefault();
        var copyAttemptId = target.getAttribute('data-attempt-id') || '';
        if (!copyAttemptId) {
          return;
        }
        copyBundle(panel, { attempt_id: copyAttemptId }, 'selected attempt');
        return;
      }
      if (target.classList.contains('vms-api-diag-download-row')) {
        evt.preventDefault();
        var downloadAttemptId = target.getAttribute('data-attempt-id') || '';
        if (!downloadAttemptId) {
          return;
        }
        downloadBundle(panel, { attempt_id: downloadAttemptId });
        return;
      }
      if (target.classList.contains('vms-api-diag-toggle-raw') && raw) {
        evt.preventDefault();
        var isHidden = raw.classList.toggle('vms-api-diag-hidden');
        target.setAttribute('aria-expanded', String(!isHidden));
      }
    });

  }

  document.addEventListener('DOMContentLoaded', function () {
    var refreshAll = function () {
      document.querySelectorAll('.vms-api-diag-panel').forEach(function (panel) {
        refreshPanel(panel);
      });
    };
    document.querySelectorAll('.vms-api-diag-panel').forEach(bindPanel);
    window.addEventListener('vms:api-attempt-updated', refreshAll);
    if (window.setInterval) {
      window.setInterval(refreshAll, 12000);
    }
  });
})();
