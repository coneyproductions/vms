(function () {
  'use strict';

  var cfg = window.vmsMaSettings || {};
  var wrap = document.getElementById('vms-ma-settings-wrap');
  if (!wrap) {
    return;
  }
 
  function setBusy(button, busyText) {
    if (!button) {
      return function () {};
    }
    var previous = button.value || button.textContent;
    button.disabled = true;
    if (typeof button.value !== 'undefined' && button.tagName === 'INPUT') {
      button.value = busyText;
    } else {
      button.textContent = busyText;
    }
    return function () {
      button.disabled = false;
      if (typeof button.value !== 'undefined' && button.tagName === 'INPUT') {
        button.value = previous;
      } else {
        button.textContent = previous;
      }
    };
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function fetchJson(url) {
    return fetch(url, {
      method: 'GET',
      headers: {
        'X-WP-Nonce': cfg.nonce || ''
      }
    }).then(function (res) {
      return res.json().catch(function () {
        return {};
      }).then(function (json) {
        if (!res.ok) {
          throw new Error((json && json.message) ? json.message : 'Request failed.');
        }
        return json;
      });
    });
  }

  function formatAgeHours(value) {
    var hours = parseInt(value, 10);
    if (!isFinite(hours)) {
      return 'Unknown';
    }
    if (hours < 1) {
      return 'Less than 1 hour ago';
    }
    if (hours < 24) {
      return hours + ' hour' + (hours === 1 ? '' : 's') + ' ago';
    }
    var days = Math.floor(hours / 24);
    return days + ' day' + (days === 1 ? '' : 's') + ' ago';
  }

  function renderList(items, emptyText) {
    if (!Array.isArray(items) || !items.length) {
      return '<p class="description">' + escapeHtml(emptyText || 'None') + '</p>';
    }
    return '<ul>' + items.map(function (item) {
      return '<li>' + escapeHtml(item) + '</li>';
    }).join('') + '</ul>';
  }

  function renderMetaRow(label, value, isCode) {
    var clean = String(value == null ? '' : value).trim();
    var display = clean !== '' ? clean : 'Not available';
    return '<div class="vms-ma-connection-status-row"><span>' + escapeHtml(label) + '</span><strong>' + (isCode ? '<code>' + escapeHtml(display) + '</code>' : escapeHtml(display)) + '</strong></div>';
  }

  function renderStatusBadge(state, label) {
    var safeState = String(state || 'warning').trim() || 'warning';
    return '<span class="vms-ma-connection-status-badge is-' + escapeHtml(safeState) + '">' + escapeHtml(label || safeState) + '</span>';
  }

  function connectionStatusPanel() {
    var refreshBtn = document.getElementById('vms-ma-connection-status-refresh');
    var inline = document.getElementById('vms-ma-connection-status-inline');
    var summary = document.getElementById('vms-ma-connection-status-summary');
    var grid = document.getElementById('vms-ma-connection-status-grid');
    var extra = document.getElementById('vms-ma-connection-status-extra');
    if (!refreshBtn || !inline || !summary || !grid || !extra) {
      return;
    }

    function setMessage(message, type) {
      inline.textContent = String(message || '');
      inline.classList.remove('is-error', 'is-success');
      if (type === 'error') {
        inline.classList.add('is-error');
      } else if (type === 'success') {
        inline.classList.add('is-success');
      }
    }

    function renderCard(title, state, intro, bodyHtml) {
      return '<section class="vms-ma-connection-status-card is-' + escapeHtml(state || 'warning') + '">' +
        '<div class="vms-ma-connection-status-card__head">' +
          '<h3>' + escapeHtml(title) + '</h3>' +
          renderStatusBadge(state, state === 'ready' ? 'Ready' : (state === 'error' ? 'Error' : 'Warning')) +
        '</div>' +
        (intro ? '<p class="description">' + escapeHtml(intro) + '</p>' : '') +
        '<div class="vms-ma-connection-status-card__body">' + bodyHtml + '</div>' +
      '</section>';
    }

    function renderSnapshot(data) {
      var snapshot = (data && typeof data === 'object') ? data : {};
      var summaryData = (snapshot.summary && typeof snapshot.summary === 'object') ? snapshot.summary : {};
      var inventory = (snapshot.inventory && typeof snapshot.inventory === 'object') ? snapshot.inventory : {};
      var token = (snapshot.token && typeof snapshot.token === 'object') ? snapshot.token : {};
      var permissions = (snapshot.permissions && typeof snapshot.permissions === 'object') ? snapshot.permissions : {};
      var assets = (snapshot.assets && typeof snapshot.assets === 'object') ? snapshot.assets : {};
      var account = (assets.ad_account && typeof assets.ad_account === 'object') ? assets.ad_account : {};
      var pageLookup = (assets.page_lookup && typeof assets.page_lookup === 'object') ? assets.page_lookup : {};
      var page = (assets.page && typeof assets.page === 'object') ? assets.page : {};
      var instagram = (assets.instagram && typeof assets.instagram === 'object') ? assets.instagram : {};
      var pixel = (assets.pixel && typeof assets.pixel === 'object') ? assets.pixel : {};
      var warnings = Array.isArray(snapshot.warnings) ? snapshot.warnings : [];
      var mismatches = Array.isArray(snapshot.mismatch_warnings) ? snapshot.mismatch_warnings : [];
      var lastDryRun = (snapshot.last_local_dry_run && typeof snapshot.last_local_dry_run === 'object') ? snapshot.last_local_dry_run : null;

      summary.innerHTML =
        '<div class="vms-ma-connection-status-summary__head">' +
          renderStatusBadge(summaryData.state || 'warning', summaryData.label || 'Status') +
          '<strong>' + escapeHtml(summaryData.note || '') + '</strong>' +
        '</div>' +
        renderList(Array.isArray(summaryData.reasons) ? summaryData.reasons : [], 'No extra notes.');
      summary.classList.remove('vms-ma-hidden');

      var cards = [];
      cards.push(renderCard(
        'Token',
        token.state || 'warning',
        token.reason || '',
        renderMetaRow('Saved token', token.redacted || 'Not available', false) +
        renderMetaRow('Token status', token.status_label || token.status || 'Unknown', false) +
        renderMetaRow('Last local verification', token.last_verified_gmt || 'Never', false) +
        renderMetaRow('Verification age', formatAgeHours(token.last_verified_age_hours), false) +
        renderMetaRow('Graph version', inventory.meta_graph_version || '', true)
      ));

      cards.push(renderCard(
        'Ad Account',
        account.state || 'warning',
        account.reachable ? 'Read-only account lookup succeeded.' : 'Stored ad account could not be confirmed with the current token.',
        renderMetaRow('Stored ID', account.stored_id || '', true) +
        renderMetaRow('Resolved ID', account.resolved_id || '', true) +
        renderMetaRow('Resolved name', account.resolved_name || '', false) +
        renderMetaRow('Timezone', account.timezone_name || '', false) +
        renderMetaRow('HTTP status', account.http_status || '', true)
      ));

      cards.push(renderCard(
        'Facebook Page',
        page.state || 'warning',
        page.reachable ? 'Direct page lookup succeeded.' : 'Stored page could not be confirmed directly.',
        renderMetaRow('Stored ID', page.stored_id || inventory.meta_page_id || '', true) +
        renderMetaRow('Resolved ID', page.resolved_id || '', true) +
        renderMetaRow('Resolved name', page.resolved_name || '', false) +
        renderMetaRow('Resolved slug', page.resolved_slug || inventory.facebook_page_slug || '', false) +
        renderMetaRow('Stored URL', inventory.facebook_page_url || '', false) +
        renderMetaRow('Connected IG ID', page.connected_ig_actor_id || '', true)
      ));

      cards.push(renderCard(
        'Instagram',
        instagram.state || 'warning',
        instagram.reachable ? 'Read-only Instagram account lookup succeeded.' : 'Stored Instagram account was not confirmed during this read-only check.',
        renderMetaRow('Stored ID', instagram.stored_id || inventory.meta_ig_actor_id || '', true) +
        renderMetaRow('Resolved ID', instagram.resolved_id || '', true) +
        renderMetaRow('Username', instagram.username || '', false) +
        renderMetaRow('Display name', instagram.name || '', false) +
        renderMetaRow('HTTP status', instagram.http_status || '', true)
      ));

      cards.push(renderCard(
        'Pixel',
        pixel.state || 'warning',
        pixel.lookup_ok ? 'Read-only pixel lookup under the ad account completed.' : 'Stored pixel could not be checked under the current ad account.',
        renderMetaRow('Stored ID', pixel.stored_id || inventory.meta_pixel_id || '', true) +
        renderMetaRow('Stored pixel found', pixel.stored_pixel_found ? 'Yes' : 'No', false) +
        renderMetaRow('Resolved name', pixel.stored_pixel && pixel.stored_pixel.name ? pixel.stored_pixel.name : '', false) +
        renderMetaRow('Pixel count on account', pixel.pixel_count || 0, true) +
        renderMetaRow('HTTP status', pixel.http_status || '', true)
      ));

      cards.push(renderCard(
        'Permissions',
        permissions.state || 'warning',
        'This is a read-only permission snapshot. Missing `pages_read_engagement` is shown here but is not currently blocking this panel.',
        renderMetaRow('Granted count', Array.isArray(permissions.granted) ? permissions.granted.length : 0, true) +
        '<div class="vms-ma-connection-status-group"><h4>Granted</h4>' + renderList(permissions.granted, 'No granted permissions returned.') + '</div>' +
        '<div class="vms-ma-connection-status-group"><h4>Missing relevant</h4>' + renderList(permissions.missing_relevant, 'None') + '</div>'
      ));

      cards.push(renderCard(
        'Page Discovery',
        pageLookup.state || 'warning',
        pageLookup.lookup_ok ? '`me/accounts` lookup succeeded.' : 'Meta page discovery did not complete.',
        renderMetaRow('Pages returned', pageLookup.page_count || 0, true) +
        renderMetaRow('Stored page found in `me/accounts`', pageLookup.stored_page_found ? 'Yes' : 'No', false) +
        renderMetaRow('Stored page name', pageLookup.stored_page && pageLookup.stored_page.name ? pageLookup.stored_page.name : '', false) +
        renderMetaRow('Stored page IG ID', pageLookup.stored_page && pageLookup.stored_page.ig_actor_id ? pageLookup.stored_page.ig_actor_id : '', true)
      ));

      grid.innerHTML = cards.join('');
      grid.classList.remove('vms-ma-hidden');

      var extraBits = [];
      extraBits.push('<section class="vms-ma-connection-status-notes">' +
        '<h3>Warnings and mismatches</h3>' +
        (warnings.length ? renderList(warnings, 'No warnings.') : '<p class="description">No warnings were returned by the read-only audit.</p>') +
        (mismatches.length ? '<div class="vms-ma-connection-status-group"><h4>Mismatch warnings</h4>' + renderList(mismatches, 'None') + '</div>' : '') +
      '</section>');

      if (lastDryRun) {
        extraBits.push('<section class="vms-ma-connection-status-notes">' +
          '<h3>Last local dry run</h3>' +
          renderMetaRow('Attempt ID', lastDryRun.id || '', true) +
          renderMetaRow('Created at', lastDryRun.created_at || '', false) +
          renderMetaRow('Operation', lastDryRun.operation || '', true) +
          renderMetaRow('Method', lastDryRun.method || '', true) +
          renderMetaRow('Endpoint', lastDryRun.endpoint || '', true) +
          renderMetaRow('HTTP status', lastDryRun.http_status || '', true) +
        '</section>');
      }

      extra.innerHTML = extraBits.join('');
      extra.classList.remove('vms-ma-hidden');
      setMessage('Read-only Meta Connection Status completed. No settings or Meta objects were changed.', 'success');
    }

    refreshBtn.addEventListener('click', function () {
      if (!cfg.metaConnectionStatusUrl || !cfg.nonce) {
        setMessage('The read-only status endpoint is not available on this screen yet.', 'error');
        return;
      }
      setMessage('Running a read-only Meta Connection Status check. No settings or Meta objects will be changed.');
      var restore = setBusy(refreshBtn, 'Checking...');
      fetchJson(cfg.metaConnectionStatusUrl).then(function (json) {
        renderSnapshot(json || {});
      }).catch(function (err) {
        setMessage((err && err.message) ? err.message : 'Read-only status check failed.', 'error');
      }).finally(function () {
        restore();
      });
    });
  }

  function testButtonState() {
    var testBtn = wrap.querySelector('input[name="vms_ma_test_connection"]');
    if (!testBtn) {
      return;
    }

    var form = testBtn.form;
    if (!form) {
      return;
    }

    form.addEventListener('submit', function (evt) {
      var submitter = evt.submitter || document.activeElement;
      var marker = form.querySelector('input[type="hidden"][name="vms_ma_test_connection"]');
      if (submitter !== testBtn) {
        if (marker) {
          marker.remove();
        }
        return;
      }
      if (!marker) {
        marker = document.createElement('input');
        marker.type = 'hidden';
        marker.name = 'vms_ma_test_connection';
        marker.value = '1';
        form.appendChild(marker);
      }
      setBusy(testBtn, 'Connecting...');
    });
  }

  function tokenControls() {
    var input = document.getElementById('vms-ma-token-input');
    var reveal = document.getElementById('vms-ma-token-reveal');
    var copy = document.getElementById('vms-ma-token-copy');
    if (!input || !reveal || !copy) {
      return;
    }

    function fetchToken() {
      if (!cfg.tokenInspectUrl || !cfg.nonce) {
        return Promise.resolve(null);
      }
      return fetch(cfg.tokenInspectUrl, {
        method: 'GET',
        headers: {
          'X-WP-Nonce': cfg.nonce
        }
      }).then(function (res) {
        if (!res.ok) {
          return null;
        }
        return res.json();
      }).catch(function () {
        return null;
      });
    }

    reveal.addEventListener('click', function () {
      var isPassword = input.getAttribute('type') === 'password';
      if (!isPassword) {
        input.setAttribute('type', 'password');
        reveal.textContent = 'Reveal';
        return;
      }

      var restore = setBusy(reveal, 'Loading...');
      fetchToken().then(function (json) {
        if (!json || !json.present || !json.token) {
          restore();
          return;
        }
        input.value = String(json.token);
        input.setAttribute('type', 'text');
        reveal.textContent = 'Hide';
        restore();
      });
    });

    copy.addEventListener('click', function () {
      var value = String(input.value || '').trim();
      if (!value || !navigator.clipboard) {
        return;
      }
      navigator.clipboard.writeText(value).catch(function () {
        return null;
      });
    });
  }

  function pageLookupControls() {
    var lookupBtn = document.getElementById('vms-ma-pages-lookup');
    var select = document.getElementById('vms-ma-pages-select');
    var status = document.getElementById('vms-ma-pages-status');
    var pageInput = wrap.querySelector('input[name="meta_page_id"]');
    var pageUrlInput = wrap.querySelector('input[name="facebook_page_url"]');
    var pageUrlBtn = document.getElementById('vms-ma-page-url-resolve');
    var igInput = wrap.querySelector('input[name="meta_ig_actor_id"]');
    var adAccountInput = wrap.querySelector('input[name="meta_ad_account_id"]');
    var tokenInput = document.getElementById('vms-ma-token-input');
    var revealBtn = document.getElementById('vms-ma-token-reveal');
    if (!lookupBtn || !select || !pageInput) {
      return;
    }

    function showStatus(message, type) {
      if (!status) {
        return;
      }
      status.textContent = String(message || '');
      status.classList.remove('is-error', 'is-success');
      if (type === 'error') {
        status.classList.add('is-error');
      } else if (type === 'success') {
        status.classList.add('is-success');
      }
    }

    function fillChosenOption(chosen) {
      if (!chosen || !chosen.value) {
        return;
      }
      pageInput.value = String(chosen.value);
      if (igInput) {
        igInput.value = String(chosen.getAttribute('data-ig-actor-id') || '');
      }
    }

    function fillResolvedItem(item) {
      if (!item || !item.id) {
        return;
      }
      pageInput.value = String(item.id || '');
      if (igInput) {
        igInput.value = String(item.ig_actor_id || '');
      }
    }

    function fetchPages() {
      if (!cfg.metaPagesUrl || !cfg.nonce) {
        return Promise.reject(new Error('Lookup is not ready on this screen yet.'));
      }
      return fetch(cfg.metaPagesUrl, {
        method: 'GET',
        headers: {
          'X-WP-Nonce': cfg.nonce
        }
      }).then(function (res) {
        return res.json().then(function (json) {
          if (!res.ok) {
            throw new Error((json && json.message) ? json.message : 'Page lookup failed.');
          }
          var items = (json && Array.isArray(json.items)) ? json.items : [];
          return items;
        });
      });
    }

    function resolvePageReference(pageRef) {
      if (!cfg.metaPageResolveUrl || !cfg.nonce) {
        return Promise.reject(new Error('Page resolver is not ready on this screen yet.'));
      }
      var url = new URL(cfg.metaPageResolveUrl, window.location.origin);
      url.searchParams.set('page_ref', String(pageRef || ''));
      return fetch(url.toString(), {
        method: 'GET',
        headers: {
          'X-WP-Nonce': cfg.nonce
        }
      }).then(function (res) {
        return res.json().then(function (json) {
          if (!res.ok) {
            throw new Error((json && json.message) ? json.message : 'Page validation failed.');
          }
          return (json && json.item) ? json.item : null;
        });
      });
    }

    function requireSavedCredentials() {
      var savedTokenPresent = revealBtn && revealBtn.getAttribute('data-token-present') === '1';
      var hasUnsavedToken = tokenInput && String(tokenInput.value || '').trim() !== '';
      var hasAdAccount = adAccountInput && String(adAccountInput.value || '').trim() !== '';

      if (!hasAdAccount) {
        showStatus('Enter your Meta Ad Account ID first, then save settings.', 'error');
        select.classList.add('vms-ma-hidden');
        return false;
      }
      if (!savedTokenPresent && !hasUnsavedToken) {
        showStatus('Add your Meta Access Token first, then click Save Settings before using lookup.', 'error');
        select.classList.add('vms-ma-hidden');
        return false;
      }
      if (hasUnsavedToken) {
        showStatus('Lookup uses the saved token. Click Save Settings first if you just pasted a new token.', 'error');
        select.classList.add('vms-ma-hidden');
        return false;
      }
      return true;
    }

    lookupBtn.addEventListener('click', function () {
      if (!requireSavedCredentials()) {
        return;
      }

      showStatus('Looking up Pages from Meta…');
      var restore = setBusy(lookupBtn, 'Loading...');
      fetchPages().then(function (items) {
        select.innerHTML = '';
        if (!items.length) {
          select.classList.add('vms-ma-hidden');
          showStatus('Meta did not return any Pages. Your token may be able to run ads but not list Pages. Paste your Facebook Page URL below and click Use Page URL to fill IDs.', 'error');
          return;
        }
        if (items.length === 1) {
          var item = items[0] || {};
          var only = new Option(String(item.name || ('Page ' + item.id)) + ' (' + String(item.id || '') + ')', String(item.id || ''));
          only.setAttribute('data-ig-actor-id', String(item.ig_actor_id || ''));
          select.appendChild(only);
          fillChosenOption(only);
          select.classList.add('vms-ma-hidden');
          if (String(item.ig_actor_id || '').trim() !== '') {
            showStatus('Found 1 Page and filled both Facebook and Instagram for you.', 'success');
          } else {
            showStatus('Found 1 Page and filled the Facebook Page ID for you. Instagram was not returned for that Page.', 'success');
          }
          return;
        }
        select.appendChild(new Option('Select a Page...', ''));
        items.forEach(function (item) {
          var label = String(item.name || ('Page ' + item.id));
          var opt = new Option(label + ' (' + item.id + ')', String(item.id || ''));
          opt.setAttribute('data-ig-actor-id', String(item.ig_actor_id || ''));
          select.appendChild(opt);
        });
        select.classList.remove('vms-ma-hidden');
        showStatus('Meta found ' + items.length + ' Pages. Pick the correct one from the list below.');
      }).catch(function (err) {
        select.classList.add('vms-ma-hidden');
        showStatus((err && err.message) ? err.message : 'Page lookup failed.', 'error');
      }).finally(function () {
        restore();
      });
    });

    select.addEventListener('change', function () {
      var chosen = select.options[select.selectedIndex] || null;
      if (!chosen || !chosen.value) {
        return;
      }
      fillChosenOption(chosen);
      if (String(chosen.getAttribute('data-ig-actor-id') || '').trim() !== '') {
        showStatus('Filled the Facebook Page ID and Instagram account for you.', 'success');
      } else {
        showStatus('Filled the Facebook Page ID for you. Instagram was not returned for that Page.', 'success');
      }
    });

    if (pageUrlBtn) {
      pageUrlBtn.addEventListener('click', function () {
        if (!requireSavedCredentials()) {
          return;
        }
        var pageRef = '';
        if (pageInput && String(pageInput.value || '').trim() !== '') {
          pageRef = String(pageInput.value || '').trim();
        } else if (pageUrlInput && String(pageUrlInput.value || '').trim() !== '') {
          pageRef = String(pageUrlInput.value || '').trim();
        }

        if (!pageRef) {
          showStatus('Paste your Facebook Page URL or Page ID first, then click this button.', 'error');
          return;
        }

        showStatus('Checking that Facebook Page with Meta…');
        var restore = setBusy(pageUrlBtn, 'Checking...');
        resolvePageReference(pageRef).then(function (item) {
          if (!item || !item.id) {
            throw new Error('Meta did not return a usable Facebook Page ID.');
          }
          fillResolvedItem(item);
          select.classList.add('vms-ma-hidden');
          if (String(item.ig_actor_id || '').trim() !== '') {
            showStatus('Success. Filled both the Facebook Page ID and Instagram account from that Page.', 'success');
          } else {
            showStatus('Success. Filled the Facebook Page ID. Instagram was not returned for that Page.', 'success');
          }
        }).catch(function (err) {
          showStatus((err && err.message) ? err.message : 'Could not validate that Facebook Page.', 'error');
        }).finally(function () {
          restore();
        });
      });
    }
  }

  testButtonState();
  tokenControls();
  pageLookupControls();
  connectionStatusPanel();
})();
