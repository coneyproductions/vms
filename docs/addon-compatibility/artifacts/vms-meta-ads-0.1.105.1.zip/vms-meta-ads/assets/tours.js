(function () {
  'use strict';

  var cfg = window.vmsMaTour || {};
  var tours = window.vmsMaTours || {};
  var engine = window.VMS_Tour || {};
  var guidanceCfg = window.vmsMaGuidance || {};
  var defaults = window.vmsMaDefaults || {};
  function resolveFieldElement(target) {
    if (!target) {
      return null;
    }
    if (typeof target === 'string') {
      return document.querySelector(target);
    }
    if (target instanceof Element) {
      return target;
    }
    return null;
  }

  function fallbackFieldHasNonDefault(target, defaultValue) {
    var el = resolveFieldElement(target);
    if (!el) {
      return false;
    }

    var value = '';
    if (el.type === 'checkbox') {
      value = el.checked ? '1' : '0';
    } else if (el.type === 'radio') {
      var scope = el.closest('form') || document;
      var checked = el.checked ? el : scope.querySelector('input[type="radio"][name="' + (el.name || '') + '"]:checked');
      value = checked ? String(checked.value || '').trim() : '';
    } else if (el.hasAttribute('data-token-present')) {
      value = String(el.getAttribute('data-token-present') || '').trim();
    } else if (typeof el.value !== 'undefined') {
      value = String(el.value || '').trim();
    } else {
      value = String(el.textContent || '').trim();
    }

    var normalizedDefault = defaultValue;
    if (normalizedDefault === null || typeof normalizedDefault === 'undefined') {
      normalizedDefault = '';
    }

    if (typeof normalizedDefault === 'number') {
      var numeric = parseFloat(value);
      return Number.isFinite(numeric) && numeric !== normalizedDefault;
    }

    return value !== String(normalizedDefault).trim();
  }

  var fieldHasNonDefault = typeof window.vmsMaFieldHasNonDefault === 'function'
    ? window.vmsMaFieldHasNonDefault
    : fallbackFieldHasNonDefault;

  var builderWrap = document.getElementById('vms-ma-ads-builder-wrap');
  var settingsWrap = document.getElementById('vms-ma-settings-wrap');
  var screen = cfg.screen || (settingsWrap ? 'settings' : 'builder');
  var wrap = screen === 'settings' ? settingsWrap : builderWrap;
  if (!wrap) {
    return;
  }

  var isBuilderScreen = screen === 'builder';

  var legacySkipRules = {
    A: [{ selector: '#vms-ma-event-plan-picker', defaultValue: '' }],
    B: [{ selector: '#vms-ma-preset-mode', defaultKey: 'preset' }],
    D: [
      { selector: '#vms-ma-radius', defaultKey: 'radius' },
      { selector: '#vms-ma-age-min', defaultKey: 'age_min' },
      { selector: '#vms-ma-age-max', defaultKey: 'age_max' }
    ],
    E: [{ selector: '#vms-ma-budget-total', defaultValue: '' }],
    F: [{ selector: '#vms-ma-copy-pack', defaultValue: '' }]
  };

  function buildFallbackTourConfig(activeScreen) {
    // 0.1.71 hardening: 0.1.70 intentionally kept Meta Ads tours out of the
    // global VMS tour catalog to stop unwanted auto-launches. On some installs,
    // that also means the localized vmsMaTours payload can be absent even though
    // the local Start tour button and VMS_MA.tourSteps payload are present. Keep
    // the manual tour usable by reconstructing a small local builder tour from
    // the existing VMS_MA.tourSteps payload instead of silently no-oping.
    if (activeScreen !== 'builder') {
      return null;
    }
    var ma = window.VMS_MA || {};
    var steps = Array.isArray(ma.tourSteps) ? ma.tourSteps : [];
    if (!steps.length) {
      return null;
    }
    return {
      tourId: 'vms_ma_ads_builder_v1',
      steps: steps.map(function (step) {
        var html = step.content || step.html || step.html_standard || step.htmlStandard || '';
        return {
          selector: step.selector || '',
          step_key: step.step_key || step.stepKey || '',
          title: step.title || '',
          html: html,
          html_standard: html,
          prefer_edge: step.prefer_edge || step.prefer || 'right',
          skip_when_filled: Array.isArray(step.skip_when_filled) ? step.skip_when_filled : []
        };
      }).filter(function (step) {
        return step.selector && step.title;
      })
    };
  }

  var tourConfig = tours[screen] || buildFallbackTourConfig(screen) || null;
  if (!tourConfig || !Array.isArray(tourConfig.steps) || !tourConfig.steps.length) {
    return;
  }
  if (!tours[screen] && screen === 'builder') {
    window.vmsMaTours = window.vmsMaTours || {};
    window.vmsMaTours.builder = tourConfig;
  }

  var startButtonId = screen === 'settings' ? 'vms-ma-settings-start-tour' : 'vms-ma-start-tour';
  var toggleId = screen === 'settings' ? 'vms-ma-settings-tour-autorun-toggle' : 'vms-ma-tour-autorun-toggle';
  var guidanceSelectId = screen === 'settings' ? 'vms-ma-settings-guidance-level' : 'vms-ma-guidance-level';
  var startButton = document.getElementById(startButtonId);
  var toggle = document.getElementById(toggleId);
  var guidanceSelect = document.getElementById(guidanceSelectId);
  function getGuidanceLevel() {
    var level = guidanceCfg.guidanceLevel || cfg.guidance || 'beginner';
    level = String(level || '').toLowerCase();
    if (level !== 'beginner' && level !== 'standard' && level !== 'expert') {
      return 'beginner';
    }
    return level;
  }

  var guidance = getGuidanceLevel();
  wrap.setAttribute('data-guidance-level', guidance);
  var snoozedForLoad = false;
  var resumeKey = 'vms_ma_tour_resume_' + screen;
  var urlParams = (function () {
    try {
      return new URLSearchParams(window.location.search || '');
    } catch (e) {
      return new URLSearchParams('');
    }
  })();
  var queryTour = parseInt(String(urlParams.get('tour') || wrap.getAttribute('data-tour-query') || '0'), 10) === 1;
  var queryPrefill = parseInt(String(urlParams.get('prefill') || wrap.getAttribute('data-prefill') || '0'), 10) === 1;
  var queryScrollTo = String(urlParams.get('scroll_to') || wrap.getAttribute('data-scroll-to') || '').toLowerCase();

  function setSnooze() {
    snoozedForLoad = true;
  }

  function clearSnooze() {
    snoozedForLoad = false;
  }

  function isSnoozed() {
    return snoozedForLoad;
  }

  function persistPref(payload) {
    if (!cfg.restUrl || !cfg.nonce) {
      return Promise.resolve(false);
    }
    return fetch(cfg.restUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': cfg.nonce
      },
      body: JSON.stringify(payload || {})
    }).then(function () {
      if (payload && Object.prototype.hasOwnProperty.call(payload, 'autorun')) {
        cfg.autorun = payload.autorun ? 1 : 0;
      }
      if (payload && payload.guidance_level) {
        guidanceCfg.guidanceLevel = payload.guidance_level;
        cfg.guidance = payload.guidance_level;
      }
      return true;
    }).catch(function () {
      return false;
    });
  }

  function getStepHtml(step, guidanceLevel) {
    var safeStep = step || {};
    var html = '';
    var isBeginnerFallback = false;
    if (guidanceLevel === 'beginner' && (safeStep.html_beginner || safeStep.htmlBeginner)) {
      html = safeStep.html_beginner || safeStep.htmlBeginner;
    }
    if (!html && guidanceLevel === 'standard' && (safeStep.html_standard || safeStep.htmlStandard)) {
      html = safeStep.html_standard || safeStep.htmlStandard;
    }
    if (!html && guidanceLevel === 'expert' && (safeStep.html_expert || safeStep.htmlExpert)) {
      html = safeStep.html_expert || safeStep.htmlExpert;
    }
    if (!html && safeStep.html) {
      html = safeStep.html;
    }
    if (!html && (safeStep.html_standard || safeStep.htmlStandard)) {
      html = safeStep.html_standard || safeStep.htmlStandard;
      isBeginnerFallback = guidanceLevel === 'beginner';
    }
    if (!html && (safeStep.html_beginner || safeStep.htmlBeginner)) {
      html = safeStep.html_beginner || safeStep.htmlBeginner;
    }
    if (isBeginnerFallback && html) {
      return linkifyHtml('<p class="vms-ma-tour-fallback-note"><strong>Beginner tip</strong></p>' + html);
    }
    return linkifyHtml(html || '');
  }

  function linkifyHtml(html) {
    if (!html || typeof html !== 'string') {
      return html;
    }

    var template = document.createElement('template');
    template.innerHTML = html;

    var walker = document.createTreeWalker(
      template.content,
      NodeFilter.SHOW_TEXT,
      null
    );

    var nodes = [];
    var node;
    while ((node = walker.nextNode())) {
      nodes.push(node);
    }

    nodes.forEach(function (textNode) {
      if (!textNode || !textNode.nodeValue) {
        return;
      }

      var parent = textNode.parentElement;
      if (!parent) {
        return;
      }

      if (parent.closest('a,script,style,textarea,code,pre')) {
        return;
      }

      var frag = vmsMaLinkifyTextToFragment(textNode.nodeValue, textNode.ownerDocument || document);
      if (frag) {
        textNode.replaceWith(frag);
      }
    });

    return template.innerHTML;
  }

  function vmsMaLinkifyTextToFragment(text, doc) {
    var re = /(https?:\/\/[^\s<]+)|((?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,})(\/[^\s<]*)?/ig;

    var match;
    var lastIndex = 0;
    var changed = false;

    var frag = doc.createDocumentFragment();

    while ((match = re.exec(text)) !== null) {
      var raw = match[0];
      var start = match.index;

      var charBefore = start > 0 ? text[start - 1] : '';
      if (charBefore === '@') {
        continue;
      }

      if (start > lastIndex) {
        frag.appendChild(doc.createTextNode(text.slice(lastIndex, start)));
      }

      var display = '';
      var href = '';

      if (match[1]) {
        display = match[1];
        href = match[1];
      } else {
        display = match[2] + (match[3] || '');
        href = 'https://' + display;
      }

      var split = vmsMaSplitTrailingPunct(display);
      var displayTrimmed = split.text;
      var trailing = split.trailing;

      var hrefTrimmed = href.endsWith(display)
        ? href.slice(0, href.length - display.length) + displayTrimmed
        : href.replace(display, displayTrimmed);

      var a = doc.createElement('a');
      a.href = hrefTrimmed;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.textContent = displayTrimmed;

      frag.appendChild(a);

      if (trailing) {
        frag.appendChild(doc.createTextNode(trailing));
      }

      lastIndex = start + raw.length;
      changed = true;
    }

    if (!changed) {
      return null;
    }

    if (lastIndex < text.length) {
      frag.appendChild(doc.createTextNode(text.slice(lastIndex)));
    }

    return frag;
  }

  function vmsMaSplitTrailingPunct(str) {
    var punct = ".,;:!?)\\]}>\"'’";
    var trailing = '';
    var text = str;

    while (text.length > 0 && punct.indexOf(text.slice(-1)) !== -1) {
      trailing = text.slice(-1) + trailing;
      text = text.slice(0, -1);
    }

    return { text: text, trailing: trailing };
  }

  function getDefaultForRule(rule) {
    if (!rule) {
      return '';
    }
    if (Object.prototype.hasOwnProperty.call(rule, 'defaultValue')) {
      return rule.defaultValue;
    }
    if (rule.defaultKey && typeof defaults[rule.defaultKey] !== 'undefined') {
      return defaults[rule.defaultKey];
    }
    return '';
  }

  function isStepLocked(step) {
    if (!step || !step.selector) {
      return true;
    }
    var target = document.querySelector(step.selector);
    if (!target) {
      return true;
    }
    var parent = target.closest('.vms-ma-step');
    if (!parent) {
      return false;
    }
    var statusEl = parent.querySelector('[data-step-status]');
    if (!statusEl) {
      return false;
    }
    var text = String(statusEl.textContent || '').toLowerCase();
    return text.indexOf('locked') !== -1;
  }

  function shouldSkipTourStep(step) {
    if (guidance !== 'beginner' || !step) {
      return false;
    }
    if (isBuilderScreen && isStepLocked(step)) {
      return true;
    }
    var metaRules = Array.isArray(step.skipWhenFilled) ? step.skipWhenFilled : [];
    if (metaRules.length) {
      return metaRules.every(function (rule) {
        var selector = rule.selector || step.selector;
        var defaultValue = getDefaultForRule(rule);
        return fieldHasNonDefault(selector, defaultValue);
      });
    }
    var key = String(step.stepKey || deriveStepKeyFromSelector(step.selector)).toUpperCase();
    if (!key) {
      return true;
    }
    var rules = legacySkipRules[key] || [];
    if (!rules.length) {
      return false;
    }
    return rules.every(function (rule) {
      var selector = rule.selector || step.selector;
      var defaultValue = getDefaultForRule(rule);
      return fieldHasNonDefault(selector, defaultValue);
    });
  }

  function resolveSteps() {
    guidance = getGuidanceLevel();
    wrap.setAttribute('data-guidance-level', guidance);
    var resolved = [];
    tourConfig.steps.forEach(function (step) {
      var resolvedStep = {
        selector: step.selector,
        stepKey: String(step.step_key || step.stepKey || '').toUpperCase(),
        title: step.title,
        html: getStepHtml(step, guidance),
        prefer: step.prefer_edge || step.prefer || 'right',
        revealAdvanced: !!(step.reveal_advanced || step.revealAdvanced),
        skipWhenFilled: Array.isArray(step.skip_when_filled)
          ? step.skip_when_filled
          : (Array.isArray(step.skipWhenFilled) ? step.skipWhenFilled : [])
      };
      if (!shouldSkipTourStep(resolvedStep)) {
        resolved.push(resolvedStep);
      }
    });
    return resolved;
  }

  function emitTourToast(message) {
    if (!message) {
      return;
    }
    document.dispatchEvent(new CustomEvent('vms-ma-toast', {
      detail: {
        type: 'warning',
        message: String(message)
      }
    }));
  }

  function deriveStepKeyFromSelector(selector) {
    if (!selector) {
      return '';
    }
    var target = document.querySelector(selector);
    if (!target) {
      return '';
    }
    var stepEl = target.closest('.vms-ma-step');
    if (!stepEl) {
      return '';
    }
    return String(stepEl.getAttribute('data-step-key') || '').toUpperCase();
  }

  function shouldRevealAdvancedForStep(step) {
    if (!step || !step.selector) {
      return false;
    }
    if (step.revealAdvanced) {
      return true;
    }
    var target = document.querySelector(step.selector);
    return !!(target && target.closest('[data-advanced=\"1\"]'));
  }

  function prepareStepVisibility(step) {
    if (screen !== 'builder' || !window.vmsMaStepper || !step) {
      return;
    }
    var key = String(step.stepKey || deriveStepKeyFromSelector(step.selector)).toUpperCase();
    if (key) {
      window.vmsMaStepper.expand(key);
      if (shouldRevealAdvancedForStep(step)) {
        window.vmsMaStepper.showAdvanced(key);
      }
    }
  }

  function ensureVisible(selector, stepKey, needsAdvanced) {
    if (screen !== 'builder' || !window.vmsMaStepper) {
      return Promise.resolve(false);
    }
    var key = String(stepKey || deriveStepKeyFromSelector(selector)).toUpperCase();
    if (key) {
      window.vmsMaStepper.expand(key);
      if (needsAdvanced) {
        window.vmsMaStepper.showAdvanced(key);
      }
    }

    return new Promise(function (resolve) {
      var start = Date.now();
      var maxMs = 1500;

      function check() {
        var target = selector ? document.querySelector(selector) : null;
        if (target) {
          if (typeof target.scrollIntoView === 'function') {
            target.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
          }
          resolve(true);
          return;
        }
        if ((Date.now() - start) >= maxMs) {
          emitTourToast('Tour skipped a step because the field is not available yet.');
          resolve(false);
          return;
        }
        window.setTimeout(check, 50);
      }

      check();
    });
  }

  function scrollStepAIfRequested() {
    if (screen !== 'builder' || queryScrollTo !== 'stepa' || !window.vmsMaStepper) {
      return;
    }
    window.vmsMaStepper.expand('A');
    window.vmsMaStepper.scrollTo('#vms-ma-step-a');
  }

  function saveResumeState(stepIndex, inProgress) {
    try {
      localStorage.setItem(resumeKey, JSON.stringify({
        tourId: tourConfig.tourId || ('vms_ma_' + screen + '_tour'),
        stepIndex: Math.max(0, parseInt(stepIndex || 0, 10)),
        guidance: guidance,
        inProgress: !!inProgress
      }));
    } catch (e) {
      // no-op
    }
  }

  function getResumeState() {
    try {
      var raw = localStorage.getItem(resumeKey);
      if (!raw) {
        return null;
      }
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object') {
        return null;
      }
      return parsed;
    } catch (e) {
      return null;
    }
  }

  function clearResumeState() {
    try {
      localStorage.removeItem(resumeKey);
    } catch (e) {
      // no-op
    }
  }

  function stripHtml(html) {
    var tmp = document.createElement('div');
    tmp.innerHTML = html || '';
    return tmp.textContent || tmp.innerText || '';
  }

  function startWithCoreEngine(resolvedSteps, activeStepIndex, resumeIndex) {
    if (!engine || typeof engine.start !== 'function') {
      return false;
    }
    engine.start({
      tourId: tourConfig.tourId || ('vms_ma_' + screen + '_tour'),
      steps: resolvedSteps,
      options: {
        persistentAutorun: true,
        allowClose: true,
        showProgress: true,
        showPrev: true,
        scrollIntoView: true,
        startIndex: Number.isInteger(resumeIndex) && resumeIndex > 0 ? resumeIndex : 0
      },
      onStepChange: function (idx) {
        activeStepIndex = Math.max(0, parseInt(idx || 0, 10));
        if (resolvedSteps[activeStepIndex]) {
          var current = resolvedSteps[activeStepIndex];
          prepareStepVisibility(current);
          ensureVisible(current.selector, current.stepKey, shouldRevealAdvancedForStep(current));
        }
        saveResumeState(idx, true);
      },
      onFinish: function () {
        setSnooze();
        clearResumeState();
        document.dispatchEvent(new CustomEvent('vms-ma-tour-closed'));
      },
      onClose: function () {
        setSnooze();
        saveResumeState(activeStepIndex, true);
        document.dispatchEvent(new CustomEvent('vms-ma-tour-closed'));
      }
    });
    return true;
  }

  function getDriverFactory() {
    if (window.driver && window.driver.js && typeof window.driver.js.driver === 'function') {
      return window.driver.js.driver;
    }
    if (window.Driver && typeof window.Driver === 'function') {
      return window.Driver;
    }
    if (window.driver && typeof window.driver === 'function') {
      return window.driver;
    }
    return null;
  }

  function startWithDriverJs(resolvedSteps, activeStepIndex, resumeIndex) {
    var factory = getDriverFactory();
    if (!factory) {
      return false;
    }
    try {
      var startIndex = Number.isInteger(resumeIndex) && resumeIndex > 0 ? resumeIndex : 0;
      var driverSteps = resolvedSteps.map(function (step) {
        return {
          element: step.selector,
          popover: {
            title: step.title || '',
            description: step.html || '',
            side: step.prefer || 'right',
            align: 'start'
          }
        };
      });
      var instance = factory({
        showProgress: true,
        allowClose: true,
        steps: driverSteps,
        onDestroyed: function () {
          setSnooze();
          clearResumeState();
          document.dispatchEvent(new CustomEvent('vms-ma-tour-closed'));
        },
        onHighlightStarted: function (element, step, opts) {
          var idx = opts && typeof opts.state !== 'undefined' && typeof opts.state.activeIndex !== 'undefined'
            ? parseInt(opts.state.activeIndex, 10)
            : 0;
          activeStepIndex = Number.isFinite(idx) ? idx : activeStepIndex;
          saveResumeState(activeStepIndex, true);
        }
      });
      if (instance && typeof instance.drive === 'function') {
        instance.drive(startIndex);
        return true;
      }
      if (instance && typeof instance.start === 'function') {
        instance.start(startIndex);
        return true;
      }
    } catch (e) {
      // Fall through to the local tour renderer below.
    }
    return false;
  }

  function removeLocalTour() {
    var existing = document.getElementById('vms-ma-local-tour');
    if (existing && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }
    document.documentElement.classList.remove('vms-ma-local-tour-active');
  }

  function positionLocalPopover(popover, target) {
    if (!popover || !target || typeof target.getBoundingClientRect !== 'function') {
      return;
    }
    var rect = target.getBoundingClientRect();
    var maxLeft = Math.max(16, window.innerWidth - popover.offsetWidth - 16);
    var left = Math.min(Math.max(16, rect.left + window.scrollX), maxLeft);
    var top = rect.bottom + window.scrollY + 14;
    if (top + popover.offsetHeight > window.scrollY + window.innerHeight - 16) {
      top = Math.max(window.scrollY + 16, rect.top + window.scrollY - popover.offsetHeight - 14);
    }
    popover.style.left = left + 'px';
    popover.style.top = top + 'px';
  }

  function startWithLocalTour(resolvedSteps, activeStepIndex) {
    removeLocalTour();
    var idx = Math.max(0, Math.min(activeStepIndex || 0, resolvedSteps.length - 1));
    var shell = document.createElement('div');
    shell.id = 'vms-ma-local-tour';
    shell.className = 'vms-ma-local-tour';
    shell.innerHTML = '<div class="vms-ma-local-tour-backdrop" data-tour-close="1"></div>'
      + '<div class="vms-ma-local-tour-popover" role="dialog" aria-modal="true" aria-live="polite">'
      + '<button type="button" class="vms-ma-local-tour-close" aria-label="Close tour">×</button>'
      + '<div class="vms-ma-local-tour-progress"></div>'
      + '<h3 class="vms-ma-local-tour-title"></h3>'
      + '<div class="vms-ma-local-tour-body"></div>'
      + '<div class="vms-ma-local-tour-actions">'
      + '<button type="button" class="button vms-ma-local-tour-prev">Back</button>'
      + '<button type="button" class="button button-primary vms-ma-local-tour-next">Next</button>'
      + '</div></div>';
    document.body.appendChild(shell);
    document.documentElement.classList.add('vms-ma-local-tour-active');

    var popover = shell.querySelector('.vms-ma-local-tour-popover');
    var progress = shell.querySelector('.vms-ma-local-tour-progress');
    var title = shell.querySelector('.vms-ma-local-tour-title');
    var body = shell.querySelector('.vms-ma-local-tour-body');
    var prev = shell.querySelector('.vms-ma-local-tour-prev');
    var next = shell.querySelector('.vms-ma-local-tour-next');
    var close = shell.querySelector('.vms-ma-local-tour-close');

    function finish(saveProgress) {
      if (saveProgress) {
        saveResumeState(idx, true);
      } else {
        clearResumeState();
      }
      setSnooze();
      removeLocalTour();
      document.dispatchEvent(new CustomEvent('vms-ma-tour-closed'));
    }

    function render() {
      var step = resolvedSteps[idx];
      if (!step) {
        finish(false);
        return;
      }
      prepareStepVisibility(step);
      ensureVisible(step.selector, step.stepKey, shouldRevealAdvancedForStep(step)).then(function () {
        var target = document.querySelector(step.selector);
        progress.textContent = 'Step ' + (idx + 1) + ' of ' + resolvedSteps.length;
        title.textContent = step.title || 'Tour step';
        body.innerHTML = step.html || '<p>' + stripHtml(step.title || '') + '</p>';
        prev.disabled = idx === 0;
        next.textContent = idx >= resolvedSteps.length - 1 ? 'Done' : 'Next';
        saveResumeState(idx, true);
        if (target && target.classList) {
          target.classList.add('vms-ma-local-tour-target');
          window.setTimeout(function () {
            target.classList.remove('vms-ma-local-tour-target');
          }, 450);
        }
        positionLocalPopover(popover, target || wrap);
      });
    }

    prev.addEventListener('click', function () {
      idx = Math.max(0, idx - 1);
      render();
    });
    next.addEventListener('click', function () {
      if (idx >= resolvedSteps.length - 1) {
        finish(false);
        return;
      }
      idx += 1;
      render();
    });
    close.addEventListener('click', function () {
      finish(true);
    });
    shell.addEventListener('click', function (evt) {
      if (evt.target && evt.target.getAttribute('data-tour-close') === '1') {
        finish(true);
      }
    });
    window.addEventListener('resize', function () {
      var step = resolvedSteps[idx];
      positionLocalPopover(popover, step ? document.querySelector(step.selector) : wrap);
    }, { passive: true });
    render();
    return true;
  }

  function startTour(options) {
    var opts = options || {};
    clearSnooze();
    if (!opts.resume) {
      clearResumeState();
    }
    var resumeState = opts.resume ? getResumeState() : null;
    var resumeIndex = resumeState && typeof resumeState.stepIndex !== 'undefined'
      ? parseInt(resumeState.stepIndex, 10)
      : 0;
    var activeStepIndex = Number.isInteger(resumeIndex) ? resumeIndex : 0;
    var resolvedSteps = resolveSteps();
    if (!resolvedSteps.length) {
      emitTourToast('The tour could not start because no available steps were found on this screen.');
      return;
    }
    if (resolvedSteps[activeStepIndex]) {
      var first = resolvedSteps[activeStepIndex];
      prepareStepVisibility(first);
      ensureVisible(first.selector, first.stepKey, shouldRevealAdvancedForStep(first));
    }
    document.dispatchEvent(new CustomEvent('vms-ma-tour-opened'));
    if (startWithCoreEngine(resolvedSteps, activeStepIndex, resumeIndex)) {
      return;
    }
    if (startWithDriverJs(resolvedSteps, activeStepIndex, resumeIndex)) {
      return;
    }
    startWithLocalTour(resolvedSteps, activeStepIndex);
  }

  if (startButton) {
    startButton.addEventListener('click', function () {
      startTour({ resume: false });
    });
  }

  function getAutorunAttrValue() {
    var attr = wrap.getAttribute('data-tour-autorun');
    if (attr === '1' || attr === '0') {
      return parseInt(attr, 10);
    }
    return cfg.autorun != null ? parseInt(String(cfg.autorun), 10) : 0;
  }

  if (toggle) {
    toggle.checked = getAutorunAttrValue() === 1;
    toggle.addEventListener('change', function () {
      var enabled = !!toggle.checked;
      persistPref({ autorun: enabled ? 1 : 0 });
      wrap.setAttribute('data-tour-autorun', enabled ? '1' : '0');
      if (enabled) {
        clearSnooze();
      } else {
        setSnooze();
      }
    });
  }

  if (guidanceSelect) {
    guidanceSelect.value = guidance;
  }

  document.addEventListener('vms-ma-guidance-updated', function (evt) {
    var nextLevel = evt && evt.detail ? String(evt.detail.level || '') : '';
    if (nextLevel !== 'beginner' && nextLevel !== 'standard' && nextLevel !== 'expert') {
      return;
    }
    guidance = nextLevel;
    wrap.setAttribute('data-guidance-level', guidance);
    if (guidanceSelect) {
      guidanceSelect.value = guidance;
    }
  });

  var autorun = getAutorunAttrValue() === 1;
  if (!queryTour && (queryPrefill || wrap.getAttribute('data-tour-autorun') === '0')) {
    autorun = false;
    setSnooze();
  }
  scrollStepAIfRequested();
  if ((queryTour || (autorun && !queryPrefill)) && !isSnoozed()) {
    var saved = getResumeState();
    if (saved && saved.inProgress && typeof saved.stepIndex === 'number' && saved.stepIndex > 0) {
      var stepN = parseInt(saved.stepIndex, 10) + 1;
      var shouldResume = window.confirm('Resume tour at Step ' + stepN + '? Click Cancel to restart from Step 1.');
      if (shouldResume) {
        startTour({ resume: true });
      } else {
        clearResumeState();
        startTour({ resume: false });
      }
    } else {
      startTour({ resume: false });
    }
  }
})();
