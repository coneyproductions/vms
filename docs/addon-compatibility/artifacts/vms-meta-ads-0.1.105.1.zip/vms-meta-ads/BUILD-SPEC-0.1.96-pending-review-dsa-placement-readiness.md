# BUILD SPEC 0.1.96

## Summary
`0.1.96` hardens paused-create readiness without enabling any publish path. The release focuses on three areas:

1. safer local classification for paused objects that are still in Meta review
2. DSA beneficiary/payor readiness and readback
3. clearer placement defaults and post-create compliance/readiness review

## Scope
- Treat ad `PENDING_REVIEW` as a safe inactive transitional state when campaign/ad set/ad are not active or delivering.
- Do not map safe paused-review states to event-level `error`.
- Add `meta_dsa_beneficiary` / `meta_dsa_payor` settings, preflight warnings, and Go Live blocking.
- Keep using Meta's DSA field names only. Do not send generic `beneficiary` / `payer`.
- Start the direct-create-safe strategy on an explicit FB/IG manual placement set that excludes Threads, Audience Network, and Messenger.
- Surface automatic-vs-manual placement mode and readback warnings before any Go Live step.
- Add post-create readiness output for status, geo, pixel, CTA/destination, placements, DSA, Multi-advertiser, Advantage+ creative, and Meta issues/recommendations.
- Keep dry run local-only, keep Meta Connection Status read-only, and keep no-spend gates intact.

## Non-Goals
- No Go Live activation changes.
- No Meta object mutation during no-spend smoke.
- No schema change beyond existing DB version `4`.
- No VMS core release.

## Files
- `includes/meta-api/client.php`
- `includes/utils.php`
- `includes/admin/screens/settings.php`
- `includes/admin/enqueue.php`
- `includes/admin/screens/ads-builder.php`
- `includes/services-event-plans.php`
- `includes/admin/event-plan-metabox.php`
- `includes/rest/controllers/class-ad-builds-controller.php`
- `assets/ads-builder.js`
- `assets/admin.css`
- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `README.md`

## Acceptance
- Local status classification no longer treats paused + pending review as event-level error.
- DSA fields are saved locally, surfaced in readiness, and block Go Live when missing.
- Direct-create-safe default uses explicit FB/IG manual placements.
- Post-create readiness panel renders without mutating Meta or local settings.
- Local/staging no-spend smoke makes zero Meta mutation calls.
