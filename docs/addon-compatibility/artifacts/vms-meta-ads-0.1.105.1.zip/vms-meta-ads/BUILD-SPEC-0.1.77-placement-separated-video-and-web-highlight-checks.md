# VMS Meta Ads Builder 0.1.77 — Placement-Separated Video + Web Highlight Checks

## Goal

Make the Clean-Room Full Push v2 recipe safer for the next live ad build by reflecting two operator findings from Meta Ads Manager:

1. Square/feed video and portrait/Reels video should be handled as separate ad-set structures for predictable delivery.
2. Meta Website Highlights / Web Highlight / Show Spotlights can inject random website images into ad creative and must be checked manually before publishing.

## Source version

Built from `vms-meta-ads` 0.1.76.

## Changes

### 1. Clean-Room Full Push v2 now separates feed and portrait placements

For `clean_room_full_push_v2`, MAB now treats the primary square/feed creative and portrait Reels/Stories creative as separate ad-set responsibilities:

| v2 ad set | Placements | Creative expectation |
|---|---|---|
| Core Radius - Feeds | Facebook Feed, Instagram Feed | Square/feed creative only |
| Vertical Video - Reels/Stories | Facebook Reels, Instagram Reels, Facebook Stories, Instagram Stories | Tall 9:16 video preferred/required when strict mode is enabled |
| Outer Towns - Feeds 50+ | Facebook Feed, Instagram Feed | Square/feed creative only; verify outer-town targeting in Meta |
| Facebook Right Column Support Test | Facebook Right Column only | Static 1:1 image; optional support test |

The legacy `clean_room_full_push` recipe remains readable and unchanged for saved builds.

### 2. Feed-only recipe ad sets avoid video-placeholder variants where possible

The server-side recipe variant selector now supports a `feed_static` mode. For v2 Feed-only ad sets, MAB selects non-video variants first so the vertical/portrait video is less likely to be attached to feed placements.

If a build only has video/video-placeholder variants, MAB falls back to the first available variant rather than failing creation. This keeps urgent ad creation possible but leaves review responsibility visible in Meta.

### 3. Vertical-video detection is less misleading

If the operator explicitly marks the video shape as Square / 1:1 or Wide / 16:9, MAB no longer treats the video as satisfying the Tall video requirement. Unknown/video-placeholder remains lenient so an operator can still build a paused structure and swap the final portrait video inside Meta.

### 4. Website Highlights manual checks added

MAB now surfaces the Website Highlights / Web Highlight / Show Spotlights reminder in three places:

- Clean-room checklist
- Copy pack output
- Go Live preflight modal

Operator guidance: before publishing, open the paused ads in Meta and confirm Website Highlights / Show Spotlights and Multi-advertiser ads are off for each ad.

## Non-goals

- Does not attempt to control Website Highlights through the Meta API.
- Does not implement full outer-town donut/exclusion targeting.
- Does not change Sales / Ticket Purchases conversion mapping from 0.1.75/0.1.76.
- Does not mutate legacy `clean_room_full_push` saved builds.

## Files changed

- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `assets/ads-builder.js`
- `includes/services-ad-builds.php`
- `includes/meta-api/client.php`
- `includes/admin/screens/ads-builder.php`
- `BUILD-SPEC-0.1.77-placement-separated-video-and-web-highlight-checks.md`
- `TEST-PLAN-0.1.77.md`
