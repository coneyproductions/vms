# Codex Test Plan — VMS Meta Ads Builder 0.1.66

## Scope

Validate that Adopt / Link existing Meta campaign persists across refreshes and Save Draft actions.

## Required Setup

Use an Event Plan with an existing saved build and at least one matching active or paused Meta campaign available through discovery.

## Tests

### 1. Adopt existing Meta campaign

1. Open Meta Ads Builder.
2. Select the Event Plan.
3. Click **Find Existing Meta Campaigns**.
4. Click **Adopt / Link this Meta campaign** on the correct candidate.

Expected:

- success message appears,
- reconciliation card shows Linked,
- build dropdown/detail shows live Meta summary,
- no Meta campaign/ad/ad set is created or edited.

### 2. Refresh persistence

1. After adoption, refresh the browser page.
2. Select or verify the same Event Plan/build.

Expected:

- linked build still shows Meta source-of-truth summary,
- reconciliation state does not revert to stale Draft-only details,
- old saved-builder details may appear only as drift/saved draft information.

### 3. Save Draft does not unlink

1. After adoption, make a harmless local change, such as editing a copy field.
2. Click **Save Draft**.
3. Refresh the page.

Expected:

- build remains linked to Meta,
- status remains Live or Paused in Meta as appropriate,
- Meta IDs remain present on the build,
- drift/saved draft messaging remains available.

### 4. Tier replacement preserves Meta linkage

1. Change a schedule or budget field that causes tier rows to be regenerated.
2. Save Draft.
3. Refresh Meta status.

Expected:

- the selected build still has the existing Meta ad set/ad IDs,
- Meta status refresh still targets the linked Meta objects.

### 5. Stale prefill cache regression

1. Adopt an existing campaign.
2. Immediately refresh the page.
3. Repeat within 10 minutes.

Expected:

- cached/stale pre-adoption details do not reappear.

## Regression Checks

- New build creation still works.
- Start New Linked Build still clears the selected build intentionally.
- Existing unlinked draft builds still display as Draft.
- Direct Meta create/update/go-live buttons remain gated as before.
- No API call changes actual Meta campaign state during adoption.

## Files touched

- `includes/services-ad-builds.php`
- `includes/meta-api/client.php`
- `assets/ads-builder.js`
- `vms-build.txt`
