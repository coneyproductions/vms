# VMS Meta Ads Builder 0.1.63 Test Plan

## Purpose

Verify that video placeholder variants work without requiring WordPress video uploads and without breaking existing image/video ad flows.

## Preconditions

- VMS Meta Ads Builder 0.1.63 installed.
- Meta API settings already configured as they were for 0.1.62.
- At least one upcoming Event Plan with a destination URL.
- At least one square/shared placeholder image available in the WordPress media library.

## Smoke Tests

### 1. Version markers

Confirm:

- Plugin header says `0.1.63`.
- `VMS_MA_VERSION` says `0.1.63`.
- `module.json` says `0.1.63`.
- `vms-build.txt` says `0.1.63`.

### 2. UI media options

Open Meta Ads Builder > Step C > Ad Variants.

Confirm each variant media dropdown includes:

- Use default shared media
- Use a different single image
- Video placeholder - upload video in Meta
- Upload WordPress video to Meta (legacy)

Confirm selecting `Video placeholder - upload video in Meta` does not show or require a WordPress video picker.

### 3. Save/reload draft

1. Select an Event Plan.
2. Add default shared image.
3. Set Variant 1 or Variant 2 to `Video placeholder - upload video in Meta`.
4. Save draft.
5. Reload the page.
6. Re-select the Event Plan/build.

Expected:

- The selected variant remains `Video placeholder - upload video in Meta`.
- No WordPress video ID is required.
- Draft is not marked invalid only because the video is not uploaded to WordPress.

### 4. Copy pack output

Generate copy pack.

Expected:

- Variant media line says it is a Meta-direct video placeholder.
- Copy pack makes it clear the shared/placeholder image is used until the real video is uploaded/swapped in Meta.
- CTA lock still shows `Buy Tickets` when using a ticketed strategy.

### 5. Create in Meta behavior

Using a safe test/draft campaign:

1. Select `Video placeholder - upload video in Meta` for one variant.
2. Create in Meta as paused/draft.

Expected:

- Plugin does not attempt to upload a WordPress video file.
- Creative is created using the placeholder/shared image path.
- Result includes a warning telling the operator to upload/swap the actual video directly in Meta before going live.
- No fatal errors.

### 6. Legacy video regression

Only if a safe small test video already exists in WordPress:

1. Select `Upload WordPress video to Meta (legacy)`.
2. Confirm old behavior still attempts to use the selected WordPress video.

Expected:

- Existing legacy behavior is not broken.
- Operator-facing label makes this path clearly non-preferred.

### 7. Existing image regression

Confirm the following still save/reload/export/create normally:

- shared media variant
- custom image variant
- no optional variants
- CTA lock = Buy Tickets
- Video-Led Ticket Push budget pacing
- Flat run budget pacing

## Do Not Test on Live Buffett Beach Ad Unless Intentionally Replacing It

Because the existing Buffett Beach campaign appears to have been manually edited in Meta, do not push builder updates to that active campaign until reconciliation/adoption is implemented or the operator intentionally creates a new replacement ad and pauses the old one.
