# TEST PLAN — MAB 0.1.76 Sales Goal UI Sync Hotfix

## Purpose
Validate that the Builder page no longer becomes unresponsive after 0.1.75 added the Sales / Ticket Purchases goal.

## Scope
This is a hotfix-only validation. Codex should not publish live campaigns or unpause ads.

## Steps

1. Install `vms-meta-ads-0.1.76-sales-goal-ui-hotfix.zip` over the existing canonical `vms-meta-ads` plugin folder.
2. Confirm version markers:
   - Plugin header: `0.1.76`
   - `VMS_MA_VERSION`: `0.1.76`
   - `module.json`: `0.1.76`
   - `vms-build.txt`: `0.1.76`
3. Open VMS > Meta Ads Builder.
4. Confirm the page finishes loading and Chrome does not show a page-unresponsive notice.
5. Select an Event Plan with existing drafts.
6. Load an existing campaign draft and confirm Step E renders.
7. Change Goal between Traffic, Engagement, Leads, and Sales / Ticket Purchases.
8. Confirm Sales forces Optimization to `Purchase conversions` without freezing the page.
9. Apply `Clean-Room Concert Campaign - Full Push v2` and confirm it defaults to Sales / Ticket Purchases without freezing.
10. Save Draft and reload the page. Confirm the saved draft reloads and the page remains responsive.
11. Do not create, update, publish, pause, or unpause live Meta assets unless using an intentionally disposable paused test.

## Expected Results
- No browser unresponsive notice.
- Sales goal still displays the Pixel/Dataset helper warning when missing.
- Sales goal still saves `sales` / `purchase_conversions`.
- All 0.1.75 Sales behavior remains intact.
