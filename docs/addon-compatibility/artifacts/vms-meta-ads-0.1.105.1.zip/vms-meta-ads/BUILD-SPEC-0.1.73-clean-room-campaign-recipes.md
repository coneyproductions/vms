# VMS Meta Ads Builder 0.1.73 — Clean-Room Campaign Recipes

## Goal

Let the operator build a campaign structure from VMS instead of duplicating inside Meta Ads Manager and inheriting unexpected Meta defaults.

This pass adds a first reusable campaign recipe:

**Clean-Room Concert Campaign - Full Push**

The recipe is intentionally created **paused** so the operator can review every campaign, ad set, ad, destination, creative, audience, and placement inside Meta before publishing.

## Operator-facing behavior

### Strategy selector

The Builder now includes:

- Custom / manual controls
- **Clean-Room Concert Campaign - Full Push**
- Ticketed Concert - Video-Led Local Push
- Standard Ticket Push
- Last-Minute Push
- Low-Budget Local Reminder

Selecting the clean-room recipe applies safe defaults:

- Flat run schedule preset
- Buy Tickets CTA lock
- Landing-page-view optimization
- Manual placements
- Facebook/Instagram feed
- Facebook/Instagram reels
- Facebook/Instagram stories
- Facebook right column
- Creative automation policy: off
- Multi-advertiser ads: off
- Age default: 45–65+

### Checklist

The strategy section now shows a clean-room checklist when this recipe is selected. It verifies:

- Campaign is built from VMS, not a Meta duplicate.
- Assets are created paused for review.
- Advantage+/catalog-style automation is not requested.
- Multi-advertiser ads are off.
- Manual placement recipe is selected.
- Buy Tickets CTA lock is on.

## Saved build payload

Saved builds now include `campaign_recipe=clean_room_full_push` for this strategy. The generated copy pack includes a `campaign_recipe_payload` with four ad-set definitions:

1. **Core Radius - Feed/Reels** — 50% of total budget
2. **Promo Video/Reels** — 20% of total budget
3. **Outer Towns - Ages 50+** — 25% of total budget
4. **Facebook Right Column** — 5% of total budget

Each recipe ad set carries its own placements, audience defaults, ad-set name, budget slice, and variant selection mode.

## Backend create behavior

For clean-room recipe builds, **Create in Meta (PAUSED)** creates:

- One paused campaign
- Four paused ad sets
- Placement/audience-specific ads under each ad set
- Persisted `adset_ids`, `adsets_meta`, `ad_ids`, and `ad_variants_meta`

The status refresh, go-live, and pause-all handlers now understand multiple ad sets and multiple ads while preserving the existing single-ad-set response fields for backward compatibility.

## Intentional limitation in this pass

`Update Existing Meta Ad` is blocked for multi-ad-set clean-room recipes. This avoids accidentally mutating several live ad sets before the recipe workflow has a dedicated multi-ad-set update/reconcile screen.

Preferred workflow for this first pass:

1. Save draft.
2. Create in Meta (PAUSED).
3. Review assets in Meta.
4. Go Live only after review.
5. If the recipe needs a fresh structural replacement, Reset/Clone and create a fresh paused bundle.

## Long-term follow-up

Future recipe work should add:

- Multiple named recipes.
- Operator-editable recipe templates.
- Rich ad-set/ad preview before API creation.
- Safer multi-ad-set update/replacement workflow.
- Recipe drift report after Meta review.
- Pixel/conversion-aware Sales objective mapping once the site-side conversion event contract is finalized.
