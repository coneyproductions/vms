# MAB 0.1.92 Test Plan — Dry-Run Placement Visibility Polish

## A. Package / version

1. Confirm the release ZIP contains one canonical top-level folder: `vms-meta-ads/`.
2. Confirm plugin header version is `0.1.92`.
3. Confirm `VMS_MA_VERSION` is `0.1.92`.
4. Confirm `module.json` version is `0.1.92`.
5. Confirm `module.json` still requires VMS core `0.2.24.711`.
6. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.92`.
7. Confirm `vms_ma_db_version` remains `4`.

## B. Static validation

Run from the unpacked plugin directory:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/admin/api-diagnostics.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.92-dry-run-placement-visibility-polish.zip
```

## C. Payload visibility

1. Fresh default build:
   - dry run succeeds locally
   - placement preview card renders above raw JSON
   - `placements_overview` is present in the response
   - active placements are readable without opening nested JSON
2. Existing/saved build:
   - dry run still shows placements explicitly
   - CTA remains `BUY_TICKETS`
   - destination remains the website event URL
   - age remains `30-65`
   - geo rows remain explicit
3. Manual placement flow:
   - dry run shows `Manual placements`
   - active Facebook/Instagram placement labels match the selected manual boxes
4. Automatic/default flow:
   - dry run shows `Advantage+ placements (automatic)`
   - active placement labels remain visible even when targeting payload does not list `publisher_platforms`

## D. Schedule support regression

1. Single-window `simple_14_day` build:
   - `schedule_support.direct_create_supported = true`
   - no stale `Flat run preset required` warning appears
2. Multi-window build:
   - dry run still succeeds locally
   - `schedule_support.direct_create_supported = false`
   - warning explains the single-window create requirement
   - first-window payload still previews
3. Live direct-create/update preflight remains blocked for multi-window builds.

## E. Safety / runtime

1. Confirm every dry run still logs to `wp_vms_api_attempts`.
2. Confirm zero requests are made to `graph.facebook.com`.
3. Confirm zero real Meta campaign/ad set/ad/creative objects are created.
4. Confirm no PHP fatals are introduced.
5. Confirm authenticated browser smoke shows no JS console errors and no page errors.
6. Confirm dry-run copy still states that no Meta API calls are made and no spend occurs.
