# VMS Meta Ads Builder 0.1.85 Test Plan

## A. Package/version
1. Confirm only one top-level zip directory exists: `vms-meta-ads/`.
2. Confirm WordPress plugin version is `0.1.85`.
3. Confirm `VMS_MA_VERSION` is `0.1.85`.
4. Confirm `module.json` reports `0.1.85`.
5. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.85`.

## B. Static validation
Run from the plugin directory:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/admin/api-diagnostics.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.85-outer-towns-city-state-targeting.zip
```

## C. Step D UI validation
1. Open MAB Step D.
2. Confirm field label is **Outer Towns locations**.
3. Confirm **Outer Towns default radius** appears and defaults to `15`.
4. Confirm helper text says city/state, ZIP, or full address are allowed.
5. Confirm helper text does not say to use locations above.

## D. Parser validation
Use:

```text
Athens, TX | 15
Henderson, TX
75751 | 10
4021 S State Hwy 161, Grand Prairie, TX 75052 | 5
```

Expected:
- Athens uses 15.
- Henderson uses the default radius.
- ZIP uses 10.
- Full address uses 5.

Invalid rows should block create:

```text
Athens, TX | abc
Athens, TX | 0
|
```

## E. Meta paused-create validation
Create a clean-room campaign paused.

Confirm in Ads Manager:
- Outer Towns does not use the primary Whitehouse/Tyler venue radius.
- Outer Towns uses the entered city/state, ZIP, or address rows.
- Outer Towns age matches Step D.
- Other ad sets still use the primary radius.
- No saved-audience stale settings are pulled into the created ad set.

## F. Regression checks
- Advantage+ creative remains off.
- Multi-advertiser ads remain off or are caught by manual QA.
- Manual QA Gate still works.
- Create in Meta is paused.
- Square feed video and vertical Reels/Stories ad sets are separate.
- UTMs remain on every ad URL.
