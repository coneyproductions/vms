# VMS Meta Ads Builder 0.1.82 Test Plan

## A. Version / package validation

1. Install `vms-meta-ads-0.1.82-meta-enhancements-fallback.zip` as the only active `vms-meta-ads` plugin directory.
2. Confirm plugin header shows `0.1.82`.
3. Confirm `VMS_MA_VERSION` resolves to `0.1.82`.
4. Confirm `module.json` shows `0.1.82`.
5. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.82`.
6. Confirm the release zip contains one canonical top-level directory: `vms-meta-ads/`.

## B. Static validation

Run from the unpacked plugin root:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/admin/api-diagnostics.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.82-meta-enhancements-fallback.zip
```

Expected: all PHP files report no syntax errors, all JS files pass syntax checks, and zip test returns `OK`.

## C. Manual QA Gate visual polish

1. Open VMS > Meta Ads Builder.
2. Scroll to the Manual Meta QA Gate.
3. Confirm each checkbox is visibly larger than the previous tiny checkbox style.
4. Confirm labels align cleanly and remain clickable.
5. Confirm the Go Live gate still requires all six manual confirmations before Go Live.

## D. Meta creative fallback regression

Use the same kind of build that failed in `0.1.81` with:

`Including standard enhancements field in creative has been deprecated.`

1. Select a Flat run / create-supported strategy.
2. Save Draft.
3. Click Create in Meta (PAUSED).
4. Confirm creation no longer stops on `create_creative_retry_without_rules failed: Including standard enhancements field in creative has been deprecated`.
5. If Meta rejects feature opt-outs, confirm diagnostics show a subsequent retry ending in `_retry_without_feature_opt_outs` for the same payload path.
6. Confirm campaign/ad sets/ads are created PAUSED, or capture the new final diagnostic if Meta rejects for a different reason.

## E. Diagnostics download fallback

1. Trigger or use an existing Meta API failure.
2. Open Meta API Diagnostics.
3. Click Copy Last Failure.
4. If browser clipboard permissions block copying, confirm the panel shows a useful error rather than throwing an uncaught console error.
5. Click Download Last Failure and confirm a `.txt` file downloads.
6. Click Download Bundle for the latest attempt and confirm a `.txt` file downloads.
7. Click a recent row's Download link and confirm it downloads that specific attempt.

## F. Preset clarity

1. Select a tiered/export-only preset.
2. Save Draft.
3. Attempt Create in Meta.
4. Confirm the error explains that the saved draft still uses a tiered/export-only schedule and instructs the user to switch Step B to Flat run, save, then create.

## G. Final pre-launch Ads Manager verification

After a successful paused create, open Ads Manager and confirm manually:

- Website Highlights / Web Highlight / Show Spotlights are off.
- Advantage+ creative enhancements are off.
- Multi-advertiser ads are off.
- Every preview uses only the intended MAB image/video.
- Ticket URL and UTM tags are present on every ad.
- Ad-set schedule start/end is correct in Meta.
