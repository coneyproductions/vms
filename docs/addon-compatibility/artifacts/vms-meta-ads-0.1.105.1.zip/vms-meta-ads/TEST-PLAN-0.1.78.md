# VMS Meta Ads Builder 0.1.78 Test Plan

## Install checks

1. Install the zip over the existing canonical `vms-meta-ads` plugin folder.
2. Confirm version markers:
   - `vms-meta-ads.php` shows `0.1.78`.
   - `module.json` shows `0.1.78`.
   - `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.78`.
3. Confirm the plugin folder remains `vms-meta-ads/`, not a parallel versioned folder.

## UI checks

1. Open a VMS Meta Ads Builder event draft.
2. Select **Clean-Room Concert Campaign - Full Push v2**.
3. In **Ad Variants**, confirm each variant has a **Placement intent** dropdown.
4. Confirm dropdown options:
   - Auto / normal
   - Feed square video (1:1)
   - Reels/Stories portrait video (9:16)

## Recipe preview checks

### No feed square video variant

1. Leave all video variants on Auto, or create only a Reels/Stories video placeholder.
2. Confirm the preview does **not** show **Feed Video - Square 1:1**.
3. Confirm v2 still shows static Feed, Reels/Stories, and Outer Towns Feed ad sets.

### Feed square video variant

1. Create one variant with Media source = **Video placeholder - upload video in Meta**.
2. Set Placement intent = **Feed square video (1:1)**.
3. Create or keep another video placeholder with Placement intent = **Reels/Stories portrait video (9:16)** or Auto.
4. Confirm the recipe preview shows **Feed Video - Square 1:1**.
5. Confirm its placements are Facebook Feed and Instagram Feed.
6. Confirm the Reels/Stories ad set remains Facebook Reels, Instagram Reels, Facebook Stories, and Instagram Stories.

## Create-in-Meta dry run / paused-create checks

1. Create the v2 campaign in Meta as paused.
2. Confirm expected ad sets:
   - Core Radius - Feeds
   - Feed Video - Square 1:1, only when a feed-square video variant exists
   - Vertical Video - Reels/Stories
   - Outer Towns - Feeds 50+
   - Optional Right Column Support Test, only when enabled
3. Confirm Feed Video ad set contains only the feed-square video/placeholder variant.
4. Confirm Vertical Video ad set does not contain the feed-square variant.
5. Before publishing in Meta, manually verify:
   - Square feed video is uploaded/swapped into the Feed Video ad.
   - Portrait video is uploaded/swapped into the Reels/Stories ad.
   - Website Highlights / Web Highlight / Show Spotlights are off.
   - Multi-advertiser ads are off.
   - Schedule timezone matches the venue/event timezone.

## Technical checks completed during packaging

- PHP lint across plugin files.
- JS syntax check for `assets/ads-builder.js`.
