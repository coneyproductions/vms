# VMS Meta Ads Builder 0.1.61 — Test Plan

## Focus
1. New **Analytics + Strategy** panel loads directly inside the builder.
2. Analytics data can be **refreshed, switched by range, copied, and downloaded**.
3. Existing build/save/create/update flows still behave normally.

## DB / upgrade checks
- Install or upgrade the plugin to **0.1.61**.
- Confirm no activation or admin fatal errors occur.
- Confirm the new table exists:
  - `wp_vms_meta_ads_analytics_snapshots` (or your site prefix equivalent)

## Builder analytics checks
- Open **Meta Ads Builder**.
- Select an Event Plan that already has a linked Meta campaign/ad set/ad.
- Confirm a new section appears in Step G named:
  - **Campaign Analytics + Strategy**
- Confirm the panel shows these controls:
  - 7d
  - 14d
  - 30d
  - Refresh Analytics
  - Download Analysis Bundle
  - Copy Strategy Notes

## Analytics data pull checks
- With a linked Event Plan selected, click **Refresh Analytics**.
- Confirm the panel populates with:
  - overview cards
  - daily spend trend
  - demographics table
  - regions table
  - placements table
  - devices table
  - strategy recommendation cards
- Confirm the top metadata line updates with a recent fetch time.

## Range checks
- Click **14d**.
- Confirm the analytics refreshes and does not fatal.
- Click **30d**.
- Confirm the analytics refreshes and does not fatal.
- Click back to **7d**.
- Confirm the panel still works.

## Export / handoff checks
- Click **Download Analysis Bundle**.
- Confirm a `.json` file downloads.
- Open the JSON file and confirm it includes keys like:
  - `summary`
  - `trend`
  - `demographics`
  - `regions`
  - `placements`
  - `devices`
  - `recommendations`
  - `strategy_notes`
- Click **Copy Strategy Notes**.
- Confirm notes copy cleanly to clipboard.

## Builder flow regression checks
- Save Draft still works.
- Create in Meta (PAUSED) still works.
- Update Existing Meta Ad still works.
- Sync Budget to Meta still works.
- Go Live modal flow still works.
- Reset Meta Link still works.

## Empty / graceful fallback checks
- Choose an Event Plan with no linked Meta IDs yet.
- Confirm the analytics area shows a useful message instead of breaking.
- Choose an Event Plan with a saved draft but no Meta create yet.
- Confirm the analytics area stays graceful.
- If Meta rejects a breakdown combo, confirm the panel still loads with a warning/fallback instead of failing entirely.
