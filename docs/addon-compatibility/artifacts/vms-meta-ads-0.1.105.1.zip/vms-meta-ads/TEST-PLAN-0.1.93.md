# TEST PLAN 0.1.93

## Static
- `php -l` on changed PHP files
- `node --check` on `assets/settings.js`

## Local
- Missing/incomplete local settings should return a read-only status snapshot without fatal errors
- Running the snapshot must not change `vms_ma_settings`, `meta_last_test_ok_gmt`, `meta_account_timezone_detected`, or DB version
- Settings screen panel should render, call the REST endpoint, redact token details, and show warning/error states without console/page errors

## Staging
- Deploy `vms-meta-ads 0.1.93` only
- Keep VMS core at `0.2.24.711`
- Keep `enable_api_create=0`
- Keep `vms_ma_phase=1`
- Run the read-only status panel using existing stored credentials only
- Confirm the panel reports ad account/page/Instagram/pixel reachability and permissions
- Confirm attempts are logged with `readonly_status_*`
- Confirm no create/update/delete/publish endpoint is called
- Confirm `meta_last_test_ok_gmt`, `meta_account_timezone_detected`, and connection settings remain unchanged

## No-Spend Guards
- Dry run behavior remains local-only
- No campaign/ad set/ad/creative/budget/spend mutation
- No production deployment in this phase
