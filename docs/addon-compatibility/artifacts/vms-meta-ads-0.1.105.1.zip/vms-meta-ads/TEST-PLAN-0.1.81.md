# VMS Meta Ads Builder 0.1.81 Test Plan

## A. Version and package checks

1. Activate the patched plugin.
2. Confirm the active plugin header shows `0.1.81`.
3. Confirm `VMS_MA_VERSION` resolves to `0.1.81`.
4. Confirm `module.json` shows `0.1.81`.
5. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.81`.
6. Confirm the release zip contains one canonical top-level `vms-meta-ads/` directory.

## B. Static validation

From the unpacked plugin root:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.81-creative-lockdown-qa.zip
```

Expected: no PHP syntax errors, no JS syntax errors, and zip test passes.

## C. Creative Lockdown UI

1. Open the MAB builder.
2. Go to Step C.
3. Confirm `Advantage+ creative policy` defaults to `Off / preserve creative`.
4. Confirm `Allow multi-advertiser ads` defaults unchecked.
5. Confirm the Creative Lockdown Mode card is visible and mentions selected image/video, ticket URL, disabled enhancement settings, and manual Meta QA.

Expected: the default state is locked down without needing operator changes.

## D. Manual Meta QA Gate

1. Go to Step G.
2. Confirm the Manual Meta QA Gate card is visible.
3. Confirm all six checklist items appear:
   - Website Highlights / Web Highlight / Show Spotlights
   - Advantage+ creative enhancements
   - Multi-advertiser ads
   - intended MAB image/video
   - ticket URL and UTM tags
   - ad-set schedule
4. Leave at least one checklist item unchecked.
5. Confirm Go Live remains disabled and the gating reason names the missing QA item.
6. Check all items.
7. Confirm the QA status changes to complete.

Expected: Go Live is blocked until all manual QA items are checked.

## E. Creative Lockdown create/publish guard

1. Save a draft with Advantage+ creative policy set to `Off` and Multi-advertiser unchecked.
2. Confirm Create in Meta can proceed when all other existing requirements are met.
3. Change Advantage+ creative policy to `Conservative review` and save.
4. Attempt Create in Meta or Go Live.
5. Confirm the API preflight blocks the action with a Creative Lockdown message.
6. Restore policy to `Off`, then enable Multi-advertiser ads and save.
7. Attempt Create in Meta or Go Live.
8. Confirm the API preflight blocks the action with a Creative Lockdown message.

Expected: non-lockdown creative automation and multi-advertiser ads cannot be created/published by accident.

## F. Outer Towns mode

1. Choose a clean-room campaign recipe that includes Outer Towns.
2. Add precise additional ZIPs or full addresses in Step D.
3. Leave `Outer Towns targeting mode` set to `Listed towns/ZIPs only`.
4. Save Draft.
5. Inspect the generated recipe preview / saved targeting payload.

Expected:

- Outer Towns displays as listed-only.
- The Outer Towns ad set does not use the primary venue radius anchor when listed locations are present.
- The saved targeting payload includes `outer_towns_mode: listed_only`.

Repeat with `Expanded outer radius` selected.

Expected:

- Outer Towns displays as expanded outer radius.
- The saved targeting payload includes `outer_towns_mode: expanded_radius`.

## G. UTM and destination drift review

1. Create a paused Meta build using a ticket URL with UTMs.
2. Refresh Meta status / drift review after the ads are linked.
3. Confirm no drift warning appears when the creative URL host/path matches the saved ticket URL and `utm_campaign` is present in URL or URL tags.
4. Manually edit a linked Meta creative destination or URL tags in Ads Manager, if safe in test.
5. Refresh drift review.

Expected: MAB displays a conservative warning when live Meta creative destination or UTM tracking appears to drift from the saved MAB plan.

## H. Final manual pre-launch smoke

For a paused real campaign draft before publishing:

1. Open every ad in Ads Manager.
2. Confirm Website Highlights / Web Highlight / Show Spotlights are off.
3. Confirm Advantage+ creative enhancements are off.
4. Confirm Multi-advertiser ads are off.
5. Confirm each preview shows only the selected MAB asset.
6. Confirm Vertical Video uses the intended 9:16 video only.
7. Confirm Feed Video uses the intended 1:1 video only.
8. Confirm ticket URL and UTMs are present.
9. Confirm ad-set schedule is correct in Meta's displayed timezone.
10. Check all Manual Meta QA Gate items in MAB.
11. Publish only after the QA gate is complete.
