<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Audience_Targeting_Service')) {
	class VMS_Meta_Ads_Audience_Targeting_Service {
		private const VERSION = 1;
		private const MODE_ALLOWED = array('broad_local', 'interest_guided', 'retargeting', 'lookalike');
		private const GENDER_ALLOWED = array('all', 'women', 'men');
		private const EVENT_TYPE_ALLOWED = array('ticketed_concert', 'tribute_show', 'festival', 'family_community', 'venue_awareness', 'other');
		private const TERM_TYPE_ALLOWED = array('interest', 'behavior');
		private const STATUS_ALLOWED = array('valid', 'unvalidated', 'deprecated', 'unavailable');
		private const SOURCE_ALLOWED = array('suggestion', 'preset', 'manual', 'legacy', 'lookup');

		public static function get_builder_catalog(): array
		{
			return array(
				'version' => self::VERSION,
				'modes' => array(
					array(
						'key' => 'broad_local',
						'label' => __('Broad/local audience', 'vms-meta-ads'),
						'description' => __('Use location, age, gender, and placements only. Detailed targeting can stay saved but inactive.', 'vms-meta-ads'),
						'disabled' => 0,
						'tag' => __('Phase 1', 'vms-meta-ads'),
					),
					array(
						'key' => 'interest_guided',
						'label' => __('Interest-guided audience', 'vms-meta-ads'),
						'description' => __('Layer in curated interests and behavior hints. Terms without live Meta validation stay label-only until approved.', 'vms-meta-ads'),
						'disabled' => 0,
						'tag' => __('Phase 1', 'vms-meta-ads'),
					),
					array(
						'key' => 'retargeting',
						'label' => __('Past-engagement / retargeting audience', 'vms-meta-ads'),
						'description' => __('Reserved for future custom-audience workflows.', 'vms-meta-ads'),
						'disabled' => 1,
						'tag' => __('Future phase', 'vms-meta-ads'),
					),
					array(
						'key' => 'lookalike',
						'label' => __('Lookalike audience', 'vms-meta-ads'),
						'description' => __('Reserved for future lookalike source selection and controls.', 'vms-meta-ads'),
						'disabled' => 1,
						'tag' => __('Future phase', 'vms-meta-ads'),
					),
				),
				'genders' => array(
					array('key' => 'all', 'label' => __('All genders', 'vms-meta-ads')),
					array('key' => 'women', 'label' => __('Women', 'vms-meta-ads')),
					array('key' => 'men', 'label' => __('Men', 'vms-meta-ads')),
				),
				'event_types' => array(
					array('key' => 'ticketed_concert', 'label' => __('Ticketed concert', 'vms-meta-ads')),
					array('key' => 'tribute_show', 'label' => __('Tribute / themed show', 'vms-meta-ads')),
					array('key' => 'festival', 'label' => __('Festival / seasonal event', 'vms-meta-ads')),
					array('key' => 'family_community', 'label' => __('Family / community event', 'vms-meta-ads')),
					array('key' => 'venue_awareness', 'label' => __('Venue awareness', 'vms-meta-ads')),
					array('key' => 'other', 'label' => __('Other', 'vms-meta-ads')),
				),
				'statuses' => array(
					'valid' => __('Validated Meta ID', 'vms-meta-ads'),
					'unvalidated' => __('Needs Meta validation', 'vms-meta-ads'),
					'deprecated' => __('Deprecated in Meta', 'vms-meta-ads'),
					'unavailable' => __('Unavailable in Meta', 'vms-meta-ads'),
				),
				'suggestions' => array(
					array(
						'key' => 'genre',
						'label' => __('Genre', 'vms-meta-ads'),
						'description' => __('Editable genre seeds. Save the label now, validate the live Meta target later.', 'vms-meta-ads'),
						'items' => array(
							self::catalog_term('country_music', __('Country music', 'vms-meta-ads'), 'interest', 'genre'),
							self::catalog_term('classic_rock', __('Classic rock', 'vms-meta-ads'), 'interest', 'genre'),
							self::catalog_term('beach_trop_rock', __('Beach / trop rock', 'vms-meta-ads'), 'interest', 'genre'),
							self::catalog_term('americana_red_dirt', __('Americana / red dirt', 'vms-meta-ads'), 'interest', 'genre'),
							self::catalog_term('latin_music', __('Latin music', 'vms-meta-ads'), 'interest', 'genre'),
							self::catalog_term('pop_hits', __('Pop hits', 'vms-meta-ads'), 'interest', 'genre'),
						),
					),
					array(
						'key' => 'live_music',
						'label' => __('Live music / concert behavior', 'vms-meta-ads'),
						'description' => __('Interest and behavior hints for concert-going audiences.', 'vms-meta-ads'),
						'items' => array(
							self::catalog_term('live_music', __('Live music', 'vms-meta-ads'), 'interest', 'live_music'),
							self::catalog_term('concerts', __('Concerts', 'vms-meta-ads'), 'interest', 'live_music'),
							self::catalog_term('music_festivals', __('Music festivals', 'vms-meta-ads'), 'interest', 'live_music'),
							self::catalog_term('nightlife', __('Nightlife', 'vms-meta-ads'), 'interest', 'live_music'),
							self::catalog_term('event_goer_behavior', __('Frequent event-goer', 'vms-meta-ads'), 'behavior', 'live_music'),
						),
					),
					array(
						'key' => 'ticketing',
						'label' => __('Ticket-buying / event discovery', 'vms-meta-ads'),
						'description' => __('Discovery-oriented hints for people already looking for things to do.', 'vms-meta-ads'),
						'items' => array(
							self::catalog_term('event_tickets', __('Event tickets', 'vms-meta-ads'), 'interest', 'ticketing'),
							self::catalog_term('things_to_do_weekend', __('Things to do this weekend', 'vms-meta-ads'), 'interest', 'ticketing'),
							self::catalog_term('local_events', __('Local events', 'vms-meta-ads'), 'interest', 'ticketing'),
							self::catalog_term('event_discovery_behavior', __('Event discovery apps / behavior', 'vms-meta-ads'), 'behavior', 'ticketing'),
						),
					),
					array(
						'key' => 'venue_local',
						'label' => __('Venue / local entertainment', 'vms-meta-ads'),
						'description' => __('Broad venue-awareness options for local reach.', 'vms-meta-ads'),
						'items' => array(
							self::catalog_term('bars_with_live_music', __('Bars with live music', 'vms-meta-ads'), 'interest', 'venue_local'),
							self::catalog_term('local_entertainment', __('Local entertainment', 'vms-meta-ads'), 'interest', 'venue_local'),
							self::catalog_term('outdoor_concerts', __('Outdoor concerts', 'vms-meta-ads'), 'interest', 'venue_local'),
							self::catalog_term('community_calendar_behavior', __('Community calendar / local discovery', 'vms-meta-ads'), 'behavior', 'venue_local'),
						),
					),
					array(
						'key' => 'family_community',
						'label' => __('Family-friendly / community', 'vms-meta-ads'),
						'description' => __('Use when the event should skew broader and more community-safe.', 'vms-meta-ads'),
						'items' => array(
							self::catalog_term('family_activities', __('Family activities', 'vms-meta-ads'), 'interest', 'family_community'),
							self::catalog_term('community_events', __('Community events', 'vms-meta-ads'), 'interest', 'family_community'),
							self::catalog_term('festivals', __('Festivals', 'vms-meta-ads'), 'interest', 'family_community'),
							self::catalog_term('parents_local_events', __('Parents seeking local events', 'vms-meta-ads'), 'behavior', 'family_community'),
						),
					),
				),
				'presets' => array(
					array(
						'key' => 'core_local_concertgoers',
						'label' => __('Core Local Concertgoers', 'vms-meta-ads'),
						'description' => __('Balanced local concert audience with broad music and event-discovery hints.', 'vms-meta-ads'),
						'mode' => 'interest_guided',
						'gender' => 'all',
						'event_type_hint' => 'ticketed_concert',
						'radius_miles' => 15,
						'age_min' => 25,
						'age_max' => 65,
						'terms' => array('live_music', 'concerts', 'local_events', 'event_tickets'),
					),
					array(
						'key' => 'country_tribute_40_plus',
						'label' => __('Country Tribute / 40+', 'vms-meta-ads'),
						'description' => __('Editable starting point for country tribute shows and older-skewing audiences.', 'vms-meta-ads'),
						'mode' => 'interest_guided',
						'gender' => 'all',
						'event_type_hint' => 'tribute_show',
						'radius_miles' => 20,
						'age_min' => 40,
						'age_max' => 65,
						'terms' => array('country_music', 'live_music', 'concerts', 'event_tickets'),
					),
					array(
						'key' => 'classic_rock_50_plus',
						'label' => __('Classic Rock / 50+', 'vms-meta-ads'),
						'description' => __('Older classic-rock audience seed with a broad local concert frame.', 'vms-meta-ads'),
						'mode' => 'interest_guided',
						'gender' => 'all',
						'event_type_hint' => 'ticketed_concert',
						'radius_miles' => 20,
						'age_min' => 45,
						'age_max' => 65,
						'terms' => array('classic_rock', 'concerts', 'live_music', 'local_events'),
					),
					array(
						'key' => 'buffett_beach_summer',
						'label' => __('Buffett / Beach / Summer crowd', 'vms-meta-ads'),
						'description' => __('Seasonal, beach, and trop-rock leaning audience starter.', 'vms-meta-ads'),
						'mode' => 'interest_guided',
						'gender' => 'all',
						'event_type_hint' => 'festival',
						'radius_miles' => 20,
						'age_min' => 30,
						'age_max' => 65,
						'terms' => array('beach_trop_rock', 'music_festivals', 'outdoor_concerts', 'things_to_do_weekend'),
					),
					array(
						'key' => 'outer_towns_awareness',
						'label' => __('Outer Towns awareness', 'vms-meta-ads'),
						'description' => __('Lighter interest stack for awareness outside the tight core radius.', 'vms-meta-ads'),
						'mode' => 'broad_local',
						'gender' => 'all',
						'event_type_hint' => 'venue_awareness',
						'radius_miles' => 25,
						'age_min' => 25,
						'age_max' => 65,
						'terms' => array('local_entertainment', 'local_events'),
					),
					array(
						'key' => 'young_family_friendly',
						'label' => __('Young family-friendly event', 'vms-meta-ads'),
						'description' => __('Community-safe starting point for broader family attendance.', 'vms-meta-ads'),
						'mode' => 'interest_guided',
						'gender' => 'all',
						'event_type_hint' => 'family_community',
						'radius_miles' => 15,
						'age_min' => 28,
						'age_max' => 50,
						'terms' => array('family_activities', 'community_events', 'festivals', 'things_to_do_weekend'),
					),
				),
				'default_state' => self::default_state(),
			);
		}

		public static function default_state(): array
		{
			return array(
				'version' => self::VERSION,
				'mode' => 'broad_local',
				'gender' => 'all',
				'event_type_hint' => 'ticketed_concert',
				'preset_key' => '',
				'preset_label' => '',
				'advantage_audience' => 0,
				'advantage_detailed_targeting' => 0,
				'artist_inspirations' => array(),
				'terms' => array(),
				'exclusions' => array(),
			);
		}

		public static function normalize_state($raw, array $fallbacks = array()): array
		{
			$state = self::default_state();
			$raw = is_array($raw) ? $raw : array();
			$fallback_mode = sanitize_key((string) ($fallbacks['mode'] ?? ''));
			$fallback_gender = sanitize_key((string) ($fallbacks['gender'] ?? ''));
			$fallback_event_type = sanitize_key((string) ($fallbacks['event_type_hint'] ?? ''));

			$state['mode'] = self::normalize_mode($raw['mode'] ?? $fallback_mode ?: $state['mode']);
			$state['gender'] = self::normalize_gender($raw['gender'] ?? $fallback_gender ?: $state['gender']);
			$state['event_type_hint'] = self::normalize_event_type($raw['event_type_hint'] ?? $fallback_event_type ?: $state['event_type_hint']);
			$state['preset_key'] = sanitize_key((string) ($raw['preset_key'] ?? ''));
			$state['preset_label'] = sanitize_text_field((string) ($raw['preset_label'] ?? ''));
			$state['advantage_audience'] = !empty($raw['advantage_audience']) ? 1 : 0;
			$state['advantage_detailed_targeting'] = !empty($raw['advantage_detailed_targeting']) ? 1 : 0;
			$state['artist_inspirations'] = self::normalize_string_list($raw['artist_inspirations'] ?? array(), 12);
			$state['terms'] = self::normalize_terms($raw['terms'] ?? array());
			$state['exclusions'] = self::normalize_terms($raw['exclusions'] ?? array());

			return $state;
		}

		public static function build_state_from_legacy(array $interest_labels, string $gender = 'all'): array
		{
			$labels = self::normalize_string_list($interest_labels, 20);
			$state = self::default_state();
			$state['gender'] = self::normalize_gender($gender);
			if (empty($labels)) {
				return $state;
			}

			$state['mode'] = 'interest_guided';
			foreach ($labels as $label) {
				$state['terms'][] = self::normalize_term(array(
					'key' => sanitize_title($label),
					'label' => $label,
					'targeting_type' => 'interest',
					'group' => 'legacy',
					'source' => 'legacy',
					'validation_status' => 'unvalidated',
				));
			}

			return $state;
		}

		public static function interest_ids_for_meta(array $state): array
		{
			$state = self::normalize_state($state);
			$ids = array();
			foreach ((array) $state['terms'] as $term) {
				if (!is_array($term)) {
					continue;
				}
				if (($term['targeting_type'] ?? '') !== 'interest') {
					continue;
				}
				$id = trim((string) ($term['meta_targeting_id'] ?? ''));
				if ($id !== '' && ctype_digit($id) && ($term['validation_status'] ?? '') === 'valid') {
					$ids[] = $id;
				}
			}
			return array_values(array_unique($ids));
		}

		public static function gender_for_meta(array $state): array
		{
			$state = self::normalize_state($state);
			if ($state['gender'] === 'women') {
				return array(1);
			}
			if ($state['gender'] === 'men') {
				return array(2);
			}
			return array();
		}

		public static function build_summary(array $state, array $context = array()): array
		{
			$state = self::normalize_state($state, array(
				'gender' => (string) ($context['gender'] ?? 'all'),
			));

			$mode_label = self::mode_label((string) ($state['mode'] ?? 'broad_local'));
			$gender_label = self::gender_label((string) ($state['gender'] ?? 'all'));
			$radius = max(1, absint($context['radius_miles'] ?? 15));
			$age_min = max(13, absint($context['age_min'] ?? 21));
			$age_max = max($age_min, absint($context['age_max'] ?? 65));
			$anchor = sanitize_text_field((string) ($context['targeting_address'] ?? ''));
			$placements_mode = sanitize_key((string) ($context['placements_mode'] ?? 'automatic'));

			$active_terms = array();
			$pending_terms = array();
			$deprecated_terms = array();
			$unavailable_terms = array();

			foreach ((array) $state['terms'] as $term) {
				if (!is_array($term)) {
					continue;
				}
				$label = sanitize_text_field((string) ($term['label'] ?? ''));
				if ($label === '') {
					continue;
				}
				$status = (string) ($term['validation_status'] ?? 'unvalidated');
				if ($status === 'deprecated') {
					$deprecated_terms[] = $label;
					continue;
				}
				if ($status === 'unavailable') {
					$unavailable_terms[] = $label;
					continue;
				}
				$active_terms[] = $label;
				if ($status !== 'valid' || empty($term['meta_targeting_id'])) {
					$pending_terms[] = $label;
				}
			}

			$summary_bits = array(
				sprintf(__('Mode: %s', 'vms-meta-ads'), $mode_label),
				sprintf(__('Radius %dmi', 'vms-meta-ads'), $radius),
				sprintf(__('Ages %1$d-%2$d', 'vms-meta-ads'), $age_min, $age_max),
				sprintf(__('Gender: %s', 'vms-meta-ads'), $gender_label),
			);
			if ($anchor !== '') {
				$summary_bits[] = sprintf(__('Anchor: %s', 'vms-meta-ads'), $anchor);
			}
			if (!empty($active_terms)) {
				$summary_bits[] = sprintf(__('Terms: %s', 'vms-meta-ads'), implode(', ', $active_terms));
			}
			if (!empty($state['artist_inspirations'])) {
				$summary_bits[] = sprintf(__('Artist inspiration: %s', 'vms-meta-ads'), implode(', ', $state['artist_inspirations']));
			}
			if ($placements_mode === 'manual') {
				$summary_bits[] = __('Manual placements', 'vms-meta-ads');
			}

			$warnings = array();
			if ($state['mode'] === 'broad_local' && !empty($active_terms)) {
				$warnings[] = __('Detailed targeting ideas are saved, but Broad/local mode keeps them inactive until you switch to Interest-guided.', 'vms-meta-ads');
			}
			if (!empty($pending_terms)) {
				$warnings[] = sprintf(
					_n(
						'%d targeting idea still needs Meta validation before it can be sent.',
						'%d targeting ideas still need Meta validation before they can be sent.',
						count($pending_terms),
						'vms-meta-ads'
					),
					count($pending_terms)
				);
			}
			if (!empty($deprecated_terms)) {
				$warnings[] = sprintf(__('Deprecated targeting labels saved for review: %s.', 'vms-meta-ads'), implode(', ', $deprecated_terms));
			}
			if (!empty($unavailable_terms)) {
				$warnings[] = sprintf(__('Unavailable targeting labels saved for review: %s.', 'vms-meta-ads'), implode(', ', $unavailable_terms));
			}
			if (!empty($state['artist_inspirations'])) {
				$warnings[] = __('Artist/band inspiration is stored as a lookup seed only and is not sent until matched to a validated Meta targeting ID.', 'vms-meta-ads');
			}
			if (!empty($state['advantage_detailed_targeting'])) {
				$warnings[] = __('Detailed targeting expansion intent is stored for later review, but its exact Marketing API payload should be revalidated before any live write path uses it.', 'vms-meta-ads');
			}

			return array(
				'summary' => implode(', ', $summary_bits),
				'warnings' => array_values(array_unique($warnings)),
				'active_terms' => array_values(array_unique($active_terms)),
				'pending_terms' => array_values(array_unique($pending_terms)),
				'deprecated_terms' => array_values(array_unique($deprecated_terms)),
				'unavailable_terms' => array_values(array_unique($unavailable_terms)),
			);
		}

		private static function catalog_term(string $key, string $label, string $type, string $group): array
		{
			return array(
				'key' => sanitize_key($key),
				'label' => sanitize_text_field($label),
				'targeting_type' => in_array($type, self::TERM_TYPE_ALLOWED, true) ? $type : 'interest',
				'group' => sanitize_key($group),
				'provider' => 'meta',
				'meta_targeting_id' => '',
				'validation_status' => 'unvalidated',
				'source' => 'suggestion',
			);
		}

		private static function normalize_mode($value): string
		{
			$value = sanitize_key((string) $value);
			return in_array($value, self::MODE_ALLOWED, true) ? $value : 'broad_local';
		}

		private static function normalize_gender($value): string
		{
			$value = sanitize_key((string) $value);
			return in_array($value, self::GENDER_ALLOWED, true) ? $value : 'all';
		}

		private static function normalize_event_type($value): string
		{
			$value = sanitize_key((string) $value);
			return in_array($value, self::EVENT_TYPE_ALLOWED, true) ? $value : 'ticketed_concert';
		}

		private static function normalize_string_list($value, int $limit = 12): array
		{
			$items = array();
			if (is_string($value)) {
				$value = preg_split('/\s*,\s*/', $value);
			}
			foreach ((array) $value as $item) {
				$item = sanitize_text_field((string) $item);
				if ($item === '') {
					continue;
				}
				$items[] = $item;
				if (count($items) >= $limit) {
					break;
				}
			}
			return array_values(array_unique($items));
		}

		private static function normalize_terms($value): array
		{
			$terms = array();
			foreach ((array) $value as $item) {
				$term = self::normalize_term($item);
				if (empty($term['label'])) {
					continue;
				}
				$signature = md5(wp_json_encode(array(
					(string) ($term['key'] ?? ''),
					(string) ($term['label'] ?? ''),
					(string) ($term['targeting_type'] ?? ''),
				)));
				$terms[$signature] = $term;
				if (count($terms) >= 30) {
					break;
				}
			}
			return array_values($terms);
		}

		private static function normalize_term($value): array
		{
			$value = is_array($value) ? $value : array();
			$label = sanitize_text_field((string) ($value['label'] ?? ''));
			$key = sanitize_key((string) ($value['key'] ?? sanitize_title($label)));
			$type = sanitize_key((string) ($value['targeting_type'] ?? 'interest'));
			$status = sanitize_key((string) ($value['validation_status'] ?? 'unvalidated'));
			$source = sanitize_key((string) ($value['source'] ?? 'manual'));

			if (!in_array($type, self::TERM_TYPE_ALLOWED, true)) {
				$type = 'interest';
			}
			if (!in_array($status, self::STATUS_ALLOWED, true)) {
				$status = 'unvalidated';
			}
			if (!in_array($source, self::SOURCE_ALLOWED, true)) {
				$source = 'manual';
			}

			$meta_targeting_id = preg_replace('/\D+/', '', (string) ($value['meta_targeting_id'] ?? ''));
			if ($meta_targeting_id === null) {
				$meta_targeting_id = '';
			}
			if ($meta_targeting_id !== '' && $status === 'unvalidated') {
				$status = 'valid';
			}

			return array(
				'key' => $key,
				'label' => $label,
				'targeting_type' => $type,
				'group' => sanitize_key((string) ($value['group'] ?? 'manual')),
				'provider' => sanitize_key((string) ($value['provider'] ?? 'meta')) ?: 'meta',
				'meta_targeting_id' => ctype_digit($meta_targeting_id) ? $meta_targeting_id : '',
				'validation_status' => $status,
				'source' => $source,
				'note' => sanitize_text_field((string) ($value['note'] ?? '')),
			);
		}

		private static function mode_label(string $mode): string
		{
			switch ($mode) {
				case 'interest_guided':
					return __('Interest-guided', 'vms-meta-ads');
				case 'retargeting':
					return __('Past-engagement / retargeting', 'vms-meta-ads');
				case 'lookalike':
					return __('Lookalike', 'vms-meta-ads');
				default:
					return __('Broad/local', 'vms-meta-ads');
			}
		}

		private static function gender_label(string $gender): string
		{
			switch ($gender) {
				case 'women':
					return __('Women', 'vms-meta-ads');
				case 'men':
					return __('Men', 'vms-meta-ads');
				default:
					return __('All genders', 'vms-meta-ads');
			}
		}
	}
}
