<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Performance_Service')) {
	class VMS_Meta_Ads_Performance_Service {
		private const CACHE_TTL = 300;
		private const CACHE_TTL_ERROR = 60;
		private const MAX_BUILDS = 50;

		public static function get_dashboard_data(array $request = array()): array
		{
			$force_refresh = !empty($request['refresh']);
			$range = self::resolve_range($request);
			$connection = self::connection_settings();
			$builds = self::list_reportable_builds(self::MAX_BUILDS);

			$data = array(
				'force_refresh' => $force_refresh,
				'range' => $range,
				'connection' => $connection,
				'builds' => $builds,
				'rows' => array(),
				'summary' => self::empty_summary(),
				'trend' => self::empty_trend($range),
				'has_connection' => !is_wp_error($connection),
				'has_builds' => !empty($builds),
				'generated_at' => current_time('timestamp'),
			);

			if (is_wp_error($connection) || empty($builds)) {
				return $data;
			}

			$summary = self::empty_summary();
			foreach ($builds as $build) {
				$reference = self::resolve_meta_reference($build);
				$row = array(
					'build' => $build,
					'reference' => $reference,
					'ok' => false,
					'empty' => false,
					'error' => '',
					'metrics' => self::empty_metrics(),
					'fetched_at' => 0,
				);

				if (is_wp_error($reference)) {
					$row['error'] = $reference->get_error_message();
					$data['rows'][] = $row;
					continue;
				}

				$insights = self::fetch_insights($connection, $reference, $range, $force_refresh);
				if (is_wp_error($insights)) {
					$row['error'] = $insights->get_error_message();
					$data['rows'][] = $row;
					continue;
				}

				$row['ok'] = true;
				$row['empty'] = !empty($insights['empty']);
				$row['metrics'] = is_array($insights['metrics'] ?? null) ? $insights['metrics'] : self::empty_metrics();
				$row['series'] = is_array($insights['series'] ?? null) ? $insights['series'] : array();
				$row['fetched_at'] = absint($insights['fetched_at'] ?? 0);
				$data['rows'][] = $row;

				if (!$row['empty']) {
					$summary = self::accumulate_summary($summary, $row['metrics']);
					$data['trend'] = self::accumulate_trend($data['trend'], $row['series']);
				}
			}

			$data['summary'] = self::finalize_summary($summary);
			$data['trend'] = self::finalize_trend($data['trend'], $range);
			return $data;
		}

		public static function get_refresh_url(array $args = array()): string
		{
			$params = array(
				'page' => 'vms-ma-ads-performance',
				'preset' => sanitize_key((string) ($args['preset'] ?? 'last_30')),
				'refresh' => 1,
			);
			if (!empty($args['start'])) {
				$params['start'] = sanitize_text_field((string) $args['start']);
			}
			if (!empty($args['end'])) {
				$params['end'] = sanitize_text_field((string) $args['end']);
			}
			if (!empty($args['sort'])) {
				$params['sort'] = sanitize_key((string) $args['sort']);
			}
			if (!empty($args['order'])) {
				$params['order'] = ('asc' === strtolower((string) $args['order'])) ? 'asc' : 'desc';
			}
			$url = add_query_arg($params, admin_url('admin.php'));
			return wp_nonce_url($url, 'vms_ma_perf_refresh');
		}

		public static function verify_refresh_request(array $request): bool
		{
			if (empty($request['refresh'])) {
				return false;
			}
			$nonce = sanitize_text_field((string) ($request['_wpnonce'] ?? ''));
			return ($nonce !== '' && wp_verify_nonce($nonce, 'vms_ma_perf_refresh'));
		}

		public static function get_presets(): array
		{
			return array(
				'last_7' => __('Last 7 days', 'vms-meta-ads'),
				'last_30' => __('Last 30 days', 'vms-meta-ads'),
				'this_month' => __('This month', 'vms-meta-ads'),
				'lifetime' => __('Lifetime', 'vms-meta-ads'),
			);
		}


		public static function get_event_plan_snapshot(int $event_plan_id, array $request = array()): array
		{
			$range = self::resolve_range(array(
				'preset' => sanitize_key((string) ($request['preset'] ?? 'last_7')),
			));
			$data = array(
				'ok' => false,
				'empty' => true,
				'error' => '',
				'range' => $range,
				'build' => array(),
				'reference' => array(),
				'metrics' => self::empty_metrics(),
				'series' => array(),
				'fetched_at' => 0,
			);

			if ($event_plan_id < 1) {
				$data['error'] = __('Missing event plan ID.', 'vms-meta-ads');
				return $data;
			}

			$connection = self::connection_settings();
			if (is_wp_error($connection)) {
				$data['error'] = $connection->get_error_message();
				return $data;
			}

			$builds = VMS_Meta_Ads_Builds_Service::list_builds(array(
				'event_plan_id' => $event_plan_id,
				'limit' => max(1, min(12, absint($request['limit'] ?? 6))),
			));
			if (empty($builds)) {
				$data['error'] = __('No Meta ad build found for this event yet.', 'vms-meta-ads');
				return $data;
			}

			$first_error = '';
			foreach ($builds as $build) {
				if (!is_array($build)) {
					continue;
				}
				$reference = self::resolve_meta_reference($build);
				if (is_wp_error($reference)) {
					if ($first_error === '') {
						$first_error = $reference->get_error_message();
					}
					continue;
				}

				$insights = self::fetch_insights($connection, $reference, $range, !empty($request['refresh']));
				if (is_wp_error($insights)) {
					if ($first_error === '') {
						$first_error = $insights->get_error_message();
					}
					continue;
				}

				$data['ok'] = true;
				$data['empty'] = !empty($insights['empty']);
				$data['build'] = $build;
				$data['reference'] = $reference;
				$data['metrics'] = is_array($insights['metrics'] ?? null) ? $insights['metrics'] : self::empty_metrics();
				$data['series'] = is_array($insights['series'] ?? null) ? $insights['series'] : array();
				$data['fetched_at'] = absint($insights['fetched_at'] ?? 0);
				return $data;
			}

			$data['error'] = ($first_error !== '') ? $first_error : __('No Meta campaign, ad set, or ad ID is available for this event yet.', 'vms-meta-ads');
			return $data;
		}

		private static function resolve_range(array $request): array
		{
			$preset = sanitize_key((string) ($request['preset'] ?? 'last_30'));
			$allowed = array_keys(self::get_presets());
			if (!in_array($preset, $allowed, true)) {
				$preset = 'last_30';
			}

			$timezone = wp_timezone();
			$today = new DateTimeImmutable('now', $timezone);
			$today_date = $today->format('Y-m-d');
			$start = $today_date;
			$end = $today_date;
			$label = self::get_presets()[$preset] ?? __('Last 30 days', 'vms-meta-ads');

			switch ($preset) {
				case 'last_7':
					$start = $today->modify('-6 days')->format('Y-m-d');
					break;
				case 'this_month':
					$start = $today->modify('first day of this month')->format('Y-m-d');
					break;
				case 'lifetime':
					$start = '';
					$end = '';
					break;
				case 'last_30':
				default:
					$start = $today->modify('-29 days')->format('Y-m-d');
					break;
			}

			return array(
				'preset' => $preset,
				'label' => $label,
				'start' => $start,
				'end' => $end,
			);
		}


		private static function get_effective_ad_account_id(): string
		{
			$settings = VMS_Meta_Ads_Utils::get_settings();
			$social_connection = apply_filters('vms_social_meta_connection', null);
			$using_social = is_array($social_connection) && !empty($social_connection['ad_account_id']) && empty($settings['meta_ad_account_override']);
			$effective_ad_account_id = $using_social ? (string) ($social_connection['ad_account_id'] ?? '') : (string) ($settings['meta_ad_account_id'] ?? '');
			return self::normalize_ad_account_id($effective_ad_account_id);
		}

		private static function connection_settings()
		{
			$settings = VMS_Meta_Ads_Utils::get_settings();
			$social_connection = apply_filters('vms_social_meta_connection', null);
			$using_social = is_array($social_connection) && !empty($social_connection['ad_account_id']) && empty($settings['meta_ad_account_override']);
			$effective_ad_account_id = $using_social ? (string) ($social_connection['ad_account_id'] ?? '') : (string) ($settings['meta_ad_account_id'] ?? '');
			$effective_ad_account_id = self::normalize_ad_account_id($effective_ad_account_id);
			$token = VMS_Meta_Ads_Utils::decrypt_token((string) ($settings['meta_access_token_encrypted'] ?? ''));

			if ($effective_ad_account_id === '') {
				return new WP_Error('missing_ad_account_id', __('Add your Meta ad account ID in Settings before opening Performance.', 'vms-meta-ads'));
			}
			if ($token === '') {
				return new WP_Error('missing_access_token', __('Save a Meta access token in Settings before opening Performance.', 'vms-meta-ads'));
			}

			$settings['meta_ad_account_id'] = $effective_ad_account_id;
			$settings['token'] = $token;
			return $settings;
		}

		private static function normalize_ad_account_id(string $value): string
		{
			$value = trim($value);
			if ($value === '') {
				return '';
			}
			$value = preg_replace('/^act_/i', '', $value);
			return $value !== null ? $value : '';
		}

		private static function list_reportable_builds(int $limit): array
		{
			$items = VMS_Meta_Ads_Builds_Service::list_builds(array(
				'limit' => max(1, min(self::MAX_BUILDS, $limit)),
			));
			if (empty($items)) {
				return array();
			}

			$rows = array();
			foreach ($items as $build) {
				if (!is_array($build)) {
					continue;
				}
				$reference = self::resolve_meta_reference($build);
				if (is_wp_error($reference)) {
					continue;
				}
				$rows[] = $build;
			}
			return $rows;
		}

		private static function resolve_meta_reference(array $build)
		{
			$meta_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			$campaign_id = sanitize_text_field((string) ($meta_ids['campaign_id'] ?? $build['meta_campaign_id'] ?? ''));
			$adset_id = sanitize_text_field((string) ($meta_ids['adset_id'] ?? ''));
			$ad_id = sanitize_text_field((string) ($meta_ids['ad_id'] ?? ''));

			if (($adset_id === '' || $ad_id === '') && !empty($build['tiers']) && is_array($build['tiers'])) {
				foreach ((array) $build['tiers'] as $tier) {
					if (!is_array($tier)) {
						continue;
					}
					if ($adset_id === '' && !empty($tier['meta_adset_id'])) {
						$adset_id = sanitize_text_field((string) $tier['meta_adset_id']);
					}
					if ($ad_id === '' && !empty($tier['meta_ad_id'])) {
						$ad_id = sanitize_text_field((string) $tier['meta_ad_id']);
					}
				}
			}

			$ad_account_id = self::get_effective_ad_account_id();
			$manager_url = 'https://adsmanager.facebook.com/';
			if ($ad_account_id !== '') {
				$manager_url = 'https://adsmanager.facebook.com/adsmanager/manage/campaigns?act=' . rawurlencode($ad_account_id);
			}

			if ($ad_id !== '') {
				return array(
					'level' => 'ad',
					'object_id' => $ad_id,
					'object_label' => __('Ad', 'vms-meta-ads'),
					'manager_url' => $manager_url,
				);
			}
			if ($adset_id !== '') {
				return array(
					'level' => 'adset',
					'object_id' => $adset_id,
					'object_label' => __('Ad Set', 'vms-meta-ads'),
					'manager_url' => $manager_url,
				);
			}
			if ($campaign_id !== '') {
				return array(
					'level' => 'campaign',
					'object_id' => $campaign_id,
					'object_label' => __('Campaign', 'vms-meta-ads'),
					'manager_url' => $manager_url,
				);
			}

			return new WP_Error('missing_meta_reference', __('This build has no Meta campaign, ad set, or ad ID yet.', 'vms-meta-ads'));
		}

		private static function fetch_insights(array $settings, array $reference, array $range, bool $force_refresh)
		{
			$cache_key = 'vms_ma_perf_' . md5(wp_json_encode(array(
				'v' => (defined('VMS_MA_VERSION') ? VMS_MA_VERSION : '1'),
				'object_id' => $reference['object_id'],
				'level' => $reference['level'],
				'preset' => $range['preset'],
				'start' => $range['start'],
				'end' => $range['end'],
			)));

			if (!$force_refresh) {
				$cached = get_transient($cache_key);
				if (is_wp_error($cached) || is_array($cached)) {
					return $cached;
				}
			}

			$query = array(
				'fields' => implode(',', array(
					'impressions',
					'reach',
					'spend',
					'cpm',
					'clicks',
					'ctr',
					'inline_link_clicks',
					'frequency',
					'actions',
					'cost_per_action_type',
					'date_start',
					'date_stop',
				)),
				'level' => (string) $reference['level'],
			);

			if ($range['preset'] === 'lifetime') {
				$query['date_preset'] = 'lifetime';
				$query['limit'] = 1;
			} else {
				$query['time_range'] = wp_json_encode(array(
					'since' => $range['start'],
					'until' => $range['end'],
				));
				$query['time_increment'] = 1;
				$query['limit'] = 90;
			}

			$response = self::meta_get_request(
				$settings,
				trailingslashit((string) $reference['object_id']) . 'insights',
				$query,
				'fetch_performance',
				'performance',
				20
			);

			if (is_wp_error($response)) {
				return $response;
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || (is_array($body) && isset($body['error']))) {
				$error = self::meta_error_from_body($body, $code);
				set_transient($cache_key, $error, self::CACHE_TTL_ERROR);
				return $error;
			}

			$rows = is_array($body['data'] ?? null) ? array_values((array) $body['data']) : array();
			$payload = array(
				'empty' => empty($rows),
				'metrics' => self::extract_metrics_from_rows($rows),
				'series' => self::extract_series($rows),
				'fetched_at' => current_time('timestamp'),
			);
			set_transient($cache_key, $payload, self::CACHE_TTL);
			return $payload;
		}

		private static function extract_metrics_from_rows(array $rows): array
		{
			if (empty($rows)) {
				return self::empty_metrics();
			}

			$summary = self::empty_metrics();
			$primary_row = array();
			$best_spend = -1.0;

			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$impressions = self::to_int($row['impressions'] ?? 0);
				$spend = self::to_float($row['spend'] ?? 0);
				$link_clicks = self::to_int($row['inline_link_clicks'] ?? 0);
				$summary['spend'] += $spend;
				$summary['impressions'] += $impressions;
				$summary['reach'] += self::to_int($row['reach'] ?? 0);
				$summary['frequency'] += self::to_float($row['frequency'] ?? 0);
				$summary['clicks'] += self::to_int($row['clicks'] ?? 0);
				$summary['link_clicks'] += $link_clicks;
				$summary['ctr'] += self::to_float($row['ctr'] ?? 0);
				$summary['cpm'] += self::to_float($row['cpm'] ?? 0);
				$summary['date_start'] = sanitize_text_field((string) ($summary['date_start'] === '' ? ($row['date_start'] ?? '') : min($summary['date_start'], sanitize_text_field((string) ($row['date_start'] ?? '')))));
				$summary['date_stop'] = sanitize_text_field((string) ($summary['date_stop'] === '' ? ($row['date_stop'] ?? '') : max($summary['date_stop'], sanitize_text_field((string) ($row['date_stop'] ?? '')))));
				if ($spend > $best_spend) {
					$best_spend = $spend;
					$primary_row = $row;
				}
			}

			$summary['link_ctr'] = ($summary['impressions'] > 0) ? (($summary['link_clicks'] / $summary['impressions']) * 100) : 0.0;
			$summary['link_cpc'] = ($summary['link_clicks'] > 0) ? ($summary['spend'] / $summary['link_clicks']) : 0.0;
			$summary['ctr'] = ($summary['impressions'] > 0) ? (($summary['clicks'] / $summary['impressions']) * 100) : 0.0;
			$summary['cpm'] = ($summary['impressions'] > 0) ? (($summary['spend'] / $summary['impressions']) * 1000) : 0.0;
			$result = self::extract_primary_result($primary_row);
			$summary['result_label'] = sanitize_text_field((string) ($result['label'] ?? ''));
			$summary['result_count'] = self::to_float($result['count'] ?? 0);
			$summary['cost_per_result'] = self::to_float($result['cost'] ?? 0);
			return $summary;
		}

		private static function extract_series(array $rows): array
		{
			$series = array();
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$date = sanitize_text_field((string) ($row['date_start'] ?? $row['date_stop'] ?? ''));
				if ($date === '') {
					continue;
				}
				if (!isset($series[$date])) {
					$series[$date] = array(
						'date' => $date,
						'spend' => 0.0,
						'impressions' => 0,
						'link_clicks' => 0,
						'reach' => 0,
					);
				}
				$series[$date]['spend'] += self::to_float($row['spend'] ?? 0);
				$series[$date]['impressions'] += self::to_int($row['impressions'] ?? 0);
				$series[$date]['link_clicks'] += self::to_int($row['inline_link_clicks'] ?? 0);
				$series[$date]['reach'] += self::to_int($row['reach'] ?? 0);
			}
			ksort($series);
			foreach ($series as $date => $point) {
				$impressions = max(0, (int) ($point['impressions'] ?? 0));
				$link_clicks = max(0, (int) ($point['link_clicks'] ?? 0));
				$series[$date]['link_ctr'] = ($impressions > 0) ? (($link_clicks / $impressions) * 100) : 0.0;
			}
			return array_values($series);
		}

		private static function empty_trend(array $range): array
		{
			return array(
				'available' => false,
				'start' => sanitize_text_field((string) ($range['start'] ?? '')),
				'end' => sanitize_text_field((string) ($range['end'] ?? '')),
				'points' => array(),
				'map' => array(),
			);
		}

		private static function accumulate_trend(array $trend, array $series): array
		{
			if (empty($series)) {
				return $trend;
			}
			$trend['available'] = true;
			if (!isset($trend['map']) || !is_array($trend['map'])) {
				$trend['map'] = array();
			}
			foreach ($series as $point) {
				if (!is_array($point)) {
					continue;
				}
				$date = sanitize_text_field((string) ($point['date'] ?? ''));
				if ($date === '') {
					continue;
				}
				if (!isset($trend['map'][$date])) {
					$trend['map'][$date] = array(
						'date' => $date,
						'spend' => 0.0,
						'impressions' => 0,
						'link_clicks' => 0,
						'reach' => 0,
					);
				}
				$trend['map'][$date]['spend'] += self::to_float($point['spend'] ?? 0);
				$trend['map'][$date]['impressions'] += self::to_int($point['impressions'] ?? 0);
				$trend['map'][$date]['link_clicks'] += self::to_int($point['link_clicks'] ?? 0);
				$trend['map'][$date]['reach'] += self::to_int($point['reach'] ?? 0);
			}
			return $trend;
		}

		private static function finalize_trend(array $trend, array $range): array
		{
			if (($range['preset'] ?? '') === 'lifetime') {
				$trend['available'] = false;
				$trend['points'] = array();
				unset($trend['map']);
				return $trend;
			}
			$map = isset($trend['map']) && is_array($trend['map']) ? $trend['map'] : array();
			$start = sanitize_text_field((string) ($range['start'] ?? ''));
			$end = sanitize_text_field((string) ($range['end'] ?? ''));
			$points = array();
			if ($start !== '' && $end !== '') {
				try {
					$cursor = new DateTimeImmutable($start, wp_timezone());
					$finish = new DateTimeImmutable($end, wp_timezone());
					while ($cursor <= $finish) {
						$date = $cursor->format('Y-m-d');
						$point = is_array($map[$date] ?? null) ? $map[$date] : array('date' => $date, 'spend' => 0.0, 'impressions' => 0, 'link_clicks' => 0, 'reach' => 0);
						$impressions = max(0, (int) ($point['impressions'] ?? 0));
						$link_clicks = max(0, (int) ($point['link_clicks'] ?? 0));
						$point['link_ctr'] = ($impressions > 0) ? (($link_clicks / $impressions) * 100) : 0.0;
						$points[] = $point;
						$cursor = $cursor->modify('+1 day');
					}
				} catch (Throwable $e) {
					$points = array_values($map);
				}
			} else {
				$points = array_values($map);
			}
			$trend['points'] = $points;
			$trend['available'] = !empty($points);
			unset($trend['map']);
			return $trend;
		}

		private static function extract_primary_result(array $row): array
		{
			$actions = is_array($row['actions'] ?? null) ? (array) $row['actions'] : array();
			$costs = is_array($row['cost_per_action_type'] ?? null) ? (array) $row['cost_per_action_type'] : array();
			if (empty($actions)) {
				return array('label' => '', 'count' => 0, 'cost' => 0);
			}

			$priority = array(
				'lead',
				'onsite_conversion.lead_grouped',
				'messaging_conversation_started_7d',
				'onsite_conversion.messaging_conversation_started_7d',
				'offsite_conversion.messaging_conversation_started_7d',
				'event_response',
				'landing_page_view',
				'link_click',
				'post_engagement',
			);

			$action_map = array();
			foreach ($actions as $action) {
				if (!is_array($action)) {
					continue;
				}
				$type = sanitize_text_field((string) ($action['action_type'] ?? ''));
				if ($type === '') {
					continue;
				}
				$action_map[$type] = self::to_float($action['value'] ?? 0);
			}

			$cost_map = array();
			foreach ($costs as $cost) {
				if (!is_array($cost)) {
					continue;
				}
				$type = sanitize_text_field((string) ($cost['action_type'] ?? ''));
				if ($type === '') {
					continue;
				}
				$cost_map[$type] = self::to_float($cost['value'] ?? 0);
			}

			foreach ($priority as $type) {
				if (!array_key_exists($type, $action_map)) {
					continue;
				}
				return array(
					'label' => self::humanize_action_type($type),
					'count' => $action_map[$type],
					'cost' => $cost_map[$type] ?? 0,
				);
			}

			$first_type = (string) key($action_map);
			if ($first_type === '') {
				return array('label' => '', 'count' => 0, 'cost' => 0);
			}

			return array(
				'label' => self::humanize_action_type($first_type),
				'count' => $action_map[$first_type] ?? 0,
				'cost' => $cost_map[$first_type] ?? 0,
			);
		}

		private static function humanize_action_type(string $value): string
		{
			$map = array(
				'lead' => __('Leads', 'vms-meta-ads'),
				'onsite_conversion.lead_grouped' => __('Leads', 'vms-meta-ads'),
				'messaging_conversation_started_7d' => __('Conversations', 'vms-meta-ads'),
				'onsite_conversion.messaging_conversation_started_7d' => __('Conversations', 'vms-meta-ads'),
				'offsite_conversion.messaging_conversation_started_7d' => __('Conversations', 'vms-meta-ads'),
				'event_response' => __('Event Responses', 'vms-meta-ads'),
				'landing_page_view' => __('Landing Page Views', 'vms-meta-ads'),
				'link_click' => __('Link Clicks', 'vms-meta-ads'),
				'post_engagement' => __('Post Engagement', 'vms-meta-ads'),
			);
			if (isset($map[$value])) {
				return $map[$value];
			}
			$value = str_replace(array('.', '_'), ' ', $value);
			return ucwords(trim($value));
		}

		private static function empty_metrics(): array
		{
			return array(
				'spend' => 0.0,
				'impressions' => 0,
				'reach' => 0,
				'frequency' => 0.0,
				'clicks' => 0,
				'link_clicks' => 0,
				'link_ctr' => 0.0,
				'link_cpc' => 0.0,
				'ctr' => 0.0,
				'cpm' => 0.0,
				'date_start' => '',
				'date_stop' => '',
				'result_label' => '',
				'result_count' => 0.0,
				'cost_per_result' => 0.0,
			);
		}

		private static function empty_summary(): array
		{
			return array(
				'spend' => 0.0,
				'impressions' => 0,
				'reach' => 0,
				'link_clicks' => 0,
				'live_rows' => 0,
				'link_ctr' => 0.0,
				'link_cpc' => 0.0,
				'cpm' => 0.0,
			);
		}

		private static function accumulate_summary(array $summary, array $metrics): array
		{
			$summary['spend'] += self::to_float($metrics['spend'] ?? 0);
			$summary['impressions'] += self::to_int($metrics['impressions'] ?? 0);
			$summary['reach'] += self::to_int($metrics['reach'] ?? 0);
			$summary['link_clicks'] += self::to_int($metrics['link_clicks'] ?? 0);
			$summary['live_rows']++;
			return $summary;
		}

		private static function finalize_summary(array $summary): array
		{
			$impressions = max(0, (int) ($summary['impressions'] ?? 0));
			$spend = self::to_float($summary['spend'] ?? 0);
			$link_clicks = max(0, (int) ($summary['link_clicks'] ?? 0));
			$summary['link_ctr'] = ($impressions > 0) ? (($link_clicks / $impressions) * 100) : 0.0;
			$summary['link_cpc'] = ($link_clicks > 0) ? ($spend / $link_clicks) : 0.0;
			$summary['cpm'] = ($impressions > 0) ? (($spend / $impressions) * 1000) : 0.0;
			return $summary;
		}

		private static function to_int($value): int
		{
			if (is_numeric($value)) {
				return (int) round((float) $value);
			}
			return 0;
		}

		private static function to_float($value): float
		{
			if (is_numeric($value)) {
				return (float) $value;
			}
			return 0.0;
		}

		private static function meta_get_request(array $settings, string $path, array $query, string $operation, string $context, int $timeout = 20)
		{
			$path = ltrim($path, '/');
			$query_for_log = $query;
			unset($query_for_log['access_token']);
			$endpoint = $path;
			if (!empty($query_for_log)) {
				$endpoint .= '?' . http_build_query($query_for_log);
			}

			return vms_api_attempt_wrap(
				'meta_ads',
				'vms-facebook-ads',
				$operation,
				$context,
				'GET',
				$endpoint,
				array('query' => $query_for_log),
				static function () use ($settings, $path, $query, $timeout) {
					$url = VMS_Meta_Ads_Meta_Endpoints::build_url($settings, $path);
					$url = add_query_arg(array_merge($query, array('access_token' => (string) ($settings['token'] ?? ''))), $url);
					return wp_remote_get($url, array('timeout' => $timeout));
				}
			);
		}

		private static function meta_error_from_body($body, int $status)
		{
			$message = __('Meta Insights request failed.', 'vms-meta-ads');
			if (is_array($body) && isset($body['error']) && is_array($body['error'])) {
				$error = (array) $body['error'];
				$raw = sanitize_text_field((string) ($error['message'] ?? ''));
				if ($raw !== '') {
					$message = $raw;
				}
			}
			return new WP_Error('meta_insights_failed', $message, array('status' => $status));
		}
	}
}
