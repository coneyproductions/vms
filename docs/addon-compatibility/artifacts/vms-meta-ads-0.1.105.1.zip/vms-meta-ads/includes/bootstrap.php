<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads')) {
	class VMS_Meta_Ads {
		public const DB_VERSION = '4';
		public const MODULE_SLUG = 'meta_ads_builder';
		private const GATE_PENDING = 'pending';
		private const GATE_ENABLED = 'enabled';
		private const GATE_LOCKED = 'locked';
		private const GATE_CORE_UNAVAILABLE = 'core_unavailable';
		private const GATE_UNREGISTERED = 'unregistered';
		private static $booted = false;
		private static $gate_status = self::GATE_PENDING;
		private static $module_registered = false;
		private static $docs_source_hook_registered = false;

		public static function init(): void
		{
			self::load_dependencies();
			self::maybe_upgrade_db();
			if (class_exists('VMS_API_Attempts')) {
				VMS_API_Attempts::init();
			}
			if (vms_ma_has_core_function('vms_register_module')) {
				self::register_module();
			}
			add_action('plugins_loaded', array(__CLASS__, 'register_module'), 20);
			add_action('plugins_loaded', array(__CLASS__, 'maybe_boot_module'), 30);
			add_action('admin_notices', array(__CLASS__, 'render_locked_notice'));
		}

		public static function maybe_boot_module(): void
		{
			if (self::$booted) {
				return;
			}
			self::$gate_status = self::module_gate_status();
			if (self::$gate_status !== self::GATE_ENABLED) {
				return;
			}
			self::$booted = true;
			VMS_Meta_Ads_Caps::register();
			VMS_Meta_Ads_Admin::init();
			VMS_Meta_Ads_Rest::init();
			VMS_Meta_Ads_Tours::init();
			VMS_Meta_Ads_Prefill_Service::init();
			VMS_Meta_Ads_Performance_Health_Service::boot();
			add_filter('cron_schedules', array(__CLASS__, 'register_cron_schedules'));
			add_action('init', array(__CLASS__, 'ensure_cron_hooks'));
			add_action('vms_ma_budget_sync_cron', array(__CLASS__, 'run_budget_sync_cron'));
			add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
		}

		public static function register_module(): void
		{
			if (!vms_ma_has_core_function('vms_register_module')) {
				return;
			}
			if (!self::$docs_source_hook_registered) {
				add_action('vms_register_docs_sources', array(__CLASS__, 'register_docs_source'));
				self::$docs_source_hook_registered = true;
			}
			if (self::$module_registered) {
				return;
			}

			self::$module_registered = vms_ma_call_core_function('vms_register_module', array(
				'slug' => self::MODULE_SLUG,
				'name' => 'Meta Ads Builder',
				'version' => VMS_MA_VERSION,
				'premium' => true,
				'description' => 'Meta Ads Builder wizard with copy pack and guarded API scaffold.',
				'source' => 'vms-meta-ads',
			));
		}

		public static function register_docs_source(callable $register): void
		{
			$register(array(
				'module' => 'vms_meta_ads',
				'label' => 'VMS Meta Ads',
				'path' => VMS_MA_PATH . 'docs',
				'public_base' => 'vms-meta-ads',
			));
		}

		public static function is_module_enabled(): bool
		{
			return self::module_gate_status() === self::GATE_ENABLED;
		}

		public static function module_gate_status(): string
		{
			if (!vms_ma_has_core_function('vms_module_is_enabled') || !vms_ma_has_core_function('vms_module_is_registered')) {
				return self::GATE_CORE_UNAVAILABLE;
			}
			if (!vms_ma_call_core_function('vms_module_is_registered', self::MODULE_SLUG)) {
				return self::GATE_UNREGISTERED;
			}
			return vms_ma_call_core_function('vms_module_is_enabled', self::MODULE_SLUG) ? self::GATE_ENABLED : self::GATE_LOCKED;
		}

		public static function render_locked_notice(): void
		{
			if (self::$booted) {
				return;
			}
			if (!is_admin()) {
				return;
			}
			if (!current_user_can('manage_options')) {
				return;
			}
			if (did_action('plugins_loaded')) {
				self::$gate_status = self::module_gate_status();
			}
			if (self::$gate_status === self::GATE_ENABLED || self::$gate_status === self::GATE_PENDING) {
				return;
			}
			$message = __('VMS Meta Ads Builder is installed but locked. Enable premium license access for module slug "meta_ads_builder" to activate it.', 'vms-meta-ads');
			if (self::$gate_status === self::GATE_CORE_UNAVAILABLE) {
				$message = __('VMS Meta Ads Builder stayed locked because the Backstage Venue Manager or legacy VMS module system is unavailable. Activate the venue-management core before using MAB.', 'vms-meta-ads');
			} elseif (self::$gate_status === self::GATE_UNREGISTERED) {
				$message = __('VMS Meta Ads Builder stayed locked because its VMS module registration could not be verified. The plugin will fail closed until the module registry is available.', 'vms-meta-ads');
			}
			echo '<div class="notice notice-warning"><p>' . esc_html($message) . '</p></div>';
		}

		public static function activate(): void
		{
			VMS_Meta_Ads_DB::install();
			if (!class_exists('VMS_API_Attempts')) {
				require_once VMS_MA_PATH . 'includes/diagnostics/class-vms-api-attempts.php';
			}
			if (class_exists('VMS_API_Attempts')) {
				VMS_API_Attempts::create_table();
				VMS_API_Attempts::init();
			}
		}

		public static function deactivate(): void
		{
			VMS_Meta_Ads_Tours::reset_all_tours();
			wp_clear_scheduled_hook('vms_api_attempts_prune_daily');
			wp_clear_scheduled_hook('vms_ma_budget_sync_cron');
		}

		public static function register_cron_schedules(array $schedules): array
		{
			if (!isset($schedules['vms_ma_every_15_minutes'])) {
				$schedules['vms_ma_every_15_minutes'] = array(
					'interval' => 15 * MINUTE_IN_SECONDS,
					'display' => __('Every 15 Minutes (VMS Meta Ads)', 'vms-meta-ads'),
				);
			}
			return $schedules;
		}

		public static function ensure_cron_hooks(): void
		{
			if (!wp_next_scheduled('vms_ma_budget_sync_cron')) {
				wp_schedule_event(time() + 300, 'vms_ma_every_15_minutes', 'vms_ma_budget_sync_cron');
			}
		}

		public static function run_budget_sync_cron(): void
		{
			if (class_exists('VMS_Meta_Ads_Meta_Client')) {
				VMS_Meta_Ads_Meta_Client::run_scheduled_budget_syncs();
			}
		}

		public static function enqueue_assets(): void
		{
			if (!is_admin()) {
				return;
			}
			$page = isset($_GET['page']) ? sanitize_key((string) $_GET['page']) : '';
			if (!in_array($page, array('vms-ma-ads-builder', 'vms-ma-ads-promote', 'vms-ma-ads-performance', 'vms-ma-ads-settings', 'vms-ma-ads-logs'), true)) {
				return;
			}
			$admin_css_ver = file_exists(VMS_MA_PATH . 'assets/admin.css') ? (string) filemtime(VMS_MA_PATH . 'assets/admin.css') : VMS_MA_VERSION;
			$ads_builder_ver = file_exists(VMS_MA_PATH . 'assets/ads-builder.js') ? (string) filemtime(VMS_MA_PATH . 'assets/ads-builder.js') : VMS_MA_VERSION;
			$tours_ver = file_exists(VMS_MA_PATH . 'assets/tours.js') ? (string) filemtime(VMS_MA_PATH . 'assets/tours.js') : VMS_MA_VERSION;
			$api_diag_ver = file_exists(VMS_MA_PATH . 'assets/admin/api-diagnostics.js') ? (string) filemtime(VMS_MA_PATH . 'assets/admin/api-diagnostics.js') : VMS_MA_VERSION;
			wp_enqueue_style('vms-ma-admin', VMS_MA_URL . 'assets/admin.css', array(), $admin_css_ver);
			wp_enqueue_script('vms-ma-ads-builder', VMS_MA_URL . 'assets/ads-builder.js', array('jquery'), $ads_builder_ver, true);
			wp_enqueue_script('vms-ma-guidance', VMS_MA_URL . 'assets/guidance.js', array('jquery'), VMS_MA_VERSION, true);
			wp_enqueue_script('vms-ma-help-mode', VMS_MA_URL . 'assets/help-mode.js', array('jquery'), VMS_MA_VERSION, true);
			if ($page === 'vms-ma-ads-settings') {
				wp_enqueue_script('vms-ma-settings', VMS_MA_URL . 'assets/settings.js', array('jquery'), VMS_MA_VERSION, true);
			}
			if (in_array($page, array('vms-ma-ads-builder', 'vms-ma-ads-settings'), true)) {
				if (vms_ma_has_core_function('vms_enqueue_tour_assets')) {
					vms_ma_call_core_function('vms_enqueue_tour_assets');
				} else {
					$core_url = (string) vms_ma_core_constant('VMS_PLUGIN_URL', '');
					$core_path = (string) vms_ma_core_constant('VMS_PLUGIN_PATH', '');
					$version = (string) vms_ma_core_constant('VMS_VERSION', VMS_MA_VERSION);
					if ($core_url !== '' && $core_path !== '' && file_exists($core_path . 'assets/vendor/driverjs/driver.min.css')) {
						wp_enqueue_style('vms-driverjs', $core_url . 'assets/vendor/driverjs/driver.min.css', array(), $version);
					}
					if ($core_url !== '' && $core_path !== '' && file_exists($core_path . 'assets/vendor/driverjs/driver.min.js')) {
						wp_enqueue_script('vms-driverjs', $core_url . 'assets/vendor/driverjs/driver.min.js', array(), $version, true);
					}
					if ($core_url !== '' && $core_path !== '') {
						wp_enqueue_style('vms-tours', $core_url . 'assets/css/vms-tours.css', array('vms-admin'), $version);
						wp_enqueue_script('vms-tours', $core_url . 'assets/js/vms-tours.js', array(), $version, true);
					}
				}
				wp_enqueue_script('vms-ma-tours', VMS_MA_URL . 'assets/tours.js', array('jquery', 'vms-ma-ads-builder'), $tours_ver, true);
			}
			if ($page === 'vms-ma-ads-builder') {
				wp_enqueue_script('vms-ma-api-diagnostics', VMS_MA_URL . 'assets/admin/api-diagnostics.js', array(), $api_diag_ver, true);
			}
		}

		private static function load_dependencies(): void
		{
			require_once VMS_MA_PATH . 'includes/caps.php';
			require_once VMS_MA_PATH . 'includes/db.php';
			require_once VMS_MA_PATH . 'includes/logger.php';
			require_once VMS_MA_PATH . 'includes/diagnostics/class-vms-api-attempts.php';
			require_once VMS_MA_PATH . 'includes/diagnostics/api-wrap.php';
			require_once VMS_MA_PATH . 'includes/diagnostics/provider-meta-ads.php';
			require_once VMS_MA_PATH . 'includes/utils.php';
			require_once VMS_MA_PATH . 'includes/services-audience-targeting.php';
			require_once VMS_MA_PATH . 'includes/services-ad-builds.php';
			require_once VMS_MA_PATH . 'includes/services-templates.php';
			require_once VMS_MA_PATH . 'includes/services-event-plans.php';
			require_once VMS_MA_PATH . 'includes/services-prefill.php';
			require_once VMS_MA_PATH . 'includes/services-performance.php';
			require_once VMS_MA_PATH . 'includes/services-performance-health.php';
			require_once VMS_MA_PATH . 'includes/services-analytics.php';
			require_once VMS_MA_PATH . 'includes/meta-api/endpoints.php';
			require_once VMS_MA_PATH . 'includes/meta-api/client.php';
			require_once VMS_MA_PATH . 'includes/shared/marketing-assets.php';
			require_once VMS_MA_PATH . 'includes/copy/access-token.php';
			require_once VMS_MA_PATH . 'includes/help/registry.php';
			require_once VMS_MA_PATH . 'includes/admin/enqueue.php';
			require_once VMS_MA_PATH . 'includes/admin/ajax.php';
			require_once VMS_MA_PATH . 'includes/admin/ui-api-diagnostics-panel.php';
			require_once VMS_MA_PATH . 'includes/admin/event-plan-metabox.php';
			require_once VMS_MA_PATH . 'includes/admin/menu.php';
			require_once VMS_MA_PATH . 'includes/rest/routes.php';
			require_once VMS_MA_PATH . 'includes/tours/registry.php';
		}

		private static function maybe_upgrade_db(): void
		{
			if (!is_admin()) {
				return;
			}
			$installed = VMS_Meta_Ads_DB::get_version();
			if ($installed === (string) self::DB_VERSION) {
				return;
			}
			VMS_Meta_Ads_DB::install();
		}
	}
}
