<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Prefill_Service')) {
	class VMS_Meta_Ads_Prefill_Service {
		private const TRANSIENT_TTL = 600;
		private const TRANSIENT_PREFIX = 'vms_ma_builder_prefill_';

		public static function init(): void
		{
			add_action('save_post_vms_event_plan', array(__CLASS__, 'handle_event_plan_save'), 10, 3);
		}

		public static function get_prefill_payload(int $event_plan_id): ?array
		{
			if ($event_plan_id < 1) {
				return null;
			}

			$cache_key = self::get_transient_key($event_plan_id);
			$payload = get_transient($cache_key);
			if ($payload !== false && is_array($payload) && !array_key_exists('builds', $payload)) {
				$payload = false;
			}
			if ($payload === false) {
				$payload = self::build_payload($event_plan_id);
				if ($payload !== null) {
					set_transient($cache_key, $payload, self::TRANSIENT_TTL);
				}
			}
			return is_array($payload) ? $payload : null;
		}

		public static function flush_prefill_cache(int $event_plan_id): void
		{
			if ($event_plan_id < 1) {
				return;
			}
			delete_transient(self::get_transient_key($event_plan_id));
		}

		public static function handle_event_plan_save(int $post_id, WP_Post $post, bool $update): void
		{
			self::flush_prefill_cache($post_id);
		}

		private static function build_payload(int $event_plan_id): ?array
		{
			$event = VMS_Meta_Ads_Event_Plans_Service::get_event_plan($event_plan_id);
			if (!$event) {
				return null;
			}

			$build = null;
			$builds = VMS_Meta_Ads_Builds_Service::list_builds(array(
				'event_plan_id' => $event_plan_id,
				'limit' => 50,
			));
			if (!empty($builds)) {
				$build = reset($builds);
			}

			$destination_url = trim((string) ($event['ticket_url'] ?? ''));
			if ($destination_url === '') {
				$destination_url = trim((string) ($event['event_permalink'] ?? ''));
			}

			return array(
				'id' => $event_plan_id,
				'title' => sanitize_text_field((string) ($event['title'] ?? '')),
				'venue_name' => sanitize_text_field((string) ($event['venue_name'] ?? '')),
				'venue_id' => absint($event['venue_id'] ?? 0),
				'location_label' => sanitize_text_field((string) ($event['location_label'] ?? '')),
				'location_address' => sanitize_text_field((string) ($event['location_address'] ?? '')),
				'location_zip' => sanitize_text_field((string) ($event['location_zip'] ?? '')),
				'location_targeting_anchor' => sanitize_text_field((string) ($event['location_targeting_anchor'] ?? '')),
				'location_has_precise_anchor' => !empty($event['location_has_precise_anchor']) ? 1 : 0,
				'location_country' => sanitize_text_field((string) ($event['location_country'] ?? 'US')),
				'location_latitude' => isset($event['location_latitude']) && is_numeric($event['location_latitude']) ? (float) $event['location_latitude'] : null,
				'location_longitude' => isset($event['location_longitude']) && is_numeric($event['location_longitude']) ? (float) $event['location_longitude'] : null,
				'start_local' => sanitize_text_field((string) ($event['start_local'] ?? '')),
				'start_input' => sanitize_text_field((string) ($event['start_input'] ?? '')),
				'start_display' => sanitize_text_field((string) ($event['start_display'] ?? '')),
				'destination_url' => esc_url_raw($destination_url),
				'ticket_url' => esc_url_raw((string) ($event['ticket_url'] ?? '')),
				'event_permalink' => esc_url_raw((string) ($event['event_permalink'] ?? '')),
				'event_plan_status' => sanitize_key((string) ($event['event_plan_status'] ?? '')),
				'meta_ads_status' => sanitize_text_field((string) ($event['meta_ads_status'] ?? '')),
				'meta_ads_last_updated' => sanitize_text_field((string) ($event['meta_ads_last_updated'] ?? '')),
				'meta_ads_last_exported' => sanitize_text_field((string) ($event['meta_ads_last_exported'] ?? '')),
				'build' => $build,
				'builds' => array_values($builds),
			);
		}

		private static function get_transient_key(int $event_plan_id): string
		{
			return self::TRANSIENT_PREFIX . $event_plan_id;
		}
	}
}
