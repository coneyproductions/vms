<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Ad_Builds_Controller')) {
	class VMS_Meta_Ads_Ad_Builds_Controller {
		public static function register_routes(): void
		{
			register_rest_route('vms-ma/v1', '/ad-builds', array(
				array(
					'methods' => 'GET',
					'callback' => array(__CLASS__, 'get_collection'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
				array(
					'methods' => 'POST',
					'callback' => array(__CLASS__, 'create_build'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));

			register_rest_route('vms-ma/v1', '/ad-builds/(?P<id>\d+)', array(
				array(
					'methods' => 'GET',
					'callback' => array(__CLASS__, 'get_item'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));

			register_rest_route('vms-ma/v1', '/ad-builds/(?P<id>\d+)/(?P<action>archive|duplicate|export|meta-dry-run|meta-create|meta-go-live|meta-sync-budget|meta-update|meta-reset|meta-adopt)', array(
				array(
					'methods' => 'POST',
					'callback' => array(__CLASS__, 'handle_action'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));

			register_rest_route('vms-ma/v1', '/meta-status', array(
				array(
					'methods' => 'GET',
					'callback' => array(__CLASS__, 'meta_status'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));

			register_rest_route('vms-ma/v1', '/meta-discovery', array(
				array(
					'methods' => 'GET',
					'callback' => array(__CLASS__, 'meta_discovery'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));

			register_rest_route('vms-ma/v1', '/go-live', array(
				array(
					'methods' => 'POST',
					'callback' => array(__CLASS__, 'go_live'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));

			register_rest_route('vms-ma/v1', '/pause-all', array(
				array(
					'methods' => 'POST',
					'callback' => array(__CLASS__, 'pause_all'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));
		}

		public static function get_collection(WP_REST_Request $request)
		{
			$items = VMS_Meta_Ads_Builds_Service::list_builds(array(
				'event_plan_id' => absint($request->get_param('event_plan_id')),
				'venue_id' => absint($request->get_param('venue_id')),
				'status' => sanitize_key((string) $request->get_param('status')),
				'limit' => absint($request->get_param('limit') ?: 20),
			));
			return rest_ensure_response(array('items' => $items));
		}

		public static function create_build(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}
			$params = (array) $request->get_json_params();
			$result = VMS_Meta_Ads_Builds_Service::save_build($params);
			if (is_wp_error($result)) {
				return $result;
			}
			return rest_ensure_response(array('item' => $result));
		}

		public static function get_item(WP_REST_Request $request)
		{
			$id = absint($request->get_param('id'));
			$result = VMS_Meta_Ads_Builds_Service::get_build($id);
			if (is_wp_error($result)) {
				return $result;
			}
			return rest_ensure_response(array('item' => $result));
		}

		public static function handle_action(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}
			$action = $request->get_param('action');
			$id = absint($request->get_param('id'));
			if ($action === 'export') {
				$result = VMS_Meta_Ads_Builds_Service::export_copy_pack($id);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response($result);
			}

			if ($action === 'duplicate') {
				$result = VMS_Meta_Ads_Builds_Service::duplicate_build_as_fresh_draft($id);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response(array(
					'item' => $result,
					'message' => sprintf(__('Build #%d was duplicated as a fresh draft with no Meta linkage.', 'vms-meta-ads'), (int) ($result['id'] ?? 0)),
				));
			}

			if ($action === 'archive') {
				$result = VMS_Meta_Ads_Builds_Service::archive_build($id);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response(array(
					'item' => $result,
					'message' => __('Build archived. It is now hidden from the normal working list.', 'vms-meta-ads'),
				));
			}


			if ($action === 'meta-adopt') {
				$params = (array) $request->get_json_params();
				$result = VMS_Meta_Ads_Meta_Client::adopt_existing_bundle($id, $params);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response($result);
			}

			if ($action === 'meta-dry-run') {
				$result = VMS_Meta_Ads_Meta_Client::dry_run_bundle($id);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response($result);
			}

			$params = (array) $request->get_json_params();

			if ($action === 'meta-create') {
				$confirmed = !empty($params['confirm_create_paused']);
				if (!$confirmed) {
					return new WP_Error(
						'confirmation_required',
						__('Create in Meta (PAUSED) requires explicit confirmation because it can create real paused Meta objects in Ads Manager.', 'vms-meta-ads'),
						array('status' => 400)
					);
				}
			}

			if (!VMS_Meta_Ads_Meta_Client::is_enabled()) {
				return new WP_Error(
					'api_disabled',
					__('Meta API creation is disabled in settings. Copy Pack export is available now; API mode remains behind the feature flag.', 'vms-meta-ads'),
					array('status' => 400)
				);
			}

			if ($action === 'meta-create') {
				$result = VMS_Meta_Ads_Meta_Client::create_paused_bundle($id);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response($result);
			}

			if ($action === 'meta-go-live') {
				$confirmed = !empty($params['confirm_spend']) && !empty($params['confirm_reviewed']);
				if (!$confirmed) {
					return new WP_Error('confirmation_required', __('Go Live requires spend and review confirmation.', 'vms-meta-ads'), array('status' => 400));
				}
				$result = VMS_Meta_Ads_Meta_Client::go_live_build($id);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response($result);
			}

			if ($action === 'meta-sync-budget') {
				$result = VMS_Meta_Ads_Meta_Client::sync_budget_build($id);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response($result);
			}

			if ($action === 'meta-update') {
				$result = VMS_Meta_Ads_Meta_Client::update_existing_build($id);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response($result);
			}

			if ($action === 'meta-reset') {
				$result = VMS_Meta_Ads_Meta_Client::reset_meta_link($id);
				if (is_wp_error($result)) {
					return $result;
				}
				return rest_ensure_response($result);
			}

			return new WP_Error('invalid_action', __('Invalid action.', 'vms-meta-ads'), array('status' => 400));
		}

		private static function verify_admin_nonce(WP_REST_Request $request)
		{
			$nonce = (string) $request->get_header('X-WP-Nonce');
			if ($nonce === '' || !wp_verify_nonce($nonce, 'wp_rest')) {
				return new WP_Error('invalid_nonce', __('Invalid request nonce.', 'vms-meta-ads'), array('status' => 403));
			}
			return true;
		}

		public static function meta_status(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}

			$build_id = absint($request->get_param('build_id'));
			if ($build_id > 0) {
				$result = VMS_Meta_Ads_Meta_Client::refresh_status_for_build($build_id);
				if (is_wp_error($result)) {
					if ($result->get_error_code() === 'missing_meta_ids') {
						return rest_ensure_response(self::empty_meta_status_response($result->get_error_message()));
					}
					return $result;
				}
				return rest_ensure_response($result);
			}

			$event_plan_id = absint($request->get_param('event_plan_id'));
			if ($event_plan_id < 1) {
				return new WP_Error('invalid_event_plan', __('A valid Event Plan ID is required.', 'vms-meta-ads'), array('status' => 400));
			}
			$result = VMS_Meta_Ads_Meta_Client::refresh_status($event_plan_id);
			if (is_wp_error($result)) {
				if ($result->get_error_code() === 'missing_meta_ids') {
					return rest_ensure_response(self::empty_meta_status_response($result->get_error_message()));
				}
				return $result;
			}
			return rest_ensure_response($result);
		}

		private static function empty_meta_status_response(string $message): array
		{
			return array(
				'ok' => true,
				'message' => sanitize_text_field($message),
				'campaign' => array(),
				'adset' => array(),
				'ad' => array(),
				'adsets' => array(),
				'adset_count' => 0,
				'ad_variants' => array(),
				'ad_variant_count' => 0,
				'local_meta_status' => '',
				'local_meta_label' => '',
				'readiness' => array(
					'state' => '',
					'items' => array(),
					'notes' => array(),
				),
				'budget_sync' => array(),
				'drift' => array(),
				'open_in_meta_url' => '',
				'ad_account_id' => '',
			);
		}

		public static function meta_discovery(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}
			$event_plan_id = absint($request->get_param('event_plan_id'));
			$build_id = absint($request->get_param('build_id'));
			$result = VMS_Meta_Ads_Meta_Client::discover_existing_campaigns($event_plan_id, $build_id);
			if (is_wp_error($result)) {
				return $result;
			}
			return rest_ensure_response($result);
		}

		public static function go_live(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}
			$params = (array) $request->get_json_params();
			$event_plan_id = absint($params['event_plan_id'] ?? 0);
			$build_id = absint($params['build_id'] ?? 0);
			$confirmed = !empty($params['confirm_spend']) && !empty($params['confirm_reviewed']);
			if ($event_plan_id < 1) {
				return new WP_Error('invalid_event_plan', __('A valid Event Plan ID is required.', 'vms-meta-ads'), array('status' => 400));
			}
			if (!$confirmed) {
				return new WP_Error('confirmation_required', __('Go Live requires spend and review confirmation.', 'vms-meta-ads'), array('status' => 400));
			}
			$resolved_build = null;
			if ($build_id > 0) {
				$resolved_build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
				if (is_wp_error($resolved_build)) {
					return $resolved_build;
				}
			}
			$result = VMS_Meta_Ads_Meta_Client::go_live_event_plan($event_plan_id, is_array($resolved_build) ? $resolved_build : null);
			if (is_wp_error($result)) {
				return $result;
			}
			return rest_ensure_response($result);
		}

		public static function pause_all(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}
			$params = (array) $request->get_json_params();
			$event_plan_id = absint($params['event_plan_id'] ?? 0);
			$build_id = absint($params['build_id'] ?? 0);
			if ($event_plan_id < 1) {
				return new WP_Error('invalid_event_plan', __('A valid Event Plan ID is required.', 'vms-meta-ads'), array('status' => 400));
			}
			$resolved_build = null;
			if ($build_id > 0) {
				$resolved_build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
				if (is_wp_error($resolved_build)) {
					return $resolved_build;
				}
			}
			$result = VMS_Meta_Ads_Meta_Client::pause_all_event_plan($event_plan_id, is_array($resolved_build) ? $resolved_build : null);
			if (is_wp_error($result)) {
				return $result;
			}
			return rest_ensure_response($result);
		}
	}
}
