<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Templates_Controller')) {
	class VMS_Meta_Ads_Templates_Controller {
		public static function register_routes(): void
		{
			register_rest_route('vms-ma/v1', '/templates', array(
				array(
					'methods' => 'GET',
					'callback' => array(__CLASS__, 'get_collection'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
				array(
					'methods' => 'POST',
					'callback' => array(__CLASS__, 'create_template'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));

			register_rest_route('vms-ma/v1', '/templates/(?P<id>\d+)', array(
				array(
					'methods' => 'GET',
					'callback' => array(__CLASS__, 'get_item'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
				array(
					'methods' => 'DELETE',
					'callback' => array(__CLASS__, 'delete_item'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));
		}

		public static function get_collection(WP_REST_Request $request)
		{
			$limit = absint($request->get_param('limit') ?: 50);
			$items = VMS_Meta_Ads_Templates_Service::list_templates($limit);
			return rest_ensure_response(array('items' => $items));
		}

		public static function get_item(WP_REST_Request $request)
		{
			$id = absint($request->get_param('id'));
			$result = VMS_Meta_Ads_Templates_Service::get_template($id);
			if (is_wp_error($result)) {
				return $result;
			}
			return rest_ensure_response(array('item' => $result));
		}

		public static function create_template(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}
			$params = (array) $request->get_json_params();
			$result = VMS_Meta_Ads_Templates_Service::create_template($params);
			if (is_wp_error($result)) {
				return $result;
			}
			return rest_ensure_response(array('item' => $result));
		}

		public static function delete_item(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}
			$id = absint($request->get_param('id'));
			$result = VMS_Meta_Ads_Templates_Service::delete_template($id);
			if (is_wp_error($result)) {
				return $result;
			}
			return rest_ensure_response($result);
		}

		private static function verify_admin_nonce(WP_REST_Request $request)
		{
			$nonce = (string) $request->get_header('X-WP-Nonce');
			if ($nonce === '' || !wp_verify_nonce($nonce, 'wp_rest')) {
				return new WP_Error('invalid_nonce', __('Invalid request nonce.', 'vms-meta-ads'), array('status' => 403));
			}
			return true;
		}
	}
}
