<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Post_Assets_Controller')) {
	class VMS_Meta_Ads_Post_Assets_Controller {
		public static function register_routes(): void
		{
			register_rest_route('vms-ma/v1', '/post-assets', array(
				array(
					'methods' => 'POST',
					'callback' => array(__CLASS__, 'create_asset'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
				array(
					'methods' => 'GET',
					'callback' => array(__CLASS__, 'list_assets'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));
		}

		public static function create_asset(WP_REST_Request $request)
		{
			$nonce = (string) $request->get_header('X-WP-Nonce');
			if ($nonce === '' || !wp_verify_nonce($nonce, 'wp_rest')) {
				return new WP_Error('invalid_nonce', __('Invalid request nonce.', 'vms-meta-ads'), array('status' => 403));
			}
			$params = $request->get_json_params();
			$result = vms_ma_post_asset_create($params);
			if (is_wp_error($result)) {
				return $result;
			}
			return rest_ensure_response(array('id' => $result));
		}

		public static function list_assets(WP_REST_Request $request)
		{
			$filters = array(
				'platform' => $request->get_param('platform'),
				'venue_id' => $request->get_param('venue_id'),
				'event_plan_id' => $request->get_param('event_plan_id'),
				'limit' => $request->get_param('limit') ?: 20,
			);
			return rest_ensure_response(array('items' => vms_ma_post_asset_list($filters)));
		}
	}
}
