<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Event_Plans_Controller')) {
	class VMS_Meta_Ads_Event_Plans_Controller {
		public static function register_routes(): void
		{
			register_rest_route('vms-ma/v1', '/event-plans', array(
				array(
					'methods' => 'GET',
					'callback' => array(__CLASS__, 'get_collection'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));
			register_rest_route('vms-ma/v1', '/event-plans/(?P<id>\d+)', array(
				array(
					'methods' => 'GET',
					'callback' => array(__CLASS__, 'get_item'),
					'permission_callback' => 'vms_ma_current_user_can_manage',
				),
			));
		}

		public static function get_collection(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}

			$status_param = (string) $request->get_param('status');
			$statuses = array();
			if ($status_param !== '') {
				$statuses = array_filter(array_map('trim', explode(',', $status_param)));
			}

			$items = VMS_Meta_Ads_Event_Plans_Service::list_event_plans(array(
				'q' => (string) $request->get_param('q'),
				'after' => (string) $request->get_param('after'),
				'days' => absint($request->get_param('days') ?: 90),
				'limit' => absint($request->get_param('limit') ?: 30),
				'venue_id' => absint($request->get_param('venue_id')),
				'group_meta_activity_last' => !empty($request->get_param('group_meta_activity_last')),
				'statuses' => $statuses,
			));
			return rest_ensure_response(array('items' => $items));
		}

		public static function get_item(WP_REST_Request $request)
		{
			$nonce_check = self::verify_admin_nonce($request);
			if (is_wp_error($nonce_check)) {
				return $nonce_check;
			}

			$id = absint($request->get_param('id'));
			$item = VMS_Meta_Ads_Event_Plans_Service::get_event_plan($id);
			if (!$item) {
				return new WP_Error('not_found', __('Event Plan not found.', 'vms-meta-ads'), array('status' => 404));
			}
			return rest_ensure_response(array('item' => $item));
		}

		private static function verify_admin_nonce(WP_REST_Request $request)
		{
			$nonce = (string) $request->get_header('X-WP-Nonce');
			if ($nonce === '' || !wp_verify_nonce($nonce, 'wp_rest')) {
				return new WP_Error('invalid_nonce', __('Invalid request nonce.', 'vms-meta-ads'), array('status' => 403));
			}
			return true;
		}
	}
}
