<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_API_Attempts_Meta_Adapter')) {
	class VMS_API_Attempts_Meta_Adapter {
		public static function init(): void
		{
			add_filter('vms_api_attempt_extract_error', array(__CLASS__, 'extract_error'), 10, 6);
			add_filter('vms_api_attempt_extract_trace_id', array(__CLASS__, 'extract_trace'), 10, 4);
			add_filter('vms_api_attempt_module_version', array(__CLASS__, 'module_version'), 10, 2);
		}

		public static function extract_error(array $normalized, string $provider_slug, $http_status, $response_body, $response_headers, $wp_error): array
		{
			if ($provider_slug !== 'meta_ads') {
				return $normalized;
			}
			if (is_wp_error($wp_error)) {
				$normalized['error_message'] = (string) $wp_error->get_error_message();
				$normalized['error_code'] = (string) $wp_error->get_error_code();
				return $normalized;
			}
			if (!is_array($response_body) || !isset($response_body['error']) || !is_array($response_body['error'])) {
				return $normalized;
			}

			$err = (array) $response_body['error'];
			$normalized['error_message'] = sanitize_text_field((string) ($err['message'] ?? ''));
			$normalized['error_code'] = isset($err['code']) ? (string) $err['code'] : '';
			$normalized['error_subcode'] = isset($err['error_subcode']) ? (string) $err['error_subcode'] : '';
			$normalized['error_user_title'] = sanitize_text_field((string) ($err['error_user_title'] ?? ''));
			$normalized['error_user_msg'] = sanitize_text_field((string) ($err['error_user_msg'] ?? ''));
			$normalized['trace_id'] = sanitize_text_field((string) ($err['fbtrace_id'] ?? ''));
			$normalized['provider_error'] = $err;
			return $normalized;
		}

		public static function extract_trace(string $trace_id, string $provider_slug, $response_body, $response_headers): string
		{
			if ($provider_slug !== 'meta_ads') {
				return $trace_id;
			}
			if ($trace_id !== '') {
				return sanitize_text_field($trace_id);
			}
			if (is_array($response_body) && isset($response_body['error']) && is_array($response_body['error'])) {
				$from_body = sanitize_text_field((string) ($response_body['error']['fbtrace_id'] ?? ''));
				if ($from_body !== '') {
					return $from_body;
				}
			}

			foreach ((array) $response_headers as $header_key => $header_val) {
				$key = strtolower((string) $header_key);
				if ($key !== 'x-fb-trace-id') {
					continue;
				}
				if (is_array($header_val)) {
					$header_val = (string) reset($header_val);
				}
				$clean = sanitize_text_field((string) $header_val);
				if ($clean !== '') {
					return $clean;
				}
			}
			return '';
		}

		public static function module_version(string $version, string $module_slug): string
		{
			if ($module_slug === 'vms-facebook-ads' && defined('VMS_MA_VERSION')) {
				return (string) VMS_MA_VERSION;
			}
			return $version;
		}
	}
}

VMS_API_Attempts_Meta_Adapter::init();
