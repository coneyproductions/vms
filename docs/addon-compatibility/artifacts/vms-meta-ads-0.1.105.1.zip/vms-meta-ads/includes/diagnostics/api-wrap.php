<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_api_attempt_wrap')) {
	function vms_api_attempt_wrap(
		string $provider_slug,
		string $module_slug,
		string $operation,
		string $context,
		string $method,
		string $endpoint,
		$request_payload,
		callable $do_request
	) {
		$request_id = wp_generate_uuid4();
		$started = microtime(true);
		$response = $do_request();
		$duration_ms = (int) round((microtime(true) - $started) * 1000);

		$wp_error = null;
		$wp_error_code = null;
		$wp_error_message = null;
		$http_status = null;
		$response_headers = array();
		$response_body_raw = null;
		$response_body = null;
		if (is_wp_error($response)) {
			$wp_error = $response;
			$wp_error_code = (string) $response->get_error_code();
			$wp_error_message = $response->get_error_message();
		} else {
			$http_status = (int) wp_remote_retrieve_response_code($response);
			$response_headers_raw = wp_remote_retrieve_headers($response);
			$response_headers = is_array($response_headers_raw) ? $response_headers_raw : (array) $response_headers_raw;
			$response_body_raw = (string) wp_remote_retrieve_body($response);
			$decoded = json_decode($response_body_raw, true);
			$response_body = (json_last_error() === JSON_ERROR_NONE) ? $decoded : $response_body_raw;
		}

		$normalized = array(
			'error_message' => '',
			'error_code' => '',
			'error_subcode' => '',
			'error_user_title' => '',
			'error_user_msg' => '',
			'trace_id' => '',
			'provider_error' => null,
		);
		$normalized = apply_filters(
			'vms_api_attempt_extract_error',
			$normalized,
			sanitize_key($provider_slug),
			$http_status,
			$response_body,
			$response_headers,
			$wp_error
		);
		$trace_id = apply_filters(
			'vms_api_attempt_extract_trace_id',
			(string) ($normalized['trace_id'] ?? ''),
			sanitize_key($provider_slug),
			$response_body,
			$response_headers
		);

		vms_api_attempt_log(array(
			'user_id' => get_current_user_id(),
			'request_id' => $request_id,
			'provider_slug' => sanitize_key($provider_slug),
			'module_slug' => sanitize_text_field($module_slug),
			'operation' => sanitize_key($operation),
			'context' => sanitize_key($context),
			'method' => strtoupper(sanitize_text_field($method)),
			'endpoint' => sanitize_text_field($endpoint),
			'http_status' => $http_status,
			'duration_ms' => $duration_ms,
			'trace_id' => sanitize_text_field((string) $trace_id),
			'wp_error_code' => $wp_error_code,
			'wp_error_message' => $wp_error_message,
			'error_message' => sanitize_text_field((string) ($normalized['error_message'] ?? '')),
			'error_code' => sanitize_text_field((string) ($normalized['error_code'] ?? '')),
			'error_subcode' => sanitize_text_field((string) ($normalized['error_subcode'] ?? '')),
			'error_user_title' => sanitize_text_field((string) ($normalized['error_user_title'] ?? '')),
			'error_user_msg' => sanitize_text_field((string) ($normalized['error_user_msg'] ?? '')),
			'provider_error_json' => $normalized['provider_error'] ?? null,
			'request_payload_json' => $request_payload,
			'response_body_json' => $response_body,
		));

		return $response;
	}
}
