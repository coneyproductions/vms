<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_API_Attempts')) {
	class VMS_API_Attempts {
		private static $table_ready = false;
		private const RETENTION_DAYS = 14;
		private const RETENTION_MAX_ROWS = 5000;
		private const VALUE_MAX_LEN = 500;
		private const PRUNE_OPTION_KEY = 'vms_api_attempts_last_prune';
		private const SENSITIVE_KEY_PARTS = array(
			'access_token',
			'token',
			'app_secret',
			'appsecret',
			'client_secret',
			'authorization',
			'cookie',
			'nonce',
			'password',
		);
 
		public static function table_name(): string
		{
			global $wpdb;
			return $wpdb->prefix . 'vms_api_attempts';
		}

		public static function init(): void
		{
			$db_version = (string) get_option('vms_api_attempts_db_version', '0');
			if ($db_version !== '1') {
				self::create_table();
			}
			if (!has_action('vms_api_attempts_prune_daily', array(__CLASS__, 'prune'))) {
				add_action('vms_api_attempts_prune_daily', array(__CLASS__, 'prune'));
			}
			if (!wp_next_scheduled('vms_api_attempts_prune_daily')) {
				wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'vms_api_attempts_prune_daily');
			}
		}

		public static function create_table(): void
		{
			global $wpdb;
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$charset = $wpdb->get_charset_collate();
			$table = self::table_name();
			$sql = "CREATE TABLE {$table} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				created_at DATETIME NOT NULL,
				user_id BIGINT UNSIGNED NULL,
				request_id VARCHAR(64) NOT NULL,
				provider_slug VARCHAR(64) NOT NULL,
				module_slug VARCHAR(64) NOT NULL,
				operation VARCHAR(64) NULL,
				context VARCHAR(191) NULL,
				method VARCHAR(8) NOT NULL,
				endpoint VARCHAR(191) NOT NULL,
				http_status SMALLINT NULL,
				duration_ms INT NULL,
				trace_id VARCHAR(64) NULL,
				wp_error_code VARCHAR(191) NULL,
				wp_error_message TEXT NULL,
				error_message TEXT NULL,
				error_code VARCHAR(64) NULL,
				error_subcode VARCHAR(64) NULL,
				error_user_title TEXT NULL,
				error_user_msg TEXT NULL,
				provider_error_json LONGTEXT NULL,
				request_payload_json LONGTEXT NULL,
				response_body_json LONGTEXT NULL,
				PRIMARY KEY  (id),
				KEY created_at (created_at),
				KEY request_id (request_id),
				KEY provider_slug (provider_slug),
				KEY operation (operation),
				KEY context (context),
				KEY http_status (http_status)
			) {$charset}";
			dbDelta($sql);
			$exists = (string) $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
			if ($exists === $table) {
				update_option('vms_api_attempts_db_version', '1', false);
				self::$table_ready = true;
			}
		}

		public static function log_attempt(array $data): int
		{
			global $wpdb;
			self::ensure_table_ready();
			$table = self::table_name();
			$request_id = sanitize_text_field((string) ($data['request_id'] ?? ''));
			if ($request_id === '') {
				$request_id = wp_generate_uuid4();
			}
			$record = array(
				'created_at' => current_time('mysql', true),
				'user_id' => isset($data['user_id']) ? absint($data['user_id']) : null,
				'request_id' => substr($request_id, 0, 64),
				'provider_slug' => substr(sanitize_key((string) ($data['provider_slug'] ?? '')), 0, 64),
				'module_slug' => substr(sanitize_text_field((string) ($data['module_slug'] ?? '')), 0, 64),
				'operation' => self::nullable_text($data['operation'] ?? null, 64),
				'context' => self::nullable_text($data['context'] ?? null, 191),
				'method' => substr(strtoupper(sanitize_text_field((string) ($data['method'] ?? 'GET'))), 0, 8),
				'endpoint' => substr(sanitize_text_field((string) ($data['endpoint'] ?? '')), 0, 191),
				'http_status' => self::nullable_int($data['http_status'] ?? null),
				'duration_ms' => self::nullable_int($data['duration_ms'] ?? null),
				'trace_id' => self::nullable_text($data['trace_id'] ?? null, 64),
				'wp_error_code' => self::nullable_text($data['wp_error_code'] ?? null, 191),
				'wp_error_message' => self::nullable_long_text($data['wp_error_message'] ?? null),
				'error_message' => self::nullable_long_text($data['error_message'] ?? null),
				'error_code' => self::nullable_text($data['error_code'] ?? null, 64),
				'error_subcode' => self::nullable_text($data['error_subcode'] ?? null, 64),
				'error_user_title' => self::nullable_long_text($data['error_user_title'] ?? null),
				'error_user_msg' => self::nullable_long_text($data['error_user_msg'] ?? null),
				'provider_error_json' => self::sanitize_for_storage($data['provider_error_json'] ?? null),
				'request_payload_json' => self::sanitize_for_storage($data['request_payload_json'] ?? null),
				'response_body_json' => self::sanitize_for_storage($data['response_body_json'] ?? null),
			);
			$inserted = $wpdb->insert($table, $record);
			if ($inserted === false) {
				error_log('[VMS API Attempts] insert failed: ' . (string) $wpdb->last_error);
				return 0;
			}
			$id = (int) $wpdb->insert_id;
			self::prune_if_due();
			return $id;
		}

		public static function get_last(string $provider_slug, ?string $context = null): ?array
		{
			$rows = self::get_recent($provider_slug, 1, $context);
			return $rows ? (array) $rows[0] : null;
		}

		public static function get_recent(string $provider_slug, int $limit = 10, ?string $context = null): array
		{
			global $wpdb;
			self::ensure_table_ready();
			$table = self::table_name();
			$limit = max(1, min(100, absint($limit)));
			$sql = "SELECT * FROM {$table} WHERE provider_slug = %s";
			$params = array(sanitize_key($provider_slug));
			if ($context !== null && $context !== '') {
				$sql .= ' AND context = %s';
				$params[] = sanitize_text_field($context);
			}
			$sql .= ' ORDER BY id DESC LIMIT %d';
			$params[] = $limit;
			$query = $wpdb->prepare($sql, $params);
			return (array) $wpdb->get_results($query, ARRAY_A);
		}

			public static function get_last_failure(string $provider_slug, ?string $context = null): ?array
			{
			global $wpdb;
			self::ensure_table_ready();
			$table = self::table_name();
			$sql = "SELECT * FROM {$table} WHERE provider_slug = %s";
			$params = array(sanitize_key($provider_slug));
			if ($context !== null && $context !== '') {
				$sql .= ' AND context = %s';
				$params[] = sanitize_text_field($context);
			}
			$sql .= " AND (
				wp_error_code IS NOT NULL
				OR http_status IS NULL
				OR http_status = 0
				OR http_status < 200
				OR http_status > 299
			) ORDER BY id DESC LIMIT 1";
			$query = $wpdb->prepare($sql, $params);
				$row = $wpdb->get_row($query, ARRAY_A);
				return is_array($row) ? $row : null;
			}

			public static function get_by_id(int $attempt_id): ?array
			{
				if ($attempt_id < 1) {
					return null;
				}
				global $wpdb;
				self::ensure_table_ready();
				$table = self::table_name();
				$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $attempt_id), ARRAY_A);
				return is_array($row) ? $row : null;
			}

			public static function get_latest_for_mode(string $provider_slug, ?string $context, string $mode): ?array
			{
				$mode = sanitize_key($mode);
				if ($mode === '' || $mode === 'latest_attempt') {
					return self::get_last($provider_slug, $context);
				}
				$rows = self::get_recent($provider_slug, 50, $context);
				foreach ($rows as $row) {
					if (!is_array($row)) {
						continue;
					}
					if (($mode === 'latest_failed_meta_call' || $mode === 'last_failure') && self::is_failure_row($row) && !self::is_dry_run_attempt($row)) {
						return $row;
					}
					if ($mode === 'latest_dry_run' && self::is_dry_run_attempt($row)) {
						return $row;
					}
				}
				return null;
			}

			public static function summarize_attempt(array $attempt_row): array
			{
				$attempt_created_raw = (string) ($attempt_row['created_at'] ?? '');
				$request_payload = self::decoded_json_from_row($attempt_row['request_payload_json'] ?? null);
				$response_body = self::decoded_json_from_row($attempt_row['response_body_json'] ?? null);
				$provider_error = self::decoded_json_from_row($attempt_row['provider_error_json'] ?? null);
				$endpoint = sanitize_text_field((string) ($attempt_row['endpoint'] ?? ''));
				$build_id = self::extract_numeric_context_value('build_id', array($request_payload, $response_body, $provider_error));
				if ($build_id < 1 && preg_match('~/build/(\d+)~', $endpoint, $matches)) {
					$build_id = absint($matches[1] ?? 0);
				}
				$event_plan_id = self::extract_numeric_context_value('event_plan_id', array($request_payload, $response_body, $provider_error));
				return array(
					'id' => (int) ($attempt_row['id'] ?? 0),
					'build_id' => $build_id,
					'event_plan_id' => $event_plan_id,
					'operation' => sanitize_text_field((string) ($attempt_row['operation'] ?? '')),
					'created_at_utc' => $attempt_created_raw,
					'created_at_local' => self::format_created_at_local($attempt_created_raw),
					'transport' => self::attempt_transport_label($attempt_row),
					'is_dry_run' => self::is_dry_run_attempt($attempt_row),
					'method' => sanitize_text_field((string) ($attempt_row['method'] ?? '')),
					'endpoint' => $endpoint,
				);
			}

			public static function build_bundle_text(array $attempt_row): string
			{
				$site_url = site_url();
				$timestamp = wp_date('Y-m-d H:i:s T', null, wp_timezone());
				$attempt_summary = self::summarize_attempt($attempt_row);
				$attempt_created_local = (string) ($attempt_summary['created_at_local'] ?? '');
				$module_slug = sanitize_text_field((string) ($attempt_row['module_slug'] ?? ''));
				$module_version = self::module_version($module_slug);
				$operation = (string) ($attempt_summary['operation'] ?? '');
				$context = sanitize_text_field((string) ($attempt_row['context'] ?? ''));
				$request_id = sanitize_text_field((string) ($attempt_row['request_id'] ?? ''));
				$method = sanitize_text_field((string) ($attempt_summary['method'] ?? ''));
				$endpoint = sanitize_text_field((string) ($attempt_summary['endpoint'] ?? ''));
				$http_status = isset($attempt_row['http_status']) ? (string) $attempt_row['http_status'] : '';
				$duration_ms = isset($attempt_row['duration_ms']) ? (string) $attempt_row['duration_ms'] : '';
				$trace_id = sanitize_text_field((string) ($attempt_row['trace_id'] ?? ''));

			$lines = array();
			$lines[] = 'VMS API Diagnostic Bundle';
			$lines[] = 'Site URL: ' . $site_url;
			$lines[] = 'Timestamp: ' . $timestamp;
				$lines[] = 'Module: ' . $module_slug . ($module_version !== '' ? ' @ ' . $module_version : '');
				$lines[] = 'Provider: ' . sanitize_key((string) ($attempt_row['provider_slug'] ?? ''));
				$lines[] = 'Attempt ID: ' . (int) ($attempt_summary['id'] ?? 0);
				$lines[] = 'Build ID: ' . (!empty($attempt_summary['build_id']) ? (string) $attempt_summary['build_id'] : 'n/a');
				$lines[] = 'Event Plan ID: ' . (!empty($attempt_summary['event_plan_id']) ? (string) $attempt_summary['event_plan_id'] : 'n/a');
				$lines[] = 'Operation: ' . $operation;
				$lines[] = 'Attempt Mode: ' . sanitize_text_field((string) ($attempt_summary['transport'] ?? 'real network call'));
				$lines[] = 'Context: ' . $context;
				$lines[] = 'Attempt Created (UTC): ' . sanitize_text_field((string) ($attempt_summary['created_at_utc'] ?? ''));
				$lines[] = 'Attempt Created (site timezone): ' . $attempt_created_local;
				$lines[] = 'Request ID: ' . $request_id;
				$lines[] = 'Method + Endpoint: ' . $method . ' ' . $endpoint;
			$lines[] = 'HTTP Status + Duration: ' . ($http_status !== '' ? $http_status : 'n/a') . ' | ' . ($duration_ms !== '' ? $duration_ms : 'n/a') . 'ms';
			$lines[] = 'Trace ID: ' . ($trace_id !== '' ? $trace_id : 'n/a');
			$lines[] = '';
			$lines[] = 'Environment';
			$lines[] = 'WP Version: ' . get_bloginfo('version');
			$lines[] = 'PHP Version: ' . PHP_VERSION;
			$theme = wp_get_theme();
			$lines[] = 'Active Theme: ' . ($theme->exists() ? ($theme->get('Name') . ' ' . $theme->get('Version')) : 'unknown');
			$build_stamp = self::vms_build_stamp();
			if ($build_stamp !== '') {
				$lines[] = 'VMS Build Stamp: ' . $build_stamp;
			}
			$lines[] = 'Active Plugins:';
			foreach (self::active_plugins_summary() as $plugin_line) {
				$lines[] = '- ' . $plugin_line;
			}
			$lines[] = '';
			$lines[] = 'Error Envelope';
			$lines[] = 'wp_error_code: ' . sanitize_text_field((string) ($attempt_row['wp_error_code'] ?? ''));
			$lines[] = 'wp_error_message: ' . sanitize_text_field((string) ($attempt_row['wp_error_message'] ?? ''));
			$lines[] = 'error_message: ' . sanitize_text_field((string) ($attempt_row['error_message'] ?? ''));
			$lines[] = 'error_code: ' . sanitize_text_field((string) ($attempt_row['error_code'] ?? ''));
			$lines[] = 'error_subcode: ' . sanitize_text_field((string) ($attempt_row['error_subcode'] ?? ''));
			$lines[] = 'error_user_title: ' . sanitize_text_field((string) ($attempt_row['error_user_title'] ?? ''));
			$lines[] = 'error_user_msg: ' . sanitize_text_field((string) ($attempt_row['error_user_msg'] ?? ''));
			$lines[] = 'trace_id: ' . $trace_id;
			$lines[] = '';
			$lines[] = 'Sanitized Request Payload';
			$lines[] = self::pretty_json_from_row($attempt_row['request_payload_json'] ?? null);
			$lines[] = '';
			$lines[] = 'Sanitized Response Body';
			$lines[] = self::pretty_json_from_row($attempt_row['response_body_json'] ?? null);
			$provider_json = (string) ($attempt_row['provider_error_json'] ?? '');
			if ($provider_json !== '' && trim($provider_json) !== trim((string) ($attempt_row['response_body_json'] ?? ''))) {
				$lines[] = '';
				$lines[] = 'Sanitized Provider Error JSON';
				$lines[] = self::pretty_json_from_row($provider_json);
			}

			return implode("\n", $lines);
		}

		public static function format_created_at_local(string $created_at_utc): string
		{
			$raw = trim($created_at_utc);
			if ($raw === '') {
				return '';
			}
			$ts = strtotime($raw . ' UTC');
			if ($ts === false) {
				return $raw;
			}
			return wp_date('Y-m-d H:i:s T', $ts, wp_timezone());
		}

		public static function prune(): void
		{
			global $wpdb;
			self::ensure_table_ready();
			$table = self::table_name();
			$cutoff = gmdate('Y-m-d H:i:s', time() - (DAY_IN_SECONDS * self::RETENTION_DAYS));
			$wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE created_at < %s", $cutoff));
			$count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
			if ($count > self::RETENTION_MAX_ROWS) {
				$overflow = $count - self::RETENTION_MAX_ROWS;
				$wpdb->query($wpdb->prepare("DELETE FROM {$table} ORDER BY id ASC LIMIT %d", $overflow));
			}
			update_option(self::PRUNE_OPTION_KEY, time(), false);
		}

		public static function sanitize_recursive($value, ?string $key = null)
		{
			if ($key !== null && self::is_sensitive_key($key)) {
				return '[REDACTED]';
			}

			if (is_string($value)) {
				return self::sanitize_string_value($value);
			}
			if (is_array($value)) {
				$out = array();
				foreach ($value as $child_key => $child_value) {
					$child_name = is_string($child_key) ? $child_key : null;
					$out[$child_key] = self::sanitize_recursive($child_value, $child_name);
				}
				return $out;
			}
			if (is_object($value)) {
				return self::sanitize_recursive((array) $value, $key);
			}
			return $value;
		}

		public static function sanitize_for_storage($value): string
		{
			if ($value === null) {
				return '{}';
			}
			$decoded = $value;
			if (is_string($value)) {
				$trimmed = trim($value);
				if ($trimmed === '') {
					return '{}';
				}
				$json = json_decode($value, true);
				if (json_last_error() === JSON_ERROR_NONE) {
					$decoded = $json;
				}
			}
			$sanitized = self::sanitize_recursive($decoded);
			$encoded = wp_json_encode($sanitized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
			return is_string($encoded) ? $encoded : '{}';
		}

		private static function prune_if_due(): void
		{
			$last = (int) get_option(self::PRUNE_OPTION_KEY, 0);
			if ($last <= 0 || (time() - $last) >= DAY_IN_SECONDS) {
				self::prune();
			}
		}

		private static function ensure_table_ready(): void
		{
			if (self::$table_ready) {
				return;
			}
			global $wpdb;
			$table = self::table_name();
			$exists = (string) $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
			if ($exists !== $table) {
				self::create_table();
				$exists = (string) $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
			}
			self::$table_ready = ($exists === $table);
		}

			private static function pretty_json_from_row($value): string
			{
			if (!is_string($value) || trim($value) === '') {
				return '{}';
			}
			$decoded = json_decode($value, true);
			if (json_last_error() !== JSON_ERROR_NONE) {
				$decoded = self::sanitize_recursive($value);
			}
				$encoded = wp_json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
				return is_string($encoded) ? $encoded : '{}';
			}

			private static function decoded_json_from_row($value): array
			{
				if (is_array($value)) {
					return $value;
				}
				if (!is_string($value) || trim($value) === '') {
					return array();
				}
				$decoded = json_decode($value, true);
				return (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? $decoded : array();
			}

			private static function extract_numeric_context_value(string $needle, array $sources): int
			{
				foreach ($sources as $source) {
					$found = self::extract_numeric_context_value_recursive($source, $needle);
					if ($found > 0) {
						return $found;
					}
				}
				return 0;
			}

			private static function extract_numeric_context_value_recursive($value, string $needle): int
			{
				if (!is_array($value)) {
					return 0;
				}
				foreach ($value as $key => $child) {
					if ((string) $key === $needle) {
						$maybe = absint($child);
						if ($maybe > 0) {
							return $maybe;
						}
					}
					if (is_array($child)) {
						$found = self::extract_numeric_context_value_recursive($child, $needle);
						if ($found > 0) {
							return $found;
						}
					}
				}
				return 0;
			}

			private static function attempt_transport_label(array $attempt_row): string
			{
				return self::is_dry_run_attempt($attempt_row) ? 'dry run / no-network' : 'real network call';
			}

			private static function is_dry_run_attempt(array $attempt_row): bool
			{
				$method = strtoupper(sanitize_text_field((string) ($attempt_row['method'] ?? '')));
				$operation = sanitize_key((string) ($attempt_row['operation'] ?? ''));
				$endpoint = strtolower(sanitize_text_field((string) ($attempt_row['endpoint'] ?? '')));
				return $method === 'LOCAL'
					|| $operation === 'dry_run_bundle'
					|| strpos($endpoint, 'meta-dry-run/') !== false;
			}

			private static function is_failure_row(array $attempt_row): bool
			{
				if (!empty($attempt_row['wp_error_code'])) {
					return true;
				}
				$status = isset($attempt_row['http_status']) ? (int) $attempt_row['http_status'] : 0;
				return $status < 200 || $status > 299;
			}

			private static function is_sensitive_key(string $key): bool
			{
			$needle = strtolower($key);
			foreach (self::SENSITIVE_KEY_PARTS as $part) {
				if (strpos($needle, $part) !== false) {
					return true;
				}
			}
			return false;
		}
 
		private static function sanitize_string_value(string $value): string
		{
			$out = $value;
			$trimmed = trim($out);
			if (preg_match('/^[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}$/i', $trimmed)) {
				$out = '[REDACTED_EMAIL]';
			}
			if (preg_match('/^\+?[0-9][0-9\s\-\(\)]{7,}[0-9]$/', $trimmed)) {
				$out = '[REDACTED_PHONE]';
			}
			if (function_exists('mb_strlen')) {
				if (mb_strlen($out, 'UTF-8') > self::VALUE_MAX_LEN) {
					$out = mb_substr($out, 0, self::VALUE_MAX_LEN, 'UTF-8') . '…';
				}
			} elseif (strlen($out) > self::VALUE_MAX_LEN) {
				$out = substr($out, 0, self::VALUE_MAX_LEN) . '…';
			}
			return $out;
		}

		private static function nullable_text($value, int $max_len): ?string
		{
			if ($value === null) {
				return null;
			}
			$text = sanitize_text_field((string) $value);
			if ($text === '') {
				return null;
			}
			return substr($text, 0, $max_len);
		}

		private static function nullable_long_text($value): ?string
		{
			if ($value === null) {
				return null;
			}
			$text = sanitize_text_field((string) $value);
			return $text !== '' ? $text : null;
		}

		private static function nullable_int($value): ?int
		{
			if ($value === null || $value === '') {
				return null;
			}
			return (int) $value;
		}

		private static function module_version(string $module_slug): string
		{
			$module_slug = sanitize_text_field($module_slug);
			$version = apply_filters('vms_api_attempt_module_version', '', $module_slug);
			$version = is_string($version) ? trim($version) : '';
			if ($version !== '') {
				return $version;
			}
			if ($module_slug === 'vms-facebook-ads' && defined('VMS_MA_VERSION')) {
				return (string) VMS_MA_VERSION;
			}
			return '';
		}

		private static function active_plugins_summary(): array
		{
			if (!function_exists('get_plugins')) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$all_plugins = function_exists('get_plugins') ? get_plugins() : array();
			$active = (array) get_option('active_plugins', array());
			if (is_multisite()) {
				$network_active = array_keys((array) get_site_option('active_sitewide_plugins', array()));
				$active = array_unique(array_merge($active, $network_active));
			}
			$rows = array();
			foreach ($active as $plugin_file) {
				$meta = $all_plugins[$plugin_file] ?? null;
				if (!is_array($meta)) {
					continue;
				}
				$name = sanitize_text_field((string) ($meta['Name'] ?? $plugin_file));
				$version = sanitize_text_field((string) ($meta['Version'] ?? ''));
				$rows[] = $name . ($version !== '' ? ' ' . $version : '');
			}
			sort($rows, SORT_NATURAL | SORT_FLAG_CASE);
			return $rows;
		}

		private static function vms_build_stamp(): string
		{
			$path = WP_PLUGIN_DIR . '/vms/vms-build.txt';
			if (!file_exists($path) || !is_readable($path)) {
				return '';
			}
			$raw = trim((string) file_get_contents($path));
			return $raw !== '' ? sanitize_text_field($raw) : '';
		}
	}
}

if (!function_exists('vms_api_attempt_log')) {
	function vms_api_attempt_log($data): int
	{
		return VMS_API_Attempts::log_attempt(is_array($data) ? $data : array());
	}
}

if (!function_exists('vms_api_attempt_get_last')) {
	function vms_api_attempt_get_last($provider_slug, $context = null)
	{
		$provider = is_string($provider_slug) ? $provider_slug : '';
		$ctx = is_string($context) ? $context : null;
		return VMS_API_Attempts::get_last($provider, $ctx);
	}
}

if (!function_exists('vms_api_attempt_get_recent')) {
	function vms_api_attempt_get_recent($provider_slug, $limit = 10, $context = null): array
	{
		$provider = is_string($provider_slug) ? $provider_slug : '';
		$ctx = is_string($context) ? $context : null;
		return VMS_API_Attempts::get_recent($provider, (int) $limit, $ctx);
	}
}

if (!function_exists('vms_api_attempt_get_last_failure')) {
	function vms_api_attempt_get_last_failure($provider_slug, $context = null)
	{
		$provider = is_string($provider_slug) ? $provider_slug : '';
		$ctx = is_string($context) ? $context : null;
		return VMS_API_Attempts::get_last_failure($provider, $ctx);
	}
}

if (!function_exists('vms_api_attempt_build_bundle_text')) {
	function vms_api_attempt_build_bundle_text($attempt_row): string
	{
		return VMS_API_Attempts::build_bundle_text(is_array($attempt_row) ? $attempt_row : array());
	}
}

if (!function_exists('vms_api_attempt_get_by_id')) {
	function vms_api_attempt_get_by_id($attempt_id)
	{
		return VMS_API_Attempts::get_by_id((int) $attempt_id);
	}
}

if (!function_exists('vms_api_attempt_get_latest_for_mode')) {
	function vms_api_attempt_get_latest_for_mode($provider_slug, $context = null, $mode = 'latest_attempt')
	{
		$provider = is_string($provider_slug) ? $provider_slug : '';
		$ctx = is_string($context) ? $context : null;
		$safe_mode = is_string($mode) ? $mode : 'latest_attempt';
		return VMS_API_Attempts::get_latest_for_mode($provider, $ctx, $safe_mode);
	}
}

if (!function_exists('vms_api_attempt_summarize')) {
	function vms_api_attempt_summarize($attempt_row): array
	{
		return VMS_API_Attempts::summarize_attempt(is_array($attempt_row) ? $attempt_row : array());
	}
}
