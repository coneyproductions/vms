<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Templates_Service')) {
	class VMS_Meta_Ads_Templates_Service {
		public static function list_templates(int $limit = 50): array
		{
			global $wpdb;
			$limit = max(1, min(200, $limit));
			$table = $wpdb->prefix . 'vms_meta_ads_templates';
			$rows = $wpdb->get_results($wpdb->prepare(
				"SELECT id, template_name, created_at, updated_at FROM $table ORDER BY updated_at DESC, id DESC LIMIT %d",
				$limit
			), ARRAY_A);
			if (!is_array($rows)) {
				return array();
			}
			return array_map(array(__CLASS__, 'normalize_template_row'), $rows);
		}

		public static function get_template(int $id)
		{
			global $wpdb;
			$table = $wpdb->prefix . 'vms_meta_ads_templates';
			$row = $wpdb->get_row($wpdb->prepare(
				"SELECT id, template_name, payload, created_at, updated_at FROM $table WHERE id = %d",
				$id
			), ARRAY_A);
			if (!$row) {
				return new WP_Error('not_found', __('Template not found.', 'vms-meta-ads'), array('status' => 404));
			}

			$raw_payload = json_decode((string) ($row['payload'] ?? ''), true);
			if (!is_array($raw_payload)) {
				$raw_payload = array();
			}

			$payload = self::strip_legacy_event_scoped_template_fields($raw_payload);
			if ($payload !== $raw_payload) {
				$wpdb->update(
					$table,
					array(
						'payload' => wp_json_encode($payload),
						'updated_at' => current_time('mysql'),
					),
					array('id' => $id),
					array('%s', '%s'),
					array('%d')
				);
			}

			$row['payload'] = $payload;
			return self::normalize_template_row($row);
		}

		public static function create_template(array $params)
		{
			global $wpdb;
			$name = isset($params['name']) ? sanitize_text_field((string) $params['name']) : '';
			if ($name === '') {
				return new WP_Error('invalid_name', __('Template name is required.', 'vms-meta-ads'), array('status' => 400));
			}
			$payload = isset($params['payload']) && is_array($params['payload']) ? $params['payload'] : array();
			$include = isset($params['include']) && is_array($params['include']) ? $params['include'] : array();

			$stored = self::extract_template_payload($payload, $include);
			if (empty($stored)) {
				return new WP_Error('empty_template', __('No template fields were selected.', 'vms-meta-ads'), array('status' => 400));
			}

			$now = current_time('mysql');
			$table = $wpdb->prefix . 'vms_meta_ads_templates';
			$inserted = $wpdb->insert(
				$table,
				array(
					'template_name' => $name,
					'payload' => wp_json_encode($stored),
					'created_by' => get_current_user_id(),
					'created_at' => $now,
					'updated_at' => $now,
				),
				array('%s', '%s', '%d', '%s', '%s')
			);

			if (!$inserted) {
				return new WP_Error('db_error', __('Failed to save template.', 'vms-meta-ads'), array('status' => 500));
			}

			return self::get_template((int) $wpdb->insert_id);
		}

		public static function delete_template(int $id)
		{
			global $wpdb;
			$table = $wpdb->prefix . 'vms_meta_ads_templates';
			$deleted = $wpdb->delete($table, array('id' => $id), array('%d'));
			if (!$deleted) {
				return new WP_Error('delete_failed', __('Template could not be deleted.', 'vms-meta-ads'), array('status' => 400));
			}
			return array('deleted' => 1);
		}

		private static function extract_template_payload(array $payload, array $include): array
		{
			$out = array();

			// Audience / targeting
			if (in_array('targeting', $include, true)) {
				$out['targeting_address'] = sanitize_text_field((string) ($payload['targeting_address'] ?? ''));
				$out['radius_miles'] = absint($payload['radius_miles'] ?? 0);
				$out['age_min'] = absint($payload['age_min'] ?? 0);
				$out['age_max'] = absint($payload['age_max'] ?? 0);
				$gender = sanitize_key((string) ($payload['gender'] ?? 'all'));
				$out['gender'] = in_array($gender, array('all', 'women', 'men'), true) ? $gender : 'all';
				$out['interests'] = sanitize_text_field((string) ($payload['interests'] ?? ''));
				if (class_exists('VMS_Meta_Ads_Audience_Targeting_Service')) {
					$out['audience_targeting'] = VMS_Meta_Ads_Audience_Targeting_Service::normalize_state(
						is_array($payload['audience_targeting'] ?? null) ? (array) $payload['audience_targeting'] : array(),
						array('gender' => (string) ($out['gender'] ?? 'all'))
					);
				}
				$out['locations'] = sanitize_textarea_field((string) ($payload['locations'] ?? ''));
				$out['outer_towns_locations'] = sanitize_textarea_field((string) ($payload['outer_towns_locations'] ?? ''));
				$outer_towns_mode = sanitize_key((string) ($payload['outer_towns_mode'] ?? 'listed_only'));
				$out['outer_towns_mode'] = in_array($outer_towns_mode, array('listed_only', 'expanded_radius'), true) ? $outer_towns_mode : 'listed_only';
				$out['outer_towns_default_radius'] = absint($payload['outer_towns_default_radius'] ?? 0);
			}

			// Placements
			if (in_array('placements', $include, true)) {
				$out['placements_mode'] = sanitize_key((string) ($payload['placements_mode'] ?? 'auto'));
				$placements = array();
				foreach ((array) ($payload['placements'] ?? array()) as $p) {
					$p = sanitize_key((string) $p);
					if ($p !== '') {
						$placements[] = $p;
					}
				}
				$out['placements'] = array_values(array_unique($placements));
			}

			// Schedule
			if (in_array('schedule', $include, true)) {
				$out['preset_mode'] = sanitize_key((string) ($payload['preset_mode'] ?? ($payload['preset'] ?? '')));
				$out['manual_start'] = sanitize_text_field((string) ($payload['manual_start'] ?? ''));
				$out['manual_end'] = sanitize_text_field((string) ($payload['manual_end'] ?? ''));
				$out['end_buffer_hours'] = absint($payload['end_buffer_hours'] ?? 0);
			}

			// Budget
			if (in_array('budget', $include, true)) {
				$out['total_budget_minor'] = absint($payload['total_budget_minor'] ?? 0);
				$tier_budgets = $payload['tier_budgets'] ?? null;
				if (is_array($tier_budgets)) {
					$clean = array();
					foreach ($tier_budgets as $k => $v) {
						$k = sanitize_key((string) $k);
						if ($k === '') {
							continue;
						}
						$clean[$k] = absint($v);
					}
					if (!empty($clean)) {
						$out['tier_budgets'] = $clean;
					}
				}
			}

			if (in_array('budget', $include, true) || in_array('strategy', $include, true)) {
				$recipe_adset_state = self::sanitize_recipe_adset_state($payload['recipe_adset_state'] ?? null, absint($payload['total_budget_minor'] ?? 0));
				if (!empty($recipe_adset_state)) {
					$out['recipe_adset_state'] = $recipe_adset_state;
				}
			}

			// Strategy / Meta intent controls.
			if (in_array('strategy', $include, true)) {
				$out['strategy_template'] = sanitize_key((string) ($payload['strategy_template'] ?? 'custom'));
				$out['campaign_recipe'] = sanitize_key((string) ($payload['campaign_recipe'] ?? ''));
				$out['include_right_column_support'] = !empty($payload['include_right_column_support']) ? 1 : 0;
				$out['include_outer_towns_adset'] = array_key_exists('include_outer_towns_adset', $payload) && empty($payload['include_outer_towns_adset']) ? 0 : 1;
				$out['video_format'] = sanitize_key((string) ($payload['video_format'] ?? 'unknown'));
				$out['require_vertical_video'] = !empty($payload['require_vertical_video']) ? 1 : 0;
				$out['creative_automation_policy'] = sanitize_key((string) ($payload['creative_automation_policy'] ?? 'off'));
				$out['multi_advertiser_ads'] = !empty($payload['multi_advertiser_ads']) ? 1 : 0;
			}

			// Reusable creative settings only.
			if (in_array('cta', $include, true)) {
				$out['cta_type'] = sanitize_key((string) ($payload['cta_type'] ?? ''));
				$out['force_buy_tickets_cta'] = !empty($payload['force_buy_tickets_cta']) ? 1 : 0;
			}

			return $out;
		}

		private static function strip_legacy_event_scoped_template_fields(array $payload): array
		{
			$blocked_keys = array(
				'event_name',
				'venue_name',
				'event_start',
				'destination_url',
				'post_asset_id',
				'fb_event_id',
				'primary_text',
				'headline',
				'description',
				'ad_variants',
				'image_square_id',
				'image_vertical_id',
				'image_wide_id',
			);

			foreach ($blocked_keys as $key) {
				if (array_key_exists($key, $payload)) {
					unset($payload[$key]);
				}
			}

			return $payload;
		}

		private static function allocate_recipe_budget_minor(int $total_budget_minor, array $weights_by_key): array
		{
			$total_budget_minor = max(0, $total_budget_minor);
			$weights = array();
			$total_weight = 0.0;
			foreach ($weights_by_key as $key => $weight) {
				$safe_key = sanitize_key((string) $key);
				if ($safe_key === '') {
					continue;
				}
				$safe_weight = max(0.0, (float) $weight);
				$weights[$safe_key] = $safe_weight;
				$total_weight += $safe_weight;
			}

			$allocations = array();
			foreach ($weights as $key => $weight) {
				$allocations[$key] = 0;
			}
			if ($total_budget_minor < 1 || empty($weights) || $total_weight <= 0) {
				return $allocations;
			}

			$allocated = 0;
			$keys = array_keys($weights);
			$last_index = count($keys) - 1;
			foreach ($keys as $index => $key) {
				if ($index === $last_index) {
					$allocations[$key] = max(0, $total_budget_minor - $allocated);
					continue;
				}
				$amount = (int) floor($total_budget_minor * ($weights[$key] / $total_weight));
				$allocations[$key] = $amount;
				$allocated += $amount;
			}

			return $allocations;
		}

		private static function sanitize_recipe_adset_state($raw, int $total_budget_minor = 0): array
		{
			if (!is_array($raw)) {
				return array();
			}

			$out = array();
			$explicit_total_minor = 0;
			$legacy_weights = array();
			foreach ($raw as $key => $row) {
				$safe_key = sanitize_key((string) $key);
				if ($safe_key === '' || !is_array($row)) {
					continue;
				}
				$percent = max(0, round((float) ($row['percent'] ?? ($row['allocation_percent'] ?? 0)), 2));
				$has_budget_minor = array_key_exists('budget_minor', $row) || array_key_exists('budget_amount_minor', $row);
				$budget_minor = $has_budget_minor
					? max(0, absint($row['budget_minor'] ?? $row['budget_amount_minor']))
					: null;
				$out[$safe_key] = array(
					'enabled' => array_key_exists('enabled', $row) ? (!empty($row['enabled']) ? 1 : 0) : 1,
					'percent' => $percent,
				);
				if ($budget_minor !== null) {
					$out[$safe_key]['budget_minor'] = $budget_minor;
					$explicit_total_minor += $budget_minor;
				} else {
					$legacy_weights[$safe_key] = $percent;
				}
			}

			if ($total_budget_minor > 0 && !empty($legacy_weights)) {
				$remaining_budget_minor = max(0, $total_budget_minor - $explicit_total_minor);
				$allocated_legacy = self::allocate_recipe_budget_minor($remaining_budget_minor, $legacy_weights);
				foreach ($allocated_legacy as $key => $budget_minor) {
					if (isset($out[$key])) {
						$out[$key]['budget_minor'] = $budget_minor;
					}
				}
			}

			if ($total_budget_minor > 0) {
				foreach ($out as &$row) {
					$budget_minor = max(0, absint($row['budget_minor'] ?? 0));
					$row['budget_minor'] = $budget_minor;
					$row['percent'] = round(($budget_minor / $total_budget_minor) * 100, 2);
				}
				unset($row);
			}

			return $out;
		}

		private static function normalize_template_row(array $row): array
		{
			$name = isset($row['template_name']) ? sanitize_text_field((string) $row['template_name']) : '';
			if ($name === '' && isset($row['name'])) {
				$name = sanitize_text_field((string) $row['name']);
			}
			$row['template_name'] = $name;
			$row['name'] = $name;
			return $row;
		}
	}
}
