<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Utils')) {
	class VMS_Meta_Ads_Utils {
		public const SETTINGS_OPTION = 'vms_ma_settings';
		public const GUIDANCE_LEVELS = array('beginner', 'standard', 'expert');

		public static function encrypt_token(string $value): string
		{
			$key = hash('sha256', wp_salt('vms_ma_token_key'), true);
			$iv = substr(hash('md5', wp_salt('vms_ma_token_iv')), 0, 16);
			if (!function_exists('openssl_encrypt')) {
				return $value;
			}
			return base64_encode(openssl_encrypt($value, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv));
		}

		public static function decrypt_token(string $value): string
		{
			$key = hash('sha256', wp_salt('vms_ma_token_key'), true);
			$iv = substr(hash('md5', wp_salt('vms_ma_token_iv')), 0, 16);
			if (!function_exists('openssl_decrypt')) {
				return $value;
			}
			$decoded = base64_decode($value, true);
			if ($decoded === false) {
				return '';
			}
			return (string) openssl_decrypt($decoded, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
		}

		public static function get_settings(): array
		{
				$defaults = array(
					'budget_max_daily_minor' => 5000,
					'budget_max_lifetime_minor' => 20000,
					'default_radius_miles' => 15,
					'max_radius_miles' => 100,
					'default_age_min' => 30,
				'default_age_max' => 65,
				'enable_api_create' => 0,
				'vms_ma_phase' => 1,
				'vms_ma_default_preset' => 'simple_14_day',
				'meta_graph_version' => 'v24.0',
				'meta_ad_account_id' => '',
				'meta_account_timezone' => '',
				'meta_account_timezone_detected' => '',
				'meta_page_id' => '',
				'facebook_page_url' => '',
				'meta_ig_actor_id' => '',
				'meta_pixel_id' => '',
				'meta_dsa_beneficiary' => '',
				'meta_dsa_payor' => '',
				'meta_access_token_encrypted' => '',
				'meta_app_mode' => '',
				'meta_app_mode_updated_gmt' => '',
				'meta_last_test_ok_gmt' => '',
				'meta_ad_account_override' => 0,
				'tour_autostart' => 1,
			);
			return wp_parse_args((array) get_option(self::SETTINGS_OPTION, array()), $defaults);
		}

		public static function normalize_timezone_identifier(string $value): string
		{
			$value = trim($value);
			if ($value === '') {
				return '';
			}

			$aliases = array(
				'PDT' => 'America/Los_Angeles',
				'PST' => 'America/Los_Angeles',
				'MDT' => 'America/Denver',
				'MST' => 'America/Denver',
				'CDT' => 'America/Chicago',
				'CST' => 'America/Chicago',
				'EDT' => 'America/New_York',
				'EST' => 'America/New_York',
			);

			$candidate = $aliases[strtoupper($value)] ?? $value;
			if (in_array($candidate, timezone_identifiers_list(), true)) {
				return $candidate;
			}

			try {
				$timezone = new DateTimeZone($candidate);
				return $timezone->getName();
			} catch (Exception $e) {
				return '';
			}
		}

		public static function get_meta_account_timezone(array $settings): DateTimeZone
		{
			$manual = self::normalize_timezone_identifier((string) ($settings['meta_account_timezone'] ?? ''));
			if ($manual !== '') {
				return new DateTimeZone($manual);
			}

			$detected = self::normalize_timezone_identifier((string) ($settings['meta_account_timezone_detected'] ?? ''));
			if ($detected !== '') {
				return new DateTimeZone($detected);
			}

			return wp_timezone();
		}

		public static function get_site_timezone_name(): string
		{
			$name = wp_timezone_string();
			if ($name !== '') {
				return $name;
			}

			return wp_timezone()->getName();
		}

		public static function update_settings(array $settings): bool
		{
			return update_option(self::SETTINGS_OPTION, $settings, false);
		}

		public static function normalize_guidance_level(string $guidance): string
		{
			$guidance = sanitize_key($guidance);
			return in_array($guidance, self::GUIDANCE_LEVELS, true) ? $guidance : 'beginner';
		}

		public static function get_guidance_defaults(string $guidance): array
		{
			$guidance = self::normalize_guidance_level($guidance);
			return array(
				'tour_autorun' => 0,
				'help_mode' => ($guidance === 'beginner') ? 1 : 0,
			);
		}

		public static function get_user_guidance_state(int $user_id): array
		{
			$guidance = self::normalize_guidance_level((string) get_user_meta($user_id, 'vms_ma_guidance_level', true));
			$defaults = self::get_guidance_defaults($guidance);

			$tour_raw = get_user_meta($user_id, 'vms_ma_tour_autorun', true);
			$help_raw = get_user_meta($user_id, 'vms_ma_help_mode', true);
			$tour_locked = (int) get_user_meta($user_id, 'vms_ma_tour_autorun_locked', true);
			$help_locked = (int) get_user_meta($user_id, 'vms_ma_help_mode_locked', true);

			return array(
				'guidance_level' => $guidance,
				'tour_autorun' => ($tour_raw === '') ? $defaults['tour_autorun'] : (((int) $tour_raw) ? 1 : 0),
				'help_mode' => ($help_raw === '') ? $defaults['help_mode'] : (((int) $help_raw) ? 1 : 0),
				'tour_autorun_locked' => $tour_locked ? 1 : 0,
				'help_mode_locked' => $help_locked ? 1 : 0,
			);
		}

		public static function record_app_mode(string $mode): void
		{
			$mode = sanitize_key($mode);
			if (!in_array($mode, array('development', 'live'), true)) {
				$mode = '';
			}
			$settings = self::get_settings();
			$settings['meta_app_mode'] = $mode;
			$settings['meta_app_mode_updated_gmt'] = gmdate('Y-m-d H:i:s');
			self::update_settings($settings);
		}

		public static function get_app_mode_state(): array
		{
			$settings = self::get_settings();
			$mode = sanitize_key((string) ($settings['meta_app_mode'] ?? ''));
			$updated_gmt = sanitize_text_field((string) ($settings['meta_app_mode_updated_gmt'] ?? ''));
			if (!in_array($mode, array('development', 'live'), true)) {
				$mode = '';
			}
			return array(
				'mode' => $mode,
				'updated_gmt' => $updated_gmt,
			);
		}

		public static function render_app_mode_badge(string $context = 'settings'): string
		{
			$state = self::get_app_mode_state();
			$mode = $state['mode'];
			$updated_gmt = $state['updated_gmt'];

			$label = 'Unknown';
			$class = 'vms-ma-mode-unknown';
			if ($mode === 'development') {
				$label = 'Development';
				$class = 'vms-ma-mode-development';
			} elseif ($mode === 'live') {
				$label = 'Live';
				$class = 'vms-ma-mode-live';
			}

			$tooltip = 'App Mode indicates whether Meta will allow your app to create ads via the API.';
			if ($updated_gmt !== '') {
				$ts = strtotime($updated_gmt . ' GMT');
				if ($ts) {
					$local = wp_date('Y-m-d H:i:s T', $ts, wp_timezone());
					$tooltip .= ' Last detected: ' . $label . ' (' . $local . ').';
				}
			} else {
				$tooltip .= ' Last detected: Unknown.';
			}
			$tooltip .= ' If you recently changed App Mode in Meta, run a Create Test again to refresh this badge.';

			return sprintf(
				'<span class="vms-ma-mode-badge %1$s" title="%2$s">%3$s</span>',
				esc_attr($class),
				esc_attr($tooltip),
				esc_html('App Mode: ' . $label)
			);
		}

	}
}

if (!function_exists('vms_ma_get_event_ad_spend_cents')) {
	function vms_ma_get_event_ad_spend_cents($event_plan_id, $context = array()): array
	{
		$event_plan_id = absint($event_plan_id);
		$result = array(
			'cents' => 0,
			'source' => '',
			'label' => __('Meta Ads budget', 'vms-meta-ads'),
			'basis' => 'budget',
		);

		if ($event_plan_id < 1) {
			return $result;
		}

		$meta_cents = absint(get_post_meta($event_plan_id, 'vms_ma_last_budget_cents', true));
		if ($meta_cents > 0) {
			$result['cents'] = $meta_cents;
			$result['source'] = 'vms_ma_last_budget_cents';
			return $result;
		}

		$draft_json = get_post_meta($event_plan_id, 'vms_ma_last_draft_json', true);
		if (is_string($draft_json) && $draft_json !== '') {
			$decoded = json_decode($draft_json, true);
			if (is_array($decoded)) {
				$draft_cents = absint($decoded['total_budget_minor'] ?? 0);
				if ($draft_cents > 0) {
					$result['cents'] = $draft_cents;
					$result['source'] = 'vms_ma_last_draft_json';
					return $result;
				}
			}
		}

		if (class_exists('VMS_Meta_Ads_Builds_Service')) {
			try {
				$builds = VMS_Meta_Ads_Builds_Service::list_builds(array(
					'event_plan_id' => $event_plan_id,
					'limit' => 1,
				));
			} catch (Throwable $e) {
				$builds = array();
			}
			if (!empty($builds) && is_array($builds[0] ?? null)) {
				$build = (array) $builds[0];
				$budget_payload = is_array($build['budget_payload'] ?? null) ? (array) $build['budget_payload'] : array();
				$build_cents = absint($budget_payload['total_budget_minor'] ?? 0);
				if ($build_cents > 0) {
					$result['cents'] = $build_cents;
					$result['source'] = 'build_budget_payload';
					return $result;
				}
			}
		}

		return $result;
	}
}

if (!function_exists('vms_meta_ads_builder_get_event_ad_spend_cents')) {
	function vms_meta_ads_builder_get_event_ad_spend_cents($event_plan_id, $context = array()): array
	{
		return vms_ma_get_event_ad_spend_cents($event_plan_id, $context);
	}
}

if (!function_exists('vms_meta_ads_builder_get_event_spend_cents')) {
	function vms_meta_ads_builder_get_event_spend_cents($event_plan_id, $context = array()): array
	{
		return vms_ma_get_event_ad_spend_cents($event_plan_id, $context);
	}
}
