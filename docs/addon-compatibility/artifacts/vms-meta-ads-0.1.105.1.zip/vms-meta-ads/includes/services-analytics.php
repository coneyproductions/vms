<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Analytics_Service')) {
	class VMS_Meta_Ads_Analytics_Service {
		private const CACHE_TTL = 900;
		private const CACHE_SCOPE = 'builder_bundle';
		private const MAX_BREAKDOWN_ROWS = 60;

		public static function rest_get_analytics(WP_REST_Request $request)
		{
			$nonce = (string) $request->get_header('X-WP-Nonce');
			if ($nonce === '' || !wp_verify_nonce($nonce, 'wp_rest')) {
				return new WP_Error('invalid_nonce', __('Invalid request nonce.', 'vms-meta-ads'), array('status' => 403));
			}

			$data = self::get_builder_analytics(
				absint($request->get_param('event_plan_id')),
				array(
					'preset' => sanitize_key((string) $request->get_param('preset')),
					'refresh' => !empty($request->get_param('refresh')),
					'build_id' => absint($request->get_param('build_id')),
				)
			);

			return rest_ensure_response($data);
		}

		public static function get_builder_analytics(int $event_plan_id, array $args = array()): array
		{
			$preset = sanitize_key((string) ($args['preset'] ?? 'last_7'));
			if (!in_array($preset, array('last_7', 'last_14', 'last_30', 'lifetime'), true)) {
				$preset = 'last_7';
			}
			$force_refresh = !empty($args['refresh']);
			$range = self::resolve_range($preset);
			$data = array(
				'ok' => false,
				'event_plan_id' => $event_plan_id,
				'preset' => $preset,
				'range' => $range,
				'error' => '',
				'warning' => '',
				'from_cache' => false,
				'fetched_at' => 0,
				'build' => array(),
				'reference' => array(),
				'summary' => self::empty_metrics(),
				'trend' => array('available' => false, 'points' => array()),
				'demographics' => array('rows' => array(), 'warning' => '', 'label' => __('Demographics', 'vms-meta-ads')),
				'regions' => array('rows' => array(), 'warning' => '', 'label' => __('Regions', 'vms-meta-ads')),
				'placements' => array('rows' => array(), 'warning' => '', 'label' => __('Placements', 'vms-meta-ads')),
				'devices' => array('rows' => array(), 'warning' => '', 'label' => __('Devices', 'vms-meta-ads')),
				'recommendations' => array(),
				'strategy_notes' => '',
			);

			if ($event_plan_id < 1) {
				$data['error'] = __('Choose an Event Plan first.', 'vms-meta-ads');
				return $data;
			}

			$connection = self::connection_settings();
			if (is_wp_error($connection)) {
				$data['error'] = $connection->get_error_message();
				return $data;
			}

			$requested_build_id = absint($args['build_id'] ?? 0);
			$builds = array();
			if ($requested_build_id > 0) {
				$requested_build = VMS_Meta_Ads_Builds_Service::get_build($requested_build_id);
				if (!is_wp_error($requested_build) && (int) ($requested_build['event_plan_id'] ?? 0) === $event_plan_id) {
					$builds[] = $requested_build;
				}
			}
			if (empty($builds)) {
				$builds = VMS_Meta_Ads_Builds_Service::list_builds(array(
					'event_plan_id' => $event_plan_id,
					'limit' => 12,
				));
			}
			if (empty($builds)) {
				$data['error'] = __('No Meta ad draft exists for this Event Plan yet. Save a draft first.', 'vms-meta-ads');
				return $data;
			}

			$build = array();
			$reference = null;
			$first_error = '';
			foreach ($builds as $candidate) {
				if (!is_array($candidate)) {
					continue;
				}
				$candidate_reference = self::resolve_meta_reference($candidate);
				if (is_wp_error($candidate_reference)) {
					if ($first_error === '') {
						$first_error = $candidate_reference->get_error_message();
					}
					continue;
				}
				$build = $candidate;
				$reference = $candidate_reference;
				break;
			}

			if (empty($build) || !is_array($reference)) {
				$data['error'] = ($first_error !== '') ? $first_error : __('This Event Plan does not have linked Meta IDs yet. Create in Meta first.', 'vms-meta-ads');
				return $data;
			}

			$data['build'] = self::compact_build($build);
			$data['reference'] = $reference;

			$cache_key = self::build_cache_key($event_plan_id, (int) ($build['id'] ?? 0), $reference, $range);
			if (!$force_refresh) {
				$cached = self::load_snapshot($cache_key);
				if (is_array($cached) && !empty($cached['payload']) && is_array($cached['payload'])) {
					$payload = (array) $cached['payload'];
					$payload['from_cache'] = true;
					$payload['fetched_at'] = absint($payload['fetched_at'] ?? strtotime((string) ($cached['fetched_at'] ?? '')));
					return array_merge($data, $payload, array(
						'ok' => !empty($payload['ok']),
						'error' => (string) ($payload['error'] ?? ''),
					));
				}
			}

			$summary_response = self::fetch_summary_bundle($connection, $reference, $range);
			if (is_wp_error($summary_response)) {
				$data['error'] = $summary_response->get_error_message();
				return $data;
			}

			$demographics = self::fetch_demographics_section($connection, $reference, $range);
			$regions = self::fetch_standard_section($connection, $reference, $range, array('region'), 'region', __('Regions', 'vms-meta-ads'));
			$placements = self::fetch_placements_section($connection, $reference, $range);
			$devices = self::fetch_standard_section($connection, $reference, $range, array('impression_device'), 'impression_device', __('Devices', 'vms-meta-ads'));

			$data['ok'] = true;
			$data['summary'] = is_array($summary_response['summary'] ?? null) ? (array) $summary_response['summary'] : self::empty_metrics();
			$data['trend'] = is_array($summary_response['trend'] ?? null) ? (array) $summary_response['trend'] : array('available' => false, 'points' => array());
			$data['demographics'] = $demographics;
			$data['regions'] = $regions;
			$data['placements'] = $placements;
			$data['devices'] = $devices;
			$data['fetched_at'] = current_time('timestamp');
			$data['recommendations'] = self::build_recommendations($data);
			$data['strategy_notes'] = self::build_strategy_notes($data['recommendations']);

			self::save_snapshot($cache_key, $event_plan_id, (int) ($build['id'] ?? 0), $reference, $range, $data);
			return $data;
		}

		private static function compact_build(array $build): array
		{
			$copy = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
			return array(
				'id' => (int) ($build['id'] ?? 0),
				'event_plan_id' => (int) ($build['event_plan_id'] ?? 0),
				'status' => sanitize_key((string) ($build['status'] ?? '')),
				'goal' => sanitize_key((string) ($build['goal'] ?? '')),
				'title' => self::build_title($build),
				'headline' => sanitize_text_field((string) ($copy['headline'] ?? '')),
				'updated_at' => sanitize_text_field((string) ($build['updated_at'] ?? '')),
			);
		}

		private static function resolve_range(string $preset): array
		{
			$today = wp_date('Y-m-d', null, wp_timezone());
			$end = $today;
			$start = $today;
			switch ($preset) {
				case 'last_14':
					$start = wp_date('Y-m-d', strtotime('-13 days', current_time('timestamp')), wp_timezone());
					break;
				case 'last_30':
					$start = wp_date('Y-m-d', strtotime('-29 days', current_time('timestamp')), wp_timezone());
					break;
				case 'lifetime':
					$start = '';
					$end = '';
					break;
				case 'last_7':
				default:
					$start = wp_date('Y-m-d', strtotime('-6 days', current_time('timestamp')), wp_timezone());
					break;
			}

			return array(
				'preset' => $preset,
				'start' => $start,
				'end' => $end,
			);
		}

		private static function fetch_summary_bundle(array $settings, array $reference, array $range)
		{
			$query = array(
				'fields' => implode(',', array(
					'impressions',
					'reach',
					'spend',
					'cpm',
					'clicks',
					'ctr',
					'inline_link_clicks',
					'frequency',
					'actions',
					'cost_per_action_type',
					'date_start',
					'date_stop',
				)),
				'level' => (string) $reference['level'],
			);

			if (($range['preset'] ?? '') === 'lifetime') {
				$query['date_preset'] = 'lifetime';
				$query['limit'] = 1;
			} else {
				$query['time_range'] = wp_json_encode(array(
					'since' => $range['start'],
					'until' => $range['end'],
				));
				$query['time_increment'] = 1;
				$query['limit'] = 90;
			}

			$rows = self::request_rows($settings, trailingslashit((string) $reference['object_id']) . 'insights', $query, 'fetch_analytics_summary', 'analytics');
			if (is_wp_error($rows)) {
				return $rows;
			}

			return array(
				'summary' => self::extract_metrics_from_rows($rows),
				'trend' => self::build_trend($rows, $range),
			);
		}

		private static function fetch_demographics_section(array $settings, array $reference, array $range): array
		{
			$section = self::empty_section(__('Demographics', 'vms-meta-ads'));
			$rows = self::fetch_breakdown_rows($settings, $reference, $range, array('age', 'gender'), 'fetch_analytics_demographics');
			if (!is_wp_error($rows)) {
				$section['rows'] = self::normalize_breakdown_rows($rows, 'demographics');
				return $section;
			}

			$age_rows = self::fetch_breakdown_rows($settings, $reference, $range, array('age'), 'fetch_analytics_demographics_age');
			$gender_rows = self::fetch_breakdown_rows($settings, $reference, $range, array('gender'), 'fetch_analytics_demographics_gender');
			$merged = array();
			if (!is_wp_error($age_rows)) {
				$merged = array_merge($merged, self::normalize_breakdown_rows($age_rows, 'age'));
			}
			if (!is_wp_error($gender_rows)) {
				$merged = array_merge($merged, self::normalize_breakdown_rows($gender_rows, 'gender'));
			}
			if (!empty($merged)) {
				$section['rows'] = $merged;
				$section['warning'] = __('Meta did not allow the combined age + gender breakdown for this report, so VMS fell back to separate age and gender slices.', 'vms-meta-ads');
				return $section;
			}

			$section['warning'] = $rows->get_error_message();
			return $section;
		}

		private static function fetch_placements_section(array $settings, array $reference, array $range): array
		{
			$section = self::empty_section(__('Placements', 'vms-meta-ads'));
			$rows = self::fetch_breakdown_rows($settings, $reference, $range, array('publisher_platform', 'platform_position'), 'fetch_analytics_placements');
			if (!is_wp_error($rows)) {
				$section['rows'] = self::normalize_breakdown_rows($rows, 'placements');
				return $section;
			}

			$fallback = self::fetch_breakdown_rows($settings, $reference, $range, array('publisher_platform'), 'fetch_analytics_placements_platform');
			if (!is_wp_error($fallback)) {
				$section['rows'] = self::normalize_breakdown_rows($fallback, 'publisher_platform');
				$section['warning'] = __('Meta did not allow publisher platform + position together for this report, so VMS fell back to platform-level placement data.', 'vms-meta-ads');
				return $section;
			}

			$section['warning'] = $rows->get_error_message();
			return $section;
		}

		private static function fetch_standard_section(array $settings, array $reference, array $range, array $breakdowns, string $mode, string $label): array
		{
			$section = self::empty_section($label);
			$rows = self::fetch_breakdown_rows($settings, $reference, $range, $breakdowns, 'fetch_analytics_' . $mode);
			if (is_wp_error($rows)) {
				$section['warning'] = $rows->get_error_message();
				return $section;
			}
			$section['rows'] = self::normalize_breakdown_rows($rows, $mode);
			return $section;
		}

		private static function empty_section(string $label): array
		{
			return array(
				'label' => $label,
				'rows' => array(),
				'warning' => '',
			);
		}

		private static function fetch_breakdown_rows(array $settings, array $reference, array $range, array $breakdowns, string $operation)
		{
			$query = array(
				'fields' => implode(',', array(
					'impressions',
					'reach',
					'spend',
					'cpm',
					'clicks',
					'ctr',
					'inline_link_clicks',
					'frequency',
					'date_start',
					'date_stop',
				)),
				'level' => (string) $reference['level'],
				'breakdowns' => implode(',', array_map('sanitize_key', $breakdowns)),
				'limit' => 250,
			);

			if (($range['preset'] ?? '') === 'lifetime') {
				$query['date_preset'] = 'lifetime';
			} else {
				$query['time_range'] = wp_json_encode(array(
					'since' => $range['start'],
					'until' => $range['end'],
				));
			}

			return self::request_rows($settings, trailingslashit((string) $reference['object_id']) . 'insights', $query, $operation, 'analytics');
		}

		private static function normalize_breakdown_rows(array $rows, string $mode): array
		{
			$out = array();
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$metrics = self::row_metrics($row);
				$label = self::breakdown_label($row, $mode);
				if ($label === '') {
					continue;
				}
				$out[] = array_merge(array(
					'label' => $label,
					'dimension' => sanitize_key($mode),
				), $metrics);
			}

			usort($out, static function (array $a, array $b): int {
				$left = (float) ($a['spend'] ?? 0);
				$right = (float) ($b['spend'] ?? 0);
				if ($left === $right) {
					return strcasecmp((string) ($a['label'] ?? ''), (string) ($b['label'] ?? ''));
				}
				return ($right <=> $left);
			});

			return array_slice($out, 0, self::MAX_BREAKDOWN_ROWS);
		}

		private static function row_metrics(array $row): array
		{
			$impressions = self::to_int($row['impressions'] ?? 0);
			$spend = self::to_float($row['spend'] ?? 0);
			$clicks = self::to_int($row['clicks'] ?? 0);
			$link_clicks = self::to_int($row['inline_link_clicks'] ?? 0);
			return array(
				'impressions' => $impressions,
				'reach' => self::to_int($row['reach'] ?? 0),
				'spend' => $spend,
				'clicks' => $clicks,
				'link_clicks' => $link_clicks,
				'ctr' => ($impressions > 0) ? (($clicks / $impressions) * 100) : self::to_float($row['ctr'] ?? 0),
				'link_ctr' => ($impressions > 0) ? (($link_clicks / $impressions) * 100) : 0.0,
				'link_cpc' => ($link_clicks > 0) ? ($spend / $link_clicks) : 0.0,
				'cpm' => ($impressions > 0) ? (($spend / $impressions) * 1000) : self::to_float($row['cpm'] ?? 0),
				'frequency' => self::to_float($row['frequency'] ?? 0),
			);
		}

		private static function breakdown_label(array $row, string $mode): string
		{
			switch ($mode) {
				case 'demographics':
					$age = sanitize_text_field((string) ($row['age'] ?? ''));
					$gender = sanitize_text_field((string) ($row['gender'] ?? ''));
					return trim(implode(' • ', array_filter(array(self::humanize_dimension($age), self::humanize_dimension($gender)))));
				case 'age':
					return sprintf(__('Age: %s', 'vms-meta-ads'), self::humanize_dimension((string) ($row['age'] ?? '')));
				case 'gender':
					return sprintf(__('Gender: %s', 'vms-meta-ads'), self::humanize_dimension((string) ($row['gender'] ?? '')));
				case 'region':
					$region = sanitize_text_field((string) ($row['region'] ?? ''));
					$country = sanitize_text_field((string) ($row['country'] ?? ''));
					return trim(implode(', ', array_filter(array($region, $country))));
				case 'placements':
					$platform = sanitize_text_field((string) ($row['publisher_platform'] ?? ''));
					$position = sanitize_text_field((string) ($row['platform_position'] ?? ''));
					return trim(implode(' • ', array_filter(array(self::humanize_dimension($platform), self::humanize_dimension($position)))));
				case 'publisher_platform':
					return self::humanize_dimension((string) ($row['publisher_platform'] ?? ''));
				case 'impression_device':
					return self::humanize_dimension((string) ($row['impression_device'] ?? ''));
				default:
					$value = sanitize_text_field((string) ($row[$mode] ?? ''));
					return self::humanize_dimension($value);
			}
		}

		private static function build_recommendations(array $data): array
		{
			$items = array();
			$summary = is_array($data['summary'] ?? null) ? (array) $data['summary'] : self::empty_metrics();
			$trend = is_array($data['trend'] ?? null) ? (array) $data['trend'] : array();
			$demographics = is_array($data['demographics']['rows'] ?? null) ? (array) $data['demographics']['rows'] : array();
			$regions = is_array($data['regions']['rows'] ?? null) ? (array) $data['regions']['rows'] : array();
			$placements = is_array($data['placements']['rows'] ?? null) ? (array) $data['placements']['rows'] : array();
			$devices = is_array($data['devices']['rows'] ?? null) ? (array) $data['devices']['rows'] : array();

			$best_demo = self::find_best_row($demographics, 500, 2);
			if (is_array($best_demo)) {
				$items[] = array(
					'severity' => 'success',
					'title' => __('Lean into the strongest demographic slice', 'vms-meta-ads'),
					'message' => sprintf(
						/* translators: 1: dimension label, 2: CTR, 3: CPC */
						__('Top response is %1$s with %2$s CTR and %3$s cost per link click. Consider duplicating the current winner and weighting audience settings toward this slice.', 'vms-meta-ads'),
						(string) ($best_demo['label'] ?? ''),
						self::format_percent((float) ($best_demo['link_ctr'] ?? 0)),
						self::format_currency((float) ($best_demo['link_cpc'] ?? 0))
					),
				);
			}

			$weak_placement = self::find_weak_placement($placements);
			if (is_array($weak_placement)) {
				$items[] = array(
					'severity' => 'warning',
					'title' => __('Trim or isolate a weak placement', 'vms-meta-ads'),
					'message' => sprintf(
						__('Placement %1$s has spent %2$s for %3$s link clicks. Consider removing it from mixed ad sets or cloning a separate test so it stops dragging the winner down.', 'vms-meta-ads'),
						(string) ($weak_placement['label'] ?? ''),
						self::format_currency((float) ($weak_placement['spend'] ?? 0)),
						number_format_i18n((int) ($weak_placement['link_clicks'] ?? 0))
					),
				);
			}

			$best_region = self::find_best_row($regions, 250, 1);
			if (is_array($best_region)) {
				$items[] = array(
					'severity' => 'info',
					'title' => __('A region is standing out', 'vms-meta-ads'),
					'message' => sprintf(
						__('Region %1$s is producing clicks at %2$s CTR. Consider tightening the radius or adding a dedicated region test around where response is already proving out.', 'vms-meta-ads'),
						(string) ($best_region['label'] ?? ''),
						self::format_percent((float) ($best_region['link_ctr'] ?? 0))
					),
				);
			}

			$device_split = self::device_split_note($devices, $summary);
			if ($device_split !== '') {
				$items[] = array(
					'severity' => 'info',
					'title' => __('Device mix snapshot', 'vms-meta-ads'),
					'message' => $device_split,
				);
			}

			$trend_note = self::trend_note($trend);
			if ($trend_note !== '') {
				$items[] = array(
					'severity' => 'warning',
					'title' => __('Recent trend check', 'vms-meta-ads'),
					'message' => $trend_note,
				);
			}

			return array_slice($items, 0, 5);
		}

		private static function build_strategy_notes(array $recommendations): string
		{
			if (empty($recommendations)) {
				return __('Not enough delivery yet for a strong strategy call. Let the ad run a little longer, then refresh analytics again.', 'vms-meta-ads');
			}
			$lines = array();
			foreach ($recommendations as $item) {
				if (!is_array($item)) {
					continue;
				}
				$lines[] = '- ' . trim((string) ($item['title'] ?? '')) . ': ' . trim((string) ($item['message'] ?? ''));
			}
			return implode("\n", array_filter($lines));
		}

		private static function find_best_row(array $rows, int $min_impressions, int $min_clicks): ?array
		{
			$winner = null;
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				if ((int) ($row['impressions'] ?? 0) < $min_impressions && (int) ($row['link_clicks'] ?? 0) < $min_clicks) {
					continue;
				}
				if ($winner === null) {
					$winner = $row;
					continue;
				}
				$current_ctr = (float) ($row['link_ctr'] ?? 0);
				$winner_ctr = (float) ($winner['link_ctr'] ?? 0);
				if ($current_ctr > $winner_ctr) {
					$winner = $row;
				}
			}
			return $winner;
		}

		private static function find_weak_placement(array $rows): ?array
		{
			$winner = null;
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$spend = (float) ($row['spend'] ?? 0);
				$link_clicks = (int) ($row['link_clicks'] ?? 0);
				$link_cpc = (float) ($row['link_cpc'] ?? 0);
				if ($spend < 5) {
					continue;
				}
				$score = ($link_clicks <= 0) ? ($spend + 1000) : ($spend + ($link_cpc * 10));
				if ($winner === null || $score > (float) ($winner['_score'] ?? 0)) {
					$row['_score'] = $score;
					$winner = $row;
				}
			}
			if (is_array($winner)) {
				unset($winner['_score']);
			}
			return $winner;
		}

		private static function device_split_note(array $rows, array $summary): string
		{
			if (empty($rows)) {
				return '';
			}
			$mobile = 0;
			$desktop = 0;
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$label = strtolower((string) ($row['label'] ?? ''));
				$impressions = (int) ($row['impressions'] ?? 0);
				if (strpos($label, 'desktop') !== false) {
					$desktop += $impressions;
				} else {
					$mobile += $impressions;
				}
			}
			$total = max(1, $mobile + $desktop);
			if ($mobile === 0 && $desktop === 0) {
				return '';
			}
			return sprintf(
				__('Approximate device mix is %1$s mobile vs %2$s desktop by impressions. Keep mobile-first creative and landing-page checks at the top of the list.', 'vms-meta-ads'),
				self::format_percent(($mobile / $total) * 100),
				self::format_percent(($desktop / $total) * 100)
			);
		}

		private static function trend_note(array $trend): string
		{
			$points = is_array($trend['points'] ?? null) ? array_values((array) $trend['points']) : array();
			if (count($points) < 6) {
				return '';
			}
			$recent = array_slice($points, -3);
			$prior = array_slice($points, -6, 3);
			$recent_ctr = self::average(array_map(static function (array $point): float {
				return (float) ($point['link_ctr'] ?? 0);
			}, $recent));
			$prior_ctr = self::average(array_map(static function (array $point): float {
				return (float) ($point['link_ctr'] ?? 0);
			}, $prior));
			if ($prior_ctr <= 0) {
				return '';
			}
			if ($recent_ctr < ($prior_ctr * 0.7)) {
				return __('The last few days are running materially softer than the previous few days. That usually means fatigue, weak placements, or a need for fresh creative.', 'vms-meta-ads');
			}
			if ($recent_ctr > ($prior_ctr * 1.2)) {
				return __('The last few days are stronger than the prior few days. This is a good time to protect the winner and avoid muddying it with too many simultaneous changes.', 'vms-meta-ads');
			}
			return '';
		}

		private static function request_rows(array $settings, string $path, array $query, string $operation, string $context)
		{
			$response = self::meta_get_request($settings, $path, $query, $operation, $context, 20);
			if (is_wp_error($response)) {
				return $response;
			}
			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || (is_array($body) && isset($body['error']))) {
				return self::meta_error_from_body($body, $code);
			}
			return is_array($body['data'] ?? null) ? array_values((array) $body['data']) : array();
		}

		private static function extract_metrics_from_rows(array $rows): array
		{
			if (empty($rows)) {
				return self::empty_metrics();
			}
			$summary = self::empty_metrics();
			$primary_row = array();
			$best_spend = -1.0;
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$impressions = self::to_int($row['impressions'] ?? 0);
				$spend = self::to_float($row['spend'] ?? 0);
				$link_clicks = self::to_int($row['inline_link_clicks'] ?? 0);
				$summary['spend'] += $spend;
				$summary['impressions'] += $impressions;
				$summary['reach'] += self::to_int($row['reach'] ?? 0);
				$summary['frequency'] += self::to_float($row['frequency'] ?? 0);
				$summary['clicks'] += self::to_int($row['clicks'] ?? 0);
				$summary['link_clicks'] += $link_clicks;
				$summary['date_start'] = sanitize_text_field((string) ($summary['date_start'] === '' ? ($row['date_start'] ?? '') : min($summary['date_start'], sanitize_text_field((string) ($row['date_start'] ?? '')))));
				$summary['date_stop'] = sanitize_text_field((string) ($summary['date_stop'] === '' ? ($row['date_stop'] ?? '') : max($summary['date_stop'], sanitize_text_field((string) ($row['date_stop'] ?? '')))));
				if ($spend > $best_spend) {
					$best_spend = $spend;
					$primary_row = $row;
				}
			}
			$summary['link_ctr'] = ($summary['impressions'] > 0) ? (($summary['link_clicks'] / $summary['impressions']) * 100) : 0.0;
			$summary['link_cpc'] = ($summary['link_clicks'] > 0) ? ($summary['spend'] / $summary['link_clicks']) : 0.0;
			$summary['ctr'] = ($summary['impressions'] > 0) ? (($summary['clicks'] / $summary['impressions']) * 100) : 0.0;
			$summary['cpm'] = ($summary['impressions'] > 0) ? (($summary['spend'] / $summary['impressions']) * 1000) : 0.0;
			$result = self::extract_primary_result($primary_row);
			$summary['result_label'] = sanitize_text_field((string) ($result['label'] ?? ''));
			$summary['result_count'] = self::to_float($result['count'] ?? 0);
			$summary['cost_per_result'] = self::to_float($result['cost'] ?? 0);
			return $summary;
		}

		private static function build_trend(array $rows, array $range): array
		{
			if (($range['preset'] ?? '') === 'lifetime') {
				return array('available' => false, 'points' => array());
			}
			$series = array();
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$date = sanitize_text_field((string) ($row['date_start'] ?? $row['date_stop'] ?? ''));
				if ($date === '') {
					continue;
				}
				if (!isset($series[$date])) {
					$series[$date] = array(
						'date' => $date,
						'spend' => 0.0,
						'impressions' => 0,
						'link_clicks' => 0,
						'reach' => 0,
					);
				}
				$series[$date]['spend'] += self::to_float($row['spend'] ?? 0);
				$series[$date]['impressions'] += self::to_int($row['impressions'] ?? 0);
				$series[$date]['link_clicks'] += self::to_int($row['inline_link_clicks'] ?? 0);
				$series[$date]['reach'] += self::to_int($row['reach'] ?? 0);
			}
			ksort($series);
			foreach ($series as $date => $point) {
				$impressions = max(0, (int) ($point['impressions'] ?? 0));
				$link_clicks = max(0, (int) ($point['link_clicks'] ?? 0));
				$series[$date]['link_ctr'] = ($impressions > 0) ? (($link_clicks / $impressions) * 100) : 0.0;
			}
			return array(
				'available' => !empty($series),
				'points' => array_values($series),
			);
		}

		private static function extract_primary_result(array $row): array
		{
			$actions = is_array($row['actions'] ?? null) ? (array) $row['actions'] : array();
			$costs = is_array($row['cost_per_action_type'] ?? null) ? (array) $row['cost_per_action_type'] : array();
			if (empty($actions)) {
				return array('label' => '', 'count' => 0, 'cost' => 0);
			}
			$priority = array('lead', 'onsite_conversion.lead_grouped', 'landing_page_view', 'link_click', 'post_engagement');
			$action_map = array();
			foreach ($actions as $action) {
				if (!is_array($action)) {
					continue;
				}
				$type = sanitize_text_field((string) ($action['action_type'] ?? ''));
				if ($type === '') {
					continue;
				}
				$action_map[$type] = self::to_float($action['value'] ?? 0);
			}
			$cost_map = array();
			foreach ($costs as $cost) {
				if (!is_array($cost)) {
					continue;
				}
				$type = sanitize_text_field((string) ($cost['action_type'] ?? ''));
				if ($type === '') {
					continue;
				}
				$cost_map[$type] = self::to_float($cost['value'] ?? 0);
			}
			foreach ($priority as $type) {
				if (!array_key_exists($type, $action_map)) {
					continue;
				}
				return array(
					'label' => self::humanize_dimension($type),
					'count' => $action_map[$type],
					'cost' => $cost_map[$type] ?? 0,
				);
			}
			$first_type = (string) key($action_map);
			return array(
				'label' => self::humanize_dimension($first_type),
				'count' => $action_map[$first_type] ?? 0,
				'cost' => $cost_map[$first_type] ?? 0,
			);
		}

		private static function build_title(array $build): string
		{
			$event_plan_id = absint($build['event_plan_id'] ?? 0);
			if ($event_plan_id > 0) {
				$title = get_the_title($event_plan_id);
				if (is_string($title) && $title !== '') {
					return $title;
				}
			}
			$copy = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
			$headline = sanitize_text_field((string) ($copy['headline'] ?? ''));
			if ($headline !== '') {
				return $headline;
			}
			return sprintf(__('Build #%d', 'vms-meta-ads'), (int) ($build['id'] ?? 0));
		}

		private static function connection_settings()
		{
			$settings = VMS_Meta_Ads_Utils::get_settings();
			$token = VMS_Meta_Ads_Utils::decrypt_token((string) ($settings['meta_access_token_encrypted'] ?? ''));
			$ad_account_id = trim((string) ($settings['meta_ad_account_id'] ?? ''));
			if ($ad_account_id === '') {
				return new WP_Error('missing_ad_account_id', __('Add your Meta ad account ID in Settings before opening Analytics.', 'vms-meta-ads'));
			}
			if ($token === '') {
				return new WP_Error('missing_access_token', __('Save a Meta access token in Settings before opening Analytics.', 'vms-meta-ads'));
			}
			return array(
				'token' => $token,
				'meta_graph_version' => (string) ($settings['meta_graph_version'] ?? 'v24.0'),
				'meta_ad_account_id' => ltrim($ad_account_id, 'act_'),
			);
		}

		private static function resolve_meta_reference(array $build)
		{
			$meta_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			$ad_id = sanitize_text_field((string) ($meta_ids['ad_id'] ?? ''));
			$adset_id = sanitize_text_field((string) ($meta_ids['adset_id'] ?? ''));
			$campaign_id = sanitize_text_field((string) ($meta_ids['campaign_id'] ?? ''));
			$settings = VMS_Meta_Ads_Utils::get_settings();
			$ad_account_id = ltrim(trim((string) ($settings['meta_ad_account_id'] ?? '')), 'act_');
			$manager_url = 'https://adsmanager.facebook.com/';
			if ($ad_account_id !== '') {
				$manager_url = 'https://adsmanager.facebook.com/adsmanager/manage/campaigns?act=' . rawurlencode($ad_account_id);
			}
			if ($ad_id !== '') {
				return array(
					'level' => 'ad',
					'object_id' => $ad_id,
					'object_label' => __('Ad', 'vms-meta-ads'),
					'manager_url' => $manager_url,
				);
			}
			if ($adset_id !== '') {
				return array(
					'level' => 'adset',
					'object_id' => $adset_id,
					'object_label' => __('Ad Set', 'vms-meta-ads'),
					'manager_url' => $manager_url,
				);
			}
			if ($campaign_id !== '') {
				return array(
					'level' => 'campaign',
					'object_id' => $campaign_id,
					'object_label' => __('Campaign', 'vms-meta-ads'),
					'manager_url' => $manager_url,
				);
			}
			return new WP_Error('missing_meta_reference', __('This build has no Meta campaign, ad set, or ad ID yet. Create in Meta first.', 'vms-meta-ads'));
		}

		private static function build_cache_key(int $event_plan_id, int $build_id, array $reference, array $range): string
		{
			return md5(wp_json_encode(array(
				'event_plan_id' => $event_plan_id,
				'build_id' => $build_id,
				'object_id' => (string) ($reference['object_id'] ?? ''),
				'level' => (string) ($reference['level'] ?? ''),
				'preset' => (string) ($range['preset'] ?? ''),
				'start' => (string) ($range['start'] ?? ''),
				'end' => (string) ($range['end'] ?? ''),
				'scope' => self::CACHE_SCOPE,
				'version' => defined('VMS_MA_VERSION') ? VMS_MA_VERSION : '1',
			)));
		}

		private static function load_snapshot(string $cache_key): ?array
		{
			global $wpdb;
			$table = $wpdb->prefix . 'vms_meta_ads_analytics_snapshots';
			$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE cache_key = %s LIMIT 1", $cache_key), ARRAY_A);
			if (!is_array($row)) {
				return null;
			}
			$fetched_at = strtotime((string) ($row['fetched_at'] ?? ''));
			if ($fetched_at <= 0 || (time() - $fetched_at) > self::CACHE_TTL) {
				return null;
			}
			$payload = json_decode((string) ($row['payload'] ?? ''), true);
			if (!is_array($payload)) {
				return null;
			}
			return array(
				'payload' => $payload,
				'fetched_at' => (string) ($row['fetched_at'] ?? ''),
			);
		}

		private static function save_snapshot(string $cache_key, int $event_plan_id, int $build_id, array $reference, array $range, array $payload): void
		{
			global $wpdb;
			$table = $wpdb->prefix . 'vms_meta_ads_analytics_snapshots';
			$now = current_time('mysql', true);
			$existing_id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE cache_key = %s LIMIT 1", $cache_key));
			$row = array(
				'cache_key' => $cache_key,
				'event_plan_id' => $event_plan_id,
				'build_id' => $build_id,
				'object_level' => sanitize_key((string) ($reference['level'] ?? '')),
				'object_id' => sanitize_text_field((string) ($reference['object_id'] ?? '')),
				'range_key' => sanitize_key((string) ($range['preset'] ?? 'last_7')),
				'scope_key' => self::CACHE_SCOPE,
				'payload' => wp_json_encode($payload),
				'fetched_at' => $now,
				'updated_at' => $now,
			);
			$formats = array('%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s');
			if ($existing_id > 0) {
				$wpdb->update($table, $row, array('id' => $existing_id), $formats, array('%d'));
				return;
			}
			$row['created_at'] = $now;
			$formats[] = '%s';
			$wpdb->insert($table, $row, $formats);
		}

		private static function meta_get_request(array $settings, string $path, array $query, string $operation, string $context, int $timeout = 20)
		{
			$path = ltrim($path, '/');
			$query_for_log = $query;
			unset($query_for_log['access_token']);
			$endpoint = $path;
			if (!empty($query_for_log)) {
				$endpoint .= '?' . http_build_query($query_for_log);
			}
			return vms_api_attempt_wrap(
				'meta_ads',
				'vms-facebook-ads',
				$operation,
				$context,
				'GET',
				$endpoint,
				array('query' => $query_for_log),
				static function () use ($settings, $path, $query, $timeout) {
					$url = VMS_Meta_Ads_Meta_Endpoints::build_url($settings, $path);
					$url = add_query_arg(array_merge($query, array('access_token' => (string) ($settings['token'] ?? ''))), $url);
					return wp_remote_get($url, array('timeout' => $timeout));
				}
			);
		}

		private static function meta_error_from_body($body, int $status)
		{
			$message = __('Meta Insights request failed.', 'vms-meta-ads');
			if (is_array($body) && isset($body['error']) && is_array($body['error'])) {
				$error = (array) $body['error'];
				$raw = sanitize_text_field((string) ($error['message'] ?? ''));
				if ($raw !== '') {
					$message = $raw;
				}
			}
			return new WP_Error('meta_insights_failed', $message, array('status' => $status));
		}

		private static function empty_metrics(): array
		{
			return array(
				'spend' => 0.0,
				'impressions' => 0,
				'reach' => 0,
				'frequency' => 0.0,
				'clicks' => 0,
				'link_clicks' => 0,
				'link_ctr' => 0.0,
				'link_cpc' => 0.0,
				'ctr' => 0.0,
				'cpm' => 0.0,
				'date_start' => '',
				'date_stop' => '',
				'result_label' => '',
				'result_count' => 0.0,
				'cost_per_result' => 0.0,
			);
		}

		private static function humanize_dimension(string $value): string
		{
			$value = trim($value);
			if ($value === '') {
				return '';
			}
			$map = array(
				'unknown' => __('Unknown', 'vms-meta-ads'),
				'female' => __('Female', 'vms-meta-ads'),
				'male' => __('Male', 'vms-meta-ads'),
				'facebook' => __('Facebook', 'vms-meta-ads'),
				'instagram' => __('Instagram', 'vms-meta-ads'),
				'audience_network' => __('Audience Network', 'vms-meta-ads'),
				'messenger' => __('Messenger', 'vms-meta-ads'),
				'facebook_feed' => __('Facebook Feed', 'vms-meta-ads'),
				'facebook_right_hand_column' => __('Facebook Right Column', 'vms-meta-ads'),
				'facebook_stories' => __('Facebook Stories', 'vms-meta-ads'),
				'facebook_reels' => __('Facebook Reels', 'vms-meta-ads'),
				'instagram_feed' => __('Instagram Feed', 'vms-meta-ads'),
				'instagram_story' => __('Instagram Story', 'vms-meta-ads'),
				'instagram_stories' => __('Instagram Stories', 'vms-meta-ads'),
				'instagram_reels' => __('Instagram Reels', 'vms-meta-ads'),
				'desktop' => __('Desktop', 'vms-meta-ads'),
				'iphone' => __('iPhone', 'vms-meta-ads'),
				'ipad' => __('iPad', 'vms-meta-ads'),
				'android_smartphone' => __('Android Smartphone', 'vms-meta-ads'),
				'android_tablet' => __('Android Tablet', 'vms-meta-ads'),
				'mobile_web' => __('Mobile Web', 'vms-meta-ads'),
				'mobile_app' => __('Mobile App', 'vms-meta-ads'),
				'landing_page_view' => __('Landing Page Views', 'vms-meta-ads'),
				'link_click' => __('Link Clicks', 'vms-meta-ads'),
				'post_engagement' => __('Post Engagement', 'vms-meta-ads'),
				'onsite_conversion.lead_grouped' => __('Leads', 'vms-meta-ads'),
				'lead' => __('Leads', 'vms-meta-ads'),
			);
			if (isset($map[$value])) {
				return $map[$value];
			}
			$value = str_replace(array('.', '_'), ' ', $value);
			return ucwords(trim($value));
		}

		private static function average(array $values): float
		{
			$values = array_values(array_filter($values, static function ($value): bool {
				return is_numeric($value);
			}));
			if (empty($values)) {
				return 0.0;
			}
			return array_sum($values) / count($values);
		}

		private static function format_percent(float $value): string
		{
			return number_format_i18n($value, 2) . '%';
		}

		private static function format_currency(float $value): string
		{
			return '$' . number_format_i18n($value, 2);
		}

		private static function to_int($value): int
		{
			return is_numeric($value) ? (int) round((float) $value) : 0;
		}

		private static function to_float($value): float
		{
			return is_numeric($value) ? (float) $value : 0.0;
		}
	}
}
