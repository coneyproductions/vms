<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ma_post_asset_create')) {
	function vms_ma_post_asset_create(array $data)
	{
		global $wpdb;
		$table = $wpdb->prefix . 'vms_marketing_post_assets';
		$now = current_time('mysql', true);
		$data = wp_parse_args($data, array(
			'platform' => 'meta_facebook',
			'venue_id' => null,
			'event_plan_id' => null,
			'post_id' => '',
			'permalink' => '',
			'copy_used' => '',
			'media_asset_id' => null,
			'created_by' => get_current_user_id(),
		));

		if (empty($data['post_id'])) {
			return new WP_Error('invalid_post_id', 'Post ID is required.');
		}

		$inserted = $wpdb->insert($table, array(
			'platform' => sanitize_text_field($data['platform']),
			'venue_id' => $data['venue_id'] ? absint($data['venue_id']) : null,
			'event_plan_id' => $data['event_plan_id'] ? absint($data['event_plan_id']) : null,
			'post_id' => sanitize_text_field($data['post_id']),
			'permalink' => esc_url_raw($data['permalink']),
			'copy_used' => wp_json_encode($data['copy_used']),
			'media_asset_id' => $data['media_asset_id'] ? absint($data['media_asset_id']) : null,
			'created_by' => absint($data['created_by']),
			'created_at' => $now,
		), array('%s', '%d', '%d', '%s', '%s', '%s', '%d', '%s'));

		if ($inserted === false) {
			return new WP_Error('db_insert', 'Unable to insert post asset.');
		}

		return (int) $wpdb->insert_id;
	}
}

if (!function_exists('vms_ma_post_asset_list')) {
	function vms_ma_post_asset_list(array $filters = array()): array
	{
		global $wpdb;
		$table = $wpdb->prefix . 'vms_marketing_post_assets';
		$clauses = array('1=1');
		$params = array();
		if (!empty($filters['platform'])) {
			$clauses[] = 'platform = %s';
			$params[] = sanitize_text_field($filters['platform']);
		}
		if (!empty($filters['event_plan_id'])) {
			$clauses[] = 'event_plan_id = %d';
			$params[] = absint($filters['event_plan_id']);
		}
		if (!empty($filters['venue_id'])) {
			$clauses[] = 'venue_id = %d';
			$params[] = absint($filters['venue_id']);
		}
		$limit = !empty($filters['limit']) ? ' LIMIT ' . intval($filters['limit']) : '';
		$query = "SELECT * FROM $table WHERE " . implode(' AND ', $clauses) . " ORDER BY created_at DESC" . $limit;
		if (!empty($params)) {
			return $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);
		}
		return $wpdb->get_results($query, ARRAY_A);
	}
}

if (!function_exists('vms_ma_post_asset_get')) {
	function vms_ma_post_asset_get(int $id)
	{
		global $wpdb;
		$table = $wpdb->prefix . 'vms_marketing_post_assets';
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id), ARRAY_A);
	}
}
