<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Help')) {
	class VMS_Meta_Ads_Help {
		public static function get_payload(): array
		{
			return array(
				'ma_help_event_plan_id' => array(
					'title' => __('Event Plan ID', 'vms-meta-ads'),
					'html_beginner' => __('<p><b>Use the Select Event Plan dropdown.</b> It autofills event name, venue, start time, and destination URL so Step A is faster.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Use the Select Event Plan picker for autofill. Manual Event Plan ID entry is available under Advanced when needed.</p>', 'vms-meta-ads'),
				),
				'ma_help_destination_url' => array(
					'title' => __('Destination URL', 'vms-meta-ads'),
					'html_beginner' => __('<p>Paste the ticket or landing page URL people should open after clicking your ad.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Primary click-through URL used for copy pack + UTM output.</p>', 'vms-meta-ads'),
				),
				'ma_help_preset' => array(
					'title' => __('Preset', 'vms-meta-ads'),
					'html_beginner' => __('<p>Preset chooses the schedule shape. New builds now start on Simple 14 day so direct Meta create/update stays on one saved schedule window. Flat run, Simple 7/14/30 day, and Manual dates are also single-window safe. Video-Led Ticket Push and Promo Bundle remain useful for preview/export, but direct Meta create/update is still single-window only in this phase.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Controls schedule structure and tier behavior. Direct Meta create/update currently supports a single schedule window only.</p>', 'vms-meta-ads'),
				),
				'ma_help_autoramp' => array(
					'title' => __('Auto-Ramp', 'vms-meta-ads'),
					'html_beginner' => __('<p>Auto-Ramp splits your total budget across windows automatically and skips tiers that no longer fit.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Enables tiered budget scheduling.</p>', 'vms-meta-ads'),
				),
					'ma_help_creative_mode' => array(
						'title' => __('Creative Mode', 'vms-meta-ads'),
						'html_beginner' => __('<p>Use <b>Dark Post Link Ad</b> for most cases. Choose Boost Existing Post only if you already have strong engagement.</p>', 'vms-meta-ads'),
						'html_standard' => __('<p>Select how ad creative is sourced.</p>', 'vms-meta-ads'),
					),
					'ma_help_dark_post' => array(
						'title' => __('Dark Post', 'vms-meta-ads'),
						'html_beginner' => __('<p>A dark post is an unpublished ad-only post. It does not clutter your Page feed but can be used for ads.</p>', 'vms-meta-ads'),
						'html_standard' => __('<p>Unpublished ad-only creative used for direct response flows.</p>', 'vms-meta-ads'),
					),
				'ma_help_radius' => array(
					'title' => __('Radius', 'vms-meta-ads'),
					'html_beginner' => __('<p>Start with 15 miles near the venue. Increase only if your audience is spread out.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Defines local audience boundary.</p>', 'vms-meta-ads'),
				),
				'ma_help_age' => array(
					'title' => __('Age Range', 'vms-meta-ads'),
					'html_beginner' => __('<p>Set age limits to match venue policy (for example, 21+ events).</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Audience age guardrail.</p>', 'vms-meta-ads'),
				),
				'ma_help_interests' => array(
					'title' => __('Interests', 'vms-meta-ads'),
					'html_beginner' => __('<p>Optional advanced targeting labels. Use the suggestion chips first, then add comma-separated labels here only when you have a specific audience idea.</p><p>These labels are saved safely, but they are not treated as live Meta targeting IDs until they are validated later.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Comma-separated interest or behavior labels. MAB stores labels and any future Meta IDs separately so stale labels do not get sent as if they were validated targets.</p>', 'vms-meta-ads'),
				),
				'ma_help_budget_total' => array(
					'title' => __('Total Budget', 'vms-meta-ads'),
					'html_beginner' => __('<p>Enter total dollars you are comfortable spending. VMS applies clamp validation before export/create.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Total campaign budget in dollars. As a rule of thumb, keep the schedule at about $1/day or higher so Meta is less likely to reject the ad set.</p>', 'vms-meta-ads'),
				),
				'ma_help_copy_pack' => array(
					'title' => __('Copy Pack', 'vms-meta-ads'),
					'html_beginner' => __('<p>Copy Pack gives paste-ready campaign names, ad set/ad names, text variants, UTMs, and summary fields.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Export-ready payload for manual Meta entry.</p>', 'vms-meta-ads'),
				),
				'ma_help_budget_max_daily' => array(
					'title' => __('Budget Max Daily', 'vms-meta-ads'),
					'html_beginner' => __('<p>Maximum daily spend allowed in Builder. Keep this conservative until workflow is stable.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Daily clamp stored internally in cents.</p>', 'vms-meta-ads'),
				),
				'ma_help_budget_max_lifetime' => array(
					'title' => __('Budget Max Lifetime', 'vms-meta-ads'),
					'html_beginner' => __('<p>Hard ceiling for total spend per build.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Lifetime clamp for draft/export validation.</p>', 'vms-meta-ads'),
				),
				'ma_help_enable_api' => array(
					'title' => __('Enable API Create', 'vms-meta-ads'),
					'html_beginner' => __('<p>Leave this off until Save + Test Connection works.</p><p>When this is on, the plugin is allowed to create ads inside Meta for you.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Feature gate for API creation routes.</p>', 'vms-meta-ads'),
				),
				'ma_help_graph_version' => array(
					'title' => __('Graph Version', 'vms-meta-ads'),
					'html_beginner' => __('<p>This is the Meta API version number.</p><p>Most people should leave it alone unless support tells them to change it.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Meta Graph API version string.</p>', 'vms-meta-ads'),
				),
				'ma_help_ad_account_id' => array(
					'title' => __('Ad Account ID', 'vms-meta-ads'),
					'html_beginner' => __('<p>Paste the ad account number Meta uses for billing.</p><p>You can paste just the number or the version that starts with <code>act_</code>.</p><p>Save this before using the Meta lookup button.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Billing account used for API create/go-live.</p>', 'vms-meta-ads'),
				),
				'ma_help_page_id' => array(
					'title' => __('Page ID', 'vms-meta-ads'),
					'html_beginner' => __('<p>This is your business Facebook Page number, not your personal Facebook profile.</p><p>The easiest path is to save your ad account and token first, then use Lookup from Meta to fill this in for you.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Page identity for ad metadata.</p>', 'vms-meta-ads'),
				),
				'ma_help_ig_actor_id' => array(
					'title' => __('Instagram Account ID', 'vms-meta-ads'),
					'html_beginner' => __('<p>This box is optional.</p><p>Only use it if you want the ad to use your Instagram account too.</p><p>This must be the Instagram Business Account ID connected to your Facebook Page, not your @username.</p><p>The easiest path is to save first, then use Lookup from Meta and let the plugin fill this for you. If you are unsure, leave it blank for now.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Optional Instagram Business Account ID used for IG placements. It must be connected to the selected Facebook Page.</p>', 'vms-meta-ads'),
				),
				'ma_help_access_token' => array(
					'title' => __('Access Token', 'vms-meta-ads'),
					'html_beginner' => vms_ma_copy_access_token_beginner_html(),
					'html_standard' => vms_ma_copy_access_token_beginner_html(),
					'html_expert' => vms_ma_copy_access_token_expert_html(),
				),
				'ma_help_test_connection' => array(
					'title' => __('Test Connection', 'vms-meta-ads'),
					'html_beginner' => __('<p>Click Save Settings first.</p><p>Then click Test Connection.</p><p>If it passes, your numbers and token are working.</p>', 'vms-meta-ads'),
					'html_standard' => __('<p>Checks API credential viability.</p>', 'vms-meta-ads'),
				),
			);
		}
	}
}
