<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ma_copy_access_token_beginner_html')) {
    function vms_ma_copy_access_token_beginner_html(): string
    {
        return __(
            '<p><strong>Access Token (permission to manage ads)</strong></p>
        <p><strong>What this does:</strong><br> This token authorizes VMS to access your Meta Ads account through the Marketing API (so VMS can read and/or create campaigns).</p>

        <p><strong>Before you start:</strong></p>
        <ul>
          <li>You must be logged into Facebook in this browser.</li>
          <li>You must have access to the Ad Account you will use (in Meta Business settings).</li>
          <li>This token must include ads permissions, or the connection test will fail.</li>
        </ul>

        <p><strong>Do this now (step by step):</strong></p>
        <ol>
          <li>Open Meta for Developers and go to Tools → Graph API Explorer.</li>
          <li>In Graph API Explorer:
            <ul>
              <li><strong>Meta App:</strong> select your app (example: “VMS Ads Builder”).</li>
              <li><strong>User or Page:</strong> choose “Get User Access Token”.</li>
            </ul>
          </li>
          <li>Under Permissions:
            <ul>
              <li>Click “Add a Permission”.</li>
              <li>Add at least one:
                <ul>
                  <li><strong>ads_read</strong> (read-only access)</li>
                  <li><strong>ads_management</strong> (create/manage ads)</li>
                </ul>
              </li>
              <li>If you want VMS to create campaigns, <strong>ads_management</strong> is required.</li>
            </ul>
          </li>
          <li>Click “Generate Access Token” and approve the prompts.</li>
          <li>Copy the generated token and paste it into this field.</li>
          <li>Click “Save”, then run “Test Connection”.</li>
        </ol>

        <p><strong>What success looks like:</strong></p>
        <ul>
          <li>The Access Token box in Graph API Explorer is filled (it starts blank until you generate).</li>
          <li>Test Connection returns success.</li>
        </ul>

        <p><strong>Common failure:</strong> If you skip selecting <strong>ads_read</strong> or <strong>ads_management</strong>, Meta will reject the test with a permissions error.</p>

        <p><strong>Important:</strong></p>
        <ul>
          <li>Treat this token like a password. Only admins should have access to it.</li>
          <li>Leave this field blank later if you want to keep the existing token unchanged.</li>
        </ul>',
            'vms-meta-ads'
        );
    }
}

if (!function_exists('vms_ma_copy_access_token_expert_html')) {
    function vms_ma_copy_access_token_expert_html(): string
    {
        return __(
            '<p><strong>Access Token (Ads API)</strong></p>
        <p>Generate a User Access Token in Graph API Explorer for your app with <strong>ads_read</strong> and/or <strong>ads_management</strong>, then paste it here. (<strong>ads_management</strong> required to create/manage campaigns.)</p>
        <p>Leave blank to keep the existing token unchanged.</p>',
            'vms-meta-ads'
        );
    }
}

if (!function_exists('vms_ma_warn_access_token_copy_mismatch')) {
    function vms_ma_warn_access_token_copy_mismatch(): void
    {
        if (!defined('WP_DEBUG') || !WP_DEBUG) {
            return;
        }
        if (!class_exists('VMS_Meta_Ads_Help')) {
            return;
        }
        $payload = VMS_Meta_Ads_Help::get_payload();
        $existing = isset($payload['ma_help_access_token']['html_beginner']) ? $payload['ma_help_access_token']['html_beginner'] : '';
        $canonical = vms_ma_copy_access_token_beginner_html();
        if ($existing !== $canonical) {
            error_log('VMS Meta Ads: Access Token beginner copy differs from canonical helper.');
        }
    }
}

add_action('admin_init', 'vms_ma_warn_access_token_copy_mismatch');
