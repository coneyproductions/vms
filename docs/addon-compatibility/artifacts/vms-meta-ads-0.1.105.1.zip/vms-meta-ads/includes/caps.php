<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Caps')) {
	class VMS_Meta_Ads_Caps {
		public static function register(): void
		{
			// Reserved for capability registration if VMS exposes custom roles.
		}

		public static function get_manage_capability(): string
		{
			foreach (array('VMS_CAP_MANAGE', 'VMS_CAP_MANAGE_VMS') as $constant_name) {
				$capability = vms_ma_core_constant($constant_name, '');
				if (is_string($capability) && $capability !== '') {
					return $capability;
				}
			}
			if (current_user_can('manage_vms')) {
				return 'manage_vms';
			}
			foreach (array('VMS_CAP_SOCIAL_MANAGE', 'VMS_CAP_MANAGE_EVENT_PLANS') as $constant_name) {
				$capability = vms_ma_core_constant($constant_name, '');
				if (is_string($capability) && $capability !== '') {
					return $capability;
				}
			}
			return 'manage_options';
		}
	}
}

if (!function_exists('vms_ma_current_user_can_manage')) {
	function vms_ma_current_user_can_manage(): bool
	{
		return current_user_can(VMS_Meta_Ads_Caps::get_manage_capability());
	}
}
