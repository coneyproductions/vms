<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_DB')) {
	class VMS_Meta_Ads_DB {
		public static function install(): void
		{
			global $wpdb;
			$charset = $wpdb->get_charset_collate();
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			$statements = array(
				"CREATE TABLE " . $wpdb->prefix . "vms_meta_ads_templates (
					id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
					template_name VARCHAR(128) NOT NULL,
					payload LONGTEXT NOT NULL,
					created_by BIGINT UNSIGNED NOT NULL,
					created_at DATETIME NOT NULL,
					updated_at DATETIME NOT NULL,
					PRIMARY KEY (id),
					KEY template_name (template_name),
					KEY created_at (created_at)
				) $charset",
				"CREATE TABLE " . $wpdb->prefix . "vms_meta_ads_builds (
					id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
					event_plan_id BIGINT UNSIGNED NULL,
					venue_id BIGINT UNSIGNED NULL,
					source_type VARCHAR(24) NOT NULL DEFAULT 'event_plan',
					source_ref VARCHAR(128) NULL,
					mode VARCHAR(16) NOT NULL DEFAULT 'simple',
					goal VARCHAR(32) NOT NULL DEFAULT 'traffic',
					objective_meta VARCHAR(64) NOT NULL DEFAULT 'OUTCOME_TRAFFIC',
					creative_mode VARCHAR(24) NOT NULL DEFAULT 'dark_post',
					post_asset_id BIGINT UNSIGNED NULL,
					destination_url TEXT NOT NULL,
					utm_url TEXT NOT NULL,
					copy_payload LONGTEXT NOT NULL,
					targeting_payload LONGTEXT NOT NULL,
					budget_payload LONGTEXT NOT NULL,
					schedule_payload LONGTEXT NOT NULL,
					placements_payload LONGTEXT NOT NULL,
					status VARCHAR(24) NOT NULL DEFAULT 'draft',
					meta_campaign_id VARCHAR(64) NULL,
					meta_ids LONGTEXT NULL,
					error_message TEXT NULL,
					created_by BIGINT UNSIGNED NOT NULL,
					created_at DATETIME NOT NULL,
					updated_at DATETIME NOT NULL,
					PRIMARY KEY (id),
					KEY event_plan_id (event_plan_id),
					KEY venue_id (venue_id),
					KEY status (status),
					KEY created_at (created_at)
				) $charset",
				"CREATE TABLE " . $wpdb->prefix . "vms_meta_ads_tiers (
					id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
					build_id BIGINT UNSIGNED NOT NULL,
					tier_key VARCHAR(16) NOT NULL,
					tier_label VARCHAR(64) NOT NULL,
					start_time DATETIME NOT NULL,
					end_time DATETIME NOT NULL,
					budget_type VARCHAR(16) NOT NULL DEFAULT 'lifetime',
					budget_amount_minor BIGINT UNSIGNED NOT NULL,
					meta_adset_id VARCHAR(64) NULL,
					meta_creative_id VARCHAR(64) NULL,
					meta_ad_id VARCHAR(64) NULL,
					meta_status VARCHAR(16) NULL,
					last_error TEXT NULL,
					created_at DATETIME NOT NULL,
					updated_at DATETIME NOT NULL,
					PRIMARY KEY (id),
					KEY build_id (build_id),
					KEY tier_key (tier_key)
				) $charset",
				"CREATE TABLE " . $wpdb->prefix . "vms_meta_ads_audit (
					id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
					build_id BIGINT UNSIGNED NULL,
					tier_id BIGINT UNSIGNED NULL,
					actor_user_id BIGINT UNSIGNED NOT NULL,
					action_key VARCHAR(64) NOT NULL,
					payload_redacted LONGTEXT NULL,
					created_at DATETIME NOT NULL,
					PRIMARY KEY (id),
					KEY build_id (build_id),
					KEY action_key (action_key),
					KEY created_at (created_at)
				) $charset",
				"CREATE TABLE " . $wpdb->prefix . "vms_marketing_post_assets (
					id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
					platform VARCHAR(24) NOT NULL,
					venue_id BIGINT UNSIGNED NULL,
					event_plan_id BIGINT UNSIGNED NULL,
					post_id VARCHAR(128) NOT NULL,
					permalink TEXT NULL,
					copy_used LONGTEXT NULL,
					media_asset_id BIGINT UNSIGNED NULL,
					created_by BIGINT UNSIGNED NOT NULL,
					created_at DATETIME NOT NULL,
					PRIMARY KEY (id),
					KEY platform (platform),
					KEY venue_id (venue_id),
					KEY event_plan_id (event_plan_id),
					KEY created_at (created_at)
				) $charset",
				"CREATE TABLE " . $wpdb->prefix . "vms_meta_ads_analytics_snapshots (
					id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
					cache_key VARCHAR(191) NOT NULL,
					event_plan_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
					build_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
					object_level VARCHAR(16) NOT NULL DEFAULT 'campaign',
					object_id VARCHAR(64) NOT NULL,
					range_key VARCHAR(24) NOT NULL DEFAULT 'last_7',
					scope_key VARCHAR(32) NOT NULL DEFAULT 'builder_bundle',
					payload LONGTEXT NOT NULL,
					fetched_at DATETIME NOT NULL,
					created_at DATETIME NOT NULL,
					updated_at DATETIME NOT NULL,
					PRIMARY KEY (id),
					UNIQUE KEY cache_key (cache_key),
					KEY event_plan_id (event_plan_id),
					KEY build_id (build_id),
					KEY fetched_at (fetched_at)
				) $charset",
			);

			foreach ($statements as $statement) {
				dbDelta($statement);
			}

			update_option('vms_ma_db_version', VMS_Meta_Ads::DB_VERSION, false);
		}

		public static function get_version(): string
		{
			return (string) get_option('vms_ma_db_version', '0');
		}
	}
}
