<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Event_Plans_Service')) {
	class VMS_Meta_Ads_Event_Plans_Service {
		private static $last_trace = array();

		public static function list_event_plans(array $args = array()): array
		{
			$started_at = microtime(true);
			$query_count_start = function_exists('get_num_queries') ? (int) get_num_queries() : 0;
			$context = sanitize_key((string) ($args['context'] ?? 'collection'));
			$today = wp_date('Y-m-d', null, wp_timezone());
			$after = self::normalize_ymd((string) ($args['after'] ?? ''));
			if ($after === '') {
				$after = $today;
			}
			$days = absint($args['days'] ?? 90);
			if ($days < 1) {
				$days = 90;
			}
			$days = min($days, 365);
			$limit = absint($args['limit'] ?? 30);
			if ($limit < 1) {
				$limit = 30;
			}
			$limit = min($limit, 100);
			$q = sanitize_text_field((string) ($args['q'] ?? ''));
			$venue_id = absint($args['venue_id'] ?? 0);
			$statuses = self::normalize_status_filters((array) ($args['statuses'] ?? array('published', 'ready')));
			$query_limit = self::resolve_query_limit($limit, $q !== '', $venue_id > 0);

			$to = wp_date('Y-m-d', strtotime($after . ' +' . $days . ' days'), wp_timezone());
			$query_args = array(
				'post_type' => 'vms_event_plan',
				'post_status' => array('publish', 'draft', 'pending', 'future', 'private'),
				'posts_per_page' => $query_limit,
				'fields' => 'ids',
				'orderby' => 'meta_value',
				'order' => 'ASC',
				'meta_key' => '_vms_event_date',
				'suppress_filters' => false,
				'meta_query' => array(
					array(
						'key' => '_vms_event_date',
						'value' => array($after, $to),
						'compare' => 'BETWEEN',
						'type' => 'DATE',
					),
				),
			);
			if ($q !== '') {
				$query_args['s'] = $q;
			}
			if ($venue_id > 0) {
				$query_args['meta_query'][] = array(
					'key' => '_vms_venue_id',
					'value' => $venue_id,
					'compare' => '=',
					'type' => 'NUMERIC',
				);
			}

			$rows = get_posts($query_args);
			$items = array();
			foreach ($rows as $plan_id) {
				$item = self::build_item((int) $plan_id);
				if (!$item) {
					continue;
				}
				if (!empty($statuses) && !in_array($item['event_plan_status'], $statuses, true)) {
					continue;
				}
				$items[] = $item;
			}

			if (!empty($args['group_meta_activity_last'])) {
				usort($items, array(__CLASS__, 'compare_picker_priority'));
			}

			if (count($items) > $limit) {
				$items = array_slice($items, 0, $limit);
			}

			self::record_trace(array(
				'context' => $context !== '' ? $context : 'collection',
				'location_mode' => 'read_only',
				'requested_limit' => $limit,
				'query_limit' => $query_limit,
				'rows_fetched' => count($rows),
				'items_returned' => count($items),
				'elapsed_ms' => round((microtime(true) - $started_at) * 1000, 1),
				'query_count' => function_exists('get_num_queries') ? max(0, ((int) get_num_queries()) - $query_count_start) : 0,
			));

			return $items;
		}

		public static function get_event_plan(int $event_plan_id): ?array
		{
			$started_at = microtime(true);
			$query_count_start = function_exists('get_num_queries') ? (int) get_num_queries() : 0;
			$item = self::build_item($event_plan_id);
			self::record_trace(array(
				'context' => 'single_item',
				'location_mode' => 'read_only',
				'event_plan_id' => $event_plan_id,
				'items_returned' => $item ? 1 : 0,
				'elapsed_ms' => round((microtime(true) - $started_at) * 1000, 1),
				'query_count' => function_exists('get_num_queries') ? max(0, ((int) get_num_queries()) - $query_count_start) : 0,
			));
			return $item;
		}

		public static function get_last_trace(): array
		{
			return is_array(self::$last_trace) ? self::$last_trace : array();
		}

		private static function build_item(int $event_plan_id): ?array
		{
			if ($event_plan_id < 1) {
				return null;
			}
			$post = get_post($event_plan_id);
			if (!$post || $post->post_type !== 'vms_event_plan') {
				return null;
			}
			$title = sanitize_text_field((string) $post->post_title);
			$venue_id = (int) get_post_meta($event_plan_id, '_vms_venue_id', true);
			$venue_name = $venue_id > 0 ? sanitize_text_field((string) get_the_title($venue_id)) : '';
			$start_dt = self::infer_start_datetime($event_plan_id, $post);
			$start_input = $start_dt ? $start_dt->format('Y-m-d H:i') : '';
			$date_format = (string) get_option('date_format', 'Y-m-d');
			$time_format = (string) get_option('time_format', 'g:i a');
			$start_display = $start_dt ? wp_date($date_format . ' ' . $time_format, $start_dt->getTimestamp(), wp_timezone()) : '';
			$tec_event_id = (int) get_post_meta($event_plan_id, '_vms_tec_event_id', true);
			$event_permalink = get_permalink($event_plan_id);
			if (!is_string($event_permalink)) {
				$event_permalink = '';
			}
			$ticket_url = self::resolve_ticket_url($event_plan_id, $tec_event_id, $event_permalink);
			$status = self::infer_internal_status($event_plan_id);
			$ma_last_updated = trim((string) get_post_meta($event_plan_id, 'vms_ma_last_updated_local', true));
			$ma_last_exported = trim((string) get_post_meta($event_plan_id, 'vms_ma_last_exported_local', true));
			$ma_live_local = trim((string) get_post_meta($event_plan_id, 'vms_ma_meta_last_live_local', true));
			$ma_pause_local = trim((string) get_post_meta($event_plan_id, 'vms_ma_meta_last_pause_local', true));
			$ma_meta_status = sanitize_key((string) get_post_meta($event_plan_id, 'vms_ma_meta_status', true));
			$ma_status_bucket = self::resolve_meta_ads_bucket($ma_meta_status, $ma_live_local, $ma_pause_local, $ma_last_exported, $ma_last_updated);
			$ma_status_label = self::format_meta_ads_status_label($ma_meta_status, $ma_live_local, $ma_pause_local, $ma_last_exported, $ma_last_updated);
			$location = self::resolve_location_context($event_plan_id, $venue_id, $tec_event_id);

			return array(
				'id' => $event_plan_id,
				'title' => $title,
				'start_local' => $start_input,
				'start_input' => $start_input,
				'start_display' => $start_display,
				'venue_name' => $venue_name,
				'venue_id' => $venue_id,
				'ticket_url' => $ticket_url,
				'event_permalink' => $event_permalink,
				'tec_event_id' => $tec_event_id,
				'location_label' => (string) ($location['label'] ?? ''),
				'location_address' => (string) ($location['address_string'] ?? ''),
				'location_zip' => (string) ($location['zip'] ?? ''),
				'location_targeting_anchor' => (string) ($location['targeting_anchor'] ?? ''),
				'location_has_precise_anchor' => !empty($location['has_precise_anchor']) ? 1 : 0,
				'location_country' => (string) ($location['country'] ?? 'US'),
				'location_latitude' => isset($location['latitude']) ? $location['latitude'] : null,
				'location_longitude' => isset($location['longitude']) ? $location['longitude'] : null,
				'has_ticket_url' => $ticket_url !== '',
				'event_plan_status' => $status,
				'meta_ads_status' => $ma_status_label,
				'meta_ads_state' => $ma_meta_status,
				'meta_ads_bucket' => $ma_status_bucket,
				'meta_ads_picker_label' => self::format_picker_status_label($ma_status_bucket),
				'has_meta_activity' => ($ma_status_bucket !== 'none') ? 1 : 0,
				'meta_ads_last_updated' => $ma_last_updated,
				'meta_ads_last_exported' => $ma_last_exported,
				'meta_ads_last_live' => $ma_live_local,
				'meta_ads_last_pause' => $ma_pause_local,
			);
		}

		private static function format_meta_ads_status_label(string $meta_status, string $live_local, string $pause_local, string $export_local, string $updated_local): string
		{
			if ($meta_status === 'live') {
				return $live_local !== ''
					? sprintf(__('Live since %s', 'vms-meta-ads'), $live_local)
					: __('Live', 'vms-meta-ads');
			}
			if ($meta_status === 'paused') {
				return $pause_local !== ''
					? sprintf(__('Paused %s', 'vms-meta-ads'), $pause_local)
					: __('Paused', 'vms-meta-ads');
			}
			if ($meta_status === 'paused_reviewing') {
				return __('Paused / pending review', 'vms-meta-ads');
			}
			if ($meta_status === 'partial') {
				return __('Partial/needs attention', 'vms-meta-ads');
			}
			if ($meta_status === 'error') {
				return __('Error (check status)', 'vms-meta-ads');
			}
			if ($export_local !== '') {
				return sprintf(__('Exported %s', 'vms-meta-ads'), $export_local);
			}
			if ($updated_local !== '') {
				return sprintf(__('Draft saved %s', 'vms-meta-ads'), $updated_local);
			}
			return __('No draft yet', 'vms-meta-ads');
		}


		private static function resolve_meta_ads_bucket(string $meta_status, string $live_local, string $pause_local, string $export_local, string $updated_local): string
		{
			if ($meta_status === 'live' || $live_local !== '') {
				return 'live';
			}
			if ($meta_status === 'paused' || $pause_local !== '') {
				return 'paused';
			}
			if ($meta_status === 'paused_reviewing') {
				return 'paused';
			}
			if ($meta_status === 'partial' || $meta_status === 'error') {
				return 'attention';
			}
			if ($export_local !== '' || $updated_local !== '') {
				return 'draft';
			}
			return 'none';
		}

		private static function format_picker_status_label(string $bucket): string
		{
			switch ($bucket) {
				case 'live':
					return __('Live ad', 'vms-meta-ads');
				case 'paused':
					return __('Paused ad', 'vms-meta-ads');
				case 'draft':
					return __('Draft saved', 'vms-meta-ads');
				case 'attention':
					return __('Needs attention', 'vms-meta-ads');
				default:
					return __('New', 'vms-meta-ads');
			}
		}

		private static function compare_picker_priority(array $a, array $b): int
		{
			$group_a = !empty($a['has_meta_activity']) ? 1 : 0;
			$group_b = !empty($b['has_meta_activity']) ? 1 : 0;
			if ($group_a !== $group_b) {
				return $group_a <=> $group_b;
			}

			$start_a = (string) ($a['start_local'] ?? '');
			$start_b = (string) ($b['start_local'] ?? '');
			if ($start_a !== $start_b) {
				return strcmp($start_a, $start_b);
			}

			$title_a = (string) ($a['title'] ?? '');
			$title_b = (string) ($b['title'] ?? '');
			return strcmp($title_a, $title_b);
		}

		private static function infer_internal_status(int $event_plan_id): string
		{
			$status = '';
			if (vms_ma_has_core_function('vms_event_plan_get_status')) {
				$status = sanitize_key((string) vms_ma_call_core_function('vms_event_plan_get_status', $event_plan_id, 'event_list'));
			}
			if ($status === '') {
				$status = sanitize_key((string) get_post_meta($event_plan_id, '_vms_event_plan_status', true));
			}
			return $status !== '' ? $status : 'draft';
		}

		private static function infer_start_datetime(int $event_plan_id, WP_Post $post): ?DateTimeImmutable
		{
			$date = trim((string) get_post_meta($event_plan_id, '_vms_event_date', true));
			$time = trim((string) get_post_meta($event_plan_id, '_vms_start_time', true));
			if ($date !== '') {
				$dt = self::parse_local_datetime($date . ' ' . ($time !== '' ? $time : '00:00:00'));
				if ($dt instanceof DateTimeImmutable) {
					return $dt;
				}
			}
			$fallback_keys = array('_vms_event_start', '_EventStartDate', 'event_start');
			foreach ($fallback_keys as $key) {
				$value = trim((string) get_post_meta($event_plan_id, $key, true));
				if ($value === '') {
					continue;
				}
				$dt = self::parse_meta_datetime($value);
				if ($dt instanceof DateTimeImmutable) {
					return $dt;
				}
			}
			$post_gmt = trim((string) $post->post_date_gmt);
			if ($post_gmt !== '' && $post_gmt !== '0000-00-00 00:00:00') {
				try {
					$dt = new DateTimeImmutable($post_gmt . ' UTC');
					return $dt->setTimezone(wp_timezone());
				} catch (Exception $e) {
					return null;
				}
			}
			return null;
		}

		private static function parse_local_datetime(string $raw): ?DateTimeImmutable
		{
			$raw = trim($raw);
			if ($raw === '') {
				return null;
			}
			$tz = wp_timezone();
			$formats = array(
				'Y-m-d H:i:s',
				'Y-m-d H:i',
				'Y-m-d g:i A',
				'Y-m-d g:ia',
				'Y-m-d h:i A',
				'Y-m-d h:ia',
				'Y-m-d',
			);
			foreach ($formats as $format) {
				$dt = DateTimeImmutable::createFromFormat($format, $raw, $tz);
				if ($dt instanceof DateTimeImmutable) {
					return $dt;
				}
			}
			try {
				return new DateTimeImmutable($raw, $tz);
			} catch (Exception $e) {
				return null;
			}
		}

		private static function parse_meta_datetime(string $raw): ?DateTimeImmutable
		{
			$raw = trim($raw);
			if ($raw === '') {
				return null;
			}
			$tz = wp_timezone();
			$has_explicit_tz = (bool) preg_match('/(?:Z|[+\-]\d{2}:?\d{2}| (?:UTC|GMT|[A-Z]{3,5}))$/', $raw);
			try {
				if ($has_explicit_tz) {
					$dt = new DateTimeImmutable($raw);
					return $dt->setTimezone($tz);
				}
				return new DateTimeImmutable($raw, $tz);
			} catch (Exception $e) {
				return null;
			}
		}

		private static function resolve_ticket_url(int $event_plan_id, int $tec_event_id, string $event_permalink): string
		{
			$candidate_keys = array(
				'_vms_destination_url',
				'_vms_ticket_url',
				'_vms_ticket_link',
				'_vms_event_url',
			);
			foreach ($candidate_keys as $key) {
				$meta = esc_url_raw((string) get_post_meta($event_plan_id, $key, true));
				if ($meta !== '') {
					return $meta;
				}
			}

			if ($tec_event_id > 0) {
				$tec_keys = array('_EventURL', '_EventWebsite', '_vms_tec_event_url');
				foreach ($tec_keys as $key) {
					$meta = esc_url_raw((string) get_post_meta($tec_event_id, $key, true));
					if ($meta !== '') {
						return $meta;
					}
				}
			}

			$plan_tec_url = esc_url_raw((string) get_post_meta($event_plan_id, '_vms_tec_event_url', true));
			if ($plan_tec_url !== '') {
				return $plan_tec_url;
			}

			if ($event_permalink !== '') {
				return esc_url_raw($event_permalink);
			}

			return '';
		}

		private static function resolve_location_context(int $event_plan_id, int $venue_id, int $tec_event_id): array
		{
			$context = array(
				'label' => '',
				'address_string' => '',
				'zip' => '',
				'targeting_anchor' => '',
				'has_precise_anchor' => false,
				'country' => 'US',
				'latitude' => null,
				'longitude' => null,
			);

			$venue_name = $venue_id > 0 ? sanitize_text_field((string) get_the_title($venue_id)) : '';
			$address = '';
			$city = '';
			$state = '';
			$zip = '';
			$country = '';
			$latitude = null;
			$longitude = null;

			$tec_venue_id = self::resolve_read_only_tec_venue_id($event_plan_id, $venue_id, $tec_event_id);

			if ($tec_venue_id > 0) {
				// Read raw venue meta directly to avoid Pro model-filter incompatibilities on
				// `tribe_get_venue_object(..., ARRAY_A)` while still getting deterministic
				// address and coordinate data for Meta radius targeting.
				if ($venue_name === '') {
					$venue_name = sanitize_text_field((string) get_the_title($tec_venue_id));
				}
				$address = self::first_meta_value($tec_venue_id, array('_VenueAddress', 'address', '_address'));
				$city = self::first_meta_value($tec_venue_id, array('_VenueCity', 'city', '_city'));
				$state = self::first_meta_value($tec_venue_id, array('_VenueStateProvince', '_VenueState', 'state', '_state'));
				$zip = self::first_meta_value($tec_venue_id, array('_VenueZip', 'zip', 'zipcode', 'postal_code'));
				$country = self::first_meta_value($tec_venue_id, array('_VenueCountry', 'country', '_country'));
				$latitude = self::first_numeric_meta_value($tec_venue_id, array('_VenueLat', 'latitude', 'lat', '_lat'));
				$longitude = self::first_numeric_meta_value($tec_venue_id, array('_VenueLng', 'longitude', 'lng', '_lng'));
			}

			if ($venue_id > 0) {
				$address_line_1 = self::first_meta_value($venue_id, array(
					'_vms_addr1',
					'_vms_address',
					'_vms_address_1',
					'_vms_street',
					'_vms_street_address',
					'_venue_address',
					'address_1',
					'address',
					'street_address',
					'street',
				));
				$address_line_2 = self::first_meta_value($venue_id, array(
					'_vms_addr2',
					'_vms_address_2',
					'_vms_suite',
					'address_2',
					'suite',
				));
				if ($address === '') {
					$address = self::combine_address_lines($address_line_1, $address_line_2);
				}
				if ($city === '') {
					$city = self::first_meta_value($venue_id, array('_vms_city', '_venue_city', 'city', '_city', 'town'));
				}
				if ($state === '') {
					$state = self::first_meta_value($venue_id, array('_vms_state', '_vms_state_province', '_venue_state', 'state', '_state', 'province'));
				}
				if ($zip === '') {
					$zip = self::first_meta_value($venue_id, array('_vms_zip', '_vms_zip_code', '_vms_postal_code', '_venue_zip', 'zip', 'zipcode', 'postal_code', 'postcode'));
				}
				if ($country === '') {
					$country = self::first_meta_value($venue_id, array('_vms_country', '_venue_country', 'country', '_country'));
				}
				if (!is_numeric($latitude)) {
					$latitude = self::first_numeric_meta_value($venue_id, array('_vms_lat', '_vms_latitude', 'latitude', 'lat', '_lat'));
				}
				if (!is_numeric($longitude)) {
					$longitude = self::first_numeric_meta_value($venue_id, array('_vms_lng', '_vms_longitude', 'longitude', 'lng', '_lng'));
				}
			}

			if ($address === '') {
				$address = self::combine_address_lines(
					self::first_meta_value($event_plan_id, array('_vms_addr1', '_vms_address', '_vms_location_address', 'address')),
					self::first_meta_value($event_plan_id, array('_vms_addr2', '_vms_address_2', 'address_2'))
				);
			}
			if ($city === '') {
				$city = self::first_meta_value($event_plan_id, array('_vms_city', '_vms_location_city', 'city'));
			}
			if ($state === '') {
				$state = self::first_meta_value($event_plan_id, array('_vms_state', '_vms_location_state', 'state'));
			}
			if ($zip === '') {
				$zip = self::first_meta_value($event_plan_id, array('_vms_zip', '_vms_zip_code', '_vms_location_zip', 'zip', 'postal_code'));
			}
			if ($country === '') {
				$country = self::first_meta_value($event_plan_id, array('_vms_country', '_vms_location_country', 'country'));
			}
			if (!is_numeric($latitude)) {
				$latitude = self::first_numeric_meta_value($event_plan_id, array('_vms_lat', '_vms_latitude', 'latitude', 'lat'));
			}
			if (!is_numeric($longitude)) {
				$longitude = self::first_numeric_meta_value($event_plan_id, array('_vms_lng', '_vms_longitude', 'longitude', 'lng'));
			}

			if ($tec_event_id > 0) {
				if ($address === '') {
					$address = self::combine_address_lines(
						self::first_meta_value($tec_event_id, array('_VenueAddress', '_EventVenueAddress', 'address')),
						self::first_meta_value($tec_event_id, array('_VenueAddress2', '_EventVenueAddress2', 'address_2'))
					);
				}
				if ($city === '') {
					$city = self::first_meta_value($tec_event_id, array('_VenueCity', '_EventVenueCity', 'city'));
				}
				if ($state === '') {
					$state = self::first_meta_value($tec_event_id, array('_VenueStateProvince', '_VenueState', '_EventVenueState', 'state'));
				}
				if ($zip === '') {
					$zip = self::first_meta_value($tec_event_id, array('_VenueZip', '_EventVenueZip', 'zip', 'postal_code'));
				}
				if ($country === '') {
					$country = self::first_meta_value($tec_event_id, array('_VenueCountry', '_EventVenueCountry', 'country'));
				}
			}

			$city_state = trim(implode(', ', array_values(array_filter(array($city, $state)))));
			$context['address_string'] = self::build_address_string($address, $city, $state, $zip, $country);
			$context['zip'] = $zip;
			$context['has_precise_anchor'] = ($context['address_string'] !== '' || $zip !== '' || (is_numeric($latitude) && is_numeric($longitude)));

			if ($context['address_string'] !== '') {
				$context['targeting_anchor'] = $context['address_string'];
			} elseif ($zip !== '') {
				$context['targeting_anchor'] = $zip;
			}

			if ($context['address_string'] !== '') {
				$context['label'] = $context['address_string'];
			} elseif ($city_state !== '') {
				$context['label'] = $city_state;
			} elseif ($zip !== '') {
				$context['label'] = $zip;
			} elseif ($venue_name !== '') {
				$context['label'] = $venue_name;
			} else {
				$context['label'] = __('Location not resolved yet', 'vms-meta-ads');
			}

			$normalized_country = self::normalize_country_code($country);
			if ($normalized_country !== '') {
				$context['country'] = $normalized_country;
			}
			if (is_numeric($latitude) && is_numeric($longitude)) {
				$context['latitude'] = round((float) $latitude, 6);
				$context['longitude'] = round((float) $longitude, 6);
			}

			return $context;
		}

		private static function resolve_read_only_tec_venue_id(int $event_plan_id, int $venue_id, int $tec_event_id): int
		{
			if ($venue_id > 0) {
				$meta_key = vms_ma_has_core_function('vms_venue_meta_key')
					? vms_ma_call_core_function('vms_venue_meta_key', 'tec_venue_id', '_vms_tec_venue_id')
					: (vms_ma_has_core_function('vms_meta_key') ? vms_ma_call_core_function('vms_meta_key', 'venue', 'tec_venue_id') : '_vms_tec_venue_id');
				$stored_tec_venue_id = absint(get_post_meta($venue_id, $meta_key, true));
				if ($stored_tec_venue_id > 0 && get_post_status($stored_tec_venue_id)) {
					return $stored_tec_venue_id;
				}
			}

			if ($event_plan_id > 0) {
				$stored_plan_tec_venue_id = absint(get_post_meta($event_plan_id, '_vms_tec_venue_id', true));
				if ($stored_plan_tec_venue_id > 0 && get_post_status($stored_plan_tec_venue_id)) {
					return $stored_plan_tec_venue_id;
				}
			}

			if ($tec_event_id > 0) {
				$stored_event_tec_venue_id = absint(get_post_meta($tec_event_id, '_EventVenueID', true));
				if ($stored_event_tec_venue_id > 0 && get_post_status($stored_event_tec_venue_id)) {
					return $stored_event_tec_venue_id;
				}
				if (function_exists('tribe_get_venue_id')) {
					$tribe_venue_id = absint(tribe_get_venue_id($tec_event_id));
					if ($tribe_venue_id > 0 && get_post_status($tribe_venue_id)) {
						return $tribe_venue_id;
					}
				}
			}

			return 0;
		}

		private static function resolve_query_limit(int $limit, bool $has_search, bool $has_venue_filter): int
		{
			$overscan = $has_search || $has_venue_filter ? 6 : 10;
			$multiplier = $has_search || $has_venue_filter ? 1.2 : 1.4;
			$query_limit = max($limit + $overscan, (int) ceil($limit * $multiplier));
			$query_limit = max($limit, $query_limit);
			return min($query_limit, max($limit, 90));
		}

		private static function record_trace(array $trace): void
		{
			self::$last_trace = $trace;
		}

		private static function first_meta_value(int $post_id, array $keys): string
		{
			if ($post_id < 1) {
				return '';
			}
			foreach ($keys as $key) {
				if (!is_string($key) || $key === '') {
					continue;
				}
				$value = get_post_meta($post_id, $key, true);
				if (is_array($value)) {
					$value = (string) reset($value);
				}
				$value = trim((string) $value);
				if ($value !== '') {
					return sanitize_text_field($value);
				}
			}
			return '';
		}

		private static function first_numeric_meta_value(int $post_id, array $keys)
		{
			if ($post_id < 1) {
				return null;
			}
			foreach ($keys as $key) {
				if (!is_string($key) || $key === '') {
					continue;
				}
				$value = get_post_meta($post_id, $key, true);
				if (is_array($value)) {
					$value = reset($value);
				}
				if ($value === '' || $value === null) {
					continue;
				}
				if (is_numeric($value)) {
					return (float) $value;
				}
			}
			return null;
		}

		private static function combine_address_lines(string $line_1, string $line_2): string
		{
			$line_1 = trim($line_1);
			$line_2 = trim($line_2);
			if ($line_1 === '') {
				return $line_2;
			}
			if ($line_2 === '') {
				return $line_1;
			}
			return $line_1 . ', ' . $line_2;
		}

		private static function build_address_string(string $address, string $city, string $state, string $zip, string $country): string
		{
			$parts = array();
			$address = trim($address);
			$city = trim($city);
			$state = trim($state);
			$zip = trim($zip);
			$country = trim($country);
			if ($address !== '') {
				$parts[] = $address;
			}
			$city_state_zip = trim(implode(', ', array_values(array_filter(array($city, $state)))));
			if ($city_state_zip !== '' && $zip !== '') {
				$city_state_zip .= ' ' . $zip;
			} elseif ($city_state_zip === '' && $zip !== '') {
				$city_state_zip = $zip;
			}
			if ($city_state_zip !== '') {
				$parts[] = $city_state_zip;
			}
			$normalized_country = self::normalize_country_code($country);
			if ($normalized_country !== '' && $normalized_country !== 'US') {
				$parts[] = $country;
			}
			$parts = array_values(array_unique(array_filter(array_map('trim', $parts))));
			return implode(', ', $parts);
		}

		private static function normalize_country_code(string $country): string
		{
			$country = strtoupper(trim($country));
			if ($country === '' || $country === 'UNITED STATES' || $country === 'USA') {
				return 'US';
			}
			if (strlen($country) === 2) {
				return $country;
			}
			return '';
		}

		private static function normalize_ymd(string $value): string
		{
			$value = trim($value);
			if ($value === '') {
				return '';
			}
			if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
				return '';
			}
			$ts = strtotime($value . ' 00:00:00');
			if ($ts === false) {
				return '';
			}
			return wp_date('Y-m-d', $ts, wp_timezone());
		}

		private static function normalize_status_filters(array $statuses): array
		{
			if (empty($statuses)) {
				$statuses = array('published', 'ready');
			}
			$out = array();
			foreach ($statuses as $status) {
				$key = sanitize_key((string) $status);
				if ($key === '') {
					continue;
				}
				$out[$key] = true;
			}
			return array_keys($out);
		}
	}
}
