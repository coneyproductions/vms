<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Performance_Health_Service')) {
	class VMS_Meta_Ads_Performance_Health_Service {
		private const STATE_OPTION = 'vms_ma_performance_health_state';
		private const NOTICE_OPTION = 'vms_ma_performance_health_notices';
		private const ALERT_COOLDOWN = 43200; // 12 hours.

		public static function boot(): void
		{
			add_action('admin_notices', array(__CLASS__, 'render_admin_notices'));
		}

		public static function enrich_promotable_items(array $items): array
		{
			$cohort_rows = array();

			foreach ($items as $index => $item) {
				$item = is_array($item) ? $item : array();
				$show_performance = self::should_show_performance($item);
				$snapshot = $show_performance
					? VMS_Meta_Ads_Performance_Service::get_event_plan_snapshot((int) ($item['id'] ?? 0), array('preset' => 'last_7'))
					: self::empty_snapshot();

				$item['performance_snapshot'] = $snapshot;
				$item['performance_health'] = self::empty_health();
				$items[$index] = $item;

				if (!$show_performance || !self::snapshot_has_meaningful_metrics($snapshot)) {
					continue;
				}

				$too_new = self::is_too_new($item, $snapshot);
				$metrics = is_array($snapshot['metrics'] ?? null) ? (array) $snapshot['metrics'] : array();
				$ctr = max(0.0, (float) ($metrics['link_ctr'] ?? 0));
				$clicks = max(0, (int) ($metrics['link_clicks'] ?? 0));
				$cpc = ($clicks > 0) ? ((float) ($metrics['spend'] ?? 0) / $clicks) : INF;
				if (!$too_new && $ctr > 0) {
					$cohort_rows[] = array(
						'ctr' => $ctr,
						'cpc' => $cpc,
					);
				}
			}

			$cohort_ctr = self::average(array_map(static function (array $row): float {
				return (float) ($row['ctr'] ?? 0);
			}, $cohort_rows));
			$cohort_cpc = self::average(array_values(array_filter(array_map(static function (array $row) {
				$value = $row['cpc'] ?? INF;
				return is_finite($value) ? (float) $value : null;
			}, $cohort_rows), static function ($value): bool {
				return $value !== null && $value > 0;
			})));

			foreach ($items as $index => $item) {
				$item = is_array($item) ? $item : array();
				$item['performance_health'] = self::calculate_health(
					$item,
					is_array($item['performance_snapshot'] ?? null) ? (array) $item['performance_snapshot'] : self::empty_snapshot(),
					$cohort_ctr,
					$cohort_cpc
				);
				$items[$index] = $item;
			}

			return $items;
		}

		public static function count_levels(array $items): array
		{
			$counts = array(
				'too_new' => 0,
				'healthy' => 0,
				'watch' => 0,
				'underperforming' => 0,
				'critical' => 0,
			);

			foreach ($items as $item) {
				$health = is_array($item['performance_health'] ?? null) ? (array) $item['performance_health'] : array();
				$slug = sanitize_key((string) ($health['slug'] ?? ''));
				if ($slug !== '' && isset($counts[$slug])) {
					$counts[$slug]++;
				}
			}

			return $counts;
		}

		public static function maybe_send_alerts(array $items): void
		{
			$state = get_option(self::STATE_OPTION, array());
			$notices = get_option(self::NOTICE_OPTION, array());
			if (!is_array($state)) {
				$state = array();
			}
			if (!is_array($notices)) {
				$notices = array();
			}

			foreach ($items as $item) {
				$item = is_array($item) ? $item : array();
				$health = is_array($item['performance_health'] ?? null) ? (array) $item['performance_health'] : array();
				if (empty($health['alertable'])) {
					continue;
				}
				$key = self::state_key($item);
				if ($key === '') {
					continue;
				}

				$metrics = is_array($health['metrics'] ?? null) ? (array) $health['metrics'] : array();
				$digest = md5(wp_json_encode(array(
					'slug' => (string) ($health['slug'] ?? ''),
					'message' => (string) ($health['message'] ?? ''),
					'spend' => round((float) ($metrics['spend'] ?? 0), 2),
					'clicks' => (int) ($metrics['link_clicks'] ?? 0),
					'impressions' => (int) ($metrics['impressions'] ?? 0),
					'ctr' => round((float) ($metrics['link_ctr'] ?? 0), 2),
				)));

				$previous = is_array($state[$key] ?? null) ? (array) $state[$key] : array();
				$previous_slug = sanitize_key((string) ($previous['slug'] ?? ''));
				$previous_digest = (string) ($previous['digest'] ?? '');
				$last_sent = absint($previous['sent_at'] ?? 0);
				$state[$key] = array(
					'slug' => (string) ($health['slug'] ?? ''),
					'digest' => $digest,
					'sent_at' => $last_sent,
				);

				$should_send = false;
				if ($previous_slug !== (string) ($health['slug'] ?? '')) {
					$should_send = true;
				} elseif ($previous_digest !== $digest && (time() - $last_sent) >= self::ALERT_COOLDOWN) {
					$should_send = true;
				}

				if (!$should_send) {
					continue;
				}

				if (self::send_alert_email($item, $health)) {
					$state[$key]['sent_at'] = time();
					$notices[$key] = array(
						'severity' => ('critical' === ($health['slug'] ?? '')) ? 'error' : 'warning',
						'title' => (string) ($item['title'] ?? __('Meta ad alert', 'vms-meta-ads')),
						'message' => (string) ($health['message'] ?? ''),
					);
				}
			}

			update_option(self::STATE_OPTION, $state, false);
			update_option(self::NOTICE_OPTION, $notices, false);
		}

		public static function render_admin_notices(): void
		{
			if (!is_admin() || !current_user_can('manage_options')) {
				return;
			}
			$page = isset($_GET['page']) ? sanitize_key((string) $_GET['page']) : '';
			if ($page === '' || strpos($page, 'vms-ma-') !== 0) {
				return;
			}
			$notices = get_option(self::NOTICE_OPTION, array());
			if (empty($notices) || !is_array($notices)) {
				return;
			}
			foreach ($notices as $notice) {
				$severity = sanitize_key((string) ($notice['severity'] ?? 'warning'));
				if (!in_array($severity, array('warning', 'error', 'success', 'info'), true)) {
					$severity = 'warning';
				}
				$title = (string) ($notice['title'] ?? __('Meta ad alert', 'vms-meta-ads'));
				$message = (string) ($notice['message'] ?? '');
				echo '<div class="notice notice-' . esc_attr($severity) . ' vms-ma-notice"><p><strong>' . esc_html($title) . '</strong>: ' . esc_html($message) . '</p></div>';
			}
			delete_option(self::NOTICE_OPTION);
		}

		private static function calculate_health(array $item, array $snapshot, float $cohort_ctr, float $cohort_cpc): array
		{
			if (!self::should_show_performance($item)) {
				return self::empty_health();
			}
			if (!empty($snapshot['error'])) {
				return array(
					'slug' => 'watch',
					'label' => __('Watch', 'vms-meta-ads'),
					'class' => 'is-watch',
					'message' => __('Performance data needs attention before this ad can be judged.', 'vms-meta-ads'),
					'alertable' => false,
					'metrics' => self::empty_metrics(),
				);
			}
			if (!self::snapshot_has_meaningful_metrics($snapshot)) {
				return array(
					'slug' => 'too_new',
					'label' => __('Too New', 'vms-meta-ads'),
					'class' => 'is-too-new',
					'message' => __('Needs more delivery before it can be judged.', 'vms-meta-ads'),
					'alertable' => false,
					'metrics' => is_array($snapshot['metrics'] ?? null) ? (array) $snapshot['metrics'] : self::empty_metrics(),
				);
			}

			$metrics = is_array($snapshot['metrics'] ?? null) ? (array) $snapshot['metrics'] : self::empty_metrics();
			$spend = max(0.0, (float) ($metrics['spend'] ?? 0));
			$clicks = max(0, (int) ($metrics['link_clicks'] ?? 0));
			$impressions = max(0, (int) ($metrics['impressions'] ?? 0));
			$ctr = max(0.0, (float) ($metrics['link_ctr'] ?? 0));
			$cpc = ($clicks > 0) ? ($spend / $clicks) : INF;
			$too_new = self::is_too_new($item, $snapshot);

			if ($too_new) {
				return array(
					'slug' => 'too_new',
					'label' => __('Too New', 'vms-meta-ads'),
					'class' => 'is-too-new',
					'message' => __('Needs more delivery before it can be judged.', 'vms-meta-ads'),
					'alertable' => false,
					'metrics' => $metrics,
				);
			}

			$score = 0;
			$reasons = array();

			if ($cohort_ctr > 0) {
				$ctr_ratio = ($cohort_ctr > 0) ? ($ctr / $cohort_ctr) : 1.0;
				if ($ctr_ratio < 0.70) {
					$score += 2;
					$reasons[] = sprintf(__('CTR is %s below similar live ads', 'vms-meta-ads'), self::format_delta_pct(1 - $ctr_ratio));
				} elseif ($ctr_ratio < 0.85) {
					$score += 1;
					$reasons[] = sprintf(__('CTR is %s below similar live ads', 'vms-meta-ads'), self::format_delta_pct(1 - $ctr_ratio));
				}
			} else {
				if ($ctr < 1.00) {
					$score += 2;
					$reasons[] = __('CTR is weak for a traffic ad', 'vms-meta-ads');
				} elseif ($ctr < 1.50) {
					$score += 1;
					$reasons[] = __('CTR is slightly behind target', 'vms-meta-ads');
				}
			}

			if (is_finite($cpc) && $cohort_cpc > 0) {
				$cpc_ratio = $cpc / $cohort_cpc;
				if ($cpc_ratio > 1.50) {
					$score += 2;
					$reasons[] = sprintf(__('Cost per click is %s worse than similar live ads', 'vms-meta-ads'), self::format_delta_pct($cpc_ratio - 1));
				} elseif ($cpc_ratio > 1.20) {
					$score += 1;
					$reasons[] = sprintf(__('Cost per click is %s worse than similar live ads', 'vms-meta-ads'), self::format_delta_pct($cpc_ratio - 1));
				}
			} elseif ($spend >= 10 && $clicks === 0) {
				$score += 3;
				$reasons[] = __('Spend is happening without generating clicks', 'vms-meta-ads');
			} elseif (is_finite($cpc)) {
				if ($cpc > 2.25) {
					$score += 2;
					$reasons[] = __('Cost per click is high', 'vms-meta-ads');
				} elseif ($cpc > 1.50) {
					$score += 1;
					$reasons[] = __('Cost per click is slightly high', 'vms-meta-ads');
				}
			}

			if ($spend >= 15 && $clicks <= 3) {
				$score += 1;
				$reasons[] = __('Spend is outpacing click volume', 'vms-meta-ads');
			}
			if ($impressions >= 2000 && $ctr < 1.00) {
				$score += 1;
				$reasons[] = __('Large impression volume is not converting into clicks', 'vms-meta-ads');
			}

			$slug = 'healthy';
			$label = __('Healthy', 'vms-meta-ads');
			$class = 'is-healthy';
			if ($score >= 4) {
				$slug = 'critical';
				$label = __('Critical', 'vms-meta-ads');
				$class = 'is-critical';
			} elseif ($score >= 2) {
				$slug = 'underperforming';
				$label = __('Underperforming', 'vms-meta-ads');
				$class = 'is-underperforming';
			} elseif ($score === 1) {
				$slug = 'watch';
				$label = __('Watch', 'vms-meta-ads');
				$class = 'is-watch';
			}

			$message = ($slug === 'healthy')
				? __('Running in line with similar live ads.', 'vms-meta-ads')
				: implode(' • ', array_slice(array_values(array_unique($reasons)), 0, 2));

			return array(
				'slug' => $slug,
				'label' => $label,
				'class' => $class,
				'message' => $message,
				'alertable' => self::is_alertable_state($item, $slug),
				'metrics' => $metrics,
			);
		}

		private static function is_alertable_state(array $item, string $slug): bool
		{
			$bucket = sanitize_key((string) ($item['meta_ads_bucket'] ?? $item['meta_ads_state'] ?? ''));
			return in_array($slug, array('underperforming', 'critical'), true) && in_array($bucket, array('live', 'attention'), true);
		}

		private static function should_show_performance(array $item): bool
		{
			$bucket = sanitize_key((string) ($item['meta_ads_bucket'] ?? $item['meta_ads_state'] ?? ''));
			return in_array($bucket, array('live', 'paused', 'attention'), true);
		}

		private static function snapshot_has_meaningful_metrics(array $snapshot): bool
		{
			$metrics = is_array($snapshot['metrics'] ?? null) ? (array) $snapshot['metrics'] : array();
			return !empty($snapshot['ok']) && empty($snapshot['error']) && ((int) ($metrics['impressions'] ?? 0) > 0 || (float) ($metrics['spend'] ?? 0) > 0);
		}

		private static function is_too_new(array $item, array $snapshot): bool
		{
			$metrics = is_array($snapshot['metrics'] ?? null) ? (array) $snapshot['metrics'] : array();
			$spend = max(0.0, (float) ($metrics['spend'] ?? 0));
			$impressions = max(0, (int) ($metrics['impressions'] ?? 0));
			$live_ts = self::parse_datetime_to_timestamp((string) ($item['meta_ads_last_live'] ?? ''));
			if ($live_ts < 1) {
				$live_ts = self::parse_datetime_to_timestamp((string) (($snapshot['build']['created_at'] ?? '')));
			}
			if ($live_ts > 0 && (time() - $live_ts) < DAY_IN_SECONDS) {
				return true;
			}
			if ($impressions < 500) {
				return true;
			}
			if ($spend < 5) {
				return true;
			}
			return false;
		}

		private static function parse_datetime_to_timestamp(string $value): int
		{
			$value = trim($value);
			if ($value === '') {
				return 0;
			}
			if (ctype_digit($value)) {
				return (int) $value;
			}
			$formats = array('Y-m-d H:i:s', 'Y-m-d H:i', DATE_ATOM, DATE_RFC3339);
			$timezone = wp_timezone();
			foreach ($formats as $format) {
				$dt = DateTimeImmutable::createFromFormat($format, $value, $timezone);
				if ($dt instanceof DateTimeImmutable) {
					return $dt->getTimestamp();
				}
			}
			$ts = strtotime($value);
			return $ts ? (int) $ts : 0;
		}

		private static function send_alert_email(array $item, array $health): bool
		{
			$emails = apply_filters('vms_ma_performance_alert_emails', array_filter(array(get_option('admin_email'))), $item, $health);
			if (empty($emails)) {
				return false;
			}
			$emails = array_values(array_unique(array_filter(array_map('sanitize_email', $emails))));
			if (empty($emails)) {
				return false;
			}

			$metrics = is_array($health['metrics'] ?? null) ? (array) $health['metrics'] : self::empty_metrics();
			$title = (string) ($item['title'] ?? __('Untitled event', 'vms-meta-ads'));
			$subject = sprintf(
				/* translators: 1: health label, 2: event title */
				__('[VMS Meta Ads] %1$s: %2$s', 'vms-meta-ads'),
				$health['label'] ?? __('Alert', 'vms-meta-ads'),
				$title
			);
			$lines = array(
				sprintf(__('Event: %s', 'vms-meta-ads'), $title),
				sprintf(__('Health: %s', 'vms-meta-ads'), (string) ($health['label'] ?? '')),
				sprintf(__('Reason: %s', 'vms-meta-ads'), (string) ($health['message'] ?? '')),
				'',
				__('Last 7 Days', 'vms-meta-ads'),
				sprintf(__('Spend: $%s', 'vms-meta-ads'), number_format_i18n((float) ($metrics['spend'] ?? 0), 2)),
				sprintf(__('Link Clicks: %s', 'vms-meta-ads'), number_format_i18n((int) ($metrics['link_clicks'] ?? 0))),
				sprintf(__('CTR: %s%%', 'vms-meta-ads'), number_format_i18n((float) ($metrics['link_ctr'] ?? 0), 2)),
				sprintf(__('Impressions: %s', 'vms-meta-ads'), number_format_i18n((int) ($metrics['impressions'] ?? 0))),
			);
			if (!empty($item['ticket_url'])) {
				$lines[] = '';
				$lines[] = sprintf(__('Open event: %s', 'vms-meta-ads'), esc_url_raw((string) $item['ticket_url']));
			}
			return wp_mail($emails, $subject, implode("\n", $lines));
		}

		private static function state_key(array $item): string
		{
			$id = absint($item['id'] ?? 0);
			if ($id > 0) {
				return 'event_' . $id;
			}
			$title = sanitize_key((string) ($item['title'] ?? ''));
			return ($title !== '') ? ('title_' . $title) : '';
		}

		private static function average(array $values): float
		{
			$values = array_values(array_filter(array_map(static function ($value): float {
				return (float) $value;
			}, $values), static function (float $value): bool {
				return $value > 0;
			}));
			if (empty($values)) {
				return 0.0;
			}
			return array_sum($values) / count($values);
		}

		private static function format_delta_pct(float $value): string
		{
			return number_format_i18n(max(0.0, $value) * 100, 0) . '%';
		}

		private static function empty_snapshot(): array
		{
			return array(
				'ok' => false,
				'empty' => true,
				'error' => '',
				'metrics' => self::empty_metrics(),
				'series' => array(),
				'build' => array(),
			);
		}

		private static function empty_metrics(): array
		{
			return array(
				'spend' => 0,
				'impressions' => 0,
				'link_clicks' => 0,
				'link_ctr' => 0,
			);
		}

		private static function empty_health(): array
		{
			return array(
				'slug' => '',
				'label' => '',
				'class' => '',
				'message' => '',
				'alertable' => false,
				'metrics' => self::empty_metrics(),
			);
		}
	}
}
