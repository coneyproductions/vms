<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Logger')) {
	class VMS_Meta_Ads_Logger {
		public static function log(string $action_key, array $context = array(), ?int $build_id = null, ?int $tier_id = null): void
		{
			$sanitized = self::sanitize_context($context);
			if (!empty($context['error'])) {
				error_log('[VMS MA] ' . $action_key . ': ' . wp_json_encode($sanitized));
			}

			global $wpdb;
			$wpdb->insert(
				$wpdb->prefix . 'vms_meta_ads_audit',
				array(
					'build_id' => $build_id,
					'tier_id' => $tier_id,
					'actor_user_id' => get_current_user_id(),
					'action_key' => $action_key,
					'payload_redacted' => wp_json_encode($sanitized),
					'created_at' => current_time('mysql', true),
				),
				array('%d', '%d', '%d', '%s', '%s', '%s')
			);
		}

		private static function sanitize_context(array $context): array
		{
			$filtered = $context;
			$tokens = array('access_token', 'token', 'refresh_token');
			foreach ($tokens as $token) {
				if (isset($filtered[$token])) {
					$filtered[$token] = 'REDACTED';
				}
			}
			if (isset($filtered['payload']) && is_array($filtered['payload'])) {
				$filtered['payload'] = '[REDACTED]';
			}
			return $filtered;
		}
	}
}

if (!function_exists('vms_ma_log')) {
	function vms_ma_log(string $action_key, array $context = array(), ?int $build_id = null, ?int $tier_id = null): void
	{
		VMS_Meta_Ads_Logger::log($action_key, $context, $build_id, $tier_id);
	}
}
