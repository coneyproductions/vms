<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Builds_Service')) {
	class VMS_Meta_Ads_Builds_Service {
		private const STATUS_ALLOWED = array('draft', 'exported', 'meta_created_paused', 'live', 'ended', 'error', 'archived');
		private const MODE_ALLOWED = array('simple', 'autoramp');
		private const CREATIVE_ALLOWED = array('dark_post', 'boost_post', 'fb_event');
		private const GOAL_ALLOWED = array('traffic', 'sales', 'engagement', 'leads', 'messages', 'event_responses');

		public static function get_build(int $id)
		{
			$db_ready = self::ensure_db_ready();
			if (is_wp_error($db_ready)) {
				return $db_ready;
			}

			global $wpdb;
			$build = $wpdb->get_row(
				$wpdb->prepare('SELECT * FROM ' . $wpdb->prefix . 'vms_meta_ads_builds WHERE id = %d', $id),
				ARRAY_A
			);
			if (!$build) {
				return new WP_Error('not_found', __('Build not found.', 'vms-meta-ads'), array('status' => 404));
			}
			$tiers = $wpdb->get_results(
				$wpdb->prepare('SELECT * FROM ' . $wpdb->prefix . 'vms_meta_ads_tiers WHERE build_id = %d ORDER BY start_time ASC', $id),
				ARRAY_A
			);
			return self::hydrate_build($build, $tiers);
		}

		public static function list_builds(array $filters): array
		{
			$db_ready = self::ensure_db_ready();
			if (is_wp_error($db_ready)) {
				return array();
			}

			global $wpdb;
			$where = array('1=1');
			$params = array();

			if (!empty($filters['event_plan_id'])) {
				$where[] = 'event_plan_id = %d';
				$params[] = absint($filters['event_plan_id']);
			}
			if (!empty($filters['venue_id'])) {
				$where[] = 'venue_id = %d';
				$params[] = absint($filters['venue_id']);
			}
			if (!empty($filters['status']) && in_array($filters['status'], self::STATUS_ALLOWED, true)) {
				$where[] = 'status = %s';
				$params[] = $filters['status'];
			} elseif (empty($filters['include_archived'])) {
				$where[] = 'status <> %s';
				$params[] = 'archived';
			}
			$limit = max(1, min(100, absint($filters['limit'] ?? 20)));

			$sql = 'SELECT * FROM ' . $wpdb->prefix . "vms_meta_ads_builds WHERE " . implode(' AND ', $where) . " ORDER BY CASE WHEN created_at IS NULL OR created_at = '0000-00-00 00:00:00' THEN 1 ELSE 0 END ASC, created_at DESC, id DESC LIMIT %d";
			$params[] = $limit;
			$rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
			if (!$rows) {
				return array();
			}

			$ids = wp_list_pluck($rows, 'id');
			$in = implode(',', array_fill(0, count($ids), '%d'));
			$tiers = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . $wpdb->prefix . 'vms_meta_ads_tiers WHERE build_id IN (' . $in . ') ORDER BY start_time ASC', $ids), ARRAY_A);
			$tiers_by_build = array();
			foreach ($tiers as $tier) {
				$build_id = (int) $tier['build_id'];
				if (!isset($tiers_by_build[$build_id])) {
					$tiers_by_build[$build_id] = array();
				}
				$tiers_by_build[$build_id][] = $tier;
			}

			$items = array();
			foreach ($rows as $row) {
				$build_id = (int) $row['id'];
				$items[] = self::hydrate_build($row, $tiers_by_build[$build_id] ?? array());
			}
			return $items;
		}

		public static function save_build(array $input)
		{
			$db_ready = self::ensure_db_ready();
			if (is_wp_error($db_ready)) {
				return $db_ready;
			}

			$normalized = self::normalize_input($input);
			if (is_wp_error($normalized)) {
				return $normalized;
			}

			$payloads = self::build_payloads($normalized);
			if (is_wp_error($payloads)) {
				return $payloads;
			}

			global $wpdb;
			$table = $wpdb->prefix . 'vms_meta_ads_builds';
			$now = current_time('mysql', true);
			$build_id = absint($input['id'] ?? 0);
			$is_update = $build_id > 0;
			$existing = null;
			$preserve_meta_link = false;
			$preserved_status = 'draft';

			if ($is_update) {
				$existing = self::get_build($build_id);
				if (is_wp_error($existing)) {
					return $existing;
				}
				$preserve_meta_link = self::build_has_meta_link((array) $existing);
				if ($preserve_meta_link) {
					$preserved_status = self::preserve_meta_status((array) $existing);
				}
			}

			$row = array(
				'event_plan_id' => $normalized['event_plan_id'] ?: null,
				'venue_id' => $normalized['venue_id'] ?: null,
				'source_type' => $normalized['source_type'],
				'source_ref' => $normalized['source_ref'],
				'mode' => $normalized['mode'],
				'goal' => $normalized['goal'],
				'objective_meta' => $normalized['objective_meta'],
				'creative_mode' => $normalized['creative_mode'],
				'post_asset_id' => $normalized['post_asset_id'] ?: null,
				'destination_url' => $normalized['destination_url'],
				'utm_url' => $payloads['utm_url'],
				'copy_payload' => wp_json_encode($payloads['copy_payload']),
				'targeting_payload' => wp_json_encode($payloads['targeting_payload']),
				'budget_payload' => wp_json_encode($payloads['budget_payload']),
				'schedule_payload' => wp_json_encode($payloads['schedule_payload']),
				'placements_payload' => wp_json_encode($payloads['placements_payload']),
				'status' => $preserve_meta_link ? $preserved_status : 'draft',
				'updated_at' => $now,
			);

			$formats = array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s');

			if ($is_update) {
				$updated = $wpdb->update($table, $row, array('id' => $build_id), $formats, array('%d'));
				if ($updated === false) {
					return new WP_Error('db_update_failed', __('Unable to update build.', 'vms-meta-ads'));
				}
				vms_ma_log('build_updated', array('build_id' => $build_id), $build_id);
			} else {
				$row['created_by'] = get_current_user_id();
				$row['created_at'] = $now;
				$formats[] = '%d';
				$formats[] = '%s';
				$inserted = $wpdb->insert($table, $row, $formats);
				if ($inserted === false) {
					$detail = trim((string) $wpdb->last_error);
					$message = __('Unable to create build.', 'vms-meta-ads');
					if ($detail !== '') {
						$message .= ' ' . sprintf(__('Database error: %s', 'vms-meta-ads'), $detail);
					}
					return new WP_Error('db_insert_failed', $message);
				}
				$build_id = (int) $wpdb->insert_id;
				vms_ma_log('build_created', array('build_id' => $build_id), $build_id);
			}

			$tier_result = self::replace_tiers($build_id, $payloads['tiers']);
			if (is_wp_error($tier_result)) {
				return $tier_result;
			}
			if ($preserve_meta_link && is_array($existing)) {
				self::restore_meta_ids_to_first_tier($build_id, (array) $existing, $preserved_status, $now);
			}
			self::sync_event_plan_meta($normalized, $payloads, $build_id);
			if (class_exists('VMS_Meta_Ads_Prefill_Service')) {
				VMS_Meta_Ads_Prefill_Service::flush_prefill_cache((int) ($normalized['event_plan_id'] ?? 0));
			}

			return self::get_build($build_id);
		}

		public static function duplicate_build_as_fresh_draft(int $build_id)
		{
			$build = self::get_build($build_id);
			if (is_wp_error($build)) {
				return $build;
			}

			$input = self::build_to_save_input((array) $build);
			$input['id'] = 0;

			$result = self::save_build($input);
			if (is_wp_error($result)) {
				return $result;
			}

			vms_ma_log('build_duplicated_as_fresh_draft', array(
				'source_build_id' => $build_id,
				'new_build_id' => (int) ($result['id'] ?? 0),
			), (int) ($result['id'] ?? 0));

			return $result;
		}

		public static function archive_build(int $build_id)
		{
			$build = self::get_build($build_id);
			if (is_wp_error($build)) {
				return $build;
			}
			if (sanitize_key((string) ($build['status'] ?? '')) === 'archived') {
				return $build;
			}

			global $wpdb;
			$updated = $wpdb->update(
				$wpdb->prefix . 'vms_meta_ads_builds',
				array(
					'status' => 'archived',
					'updated_at' => current_time('mysql', true),
				),
				array('id' => $build_id),
				array('%s', '%s'),
				array('%d')
			);
			if ($updated === false) {
				return new WP_Error('db_archive_failed', __('Unable to archive build.', 'vms-meta-ads'));
			}

			if (class_exists('VMS_Meta_Ads_Prefill_Service')) {
				VMS_Meta_Ads_Prefill_Service::flush_prefill_cache((int) ($build['event_plan_id'] ?? 0));
			}
			vms_ma_log('build_archived', array('build_id' => $build_id), $build_id);

			return self::get_build($build_id);
		}

		public static function export_copy_pack(int $build_id)
		{
			$build = self::get_build($build_id);
			if (is_wp_error($build)) {
				return $build;
			}

			global $wpdb;
			$updated = $wpdb->update(
				$wpdb->prefix . 'vms_meta_ads_builds',
				array('status' => 'exported', 'updated_at' => current_time('mysql', true)),
				array('id' => $build_id),
				array('%s', '%s'),
				array('%d')
			);
			if ($updated === false) {
				return new WP_Error('db_export_failed', __('Unable to mark build exported.', 'vms-meta-ads'));
			}

			vms_ma_log('export_generated', array('build_id' => $build_id), $build_id);
			$build['status'] = 'exported';
			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			if ($event_plan_id > 0) {
				update_post_meta($event_plan_id, 'vms_ma_last_exported_local', wp_date('Y-m-d H:i:s', null, wp_timezone()));
			}
			return array(
				'build' => $build,
				'copy_pack' => $build['copy_payload'],
			);
		}

		private static function hydrate_build(array $build, array $tiers): array
		{
			$json_fields = array('copy_payload', 'targeting_payload', 'budget_payload', 'schedule_payload', 'placements_payload', 'meta_ids');
			foreach ($json_fields as $field) {
				$build[$field] = !empty($build[$field]) ? json_decode((string) $build[$field], true) : array();
				if (!is_array($build[$field])) {
					$build[$field] = array();
				}
			}
			$build['created_at'] = self::normalize_mysql_datetime_for_display((string) ($build['created_at'] ?? ''), (int) ($build['id'] ?? 0));
			$build['updated_at'] = self::normalize_mysql_datetime_for_display((string) ($build['updated_at'] ?? ''), (int) ($build['id'] ?? 0));
			$build['id'] = (int) $build['id'];
			$build['event_plan_id'] = (int) $build['event_plan_id'];
			$build['venue_id'] = (int) $build['venue_id'];
			$build['post_asset_id'] = (int) $build['post_asset_id'];
			$build['created_by'] = (int) $build['created_by'];
			$build['tiers'] = array_map(static function (array $tier): array {
				$tier['id'] = (int) $tier['id'];
				$tier['build_id'] = (int) $tier['build_id'];
				$tier['budget_amount_minor'] = (int) $tier['budget_amount_minor'];
				return $tier;
			}, $tiers);
			return $build;
		}

		private static function build_to_save_input(array $build): array
		{
			$copy = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
			$targeting = is_array($build['targeting_payload'] ?? null) ? (array) $build['targeting_payload'] : array();
			$budget = is_array($build['budget_payload'] ?? null) ? (array) $build['budget_payload'] : array();
			$schedule = is_array($build['schedule_payload'] ?? null) ? (array) $build['schedule_payload'] : array();
			$placements = is_array($build['placements_payload'] ?? null) ? (array) $build['placements_payload'] : array();
			$meta_controls = is_array($placements['meta_controls'] ?? null) ? (array) $placements['meta_controls'] : array();
			$recipe_payload = is_array($copy['campaign_recipe_payload'] ?? null) ? (array) $copy['campaign_recipe_payload'] : array();

			$tier_budgets = array();
			foreach ((array) ($build['tiers'] ?? array()) as $tier) {
				if (!is_array($tier)) {
					continue;
				}
				$key = sanitize_key((string) ($tier['tier_key'] ?? ''));
				if ($key === '') {
					continue;
				}
				$tier_budgets[$key] = max(0, absint($tier['budget_amount_minor'] ?? 0));
			}

			return array(
				'event_plan_id' => (int) ($build['event_plan_id'] ?? 0),
				'venue_id' => (int) ($build['venue_id'] ?? 0),
				'source_type' => sanitize_key((string) ($build['source_type'] ?? 'event_plan')),
				'source_ref' => sanitize_text_field((string) ($build['source_ref'] ?? '')),
				'mode' => sanitize_key((string) ($build['mode'] ?? 'autoramp')),
				'goal' => sanitize_key((string) ($build['goal'] ?? 'traffic')),
				'objective_meta' => sanitize_text_field((string) ($build['objective_meta'] ?? '')),
				'creative_mode' => sanitize_key((string) ($build['creative_mode'] ?? 'dark_post')),
				'post_asset_id' => absint($build['post_asset_id'] ?? 0),
				'destination_url' => esc_url_raw((string) ($build['destination_url'] ?? '')),
				'event_start' => sanitize_text_field((string) ($schedule['event_start'] ?? '')),
				'radius_miles' => max(1, absint($targeting['radius_miles'] ?? 15)),
				'age_min' => max(13, absint($targeting['age_min'] ?? 21)),
				'age_max' => max(13, absint($targeting['age_max'] ?? 65)),
				'gender' => sanitize_key((string) ($targeting['gender'] ?? 'all')),
				'interests' => implode(',', array_values(array_filter(array_map('sanitize_text_field', (array) ($targeting['interests'] ?? array()))))),
				'audience_targeting' => is_array($targeting['audience_targeting'] ?? null) ? (array) $targeting['audience_targeting'] : array(),
				'placements_mode' => ((string) ($placements['mode'] ?? 'automatic') === 'manual') ? 'manual' : 'automatic',
				'total_budget_minor' => max(0, absint($budget['total_budget_minor'] ?? 0)),
				'recipe_adset_state' => self::sanitize_recipe_adset_state(
					is_array($budget['recipe_adset_state'] ?? null)
						? (array) $budget['recipe_adset_state']
						: self::recipe_payload_to_state($recipe_payload),
					max(0, absint($budget['total_budget_minor'] ?? 0))
				),
				'auto_sync_budget_enabled' => !empty($budget['auto_sync_budget_enabled']) ? 1 : 0,
				'event_name' => sanitize_text_field((string) ($build['event_name'] ?? '')),
				'venue_name' => sanitize_text_field((string) ($build['venue_name'] ?? '')),
				'strategy_template' => sanitize_key((string) ($copy['strategy_template'] ?? 'custom')),
				'campaign_recipe' => sanitize_key((string) ($copy['campaign_recipe'] ?? '')),
				'include_right_column_support' => !empty($copy['include_right_column_support']) ? 1 : 0,
				'include_outer_towns_adset' => array_key_exists('include_outer_towns_adset', $copy) ? (!empty($copy['include_outer_towns_adset']) ? 1 : 0) : 1,
				'video_format' => sanitize_key((string) ($copy['video_format'] ?? 'unknown')),
				'require_vertical_video' => !empty($copy['require_vertical_video']) ? 1 : 0,
				'force_buy_tickets_cta' => !empty($copy['force_buy_tickets_cta']) ? 1 : 0,
				'creative_automation_policy' => sanitize_key((string) ($copy['creative_automation_policy'] ?? ($meta_controls['creative_automation_policy'] ?? 'off'))),
				'multi_advertiser_ads' => !empty($copy['multi_advertiser_ads']) || !empty($meta_controls['multi_advertiser_ads']) ? 1 : 0,
				'targeting_address' => sanitize_text_field((string) ($targeting['targeting_address'] ?? '')),
				'tier_budgets' => $tier_budgets,
				'preset_mode' => sanitize_key((string) ($schedule['preset_mode'] ?? 'flat_run')),
				'optimization' => sanitize_key((string) ($copy['optimization'] ?? (($build['goal'] ?? '') === 'sales' ? 'purchase_conversions' : 'link_clicks'))),
				'end_buffer_hours' => max(0, absint($schedule['end_buffer_hours'] ?? 2)),
				'manual_start' => sanitize_text_field((string) ($schedule['manual_start'] ?? '')),
				'manual_end' => sanitize_text_field((string) ($schedule['manual_end'] ?? '')),
				'primary_text' => sanitize_textarea_field((string) ($copy['primary_text_variants'][0] ?? '')),
				'headline' => sanitize_text_field((string) ($copy['headline_variants'][0] ?? '')),
				'description' => sanitize_text_field((string) ($copy['description_variants'][0] ?? '')),
				'ad_variants' => is_array($copy['ad_variants'] ?? null) ? (array) $copy['ad_variants'] : array(),
				'cta_type' => sanitize_text_field((string) ($copy['cta_type'] ?? ($copy['cta_suggestion'] ?? 'LEARN_MORE'))),
				'locations' => sanitize_textarea_field((string) ($targeting['locations'] ?? '')),
				'outer_towns_locations' => sanitize_textarea_field((string) ($targeting['outer_towns_locations'] ?? '')),
				'outer_towns_mode' => sanitize_key((string) ($targeting['outer_towns_mode'] ?? 'listed_only')),
				'outer_towns_default_radius' => max(1, absint($targeting['outer_towns_default_radius'] ?? 15)),
				'placements' => !empty($placements['placements']) && is_array($placements['placements']) ? array_values($placements['placements']) : array(),
				'image_square_id' => absint($copy['image_square_id'] ?? ($copy['creative_assets']['image_square_id'] ?? 0)),
				'image_vertical_id' => absint($copy['image_vertical_id'] ?? ($copy['creative_assets']['image_vertical_id'] ?? 0)),
				'image_wide_id' => absint($copy['image_wide_id'] ?? ($copy['creative_assets']['image_wide_id'] ?? 0)),
				'fb_event_id' => sanitize_text_field((string) ($copy['fb_event_id'] ?? '')),
			);
		}


		private static function normalize_input(array $input)
		{
			$mode = in_array($input['mode'] ?? '', self::MODE_ALLOWED, true) ? $input['mode'] : 'autoramp';
			$creative_mode = in_array($input['creative_mode'] ?? '', self::CREATIVE_ALLOWED, true) ? $input['creative_mode'] : 'dark_post';
			$goal = in_array($input['goal'] ?? '', self::GOAL_ALLOWED, true) ? $input['goal'] : 'traffic';
			$objective = self::objective_for_goal($goal, sanitize_text_field((string) ($input['objective_meta'] ?? '')));
			$source_type = sanitize_key((string) ($input['source_type'] ?? 'event_plan'));
			$source_ref = sanitize_text_field((string) ($input['source_ref'] ?? ''));
			$event_plan_id = absint($input['event_plan_id'] ?? 0);
			$venue_id = absint($input['venue_id'] ?? 0);
			$post_asset_id = absint($input['post_asset_id'] ?? 0);
			$destination_url = esc_url_raw((string) ($input['destination_url'] ?? ''));

			if (!$destination_url || !wp_http_validate_url($destination_url)) {
				return new WP_Error('invalid_destination_url', __('A valid destination URL is required.', 'vms-meta-ads'), array('status' => 400));
			}

			$event_start = sanitize_text_field((string) ($input['event_start'] ?? ''));
			if ($event_start === '') {
				$event_start = self::infer_event_start($event_plan_id);
			}
			if ($event_start === '') {
				return new WP_Error('missing_event_start', __('Event start is required to calculate schedule tiers.', 'vms-meta-ads'), array('status' => 400));
			}

			$settings = VMS_Meta_Ads_Utils::get_settings();
			$max_radius = max(1, absint($settings['max_radius_miles'] ?? 100));
			$radius = max(1, min($max_radius, absint($input['radius_miles'] ?? 15)));
			$age_min = max(13, absint($input['age_min'] ?? 21));
			$age_max = max($age_min, absint($input['age_max'] ?? 65));
			$gender = sanitize_key((string) ($input['gender'] ?? 'all'));
			if (!in_array($gender, array('all', 'women', 'men'), true)) {
				$gender = 'all';
			}
			$interests_raw = sanitize_text_field((string) ($input['interests'] ?? ''));
			$interests = array_values(array_filter(array_map('trim', explode(',', $interests_raw))));
			$audience_targeting = array();
			if (class_exists('VMS_Meta_Ads_Audience_Targeting_Service')) {
				$audience_targeting_raw = is_array($input['audience_targeting'] ?? null) ? (array) $input['audience_targeting'] : array();
				$audience_targeting = VMS_Meta_Ads_Audience_Targeting_Service::normalize_state($audience_targeting_raw, array(
					'gender' => $gender,
				));
				if (empty($audience_targeting_raw) && !empty($interests)) {
					$audience_targeting = VMS_Meta_Ads_Audience_Targeting_Service::build_state_from_legacy($interests, $gender);
				}
				$gender = (string) ($audience_targeting['gender'] ?? $gender);
				$interests = VMS_Meta_Ads_Audience_Targeting_Service::interest_ids_for_meta($audience_targeting);
			}
			$placements_mode = ($input['placements_mode'] ?? 'automatic') === 'manual' ? 'manual' : 'automatic';
			$targeting_address = sanitize_text_field((string) ($input['targeting_address'] ?? ''));
			if ($targeting_address === '') {
				$targeting_address = self::infer_targeting_address($event_plan_id, $venue_id);
			}
			$locations = sanitize_textarea_field((string) ($input['locations'] ?? ''));
			$outer_towns_locations = sanitize_textarea_field((string) ($input['outer_towns_locations'] ?? ''));
			$outer_towns_default_radius = max(1, min(250, absint($input['outer_towns_default_radius'] ?? 15)));
			$outer_towns_mode = sanitize_key((string) ($input['outer_towns_mode'] ?? 'listed_only'));
			if (!in_array($outer_towns_mode, array('listed_only', 'expanded_radius'), true)) {
				$outer_towns_mode = 'listed_only';
			}
			$placements = array();
			if (!empty($input['placements']) && is_array($input['placements'])) {
				$placements = array_values(array_filter(array_map('sanitize_key', $input['placements'])));
			}
			$allowed_cta = array('LEARN_MORE', 'GET_OFFER', 'SIGN_UP', 'BOOK_NOW', 'CONTACT_US', 'GET_TICKETS', 'BUY_TICKETS');
			$cta_candidate = strtoupper(sanitize_key((string) ($input['cta_type'] ?? '')));
			if ($cta_candidate === 'BUY_NOW') {
				$cta_candidate = 'LEARN_MORE';
			}
			$force_buy_tickets_cta = !empty($input['force_buy_tickets_cta']) ? 1 : 0;
			$cta_type = in_array($cta_candidate, $allowed_cta, true) ? $cta_candidate : 'LEARN_MORE';
			if ($force_buy_tickets_cta) {
				$cta_type = 'BUY_TICKETS';
			}
			$image_square_id = absint($input['image_square_id'] ?? 0);
			$image_vertical_id = absint($input['image_vertical_id'] ?? 0);
			$image_wide_id = absint($input['image_wide_id'] ?? 0);

			$total_budget_minor = absint($input['total_budget_minor'] ?? 0);
			if ($total_budget_minor < 1) {
				return new WP_Error('invalid_budget', __('Total budget must be greater than zero.', 'vms-meta-ads'), array('status' => 400));
			}
			$recipe_adset_state = self::sanitize_recipe_adset_state($input['recipe_adset_state'] ?? array(), $total_budget_minor);

			$max_lifetime = max(1, absint($settings['budget_max_lifetime_minor']));
			if ($total_budget_minor > $max_lifetime) {
				$max_lifetime_dollars = number_format_i18n($max_lifetime / 100, 2);
				return new WP_Error(
					'budget_over_max',
					sprintf(__('Total budget exceeds clamp of $%s.', 'vms-meta-ads'), $max_lifetime_dollars),
					array('status' => 400)
				);
			}

			$event_name = sanitize_text_field((string) ($input['event_name'] ?? self::infer_event_name($event_plan_id)));
			$venue_name = sanitize_text_field((string) ($input['venue_name'] ?? self::infer_venue_name($venue_id)));
			$preset_mode = sanitize_key((string) ($input['preset_mode'] ?? 'flat_run'));
			if (!in_array($preset_mode, array('flat_run', 'video_tribute_push', 'promo_bundle_30_14_7', 'simple_7_day', 'simple_14_day', 'simple_30_day', 'manual_dates'), true)) {
				$preset_mode = 'flat_run';
			}
			$optimization = sanitize_key((string) ($input['optimization'] ?? 'link_clicks'));
			if (!in_array($optimization, array('link_clicks', 'landing_page_views', 'purchase_conversions'), true)) {
				$optimization = 'link_clicks';
			}
			if ($goal === 'sales') {
				$optimization = 'purchase_conversions';
			} elseif ($optimization === 'purchase_conversions') {
				$optimization = 'landing_page_views';
			}

			$strategy_template = sanitize_key((string) ($input['strategy_template'] ?? 'custom'));
			if (!in_array($strategy_template, array('custom', 'direct_create_safe_ticket_push', 'clean_room_full_push', 'clean_room_full_push_v2', 'ticketed_video_local', 'standard_ticket_push', 'last_minute_push', 'low_budget_reminder'), true)) {
				$strategy_template = 'custom';
			}
			$campaign_recipe = sanitize_key((string) ($input['campaign_recipe'] ?? ''));
			if ($strategy_template === 'clean_room_full_push_v2') {
				$campaign_recipe = 'clean_room_full_push_v2';
			} elseif ($strategy_template === 'clean_room_full_push') {
				$campaign_recipe = 'clean_room_full_push';
			}
			if (!in_array($campaign_recipe, array('clean_room_full_push', 'clean_room_full_push_v2'), true)) {
				$campaign_recipe = '';
			}
			$include_right_column_support = !empty($input['include_right_column_support']) || $campaign_recipe === 'clean_room_full_push' ? 1 : 0;
			$include_outer_towns_adset = array_key_exists('include_outer_towns_adset', $input)
				? (!empty($input['include_outer_towns_adset']) ? 1 : 0)
				: 1;
			$video_format = sanitize_key((string) ($input['video_format'] ?? 'unknown'));
			if (!in_array($video_format, array('unknown', 'tall_9_16', 'square_1_1', 'wide_16_9', 'meta_direct_vertical'), true)) {
				$video_format = 'unknown';
			}
			$require_vertical_video = !empty($input['require_vertical_video']) ? 1 : 0;

			$creative_automation_policy = sanitize_key((string) ($input['creative_automation_policy'] ?? 'off'));
			if (!in_array($creative_automation_policy, array('off', 'conservative', 'meta_optimized'), true)) {
				$creative_automation_policy = 'off';
			}
			$multi_advertiser_ads = !empty($input['multi_advertiser_ads']) ? 1 : 0;

			$primary_text = sanitize_textarea_field((string) ($input['primary_text'] ?? ''));
			$headline = sanitize_text_field((string) ($input['headline'] ?? ''));
			$description = sanitize_text_field((string) ($input['description'] ?? ''));
			$ad_variants = self::sanitize_ad_variants($input['ad_variants'] ?? array(), $primary_text, $headline, $description);

			if ($primary_text === '' && !empty($ad_variants[0]['primary_text'])) {
				$primary_text = (string) $ad_variants[0]['primary_text'];
			}
			if ($headline === '' && !empty($ad_variants[0]['headline'])) {
				$headline = (string) $ad_variants[0]['headline'];
			}
			if ($description === '' && !empty($ad_variants[0]['description'])) {
				$description = (string) $ad_variants[0]['description'];
			}

			if ($campaign_recipe !== '' && $include_outer_towns_adset && $outer_towns_mode === 'listed_only') {
				if (trim($outer_towns_locations) === '') {
					return new WP_Error(
						'outer_towns_locations_required',
						__('Outer Towns listed-only mode requires at least one city/state, ZIP, or full address in Step D.', 'vms-meta-ads'),
						array('status' => 400)
					);
				}
				$outer_rows_validation = self::validate_location_rows_text($outer_towns_locations, $outer_towns_default_radius, __('Outer Towns', 'vms-meta-ads'));
				if (is_wp_error($outer_rows_validation)) {
					return $outer_rows_validation;
				}
			}

			return array(
				'event_plan_id' => $event_plan_id,
				'venue_id' => $venue_id,
				'source_type' => $source_type,
				'source_ref' => $source_ref,
				'mode' => $mode,
				'goal' => $goal,
				'objective_meta' => $objective,
				'creative_mode' => $creative_mode,
				'post_asset_id' => $post_asset_id,
				'destination_url' => $destination_url,
				'event_start' => $event_start,
				'radius_miles' => $radius,
				'age_min' => $age_min,
				'age_max' => $age_max,
				'gender' => $gender,
				'interests' => $interests,
				'audience_targeting' => $audience_targeting,
				'placements_mode' => $placements_mode,
				'total_budget_minor' => $total_budget_minor,
				'recipe_adset_state' => $recipe_adset_state,
				'auto_sync_budget_enabled' => !empty($input['auto_sync_budget_enabled']) ? 1 : 0,
				'event_name' => $event_name,
				'venue_name' => $venue_name,
				'strategy_template' => $strategy_template,
				'campaign_recipe' => $campaign_recipe,
				'include_right_column_support' => $include_right_column_support,
				'include_outer_towns_adset' => $include_outer_towns_adset,
				'video_format' => $video_format,
				'require_vertical_video' => $require_vertical_video,
				'force_buy_tickets_cta' => $force_buy_tickets_cta,
				'creative_automation_policy' => $creative_automation_policy,
				'multi_advertiser_ads' => $multi_advertiser_ads,
				'targeting_address' => $targeting_address,
				'tier_budgets' => is_array($input['tier_budgets'] ?? null) ? $input['tier_budgets'] : array(),
				'preset_mode' => $preset_mode,
				'optimization' => $optimization,
				'end_buffer_hours' => max(0, absint($input['end_buffer_hours'] ?? 2)),
				'manual_start' => sanitize_text_field((string) ($input['manual_start'] ?? '')),
				'manual_end' => sanitize_text_field((string) ($input['manual_end'] ?? '')),
				'primary_text' => $primary_text,
				'headline' => $headline,
				'description' => $description,
				'ad_variants' => $ad_variants,
				'cta_type' => $cta_type,
				'locations' => $locations,
				'outer_towns_locations' => $outer_towns_locations,
				'outer_towns_mode' => $outer_towns_mode,
				'outer_towns_default_radius' => $outer_towns_default_radius,
				'placements' => $placements,
				'image_square_id' => $image_square_id,
				'image_vertical_id' => $image_vertical_id,
				'image_wide_id' => $image_wide_id,
				'fb_event_id' => sanitize_text_field((string) ($input['fb_event_id'] ?? '')),
			);
		}


		private static function objective_for_goal(string $goal, string $candidate = ''): string
		{
			$goal = sanitize_key($goal);
			$candidate = sanitize_text_field($candidate);
			if ($goal === 'sales') {
				return 'OUTCOME_SALES';
			}
			if ($goal === 'engagement') {
				return 'OUTCOME_ENGAGEMENT';
			}
			if ($goal === 'leads') {
				return 'OUTCOME_LEADS';
			}
			if ($candidate !== '') {
				return $candidate;
			}
			return 'OUTCOME_TRAFFIC';
		}

		private static function sanitize_ad_variants($raw, string $fallback_primary = '', string $fallback_headline = '', string $fallback_description = ''): array
		{
			$variants = array();
			if (is_array($raw)) {
				foreach (array_values($raw) as $index => $row) {
					if ($index >= 3) {
						break;
					}
					$row = is_array($row) ? $row : array();
					$primary_text = sanitize_textarea_field((string) ($row['primary_text'] ?? ''));
					$headline = sanitize_text_field((string) ($row['headline'] ?? ''));
					$description = sanitize_text_field((string) ($row['description'] ?? ''));
					$label = sanitize_text_field((string) ($row['label'] ?? ('Variant ' . ($index + 1))));
					$media_mode = sanitize_key((string) ($row['media_mode'] ?? 'shared'));
					if (!in_array($media_mode, array('shared', 'image', 'video', 'video_placeholder'), true)) {
						$media_mode = 'shared';
					}
					$placement_slot = sanitize_key((string) ($row['placement_slot'] ?? 'auto'));
					if (!in_array($placement_slot, array('auto', 'feed_square_video', 'reels_stories_video'), true)) {
						$placement_slot = 'auto';
					}
					$media_image_id = absint($row['media_image_id'] ?? 0);
					$media_video_id = absint($row['media_video_id'] ?? 0);
					if ($media_mode === 'image' && $media_image_id < 1) {
						$media_mode = 'shared';
					}
					if ($media_mode === 'video' && $media_video_id < 1) {
						$media_mode = 'shared';
					}
					if ($media_mode !== 'image') {
						$media_image_id = 0;
					}
					if ($media_mode !== 'video') {
						$media_video_id = 0;
					}
					if ($primary_text === '' && $headline === '' && $description === '' && $media_mode === 'shared') {
						continue;
					}
					$variants[] = array(
						'variant_key' => 'v' . ($index + 1),
						'label' => $label !== '' ? $label : ('Variant ' . ($index + 1)),
						'primary_text' => $primary_text,
						'headline' => $headline,
						'description' => $description,
						'media_mode' => $media_mode,
						'placement_slot' => $placement_slot,
						'media_image_id' => $media_image_id,
						'media_video_id' => $media_video_id,
					);
				}
			}

			if (empty($variants)) {
				$variants[] = array(
					'variant_key' => 'v1',
					'label' => 'Variant 1',
					'primary_text' => $fallback_primary,
					'headline' => $fallback_headline,
					'description' => $fallback_description,
					'media_mode' => 'shared',
					'placement_slot' => 'auto',
					'media_image_id' => 0,
					'media_video_id' => 0,
				);
			}

			$deduped = array();
			foreach ($variants as $variant) {
				$signature = md5(wp_json_encode(array(
					(string) ($variant['primary_text'] ?? ''),
					(string) ($variant['headline'] ?? ''),
					(string) ($variant['description'] ?? ''),
					(string) ($variant['media_mode'] ?? 'shared'),
					(string) ($variant['placement_slot'] ?? 'auto'),
					(int) ($variant['media_image_id'] ?? 0),
					(int) ($variant['media_video_id'] ?? 0),
				)));
				if (isset($deduped[$signature])) {
					continue;
				}
				$deduped[$signature] = $variant;
			}

			return array_values($deduped);
		}

		private static function allocate_recipe_budget_minor(int $total_budget_minor, array $weights_by_key): array
		{
			$total_budget_minor = max(0, $total_budget_minor);
			$weights = array();
			$total_weight = 0.0;
			foreach ($weights_by_key as $key => $weight) {
				$safe_key = sanitize_key((string) $key);
				if ($safe_key === '') {
					continue;
				}
				$safe_weight = max(0.0, (float) $weight);
				$weights[$safe_key] = $safe_weight;
				$total_weight += $safe_weight;
			}

			$allocations = array();
			foreach ($weights as $key => $weight) {
				$allocations[$key] = 0;
			}
			if ($total_budget_minor < 1 || empty($weights) || $total_weight <= 0) {
				return $allocations;
			}

			$allocated = 0;
			$keys = array_keys($weights);
			$last_index = count($keys) - 1;
			foreach ($keys as $index => $key) {
				if ($index === $last_index) {
					$allocations[$key] = max(0, $total_budget_minor - $allocated);
					continue;
				}
				$amount = (int) floor($total_budget_minor * ($weights[$key] / $total_weight));
				$allocations[$key] = $amount;
				$allocated += $amount;
			}

			return $allocations;
		}

		private static function sanitize_recipe_adset_state($raw, int $total_budget_minor = 0): array
		{
			if (!is_array($raw)) {
				return array();
			}

			$out = array();
			$explicit_total_minor = 0;
			$legacy_weights = array();
			foreach ($raw as $key => $row) {
				$safe_key = sanitize_key((string) $key);
				if ($safe_key === '' || !is_array($row)) {
					continue;
				}
				$percent = max(0, round((float) ($row['percent'] ?? ($row['allocation_percent'] ?? 0)), 2));
				$has_budget_minor = array_key_exists('budget_minor', $row) || array_key_exists('budget_amount_minor', $row);
				$budget_minor = $has_budget_minor
					? max(0, absint($row['budget_minor'] ?? $row['budget_amount_minor']))
					: null;
				$out[$safe_key] = array(
					'enabled' => array_key_exists('enabled', $row) ? (!empty($row['enabled']) ? 1 : 0) : 1,
					'percent' => $percent,
				);
				if ($budget_minor !== null) {
					$out[$safe_key]['budget_minor'] = $budget_minor;
					$explicit_total_minor += $budget_minor;
				} else {
					$legacy_weights[$safe_key] = $percent;
				}
			}

			if ($total_budget_minor > 0 && !empty($legacy_weights)) {
				$remaining_budget_minor = max(0, $total_budget_minor - $explicit_total_minor);
				$allocated_legacy = self::allocate_recipe_budget_minor($remaining_budget_minor, $legacy_weights);
				foreach ($allocated_legacy as $key => $budget_minor) {
					if (isset($out[$key])) {
						$out[$key]['budget_minor'] = $budget_minor;
					}
				}
			}

			if ($total_budget_minor > 0) {
				foreach ($out as &$row) {
					$budget_minor = max(0, absint($row['budget_minor'] ?? 0));
					$row['budget_minor'] = $budget_minor;
					$row['percent'] = round(($budget_minor / $total_budget_minor) * 100, 2);
				}
				unset($row);
			}

			return $out;
		}

		private static function recipe_payload_to_state(array $recipe_payload): array
		{
			$rows = !empty($recipe_payload['adsets']) && is_array($recipe_payload['adsets']) ? (array) $recipe_payload['adsets'] : array();
			$out = array();
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$key = sanitize_key((string) ($row['key'] ?? ''));
				if ($key === '') {
					continue;
				}
				$out[$key] = array(
					'enabled' => array_key_exists('enabled', $row) ? (!empty($row['enabled']) ? 1 : 0) : 1,
					'budget_minor' => max(0, absint($row['budget_amount_minor'] ?? ($row['budget_minor'] ?? 0))),
					'percent' => max(0, round((float) ($row['allocation_percent'] ?? ($row['percent'] ?? 0)), 2)),
				);
			}
			return $out;
		}


		private static function build_payloads(array $normalized)
		{
			$tiers_result = self::build_tiers(
				$normalized['mode'],
				$normalized['preset_mode'],
				$normalized['event_start'],
				$normalized['total_budget_minor'],
				$normalized['tier_budgets'],
				$normalized['end_buffer_hours'],
				$normalized['manual_start'],
				$normalized['manual_end']
			);
			if (is_wp_error($tiers_result)) {
				return $tiers_result;
			}

			$event_dt = new DateTimeImmutable($normalized['event_start'], wp_timezone());
			$utm_url = self::build_utm_url($normalized['destination_url'], $normalized['venue_name'], $normalized['event_name'], $event_dt);
			$copy_pack = self::build_copy_pack($normalized, $tiers_result, $utm_url, $event_dt);
			$campaign_recipe_payload = self::build_campaign_recipe_payload($normalized, $tiers_result, $event_dt);
			if (!empty($campaign_recipe_payload)) {
				$copy_pack['campaign_recipe_payload'] = $campaign_recipe_payload;
				$copy_pack['recipe_checklist'] = self::build_recipe_checklist($normalized);
			}

			return array(
				'utm_url' => $utm_url,
				'copy_payload' => $copy_pack,
				'targeting_payload' => array(
					'targeting_address' => (string) ($normalized['targeting_address'] ?? ''),
					'radius_miles' => $normalized['radius_miles'],
					'age_min' => $normalized['age_min'],
					'age_max' => $normalized['age_max'],
					'gender' => (string) ($normalized['gender'] ?? 'all'),
					'interests' => $normalized['interests'],
					'audience_targeting' => is_array($normalized['audience_targeting'] ?? null) ? (array) $normalized['audience_targeting'] : array(),
					'locations' => (string) ($normalized['locations'] ?? ''),
					'outer_towns_locations' => (string) ($normalized['outer_towns_locations'] ?? ''),
					'outer_towns_mode' => (string) ($normalized['outer_towns_mode'] ?? 'listed_only'),
					'outer_towns_default_radius' => (int) ($normalized['outer_towns_default_radius'] ?? 15),
				),
				'budget_payload' => array(
					'total_budget_minor' => $normalized['total_budget_minor'],
					'recipe_adset_state' => self::sanitize_recipe_adset_state($normalized['recipe_adset_state'] ?? array(), (int) ($normalized['total_budget_minor'] ?? 0)),
					'auto_sync_budget_enabled' => !empty($normalized['auto_sync_budget_enabled']) ? 1 : 0,
					'tiers' => array_map(static function (array $tier): array {
						return array(
							'tier_key' => $tier['tier_key'],
							'budget_type' => $tier['budget_type'],
							'budget_amount_minor' => $tier['budget_amount_minor'],
						);
					}, $tiers_result),
				),
				'schedule_payload' => array(
					'event_start' => $event_dt->format('Y-m-d H:i:s'),
					'preset_mode' => $normalized['preset_mode'],
					'end_buffer_hours' => $normalized['end_buffer_hours'],
					'manual_start' => $normalized['manual_start'],
					'manual_end' => $normalized['manual_end'],
					'tiers' => array_map(static function (array $tier): array {
						return array(
							'tier_key' => $tier['tier_key'],
							'start_time' => $tier['start_time'],
							'end_time' => $tier['end_time'],
						);
					}, $tiers_result),
				),
				'placements_payload' => array(
					'mode' => $normalized['placements_mode'],
					'placements' => !empty($normalized['placements']) && is_array($normalized['placements']) ? array_values($normalized['placements']) : array(),
					'meta_controls' => array(
						'creative_automation_policy' => (string) ($normalized['creative_automation_policy'] ?? 'off'),
						'multi_advertiser_ads' => !empty($normalized['multi_advertiser_ads']) ? 1 : 0,
					),
				),
				'tiers' => $tiers_result,
			);
		}


		private static function build_campaign_recipe_payload(array $normalized, array $tiers, DateTimeImmutable $event_dt): array
		{
			$recipe_key = sanitize_key((string) ($normalized['campaign_recipe'] ?? ''));
			if (!in_array($recipe_key, array('clean_room_full_push', 'clean_room_full_push_v2'), true)) {
				return array();
			}

			$is_v2 = $recipe_key === 'clean_room_full_push_v2';
			$include_right_column = !$is_v2 || !empty($normalized['include_right_column_support']);
			$include_outer_towns = !array_key_exists('include_outer_towns_adset', $normalized) || !empty($normalized['include_outer_towns_adset']);
			$total_budget = max(0, (int) ($normalized['total_budget_minor'] ?? 0));
			$has_feed_square_video = false;
			foreach ((array) ($normalized['ad_variants'] ?? array()) as $variant_for_slot) {
				if (!is_array($variant_for_slot)) {
					continue;
				}
				$mode = sanitize_key((string) ($variant_for_slot['media_mode'] ?? 'shared'));
				$slot = sanitize_key((string) ($variant_for_slot['placement_slot'] ?? 'auto'));
				if (in_array($mode, array('video', 'video_placeholder'), true) && $slot === 'feed_square_video') {
					$has_feed_square_video = true;
					break;
				}
			}
			$include_feed_square_video = $is_v2;
			$recipe_adset_state = self::sanitize_recipe_adset_state($normalized['recipe_adset_state'] ?? array(), $total_budget);
			if ($is_v2 && $include_feed_square_video) {
				$weights = $include_outer_towns
					? array(
						'core_feed_reels' => $include_right_column ? 40 : 45,
						'feed_square_video' => 15,
						'vertical_video_reels_stories' => 20,
						'outer_towns_50_plus' => 20,
					)
					: array(
						'core_feed_reels' => $include_right_column ? 55 : 60,
						'feed_square_video' => 20,
						'vertical_video_reels_stories' => 20,
					);
				if ($include_right_column) {
					$weights['fb_right_column_support'] = 5;
				}
			} elseif ($is_v2) {
				$weights = $include_outer_towns
					? array(
						'core_feed_reels' => $include_right_column ? 50 : 55,
						'vertical_video_reels_stories' => 25,
						'outer_towns_50_plus' => 20,
					)
					: array(
						'core_feed_reels' => $include_right_column ? 65 : 70,
						'vertical_video_reels_stories' => 30,
					);
				if ($include_right_column) {
					$weights['fb_right_column_support'] = 5;
				}
			} else {
				$weights = $include_outer_towns ? array(
					'core_feed_reels' => 50,
					'promo_video_reels' => 20,
					'outer_towns_50_plus' => 25,
					'fb_right_column' => 5,
				) : array(
					'core_feed_reels' => 65,
					'promo_video_reels' => 30,
					'fb_right_column' => 5,
				);
			}

			$base_radius = max(1, (int) ($normalized['radius_miles'] ?? 25));
			$outer_radius = max($base_radius + 15, 45);
			$outer_towns_mode = sanitize_key((string) ($normalized['outer_towns_mode'] ?? 'listed_only'));
			if (!in_array($outer_towns_mode, array('listed_only', 'expanded_radius'), true)) {
				$outer_towns_mode = 'listed_only';
			}
			$outer_locations = trim((string) ($normalized['outer_towns_locations'] ?? ''));
			$outer_listed_only = $outer_towns_mode === 'listed_only';
			$outer_user_default_radius = max(1, min(250, (int) ($normalized['outer_towns_default_radius'] ?? 15)));
			$outer_default_radius = $outer_listed_only ? $outer_user_default_radius : $outer_radius;
			$age_min = max(13, (int) ($normalized['age_min'] ?? 21));
			$age_max = max($age_min, (int) ($normalized['age_max'] ?? 65));
			$outer_age_min = $age_min;
			$outer_age_max = $age_max;

			$adsets = array(
				array(
					'key' => 'core_feed_reels',
					'label' => $is_v2 ? __('Core Radius - Feeds', 'vms-meta-ads') : __('Core Radius - Feed/Reels', 'vms-meta-ads'),
					'name' => sprintf('%s - %s - %s', (string) ($normalized['event_name'] ?? 'Event'), $is_v2 ? 'Core Radius Feeds' : 'Core Radius Feed/Reels', $event_dt->format('Y-m-d')),
					'allocation_percent' => (float) ($weights['core_feed_reels'] ?? 0),
					'recommended_allocation_percent' => (float) ($weights['core_feed_reels'] ?? 0),
					'enabled' => 1,
					'budget_amount_minor' => 0,
					'placements' => $is_v2 ? array('fb_feed', 'ig_feed') : array('fb_feed', 'ig_feed', 'fb_reels', 'ig_reels'),
					'audience' => array(
						'targeting_address' => (string) ($normalized['targeting_address'] ?? ''),
						'locations' => '',
						'radius_miles' => $base_radius,
						'age_min' => $age_min,
						'age_max' => $age_max,
					),
					'variant_mode' => $is_v2 ? 'feed_static' : 'standard',
					'creative_needed' => $is_v2 ? __('Square/feed creative only', 'vms-meta-ads') : __('Square/static plus optional video variant', 'vms-meta-ads'),
				),
			);

			if ($is_v2 && $include_feed_square_video) {
				$adsets[] = array(
					'key' => 'feed_square_video',
					'label' => __('Feed Video - Square 1:1', 'vms-meta-ads'),
					'name' => sprintf('%s - Feed Square Video - %s', (string) ($normalized['event_name'] ?? 'Event'), $event_dt->format('Y-m-d')),
					'allocation_percent' => (float) ($weights['feed_square_video'] ?? 0),
					'recommended_allocation_percent' => (float) ($weights['feed_square_video'] ?? 0),
					'enabled' => 1,
					'budget_amount_minor' => 0,
					'placements' => array('fb_feed', 'ig_feed'),
					'audience' => array(
						'targeting_address' => (string) ($normalized['targeting_address'] ?? ''),
						'locations' => '',
						'radius_miles' => $base_radius,
						'age_min' => $age_min,
						'age_max' => $age_max,
					),
					'variant_mode' => 'feed_video',
					'creative_needed' => $has_feed_square_video ? __('Square 1:1 video variant or placeholder for Feed placements', 'vms-meta-ads') : __('Auto placeholder; swap/upload square 1:1 video in Meta before publishing', 'vms-meta-ads'),
				);
			}

			$adsets[] = array(
				'key' => $is_v2 ? 'vertical_video_reels_stories' : 'promo_video_reels',
				'label' => $is_v2 ? __('Vertical Video - Reels/Stories', 'vms-meta-ads') : __('Promo Video/Reels', 'vms-meta-ads'),
				'name' => sprintf('%s - %s - %s', (string) ($normalized['event_name'] ?? 'Event'), $is_v2 ? 'Vertical Video Reels Stories' : 'Promo Video Reels', $event_dt->format('Y-m-d')),
				'allocation_percent' => (float) ($weights[$is_v2 ? 'vertical_video_reels_stories' : 'promo_video_reels'] ?? 0),
				'recommended_allocation_percent' => (float) ($weights[$is_v2 ? 'vertical_video_reels_stories' : 'promo_video_reels'] ?? 0),
				'enabled' => 1,
				'budget_amount_minor' => 0,
				'placements' => array('fb_reels', 'ig_reels', 'fb_story', 'ig_story'),
				'audience' => array(
					'targeting_address' => (string) ($normalized['targeting_address'] ?? ''),
					'locations' => '',
					'radius_miles' => $base_radius,
					'age_min' => $age_min,
					'age_max' => $age_max,
				),
				'variant_mode' => 'video_preferred',
				'creative_needed' => __('Tall 9:16 video preferred for Reels/Stories', 'vms-meta-ads'),
			);

			if ($include_outer_towns) {
				$adsets[] = array(
					'key' => 'outer_towns_50_plus',
					'label' => $is_v2 ? __('Outer Towns - Feeds', 'vms-meta-ads') : __('Outer Towns', 'vms-meta-ads'),
					'name' => sprintf('%s - %s - %s', (string) ($normalized['event_name'] ?? 'Event'), $is_v2 ? 'Outer Towns Feeds' : 'Outer Towns', $event_dt->format('Y-m-d')),
					'allocation_percent' => (float) ($weights['outer_towns_50_plus'] ?? 0),
					'recommended_allocation_percent' => (float) ($weights['outer_towns_50_plus'] ?? 0),
					'enabled' => 1,
					'budget_amount_minor' => 0,
					'placements' => $is_v2 ? array('fb_feed', 'ig_feed') : array('fb_feed', 'ig_feed', 'fb_reels', 'ig_reels'),
					'audience' => array(
						'targeting_address' => $outer_listed_only ? '' : (string) ($normalized['targeting_address'] ?? ''),
						'locations' => $outer_locations,
						'radius_miles' => $outer_default_radius,
						'age_min' => $outer_age_min,
						'age_max' => $outer_age_max,
						'outer_towns_mode' => $outer_towns_mode,
						'require_explicit_locations' => $outer_listed_only ? 1 : 0,
					),
					'variant_mode' => $is_v2 ? 'feed_static' : 'standard',
					'creative_needed' => $is_v2 ? ($outer_listed_only ? __('Square/feed creative only; listed outer towns/cities/ZIPs only', 'vms-meta-ads') : __('Square/feed creative only; expanded outer radius fallback', 'vms-meta-ads')) : __('Static or video variant', 'vms-meta-ads'),
				);
			}

			if ($include_right_column) {
				$adsets[] = array(
					'key' => $is_v2 ? 'fb_right_column_support' : 'fb_right_column',
					'label' => $is_v2 ? __('Facebook Right Column Support Test', 'vms-meta-ads') : __('Facebook Right Column', 'vms-meta-ads'),
					'name' => sprintf('%s - FB Right Column%s - %s', (string) ($normalized['event_name'] ?? 'Event'), $is_v2 ? ' Support Test' : '', $event_dt->format('Y-m-d')),
					'allocation_percent' => (float) ($weights[$is_v2 ? 'fb_right_column_support' : 'fb_right_column'] ?? 0),
					'recommended_allocation_percent' => (float) ($weights[$is_v2 ? 'fb_right_column_support' : 'fb_right_column'] ?? 0),
					'enabled' => 1,
					'budget_amount_minor' => 0,
					'placements' => array('fb_right_column'),
					'audience' => array(
						'targeting_address' => (string) ($normalized['targeting_address'] ?? ''),
						'locations' => '',
						'radius_miles' => $base_radius,
						'age_min' => $age_min,
						'age_max' => $age_max,
					),
					'variant_mode' => 'single_static',
					'creative_needed' => __('Static 1:1 image and short headline', 'vms-meta-ads'),
				);
			}

			$adsets = self::apply_recipe_adset_allocations($adsets, $total_budget, $recipe_adset_state);
			$enabled_adsets = array_values(array_filter($adsets, static function (array $adset): bool {
				return !empty($adset['enabled']) && (int) ($adset['budget_amount_minor'] ?? 0) > 0;
			}));
			$allocation_total_percent = 0.0;
			$allocated_total_minor = 0;
			foreach ($enabled_adsets as $adset) {
				if (empty($adset['enabled']) || (int) ($adset['budget_amount_minor'] ?? 0) < 1) {
					continue;
				}
				$allocated_total_minor += (int) ($adset['budget_amount_minor'] ?? 0);
				$allocation_total_percent += (float) ($adset['allocation_percent'] ?? 0);
			}
			$allocation_total_percent = round($allocation_total_percent, 2);
			$allocation_valid = !empty($enabled_adsets) && $allocated_total_minor === $total_budget;

			return array(
				'recipe_key' => $recipe_key,
				'label' => $is_v2 ? __('Clean-Room Concert Campaign - Full Push v2', 'vms-meta-ads') : __('Clean-Room Concert Campaign - Full Push', 'vms-meta-ads'),
				'build_mode' => 'multi_adset_paused',
				'include_right_column_support' => $include_right_column ? 1 : 0,
				'include_outer_towns_adset' => $include_outer_towns ? 1 : 0,
				'video_format' => (string) ($normalized['video_format'] ?? 'unknown'),
				'require_vertical_video' => !empty($normalized['require_vertical_video']) ? 1 : 0,
				'adsets' => $enabled_adsets,
				'allocation_total_percent' => $allocation_total_percent,
				'allocation_valid' => $allocation_valid ? 1 : 0,
				'enabled_adset_count' => count($enabled_adsets),
				'goal' => (string) ($normalized['goal'] ?? 'traffic'),
				'objective_meta' => self::objective_for_goal((string) ($normalized['goal'] ?? 'traffic'), (string) ($normalized['objective_meta'] ?? '')),
				'optimization' => (string) ($normalized['optimization'] ?? 'link_clicks'),
				'conversion_event' => ((string) ($normalized['goal'] ?? '') === 'sales') ? 'PURCHASE' : '',
				'guardrails' => array(
					'advantage_catalog_ads' => 'off',
					'creative_automation_policy' => (string) ($normalized['creative_automation_policy'] ?? 'off'),
					'multi_advertiser_ads' => !empty($normalized['multi_advertiser_ads']) ? 1 : 0,
					'website_highlights_manual_check' => 'confirm_off_in_meta_before_publish',
					'outer_towns_mode' => $outer_towns_mode,
					'cta_type' => (string) ($normalized['cta_type'] ?? 'BUY_TICKETS'),
					'created_status' => 'PAUSED',
				),
			);
		}

		private static function apply_recipe_adset_allocations(array $adsets, int $total_budget_minor, array $recipe_adset_state): array
		{
			$total_budget_minor = max(0, $total_budget_minor);
			$explicit_total_minor = 0;
			$missing_budget_weights = array();
			foreach ($adsets as $index => &$adset) {
				$key = sanitize_key((string) ($adset['key'] ?? ''));
				$state = is_array($recipe_adset_state[$key] ?? null) ? (array) $recipe_adset_state[$key] : array();
				if (empty($state)) {
					if ($key === 'promo_video_reels' && is_array($recipe_adset_state['vertical_video_reels_stories'] ?? null)) {
						$state = (array) $recipe_adset_state['vertical_video_reels_stories'];
					} elseif ($key === 'vertical_video_reels_stories' && is_array($recipe_adset_state['promo_video_reels'] ?? null)) {
						$state = (array) $recipe_adset_state['promo_video_reels'];
					} elseif ($key === 'fb_right_column' && is_array($recipe_adset_state['fb_right_column_support'] ?? null)) {
						$state = (array) $recipe_adset_state['fb_right_column_support'];
					} elseif ($key === 'fb_right_column_support' && is_array($recipe_adset_state['fb_right_column'] ?? null)) {
						$state = (array) $recipe_adset_state['fb_right_column'];
					}
				}
				$adset['recommended_allocation_percent'] = max(0, round((float) ($adset['recommended_allocation_percent'] ?? ($adset['allocation_percent'] ?? 0)), 2));
				$adset['enabled'] = array_key_exists('enabled', $state) ? (!empty($state['enabled']) ? 1 : 0) : 1;
				if (array_key_exists('budget_minor', $state) || array_key_exists('budget_amount_minor', $state)) {
					$adset['budget_amount_minor'] = max(0, absint($state['budget_minor'] ?? $state['budget_amount_minor']));
					$explicit_total_minor += (int) $adset['budget_amount_minor'];
				} else {
					$adset['budget_amount_minor'] = 0;
					$missing_budget_weights[$index] = max(0, (float) ($state['percent'] ?? $adset['recommended_allocation_percent']));
				}
			}
			unset($adset);

			if (!empty($missing_budget_weights) && $total_budget_minor > 0) {
				$allocated_missing = self::allocate_recipe_budget_minor(max(0, $total_budget_minor - $explicit_total_minor), $missing_budget_weights);
				foreach ($allocated_missing as $index => $budget_minor) {
					if (isset($adsets[$index])) {
						$adsets[$index]['budget_amount_minor'] = max(0, (int) $budget_minor);
					}
				}
			}

			foreach ($adsets as &$adset) {
				$budget_amount_minor = max(0, absint($adset['budget_amount_minor'] ?? 0));
				$adset['budget_amount_minor'] = $budget_amount_minor;
				$adset['allocation_percent'] = $total_budget_minor > 0
					? round(($budget_amount_minor / $total_budget_minor) * 100, 2)
					: 0.0;
			}
			unset($adset);

			return $adsets;
		}

		private static function build_recipe_checklist(array $normalized): array
		{
			$recipe_key = sanitize_key((string) ($normalized['campaign_recipe'] ?? ''));
			if (!in_array($recipe_key, array('clean_room_full_push', 'clean_room_full_push_v2'), true)) {
				return array();
			}
			$is_v2 = $recipe_key === 'clean_room_full_push_v2';
			$items = array(
				array('label' => __('VMS recipe creates a fresh campaign; no Meta duplicate settings are inherited.', 'vms-meta-ads'), 'ok' => true),
				array('label' => __('Campaign, ad sets, and ads are created paused for review.', 'vms-meta-ads'), 'ok' => true),
				array('label' => __('Advantage+ catalog ads are not requested by the builder.', 'vms-meta-ads'), 'ok' => true),
				array('label' => __('Creative automation is off unless you intentionally change it.', 'vms-meta-ads'), 'ok' => (string) ($normalized['creative_automation_policy'] ?? 'off') === 'off'),
				array('label' => __('Multi-advertiser ads are off by default.', 'vms-meta-ads'), 'ok' => empty($normalized['multi_advertiser_ads'])),
				array('label' => __('Buy Tickets CTA lock is enabled.', 'vms-meta-ads'), 'ok' => !empty($normalized['force_buy_tickets_cta'])),
				array('label' => __('Manual Meta review: confirm Website Highlights / Show Spotlights are off before publishing.', 'vms-meta-ads'), 'ok' => true),
			);
			if ($is_v2) {
				$items[] = array('label' => __('Right Column is optional and excluded from the default v2 recipe.', 'vms-meta-ads'), 'ok' => empty($normalized['include_right_column_support']));
				$items[] = array('label' => !empty($normalized['include_outer_towns_adset']) ? __('Outer Towns feed ad set is enabled and requires explicit towns when listed-only mode is selected.', 'vms-meta-ads') : __('Outer Towns feed ad set is intentionally disabled for this build.', 'vms-meta-ads'), 'ok' => true);
				$items[] = array('label' => __('Reels/Stories use a dedicated vertical-video placement group.', 'vms-meta-ads'), 'ok' => true);
				if (!empty($normalized['require_vertical_video'])) {
					$items[] = array('label' => __('Strict vertical-video check is enabled before Meta creation/update.', 'vms-meta-ads'), 'ok' => true);
				}
			}
			return $items;
		}

		private static function build_tiers(string $mode, string $preset_mode, string $event_start, int $total_budget_minor, array $tier_budgets, int $end_buffer_hours = 2, string $manual_start = '', string $manual_end = '')
		{
			$tz = wp_timezone();
			$event_dt = new DateTimeImmutable($event_start, $tz);
			$today = new DateTimeImmutable('now', $tz);
			if ($event_dt->format('Y-m-d') <= $today->format('Y-m-d')) {
				return new WP_Error('event_not_future', __('Event date must be in the future to create ads.', 'vms-meta-ads'), array('status' => 400));
			}

			$days_until = (int) $today->diff($event_dt)->format('%a');
			$tiers = array();
			$defaults = array(
				'd30' => 30,
				'd14' => 30,
				'd7' => 40,
			);
			$video_defaults = array(
				'v30' => 20,
				'v14' => 30,
				'v7' => 30,
				'v48' => 20,
			);

			$build_tier = static function (string $key, string $label, DateTimeImmutable $start, DateTimeImmutable $end, int $budget) {
				return array(
					'tier_key' => $key,
					'tier_label' => $label,
					'start_time' => $start->format('Y-m-d H:i:s'),
					'end_time' => $end->format('Y-m-d H:i:s'),
					'budget_type' => 'lifetime',
					'budget_amount_minor' => $budget,
				);
			};

			if ($preset_mode === 'manual_dates') {
				$manual_start_dt = null;
				$manual_end_dt = null;
				try {
					$manual_start_dt = $manual_start !== '' ? new DateTimeImmutable($manual_start, $tz) : null;
					$manual_end_dt = $manual_end !== '' ? new DateTimeImmutable($manual_end, $tz) : null;
				} catch (Exception $e) {
					$manual_start_dt = null;
					$manual_end_dt = null;
				}
				if (!($manual_start_dt instanceof DateTimeImmutable) || !($manual_end_dt instanceof DateTimeImmutable) || $manual_end_dt <= $manual_start_dt) {
					return new WP_Error('invalid_manual_dates', __('Manual start/end must be valid and end must be after start.', 'vms-meta-ads'), array('status' => 400));
				}
				$tiers[] = $build_tier('manual', __('Manual window', 'vms-meta-ads'), $manual_start_dt, $manual_end_dt, $total_budget_minor);
			} elseif ($preset_mode === 'flat_run') {
				$end = $event_dt->sub(new DateInterval('PT' . max(0, $end_buffer_hours) . 'H'));
				$tiers[] = $build_tier('flat_run', __('Flat run', 'vms-meta-ads'), $today, $end, $total_budget_minor);
			} elseif ($preset_mode === 'video_tribute_push') {
				$end_dt = $event_dt->sub(new DateInterval('PT' . max(0, $end_buffer_hours) . 'H'));
				$two_days_before = $event_dt->sub(new DateInterval('P2D'));
				$final_week_end = $two_days_before < $end_dt ? $two_days_before : $end_dt;
				if ($days_until > 10) {
					$budget = self::resolve_tier_budget('v30', $total_budget_minor, $video_defaults, $tier_budgets);
					$tiers[] = $build_tier('v30', __('Early Video/Main Awareness', 'vms-meta-ads'), $event_dt->sub(new DateInterval('P30D')), $event_dt->sub(new DateInterval('P15D')), $budget);
				}
				if ($days_until > 6) {
					$budget = self::resolve_tier_budget('v14', $total_budget_minor, $video_defaults, $tier_budgets);
					$tiers[] = $build_tier('v14', __('Mid-Campaign Momentum', 'vms-meta-ads'), $event_dt->sub(new DateInterval('P14D')), $event_dt->sub(new DateInterval('P8D')), $budget);
				}
				if ($final_week_end > $today) {
					$budget = self::resolve_tier_budget('v7', $total_budget_minor, $video_defaults, $tier_budgets);
					$tiers[] = $build_tier('v7', __('Final Week Video Push', 'vms-meta-ads'), $event_dt->sub(new DateInterval('P7D')), $final_week_end, $budget);
				}
				$budget = self::resolve_tier_budget('v48', $total_budget_minor, $video_defaults, $tier_budgets);
				$tiers[] = $build_tier('v48', __('Last 48 Hours', 'vms-meta-ads'), $event_dt->sub(new DateInterval('P2D')), $end_dt, $budget);
			} elseif ($preset_mode === 'simple_7_day' || $preset_mode === 'simple_14_day' || $preset_mode === 'simple_30_day') {
				$days = 7;
				if ($preset_mode === 'simple_14_day') {
					$days = 14;
				} elseif ($preset_mode === 'simple_30_day') {
					$days = 30;
				}
				$start = $event_dt->sub(new DateInterval('P' . $days . 'D'));
				$end = $event_dt->sub(new DateInterval('PT' . max(0, $end_buffer_hours) . 'H'));
				if ($start < $today) {
					$start = $today;
				}
				$tiers[] = $build_tier('simple_' . $days, sprintf(__('Simple %dd', 'vms-meta-ads'), $days), $start, $end, $total_budget_minor);
			} elseif ($mode === 'simple') {
				$start = $today;
				$end = $event_dt->sub(new DateInterval('PT' . max(0, $end_buffer_hours) . 'H'));
				$tiers[] = $build_tier('promo', __('Promo', 'vms-meta-ads'), $start, $end, $total_budget_minor);
			} else {
				$end_dt = $event_dt->sub(new DateInterval('PT' . max(0, $end_buffer_hours) . 'H'));
				if ($days_until > 10) {
					$budget = self::resolve_tier_budget('d30', $total_budget_minor, $defaults, $tier_budgets);
					$tiers[] = $build_tier('d30', __('30d Awareness', 'vms-meta-ads'), $event_dt->sub(new DateInterval('P30D')), $event_dt->sub(new DateInterval('P15D')), $budget);
				}
				if ($days_until > 6) {
					$budget = self::resolve_tier_budget('d14', $total_budget_minor, $defaults, $tier_budgets);
					$tiers[] = $build_tier('d14', __('14d Intent', 'vms-meta-ads'), $event_dt->sub(new DateInterval('P14D')), $event_dt->sub(new DateInterval('P8D')), $budget);
				}
				$budget = self::resolve_tier_budget('d7', $total_budget_minor, $defaults, $tier_budgets);
				$tiers[] = $build_tier('d7', __('7d Urgency', 'vms-meta-ads'), $event_dt->sub(new DateInterval('P7D')), $end_dt, $budget);
			}

			if (empty($tiers)) {
				return new WP_Error('no_tiers', __('No valid tiers were produced from the selected event date.', 'vms-meta-ads'), array('status' => 400));
			}
			$tiers = array_values(array_filter($tiers, static function (array $tier) use ($today): bool {
				try {
					$start = new DateTimeImmutable($tier['start_time'], wp_timezone());
					$end = new DateTimeImmutable($tier['end_time'], wp_timezone());
				} catch (Exception $e) {
					return false;
				}
				if ($end <= $start) {
					return false;
				}
				return $end > $today;
			}));
			$tiers = array_values(array_map(static function (array $tier) use ($today): array {
				try {
					$start = new DateTimeImmutable($tier['start_time'], wp_timezone());
				} catch (Exception $e) {
					return $tier;
				}
				if ($start < $today) {
					$tier['start_time'] = $today->format('Y-m-d H:i:s');
				}
				return $tier;
			}, $tiers));

			$settings = VMS_Meta_Ads_Utils::get_settings();
			$max_lifetime = absint($settings['budget_max_lifetime_minor']);
			$total_tier_budget = 0;
			foreach ($tiers as $tier) {
				if ($tier['budget_amount_minor'] < 1) {
					return new WP_Error('tier_budget_invalid', __('Each tier budget must be greater than zero.', 'vms-meta-ads'), array('status' => 400));
				}
				if ($tier['budget_amount_minor'] > $max_lifetime) {
					return new WP_Error('tier_budget_over_max', __('A tier budget exceeds the configured lifetime clamp.', 'vms-meta-ads'), array('status' => 400));
				}
				$total_tier_budget += (int) $tier['budget_amount_minor'];
			}

			if ($total_tier_budget !== $total_budget_minor) {
				$delta = $total_budget_minor - $total_tier_budget;
				$last = count($tiers) - 1;
				$tiers[$last]['budget_amount_minor'] += $delta;
			}

			return $tiers;
		}

		private static function resolve_tier_budget(string $key, int $total_budget_minor, array $defaults, array $tier_budgets): int
		{
			if (isset($tier_budgets[$key])) {
				return max(0, absint($tier_budgets[$key]));
			}
			$percent = $defaults[$key] ?? 0;
			return (int) floor(($total_budget_minor * $percent) / 100);
		}

		private static function replace_tiers(int $build_id, array $tiers)
		{
			global $wpdb;
			$table = $wpdb->prefix . 'vms_meta_ads_tiers';
			$deleted = $wpdb->delete($table, array('build_id' => $build_id), array('%d'));
			if ($deleted === false) {
				return new WP_Error('db_tier_delete_failed', __('Unable to replace tier rows.', 'vms-meta-ads'));
			}

			$now = current_time('mysql', true);
			foreach ($tiers as $tier) {
				$ok = $wpdb->insert(
					$table,
					array(
						'build_id' => $build_id,
						'tier_key' => $tier['tier_key'],
						'tier_label' => $tier['tier_label'],
						'start_time' => $tier['start_time'],
						'end_time' => $tier['end_time'],
						'budget_type' => $tier['budget_type'],
						'budget_amount_minor' => $tier['budget_amount_minor'],
						'created_at' => $now,
						'updated_at' => $now,
					),
					array('%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s')
				);
				if ($ok === false) {
					return new WP_Error('db_tier_insert_failed', __('Unable to save tier rows.', 'vms-meta-ads'));
				}
			}
			return true;
		}

		private static function build_utm_url(string $destination_url, string $venue_name, string $event_name, DateTimeImmutable $event_dt): string
		{
			$venue_slug = sanitize_title($venue_name ?: 'venue');
			$event_slug = sanitize_title($event_name ?: 'event');
			$campaign = $venue_slug . '_' . $event_slug . '_' . $event_dt->format('Ymd');

			$parts = wp_parse_url($destination_url);
			$query = array();
			if (!empty($parts['query'])) {
				parse_str($parts['query'], $query);
			}
			$query['utm_source'] = 'facebook';
			$query['utm_medium'] = 'paid_social';
			$query['utm_campaign'] = $campaign;

			$base = $destination_url;
			if (strpos($destination_url, '?') !== false) {
				$base = (string) strtok($destination_url, '?');
			}

			return $base . '?' . http_build_query($query);
		}

		
			private static function validate_location_rows_text(string $raw, int $default_radius_miles, string $field_label = '')
			{
				$raw = (string) $raw;
				$default_radius_miles = max(1, min(250, (int) $default_radius_miles));
				$lines = preg_split('/\r\n|\r|\n/', $raw);
				if (!$lines) {
					return array();
				}
				$out = array();
				foreach ($lines as $index => $line) {
					$line = trim((string) $line);
					if ($line === '' || strpos($line, '#') === 0) {
						continue;
					}
					$radius = $default_radius_miles;
					$label = $line;
					if (strpos($line, '|') !== false) {
						$parts = array_map('trim', explode('|', $line, 2));
						$label = (string) ($parts[0] ?? '');
						$radius_raw = trim((string) ($parts[1] ?? ''));
						if ($radius_raw === '' || !preg_match('/^[0-9]+(?:\.[0-9]+)?(?:\s*(?:mi|mile|miles))?$/i', $radius_raw)) {
							return new WP_Error(
								'outer_towns_invalid_radius',
								sprintf(__('%1$s location row %2$d has an invalid radius: "%3$s". Use a number of miles, for example "Athens, Texas | 15".', 'vms-meta-ads'), $field_label ?: __('Audience', 'vms-meta-ads'), $index + 1, $line),
								array('status' => 400)
							);
						}
						$radius = (int) round((float) preg_replace('/[^0-9.]/', '', $radius_raw));
					}
					$label = sanitize_text_field($label);
					if ($label === '') {
						return new WP_Error(
							'outer_towns_missing_location',
							sprintf(__('%1$s location row %2$d is missing a location before the | radius.', 'vms-meta-ads'), $field_label ?: __('Audience', 'vms-meta-ads'), $index + 1),
							array('status' => 400)
						);
					}
					if ($radius < 1) {
						return new WP_Error(
							'outer_towns_radius_too_small',
							sprintf(__('%1$s location row %2$d must use a radius greater than 0 miles.', 'vms-meta-ads'), $field_label ?: __('Audience', 'vms-meta-ads'), $index + 1),
							array('status' => 400)
						);
					}
					$out[] = array('label' => $label, 'radius_miles' => max(1, min(250, $radius)));
				}
				return $out;
			}

			private static function parse_locations_text(string $raw, int $default_radius_miles): array
			{
				$raw = (string) $raw;
				$default_radius_miles = max(1, min(250, (int) $default_radius_miles));
				$lines = preg_split('/\r\n|\r|\n/', $raw);
				if (!$lines) {
					return array();
				}
				$out = array();
				foreach ($lines as $line) {
					$line = trim((string) $line);
					if ($line === '' || strpos($line, '#') === 0) {
						continue;
					}
					$radius = $default_radius_miles;
					$label = $line;
					if (strpos($line, '|') !== false) {
						$parts = array_map('trim', explode('|', $line, 2));
						$label = (string) ($parts[0] ?? '');
						$maybe = preg_replace('/[^0-9]/', '', (string) ($parts[1] ?? ''));
						if ($maybe !== '') {
							$radius = (int) $maybe;
						}
					}
					$label = sanitize_text_field($label);
					$radius = max(1, min(250, (int) $radius));
					if ($label === '') {
						continue;
					}
					$key = strtolower($label) . ':' . $radius;
					$out[$key] = array(
						'label' => $label,
						'radius_miles' => $radius,
					);
				}
				return array_values($out);
			}

			private static function sanitize_placements($raw): array
			{
				$allowed = array('fb_feed','fb_profile_feed','fb_right_column','fb_story','fb_reels','fb_search','ig_feed','ig_story','ig_reels','ig_search','ig_explore');
				$in = is_array($raw) ? $raw : array();
				$out = array();
				foreach ($in as $v) {
					$v = sanitize_key((string) $v);
					$v = str_replace('-', '_', $v);
					if (in_array($v, $allowed, true)) {
						$out[$v] = $v;
					}
				}
				return array_values($out);
			}

private static function build_copy_pack(array $normalized, array $tiers, string $utm_url, DateTimeImmutable $event_dt): array
		{
			$venue_name = $normalized['venue_name'] ?: __('Venue', 'vms-meta-ads');
			$event_name = $normalized['event_name'] ?: __('Event', 'vms-meta-ads');
			$date_display = wp_date('M j, Y g:i A', $event_dt->getTimestamp(), wp_timezone());

			$campaign_name = sprintf('%s — %s — %s', $venue_name, $event_name, $event_dt->format('Y-m-d'));
			$ad_variants = !empty($normalized['ad_variants']) && is_array($normalized['ad_variants']) ? array_values((array) $normalized['ad_variants']) : array();
			if (empty($ad_variants)) {
				$ad_variants[] = array(
					'variant_key' => 'v1',
					'label' => 'Variant 1',
					'primary_text' => (string) ($normalized['primary_text'] ?? ''),
					'headline' => (string) ($normalized['headline'] ?? ''),
					'description' => (string) ($normalized['description'] ?? ''),
				);
			}

			$default_primary_variants = array(
				sprintf('%s at %s on %s. Grab your tickets now.', $event_name, $venue_name, $date_display),
				sprintf("Don't miss %s at %s. Tickets are moving.", $event_name, $venue_name),
				sprintf('%s is coming up fast. Lock in your spot today.', $event_name),
			);
			$default_headline_variants = array(
				sprintf('%s Tickets Available', $event_name),
				sprintf('%s at %s', $event_name, $venue_name),
				'Reserve Your Spot Now',
			);

			$variant_rows = array();
			$primary_variants = array();
			$headline_variants = array();
			$description_variants = array();
			$ad_names = array();
			foreach ($ad_variants as $index => $variant) {
				$label = sanitize_text_field((string) ($variant['label'] ?? ('Variant ' . ($index + 1))));
				if ($label === '') {
					$label = 'Variant ' . ($index + 1);
				}
				$primary_text = sanitize_textarea_field((string) ($variant['primary_text'] ?? ''));
				$headline = sanitize_text_field((string) ($variant['headline'] ?? ''));
				$description = sanitize_text_field((string) ($variant['description'] ?? ''));
				if ($primary_text === '' && isset($default_primary_variants[$index])) {
					$primary_text = (string) $default_primary_variants[$index];
				}
				if ($headline === '' && isset($default_headline_variants[$index])) {
					$headline = (string) $default_headline_variants[$index];
				}
				if ($description === '') {
					$description = __('Tickets available now.', 'vms-meta-ads');
				}

				$variant_key = sanitize_key((string) ($variant['variant_key'] ?? ('v' . ($index + 1))));
				if ($variant_key === '') {
					$variant_key = 'v' . ($index + 1);
				}
				$ad_name = sprintf('%s — %s — %s', $event_name, $label, strtoupper($variant_key));
				$ad_names[] = $ad_name;
				$variant_rows[] = array(
					'variant_key' => $variant_key,
					'label' => $label,
					'primary_text' => $primary_text,
					'headline' => $headline,
					'description' => $description,
					'media_mode' => sanitize_key((string) ($variant['media_mode'] ?? 'shared')) ?: 'shared',
					'media_image_id' => absint($variant['media_image_id'] ?? 0),
					'media_video_id' => absint($variant['media_video_id'] ?? 0),
					'ad_name' => $ad_name,
					'creative_name' => $ad_name . ' Creative',
				);
				$primary_variants[] = $primary_text;
				$headline_variants[] = $headline;
				$description_variants[] = $description;
			}

			$primary_variants = array_slice(array_values(array_unique(array_filter(array_merge($primary_variants, $default_primary_variants)))), 0, 8);
			$headline_variants = array_slice(array_values(array_unique(array_filter(array_merge($headline_variants, $default_headline_variants)))), 0, 8);
			$description_variants = array_slice(array_values(array_unique(array_filter($description_variants))), 0, 8);
			if (empty($description_variants)) {
				$description_variants = array(__('Tickets available now.', 'vms-meta-ads'));
			}

			$adset_names = array();
			foreach ($tiers as $tier) {
				$adset_names[] = self::adset_name_for_tier($tier['tier_key'], $event_dt);
			}
			$audience_summary_payload = array(
				'summary' => sprintf(
					'Radius %dmi, age %d-%d%s%s%s%s%s',
					$normalized['radius_miles'],
					$normalized['age_min'],
					$normalized['age_max'],
					empty($normalized['targeting_address']) ? '' : ', anchor: ' . (string) $normalized['targeting_address'],
					empty($normalized['interests']) ? '' : ', interests: ' . implode(', ', $normalized['interests']),
					empty($normalized['locations']) ? '' : ', multiple locations',
					($normalized['placements_mode'] ?? 'automatic') === 'manual' ? ', manual placements' : '',
					!empty($normalized['force_buy_tickets_cta']) ? ', CTA locked to Buy Tickets' : ''
				),
				'warnings' => array(),
			);
			if (class_exists('VMS_Meta_Ads_Audience_Targeting_Service')) {
				$audience_summary_payload = VMS_Meta_Ads_Audience_Targeting_Service::build_summary(
					is_array($normalized['audience_targeting'] ?? null) ? (array) $normalized['audience_targeting'] : array(),
					array(
						'targeting_address' => (string) ($normalized['targeting_address'] ?? ''),
						'radius_miles' => (int) ($normalized['radius_miles'] ?? 15),
						'age_min' => (int) ($normalized['age_min'] ?? 21),
						'age_max' => (int) ($normalized['age_max'] ?? 65),
						'gender' => (string) ($normalized['gender'] ?? 'all'),
						'placements_mode' => (string) ($normalized['placements_mode'] ?? 'automatic'),
					)
				);
			}

			return array(
				'campaign_name' => $campaign_name,
				'adset_names' => $adset_names,
				'ad_names' => $ad_names,
				'ad_variants' => $variant_rows,
				'primary_text_variants' => $primary_variants,
				'headline_variants' => $headline_variants,
				'description_variants' => $description_variants,
				'cta_suggestion' => (string) ($normalized['cta_type'] ?? 'LEARN_MORE'),
					'cta_type' => (string) ($normalized['cta_type'] ?? 'LEARN_MORE'),
					'strategy_template' => (string) ($normalized['strategy_template'] ?? 'custom'),
					'optimization' => (string) ($normalized['optimization'] ?? 'link_clicks'),
					'campaign_recipe' => (string) ($normalized['campaign_recipe'] ?? ''),
					'include_right_column_support' => !empty($normalized['include_right_column_support']) ? 1 : 0,
					'include_outer_towns_adset' => !empty($normalized['include_outer_towns_adset']) ? 1 : 0,
					'video_format' => (string) ($normalized['video_format'] ?? 'unknown'),
					'require_vertical_video' => !empty($normalized['require_vertical_video']) ? 1 : 0,
					'creative_requirements' => self::build_creative_requirements($normalized),
					'force_buy_tickets_cta' => !empty($normalized['force_buy_tickets_cta']) ? 1 : 0,
					'creative_automation_policy' => (string) ($normalized['creative_automation_policy'] ?? 'off'),
					'multi_advertiser_ads' => !empty($normalized['multi_advertiser_ads']) ? 1 : 0,
				'image_square_id' => absint($normalized['image_square_id'] ?? 0),
				'image_vertical_id' => absint($normalized['image_vertical_id'] ?? 0),
				'image_wide_id' => absint($normalized['image_wide_id'] ?? 0),
				'creative_assets' => array(
					'image_square_id' => absint($normalized['image_square_id'] ?? 0),
					'image_vertical_id' => absint($normalized['image_vertical_id'] ?? 0),
					'image_wide_id' => absint($normalized['image_wide_id'] ?? 0),
				),
				'destination_url' => $normalized['destination_url'],
				'utm_url' => $utm_url,
				'audience_recipe_summary' => (string) ($audience_summary_payload['summary'] ?? ''),
				'audience_warnings' => array_values((array) ($audience_summary_payload['warnings'] ?? array())),
				'budget_schedule_summary' => array_map(static function (array $tier): string {
					return sprintf(
						'%s: $%0.2f (%s to %s)',
						$tier['tier_label'],
						$tier['budget_amount_minor'] / 100,
						wp_date('M j g:i A', strtotime($tier['start_time']), wp_timezone()),
						wp_date('M j g:i A', strtotime($tier['end_time']), wp_timezone())
					);
				}, $tiers),
				'creative_mode' => $normalized['creative_mode'],
				'fb_event_id' => $normalized['fb_event_id'],
			);
		}

		private static function build_creative_requirements(array $normalized): array
		{
			$recipe_key = sanitize_key((string) ($normalized['campaign_recipe'] ?? ''));
			if ($recipe_key === '') {
				return array();
			}
			$rows = array(
				array(
					'key' => 'square_static',
					'label' => __('Square/static creative', 'vms-meta-ads'),
					'needed_for' => __('Feed, Reels fallback, outer-town support, and Right Column fallback', 'vms-meta-ads'),
					'status' => !empty($normalized['image_square_id']) ? 'ready' : 'warning',
				),
				array(
					'key' => 'vertical_video',
					'label' => __('Tall 9:16 video', 'vms-meta-ads'),
					'needed_for' => __('Dedicated Reels/Stories placement group', 'vms-meta-ads'),
					'status' => in_array((string) ($normalized['video_format'] ?? ''), array('tall_9_16', 'meta_direct_vertical'), true) ? 'ready' : (!empty($normalized['require_vertical_video']) ? 'blocked' : 'warning'),
				),
			);
			if ($recipe_key === 'clean_room_full_push_v2' && !empty($normalized['include_right_column_support'])) {
				$rows[] = array(
					'key' => 'right_column_static',
					'label' => __('Right Column static image', 'vms-meta-ads'),
					'needed_for' => __('Optional desktop support test only', 'vms-meta-ads'),
					'status' => !empty($normalized['image_square_id']) ? 'ready' : 'blocked',
				);
			}
			return $rows;
		}

		private static function sync_event_plan_meta(array $normalized, array $payloads, int $build_id): void
		{
			$event_plan_id = (int) ($normalized['event_plan_id'] ?? 0);
			if ($event_plan_id < 1) {
				return;
			}

			$copy = (array) ($payloads['copy_payload'] ?? array());
			$schedule = (array) ($payloads['schedule_payload'] ?? array());
			$draft_json = array(
				'build_id' => $build_id,
				'event_plan_id' => $event_plan_id,
				'preset_mode' => (string) ($normalized['preset_mode'] ?? 'flat_run'),
				'optimization' => (string) ($normalized['optimization'] ?? 'link_clicks'),
				'goal' => (string) ($normalized['goal'] ?? 'traffic'),
				'objective_meta' => self::objective_for_goal((string) ($normalized['goal'] ?? 'traffic'), (string) ($normalized['objective_meta'] ?? '')),
				'gender' => (string) ($normalized['gender'] ?? 'all'),
				'audience_targeting' => is_array($normalized['audience_targeting'] ?? null) ? (array) $normalized['audience_targeting'] : array(),
				'end_buffer_hours' => (int) ($normalized['end_buffer_hours'] ?? 2),
				'manual_start' => (string) ($normalized['manual_start'] ?? ''),
				'manual_end' => (string) ($normalized['manual_end'] ?? ''),
				'total_budget_minor' => (int) ($normalized['total_budget_minor'] ?? 0),
				'strategy_template' => (string) ($normalized['strategy_template'] ?? 'custom'),
				'campaign_recipe' => (string) ($normalized['campaign_recipe'] ?? ''),
				'include_right_column_support' => !empty($normalized['include_right_column_support']) ? 1 : 0,
				'include_outer_towns_adset' => !empty($normalized['include_outer_towns_adset']) ? 1 : 0,
				'video_format' => (string) ($normalized['video_format'] ?? 'unknown'),
				'require_vertical_video' => !empty($normalized['require_vertical_video']) ? 1 : 0,
				'image_square_id' => absint($normalized['image_square_id'] ?? 0),
				'image_vertical_id' => absint($normalized['image_vertical_id'] ?? 0),
				'image_wide_id' => absint($normalized['image_wide_id'] ?? 0),
				'updated_local' => wp_date('Y-m-d H:i:s', null, wp_timezone()),
			);

			update_post_meta($event_plan_id, 'vms_ma_last_draft_json', wp_json_encode($draft_json));
			update_post_meta($event_plan_id, 'vms_ma_last_copy_pack', self::copy_pack_to_text($copy));
			update_post_meta($event_plan_id, 'vms_ma_last_updated_local', wp_date('Y-m-d H:i:s', null, wp_timezone()));
			update_post_meta($event_plan_id, 'vms_ma_auto_budget_sync_enabled', !empty($normalized['auto_sync_budget_enabled']) ? 1 : 0);
			update_post_meta($event_plan_id, 'vms_ma_last_preset', (string) ($normalized['preset_mode'] ?? 'flat_run'));
			update_post_meta($event_plan_id, 'vms_ma_last_budget_cents', (int) ($normalized['total_budget_minor'] ?? 0));
			update_post_meta($event_plan_id, 'vms_ma_last_schedule_json', wp_json_encode($schedule));
		}

		private static function copy_pack_to_text(array $copy): string
		{
			$lines = array();
			$lines[] = 'Campaign: ' . (string) ($copy['campaign_name'] ?? '');
			$lines[] = 'Destination URL: ' . (string) ($copy['destination_url'] ?? '');
			$lines[] = 'UTM URL: ' . (string) ($copy['utm_url'] ?? '');
			$lines[] = 'Audience: ' . (string) ($copy['audience_recipe_summary'] ?? '');
			foreach ((array) ($copy['audience_warnings'] ?? array()) as $audience_warning) {
				$warning = sanitize_text_field((string) $audience_warning);
				if ($warning !== '') {
					$lines[] = 'Audience warning: ' . $warning;
				}
			}
			if (!empty($copy['campaign_recipe_payload']) && is_array($copy['campaign_recipe_payload'])) {
				$recipe = (array) $copy['campaign_recipe_payload'];
				$lines[] = 'Campaign Recipe: ' . (string) ($recipe['label'] ?? $recipe['recipe_key'] ?? '');
				if (isset($recipe['include_right_column_support'])) {
					$lines[] = 'Right Column Support Test: ' . (!empty($recipe['include_right_column_support']) ? 'Included' : 'Excluded');
				}
				if (!empty($recipe['video_format'])) {
					$lines[] = 'Video Format: ' . (string) $recipe['video_format'];
				}
				foreach ((array) ($recipe['adsets'] ?? array()) as $adset) {
					if (!is_array($adset)) { continue; }
					$creative_needed = (string) ($adset['creative_needed'] ?? '');
					$lines[] = sprintf('- %s: $%0.2f | placements: %s%s', (string) ($adset['label'] ?? $adset['key'] ?? ''), ((int) ($adset['budget_amount_minor'] ?? 0)) / 100, implode(', ', (array) ($adset['placements'] ?? array())), $creative_needed !== '' ? ' | creative: ' . $creative_needed : '');
				}
			}
			$lines[] = 'CTA: ' . (string) ($copy['cta_suggestion'] ?? '');
			$lines[] = 'Budget + Schedule:';
			foreach ((array) ($copy['budget_schedule_summary'] ?? array()) as $row) {
				$lines[] = '- ' . (string) $row;
			}
			$lines[] = 'Primary text variants:';
			foreach ((array) ($copy['primary_text_variants'] ?? array()) as $row) {
				$lines[] = '- ' . (string) $row;
			}
			$lines[] = 'Headline variants:';
			foreach ((array) ($copy['headline_variants'] ?? array()) as $row) {
				$lines[] = '- ' . (string) $row;
			}
			$lines[] = 'Description variants:';
			foreach ((array) ($copy['description_variants'] ?? array()) as $row) {
				$lines[] = '- ' . (string) $row;
			}
			return implode("\n", $lines);
		}

		private static function adset_name_for_tier(string $tier_key, DateTimeImmutable $event_dt): string
		{
			switch ($tier_key) {
				case 'd30':
					$label = '30d Awareness';
					break;
				case 'd14':
					$label = '14d Intent';
					break;
				case 'd7':
					$label = '7d Urgency';
					break;
				default:
					$label = 'Promo';
					break;
			}
			return $label . ' — ' . $event_dt->format('Y-m-d');
		}

		private static function infer_event_start(int $event_plan_id): string
		{
			if ($event_plan_id < 1) {
				return '';
			}
			$candidates = array(
				'_vms_event_start',
				'_vms_event_date',
				'_EventStartDate',
				'event_start',
			);
			foreach ($candidates as $meta_key) {
				$value = (string) get_post_meta($event_plan_id, $meta_key, true);
				if ($value !== '') {
					$ts = strtotime($value);
					if ($ts !== false) {
						return wp_date('Y-m-d H:i:s', $ts, wp_timezone());
					}
				}
			}
			$post = get_post($event_plan_id);
			if ($post && $post->post_date_gmt) {
				$ts = strtotime($post->post_date_gmt . ' GMT');
				if ($ts !== false) {
					return wp_date('Y-m-d H:i:s', $ts, wp_timezone());
				}
			}
			return '';
		}

		private static function infer_event_name(int $event_plan_id): string
		{
			if ($event_plan_id < 1) {
				return '';
			}
			$post = get_post($event_plan_id);
			return $post ? sanitize_text_field($post->post_title) : '';
		}

		private static function infer_venue_name(int $venue_id): string
		{
			if ($venue_id < 1) {
				return '';
			}
			$post = get_post($venue_id);
			return $post ? sanitize_text_field($post->post_title) : '';
		}

		private static function infer_targeting_address(int $event_plan_id, int $venue_id): string
		{
			if (class_exists('VMS_Meta_Ads_Event_Plans_Service')) {
				$event = null;
				if ($event_plan_id > 0) {
					$event = VMS_Meta_Ads_Event_Plans_Service::get_event_plan($event_plan_id);
				}
				if (is_array($event)) {
					$anchor = trim((string) ($event['location_targeting_anchor'] ?? ''));
					if ($anchor !== '') {
						return sanitize_text_field($anchor);
					}
					$address = trim((string) ($event['location_address'] ?? ''));
					if ($address !== '') {
						return sanitize_text_field($address);
					}
					$zip = trim((string) ($event['location_zip'] ?? ''));
					if ($zip !== '') {
						return sanitize_text_field($zip);
					}
				}
			}

			if ($venue_id > 0) {
				$candidates = array(
					'_vms_addr1',
					'_vms_address',
					'_vms_address_1',
					'_vms_street',
					'address_1',
					'address',
					'street_address',
					'_vms_zip',
					'_vms_zip_code',
					'_vms_postal_code',
					'zip',
					'zipcode',
					'postal_code',
				);
				foreach ($candidates as $key) {
					$value = trim((string) get_post_meta($venue_id, $key, true));
					if ($value !== '') {
						return sanitize_text_field($value);
					}
				}
			}
			return '';
		}

		private static function build_has_meta_link(array $build): bool
		{
			$meta_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			$campaign_id = trim((string) ($build['meta_campaign_id'] ?? ($meta_ids['campaign_id'] ?? '')));
			$adset_id = trim((string) ($meta_ids['adset_id'] ?? ''));
			$ad_id = trim((string) ($meta_ids['ad_id'] ?? ''));
			if ($campaign_id !== '' || $adset_id !== '' || $ad_id !== '') {
				return true;
			}
			foreach ((array) ($build['tiers'] ?? array()) as $tier) {
				if (!is_array($tier)) {
					continue;
				}
				if (trim((string) ($tier['meta_adset_id'] ?? '')) !== '' || trim((string) ($tier['meta_ad_id'] ?? '')) !== '' || trim((string) ($tier['meta_creative_id'] ?? '')) !== '') {
					return true;
				}
			}
			return false;
		}

		private static function preserve_meta_status(array $build): string
		{
			$status = sanitize_key((string) ($build['status'] ?? ''));
			if (in_array($status, array('live', 'meta_created_paused', 'ended', 'error'), true)) {
				return $status;
			}
			$meta_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			$summary = is_array($meta_ids['adopted_summary'] ?? null) ? (array) $meta_ids['adopted_summary'] : array();
			$campaign_status = strtoupper(sanitize_text_field((string) ($summary['campaign_status'] ?? '')));
			$adset_status = strtoupper(sanitize_text_field((string) ($summary['adset_status'] ?? '')));
			if ($campaign_status === 'ACTIVE' || $adset_status === 'ACTIVE') {
				return 'live';
			}
			return 'meta_created_paused';
		}

		private static function restore_meta_ids_to_first_tier(int $build_id, array $existing, string $status, string $now): void
		{
			if ($build_id < 1) {
				return;
			}
			$meta_ids = is_array($existing['meta_ids'] ?? null) ? (array) $existing['meta_ids'] : array();
			$adset_id = sanitize_text_field((string) ($meta_ids['adset_id'] ?? ''));
			$creative_id = sanitize_text_field((string) ($meta_ids['creative_id'] ?? ''));
			$ad_id = sanitize_text_field((string) ($meta_ids['ad_id'] ?? ''));
			if (($creative_id === '' || $ad_id === '' || $adset_id === '') && !empty($existing['tiers']) && is_array($existing['tiers'])) {
				$first_existing_tier = is_array($existing['tiers'][0] ?? null) ? (array) $existing['tiers'][0] : array();
				if ($adset_id === '') {
					$adset_id = sanitize_text_field((string) ($first_existing_tier['meta_adset_id'] ?? ''));
				}
				if ($creative_id === '') {
					$creative_id = sanitize_text_field((string) ($first_existing_tier['meta_creative_id'] ?? ''));
				}
				if ($ad_id === '') {
					$ad_id = sanitize_text_field((string) ($first_existing_tier['meta_ad_id'] ?? ''));
				}
			}
			if ($adset_id === '' && $creative_id === '' && $ad_id === '') {
				return;
			}
			$tier_status = null;
			if ($status === 'live') {
				$tier_status = 'ACTIVE';
			} elseif ($status === 'meta_created_paused') {
				$tier_status = 'PAUSED';
			}
			global $wpdb;
			$tier_id = (int) $wpdb->get_var($wpdb->prepare(
				'SELECT id FROM ' . $wpdb->prefix . 'vms_meta_ads_tiers WHERE build_id = %d ORDER BY start_time ASC LIMIT 1',
				$build_id
			));
			if ($tier_id < 1) {
				return;
			}
			$wpdb->update(
				$wpdb->prefix . 'vms_meta_ads_tiers',
				array(
					'meta_adset_id' => $adset_id !== '' ? $adset_id : null,
					'meta_creative_id' => $creative_id !== '' ? $creative_id : null,
					'meta_ad_id' => $ad_id !== '' ? $ad_id : null,
					'meta_status' => $tier_status,
					'updated_at' => $now,
				),
				array('id' => $tier_id),
				array('%s', '%s', '%s', '%s', '%s'),
				array('%d')
			);
		}


		private static function is_zero_mysql_datetime(string $value): bool
		{
			$value = trim($value);
			return $value === '' || $value === '0000-00-00 00:00:00' || $value === '0000-00-00';
		}

		private static function normalize_mysql_datetime_for_display(string $value, int $fallback_id = 0): string
		{
			if (!self::is_zero_mysql_datetime($value)) {
				return $value;
			}
			if ($fallback_id > 0) {
				return sprintf(__('legacy row #%d timestamp pending repair', 'vms-meta-ads'), $fallback_id);
			}
			return '';
		}

		private static function repair_zero_timestamps(): void
		{
			global $wpdb;
			$now = current_time('mysql', true);
			$builds_table = $wpdb->prefix . 'vms_meta_ads_builds';
			$tiers_table = $wpdb->prefix . 'vms_meta_ads_tiers';

			// Keep this intentionally lightweight and idempotent. It repairs legacy rows that were
			// created while the build save format list failed to include updated_at.
			$wpdb->query($wpdb->prepare(
				"UPDATE {$builds_table}
				 SET created_at = CASE
					 WHEN created_at IS NULL OR created_at = '0000-00-00 00:00:00' THEN
						 CASE WHEN updated_at IS NOT NULL AND updated_at <> '0000-00-00 00:00:00' THEN updated_at ELSE %s END
					 ELSE created_at END,
				 updated_at = CASE
					 WHEN updated_at IS NULL OR updated_at = '0000-00-00 00:00:00' THEN
						 CASE WHEN created_at IS NOT NULL AND created_at <> '0000-00-00 00:00:00' THEN created_at ELSE %s END
					 ELSE updated_at END
				 WHERE created_at IS NULL OR created_at = '0000-00-00 00:00:00' OR updated_at IS NULL OR updated_at = '0000-00-00 00:00:00'",
				$now,
				$now
			));

			$wpdb->query($wpdb->prepare(
				"UPDATE {$tiers_table}
				 SET created_at = CASE
					 WHEN created_at IS NULL OR created_at = '0000-00-00 00:00:00' THEN
						 CASE WHEN updated_at IS NOT NULL AND updated_at <> '0000-00-00 00:00:00' THEN updated_at ELSE %s END
					 ELSE created_at END,
				 updated_at = CASE
					 WHEN updated_at IS NULL OR updated_at = '0000-00-00 00:00:00' THEN
						 CASE WHEN created_at IS NOT NULL AND created_at <> '0000-00-00 00:00:00' THEN created_at ELSE %s END
					 ELSE updated_at END
				 WHERE created_at IS NULL OR created_at = '0000-00-00 00:00:00' OR updated_at IS NULL OR updated_at = '0000-00-00 00:00:00'",
				$now,
				$now
			));
		}

		private static function ensure_db_ready()
		{
			global $wpdb;
			$builds_table = $wpdb->prefix . 'vms_meta_ads_builds';
			$tiers_table = $wpdb->prefix . 'vms_meta_ads_tiers';
			$audit_table = $wpdb->prefix . 'vms_meta_ads_audit';

			$has_builds = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $builds_table)) === $builds_table);
			$has_tiers = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $tiers_table)) === $tiers_table);
			$has_audit = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $audit_table)) === $audit_table);

			if ($has_builds && $has_tiers && $has_audit) {
				self::repair_zero_timestamps();
				return true;
			}

			if (class_exists('VMS_Meta_Ads_DB') && method_exists('VMS_Meta_Ads_DB', 'install')) {
				VMS_Meta_Ads_DB::install();
			}

			$has_builds = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $builds_table)) === $builds_table);
			$has_tiers = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $tiers_table)) === $tiers_table);
			$has_audit = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $audit_table)) === $audit_table);

			if ($has_builds && $has_tiers && $has_audit) {
				self::repair_zero_timestamps();
				return true;
			}

			return new WP_Error(
				'db_missing',
				__('Meta Ads database tables are missing. Re-activate VMS Meta Ads Builder (or run DB install) and retry Save Draft.', 'vms-meta-ads'),
				array('status' => 500)
			);
		}
	}
}
