<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Admin_Enqueue')) {
	class VMS_Meta_Ads_Admin_Enqueue {
		public static function init(): void
		{
			add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_builder_assets'), 20);
		}

		public static function enqueue_builder_assets(string $hook): void
		{
			$page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
			if (!in_array($page, array('vms-ma-ads-builder', 'vms-ma-ads-promote', 'vms-ma-ads-performance', 'vms-ma-ads-settings', 'vms-ma-ads-logs'), true)) {
				return;
			}
			if ($page === 'vms-ma-ads-builder') {
				wp_enqueue_media();
			}
			if (in_array($page, array('vms-ma-ads-builder', 'vms-ma-ads-settings'), true) && vms_ma_has_core_function('vms_enqueue_tour_assets')) {
				vms_ma_call_core_function('vms_enqueue_tour_assets');
			}
			$settings = VMS_Meta_Ads_Utils::get_settings();
			$social_connection = apply_filters('vms_social_meta_connection', null);
			$using_social = is_array($social_connection) && !empty($social_connection['ad_account_id']) && empty($settings['meta_ad_account_override']);
			$effective_ad_account_id = $using_social ? (string) ($social_connection['ad_account_id'] ?? '') : (string) ($settings['meta_ad_account_id'] ?? '');
			$effective_page_id = $using_social ? (string) ($social_connection['page_id'] ?? '') : (string) ($settings['meta_page_id'] ?? '');
			$token_present = VMS_Meta_Ads_Utils::decrypt_token((string) ($settings['meta_access_token_encrypted'] ?? '')) !== '';
			$api_ready = !empty($settings['enable_api_create']) && $token_present && trim($effective_page_id) !== '' && trim($effective_ad_account_id) !== '';
			$tours_payload = VMS_Meta_Ads_Tours::get_tours_payload();
			$user_state = VMS_Meta_Ads_Utils::get_user_guidance_state(get_current_user_id());
			$guidance = $user_state['guidance_level'];
			$tour_autorun = (int) $user_state['tour_autorun'];
			$help_mode = (int) $user_state['help_mode'];
			$default_radius = max(1, absint($settings['default_radius_miles']));
			$default_age_min = max(13, absint($settings['default_age_min']));
			$default_age_max = absint($settings['default_age_max'] ?? 65);
			if ($default_age_max < 25) {
				$default_age_max = 25;
			}
			if ($default_age_max > 65) {
				$default_age_max = 65;
			}
			$prefill_defaults = array(
				'radius' => $default_radius,
				'age_min' => $default_age_min,
				'age_max' => $default_age_max,
				'preset' => sanitize_key((string) ($settings['vms_ma_default_preset'] ?? 'simple_14_day')),
				'end_buffer_hours' => max(0, absint($settings['default_end_buffer_hours'] ?? 2)),
				'goal' => 'traffic',
				'optimization' => 'link_clicks',
				'cta_type' => 'LEARN_MORE',
				'primary_text' => '',
				'headline' => '',
				'description' => '',
				'destination_url' => '',
				'image_square_id' => 0,
				'image_vertical_id' => 0,
				'image_wide_id' => 0,
			);
			$audience_catalog = class_exists('VMS_Meta_Ads_Audience_Targeting_Service')
				? VMS_Meta_Ads_Audience_Targeting_Service::get_builder_catalog()
				: array();
			wp_localize_script('vms-ma-ads-builder', 'VMS_MA', array(
				'restRoot' => esc_url_raw(rest_url('vms-ma/v1')),
				'nonce' => wp_create_nonce('wp_rest'),
				'ajaxUrl' => admin_url('admin-ajax.php'),
					'eventPlansUrl' => esc_url_raw(rest_url('vms-ma/v1/event-plans')),
					'postAssetsUrl' => esc_url_raw(rest_url('vms-ma/v1/post-assets')),
				'templatesUrl' => esc_url_raw(rest_url('vms-ma/v1/templates')),
				'wpMediaUrlBase' => esc_url_raw(rest_url('wp/v2/media/')),
					'builderUrl' => admin_url('admin.php?page=vms-ma-ads-builder'),
					'settingsUrl' => admin_url('admin.php?page=vms-ma-ads-settings'),
					'tourAutostart' => !empty($settings['tour_autostart']),
					'apiEnabled' => !empty($settings['enable_api_create']),
					'apiReady' => $api_ready ? 1 : 0,
				'createScaffoldOnly' => 0,
					'budgetMaxLifetimeMinor' => absint($settings['budget_max_lifetime_minor']),
					'budgetMaxDailyMinor' => absint($settings['budget_max_daily_minor']),
					'maxRadiusMiles' => max(1, absint($settings['max_radius_miles'] ?? 100)),
					'phase' => max(1, absint($settings['vms_ma_phase'] ?? 1)),
				'metaStatusUrl' => esc_url_raw(rest_url('vms-ma/v1/meta-status')),
				'metaGoLiveUrl' => esc_url_raw(rest_url('vms-ma/v1/go-live')),
				'metaPauseAllUrl' => esc_url_raw(rest_url('vms-ma/v1/pause-all')),
				'analyticsUrl' => esc_url_raw(rest_url('vms-ma/v1/analytics')),
				'adAccountId' => ltrim(trim((string) $effective_ad_account_id), 'act_'),
				'metaPageId' => trim((string) $effective_page_id),
				'metaIgActorId' => trim((string) ($using_social ? (string) ($social_connection['ig_actor_id'] ?? '') : (string) ($settings['meta_ig_actor_id'] ?? ''))),
				'metaPixelId' => trim((string) ($settings['meta_pixel_id'] ?? '')),
				'metaDsaBeneficiary' => trim((string) ($settings['meta_dsa_beneficiary'] ?? '')),
				'metaDsaPayor' => trim((string) ($settings['meta_dsa_payor'] ?? '')),
				'metaGraphVersion' => (string) ($settings['meta_graph_version'] ?? 'v24.0'),
				'lastTestOkGmt' => (string) ($settings['meta_last_test_ok_gmt'] ?? ''),
				'defaultPreset' => sanitize_key((string) ($settings['vms_ma_default_preset'] ?? 'simple_14_day')),
				'prefillDefaults' => $prefill_defaults,
				'audienceCatalog' => $audience_catalog,
				'tourSteps' => VMS_Meta_Ads_Tours::get_steps_payload(),
			));
			if (in_array($page, array('vms-ma-ads-builder', 'vms-ma-ads-settings'), true)) {
				wp_localize_script('vms-ma-tours', 'vmsMaTours', $tours_payload);
				wp_localize_script('vms-ma-tours', 'vmsMaTour', array(
					'autorun' => $tour_autorun,
					'helpMode' => $help_mode,
					'nonce' => wp_create_nonce('wp_rest'),
					'restUrl' => esc_url_raw(rest_url('vms-ma/v1/tour-pref')),
					'guidance' => $guidance,
					'screen' => ($page === 'vms-ma-ads-settings') ? 'settings' : 'builder',
				));
				wp_localize_script('vms-ma-tours', 'vmsMaGuidance', array(
					'guidanceLevel' => $guidance,
					'helpMode' => $help_mode,
				));
				wp_localize_script('vms-ma-help-mode', 'vmsMaHelp', array(
					'helpMode' => $help_mode,
					'guidanceLevel' => $guidance,
					'registry' => VMS_Meta_Ads_Help::get_payload(),
					'nonce' => wp_create_nonce('wp_rest'),
					'restUrl' => esc_url_raw(rest_url('vms-ma/v1/tour-pref')),
					'screen' => ($page === 'vms-ma-ads-settings') ? 'settings' : 'builder',
				));
				wp_localize_script('vms-ma-guidance', 'vmsMaGuidanceUi', array(
					'guidanceLevel' => $guidance,
					'helpMode' => $help_mode,
					'autorun' => $tour_autorun,
				));
				if ($page === 'vms-ma-ads-settings') {
					wp_localize_script('vms-ma-settings', 'vmsMaSettings', array(
						'nonce' => wp_create_nonce('wp_rest'),
						'tokenInspectUrl' => esc_url_raw(rest_url('vms-ma/v1/token-inspect')),
						'metaPagesUrl' => esc_url_raw(rest_url('vms-ma/v1/meta-pages')),
						'metaPageResolveUrl' => esc_url_raw(rest_url('vms-ma/v1/meta-page-resolve')),
						'metaConnectionStatusUrl' => esc_url_raw(rest_url('vms-ma/v1/meta-connection-status')),
					));
				}
			}
		}
	}
}
 
VMS_Meta_Ads_Admin_Enqueue::init();
