<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_render_api_diagnostics_panel')) {
	function vms_render_api_diagnostics_panel(array $args): void
	{
		$provider_slug = sanitize_key((string) ($args['provider_slug'] ?? ''));
		$module_slug = sanitize_text_field((string) ($args['module_slug'] ?? ''));
		if ($provider_slug === '' || $module_slug === '') {
			return;
		}
		if (!current_user_can('manage_options')) {
			echo '<p class="description">' . esc_html__('Diagnostics are available to administrators.', 'vms-meta-ads') . '</p>';
			return;
		}

		$context = isset($args['context']) ? sanitize_key((string) $args['context']) : null;
		$title = isset($args['title']) ? sanitize_text_field((string) $args['title']) : __('API Diagnostics', 'vms-meta-ads');
		$limit = max(1, min(25, absint($args['limit'] ?? 10)));
		$ajax_action = sanitize_key((string) ($args['ajax_action'] ?? 'vms_api_copy_bundle'));
			$last = vms_api_attempt_get_last($provider_slug, $context);
			$recent = vms_api_attempt_get_recent($provider_slug, $limit, $context);
			$last_id = (int) ($last['id'] ?? 0);
			$last_summary = $last ? vms_api_attempt_summarize((array) $last) : array();
			$nonce = wp_create_nonce('vms_api_diag_nonce');
		$pretty_json = static function ($value): string {
			$raw = is_string($value) ? trim($value) : '';
			if ($raw === '') {
				return '{}';
			}
			$decoded = json_decode($raw, true);
			if (json_last_error() !== JSON_ERROR_NONE) {
				return $raw;
			}
			$encoded = wp_json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
			return is_string($encoded) ? $encoded : '{}';
		};
		$created_local = static function ($row): string {
			$raw = is_array($row) ? (string) ($row['created_at'] ?? '') : '';
			return class_exists('VMS_API_Attempts') ? VMS_API_Attempts::format_created_at_local($raw) : $raw;
		};
		?>
		<section class="vms-api-diag-panel" data-provider-slug="<?php echo esc_attr($provider_slug); ?>" data-module-slug="<?php echo esc_attr($module_slug); ?>" data-context="<?php echo esc_attr((string) $context); ?>" data-ajax-action="<?php echo esc_attr($ajax_action); ?>" data-nonce="<?php echo esc_attr($nonce); ?>" data-default-attempt-id="<?php echo esc_attr((string) $last_id); ?>">
			<h3><?php echo esc_html($title); ?></h3>
			<?php if (!$last) : ?>
				<p class="description"><?php esc_html_e('No API attempts logged yet.', 'vms-meta-ads'); ?></p>
			<?php else : ?>
				<div class="vms-api-diag-last">
					<p><strong><?php esc_html_e('Last attempt', 'vms-meta-ads'); ?></strong> <?php echo esc_html($created_local($last)); ?></p>
					<p>
						<?php echo esc_html(strtoupper((string) ($last['method'] ?? '')) . ' ' . (string) ($last['endpoint'] ?? '')); ?>
						|
						<?php echo esc_html__('HTTP', 'vms-meta-ads') . ' ' . esc_html((string) ($last['http_status'] ?? 'n/a')); ?>
						|
						<?php echo esc_html__('Duration', 'vms-meta-ads') . ' ' . esc_html((string) ($last['duration_ms'] ?? 'n/a')) . 'ms'; ?>
					</p>
						<p>
							<?php echo esc_html__('Request ID:', 'vms-meta-ads') . ' ' . esc_html((string) ($last['request_id'] ?? '')); ?>
							|
							<?php echo esc_html__('Trace ID:', 'vms-meta-ads') . ' ' . esc_html((string) ($last['trace_id'] ?? '')); ?>
						</p>
						<p class="description">
							<?php
							echo esc_html__('Build ID:', 'vms-meta-ads') . ' ' . esc_html(!empty($last_summary['build_id']) ? (string) $last_summary['build_id'] : 'n/a');
							echo ' | ';
							echo esc_html__('Event Plan ID:', 'vms-meta-ads') . ' ' . esc_html(!empty($last_summary['event_plan_id']) ? (string) $last_summary['event_plan_id'] : 'n/a');
							echo ' | ';
							echo esc_html__('Mode:', 'vms-meta-ads') . ' ' . esc_html((string) ($last_summary['transport'] ?? __('real network call', 'vms-meta-ads')));
							?>
						</p>
						<p class="description"><?php echo esc_html((string) (($last['error_message'] ?? '') ?: ($last['wp_error_message'] ?? ''))); ?></p>
						<div class="vms-api-diag-actions">
							<button type="button" class="button button-secondary vms-api-diag-copy-latest-attempt" data-attempt-id="<?php echo esc_attr((string) $last_id); ?>"><?php esc_html_e('Copy latest attempt', 'vms-meta-ads'); ?></button>
							<button type="button" class="button vms-api-diag-copy-latest-failed"><?php esc_html_e('Copy latest failed Meta API call', 'vms-meta-ads'); ?></button>
							<button type="button" class="button vms-api-diag-copy-latest-dry-run"><?php esc_html_e('Copy latest dry run', 'vms-meta-ads'); ?></button>
							<button type="button" class="button vms-api-diag-download-latest-attempt" data-attempt-id="<?php echo esc_attr((string) $last_id); ?>"><?php esc_html_e('Download latest attempt', 'vms-meta-ads'); ?></button>
							<button type="button" class="button-link vms-api-diag-toggle-raw" aria-expanded="false"><?php esc_html_e('View Raw (sanitized)', 'vms-meta-ads'); ?></button>
						</div>
					<div class="vms-api-diag-raw vms-api-diag-hidden">
						<h4><?php esc_html_e('Request Payload (sanitized)', 'vms-meta-ads'); ?></h4>
						<pre><?php echo esc_html($pretty_json($last['request_payload_json'] ?? '{}')); ?></pre>
						<h4><?php esc_html_e('Response Body (sanitized)', 'vms-meta-ads'); ?></h4>
						<pre><?php echo esc_html($pretty_json($last['response_body_json'] ?? '{}')); ?></pre>
					</div>
				</div>
			<?php endif; ?>

			<?php if (!empty($recent)) : ?>
				<ul class="vms-api-diag-recent">
					<?php foreach ($recent as $row) : ?>
						<li>
							<span><?php echo esc_html($created_local($row)); ?></span>
							<span><?php echo esc_html((string) ($row['http_status'] ?? 'n/a')); ?></span>
							<span><?php echo esc_html((string) ($row['operation'] ?? '')); ?></span>
							<span class="vms-api-diag-endpoint"><?php echo esc_html((string) ($row['endpoint'] ?? '')); ?></span>
							<span>
								<button type="button" class="button-link vms-api-diag-copy-row" data-attempt-id="<?php echo esc_attr((string) ($row['id'] ?? 0)); ?>"><?php esc_html_e('Copy', 'vms-meta-ads'); ?></button>
								<span aria-hidden="true"> · </span>
								<button type="button" class="button-link vms-api-diag-download-row" data-attempt-id="<?php echo esc_attr((string) ($row['id'] ?? 0)); ?>"><?php esc_html_e('Download', 'vms-meta-ads'); ?></button>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<p class="description vms-api-diag-status" aria-live="polite"></p>
		</section>
		<?php
	}
}
