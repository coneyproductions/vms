<?php
defined('ABSPATH') || exit;

if (!function_exists('vms_ma_render_ads_builder_screen')) {
	function vms_ma_render_ads_builder_screen(): void
	{
		$builder_started_at = microtime(true);
		$builder_query_start = function_exists('get_num_queries') ? (int) get_num_queries() : 0;
		$settings = VMS_Meta_Ads_Utils::get_settings();
		$state = VMS_Meta_Ads_Utils::get_user_guidance_state(get_current_user_id());
		$help_mode = (int) $state['help_mode'];
		$tour_autorun = (int) $state['tour_autorun'];
		$guidance_level = (string) $state['guidance_level'];
		$prefill_event_plan_id = isset($_GET['event_plan_id']) ? absint($_GET['event_plan_id']) : 0;
		$prefill_hint = isset($_GET['prefill']) ? 1 : 0;
		$prefill_payload = null;
		if ($prefill_event_plan_id > 0) {
			$prefill_payload = VMS_Meta_Ads_Prefill_Service::get_prefill_payload($prefill_event_plan_id);
			if ($prefill_payload !== null) {
				$prefill_hint = 1;
			}
		}
		$copy_pack_hint = isset($_GET['copy_pack']) ? 1 : 0;
		$tour_query = isset($_GET['tour']) ? absint($_GET['tour']) : 0;
		$scroll_to = isset($_GET['scroll_to']) ? sanitize_key((string) $_GET['scroll_to']) : '';
		$event_plan_seed_limit = 20;
		$event_plan_seed = VMS_Meta_Ads_Event_Plans_Service::list_event_plans(array(
			'after' => wp_date('Y-m-d', null, wp_timezone()),
			'days' => 180,
			'limit' => $event_plan_seed_limit,
			'group_meta_activity_last' => true,
			'statuses' => array('published', 'ready', 'draft'),
			'context' => 'builder_initial',
		));
		$event_plan_seed_trace = VMS_Meta_Ads_Event_Plans_Service::get_last_trace();
		$builder_perf = array(
			'seed_count' => count($event_plan_seed),
			'seed_limit' => $event_plan_seed_limit,
			'seed_rows_fetched' => (int) ($event_plan_seed_trace['rows_fetched'] ?? count($event_plan_seed)),
			'seed_query_limit' => (int) ($event_plan_seed_trace['query_limit'] ?? count($event_plan_seed)),
			'seed_elapsed_ms' => (float) ($event_plan_seed_trace['elapsed_ms'] ?? 0),
			'seed_query_count' => (int) ($event_plan_seed_trace['query_count'] ?? 0),
			'location_mode' => (string) ($event_plan_seed_trace['location_mode'] ?? 'read_only'),
			'render_elapsed_ms' => round((microtime(true) - $builder_started_at) * 1000, 1),
			'render_query_count' => function_exists('get_num_queries') ? max(0, ((int) get_num_queries()) - $builder_query_start) : 0,
		);
		$age_max_default = (int) ($settings['default_age_max'] ?? 65);
		if ($age_max_default < 25) {
			$age_max_default = 25;
		}
		if ($age_max_default > 65) {
			$age_max_default = 65;
		}
		$age_options = array(25, 30, 35, 40, 45, 50, 55, 60, 65);
		$current_phase = max(1, (int) ($settings['vms_ma_phase'] ?? 1));
		$api_create_enabled = !empty($settings['enable_api_create']);
		$show_live_action_warning = $api_create_enabled || $current_phase > 1;
		?>
			<div class="wrap vms-ma" id="vms-ma-ads-builder-wrap" data-help-mode="<?php echo esc_attr($help_mode); ?>" data-tour-autorun="<?php echo esc_attr($tour_autorun); ?>" data-guidance-level="<?php echo esc_attr($guidance_level); ?>" data-prefill-event-plan-id="<?php echo esc_attr($prefill_event_plan_id); ?>" data-prefill="<?php echo esc_attr($prefill_hint); ?>" data-copy-pack-hint="<?php echo esc_attr($copy_pack_hint); ?>" data-tour-query="<?php echo esc_attr($tour_query); ?>" data-scroll-to="<?php echo esc_attr($scroll_to); ?>">
			  <script>window.vmsMaBuilderPerf = <?php echo wp_json_encode($builder_perf); ?>;</script>
			  <?php if ($prefill_payload) : ?>
			    <script>
			      window.vmsMaPrefill = <?php echo wp_json_encode($prefill_payload); ?>;
		      window.vmsMaPrefillSource = 'server';
		      window.vmsMaPrefillId = <?php echo absint($prefill_event_plan_id); ?>;
		    </script>
		  <?php endif; ?>
		  <div class="vms-ma-page-header">
		    <div class="vms-ma-page-title">
		      <h1><?php esc_html_e('Meta Ads Builder', 'vms-meta-ads'); ?></h1>
		      <p class="description vms-ma-intro"><?php esc_html_e('Guided wizard for simple and auto-ramp promo bundles.', 'vms-meta-ads'); ?></p>
		    </div>
		    <div class="vms-ma-topbar">
		      <div class="vms-ma-topbar-main">
		        <button type="button" class="button" id="vms-ma-start-tour"><?php esc_html_e('Start tour', 'vms-meta-ads'); ?></button>
		      </div>
		      <div class="vms-ma-topbar-meta">
				<?php echo VMS_Meta_Ads_Utils::render_app_mode_badge('builder'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		        <label class="vms-ma-choice vms-ma-inline-choice vms-ma-control">
		          <span><?php esc_html_e('Guidance', 'vms-meta-ads'); ?></span>
		          <select id="vms-ma-guidance-level">
		            <option value="beginner" <?php selected($guidance_level, 'beginner'); ?>><?php esc_html_e('Beginner', 'vms-meta-ads'); ?></option>
		            <option value="standard" <?php selected($guidance_level, 'standard'); ?>><?php esc_html_e('Standard', 'vms-meta-ads'); ?></option>
		            <option value="expert" <?php selected($guidance_level, 'expert'); ?>><?php esc_html_e('Expert', 'vms-meta-ads'); ?></option>
		          </select>
		        </label>
		        <label class="vms-ma-choice vms-ma-inline-choice vms-ma-control">
		          <input type="checkbox" id="vms-ma-tour-autorun-toggle" <?php checked(1, $tour_autorun); ?> />
		          <span><?php esc_html_e('Guided tour (auto)', 'vms-meta-ads'); ?></span>
		        </label>
		        <label class="vms-ma-choice vms-ma-inline-choice vms-ma-control">
		          <input type="checkbox" id="vms-ma-help-mode-toggle" <?php checked(1, $help_mode); ?> />
		          <span><?php esc_html_e('Help Mode', 'vms-meta-ads'); ?></span>
		        </label>
		      </div>
		    </div>
		  </div>

		  <div id="vms-ma-builder-notices" class="notice notice-alt is-dismissible vms-ma-notice vms-ma-hidden"></div>
		  <div id="vms-ma-toast-root" class="vms-ma-toast-root" aria-live="polite"></div>
		  <?php if ($show_live_action_warning) : ?>
		    <div class="notice notice-error vms-ma-notice vms-ma-risk-banner">
		      <p><strong><?php esc_html_e('MAB is above no-spend dry-run mode.', 'vms-meta-ads'); ?></strong></p>
		      <ul>
		        <li><?php esc_html_e('Preview / Troubleshooting Dry Run: local preview only. No Meta objects are created and no spend can occur.', 'vms-meta-ads'); ?></li>
		        <li><?php esc_html_e('Create Paused Campaign in Meta: creates real paused Meta campaign, ad set, creative, and ad objects in Ads Manager.', 'vms-meta-ads'); ?></li>
		        <li><?php esc_html_e('Go Live: can activate delivery and spend.', 'vms-meta-ads'); ?></li>
		      </ul>
		    </div>
		  <?php endif; ?>

		  <section id="vms-ma-step-a" class="vms-ma-section vms-ma-step vms-ma-card" data-step="source" data-step-key="A" data-step-index="1">
		    <div class="vms-ma-step-header vms-ma-step-head" role="button" tabindex="0" aria-expanded="true">
		      <h2 class="vms-ma-section-title"><?php esc_html_e('Step A - Source', 'vms-meta-ads'); ?></h2>
		      <div class="vms-ma-step-head-actions">
		        <button type="button" class="button-link vms-ma-advanced-toggle"><?php esc_html_e('Manual entry', 'vms-meta-ads'); ?></button>
		        <span class="vms-ma-step-status" data-step-status><?php esc_html_e('Not started', 'vms-meta-ads'); ?></span>
		      </div>
		    </div>
		    <div class="vms-ma-step-body">
		      <p class="description vms-ma-section-intro"><?php esc_html_e('Choose your Event Plan context and destination URL.', 'vms-meta-ads'); ?></p>
		      <div id="vms-ma-event-picker" class="vms-ma-grid-two" data-vms-tour="vms-ma-event-picker" data-seed-count="<?php echo esc_attr((string) $builder_perf['seed_count']); ?>" data-seed-limit="<?php echo esc_attr((string) $builder_perf['seed_limit']); ?>" data-location-mode="<?php echo esc_attr((string) $builder_perf['location_mode']); ?>" data-render-ms="<?php echo esc_attr((string) $builder_perf['render_elapsed_ms']); ?>" data-query-count="<?php echo esc_attr((string) $builder_perf['render_query_count']); ?>">
		        <label for="vms-ma-event-plan-picker"><span><?php esc_html_e('Select Event Plan', 'vms-meta-ads'); ?> <button type="button" class="vms-ma-info" aria-label="<?php esc_attr_e('Help for Event Plan ID', 'vms-meta-ads'); ?>" data-help-id="ma_help_event_plan_id" data-auto-help="1" data-auto-help-target="#vms-ma-event-plan-picker" data-auto-help-default="">i</button></span><select id="vms-ma-event-plan-picker"><option value=""><?php esc_html_e('Search upcoming Event Plans...', 'vms-meta-ads'); ?></option><?php foreach ($event_plan_seed as $seed_item) : ?><?php $seed_text = '[' . trim((string) ($seed_item['meta_ads_picker_label'] ?? __('New', 'vms-meta-ads'))) . '] ' . trim((string) ($seed_item['title'] ?? '')); $seed_meta = trim((string) ($seed_item['start_display'] ?? ($seed_item['start_local'] ?? ''))); if ($seed_meta !== '') { $seed_text .= ' - ' . $seed_meta; } if (!empty($seed_item['venue_name'])) { $seed_text .= ' | ' . (string) $seed_item['venue_name']; } ?><option value="<?php echo esc_attr((int) ($seed_item['id'] ?? 0)); ?>" data-event-item="<?php echo esc_attr(wp_json_encode($seed_item)); ?>"><?php echo esc_html($seed_text); ?></option><?php endforeach; ?></select></label>
		        <div class="vms-ma-picker-search">
		          <label for="vms-ma-event-plan-search"><span><?php esc_html_e('Search Event Plans', 'vms-meta-ads'); ?></span><input type="search" id="vms-ma-event-plan-search" placeholder="<?php esc_attr_e('Title or venue', 'vms-meta-ads'); ?>" /></label>
		          <div class="vms-ma-inline-actions">
		            <button type="button" class="button button-secondary" id="vms-ma-event-plan-search-button"><?php esc_html_e('Search', 'vms-meta-ads'); ?></button>
		            <button type="button" class="button button-link" id="vms-ma-event-plan-search-reset"><?php echo esc_html(sprintf(__('Show latest %d', 'vms-meta-ads'), $event_plan_seed_limit)); ?></button>
		          </div>
		          <p id="vms-ma-event-plan-search-status" class="description"><?php echo esc_html(sprintf(__('Builder loads a read-only seed of %d upcoming Event Plans. Search loads more on demand and never syncs TEC venues on page render.', 'vms-meta-ads'), $event_plan_seed_limit)); ?></p>
		        </div>
		        <input type="hidden" id="vms-ma-event-plan-id" data-required-step="1" />
		        <input type="hidden" id="vms-ma-venue-id" />
		        <div class="vms-ma-manual-entry" data-advanced="1">
		          <label for="vms-ma-event-plan-id-manual"><span><?php esc_html_e('Event Plan ID (manual)', 'vms-meta-ads'); ?></span><input type="number" id="vms-ma-event-plan-id-manual" min="0" step="1" /></label>
		          <label for="vms-ma-venue-id-manual"><span><?php esc_html_e('Venue ID (optional)', 'vms-meta-ads'); ?></span><input type="number" id="vms-ma-venue-id-manual" min="0" step="1" /></label>
		        </div>
		        <label><span><?php esc_html_e('Event name', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-event-name" /></label>
		        <label><span><?php esc_html_e('Venue name', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-venue-name" /></label>
		        <label><span><?php esc_html_e('Event start (site timezone)', 'vms-meta-ads'); ?></span><input type="datetime-local" id="vms-ma-event-start" /></label>
		        <label for="vms-ma-destination-url"><span><?php esc_html_e('Destination URL', 'vms-meta-ads'); ?> <button type="button" class="vms-ma-info" aria-label="<?php esc_attr_e('Help for Destination URL', 'vms-meta-ads'); ?>" data-help-id="ma_help_destination_url" data-auto-help="1" data-auto-help-target="#vms-ma-destination-url" data-auto-help-default="">i</button></span><input type="url" id="vms-ma-destination-url" placeholder="https://" data-required-step="1" /></label>
		      </div>
		      <div id="vms-ma-build-manager" class="vms-ma-build-manager">
		        <div class="vms-ma-grid-two">
		          <label for="vms-ma-build-select"><span><?php esc_html_e('Campaign draft', 'vms-meta-ads'); ?></span>
		            <select id="vms-ma-build-select" disabled>
		              <option value=""><?php esc_html_e('Select an Event Plan first…', 'vms-meta-ads'); ?></option>
		            </select>
		          </label>
		          <div class="vms-ma-inline-actions vms-ma-build-actions">
		            <button type="button" class="button button-secondary" id="vms-ma-start-new-build" disabled><?php esc_html_e('Create New Campaign Draft', 'vms-meta-ads'); ?></button>
		            <button type="button" class="button button-link" id="vms-ma-refresh-builds" disabled><?php esc_html_e('Refresh builds', 'vms-meta-ads'); ?></button>
		          </div>
		        </div>
		        <p id="vms-ma-build-meta" class="description" aria-live="polite"><?php esc_html_e('Choose an Event Plan to see saved builds for it.', 'vms-meta-ads'); ?></p>
		        <div id="vms-ma-build-list" class="vms-ma-build-list" aria-live="polite"></div>

		        <div id="vms-ma-reconcile-panel" class="vms-ma-reconcile-panel">
		          <div class="vms-ma-reconcile-head">
		            <strong><?php esc_html_e('Meta reconciliation', 'vms-meta-ads'); ?></strong>
		            <button type="button" class="button button-secondary" id="vms-ma-find-meta-campaigns" disabled><?php esc_html_e('Find Existing Meta Campaigns', 'vms-meta-ads'); ?></button>
		          </div>
		          <p class="description"><?php esc_html_e('Use this when an ad was edited or created directly in Meta Ads Manager. Review matches before linking anything.', 'vms-meta-ads'); ?></p>
		          <div id="vms-ma-reconcile-results" class="vms-ma-reconcile-results" aria-live="polite"></div>
		        </div>
		      </div>
		      <p id="vms-ma-event-picker-warning" class="description vms-ma-inline-warning vms-ma-hidden"><?php esc_html_e('Choose an Event Plan first. This fills the rest automatically.', 'vms-meta-ads'); ?></p>
		      <p class="description vms-ma-beginner-copy"><?php esc_html_e('Do this now: pick your Event Plan from the dropdown. VMS autofills the rest.', 'vms-meta-ads'); ?></p>
		      <p class="description"><?php esc_html_e('New events are listed first. Anything that already has a saved draft or Meta ad is labeled and moved lower.', 'vms-meta-ads'); ?></p>
		      <p id="vms-ma-step-a-status" class="description" aria-live="polite"></p>
		      <p><button type="button" class="button button-secondary vms-ma-step-continue"><?php esc_html_e('Continue', 'vms-meta-ads'); ?></button></p>
		    </div>
		  </section>

		  <section id="vms-ma-step-b" class="vms-ma-section vms-ma-step vms-ma-card" data-step="strategy" data-step-key="B" data-step-index="2">
		    <div class="vms-ma-step-header vms-ma-step-head" role="button" tabindex="0" aria-expanded="false">
		      <h2 class="vms-ma-section-title"><?php esc_html_e('Step B - Strategy / Preset', 'vms-meta-ads'); ?></h2>
		      <span class="vms-ma-step-status" data-step-status><?php esc_html_e('Locked', 'vms-meta-ads'); ?></span>
		    </div>
		    <div class="vms-ma-step-body">
		      <div id="vms-ma-preset" class="vms-ma-grid-two" data-vms-tour="vms-ma-preset">
		        <label>
		          <span><?php esc_html_e('Campaign strategy', 'vms-meta-ads'); ?></span>
		          <select id="vms-ma-strategy-template" data-required-step="2">
		            <option value="custom"><?php esc_html_e('Custom / manual controls', 'vms-meta-ads'); ?></option>
		            <option value="clean_room_full_push_v2" selected><?php esc_html_e('Clean-Room Concert Campaign - Full Push v2', 'vms-meta-ads'); ?></option>
		            <option value="direct_create_safe_ticket_push"><?php esc_html_e('Simple one-ad test / troubleshooting recipe', 'vms-meta-ads'); ?></option>
		            <option value="clean_room_full_push"><?php esc_html_e('Clean-Room Concert Campaign - Full Push (legacy)', 'vms-meta-ads'); ?></option>
		            <option value="ticketed_video_local"><?php esc_html_e('Ticketed Concert - Video-Led Local Push', 'vms-meta-ads'); ?></option>
		            <option value="standard_ticket_push"><?php esc_html_e('Standard Ticket Push', 'vms-meta-ads'); ?></option>
		            <option value="last_minute_push"><?php esc_html_e('Last-Minute Push', 'vms-meta-ads'); ?></option>
		            <option value="low_budget_reminder"><?php esc_html_e('Low-Budget Local Reminder', 'vms-meta-ads'); ?></option>
		          </select>
		          <small class="description"><?php esc_html_e('Strategies apply safe defaults for ticket intent, pacing, placements, and review checks. You can still adjust fields below.', 'vms-meta-ads'); ?></small>
		        </label>
		        <label>
		          <span><?php esc_html_e('Preset mode', 'vms-meta-ads'); ?> <button type="button" class="vms-ma-info" aria-label="<?php esc_attr_e('Help for preset mode', 'vms-meta-ads'); ?>" data-help-id="ma_help_preset" data-auto-help="1" data-auto-help-target="#vms-ma-preset-mode" data-auto-help-default="<?php echo esc_attr((string) ($settings['vms_ma_default_preset'] ?? 'simple_14_day')); ?>">i</button></span>
		          <select id="vms-ma-preset-mode" data-vms-tour="vms-ma-preset-mode" data-required-step="2">
		            <option value="video_tribute_push"><?php esc_html_e('Video-Led Ticket Push (20/30/30/20)', 'vms-meta-ads'); ?></option>
		            <option value="flat_run"><?php esc_html_e('Flat run', 'vms-meta-ads'); ?></option>
		            <option value="promo_bundle_30_14_7"><?php esc_html_e('Promo Bundle 30/14/7', 'vms-meta-ads'); ?></option>
		            <option value="simple_7_day"><?php esc_html_e('Simple 7 day', 'vms-meta-ads'); ?></option>
		            <option value="simple_14_day"><?php esc_html_e('Simple 14 day', 'vms-meta-ads'); ?></option>
		            <option value="simple_30_day"><?php esc_html_e('Simple 30 day', 'vms-meta-ads'); ?></option>
		            <option value="manual_dates"><?php esc_html_e('Manual dates (Expert)', 'vms-meta-ads'); ?></option>
		          </select>
		        </label>
		        <label><span><?php esc_html_e('End ads this many hours before event', 'vms-meta-ads'); ?></span><input type="number" id="vms-ma-end_buffer_hours" min="0" step="1" value="2" data-required-step="2" /><small class="description"><?php esc_html_e('Most venues stop ads shortly before doors so you do not pay for late clicks.', 'vms-meta-ads'); ?></small></label>
		        <label data-advanced="1"><span><?php esc_html_e('Manual start (Expert)', 'vms-meta-ads'); ?></span><input type="datetime-local" id="vms-ma-manual-start" /></label>
		        <label data-advanced="1"><span><?php esc_html_e('Manual end (Expert)', 'vms-meta-ads'); ?></span><input type="datetime-local" id="vms-ma-manual-end" /></label>
		        <div class="vms-ma-how-scheduling description">
		          <strong><?php esc_html_e('How scheduling works', 'vms-meta-ads'); ?></strong><br />
		          <?php esc_html_e('1) Manual dates preset: manual start/end win. 2) Any other preset: VMS computes windows from preset. 3) End buffer always applies unless Manual dates is selected.', 'vms-meta-ads'); ?>
		        </div>
		        <div class="vms-ma-grid-three" data-advanced="1" id="vms-ma-custom-weight-wrap">
		          <label><span><?php esc_html_e('Weight 30 day %', 'vms-meta-ads'); ?></span><input type="number" id="vms-ma-weight_30" min="0" max="100" step="1" value="30" /></label>
		          <label><span><?php esc_html_e('Weight 14 day %', 'vms-meta-ads'); ?></span><input type="number" id="vms-ma-weight_14" min="0" max="100" step="1" value="30" /></label>
		          <label><span><?php esc_html_e('Weight 7 day %', 'vms-meta-ads'); ?></span><input type="number" id="vms-ma-weight_7" min="0" max="100" step="1" value="40" /></label>
		        </div>
		      </div>
		      <div id="vms-ma-strategy-summary" class="vms-ma-strategy-summary" aria-live="polite">
		        <div id="vms-ma-strategy-status" class="vms-ma-strategy-summary__overview"></div>
		        <div id="vms-ma-clean-room-checklist" class="vms-ma-clean-room-checklist vms-ma-hidden"></div>
                <div id="vms-ma-clean-room-options" class="vms-ma-clean-room-options vms-ma-hidden">
                  <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" id="vms-ma-include-outer-towns-adset" checked /> <span><?php esc_html_e('Include Outer Towns feed ad set', 'vms-meta-ads'); ?></span></label>
                  <p class="description"><?php esc_html_e('Turn this off only when you intentionally want the clean-room recipe to stay inside the core radius and video ad sets.', 'vms-meta-ads'); ?></p>
                  <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" id="vms-ma-include-right-column" /> <span><?php esc_html_e('Include optional Facebook Right Column support test', 'vms-meta-ads'); ?></span></label>
                  <p class="description"><?php esc_html_e('Use this only as a small desktop reminder placement. It is no longer part of the default campaign recipe.', 'vms-meta-ads'); ?></p>
                </div>
		      </div>
              <div id="vms-ma-recipe-preview" class="vms-ma-recipe-preview vms-ma-hidden" aria-live="polite"></div>
		      <p id="vms-ma-step-b-status" class="description" aria-live="polite"></p>
		      <p><button type="button" class="button button-secondary vms-ma-step-continue"><?php esc_html_e('Continue', 'vms-meta-ads'); ?></button></p>
		    </div>
		  </section>
 
		  <section id="vms-ma-step-c" class="vms-ma-section vms-ma-step vms-ma-card" data-step="creative" data-step-key="C" data-step-index="3">
		    <div class="vms-ma-step-header vms-ma-step-head" role="button" tabindex="0" aria-expanded="false">
		      <h2 class="vms-ma-section-title"><?php esc_html_e('Step C - Creative Mode', 'vms-meta-ads'); ?></h2>
		      <div class="vms-ma-step-head-actions">
		        <button type="button" class="button-link vms-ma-advanced-toggle"><?php esc_html_e('Advanced', 'vms-meta-ads'); ?></button>
		        <span class="vms-ma-step-status" data-step-status><?php esc_html_e('Locked', 'vms-meta-ads'); ?></span>
		      </div>
		    </div>
		    <div class="vms-ma-step-body">
		      <div class="vms-ma-inline-card vms-ma-creative-mode-summary">
		        <strong><?php esc_html_e('Current creative mode: Dark Post Link Ad', 'vms-meta-ads'); ?></strong>
		        <p class="description"><?php esc_html_e('This is the recommended and supported mode for Phase 1. Other creative modes stay visible as future/advanced paths so the normal builder flow is unambiguous.', 'vms-meta-ads'); ?></p>
		      </div>
		      <fieldset class="vms-ma-choice-group vms-ma-choice-group-cards" id="vms-ma-creative-mode-group">
		        <legend class="screen-reader-text"><?php esc_html_e('Creative mode', 'vms-meta-ads'); ?></legend>
		        <label class="vms-ma-choice vms-ma-choice-card vms-ma-choice-card--current" data-vms-tour="vms-ma-creative-dark">
		          <input type="radio" id="vms-ma-creative-dark" name="vms_ma_creative_mode" value="dark_post" checked data-required-step="3" />
		          <span><strong><?php esc_html_e('Dark Post Link Ad', 'vms-meta-ads'); ?></strong> <span class="vms-ma-tag"><?php esc_html_e('Current mode', 'vms-meta-ads'); ?></span> <button type="button" class="vms-ma-info" aria-label="<?php esc_attr_e('Help for dark post mode', 'vms-meta-ads'); ?>" data-help-id="ma_help_dark_post" data-auto-help="1" data-auto-help-target="#vms-ma-creative-dark">i</button><small><?php esc_html_e('Single supported operator path for this phase.', 'vms-meta-ads'); ?></small></span>
		        </label>
		        <label class="vms-ma-choice vms-ma-choice-card is-disabled">
		          <input type="radio" id="vms-ma-creative-boost" name="vms_ma_creative_mode" value="boost_post" disabled />
		          <span><strong><?php esc_html_e('Boost Existing Post', 'vms-meta-ads'); ?></strong> <span class="vms-ma-tag"><?php esc_html_e('Future / advanced', 'vms-meta-ads'); ?></span><small><?php esc_html_e('Not part of the normal Phase 1 builder flow.', 'vms-meta-ads'); ?></small></span>
		        </label>
		        <label class="vms-ma-choice vms-ma-choice-card is-disabled">
		          <input type="radio" id="vms-ma-creative-event" name="vms_ma_creative_mode" value="fb_event" disabled />
		          <span><strong><?php esc_html_e('Promote Facebook Event', 'vms-meta-ads'); ?></strong> <span class="vms-ma-tag"><?php esc_html_e('Future / advanced', 'vms-meta-ads'); ?></span><small><?php esc_html_e('Visible for roadmap context only in this phase.', 'vms-meta-ads'); ?></small></span>
		        </label>
		      </fieldset>
		      <p><button type="button" class="button-link" id="vms-ma-copy_regen"><?php esc_html_e('Regenerate from event', 'vms-meta-ads'); ?></button></p>
		      <div id="vms-ma-creative-dark-fields" class="vms-ma-creative-fields vms-ma-creative-fields--dark vms-ma-grid-two" data-mode="dark_post">
		        <label><span><?php esc_html_e('Variant 1 - Primary text', 'vms-meta-ads'); ?></span><textarea id="vms-ma-primary-text" name="primary_text" rows="2"></textarea></label>
		        <label><span><?php esc_html_e('Variant 1 - Headline', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-headline" name="headline" value="" /></label>
		        <label><span><?php esc_html_e('Variant 1 - Description', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-description" name="description" value="" /></label>
		      </div>
		      <div class="vms-ma-image-fields" id="vms-ma-image-fields">
		        <div class="vms-ma-image-fields__head">
		          <h3 class="vms-ma-subtitle"><?php esc_html_e('Default Shared Media', 'vms-meta-ads'); ?></h3>
		          <p class="description"><?php esc_html_e('Start here. Variant 1 and any other variant set to Shared media will use these images. Video placeholder variants also use these images at creation time so you can upload or swap the actual video directly in Meta without storing video files on the website.', 'vms-meta-ads'); ?></p>
		        </div>
		        <div class="vms-ma-grid-two">
		          <div class="vms-ma-image-picker" data-image-kind="square">
		            <div class="vms-ma-image-picker-head"><strong><?php esc_html_e('Square (1:1) — feeds', 'vms-meta-ads'); ?></strong></div>
		            <div class="vms-ma-image-picker-row">
		              <img src="" alt="" class="vms-ma-image-preview vms-ma-hidden" id="vms-ma-image-square-preview"  />
		              <input type="hidden" id="vms-ma-image-square-id" value="0" />
		              <button type="button" id="vms-ma-image-square-choose" class="button button-secondary vms-ma-pick-image" data-target="square"><?php esc_html_e('Choose', 'vms-meta-ads'); ?></button>
		              <button type="button" id="vms-ma-image-square-clear" class="button vms-ma-clear-image" data-target="square"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		            </div>
		          </div>
		          <div class="vms-ma-image-picker" data-image-kind="vertical">
		            <div class="vms-ma-image-picker-head"><strong><?php esc_html_e('Vertical (9:16) — stories/reels', 'vms-meta-ads'); ?></strong></div>
		            <div class="vms-ma-image-picker-row">
		              <img src="" alt="" class="vms-ma-image-preview vms-ma-hidden" id="vms-ma-image-vertical-preview"  />
		              <input type="hidden" id="vms-ma-image-vertical-id" value="0" />
		              <button type="button" id="vms-ma-image-vertical-choose" class="button button-secondary vms-ma-pick-image" data-target="vertical"><?php esc_html_e('Choose', 'vms-meta-ads'); ?></button>
		              <button type="button" id="vms-ma-image-vertical-clear" class="button vms-ma-clear-image" data-target="vertical"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		            </div>
		          </div>
		          <div class="vms-ma-image-picker" data-image-kind="wide">
		            <div class="vms-ma-image-picker-head"><strong><?php esc_html_e('Wide (1.91:1) — optional', 'vms-meta-ads'); ?></strong></div>
		            <div class="vms-ma-image-picker-row">
		              <img src="" alt="" class="vms-ma-image-preview vms-ma-hidden" id="vms-ma-image-wide-preview"  />
		              <input type="hidden" id="vms-ma-image-wide-id" value="0" />
		              <button type="button" id="vms-ma-image-wide-choose" class="button button-secondary vms-ma-pick-image" data-target="wide"><?php esc_html_e('Choose', 'vms-meta-ads'); ?></button>
		              <button type="button" id="vms-ma-image-wide-clear" class="button vms-ma-clear-image" data-target="wide"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		            </div>
		          </div>
		        </div>
<p class="description vms-ma-image-fields__footnote"><?php esc_html_e('If you leave these blank, the builder will fall back to the event featured image when available.', 'vms-meta-ads'); ?></p>
		      </div>
		      <div id="vms-ma-creative-format-card" class="vms-ma-creative-format-card" aria-live="polite">
		        <div class="vms-ma-creative-format-card__head">
		          <h3 class="vms-ma-subtitle"><?php esc_html_e('Creative formats needed', 'vms-meta-ads'); ?></h3>
		          <p class="description"><?php esc_html_e('MAB checks the creative format needed for each placement group before you create paused assets in Meta.', 'vms-meta-ads'); ?></p>
		        </div>
		        <div class="vms-ma-grid-two vms-ma-creative-format-controls">
		          <label><span><?php esc_html_e('Video shape', 'vms-meta-ads'); ?></span>
		            <select id="vms-ma-video-format">
		              <option value="unknown"><?php esc_html_e('Unknown / review in Meta', 'vms-meta-ads'); ?></option>
		              <option value="tall_9_16"><?php esc_html_e('Tall / 9:16', 'vms-meta-ads'); ?></option>
		              <option value="square_1_1"><?php esc_html_e('Square / 1:1', 'vms-meta-ads'); ?></option>
		              <option value="wide_16_9"><?php esc_html_e('Wide / 16:9', 'vms-meta-ads'); ?></option>
		              <option value="meta_direct_vertical"><?php esc_html_e('Meta-direct vertical placeholder', 'vms-meta-ads'); ?></option>
		            </select>
		            <small class="description"><?php esc_html_e('Use this when the actual video will be uploaded or swapped inside Meta Ads Manager.', 'vms-meta-ads'); ?></small>
		          </label>
		          <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" id="vms-ma-require-vertical-video" /> <span><?php esc_html_e('Require tall video before Create in Meta', 'vms-meta-ads'); ?></span></label>
		        </div>
		        <div id="vms-ma-creative-format-slots" class="vms-ma-creative-format-slots"></div>
		      </div>
		      <div class="vms-ma-variant-stack" id="vms-ma-variant-stack">
		        <div class="vms-ma-variant-stack__head">
		          <h3 class="vms-ma-subtitle"><?php esc_html_e('Ad Variants', 'vms-meta-ads'); ?></h3>
		          <p class="description"><?php esc_html_e('Each variant becomes its own ad inside the matching recipe ad set. In v2, static square/feed creative, 1:1 feed video, and portrait Reels/Stories video are separated by ad set. For video variants, use Placement intent so MAB routes square video to Feed and portrait video to Reels/Stories. Use Video placeholder to create the ad structure with a thumbnail/placeholder, then upload or swap the actual video directly inside Meta Ads Manager.', 'vms-meta-ads'); ?></p>
		        </div>
		        <div class="vms-ma-variant-grid">
		          <article class="vms-ma-variant-card">
		            <header class="vms-ma-variant-card__header"><strong><?php esc_html_e('Variant 1', 'vms-meta-ads'); ?></strong><span class="vms-ma-mini-tag"><?php esc_html_e('Main', 'vms-meta-ads'); ?></span></header>
		            <label><span><?php esc_html_e('Media source', 'vms-meta-ads'); ?></span>
		              <select id="vms-ma-variant-1-media-mode">
		                <option value="shared"><?php esc_html_e('Use default shared media', 'vms-meta-ads'); ?></option>
		                <option value="image"><?php esc_html_e('Use a different single image', 'vms-meta-ads'); ?></option>
		                <option value="video_placeholder"><?php esc_html_e('Video placeholder - upload video in Meta', 'vms-meta-ads'); ?></option>
		                <option value="video"><?php esc_html_e('Upload WordPress video to Meta (legacy)', 'vms-meta-ads'); ?></option>
		              </select>
		            </label>
		            <label><span><?php esc_html_e('Placement intent', 'vms-meta-ads'); ?></span>
		              <select id="vms-ma-variant-1-placement-slot">
		                <option value="auto"><?php esc_html_e('Auto / normal', 'vms-meta-ads'); ?></option>
		                <option value="feed_square_video"><?php esc_html_e('Feed square video (1:1)', 'vms-meta-ads'); ?></option>
		                <option value="reels_stories_video"><?php esc_html_e('Reels/Stories portrait video (9:16)', 'vms-meta-ads'); ?></option>
		              </select>
		            </label>
		            <div class="vms-ma-variant-source-note" id="vms-ma-variant-1-media-note"><?php esc_html_e('Uses Default Shared Media above.', 'vms-meta-ads'); ?></div>
		            <div class="vms-ma-variant-media-picker vms-ma-hidden" id="vms-ma-variant-1-image-wrap">
		              <input type="hidden" id="vms-ma-variant-1-image-id" value="0" />
		              <div class="vms-ma-media-pill" id="vms-ma-variant-1-image-name"><?php esc_html_e('No custom image selected.', 'vms-meta-ads'); ?></div>
		              <div class="vms-ma-media-picker-actions">
		                <button type="button" class="button button-secondary vms-ma-pick-variant-media" data-variant="1" data-media-type="image"><?php esc_html_e('Choose Image', 'vms-meta-ads'); ?></button>
		                <button type="button" class="button vms-ma-clear-variant-media" data-variant="1" data-media-type="image"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		              </div>
		            </div>
		            <div class="vms-ma-variant-media-picker vms-ma-hidden" id="vms-ma-variant-1-video-wrap">
		              <input type="hidden" id="vms-ma-variant-1-video-id" value="0" />
		              <div class="vms-ma-media-pill" id="vms-ma-variant-1-video-name"><?php esc_html_e('No video selected.', 'vms-meta-ads'); ?></div>
		              <div class="vms-ma-media-picker-actions">
		                <button type="button" class="button button-secondary vms-ma-pick-variant-media" data-variant="1" data-media-type="video"><?php esc_html_e('Choose Video', 'vms-meta-ads'); ?></button>
		                <button type="button" class="button vms-ma-clear-variant-media" data-variant="1" data-media-type="video"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		              </div>
		            </div>
		          </article>
		          <article class="vms-ma-variant-card">
		            <header class="vms-ma-variant-card__header"><strong><?php esc_html_e('Variant 2', 'vms-meta-ads'); ?></strong><span class="vms-ma-mini-tag"><?php esc_html_e('Optional', 'vms-meta-ads'); ?></span></header>
		            <label><span><?php esc_html_e('Label', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-variant-2-label" value="Variant 2" /></label>
		            <label><span><?php esc_html_e('Primary text', 'vms-meta-ads'); ?></span><textarea id="vms-ma-variant-2-primary" rows="2"></textarea></label>
		            <label><span><?php esc_html_e('Headline', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-variant-2-headline" value="" /></label>
		            <label><span><?php esc_html_e('Description', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-variant-2-description" value="" /></label>
		            <label><span><?php esc_html_e('Media source', 'vms-meta-ads'); ?></span>
		              <select id="vms-ma-variant-2-media-mode">
		                <option value="shared"><?php esc_html_e('Use default shared media', 'vms-meta-ads'); ?></option>
		                <option value="image"><?php esc_html_e('Use a different single image', 'vms-meta-ads'); ?></option>
		                <option value="video_placeholder"><?php esc_html_e('Video placeholder - upload video in Meta', 'vms-meta-ads'); ?></option>
		                <option value="video"><?php esc_html_e('Upload WordPress video to Meta (legacy)', 'vms-meta-ads'); ?></option>
		              </select>
		            </label>
		            <label><span><?php esc_html_e('Placement intent', 'vms-meta-ads'); ?></span>
		              <select id="vms-ma-variant-2-placement-slot">
		                <option value="auto"><?php esc_html_e('Auto / normal', 'vms-meta-ads'); ?></option>
		                <option value="feed_square_video"><?php esc_html_e('Feed square video (1:1)', 'vms-meta-ads'); ?></option>
		                <option value="reels_stories_video"><?php esc_html_e('Reels/Stories portrait video (9:16)', 'vms-meta-ads'); ?></option>
		              </select>
		            </label>
		            <div class="vms-ma-variant-source-note" id="vms-ma-variant-2-media-note"><?php esc_html_e('Uses Default Shared Media above unless you switch it.', 'vms-meta-ads'); ?></div>
		            <div class="vms-ma-variant-media-picker vms-ma-hidden" id="vms-ma-variant-2-image-wrap">
		              <input type="hidden" id="vms-ma-variant-2-image-id" value="0" />
		              <div class="vms-ma-media-pill" id="vms-ma-variant-2-image-name"><?php esc_html_e('No custom image selected.', 'vms-meta-ads'); ?></div>
		              <div class="vms-ma-media-picker-actions">
		                <button type="button" class="button button-secondary vms-ma-pick-variant-media" data-variant="2" data-media-type="image"><?php esc_html_e('Choose Image', 'vms-meta-ads'); ?></button>
		                <button type="button" class="button vms-ma-clear-variant-media" data-variant="2" data-media-type="image"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		              </div>
		            </div>
		            <div class="vms-ma-variant-media-picker vms-ma-hidden" id="vms-ma-variant-2-video-wrap">
		              <input type="hidden" id="vms-ma-variant-2-video-id" value="0" />
		              <div class="vms-ma-media-pill" id="vms-ma-variant-2-video-name"><?php esc_html_e('No video selected.', 'vms-meta-ads'); ?></div>
		              <div class="vms-ma-media-picker-actions">
		                <button type="button" class="button button-secondary vms-ma-pick-variant-media" data-variant="2" data-media-type="video"><?php esc_html_e('Choose Video', 'vms-meta-ads'); ?></button>
		                <button type="button" class="button vms-ma-clear-variant-media" data-variant="2" data-media-type="video"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		              </div>
		            </div>
		          </article>
		          <article class="vms-ma-variant-card">
		            <header class="vms-ma-variant-card__header"><strong><?php esc_html_e('Variant 3', 'vms-meta-ads'); ?></strong><span class="vms-ma-mini-tag"><?php esc_html_e('Optional', 'vms-meta-ads'); ?></span></header>
		            <label><span><?php esc_html_e('Label', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-variant-3-label" value="Variant 3" /></label>
		            <label><span><?php esc_html_e('Primary text', 'vms-meta-ads'); ?></span><textarea id="vms-ma-variant-3-primary" rows="2"></textarea></label>
		            <label><span><?php esc_html_e('Headline', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-variant-3-headline" value="" /></label>
		            <label><span><?php esc_html_e('Description', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-variant-3-description" value="" /></label>
		            <label><span><?php esc_html_e('Media source', 'vms-meta-ads'); ?></span>
		              <select id="vms-ma-variant-3-media-mode">
		                <option value="shared"><?php esc_html_e('Use default shared media', 'vms-meta-ads'); ?></option>
		                <option value="image"><?php esc_html_e('Use a different single image', 'vms-meta-ads'); ?></option>
		                <option value="video_placeholder"><?php esc_html_e('Video placeholder - upload video in Meta', 'vms-meta-ads'); ?></option>
		                <option value="video"><?php esc_html_e('Upload WordPress video to Meta (legacy)', 'vms-meta-ads'); ?></option>
		              </select>
		            </label>
		            <label><span><?php esc_html_e('Placement intent', 'vms-meta-ads'); ?></span>
		              <select id="vms-ma-variant-3-placement-slot">
		                <option value="auto"><?php esc_html_e('Auto / normal', 'vms-meta-ads'); ?></option>
		                <option value="feed_square_video"><?php esc_html_e('Feed square video (1:1)', 'vms-meta-ads'); ?></option>
		                <option value="reels_stories_video"><?php esc_html_e('Reels/Stories portrait video (9:16)', 'vms-meta-ads'); ?></option>
		              </select>
		            </label>
		            <div class="vms-ma-variant-source-note" id="vms-ma-variant-3-media-note"><?php esc_html_e('Uses Default Shared Media above unless you switch it.', 'vms-meta-ads'); ?></div>
		            <div class="vms-ma-variant-media-picker vms-ma-hidden" id="vms-ma-variant-3-image-wrap">
		              <input type="hidden" id="vms-ma-variant-3-image-id" value="0" />
		              <div class="vms-ma-media-pill" id="vms-ma-variant-3-image-name"><?php esc_html_e('No custom image selected.', 'vms-meta-ads'); ?></div>
		              <div class="vms-ma-media-picker-actions">
		                <button type="button" class="button button-secondary vms-ma-pick-variant-media" data-variant="3" data-media-type="image"><?php esc_html_e('Choose Image', 'vms-meta-ads'); ?></button>
		                <button type="button" class="button vms-ma-clear-variant-media" data-variant="3" data-media-type="image"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		              </div>
		            </div>
		            <div class="vms-ma-variant-media-picker vms-ma-hidden" id="vms-ma-variant-3-video-wrap">
		              <input type="hidden" id="vms-ma-variant-3-video-id" value="0" />
		              <div class="vms-ma-media-pill" id="vms-ma-variant-3-video-name"><?php esc_html_e('No video selected.', 'vms-meta-ads'); ?></div>
		              <div class="vms-ma-media-picker-actions">
		                <button type="button" class="button button-secondary vms-ma-pick-variant-media" data-variant="3" data-media-type="video"><?php esc_html_e('Choose Video', 'vms-meta-ads'); ?></button>
		                <button type="button" class="button vms-ma-clear-variant-media" data-variant="3" data-media-type="video"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		              </div>
		            </div>
		          </article>
		        </div>
		      </div>
		      <div id="vms-ma-creative-boost-fields" class="vms-ma-creative-fields vms-ma-creative-fields--boost" data-mode="boost_post" data-advanced="1">
		        <label id="vms-ma-post-picker-wrap" class="vms-ma-hidden"><span><?php esc_html_e('Find existing post', 'vms-meta-ads'); ?></span><select id="vms-ma-post-picker"><option value=""><?php esc_html_e('Select a recent post...', 'vms-meta-ads'); ?></option></select></label>
		        <label id="vms-ma-post-url-wrap"><span><?php esc_html_e('Paste Facebook post URL or ID', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-post-url" placeholder="https://facebook.com/.../posts/..." /></label>
		        <input type="hidden" id="vms-ma-post-id" name="post_asset_id" value="" />
		      </div>
		      <div id="vms-ma-creative-event-fields" class="vms-ma-creative-fields vms-ma-creative-fields--fb-event" data-mode="fb_event" data-advanced="1">
		        <label id="vms-ma-fb-event-picker-wrap" class="vms-ma-hidden"><span><?php esc_html_e('Find Facebook Event', 'vms-meta-ads'); ?></span><select id="vms-ma-fb-event-picker"><option value=""><?php esc_html_e('Select upcoming event...', 'vms-meta-ads'); ?></option></select></label>
		        <label id="vms-ma-fb-event-url-wrap"><span><?php esc_html_e('Paste Facebook Event URL or ID', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-fb-event-url" placeholder="https://facebook.com/events/..." /></label>
		        <input type="hidden" id="vms-ma-fb-event-id" name="facebook_event_id" value="" />
		      </div>
			      <div class="vms-ma-grid-two" id="vms-ma-cta-wrap">
			        <label><span><?php esc_html_e('Call to action', 'vms-meta-ads'); ?></span>
			          <select id="vms-ma-cta-type" name="cta_type" data-required-step="3">
			            <option value="BUY_TICKETS" selected><?php esc_html_e('Buy Tickets', 'vms-meta-ads'); ?></option>
			            <option value="GET_TICKETS"><?php esc_html_e('Get Tickets', 'vms-meta-ads'); ?></option>
			            <option value="LEARN_MORE"><?php esc_html_e('Learn More', 'vms-meta-ads'); ?></option>
			          </select>
			          <small class="description"><?php esc_html_e('For ticketed concerts, Buy Tickets is the preferred intent signal and should not be left to Meta defaults.', 'vms-meta-ads'); ?></small>
			          <small id="vms-ma-cta-lock-status" class="description vms-ma-cta-lock-status" aria-live="polite"></small>
			        </label>
			      </div>
			      <div class="vms-ma-grid-two vms-ma-meta-control-grid" data-advanced="1">
			        <label><span><?php esc_html_e('Advantage+ creative policy', 'vms-meta-ads'); ?></span>
			          <select id="vms-ma-creative-automation-policy">
		            <option value="off" selected><?php esc_html_e('Off / preserve creative', 'vms-meta-ads'); ?></option>
		            <option value="conservative"><?php esc_html_e('Conservative review', 'vms-meta-ads'); ?></option>
		            <option value="meta_optimized"><?php esc_html_e('Allow Meta-optimized', 'vms-meta-ads'); ?></option>
			          </select>
			          <small class="description"><?php esc_html_e('Captured in the review checklist so Meta enhancements, music, and layout changes are intentional.', 'vms-meta-ads'); ?></small>
			        </label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" id="vms-ma-multi-advertiser-ads" /> <span><?php esc_html_e('Allow multi-advertiser ads', 'vms-meta-ads'); ?></span><small class="description"><?php esc_html_e('Default off for concert ticket campaigns unless you intentionally want Meta to show the ad beside other advertisers.', 'vms-meta-ads'); ?></small></label>
		        <label class="vms-ma-choice vms-ma-inline-choice vms-ma-cta-override-choice"><input type="checkbox" id="vms-ma-force-buy-tickets" checked /> <span><?php esc_html_e('Keep strategy CTA lock (advanced)', 'vms-meta-ads'); ?></span><small class="description"><?php esc_html_e('Turn this off only if you intentionally need to review a different CTA later.', 'vms-meta-ads'); ?></small></label>
			      </div>
		      <div class="vms-ma-inline-card vms-ma-creative-lockdown-card">
		        <strong><?php esc_html_e('Creative Lockdown Mode', 'vms-meta-ads'); ?></strong>
		        <p class="description"><?php esc_html_e('MAB treats your selected image/video, ticket URL, and disabled enhancement settings as the source of truth. Go Live is blocked until manual Meta QA confirms no website images, Advantage+ creative changes, Dynamic/Flexible creative, or multi-advertiser placement snuck back in.', 'vms-meta-ads'); ?></p>
		      </div>
		      <p id="vms-ma-step-c-status" class="description" aria-live="polite"></p>
		      <p><button type="button" class="button button-secondary vms-ma-step-continue"><?php esc_html_e('Continue', 'vms-meta-ads'); ?></button></p>
		    </div>
		  </section>

		  <section id="vms-ma-step-d" class="vms-ma-section vms-ma-step vms-ma-card" data-step="audience" data-step-key="D" data-step-index="4">
		    <div class="vms-ma-step-header vms-ma-step-head" role="button" tabindex="0" aria-expanded="false">
		      <h2 class="vms-ma-section-title"><?php esc_html_e('Step D - Audience', 'vms-meta-ads'); ?></h2>
		      <div class="vms-ma-step-head-actions">
		        <button type="button" class="button-link vms-ma-advanced-toggle"><?php esc_html_e('Advanced', 'vms-meta-ads'); ?></button>
		        <span class="vms-ma-step-status" data-step-status><?php esc_html_e('Locked', 'vms-meta-ads'); ?></span>
		      </div>
		    </div>
		    <div class="vms-ma-step-body">
		      <div class="vms-ma-grid-two">
		        <label id="vms-ma-radius-wrap" data-vms-tour="vms-ma-radius"><span><?php esc_html_e('Radius (miles)', 'vms-meta-ads'); ?> <button type="button" class="vms-ma-info" aria-label="<?php esc_attr_e('Help for radius', 'vms-meta-ads'); ?>" data-help-id="ma_help_radius" data-auto-help="1" data-auto-help-target="#vms-ma-radius" data-auto-help-default="<?php echo esc_attr((int) $settings['default_radius_miles']); ?>">i</button></span><input type="number" id="vms-ma-radius" min="1" max="<?php echo esc_attr((int) ($settings['max_radius_miles'] ?? 100)); ?>" value="<?php echo esc_attr((int) $settings['default_radius_miles']); ?>" data-required-step="4" /></label>
		        <label><span><?php esc_html_e('Age min', 'vms-meta-ads'); ?> <button type="button" class="vms-ma-info" aria-label="<?php esc_attr_e('Help for age range', 'vms-meta-ads'); ?>" data-help-id="ma_help_age" data-auto-help="1" data-auto-help-target="#vms-ma-age-min" data-auto-help-default="<?php echo esc_attr((int) $settings['default_age_min']); ?>">i</button></span><input type="number" id="vms-ma-age-min" inputmode="numeric" value="<?php echo esc_attr((int) $settings['default_age_min']); ?>" data-required-step="4" /></label>
		        <label><span><?php esc_html_e('Age max', 'vms-meta-ads'); ?></span><select id="vms-ma-age-max" data-required-step="4"><?php foreach ($age_options as $age_opt) : ?><option value="<?php echo esc_attr((string) $age_opt); ?>" <?php selected($age_max_default, $age_opt); ?>><?php echo esc_html($age_opt === 65 ? '65+' : (string) $age_opt); ?></option><?php endforeach; ?></select></label>
		        <label><span><?php esc_html_e('Gender', 'vms-meta-ads'); ?></span>
		          <select id="vms-ma-gender">
		            <option value="all"><?php esc_html_e('All genders', 'vms-meta-ads'); ?></option>
		            <option value="women"><?php esc_html_e('Women', 'vms-meta-ads'); ?></option>
		            <option value="men"><?php esc_html_e('Men', 'vms-meta-ads'); ?></option>
		          </select>
		        </label>
		      </div>
		      <div class="vms-ma-audience-targeting-shell">
		        <div class="vms-ma-grid-two vms-ma-audience-card-grid">
		          <section class="vms-ma-inline-card vms-ma-audience-card">
		            <h3><?php esc_html_e('Audience Mode', 'vms-meta-ads'); ?></h3>
		            <fieldset class="vms-ma-choice-group vms-ma-choice-group-cards">
		              <label class="vms-ma-choice vms-ma-choice-card"><input type="radio" name="vms_ma_audience_mode" value="broad_local" checked /> <span><?php esc_html_e('Broad/local audience', 'vms-meta-ads'); ?><small><?php esc_html_e('Radius, age, gender, and placements only.', 'vms-meta-ads'); ?></small></span></label>
		              <label class="vms-ma-choice vms-ma-choice-card"><input type="radio" name="vms_ma_audience_mode" value="interest_guided" /> <span><?php esc_html_e('Interest-guided audience', 'vms-meta-ads'); ?><small><?php esc_html_e('Adds curated interest and behavior hints.', 'vms-meta-ads'); ?></small></span></label>
		              <label class="vms-ma-choice vms-ma-choice-card is-disabled"><input type="radio" name="vms_ma_audience_mode" value="retargeting" disabled /> <span><?php esc_html_e('Past-engagement / retargeting', 'vms-meta-ads'); ?><small><?php esc_html_e('Future phase', 'vms-meta-ads'); ?></small></span></label>
		              <label class="vms-ma-choice vms-ma-choice-card is-disabled"><input type="radio" name="vms_ma_audience_mode" value="lookalike" disabled /> <span><?php esc_html_e('Lookalike audience', 'vms-meta-ads'); ?><small><?php esc_html_e('Future phase', 'vms-meta-ads'); ?></small></span></label>
		            </fieldset>
		            <div class="vms-ma-grid-two">
			              <label><span><?php esc_html_e('Audience style', 'vms-meta-ads'); ?></span>
			                <select id="vms-ma-audience-event-type">
			                  <option value="ticketed_concert"><?php esc_html_e('Ticketed concert', 'vms-meta-ads'); ?></option>
			                  <option value="tribute_show"><?php esc_html_e('Tribute / themed show', 'vms-meta-ads'); ?></option>
		                  <option value="festival"><?php esc_html_e('Festival / seasonal event', 'vms-meta-ads'); ?></option>
		                  <option value="family_community"><?php esc_html_e('Family / community event', 'vms-meta-ads'); ?></option>
		                  <option value="venue_awareness"><?php esc_html_e('Venue awareness', 'vms-meta-ads'); ?></option>
			                  <option value="other"><?php esc_html_e('Other', 'vms-meta-ads'); ?></option>
			                </select>
			              </label>
			              <label><span><?php esc_html_e('Audience preset', 'vms-meta-ads'); ?></span>
			                <select id="vms-ma-audience-preset">
			                  <option value=""><?php esc_html_e('Choose an editable preset', 'vms-meta-ads'); ?></option>
			                </select>
			                <small class="description"><?php esc_html_e('Selecting a preset fills the current audience fields immediately, and you can edit everything after it loads.', 'vms-meta-ads'); ?></small>
			              </label>
			            </div>
			            <p id="vms-ma-audience-preset-status" class="description"></p>
		            <div class="vms-ma-grid-two">
		              <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" id="vms-ma-advantage-audience" value="1" /> <span><?php esc_html_e('Store Advantage+ audience expansion preference', 'vms-meta-ads'); ?></span></label>
		              <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" id="vms-ma-advantage-detailed-targeting" value="1" /> <span><?php esc_html_e('Store detailed targeting expansion preference', 'vms-meta-ads'); ?></span></label>
		            </div>
		            <p class="description"><?php esc_html_e('These controls are saved for later Meta write paths. They are off by default and are not force-enabled tonight.', 'vms-meta-ads'); ?></p>
		          </section>
		          <section class="vms-ma-inline-card vms-ma-audience-card">
		            <h3><?php esc_html_e('Interest Suggestions', 'vms-meta-ads'); ?></h3>
		            <p class="description"><?php esc_html_e('These are saved as targeting ideas first. MAB will only send validated Meta IDs later.', 'vms-meta-ads'); ?></p>
		            <div class="vms-ma-audience-artist-row">
		              <label class="vms-ma-audience-artist-field"><span><?php esc_html_e('Artist / band inspiration', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-artist-inspiration-input" placeholder="<?php esc_attr_e('Type artist or band names, separated by commas', 'vms-meta-ads'); ?>" /></label>
		              <p><button type="button" class="button button-secondary" id="vms-ma-artist-inspiration-add"><?php esc_html_e('Add inspiration', 'vms-meta-ads'); ?></button></p>
		            </div>
		            <p class="description"><?php esc_html_e('Examples: Jimmy Buffett, George Strait, Fleetwood Mac', 'vms-meta-ads'); ?></p>
		            <div id="vms-ma-artist-inspiration-list" class="vms-ma-audience-token-list" aria-live="polite"></div>
		            <div id="vms-ma-audience-suggestion-groups" class="vms-ma-audience-suggestion-groups"></div>
		            <label data-advanced="1"><span><?php esc_html_e('Manual targeting labels (advanced)', 'vms-meta-ads'); ?> <button type="button" class="vms-ma-info" aria-label="<?php esc_attr_e('Help for interests', 'vms-meta-ads'); ?>" data-help-id="ma_help_interests">i</button></span><input type="text" id="vms-ma-interests" placeholder="<?php esc_attr_e('Live music, local events, country music', 'vms-meta-ads'); ?>" /></label>
		            <small class="description"><?php esc_html_e('Comma-separated labels are stored as suggested labels only. They are not treated as Meta-ready targeting until validated later.', 'vms-meta-ads'); ?></small>
		            <div id="vms-ma-audience-selected-terms" class="vms-ma-audience-token-list" aria-live="polite"></div>
		          </section>
		        </div>
		        <section class="vms-ma-inline-card vms-ma-audience-card vms-ma-audience-preview-card">
		          <h3><?php esc_html_e('Targeting Preview', 'vms-meta-ads'); ?></h3>
		          <div id="vms-ma-targeting-preview" class="vms-ma-audience-preview" aria-live="polite"></div>
		          <div id="vms-ma-targeting-preview-warnings" class="vms-ma-audience-warning-list" aria-live="polite"></div>
		        </section>
		      </div>
		      <div class="vms-ma-manual-entry">
		        <label><span><?php esc_html_e('Primary targeting address or ZIP', 'vms-meta-ads'); ?></span>
		          <input type="text" id="vms-ma-targeting-address" placeholder="4021 S State Hwy 161, Grand Prairie, TX 75052" />
		          <small class="description"><?php esc_html_e('Editable primary radius anchor. VMS prefills this from the selected Event Plan venue address when exact venue address, ZIP, or coordinates are available.', 'vms-meta-ads'); ?></small>
		          <small id="vms-ma-targeting-address-status" class="description"></small>
		        </label>
		        <label><span><?php esc_html_e('Additional locations for the core audience (optional)', 'vms-meta-ads'); ?></span>
		          <textarea id="vms-ma-locations" rows="3" placeholder="4021 S State Hwy 161, Grand Prairie, TX 75052 | 20
75052 | 15"></textarea>
		          <small class="description"><?php esc_html_e('Optional extra full addresses or ZIPs for non-recipe/legacy audience builds. Clean-room Outer Towns uses the dedicated field to the right.', 'vms-meta-ads'); ?></small>
		        </label>
		        <label><span><?php esc_html_e('Outer Towns targeting mode', 'vms-meta-ads'); ?></span>
		          <select id="vms-ma-outer-towns-mode">
		            <option value="listed_only" selected><?php esc_html_e('Listed towns/cities/ZIPs only', 'vms-meta-ads'); ?></option>
		            <option value="expanded_radius"><?php esc_html_e('Expanded outer radius', 'vms-meta-ads'); ?></option>
		          </select>
		          <small class="description"><?php esc_html_e('Listed-only keeps the Outer Towns ad set from quietly overlapping the core venue radius. Enter the outer cities, ZIPs, or full addresses in the dedicated field below.', 'vms-meta-ads'); ?></small>
		        </label>
		        <label><span><?php esc_html_e('Outer Towns default radius', 'vms-meta-ads'); ?></span>
		          <input type="number" id="vms-ma-outer-default-radius" min="1" max="250" value="15" />
		          <small class="description"><?php esc_html_e('Used for Outer Towns lines without their own | miles value.', 'vms-meta-ads'); ?></small>
		        </label>
		        <label class="vms-ma-outer-towns-field"><span><?php esc_html_e('Outer Towns locations (one per line)', 'vms-meta-ads'); ?></span>
		          <textarea id="vms-ma-outer-locations" rows="4" placeholder="Athens, Texas | 15
Henderson, Texas | 15
Jacksonville, Texas | 15
Longview, Texas | 15
Mineola, Texas | 15
Palestine, Texas | 25"></textarea>
		          <small class="description"><?php esc_html_e('Required for Listed towns/cities/ZIPs only. One per line. Accepts city/state, ZIP, or full address. Optional radius after |. Spell out the state name when possible; abbreviations are accepted and normalized. Listed-only mode uses only these locations and will not fall back to the venue radius.', 'vms-meta-ads'); ?></small>
		        </label>
		      </div>
		      <div class="vms-ma-grid-two">
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="radio" name="vms_ma_placements_mode" value="auto" /> <span><?php esc_html_e('Advantage+ placements (automatic)', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="radio" name="vms_ma_placements_mode" value="manual" checked /> <span><?php esc_html_e('Manual placements', 'vms-meta-ads'); ?></span></label>
		      </div>
		      <p class="description"><?php esc_html_e('Clean-room builds default to an explicit FB/IG manual placement set. Automatic placements remain available, but Meta may imply broader placement coverage in edit UI and should be rechecked before any future launch step.', 'vms-meta-ads'); ?></p>
		      <div id="vms-ma-placements-manual" class="vms-ma-grid-three">
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="fb_feed" checked /> <span><?php esc_html_e('Facebook Feed', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="fb_profile_feed" checked /> <span><?php esc_html_e('Facebook Profile Feed', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="fb_right_column" /> <span><?php esc_html_e('Facebook Right Column', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="fb_story" checked /> <span><?php esc_html_e('Facebook Stories', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="fb_reels" checked /> <span><?php esc_html_e('Facebook Reels', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="fb_search" checked /> <span><?php esc_html_e('Facebook Search Results', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="ig_feed" checked /> <span><?php esc_html_e('Instagram Feed', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="ig_explore" checked /> <span><?php esc_html_e('Instagram Explore Home', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="ig_story" checked /> <span><?php esc_html_e('Instagram Stories', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="ig_reels" checked /> <span><?php esc_html_e('Instagram Reels', 'vms-meta-ads'); ?></span></label>
		        <label class="vms-ma-choice vms-ma-inline-choice"><input type="checkbox" class="vms-ma-placement" value="ig_search" checked /> <span><?php esc_html_e('Instagram Search Results', 'vms-meta-ads'); ?></span></label>
		      </div>
		      <p id="vms-ma-radius-warning" class="description vms-ma-inline-warning vms-ma-hidden"></p>
		      <p class="description vms-ma-beginner-copy"><?php esc_html_e('Keep audience broad; interests can reduce delivery if too narrow.', 'vms-meta-ads'); ?></p>
		      <p id="vms-ma-step-d-status" class="description" aria-live="polite"></p>
		      <p><button type="button" class="button button-secondary vms-ma-step-continue"><?php esc_html_e('Continue', 'vms-meta-ads'); ?></button></p>
		    </div>
		  </section>

		  <section id="vms-ma-step-e" class="vms-ma-section vms-ma-step vms-ma-card" data-step="budget" data-step-key="E" data-step-index="5" data-vms-tour="vms-ma-budget">
		    <div class="vms-ma-step-header vms-ma-step-head" role="button" tabindex="0" aria-expanded="false">
		      <h2 class="vms-ma-section-title"><?php esc_html_e('Step E - Budget + Schedule', 'vms-meta-ads'); ?></h2>
		      <span class="vms-ma-step-status" data-step-status><?php esc_html_e('Locked', 'vms-meta-ads'); ?></span>
		    </div>
		    <div class="vms-ma-step-body">
		      <div class="vms-ma-grid-two">
		        <label class="vms-ma-budget-total-label"><span><?php esc_html_e('Total budget (dollars)', 'vms-meta-ads'); ?> <button type="button" class="vms-ma-info" aria-label="<?php esc_attr_e('Help for total budget', 'vms-meta-ads'); ?>" data-help-id="ma_help_budget_total" data-auto-help="1" data-auto-help-target="#vms-ma-budget-total" data-auto-help-default="">i</button></span><input type="number" id="vms-ma-budget-total" data-vms-tour="vms-ma-budget-total" min="1" step="0.01" data-required-step="5" /><small id="vms-ma-budget-minimum-note" class="description vms-ma-budget-minimum-note" aria-live="polite"><?php esc_html_e('Minimum for current allocation will appear after the recipe and schedule are available.', 'vms-meta-ads'); ?></small></label>
		        <label>
		          <span><?php esc_html_e('Goal', 'vms-meta-ads'); ?></span>
		          <select id="vms-ma-goal" data-required-step="5">
		            <option value="traffic"><?php esc_html_e('Traffic', 'vms-meta-ads'); ?></option>
		            <option value="sales"><?php esc_html_e('Sales / Ticket Purchases', 'vms-meta-ads'); ?></option>
		            <option value="engagement"><?php esc_html_e('Engagement', 'vms-meta-ads'); ?></option>
		            <option value="leads"><?php esc_html_e('Leads', 'vms-meta-ads'); ?></option>
		          </select>
		        </label>
		        <label id="vms-ma-optimization-wrap"><span><?php esc_html_e('Optimization', 'vms-meta-ads'); ?></span><select id="vms-ma-optimization"><option value="link_clicks"><?php esc_html_e('Link clicks', 'vms-meta-ads'); ?></option><option value="landing_page_views"><?php esc_html_e('Landing page views', 'vms-meta-ads'); ?></option><option value="purchase_conversions"><?php esc_html_e('Purchase conversions', 'vms-meta-ads'); ?></option></select><small class="description" id="vms-ma-optimization-help"><?php esc_html_e('Traffic is the goal. Link clicks is how Meta optimizes delivery.', 'vms-meta-ads'); ?></small></label>
			        <div id="vms-ma-sales-goal-card" class="vms-ma-inline-card vms-ma-hidden"><strong><?php esc_html_e('Sales uses Purchase conversions.', 'vms-meta-ads'); ?></strong><p class="description"><?php esc_html_e('MAB will use your saved Meta Pixel or Dataset ID and keep any later Meta assets paused for review.', 'vms-meta-ads'); ?></p><p id="vms-ma-sales-goal-warning" class="description vms-ma-inline-warning vms-ma-hidden"></p></div>
		        <label><span><?php esc_html_e('Schedule start', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-sched-start" readonly /></label>
		        <label><span><?php esc_html_e('Schedule end', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-sched-end" readonly /></label>
		      </div>
		      <p class="description vms-ma-section-intro"><?php esc_html_e('Tier windows and budgets are generated automatically and validated against clamps.', 'vms-meta-ads'); ?></p>
		      <p class="description"><?php esc_html_e('Schedule is computed from your preset. Switch to Manual Dates in Expert if you need custom.', 'vms-meta-ads'); ?></p>
		      <div id="vms-ma-budget-summary" class="vms-ma-budget-summary" aria-live="polite"></div>
		      <div id="vms-ma-recipe-budget-preview" class="vms-ma-recipe-budget-preview" aria-live="polite"></div>
		      <p id="vms-ma-budget-floor-warning" class="description vms-ma-inline-warning vms-ma-hidden" aria-live="polite"></p>
		      <div id="vms-ma-tier-table" class="vms-ma-tier-table" aria-live="polite"></div>
		      <label class="vms-ma-choice vms-ma-inline-choice vms-ma-budget-sync-toggle"><input type="checkbox" id="vms-ma-auto-budget-sync" /> <span><?php esc_html_e('Auto-sync saved draft budget to Meta every 15 minutes', 'vms-meta-ads'); ?></span></label>
		      <p class="description"><?php esc_html_e('Useful when you want the plugin to catch saved budget changes and push them automatically without rebuilding the ad.', 'vms-meta-ads'); ?></p>
		      <p id="vms-ma-step-e-status" class="description" aria-live="polite"></p>
		      <p><button type="button" class="button button-secondary vms-ma-step-continue"><?php esc_html_e('Continue', 'vms-meta-ads'); ?></button></p>
		    </div>
		  </section>

		  <section id="vms-ma-step-g" class="vms-ma-section vms-ma-step vms-ma-card" data-step="actions" data-step-key="G" data-step-index="6">
		    <div class="vms-ma-step-header vms-ma-step-head" role="button" tabindex="0" aria-expanded="false">
		      <h2 class="vms-ma-section-title"><?php esc_html_e('Step G - Actions', 'vms-meta-ads'); ?></h2>
		      <span class="vms-ma-step-status" data-step-status><?php esc_html_e('Locked', 'vms-meta-ads'); ?></span>
			    </div>
			    <div class="vms-ma-step-body">
		      <p class="description vms-ma-section-intro"><?php esc_html_e('Save the draft, review any create blockers, and use Preview / Troubleshooting only when you need a local preflight or payload inspection.', 'vms-meta-ads'); ?></p>
		      <div id="vms-ma-create-structure-preview" class="vms-ma-inline-card vms-ma-create-structure-preview" aria-live="polite"></div>
		      <div class="vms-ma-actions-stack vms-ma-actions--primary">
		        <div class="vms-ma-actions vms-ma-actions-row vms-ma-actions-row--primary">
			          <button id="vms-ma-save-draft" class="button button-primary" type="button"><?php esc_html_e('Save Draft', 'vms-meta-ads'); ?></button>
			          <button id="vms-ma-meta-dry-run" class="button button-secondary" type="button"><?php esc_html_e('Preview / Troubleshooting Dry Run', 'vms-meta-ads'); ?></button>
			          <button id="vms-ma-create-paused" class="button" type="button"><?php esc_html_e('Create Paused Campaign in Meta', 'vms-meta-ads'); ?></button>
			          <button id="vms-ma-go-live" class="button" type="button"><?php esc_html_e('Go Live', 'vms-meta-ads'); ?></button>
			        </div>
			        <p class="description"><?php esc_html_e('Dry Run is optional here. It stays local-only, gives you a safe payload preview, and should be treated as Preview / Troubleshooting until live create is allowed.', 'vms-meta-ads'); ?></p>
			        <div id="vms-ma-action-blockers" class="vms-ma-inline-card vms-ma-action-blockers" aria-live="polite">
			          <strong><?php esc_html_e('Create is currently blocked.', 'vms-meta-ads'); ?></strong>
			          <p class="description"><?php esc_html_e('Load a saved build, clear any blocker reasons, and review the paused-create confirmation before using Meta create. Dry Run stays safe and does not contact Meta.', 'vms-meta-ads'); ?></p>
			        </div>
			        <input type="hidden" id="vms-ma-build-id" value="" />
		      </div>
		      <p id="vms-ma-api-gating-reason" class="description"></p>
		      <p id="vms-ma-dirty-state" class="description vms-ma-dirty-state vms-ma-hidden" aria-live="polite"></p>
			      <section id="vms-ma-launch-qa-card" class="vms-ma-launch-qa-card vms-ma-inline-card" aria-live="polite">
			        <h3><?php esc_html_e('Manual Meta QA Gate', 'vms-meta-ads'); ?></h3>
			        <p class="description"><?php esc_html_e('Use this immediately before Go Live. These checks are manual because Meta can expose enhancement toggles only inside Ads Manager.', 'vms-meta-ads'); ?></p>
		        <div class="vms-ma-launch-qa-grid">
		          <label class="vms-ma-qa-check"><input type="checkbox" id="vms-ma-qa-website-highlights" /> <span><?php esc_html_e('Website Highlights / Web Highlight / Show Spotlights are off for every ad.', 'vms-meta-ads'); ?></span></label>
		          <label class="vms-ma-qa-check"><input type="checkbox" id="vms-ma-qa-advantage-off" /> <span><?php esc_html_e('Advantage+ creative enhancements are off for every ad.', 'vms-meta-ads'); ?></span></label>
		          <label class="vms-ma-qa-check"><input type="checkbox" id="vms-ma-qa-multi-off" /> <span><?php esc_html_e('Multi-advertiser ads stayed off for every ad.', 'vms-meta-ads'); ?></span></label>
		          <label class="vms-ma-qa-check"><input type="checkbox" id="vms-ma-qa-placements" /> <span><?php esc_html_e('Placements in Meta still match the intended FB/IG setup.', 'vms-meta-ads'); ?></span></label>
		          <label class="vms-ma-qa-check"><input type="checkbox" id="vms-ma-qa-media-match" /> <span><?php esc_html_e('Every preview uses only the intended MAB image/video.', 'vms-meta-ads'); ?></span></label>
		          <label class="vms-ma-qa-check"><input type="checkbox" id="vms-ma-qa-destination-utm" /> <span><?php esc_html_e('Ticket URL and UTM tags are present on every ad.', 'vms-meta-ads'); ?></span></label>
			          <label class="vms-ma-qa-check"><input type="checkbox" id="vms-ma-qa-schedule" /> <span><?php esc_html_e('Ad-set schedule start/end is correct in Meta.', 'vms-meta-ads'); ?></span></label>
			        </div>
			        <p id="vms-ma-launch-qa-status" class="description vms-ma-inline-warning"><?php esc_html_e('Manual launch QA is not complete.', 'vms-meta-ads'); ?></p>
			      </section>
			      <details id="vms-ma-dry-run-panel" class="vms-ma-builder-diagnostics vms-ma-builder-diagnostics--step-g">
			        <summary>
			          <span><?php esc_html_e('Preview / Troubleshooting Dry Run', 'vms-meta-ads'); ?></span>
			          <small><?php esc_html_e('Optional local preflight, safe in Phase 1', 'vms-meta-ads'); ?></small>
			        </summary>
			        <div class="vms-ma-builder-diagnostics-body">
			          <p id="vms-ma-dry-run-status" class="description" aria-live="polite"><?php esc_html_e('Use this when you want a local request preview, blocker list, or troubleshooting detail. Dry Run saves the draft, stays inside WordPress, does not contact Meta, and cannot spend money.', 'vms-meta-ads'); ?></p>
			          <div id="vms-ma-dry-run-summary" class="vms-ma-dry-run-summary"></div>
			          <div id="vms-ma-dry-run-blockers" class="vms-ma-inline-card vms-ma-dry-run-message vms-ma-hidden" aria-live="polite"></div>
			          <div id="vms-ma-dry-run-warnings" class="vms-ma-inline-card vms-ma-dry-run-message vms-ma-hidden" aria-live="polite"></div>
			          <div id="vms-ma-dry-run-insights" class="vms-ma-dry-run-insights vms-ma-hidden"></div>
			          <details class="vms-ma-subdetails vms-ma-dry-run-json">
			            <summary class="vms-ma-subdetails__summary"><?php esc_html_e('Advanced Details (JSON)', 'vms-meta-ads'); ?></summary>
			            <div class="vms-ma-subdetails__body">
			              <pre id="vms-ma-dry-run-output" class="vms-ma-dry-run-output">{}</pre>
			            </div>
			          </details>
			        </div>
			      </details>
			      <article id="vms-ma-meta-status-card" class="vms-ma-meta-status-card">
			        <header class="vms-ma-meta-status-head">
			          <h3><?php esc_html_e('Meta Ad Status', 'vms-meta-ads'); ?></h3>
			          <a id="vms-ma-open-meta-link" href="https://adsmanager.facebook.com/" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Open Meta', 'vms-meta-ads'); ?></a>
			        </header>
			        <div class="vms-ma-meta-chip-grid">
			          <div class="vms-ma-meta-chip-row">
			            <strong><?php esc_html_e('Campaign', 'vms-meta-ads'); ?></strong>
			            <span class="vms-ma-meta-chip" data-meta-kind="campaign"><?php esc_html_e('Not created yet', 'vms-meta-ads'); ?></span>
			            <small><?php esc_html_e('Configured:', 'vms-meta-ads'); ?> <span id="vms-ma-meta-campaign-configured"><?php esc_html_e('Not checked yet', 'vms-meta-ads'); ?></span></small>
			            <small><?php esc_html_e('Effective:', 'vms-meta-ads'); ?> <span id="vms-ma-meta-campaign-effective"><?php esc_html_e('Not checked yet', 'vms-meta-ads'); ?></span></small>
			          </div>
			          <div class="vms-ma-meta-chip-row">
			            <strong><?php esc_html_e('Ad Set', 'vms-meta-ads'); ?></strong>
			            <span class="vms-ma-meta-chip" data-meta-kind="adset"><?php esc_html_e('Not created yet', 'vms-meta-ads'); ?></span>
			            <small><?php esc_html_e('Configured:', 'vms-meta-ads'); ?> <span id="vms-ma-meta-adset-configured"><?php esc_html_e('Not checked yet', 'vms-meta-ads'); ?></span></small>
			            <small><?php esc_html_e('Effective:', 'vms-meta-ads'); ?> <span id="vms-ma-meta-adset-effective"><?php esc_html_e('Not checked yet', 'vms-meta-ads'); ?></span></small>
			          </div>
			          <div class="vms-ma-meta-chip-row">
			            <strong><?php esc_html_e('Ad', 'vms-meta-ads'); ?></strong>
			            <span class="vms-ma-meta-chip" data-meta-kind="ad"><?php esc_html_e('Not created yet', 'vms-meta-ads'); ?></span>
			            <small><?php esc_html_e('Configured:', 'vms-meta-ads'); ?> <span id="vms-ma-meta-ad-configured"><?php esc_html_e('Not checked yet', 'vms-meta-ads'); ?></span></small>
			            <small><?php esc_html_e('Effective:', 'vms-meta-ads'); ?> <span id="vms-ma-meta-ad-effective"><?php esc_html_e('Not checked yet', 'vms-meta-ads'); ?></span></small>
			          </div>
			        </div>
			        <div id="vms-ma-meta-adset-details" class="vms-ma-meta-adset-details"><?php esc_html_e('No Meta campaign has been created yet.', 'vms-meta-ads'); ?></div>
			        <div id="vms-ma-meta-readiness" class="vms-ma-meta-readiness vms-ma-hidden"><?php esc_html_e('Post-create readiness checks load after status refresh.', 'vms-meta-ads'); ?></div>
			        <div class="vms-ma-meta-variant-row">
			          <strong><?php esc_html_e('Ad Variants', 'vms-meta-ads'); ?></strong>
			          <span id="vms-ma-meta-variant-summary"><?php esc_html_e('No Meta campaign has been created yet.', 'vms-meta-ads'); ?></span>
			          <small id="vms-ma-meta-variant-details"><?php esc_html_e('Load a saved build first. Create Paused only uses the build currently loaded in the builder.', 'vms-meta-ads'); ?></small>
			        </div>
			        <div class="vms-ma-meta-budget-row">
			          <strong><?php esc_html_e('Budget Sync', 'vms-meta-ads'); ?></strong>
			          <span id="vms-ma-budget-sync-status"><?php esc_html_e('No Meta budget sync yet.', 'vms-meta-ads'); ?></span>
			          <small id="vms-ma-budget-sync-details"><?php esc_html_e('Load a saved build first. Budget sync only works after paused Meta assets exist for that build.', 'vms-meta-ads'); ?></small>
			        </div>
			        <div class="vms-ma-actions vms-ma-actions--meta-status">
			          <button id="vms-ma-refresh-status" class="button" type="button"><?php esc_html_e('Refresh Status', 'vms-meta-ads'); ?></button>
			          <button id="vms-ma-update-existing" class="button" type="button"><?php esc_html_e('Update Existing Meta Ad', 'vms-meta-ads'); ?></button>
			          <button id="vms-ma-sync-budget" class="button" type="button"><?php esc_html_e('Sync Budget to Meta', 'vms-meta-ads'); ?></button>
			          <button id="vms-ma-pause-all" class="button" type="button"><?php esc_html_e('Pause All', 'vms-meta-ads'); ?></button>
			          <button id="vms-ma-reset-meta-link" class="button" type="button"><?php esc_html_e('Reset Meta Link', 'vms-meta-ads'); ?></button>
			        </div>
			        <p id="vms-ma-meta-status-inline" class="description" aria-live="polite"></p>
			        <div id="vms-ma-meta-create-guidance" class="vms-ma-inline-card vms-ma-hidden" aria-live="polite"></div>
			        <div id="vms-ma-drift-panel" class="vms-ma-drift-panel vms-ma-hidden" aria-live="polite"></div>
			      </article>
			      <section id="vms-ma-builder-analytics" class="vms-ma-builder-analytics">
		        <header class="vms-ma-builder-analytics__head">
		          <div>
		            <h3><?php esc_html_e('Campaign Analytics + Strategy', 'vms-meta-ads'); ?></h3>
		            <p class="description"><?php esc_html_e('Pull delivery data into the builder, spot winners and weak spots, and download a clean analysis bundle for deeper review.', 'vms-meta-ads'); ?></p>
		          </div>
		          <div class="vms-ma-builder-analytics__actions">
		            <div class="vms-ma-analytics-range" role="group" aria-label="<?php esc_attr_e('Analytics date range', 'vms-meta-ads'); ?>">
		              <button type="button" class="button button-small vms-ma-analytics-range-btn is-active" data-range="last_7"><?php esc_html_e('7d', 'vms-meta-ads'); ?></button>
		              <button type="button" class="button button-small vms-ma-analytics-range-btn" data-range="last_14"><?php esc_html_e('14d', 'vms-meta-ads'); ?></button>
		              <button type="button" class="button button-small vms-ma-analytics-range-btn" data-range="last_30"><?php esc_html_e('30d', 'vms-meta-ads'); ?></button>
		            </div>
		            <button type="button" class="button" id="vms-ma-analytics-refresh"><?php esc_html_e('Refresh Analytics', 'vms-meta-ads'); ?></button>
		            <button type="button" class="button" id="vms-ma-analytics-download"><?php esc_html_e('Download Analysis Bundle', 'vms-meta-ads'); ?></button>
		            <button type="button" class="button" id="vms-ma-analytics-copy-notes"><?php esc_html_e('Copy Strategy Notes', 'vms-meta-ads'); ?></button>
		          </div>
		        </header>
		        <p id="vms-ma-analytics-meta" class="description" aria-live="polite"><?php esc_html_e('Choose an Event Plan and linked build to load analytics.', 'vms-meta-ads'); ?></p>
		        <div id="vms-ma-analytics-warnings" class="vms-ma-inline-warning vms-ma-hidden"></div>
		        <div id="vms-ma-analytics-recommendations" class="vms-ma-analytics-recommendations"></div>
		        <div id="vms-ma-analytics-cards" class="vms-ma-performance-cards vms-ma-performance-cards--builder"></div>
		        <div id="vms-ma-analytics-trend" class="vms-ma-analytics-trend"></div>
		        <div class="vms-ma-builder-analytics__grid">
		          <div class="vms-ma-builder-analytics__panel">
		            <h4><?php esc_html_e('Demographics', 'vms-meta-ads'); ?></h4>
		            <div id="vms-ma-analytics-demographics" class="vms-ma-analytics-table"></div>
		          </div>
		          <div class="vms-ma-builder-analytics__panel">
		            <h4><?php esc_html_e('Regions', 'vms-meta-ads'); ?></h4>
		            <div id="vms-ma-analytics-regions" class="vms-ma-analytics-table"></div>
		          </div>
		          <div class="vms-ma-builder-analytics__panel">
		            <h4><?php esc_html_e('Placements', 'vms-meta-ads'); ?></h4>
		            <div id="vms-ma-analytics-placements" class="vms-ma-analytics-table"></div>
		          </div>
		          <div class="vms-ma-builder-analytics__panel">
		            <h4><?php esc_html_e('Devices', 'vms-meta-ads'); ?></h4>
		            <div id="vms-ma-analytics-devices" class="vms-ma-analytics-table"></div>
		          </div>
		        </div>
		      </section>
		      <p id="vms-ma-step-g-status" class="description" aria-live="polite"></p>
		    </div>
		  </section>

		  <details id="vms-ma-templates" class="vms-ma-section vms-ma-card vms-ma-templates vms-ma-templates--advanced" data-vms-tour="vms-ma-templates">
		    <summary class="vms-ma-details-summary">
		      <span class="vms-ma-details-summary__title"><?php esc_html_e('Advanced / Export, Copy Pack + Templates', 'vms-meta-ads'); ?></span>
		      <span class="vms-ma-details-summary__meta"><?php esc_html_e('Collapsed by default', 'vms-meta-ads'); ?></span>
		    </summary>
		    <div class="vms-ma-details-body">
		      <div class="vms-ma-template-loadbox">
		        <div class="vms-ma-grid-two">
		          <label for="vms-ma-template-select"><span><?php esc_html_e('Load template', 'vms-meta-ads'); ?></span>
		            <select id="vms-ma-template-select">
		              <option value=""><?php esc_html_e('No template selected', 'vms-meta-ads'); ?></option>
		            </select>
		          </label>
		          <div class="vms-ma-inline-actions">
		            <button type="button" class="button button-secondary" id="vms-ma-apply-template" disabled><?php esc_html_e('Apply template', 'vms-meta-ads'); ?></button>
		            <button type="button" class="button vms-ma-button-danger" id="vms-ma-delete-template" disabled><?php esc_html_e('Delete template', 'vms-meta-ads'); ?></button>
		            <button type="button" class="button vms-ma-button-ghost" id="vms-ma-refresh-templates"><?php esc_html_e('Refresh list', 'vms-meta-ads'); ?></button>
		          </div>
		        </div>
		        <p class="description"><?php esc_html_e('Load a saved template before editing when you want to start from a known audience, placement, schedule, or budget setup.', 'vms-meta-ads'); ?></p>
		        <p id="vms-ma-template-meta" class="description vms-ma-template-meta" aria-live="polite"></p>
		      </div>
		      <div class="vms-ma-template-savebox">
		        <div class="vms-ma-grid-two vms-ma-template-savebox__grid">
		          <label for="vms-ma-template-name"><span><?php esc_html_e('Template name', 'vms-meta-ads'); ?></span><input type="text" id="vms-ma-template-name" placeholder="<?php esc_attr_e('Example: Tyler 50mi + Ticket Push', 'vms-meta-ads'); ?>" /></label>
		          <div class="vms-ma-inline-actions vms-ma-template-savebox__name-actions">
		            <button type="button" class="button vms-ma-button-ghost" id="vms-ma-clear-template-name"><?php esc_html_e('Clear', 'vms-meta-ads'); ?></button>
		          </div>
		        </div>
		        <div class="vms-ma-template-includes">
		          <div class="vms-ma-template-includes-head"><strong><?php esc_html_e('Include in template', 'vms-meta-ads'); ?></strong> <span class="description"><?php esc_html_e('(optional)', 'vms-meta-ads'); ?></span></div>
		          <p class="description"><?php esc_html_e('Templates now save reusable settings only. Event-specific images, copy, and destination URLs stay with each event.', 'vms-meta-ads'); ?></p>
		          <label><input type="checkbox" id="vms-ma-tpl-inc-targeting" checked /> <?php esc_html_e('Audience', 'vms-meta-ads'); ?></label>
		          <label><input type="checkbox" id="vms-ma-tpl-inc-placements" checked /> <?php esc_html_e('Placements', 'vms-meta-ads'); ?></label>
		          <label><input type="checkbox" id="vms-ma-tpl-inc-schedule" checked /> <?php esc_html_e('Schedule preset', 'vms-meta-ads'); ?></label>
		          <label><input type="checkbox" id="vms-ma-tpl-inc-budget" checked /> <?php esc_html_e('Budget', 'vms-meta-ads'); ?></label>
		          <label><input type="checkbox" id="vms-ma-tpl-inc-strategy" checked /> <?php esc_html_e('Strategy / Meta intent controls', 'vms-meta-ads'); ?></label>
		          <label><input type="checkbox" id="vms-ma-tpl-inc-cta" checked /> <?php esc_html_e('Call to action', 'vms-meta-ads'); ?></label>
		        </div>
		        <div class="vms-ma-actions vms-ma-actions-row vms-ma-actions-row--secondary">
		          <button id="vms-ma-save-template" class="button button-secondary" type="button"><?php esc_html_e('Save Settings as Template', 'vms-meta-ads'); ?></button>
		        </div>
		      </div>
		      <details id="vms-ma-copy-pack-details" class="vms-ma-subdetails">
		        <summary class="vms-ma-subdetails__summary"><?php esc_html_e('Copy Pack Output', 'vms-meta-ads'); ?></summary>
		        <div class="vms-ma-subdetails__body">
		          <p class="description vms-ma-section-intro"><?php esc_html_e('Optional export area for copy review, URL checks, and handoff text. It is no longer part of the required Step A-G flow.', 'vms-meta-ads'); ?></p>
		          <div id="vms-ma-copy-pack-warning" class="vms-ma-inline-warning vms-ma-hidden"></div>
		          <div id="vms-ma-output-pack" data-vms-tour="vms-ma-output-pack"><pre id="vms-ma-copy-pack"></pre></div>
		          <div class="vms-ma-actions vms-ma-actions--copy">
		            <button type="button" class="button button-secondary" id="vms-ma-export-pack"><?php esc_html_e('Export Copy Pack', 'vms-meta-ads'); ?></button>
		            <button type="button" class="button button-secondary" id="vms-ma-copy-all"><?php esc_html_e('Copy All', 'vms-meta-ads'); ?></button>
		            <button type="button" class="button vms-ma-button-ghost" id="vms-ma-copy-url"><?php esc_html_e('Copy URL', 'vms-meta-ads'); ?></button>
		            <button type="button" class="button vms-ma-button-ghost" id="vms-ma-download-pack"><?php esc_html_e('Download .txt', 'vms-meta-ads'); ?></button>
		          </div>
		        </div>
		      </details>
		      <div class="vms-ma-spec-box">
		        <div class="vms-ma-spec-box__head">
		          <h3 class="vms-ma-subtitle"><?php esc_html_e('Paste / Export Ad Spec', 'vms-meta-ads'); ?></h3>
		          <p class="description"><?php esc_html_e('Paste JSON or simple Key: Value lines here for reusable recipes, variant copy, and quick local backup/export.', 'vms-meta-ads'); ?></p>
		        </div>
		        <label for="vms-ma-spec-input" class="vms-ma-spec-box__field">
		          <span><?php esc_html_e('Ad spec', 'vms-meta-ads'); ?></span>
		          <textarea id="vms-ma-spec-input" rows="10" placeholder="{&#10;  &quot;total_budget_minor&quot;: 1500,&#10;  &quot;age_min&quot;: 50,&#10;  &quot;age_max&quot;: 72,&#10;  &quot;locations&quot;: &quot;Tyler, TX | 35&quot;,&#10;  &quot;ad_variants&quot;: [&#10;    {&quot;label&quot;:&quot;Variant 1&quot;,&quot;primary_text&quot;:&quot;...&quot;,&quot;headline&quot;:&quot;...&quot;,&quot;description&quot;:&quot;...&quot;}&#10;  ]&#10;}"></textarea>
		        </label>
		        <div class="vms-ma-inline-actions vms-ma-spec-box__actions">
		          <button type="button" class="button button-secondary" id="vms-ma-apply-spec"><?php esc_html_e('Apply Pasted Spec', 'vms-meta-ads'); ?></button>
		          <button type="button" class="button vms-ma-button-ghost" id="vms-ma-export-spec"><?php esc_html_e('Export Current Settings', 'vms-meta-ads'); ?></button>
		          <button type="button" class="button vms-ma-button-ghost" id="vms-ma-copy-spec"><?php esc_html_e('Copy Export', 'vms-meta-ads'); ?></button>
		          <button type="button" class="button vms-ma-button-danger" id="vms-ma-clear-spec"><?php esc_html_e('Clear Box', 'vms-meta-ads'); ?></button>
		        </div>
		        <p id="vms-ma-spec-status" class="description" aria-live="polite"></p>
		      </div>
		    </div>
		  </details>

		  <?php if (function_exists('vms_render_api_diagnostics_panel')) : ?>
		  <details id="vms-ma-builder-diagnostics" class="vms-ma-builder-diagnostics">
		    <summary>
		      <span><?php esc_html_e('Meta API Diagnostics', 'vms-meta-ads'); ?></span>
		      <small><?php esc_html_e('Collapsed by default', 'vms-meta-ads'); ?></small>
		    </summary>
		    <div class="vms-ma-builder-diagnostics-body">
		      <?php
		      vms_render_api_diagnostics_panel(array(
		      	'provider_slug' => 'meta_ads',
		      	'module_slug' => 'vms-facebook-ads',
		      	'context' => 'ad_builder',
		      	'title' => __('Meta API Diagnostics', 'vms-meta-ads'),
		      	'limit' => 10,
		      	'ajax_action' => 'vms_api_copy_bundle',
		      ));
		      ?>
		    </div>
		  </details>
		  <?php endif; ?>
		</div>
		<div id="vms-ma-gated-modal" class="vms-ma-modal vms-ma-hidden" role="dialog" aria-modal="true" aria-labelledby="vms-ma-gated-title">
		  <div class="vms-ma-modal-card">
		    <h2 id="vms-ma-gated-title"><?php esc_html_e('This action is gated in the current phase.', 'vms-meta-ads'); ?></h2>
		    <p id="vms-ma-gated-message"><?php esc_html_e('Use Save Draft or Preview / Troubleshooting Dry Run in this phase. You can raise phase in Settings when ready.', 'vms-meta-ads'); ?></p>
		    <p>
		      <a class="button button-primary" href="<?php echo esc_url(add_query_arg(array('page' => 'vms-ma-ads-settings'), admin_url('admin.php'))); ?>"><?php esc_html_e('Open Settings', 'vms-meta-ads'); ?></a>
		      <button type="button" class="button" id="vms-ma-gated-close"><?php esc_html_e('Close', 'vms-meta-ads'); ?></button>
		    </p>
		  </div>
		</div>
		<div id="vms-ma-create-preflight-modal" class="vms-ma-modal vms-ma-hidden" role="dialog" aria-modal="true" aria-labelledby="vms-ma-create-preflight-title">
		  <div class="vms-ma-modal-card">
		    <h2 id="vms-ma-create-preflight-title"><?php esc_html_e('Create paused Meta objects?', 'vms-meta-ads'); ?></h2>
		    <p><?php esc_html_e('This action creates real campaign, ad set, creative, and ad objects in Meta Ads Manager from the build currently loaded in the builder. Everything is expected to be created in PAUSED status only for owner review.', 'vms-meta-ads'); ?></p>
		    <div id="vms-ma-create-preflight-summary" class="vms-ma-preflight-summary"></div>
		    <label class="vms-ma-choice"><input type="checkbox" id="vms-ma-create-confirm-paused" /> <span><?php esc_html_e('I understand this creates real paused Meta draft objects only for the loaded build and does not delete them automatically if a later step fails.', 'vms-meta-ads'); ?></span></label>
		    <p class="description"><?php esc_html_e('If a partial create occurs, use the cleanup guidance in the Meta status card. Reset Meta Link only unlinks local IDs; it does not delete or archive Meta objects.', 'vms-meta-ads'); ?></p>
		    <p>
		      <button type="button" class="button button-primary" id="vms-ma-create-preflight-confirm" disabled><?php esc_html_e('Create paused objects', 'vms-meta-ads'); ?></button>
		      <button type="button" class="button" id="vms-ma-create-preflight-cancel"><?php esc_html_e('Cancel', 'vms-meta-ads'); ?></button>
		    </p>
		  </div>
		</div>
		<div id="vms-ma-live-preflight-modal" class="vms-ma-modal vms-ma-hidden" role="dialog" aria-modal="true" aria-labelledby="vms-ma-live-preflight-title">
		  <div class="vms-ma-modal-card">
		    <h2 id="vms-ma-live-preflight-title"><?php esc_html_e('Review before going live', 'vms-meta-ads'); ?></h2>
		    <div id="vms-ma-live-preflight-summary" class="vms-ma-preflight-summary"></div>
		    <label class="vms-ma-choice"><input type="checkbox" id="vms-ma-live-confirm-spend" /> <span><?php esc_html_e('I understand this can spend money.', 'vms-meta-ads'); ?></span></label>
		    <label class="vms-ma-choice"><input type="checkbox" id="vms-ma-live-confirm-review" /> <span><?php esc_html_e('I reviewed schedule and budget.', 'vms-meta-ads'); ?></span></label>
		    <p class="description"><?php esc_html_e('Publishing can spend money.', 'vms-meta-ads'); ?></p>
		    <p>
		      <button type="button" class="button button-primary" id="vms-ma-live-preflight-continue" disabled><?php esc_html_e('Continue', 'vms-meta-ads'); ?></button>
		      <button type="button" class="button" id="vms-ma-live-preflight-cancel"><?php esc_html_e('Cancel', 'vms-meta-ads'); ?></button>
		    </p>
		  </div>
		</div>
		<div id="vms-ma-live-final-modal" class="vms-ma-modal vms-ma-hidden" role="dialog" aria-modal="true" aria-labelledby="vms-ma-live-final-title">
		  <div class="vms-ma-modal-card">
		    <h2 id="vms-ma-live-final-title"><?php esc_html_e('Go Live now?', 'vms-meta-ads'); ?></h2>
		    <p><?php esc_html_e('This will set Campaign, Ad Set, and Ad to ACTIVE.', 'vms-meta-ads'); ?></p>
		    <p>
		      <button type="button" class="button button-primary" id="vms-ma-live-final-confirm"><?php esc_html_e('Go Live', 'vms-meta-ads'); ?></button>
		      <button type="button" class="button" id="vms-ma-live-final-cancel"><?php esc_html_e('Cancel', 'vms-meta-ads'); ?></button>
		    </p>
		  </div>
		</div>
		<?php
	}
}
