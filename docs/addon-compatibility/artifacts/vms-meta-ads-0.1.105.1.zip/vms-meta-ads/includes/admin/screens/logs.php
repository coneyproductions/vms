<?php
defined('ABSPATH') || exit;

if (!function_exists('vms_ma_render_logs_screen')) {
	function vms_ma_render_logs_screen(): void
	{
		global $wpdb;
		$rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}vms_meta_ads_audit ORDER BY created_at DESC LIMIT 20", ARRAY_A);
		?>
		<div class="wrap" id="vms-ma-logs-wrap">
		  <h1><?php esc_html_e('Meta Ads Logs', 'vms-meta-ads'); ?></h1>
		  <table class="widefat">
		    <thead>
		      <tr>
		        <th><?php esc_html_e('Time', 'vms-meta-ads'); ?></th>
		        <th><?php esc_html_e('User', 'vms-meta-ads'); ?></th>
		        <th><?php esc_html_e('Action', 'vms-meta-ads'); ?></th>
		        <th><?php esc_html_e('Summary', 'vms-meta-ads'); ?></th>
		      </tr>
		    </thead>
		    <tbody>
		      <?php if (empty($rows)) : ?>
		        <tr><td colspan="4"><?php esc_html_e('No log entries yet.', 'vms-meta-ads'); ?></td></tr>
		      <?php else : foreach ($rows as $row) : ?>
		          <tr>
		            <td><?php echo esc_html($row['created_at']); ?></td>
		            <td><?php echo esc_html(get_userdata($row['actor_user_id'])->display_name ?? '—'); ?></td>
		            <td><?php echo esc_html($row['action_key']); ?></td>
		            <td><?php echo esc_html(wp_html_excerpt((string) ($row['payload_redacted'] ?? ''), 80, '…')); ?></td>
		          </tr>
		      <?php endforeach; endif; ?>
		    </tbody>
		  </table>
		</div>
		<?php
	}
}
