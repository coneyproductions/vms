<?php
defined('ABSPATH') || exit;

if (!function_exists('vms_ma_promote_state_bucket')) {
	function vms_ma_promote_state_bucket(array $item): string
	{
		$meta_state = sanitize_key((string) ($item['meta_ads_state'] ?? ''));
		if (in_array($meta_state, array('error', 'partial'), true)) {
			return 'attention';
		}
		if ($meta_state === 'live') {
			return 'live';
		}
		if ($meta_state === 'paused') {
			return 'paused';
		}
		if (!empty($item['meta_ads_last_exported']) || !empty($item['meta_ads_last_updated'])) {
			return 'draft';
		}
		return 'none';
	}
}

if (!function_exists('vms_ma_promote_state_badge')) {
	function vms_ma_promote_state_badge(array $item): array
	{
		$bucket = vms_ma_promote_state_bucket($item);
		switch ($bucket) {
			case 'live':
				return array('key' => 'live', 'label' => __('Ad Live', 'vms-meta-ads'), 'class' => 'is-live');
			case 'paused':
				return array('key' => 'paused', 'label' => __('Ad Paused', 'vms-meta-ads'), 'class' => 'is-paused');
			case 'attention':
				return array('key' => 'attention', 'label' => __('Needs attention', 'vms-meta-ads'), 'class' => 'is-attention');
			case 'draft':
				return array('key' => 'draft', 'label' => __('Ad Draft', 'vms-meta-ads'), 'class' => 'is-draft');
			default:
				return array('key' => 'none', 'label' => __('No Ad Yet', 'vms-meta-ads'), 'class' => 'is-none');
		}
	}
}

if (!function_exists('vms_ma_promote_ticket_badge')) {
	function vms_ma_promote_ticket_badge(array $item): array
	{
		$ok = !empty($item['has_ticket_url']);
		return array(
			'label' => $ok ? __('Tickets Ready', 'vms-meta-ads') : __('Tickets Missing', 'vms-meta-ads'),
			'class' => $ok ? 'is-ticket-ok' : 'is-ticket-missing',
		);
	}
}

if (!function_exists('vms_ma_promote_plan_badge')) {
	function vms_ma_promote_plan_badge(array $item): array
	{
		$status = sanitize_key((string) ($item['event_plan_status'] ?? 'draft'));
		$label_map = array(
			'published' => __('Plan Published', 'vms-meta-ads'),
			'ready' => __('Plan Ready', 'vms-meta-ads'),
			'draft' => __('Plan Draft', 'vms-meta-ads'),
			'cancelled' => __('Plan Cancelled', 'vms-meta-ads'),
		);
		return array(
			'label' => (string) ($label_map[$status] ?? ucfirst($status !== '' ? $status : 'draft')),
			'class' => 'is-plan-' . ($status !== '' ? $status : 'draft'),
		);
	}
}

if (!function_exists('vms_ma_promote_thumbnail_url')) {
	function vms_ma_promote_thumbnail_url(array $item): string
	{
		$candidates = array(absint($item['id'] ?? 0), absint($item['tec_event_id'] ?? 0));
		foreach ($candidates as $post_id) {
			if ($post_id < 1) {
				continue;
			}
			$url = get_the_post_thumbnail_url($post_id, 'medium_large');
			if (is_string($url) && $url !== '') {
				return $url;
			}
		}
		return '';
	}
}

if (!function_exists('vms_ma_promote_perf_state')) {
	function vms_ma_promote_perf_state(array $snapshot): array
	{
		$metrics = is_array($snapshot['metrics'] ?? null) ? (array) $snapshot['metrics'] : array();
		if (!empty($snapshot['error'])) {
			return array('label' => __('Needs attention', 'vms-meta-ads'), 'class' => 'is-attention');
		}
		if (!empty($snapshot['empty']) || (int) ($metrics['impressions'] ?? 0) <= 0) {
			return array('label' => __('No data yet', 'vms-meta-ads'), 'class' => 'is-none');
		}
		if ((int) ($metrics['link_clicks'] ?? 0) > 0) {
			return array('label' => __('Getting clicks', 'vms-meta-ads'), 'class' => 'is-live');
		}
		return array('label' => __('Serving / warming up', 'vms-meta-ads'), 'class' => 'is-draft');
	}
}

if (!function_exists('vms_ma_promote_sparkline_svg')) {
	function vms_ma_promote_sparkline_svg(array $series): string
	{
		$points = array_values(array_filter($series, static function ($point): bool {
			return is_array($point);
		}));
		if (count($points) < 2) {
			return '';
		}

		$metric_key = 'link_clicks';
		$metric_values = array();
		foreach ($points as $point) {
			$metric_values[] = (float) ($point[$metric_key] ?? 0);
		}
		if (max($metric_values) <= 0) {
			$metric_key = 'impressions';
			$metric_values = array();
			foreach ($points as $point) {
				$metric_values[] = (float) ($point[$metric_key] ?? 0);
			}
		}
		$max = max($metric_values);
		$min = min($metric_values);
		if ($max <= 0 && $min <= 0) {
			return '';
		}
		if ($max === $min) {
			$min = 0.0;
		}

		$width = 180;
		$height = 44;
		$padding = 3;
		$count = count($metric_values);
		$step_x = ($count > 1) ? (($width - ($padding * 2)) / ($count - 1)) : 0;
		$coords = array();
		foreach ($metric_values as $index => $value) {
			$ratio = ($max > $min) ? (($value - $min) / ($max - $min)) : 1.0;
			$x = $padding + ($step_x * $index);
			$y = $height - $padding - ($ratio * ($height - ($padding * 2)));
			$coords[] = round($x, 2) . ',' . round($y, 2);
		}
		if (count($coords) < 2) {
			return '';
		}

		$line = implode(' ', $coords);
		$fill = $coords;
		$fill[] = round($width - $padding, 2) . ',' . round($height - $padding, 2);
		$fill[] = round($padding, 2) . ',' . round($height - $padding, 2);
		$fill_points = implode(' ', $fill);
		$metric_label = ($metric_key === 'link_clicks') ? __('7-day clicks trend', 'vms-meta-ads') : __('7-day impressions trend', 'vms-meta-ads');

		return sprintf(
			'<svg class="vms-ma-promote-sparkline-svg" viewBox="0 0 %1$d %2$d" preserveAspectRatio="none" role="img" aria-label="%3$s"><polygon class="vms-ma-promote-sparkline-fill" points="%4$s"></polygon><polyline class="vms-ma-promote-sparkline-line" points="%5$s"></polyline></svg>',
			$width,
			$height,
			esc_attr($metric_label),
			esc_attr($fill_points),
			esc_attr($line)
		);
	}
}

if (!function_exists('vms_ma_promote_fallback_initial')) {
	function vms_ma_promote_fallback_initial(string $value): string
	{
		$value = trim($value);
		if ($value === '') {
			return '?';
		}
		if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
			return mb_strtoupper(mb_substr($value, 0, 1));
		}
		return strtoupper(substr($value, 0, 1));
	}
}

if (!function_exists('vms_ma_render_promotable_events_screen')) {
	function vms_ma_render_promotable_events_screen(): void
	{
		$days = 90;
		$items = VMS_Meta_Ads_Event_Plans_Service::list_event_plans(array(
			'after' => wp_date('Y-m-d', null, wp_timezone()),
			'days' => $days,
			'limit' => 80,
			'statuses' => array('published', 'ready', 'draft'),
		));

		$items = VMS_Meta_Ads_Performance_Health_Service::enrich_promotable_items($items);
		VMS_Meta_Ads_Performance_Health_Service::maybe_send_alerts($items);
		$health_counts = VMS_Meta_Ads_Performance_Health_Service::count_levels($items);

		$summary = array('total' => count($items), 'live' => 0, 'paused' => 0, 'draft' => 0, 'attention' => 0, 'none' => 0);
		foreach ($items as $item) {
			$bucket = vms_ma_promote_state_bucket((array) $item);
			if (!isset($summary[$bucket])) {
				$bucket = 'none';
			}
			$summary[$bucket]++;
		}
		?>
		<div class="wrap vms-ma" id="vms-ma-promote-wrap">
			<div class="vms-ma-page-header">
				<div class="vms-ma-page-title">
					<h1><?php esc_html_e('Promotable Events', 'vms-meta-ads'); ?></h1>
					<p class="description vms-ma-intro"><?php echo esc_html(sprintf(__('Upcoming Event Plans in the next %d days. Choose one and jump straight into Builder.', 'vms-meta-ads'), $days)); ?></p>
				</div>
			</div>

			<?php if (empty($items)) : ?>
				<div class="notice notice-warning vms-ma-notice">
					<p><?php esc_html_e('No upcoming Event Plans found for the current window.', 'vms-meta-ads'); ?></p>
					<p><a class="button button-primary" href="<?php echo esc_url(admin_url('post-new.php?post_type=vms_event_plan')); ?>"><?php esc_html_e('Create an Event Plan', 'vms-meta-ads'); ?></a></p>
				</div>
			<?php else : ?>
				<div class="vms-ma-promote-overview">
					<div class="vms-ma-promote-overview-card is-total"><span class="vms-ma-promote-overview-label"><?php esc_html_e('Upcoming', 'vms-meta-ads'); ?></span><strong><?php echo esc_html(number_format_i18n((int) $summary['total'])); ?></strong></div>
					<div class="vms-ma-promote-overview-card is-live"><span class="vms-ma-promote-overview-label"><?php esc_html_e('Live', 'vms-meta-ads'); ?></span><strong><?php echo esc_html(number_format_i18n((int) $summary['live'])); ?></strong></div>
					<div class="vms-ma-promote-overview-card is-paused"><span class="vms-ma-promote-overview-label"><?php esc_html_e('Paused', 'vms-meta-ads'); ?></span><strong><?php echo esc_html(number_format_i18n((int) $summary['paused'])); ?></strong></div>
					<div class="vms-ma-promote-overview-card is-draft"><span class="vms-ma-promote-overview-label"><?php esc_html_e('Draft saved', 'vms-meta-ads'); ?></span><strong><?php echo esc_html(number_format_i18n((int) $summary['draft'])); ?></strong></div>
					<div class="vms-ma-promote-overview-card is-none"><span class="vms-ma-promote-overview-label"><?php esc_html_e('Not set', 'vms-meta-ads'); ?></span><strong><?php echo esc_html(number_format_i18n((int) $summary['none'])); ?></strong></div>
					<?php if (!empty($summary['attention'])) : ?>
						<div class="vms-ma-promote-overview-card is-attention"><span class="vms-ma-promote-overview-label"><?php esc_html_e('Needs attention', 'vms-meta-ads'); ?></span><strong><?php echo esc_html(number_format_i18n((int) $summary['attention'])); ?></strong></div>
					<?php endif; ?>
					<?php if (!empty($health_counts['watch'])) : ?>
						<div class="vms-ma-promote-overview-card is-watch"><span class="vms-ma-promote-overview-label"><?php esc_html_e('Watch', 'vms-meta-ads'); ?></span><strong><?php echo esc_html(number_format_i18n((int) $health_counts['watch'])); ?></strong></div>
					<?php endif; ?>
					<?php if (!empty($health_counts['underperforming'])) : ?>
						<div class="vms-ma-promote-overview-card is-underperforming"><span class="vms-ma-promote-overview-label"><?php esc_html_e('Underperforming', 'vms-meta-ads'); ?></span><strong><?php echo esc_html(number_format_i18n((int) $health_counts['underperforming'])); ?></strong></div>
					<?php endif; ?>
					<?php if (!empty($health_counts['critical'])) : ?>
						<div class="vms-ma-promote-overview-card is-critical"><span class="vms-ma-promote-overview-label"><?php esc_html_e('Critical', 'vms-meta-ads'); ?></span><strong><?php echo esc_html(number_format_i18n((int) $health_counts['critical'])); ?></strong></div>
					<?php endif; ?>
				</div>

				<div class="vms-ma-promote-list">
					<?php foreach ($items as $item) : ?>
						<?php
						$item = (array) $item;
						$promote_url = add_query_arg(array('page' => 'vms-ma-ads-builder', 'event_plan_id' => (int) $item['id'], 'prefill' => 1, 'tour' => 0), admin_url('admin.php'));
						$performance_url = admin_url('admin.php?page=vms-ma-ads-performance');
						$event_url = !empty($item['ticket_url']) ? (string) $item['ticket_url'] : (string) ($item['event_permalink'] ?? '');
						$state_badge = vms_ma_promote_state_badge($item);
						$ticket_badge = vms_ma_promote_ticket_badge($item);
						$plan_badge = vms_ma_promote_plan_badge($item);
						$thumb_url = vms_ma_promote_thumbnail_url($item);
						$show_performance = in_array($state_badge['key'], array('live', 'paused', 'attention'), true);
						$snapshot = is_array($item['performance_snapshot'] ?? null) ? (array) $item['performance_snapshot'] : array();
						$perf_state = !empty($snapshot) ? vms_ma_promote_perf_state($snapshot) : array('label' => __('Not live yet', 'vms-meta-ads'), 'class' => 'is-none');
						$metrics = is_array($snapshot['metrics'] ?? null) ? (array) $snapshot['metrics'] : array();
						$sparkline = !empty($snapshot) ? vms_ma_promote_sparkline_svg((array) ($snapshot['series'] ?? array())) : '';
						$health = is_array($item['performance_health'] ?? null) ? (array) $item['performance_health'] : array();
						$meta_detail = trim((string) ($item['meta_ads_status'] ?? ''));
						$spend = '$' . number_format_i18n((float) ($metrics['spend'] ?? 0), 2);
						$clicks = number_format_i18n((int) ($metrics['link_clicks'] ?? 0));
						$ctr = number_format_i18n((float) ($metrics['link_ctr'] ?? 0), 2) . '%';
						$impressions = number_format_i18n((int) ($metrics['impressions'] ?? 0));
						?>
						<article class="vms-ma-promote-card <?php echo esc_attr($state_badge['class']); ?>">
							<div class="vms-ma-promote-media<?php echo $thumb_url === '' ? ' is-empty' : ''; ?>">
								<?php if ($thumb_url !== '') : ?>
									<img src="<?php echo esc_url($thumb_url); ?>" alt="<?php echo esc_attr((string) $item['title']); ?>" loading="lazy" />
								<?php else : ?>
									<span class="vms-ma-promote-media-fallback"><?php echo esc_html(vms_ma_promote_fallback_initial((string) ($item['title'] ?? ''))); ?></span>
								<?php endif; ?>
							</div>
							<div class="vms-ma-promote-main">
								<div class="vms-ma-promote-head">
									<div class="vms-ma-promote-head-copy">
										<h2><?php echo esc_html((string) $item['title']); ?></h2>
										<p class="description"><?php echo esc_html((string) ($item['start_display'] ?? $item['start_local'])); ?><?php if (!empty($item['venue_name'])) : ?> · <?php echo esc_html((string) $item['venue_name']); ?><?php endif; ?></p>
									</div>
									<div class="vms-ma-promote-badges">
										<span class="vms-ma-badge <?php echo esc_attr($state_badge['class']); ?>"><?php echo esc_html((string) $state_badge['label']); ?></span>
										<span class="vms-ma-badge <?php echo esc_attr($ticket_badge['class']); ?>"><?php echo esc_html((string) $ticket_badge['label']); ?></span>
										<span class="vms-ma-badge <?php echo esc_attr($plan_badge['class']); ?>"><?php echo esc_html((string) $plan_badge['label']); ?></span>
									</div>
								</div>
								<div class="vms-ma-promote-stats">
									<div class="vms-ma-promote-stat"><span class="vms-ma-promote-stat-label"><?php esc_html_e('Meta Ad Status', 'vms-meta-ads'); ?></span><strong><?php echo esc_html((string) $state_badge['label']); ?></strong><small><?php echo esc_html($meta_detail !== '' ? $meta_detail : __('No draft yet', 'vms-meta-ads')); ?></small></div>
									<div class="vms-ma-promote-stat"><span class="vms-ma-promote-stat-label"><?php esc_html_e('Last 7 days spend', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($spend); ?></strong><small><?php echo esc_html($show_performance ? $perf_state['label'] : __('Starts after launch', 'vms-meta-ads')); ?></small></div>
									<div class="vms-ma-promote-stat"><span class="vms-ma-promote-stat-label"><?php esc_html_e('Link clicks', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($clicks); ?></strong><small><?php esc_html_e('Last 7 days', 'vms-meta-ads'); ?></small></div>
									<div class="vms-ma-promote-stat"><span class="vms-ma-promote-stat-label"><?php esc_html_e('CTR / Impressions', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($ctr); ?></strong><small><?php echo esc_html(sprintf(__('%s impressions', 'vms-meta-ads'), $impressions)); ?></small></div>
								</div>
								<?php if (!empty($health['message'])) : ?>
									<div class="vms-ma-promote-health-reason <?php echo esc_attr((string) ($health['class'] ?? '')); ?>"><?php echo esc_html((string) $health['message']); ?></div>
								<?php endif; ?>
								<?php if ($sparkline !== '') : ?>
									<div class="vms-ma-promote-trend-wrap"><div class="vms-ma-promote-trend-copy"><span class="vms-ma-promote-trend-label"><?php esc_html_e('Quick trend', 'vms-meta-ads'); ?></span><small><?php esc_html_e('Last 7 days', 'vms-meta-ads'); ?></small></div><div class="vms-ma-promote-trend-graphic"><?php echo $sparkline; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></div>
								<?php endif; ?>
							</div>
							<div class="vms-ma-promote-actions">
								<a class="button button-primary" href="<?php echo esc_url($promote_url); ?>"><?php esc_html_e('Promote', 'vms-meta-ads'); ?></a>
								<a class="button" href="<?php echo esc_url($performance_url); ?>"><?php esc_html_e('Performance', 'vms-meta-ads'); ?></a>
								<?php if ($event_url !== '') : ?>
									<a class="button button-link" href="<?php echo esc_url($event_url); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Open event', 'vms-meta-ads'); ?></a>
								<?php endif; ?>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
