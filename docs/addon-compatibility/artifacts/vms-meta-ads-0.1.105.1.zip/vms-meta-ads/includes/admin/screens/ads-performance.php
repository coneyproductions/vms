<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ma_render_performance_screen')) {
	function vms_ma_render_performance_screen(): void
	{
		$refresh_requested = !empty($_GET['refresh']);
		$refresh_ok = VMS_Meta_Ads_Performance_Service::verify_refresh_request($_GET);
		$force_refresh = ($refresh_requested && $refresh_ok);
		$sort_key = sanitize_key((string) ($_GET['sort'] ?? 'spend'));
		$order = ('asc' === strtolower((string) ($_GET['order'] ?? 'desc'))) ? 'asc' : 'desc';
		$presets = VMS_Meta_Ads_Performance_Service::get_presets();
		$sort_options = array(
			'spend' => __('Spend', 'vms-meta-ads'),
			'impressions' => __('Impressions', 'vms-meta-ads'),
			'reach' => __('Reach', 'vms-meta-ads'),
			'link_clicks' => __('Link Clicks', 'vms-meta-ads'),
			'link_ctr' => __('Link CTR', 'vms-meta-ads'),
			'link_cpc' => __('Cost / Link Click', 'vms-meta-ads'),
			'cpm' => __('CPM', 'vms-meta-ads'),
			'updated' => __('Updated', 'vms-meta-ads'),
		);
		if (!isset($sort_options[$sort_key])) {
			$sort_key = 'spend';
		}

		$data = VMS_Meta_Ads_Performance_Service::get_dashboard_data(array(
			'preset' => sanitize_key((string) ($_GET['preset'] ?? 'last_30')),
			'refresh' => $force_refresh,
		));
		$range = is_array($data['range'] ?? null) ? $data['range'] : array();
		$summary = is_array($data['summary'] ?? null) ? $data['summary'] : array();
		$rows = is_array($data['rows'] ?? null) ? $data['rows'] : array();
		$trend = is_array($data['trend'] ?? null) ? $data['trend'] : array('available' => false, 'points' => array());
		$refresh_url = VMS_Meta_Ads_Performance_Service::get_refresh_url(array_merge($range, array(
			'sort' => $sort_key,
			'order' => $order,
		)));
		$settings_url = admin_url('admin.php?page=vms-ma-ads-settings');
		$builder_url = admin_url('admin.php?page=vms-ma-ads-builder');

		$format_currency = static function ($value): string {
			return '$' . number_format_i18n((float) $value, 2);
		};
		$format_number = static function ($value): string {
			return number_format_i18n((float) $value, 0);
		};
		$format_decimal = static function ($value, int $decimals = 2): string {
			return number_format_i18n((float) $value, $decimals);
		};
		$format_percent = static function ($value) use ($format_decimal): string {
			return $format_decimal($value, 2) . '%';
		};
		$format_local = static function ($value): string {
			$timestamp = 0;
			if (is_numeric($value)) {
				$timestamp = (int) $value;
			} elseif (is_string($value) && trim($value) !== '') {
				$timestamp = strtotime($value . ' UTC');
			}
			if ($timestamp <= 0) {
				return '';
			}
			return wp_date('M j, Y g:i a', $timestamp, wp_timezone());
		};
		$format_short_date = static function (string $value): string {
			if ($value === '') {
				return '';
			}
			$timestamp = strtotime($value . ' 12:00:00');
			if ($timestamp <= 0) {
				return $value;
			}
			return wp_date('M j', $timestamp, wp_timezone());
		};
		$build_title = static function (array $build): string {
			$event_plan_id = absint($build['event_plan_id'] ?? 0);
			if ($event_plan_id > 0) {
				$title = get_the_title($event_plan_id);
				if (is_string($title) && $title !== '') {
					return $title;
				}
			}
			$copy = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
			$headline = sanitize_text_field((string) ($copy['headline'] ?? ''));
			if ($headline !== '') {
				return $headline;
			}
			return sprintf(__('Build #%d', 'vms-meta-ads'), (int) ($build['id'] ?? 0));
		};
		$truncate = static function (string $value, int $max = 36): string {
			$value = trim($value);
			if (function_exists('mb_strlen') && function_exists('mb_substr')) {
				return (mb_strlen($value) > $max) ? mb_substr($value, 0, $max - 1) . '…' : $value;
			}
			return (strlen($value) > $max) ? substr($value, 0, $max - 1) . '…' : $value;
		};

		$state_for_row = static function (array $row): array {
			$metrics = is_array($row['metrics'] ?? null) ? (array) $row['metrics'] : array();
			if (!empty($row['error'])) {
				return array('key' => 'issue', 'label' => __('Needs attention', 'vms-meta-ads'));
			}
			if (!empty($row['empty']) || (int) ($metrics['impressions'] ?? 0) <= 0) {
				return array('key' => 'no-data', 'label' => __('No data yet', 'vms-meta-ads'));
			}
			if ((int) ($metrics['link_clicks'] ?? 0) > 0) {
				return array('key' => 'clicking', 'label' => __('Getting clicks', 'vms-meta-ads'));
			}
			return array('key' => 'serving', 'label' => __('Serving / warming up', 'vms-meta-ads'));
		};

		foreach ($rows as $index => $row) {
			$build = is_array($row['build'] ?? null) ? (array) $row['build'] : array();
			$metrics = is_array($row['metrics'] ?? null) ? (array) $row['metrics'] : array();
			$rows[$index]['title'] = $build_title($build);
			$rows[$index]['state'] = $state_for_row($row);
			$sort_value = (float) ($metrics['spend'] ?? 0);
			switch ($sort_key) {
				case 'impressions':
					$sort_value = (float) ($metrics['impressions'] ?? 0);
					break;
				case 'reach':
					$sort_value = (float) ($metrics['reach'] ?? 0);
					break;
				case 'link_clicks':
					$sort_value = (float) ($metrics['link_clicks'] ?? 0);
					break;
				case 'link_ctr':
					$sort_value = (float) ($metrics['link_ctr'] ?? 0);
					break;
				case 'link_cpc':
					$sort_value = (float) ($metrics['link_cpc'] ?? 0);
					break;
				case 'cpm':
					$sort_value = (float) ($metrics['cpm'] ?? 0);
					break;
				case 'updated':
					$sort_value = (float) ($row['fetched_at'] ?? 0);
					break;
			}
			$rows[$index]['sort_value'] = $sort_value;
		}

		usort($rows, static function (array $a, array $b) use ($order) {
			$left = (float) ($a['sort_value'] ?? 0);
			$right = (float) ($b['sort_value'] ?? 0);
			if ($left === $right) {
				return strcasecmp((string) ($a['title'] ?? ''), (string) ($b['title'] ?? ''));
			}
			if ('asc' === $order) {
				return ($left <=> $right);
			}
			return ($right <=> $left);
		});

		$non_empty_rows = array_values(array_filter($rows, static function (array $row): bool {
			return empty($row['empty']) && empty($row['error']);
		}));

		$find_row = static function (array $source_rows, callable $filter, callable $score_picker, bool $want_lowest = false): ?array {
			$winner = null;
			$winner_score = null;
			foreach ($source_rows as $row) {
				if (!$filter($row)) {
					continue;
				}
				$score = (float) $score_picker($row);
				if ($winner === null) {
					$winner = $row;
					$winner_score = $score;
					continue;
				}
				if ((!$want_lowest && $score > $winner_score) || ($want_lowest && $score < $winner_score)) {
					$winner = $row;
					$winner_score = $score;
				}
			}
			return $winner;
		};

		$leader_cards = array();
		$top_clicks = $find_row($non_empty_rows, static function (array $row): bool { return (float) (($row['metrics']['link_clicks'] ?? 0)) > 0; }, static function (array $row): float { return (float) ($row['metrics']['link_clicks'] ?? 0); });
		if (is_array($top_clicks)) {
			$leader_cards[] = array(
				'label' => __('Most clicks', 'vms-meta-ads'),
				'title' => (string) ($top_clicks['title'] ?? ''),
				'value' => $format_number($top_clicks['metrics']['link_clicks'] ?? 0),
			);
		}
		$best_ctr = $find_row($non_empty_rows, static function (array $row): bool { return (float) (($row['metrics']['impressions'] ?? 0)) > 0; }, static function (array $row): float { return (float) ($row['metrics']['link_ctr'] ?? 0); });
		if (is_array($best_ctr)) {
			$leader_cards[] = array(
				'label' => __('Best CTR', 'vms-meta-ads'),
				'title' => (string) ($best_ctr['title'] ?? ''),
				'value' => $format_percent($best_ctr['metrics']['link_ctr'] ?? 0),
			);
		}
		$lowest_cpc = $find_row($non_empty_rows, static function (array $row): bool { return (float) (($row['metrics']['link_clicks'] ?? 0)) > 0; }, static function (array $row): float { return (float) ($row['metrics']['link_cpc'] ?? 0); }, true);
		if (is_array($lowest_cpc)) {
			$leader_cards[] = array(
				'label' => __('Lowest cost / click', 'vms-meta-ads'),
				'title' => (string) ($lowest_cpc['title'] ?? ''),
				'value' => $format_currency($lowest_cpc['metrics']['link_cpc'] ?? 0),
			);
		}
		$top_spend = $find_row($non_empty_rows, static function (array $row): bool { return (float) (($row['metrics']['spend'] ?? 0)) > 0; }, static function (array $row): float { return (float) ($row['metrics']['spend'] ?? 0); });
		if (is_array($top_spend)) {
			$leader_cards[] = array(
				'label' => __('Most spend', 'vms-meta-ads'),
				'title' => (string) ($top_spend['title'] ?? ''),
				'value' => $format_currency($top_spend['metrics']['spend'] ?? 0),
			);
		}

		$sort_summary = sprintf(
			/* translators: 1: field name, 2: direction */
			__('Sorted by %1$s (%2$s).', 'vms-meta-ads'),
			(string) ($sort_options[$sort_key] ?? __('Spend', 'vms-meta-ads')),
			('asc' === $order ? __('lowest first', 'vms-meta-ads') : __('highest first', 'vms-meta-ads'))
		);

		$build_mix_rows = array();
		$total_spend = max(0.0, (float) ($summary['spend'] ?? 0));
		$total_clicks = max(0, (int) ($summary['link_clicks'] ?? 0));
		foreach (array_slice($non_empty_rows, 0, 6) as $row) {
			$metrics = is_array($row['metrics'] ?? null) ? (array) $row['metrics'] : array();
			$spend = (float) ($metrics['spend'] ?? 0);
			$clicks = (int) ($metrics['link_clicks'] ?? 0);
			$build_mix_rows[] = array(
				'title' => (string) ($row['title'] ?? ''),
				'label' => $truncate((string) ($row['title'] ?? ''), 30),
				'spend_share' => ($total_spend > 0) ? (($spend / $total_spend) * 100) : 0.0,
				'click_share' => ($total_clicks > 0) ? (($clicks / $total_clicks) * 100) : 0.0,
				'ctr' => (float) ($metrics['link_ctr'] ?? 0),
				'spend' => $spend,
				'clicks' => $clicks,
			);
		}

		$build_line_chart = static function (array $points, string $metric_key, string $metric_label, callable $value_formatter, callable $date_formatter): string {
			if (count($points) < 2) {
				return '';
			}
			$values = array();
			foreach ($points as $point) {
				$values[] = (float) ($point[$metric_key] ?? 0);
			}
			$max = max($values);
			$min = min($values);
			if ($max <= 0 && $min <= 0) {
				return '';
			}
			if ($max === $min) {
				$min = 0.0;
			}
			$width = 640;
			$height = 220;
			$left = 42;
			$right = 12;
			$top = 16;
			$bottom = 30;
			$plot_width = $width - $left - $right;
			$plot_height = $height - $top - $bottom;
			$count = count($points);
			$step_x = ($count > 1) ? ($plot_width / ($count - 1)) : $plot_width;
			$range = max(0.00001, $max - $min);
			$line = array();
			$area = array();
			$dots = array();
			foreach ($points as $index => $point) {
				$value = (float) ($point[$metric_key] ?? 0);
				$x = $left + ($index * $step_x);
				$y = $top + $plot_height - (($value - $min) / $range) * $plot_height;
				$line[] = sprintf('%1$.2f,%2$.2f', $x, $y);
				$area[] = sprintf('%1$.2f,%2$.2f', $x, $y);
				$dots[] = array('x' => $x, 'y' => $y, 'value' => $value, 'date' => (string) ($point['date'] ?? ''));
			}
			$area_path = 'M ' . sprintf('%1$.2f,%2$.2f', $left, $top + $plot_height) . ' L ' . implode(' L ', $area) . ' L ' . sprintf('%1$.2f,%2$.2f', $left + $plot_width, $top + $plot_height) . ' Z';
			$line_path = 'M ' . implode(' L ', $line);
			$grid = array();
			for ($i = 0; $i < 4; $i++) {
				$ratio = $i / 3;
				$y = $top + ($plot_height * $ratio);
				$label_value = $max - (($max - $min) * $ratio);
				$grid[] = array('y' => $y, 'label' => $value_formatter($label_value));
			}
			$label_points = array();
			$label_indexes = array_unique(array(0, (int) floor(($count - 1) * 0.33), (int) floor(($count - 1) * 0.66), $count - 1));
			foreach ($label_indexes as $index) {
				if (!isset($points[$index])) {
					continue;
				}
				$label_points[] = array(
					'x' => $left + ($index * $step_x),
					'label' => $date_formatter((string) ($points[$index]['date'] ?? '')),
				);
			}
			ob_start();
			?>
			<svg class="vms-ma-performance-line-chart" viewBox="0 0 <?php echo esc_attr((string) $width); ?> <?php echo esc_attr((string) $height); ?>" role="img" aria-label="<?php echo esc_attr($metric_label); ?>">
				<?php foreach ($grid as $grid_line) : ?>
					<line x1="<?php echo esc_attr((string) $left); ?>" y1="<?php echo esc_attr((string) $grid_line['y']); ?>" x2="<?php echo esc_attr((string) ($left + $plot_width)); ?>" y2="<?php echo esc_attr((string) $grid_line['y']); ?>" class="vms-ma-performance-line-grid" />
					<text x="6" y="<?php echo esc_attr((string) ($grid_line['y'] + 4)); ?>" class="vms-ma-performance-line-axis"><?php echo esc_html((string) $grid_line['label']); ?></text>
				<?php endforeach; ?>
				<path d="<?php echo esc_attr($area_path); ?>" class="vms-ma-performance-line-area" />
				<path d="<?php echo esc_attr($line_path); ?>" class="vms-ma-performance-line-stroke" />
				<?php foreach ($dots as $dot) : ?>
					<circle cx="<?php echo esc_attr((string) $dot['x']); ?>" cy="<?php echo esc_attr((string) $dot['y']); ?>" r="3" class="vms-ma-performance-line-dot">
						<title><?php echo esc_html($date_formatter((string) $dot['date']) . ' — ' . $value_formatter((float) $dot['value'])); ?></title>
					</circle>
				<?php endforeach; ?>
				<?php foreach ($label_points as $label_point) : ?>
					<text x="<?php echo esc_attr((string) $label_point['x']); ?>" y="<?php echo esc_attr((string) ($height - 8)); ?>" text-anchor="middle" class="vms-ma-performance-line-axis"><?php echo esc_html((string) $label_point['label']); ?></text>
				<?php endforeach; ?>
			</svg>
			<?php
			return trim((string) ob_get_clean());
		};

		$trend_points = is_array($trend['points'] ?? null) ? (array) $trend['points'] : array();
		$spend_chart = $build_line_chart($trend_points, 'spend', __('Daily spend trend', 'vms-meta-ads'), $format_currency, $format_short_date);
		$click_chart = $build_line_chart($trend_points, 'link_clicks', __('Daily click trend', 'vms-meta-ads'), $format_number, $format_short_date);
		$ctr_chart = $build_line_chart($trend_points, 'link_ctr', __('Daily CTR trend', 'vms-meta-ads'), $format_percent, $format_short_date);
		?>
		<div class="wrap vms-ma" id="vms-ma-performance-wrap">
			<div class="vms-ma-page-header">
				<h1><?php esc_html_e('Meta Ads Performance', 'vms-meta-ads'); ?></h1>
				<p class="description"><?php esc_html_e('See your Meta ad performance without opening Ads Manager.', 'vms-meta-ads'); ?></p>
			</div>

			<?php if ($refresh_requested && !$refresh_ok) : ?>
				<div class="notice notice-error vms-ma-notice"><p><?php esc_html_e('Performance refresh link expired. Reload the page and try again.', 'vms-meta-ads'); ?></p></div>
			<?php elseif ($force_refresh) : ?>
				<div class="notice notice-success vms-ma-notice"><p><?php esc_html_e('Performance refreshed from Meta.', 'vms-meta-ads'); ?></p></div>
			<?php endif; ?>

			<form method="get" class="vms-ma-performance-toolbar" id="vms-ma-performance-toolbar">
				<input type="hidden" name="page" value="vms-ma-ads-performance" />
				<div class="vms-ma-performance-control">
					<label for="vms-ma-performance-preset"><?php esc_html_e('Date range', 'vms-meta-ads'); ?></label>
					<select id="vms-ma-performance-preset" name="preset">
						<?php foreach ($presets as $preset_key => $preset_label) : ?>
							<option value="<?php echo esc_attr($preset_key); ?>" <?php selected((string) ($range['preset'] ?? ''), (string) $preset_key); ?>><?php echo esc_html($preset_label); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="vms-ma-performance-control">
					<label for="vms-ma-performance-sort"><?php esc_html_e('Sort table by', 'vms-meta-ads'); ?></label>
					<select id="vms-ma-performance-sort" name="sort">
						<?php foreach ($sort_options as $sort_option_key => $sort_option_label) : ?>
							<option value="<?php echo esc_attr($sort_option_key); ?>" <?php selected($sort_key, $sort_option_key); ?>><?php echo esc_html($sort_option_label); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="vms-ma-performance-control">
					<label for="vms-ma-performance-order"><?php esc_html_e('Direction', 'vms-meta-ads'); ?></label>
					<select id="vms-ma-performance-order" name="order">
						<option value="desc" <?php selected($order, 'desc'); ?>><?php esc_html_e('Highest first', 'vms-meta-ads'); ?></option>
						<option value="asc" <?php selected($order, 'asc'); ?>><?php esc_html_e('Lowest first', 'vms-meta-ads'); ?></option>
					</select>
				</div>
				<div class="vms-ma-performance-actions">
					<button type="submit" class="button button-secondary"><?php esc_html_e('Apply', 'vms-meta-ads'); ?></button>
					<a class="button" href="<?php echo esc_url($refresh_url); ?>"><?php esc_html_e('Refresh from Meta', 'vms-meta-ads'); ?></a>
				</div>
			</form>

			<?php if (is_wp_error($data['connection'] ?? null)) : ?>
				<div class="notice notice-warning vms-ma-notice">
					<p><strong><?php esc_html_e('Performance is not ready yet.', 'vms-meta-ads'); ?></strong> <?php echo esc_html($data['connection']->get_error_message()); ?></p>
					<p><a class="button button-primary" href="<?php echo esc_url($settings_url); ?>"><?php esc_html_e('Open Settings', 'vms-meta-ads'); ?></a></p>
				</div>
			<?php elseif (empty($data['builds'])) : ?>
				<div class="notice notice-info vms-ma-notice">
					<p><strong><?php esc_html_e('No Meta-linked builds found yet.', 'vms-meta-ads'); ?></strong> <?php esc_html_e('Save a draft, then use Create in Meta (Paused) so this screen has a campaign, ad set, or ad to report on.', 'vms-meta-ads'); ?></p>
					<p><a class="button button-primary" href="<?php echo esc_url($builder_url); ?>"><?php esc_html_e('Open Builder', 'vms-meta-ads'); ?></a></p>
				</div>
			<?php else : ?>
				<div class="vms-ma-performance-meta">
					<p><strong><?php echo esc_html(sprintf(__('Showing %1$s across %2$d build(s).', 'vms-meta-ads'), (string) ($range['label'] ?? __('Last 30 days', 'vms-meta-ads')), count($data['builds']))); ?></strong></p>
					<p class="description"><?php esc_html_e('Reported reach can overlap across ads, so treat the reach total as directional rather than deduplicated.', 'vms-meta-ads'); ?></p>
					<p class="description"><?php echo esc_html($sort_summary); ?></p>
				</div>

				<div class="vms-ma-performance-cards">
					<div class="vms-ma-performance-card"><span><?php esc_html_e('Spend', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($format_currency($summary['spend'] ?? 0)); ?></strong></div>
					<div class="vms-ma-performance-card"><span><?php esc_html_e('Impressions', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($format_number($summary['impressions'] ?? 0)); ?></strong></div>
					<div class="vms-ma-performance-card"><span><?php esc_html_e('Reported Reach', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($format_number($summary['reach'] ?? 0)); ?></strong></div>
					<div class="vms-ma-performance-card"><span><?php esc_html_e('Link Clicks', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($format_number($summary['link_clicks'] ?? 0)); ?></strong></div>
					<div class="vms-ma-performance-card"><span><?php esc_html_e('Link CTR', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($format_percent($summary['link_ctr'] ?? 0)); ?></strong></div>
					<div class="vms-ma-performance-card"><span><?php esc_html_e('Cost / Link Click', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($format_currency($summary['link_cpc'] ?? 0)); ?></strong></div>
					<div class="vms-ma-performance-card"><span><?php esc_html_e('CPM', 'vms-meta-ads'); ?></span><strong><?php echo esc_html($format_currency($summary['cpm'] ?? 0)); ?></strong></div>
				</div>

				<?php if (!empty($leader_cards)) : ?>
					<div class="vms-ma-performance-leaders">
						<?php foreach ($leader_cards as $leader) : ?>
							<div class="vms-ma-performance-leader-card">
								<span><?php echo esc_html((string) ($leader['label'] ?? '')); ?></span>
								<strong><?php echo esc_html((string) ($leader['value'] ?? '')); ?></strong>
								<div class="vms-ma-performance-subline"><?php echo esc_html((string) ($leader['title'] ?? '')); ?></div>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<div class="vms-ma-performance-visuals" id="vms-ma-performance-visuals">
					<div class="vms-ma-performance-chart-card vms-ma-performance-chart-card--wide">
						<div class="vms-ma-performance-chart-head">
							<h2><?php esc_html_e('Daily spend trend', 'vms-meta-ads'); ?></h2>
							<p><?php esc_html_e('Much more useful than a winner-only bar: this shows when your budget actually moved.', 'vms-meta-ads'); ?></p>
						</div>
						<?php if ($spend_chart !== '') : ?>
							<?php echo $spend_chart; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php else : ?>
							<p class="description"><?php esc_html_e('Not enough dated spend data yet to draw a trend line.', 'vms-meta-ads'); ?></p>
						<?php endif; ?>
					</div>

					<div class="vms-ma-performance-chart-card">
						<div class="vms-ma-performance-chart-head">
							<h2><?php esc_html_e('Daily link clicks', 'vms-meta-ads'); ?></h2>
							<p><?php esc_html_e('Traffic is easier to judge when you can see which days actually produced clicks.', 'vms-meta-ads'); ?></p>
						</div>
						<?php if ($click_chart !== '') : ?>
							<?php echo $click_chart; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php else : ?>
							<p class="description"><?php esc_html_e('Not enough click data yet to draw a trend line.', 'vms-meta-ads'); ?></p>
						<?php endif; ?>
					</div>

					<div class="vms-ma-performance-chart-card">
						<div class="vms-ma-performance-chart-head">
							<h2><?php esc_html_e('Daily CTR', 'vms-meta-ads'); ?></h2>
							<p><?php esc_html_e('CTR makes more sense over time than as a maxed-out bar when you only have a couple of ads.', 'vms-meta-ads'); ?></p>
						</div>
						<?php if ($ctr_chart !== '') : ?>
							<?php echo $ctr_chart; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php else : ?>
							<p class="description"><?php esc_html_e('Not enough dated impression data yet to draw a CTR trend line.', 'vms-meta-ads'); ?></p>
						<?php endif; ?>
					</div>

					<div class="vms-ma-performance-chart-card">
						<div class="vms-ma-performance-chart-head">
							<h2><?php esc_html_e('Build mix snapshot', 'vms-meta-ads'); ?></h2>
							<p><?php esc_html_e('This compares share of spend and share of clicks, which is more helpful when only a few ads are live.', 'vms-meta-ads'); ?></p>
						</div>
						<?php if (!empty($build_mix_rows)) : ?>
							<div class="vms-ma-performance-mix-list">
								<?php foreach ($build_mix_rows as $mix_row) : ?>
									<div class="vms-ma-performance-mix-row">
										<div class="vms-ma-performance-mix-head">
											<strong title="<?php echo esc_attr((string) $mix_row['title']); ?>"><?php echo esc_html((string) $mix_row['label']); ?></strong>
											<span><?php echo esc_html($format_percent($mix_row['ctr'])); ?> CTR</span>
										</div>
										<div class="vms-ma-performance-mix-track">
											<span class="vms-ma-performance-mix-fill vms-ma-performance-mix-fill--spend" style="width: <?php echo esc_attr((string) max(4, min(100, (float) $mix_row['spend_share']))); ?>%;"></span>
										</div>
										<div class="vms-ma-performance-mix-meta">
											<span><?php echo esc_html(sprintf(__('Spend share: %s', 'vms-meta-ads'), $format_percent($mix_row['spend_share']))); ?></span>
											<span><?php echo esc_html(sprintf(__('Click share: %s', 'vms-meta-ads'), $format_percent($mix_row['click_share']))); ?></span>
										</div>
									</div>
								<?php endforeach; ?>
							</div>
						<?php else : ?>
							<p class="description"><?php esc_html_e('No build mix data yet for this date range.', 'vms-meta-ads'); ?></p>
						<?php endif; ?>
					</div>
				</div>

				<div class="vms-ma-performance-table-wrap" id="vms-ma-performance-table">
					<table class="widefat striped vms-ma-performance-table">
						<thead>
							<tr>
								<th><?php esc_html_e('Build', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Performance State', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Meta Object', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Spend', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Impressions', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Reach', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Link Clicks', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Link CTR', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Cost / Link Click', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('CPM', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Primary Result', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Cost / Result', 'vms-meta-ads'); ?></th>
								<th><?php esc_html_e('Updated', 'vms-meta-ads'); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($rows as $row) : ?>
								<?php
								$build = is_array($row['build'] ?? null) ? (array) $row['build'] : array();
								$reference = is_array($row['reference'] ?? null) ? (array) $row['reference'] : array();
								$metrics = is_array($row['metrics'] ?? null) ? (array) $row['metrics'] : array();
								$title = (string) ($row['title'] ?? $build_title($build));
								$build_status = sanitize_text_field((string) ($build['status'] ?? ''));
								$updated = (int) ($row['fetched_at'] ?? 0);
								$created_local = $format_local((string) ($build['created_at'] ?? ''));
								$state = is_array($row['state'] ?? null) ? (array) $row['state'] : array('key' => 'serving', 'label' => __('Unknown', 'vms-meta-ads'));
								?>
								<tr class="vms-ma-performance-row state-<?php echo esc_attr((string) ($state['key'] ?? 'serving')); ?>">
									<td>
										<strong><?php echo esc_html($title); ?></strong>
										<div class="vms-ma-performance-subline"><?php echo esc_html(sprintf(__('Build #%1$d • %2$s', 'vms-meta-ads'), (int) ($build['id'] ?? 0), $build_status !== '' ? $build_status : __('unknown', 'vms-meta-ads'))); ?></div>
										<?php if ($created_local !== '') : ?><div class="vms-ma-performance-subline"><?php echo esc_html(sprintf(__('Saved %s', 'vms-meta-ads'), $created_local)); ?></div><?php endif; ?>
										<?php if (!empty($row['error'])) : ?><div class="vms-ma-performance-error"><?php echo esc_html($row['error']); ?></div><?php endif; ?>
									</td>
									<td><span class="vms-ma-performance-pill state-<?php echo esc_attr((string) ($state['key'] ?? 'serving')); ?>"><?php echo esc_html((string) ($state['label'] ?? __('Unknown', 'vms-meta-ads'))); ?></span></td>
									<td>
										<?php if (!empty($reference['object_label']) && !empty($reference['object_id'])) : ?>
											<strong><?php echo esc_html((string) $reference['object_label']); ?></strong>
											<div class="vms-ma-performance-subline"><?php echo esc_html((string) $reference['object_id']); ?></div>
											<?php if (!empty($reference['manager_url'])) : ?><div class="vms-ma-performance-subline"><a href="<?php echo esc_url((string) $reference['manager_url']); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Open in Meta', 'vms-meta-ads'); ?></a></div><?php endif; ?>
										<?php else : ?>
											&mdash;
										<?php endif; ?>
									</td>
									<td><?php echo esc_html($row['ok'] ? $format_currency($metrics['spend'] ?? 0) : '—'); ?></td>
									<td><?php echo esc_html($row['ok'] ? $format_number($metrics['impressions'] ?? 0) : '—'); ?></td>
									<td><?php echo esc_html($row['ok'] ? $format_number($metrics['reach'] ?? 0) : '—'); ?></td>
									<td><?php echo esc_html($row['ok'] ? $format_number($metrics['link_clicks'] ?? 0) : '—'); ?></td>
									<td><?php echo esc_html($row['ok'] ? $format_percent($metrics['link_ctr'] ?? 0) : '—'); ?></td>
									<td><?php echo esc_html($row['ok'] ? $format_currency($metrics['link_cpc'] ?? 0) : '—'); ?></td>
									<td><?php echo esc_html($row['ok'] ? $format_currency($metrics['cpm'] ?? 0) : '—'); ?></td>
									<td>
										<?php if ($row['ok'] && !empty($metrics['result_label'])) : ?>
											<?php echo esc_html((string) $metrics['result_label']); ?>
											<div class="vms-ma-performance-subline"><?php echo esc_html($format_decimal($metrics['result_count'] ?? 0, 0)); ?></div>
										<?php elseif (!empty($row['empty'])) : ?>
											<?php esc_html_e('No data yet', 'vms-meta-ads'); ?>
										<?php else : ?>
											&mdash;
										<?php endif; ?>
									</td>
									<td>
										<?php if ($row['ok'] && !empty($metrics['result_label']) && (float) ($metrics['result_count'] ?? 0) > 0) : ?>
											<?php echo esc_html($format_currency($metrics['cost_per_result'] ?? 0)); ?>
										<?php else : ?>
											&mdash;
										<?php endif; ?>
									</td>
									<td><?php echo esc_html($updated > 0 ? $format_local($updated) : '—'); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>

				<details class="vms-ma-performance-diagnostics">
					<summary>
						<span><?php esc_html_e('Meta Performance Diagnostics', 'vms-meta-ads'); ?></span>
						<small><?php esc_html_e('Collapsed by default', 'vms-meta-ads'); ?></small>
					</summary>
					<div class="vms-ma-performance-diagnostics-body">
						<?php vms_render_api_diagnostics_panel(array(
							'provider_slug' => 'meta_ads',
							'module_slug' => 'vms-facebook-ads',
							'context' => 'performance',
							'title' => __('Meta Performance Diagnostics', 'vms-meta-ads'),
							'limit' => 10,
							'ajax_action' => 'vms_api_copy_bundle',
						)); ?>
					</div>
				</details>
			<?php endif; ?>
		</div>
		<?php
	}
}
