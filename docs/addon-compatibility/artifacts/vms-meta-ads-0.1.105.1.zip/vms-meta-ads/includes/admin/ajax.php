<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_API_Diagnostics_Ajax')) {
	class VMS_API_Diagnostics_Ajax {
		public static function init(): void
		{
			add_action('wp_ajax_vms_api_copy_bundle', array(__CLASS__, 'copy_bundle'));
			add_action('wp_ajax_vms_api_diag_panel_html', array(__CLASS__, 'panel_html'));
		}

			public static function copy_bundle(): void
			{
			if (!current_user_can('manage_options')) {
				wp_send_json(array('ok' => false, 'message' => __('Not allowed.', 'vms-meta-ads')), 403);
			}
			$nonce = isset($_POST['nonce']) ? sanitize_text_field((string) $_POST['nonce']) : '';
			if ($nonce === '' || !wp_verify_nonce($nonce, 'vms_api_diag_nonce')) {
				wp_send_json(array('ok' => false, 'message' => __('Invalid request.', 'vms-meta-ads')), 403);
			}

				$mode = isset($_POST['mode']) ? sanitize_key((string) $_POST['mode']) : '';
				$attempt = null;
				if ($mode !== '') {
					$provider_slug = sanitize_key((string) ($_POST['provider_slug'] ?? ''));
					$context_raw = isset($_POST['context']) ? sanitize_key((string) $_POST['context']) : '';
					$context = ($context_raw !== '') ? $context_raw : null;
					$attempt = vms_api_attempt_get_latest_for_mode($provider_slug, $context, $mode);
					if (!$attempt) {
						$messages = array(
							'latest_failed_meta_call' => __('No failed Meta API calls logged yet.', 'vms-meta-ads'),
							'last_failure' => __('No failed Meta API calls logged yet.', 'vms-meta-ads'),
							'latest_dry_run' => __('No Meta dry runs logged yet.', 'vms-meta-ads'),
							'latest_attempt' => __('No API attempts logged yet.', 'vms-meta-ads'),
						);
						wp_send_json(array('ok' => false, 'message' => $messages[$mode] ?? __('No matching API attempt was found.', 'vms-meta-ads')));
					}
				} else {
					$attempt_id = absint($_POST['attempt_id'] ?? 0);
					if ($attempt_id < 1) {
						wp_send_json(array('ok' => false, 'message' => __('Attempt ID is required.', 'vms-meta-ads')), 400);
					}
					$attempt = vms_api_attempt_get_by_id($attempt_id);
					if (!is_array($attempt)) {
						wp_send_json(array('ok' => false, 'message' => __('Attempt not found.', 'vms-meta-ads')), 404);
					}
				}

				$bundle = vms_api_attempt_build_bundle_text((array) $attempt);
				$attempt_summary = vms_api_attempt_summarize((array) $attempt);
				wp_send_json(array(
					'ok' => true,
					'bundle_text' => $bundle,
					'attempt' => $attempt_summary,
				));
			}

		public static function panel_html(): void
		{
			if (!current_user_can('manage_options')) {
				wp_send_json(array('ok' => false, 'message' => __('Not allowed.', 'vms-meta-ads')), 403);
			}
			$nonce = isset($_POST['nonce']) ? sanitize_text_field((string) $_POST['nonce']) : '';
			if ($nonce === '' || !wp_verify_nonce($nonce, 'vms_api_diag_nonce')) {
				wp_send_json(array('ok' => false, 'message' => __('Invalid request.', 'vms-meta-ads')), 403);
			}
			$provider_slug = sanitize_key((string) ($_POST['provider_slug'] ?? ''));
			$module_slug = sanitize_text_field((string) ($_POST['module_slug'] ?? ''));
			$context_raw = isset($_POST['context']) ? sanitize_key((string) $_POST['context']) : '';
			$context = ($context_raw !== '') ? $context_raw : null;
			if ($provider_slug === '' || $module_slug === '') {
				wp_send_json(array('ok' => false, 'message' => __('Missing diagnostics scope.', 'vms-meta-ads')), 400);
			}
			ob_start();
			vms_render_api_diagnostics_panel(array(
				'provider_slug' => $provider_slug,
				'module_slug' => $module_slug,
				'context' => $context,
				'title' => __('Meta API Diagnostics', 'vms-meta-ads'),
				'limit' => 10,
				'ajax_action' => 'vms_api_copy_bundle',
			));
			$html = (string) ob_get_clean();
			wp_send_json(array('ok' => true, 'html' => $html));
		}
	}
}

VMS_API_Diagnostics_Ajax::init();
