<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Admin')) {
	class VMS_Meta_Ads_Admin {
		public static function init(): void
		{
			add_action('admin_menu', array(__CLASS__, 'register_menu'));
		}

		public static function register_menu(): void
		{
			$cap = VMS_Meta_Ads_Caps::get_manage_capability();
			$parent = 'vms-dashboard';
			add_submenu_page($parent, __('Meta Ads Builder', 'vms-meta-ads'), __('Meta Ads Builder', 'vms-meta-ads'), $cap, 'vms-ma-ads-builder', array(__CLASS__, 'render_builder'));
			add_submenu_page($parent, __('Promotable Events', 'vms-meta-ads'), __('Promotable Events', 'vms-meta-ads'), $cap, 'vms-ma-ads-promote', array(__CLASS__, 'render_promote'));
			add_submenu_page($parent, __('Meta Ads Performance', 'vms-meta-ads'), __('Meta Ads Performance', 'vms-meta-ads'), $cap, 'vms-ma-ads-performance', array(__CLASS__, 'render_performance'));
			add_submenu_page($parent, __('Meta Ads Logs', 'vms-meta-ads'), __('Meta Ads Logs', 'vms-meta-ads'), $cap, 'vms-ma-ads-logs', array(__CLASS__, 'render_logs'));
			add_submenu_page($parent, __('Meta Ads Settings', 'vms-meta-ads'), __('Meta Ads Settings', 'vms-meta-ads'), $cap, 'vms-ma-ads-settings', array(__CLASS__, 'render_settings'));
		}

		public static function render_builder(): void
		{
			if (!vms_ma_current_user_can_manage()) {
				wp_die(__('Insufficient permissions.', 'vms-meta-ads'));
			}
			require_once VMS_MA_PATH . 'includes/admin/screens/ads-builder.php';
			if (function_exists('vms_ma_render_ads_builder_screen')) {
				vms_ma_render_ads_builder_screen();
			}
		}

		public static function render_performance(): void
		{
			if (!vms_ma_current_user_can_manage()) {
				wp_die(__('Insufficient permissions.', 'vms-meta-ads'));
			}
			require_once VMS_MA_PATH . 'includes/admin/screens/ads-performance.php';
			if (function_exists('vms_ma_render_performance_screen')) {
				vms_ma_render_performance_screen();
			}
		}

		public static function render_promote(): void
		{
			if (!vms_ma_current_user_can_manage()) {
				wp_die(__('Insufficient permissions.', 'vms-meta-ads'));
			}
			require_once VMS_MA_PATH . 'includes/admin/screens/promotable-events.php';
			if (function_exists('vms_ma_render_promotable_events_screen')) {
				vms_ma_render_promotable_events_screen();
			}
		}

		public static function render_logs(): void
		{
			if (!vms_ma_current_user_can_manage()) {
				wp_die(__('Insufficient permissions.', 'vms-meta-ads'));
			}
			require_once VMS_MA_PATH . 'includes/admin/screens/logs.php';
			if (function_exists('vms_ma_render_logs_screen')) {
				vms_ma_render_logs_screen();
			}
		}

		public static function render_settings(): void
		{
			if (!vms_ma_current_user_can_manage()) {
				wp_die(__('Insufficient permissions.', 'vms-meta-ads'));
			}
			require_once VMS_MA_PATH . 'includes/admin/screens/settings.php';
			if (function_exists('vms_ma_render_settings_screen')) {
				vms_ma_render_settings_screen();
			}
		}
	}
}
