<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Meta_Endpoints')) {
	class VMS_Meta_Ads_Meta_Endpoints {
		public static function base_url(array $settings): string
		{
			return 'https://graph.facebook.com/' . rawurlencode($settings['meta_graph_version'] ?? 'v24.0') . '/';
		}

		public static function ad_account_endpoint(string $ad_account_id): string
		{
			return 'act_' . ltrim($ad_account_id, 'act_');
		}

		public static function build_url(array $settings, string $path): string
		{
			return trailingslashit(self::base_url($settings)) . ltrim($path, '/');
		}
	}
}
