<?php

defined('ABSPATH') || exit;

if (!class_exists('VMS_Meta_Ads_Meta_Client')) {
	class VMS_Meta_Ads_Meta_Client
	{
		private const STATUS_ACTIVE = 'ACTIVE';
		private const STATUS_PAUSED = 'PAUSED';
		private const STATUS_PENDING_REVIEW = 'PENDING_REVIEW';
		private const STATUS_IN_PROCESS = 'IN_PROCESS';
		private const STATUS_PREAPPROVED = 'PREAPPROVED';
		private const STATUS_CAMPAIGN_PAUSED = 'CAMPAIGN_PAUSED';
		private const STATUS_ADSET_PAUSED = 'ADSET_PAUSED';
		private const STATUS_WITH_ISSUES = 'WITH_ISSUES';
		private const STATUS_DISAPPROVED = 'DISAPPROVED';
		private const STATUS_REJECTED = 'REJECTED';
		private const STATUS_PENDING_BILLING_INFO = 'PENDING_BILLING_INFO';

		public static function is_enabled(): bool
		{
			$settings = VMS_Meta_Ads_Utils::get_settings();
			return !empty($settings['enable_api_create']);
		}

		public static function dry_run_bundle(int $build_id)
		{
			$build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
			if (is_wp_error($build)) {
				return $build;
			}
			if (!vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to inspect Meta dry-run payloads.', 'vms-meta-ads'), array('status' => 403));
			}

			$preview = self::build_dry_run_preview($build);
			$preview['logged_attempt_id'] = self::log_dry_run_attempt($preview);
			$preview['ok'] = true;
			$preview['message'] = !empty($preview['create_ready'])
				? __('Meta dry run generated. No Meta API calls were made.', 'vms-meta-ads')
				: __('Meta dry run generated with blockers. No Meta API calls were made.', 'vms-meta-ads');

			return $preview;
		}

		private static function build_dry_run_preview(array $build): array
		{
			$settings = self::preview_connection_settings();
			$connection_state = self::build_dry_run_connection_state($settings);
			$dsa_readiness = self::dsa_readiness($settings);
			$build_id = max(0, (int) ($build['id'] ?? 0));
			$event_plan_id = max(0, (int) ($build['event_plan_id'] ?? 0));
			$copy = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
			$targeting_payload = is_array($build['targeting_payload'] ?? null) ? (array) $build['targeting_payload'] : array();
			$placements_payload = is_array($build['placements_payload'] ?? null) ? (array) $build['placements_payload'] : array();
			$schedule_payload = is_array($build['schedule_payload'] ?? null) ? (array) $build['schedule_payload'] : array();
			$budget_payload = is_array($build['budget_payload'] ?? null) ? (array) $build['budget_payload'] : array();
			$blockers = array();
			$warnings = array();

			if (empty($connection_state['api_enabled'])) {
				self::append_dry_run_message($blockers, __('Create in Meta is disabled because the API create setting is off.', 'vms-meta-ads'));
			}
			if (empty($connection_state['meta_ad_account_id_present'])) {
				self::append_dry_run_message($blockers, __('Meta Ad Account ID is missing.', 'vms-meta-ads'));
			}
			if (empty($connection_state['meta_page_id_present'])) {
				self::append_dry_run_message($blockers, __('Meta Page ID is missing.', 'vms-meta-ads'));
			}
			if (($connection_state['token_state'] ?? 'missing') !== 'present') {
				self::append_dry_run_message($blockers, __('Meta access token is missing or intentionally disconnected.', 'vms-meta-ads'));
			}
			if (empty($connection_state['connection_fresh'])) {
				self::append_dry_run_message($blockers, __('Connection test is missing or older than 24 hours.', 'vms-meta-ads'));
			}
			foreach ((array) ($dsa_readiness['warnings'] ?? array()) as $warning) {
				self::append_dry_run_message($warnings, (string) $warning);
			}

			if ($event_plan_id < 1) {
				self::append_dry_run_message($blockers, __('This build is not linked to an Event Plan yet. Save Draft first.', 'vms-meta-ads'));
			} else {
				$post = get_post($event_plan_id);
				if (!$post || $post->post_type !== 'vms_event_plan') {
					self::append_dry_run_message($blockers, __('Linked Event Plan could not be loaded.', 'vms-meta-ads'));
				} elseif (!current_user_can('edit_post', $event_plan_id)) {
					self::append_dry_run_message($blockers, __('Current user cannot edit the linked Event Plan.', 'vms-meta-ads'));
				}
			}

			$creative_mode = sanitize_key((string) ($build['creative_mode'] ?? 'dark_post'));
			if ($creative_mode !== 'dark_post') {
				self::append_dry_run_message($blockers, __('Create in Meta currently supports Dark Post Link Ad only.', 'vms-meta-ads'));
			}
			$lockdown_ok = self::validate_creative_lockdown_controls($build);
			if (is_wp_error($lockdown_ok)) {
				self::append_dry_run_message($blockers, $lockdown_ok->get_error_message());
			}

			$schedule_support = self::resolve_schedule_create_support($build);
			$preset = (string) ($schedule_support['preset'] ?? 'flat_run');
			if (empty($schedule_support['supported']) && !empty($schedule_support['dry_run_message'])) {
				self::append_dry_run_message($warnings, (string) $schedule_support['dry_run_message']);
			}

			$tier = self::resolve_create_tier($build);
			$start_iso = '';
			$end_iso = '';
			$tier_key = sanitize_key((string) ($schedule_support['tier_key'] ?? $preset)) ?: 'flat_run';
			$tier_label = sanitize_text_field((string) ($schedule_support['tier_label'] ?? self::schedule_preset_label($preset)));
			$lifetime_budget_minor = absint($budget_payload['total_budget_minor'] ?? 0);
			if (is_wp_error($tier)) {
				self::append_dry_run_message($blockers, $tier->get_error_message());
				$tier = array();
			} else {
				$tier_key = sanitize_key((string) ($tier['tier_key'] ?? $tier_key)) ?: $tier_key;
				$tier_label = sanitize_text_field((string) ($tier['tier_label'] ?? $tier_label)) ?: $tier_label;
				$lifetime_budget_minor = absint($tier['budget_amount_minor'] ?? 0);
				$start_iso = self::to_meta_iso8601((string) ($tier['start_time'] ?? ''), $settings);
				$end_iso = self::to_meta_iso8601((string) ($tier['end_time'] ?? ''), $settings);
				if ($start_iso === '' || $end_iso === '') {
					self::append_dry_run_message($blockers, __('Schedule dates could not be converted into Meta account time.', 'vms-meta-ads'));
				} else {
					try {
						$end_dt = new DateTimeImmutable($end_iso);
						if ($end_dt <= new DateTimeImmutable('now', new DateTimeZone('UTC'))) {
							self::append_dry_run_message($blockers, __('Schedule already ended. Update the schedule before creating in Meta.', 'vms-meta-ads'));
						}
					} catch (Exception $e) {
						self::append_dry_run_message($blockers, __('Schedule end time is invalid for Meta create.', 'vms-meta-ads'));
					}
				}
				$budget_floor_check = self::validate_minimum_meta_budget_per_day((array) $tier);
				if (is_wp_error($budget_floor_check)) {
					self::append_dry_run_message($blockers, $budget_floor_check->get_error_message());
				}
			}

			$destination_url = esc_url_raw((string) ($build['utm_url'] ?? $build['destination_url'] ?? ''));
			if ($destination_url === '' || !wp_http_validate_url($destination_url)) {
				self::append_dry_run_message($blockers, __('Destination URL is missing or invalid.', 'vms-meta-ads'));
			}

			$goal = sanitize_key((string) ($build['goal'] ?? 'traffic'));
			$objective = sanitize_text_field((string) ($build['objective_meta'] ?? 'OUTCOME_TRAFFIC'));
			if ($goal === 'sales') {
				$objective = 'OUTCOME_SALES';
			}

			$placement_resolution = self::resolve_effective_placements_for_create($placements_payload, (string) ($settings['meta_ig_actor_id'] ?? ''));
			$effective_placements_payload = $placements_payload;
			if (is_wp_error($placement_resolution)) {
				self::append_dry_run_message($blockers, $placement_resolution->get_error_message());
			} else {
				$effective_placements_payload = (array) ($placement_resolution['placements_payload'] ?? $placements_payload);
				self::merge_dry_run_messages($warnings, (array) ($placement_resolution['warnings'] ?? array()));
			}

			$targeting_preview = self::build_local_targeting_preview($settings, $targeting_payload, $effective_placements_payload, $event_plan_id);
			self::merge_dry_run_messages($blockers, (array) ($targeting_preview['blockers'] ?? array()));
			self::merge_dry_run_messages($warnings, (array) ($targeting_preview['warnings'] ?? array()));

			$promoted_object = self::build_promoted_object_for_goal($goal, $objective, $settings);
			if (is_wp_error($promoted_object)) {
				self::append_dry_run_message($blockers, $promoted_object->get_error_message());
				$promoted_object = array();
			}

			$ad_variants = self::resolve_copy_ad_variants($copy, $event_plan_id);
			foreach ($ad_variants as $variant_for_warning) {
				if ((string) ($variant_for_warning['media_mode'] ?? 'shared') === 'video_placeholder') {
					self::append_dry_run_message($warnings, __('One or more variants are still using a Meta-direct video placeholder. The ad will need the final video swapped in Ads Manager before publish.', 'vms-meta-ads'));
					break;
				}
			}

			$shared_images = self::resolve_creative_image_assets($build);
			if (empty($shared_images['square']) && empty($shared_images['wide']) && empty($shared_images['vertical'])) {
				self::append_dry_run_message($blockers, __('No shared creative images could be resolved from the draft or featured image fallback.', 'vms-meta-ads'));
			}

			$first_variant = is_array($ad_variants[0] ?? null) ? (array) $ad_variants[0] : array();
			$headline = sanitize_text_field((string) (($first_variant['headline'] ?? ($copy['headline_variants'][0] ?? '')) ?: ''));
			$description = sanitize_text_field((string) (($first_variant['description'] ?? ($copy['description_variants'][0] ?? '')) ?: ''));
			if ($headline === '') {
				$headline = __('Get Tickets', 'vms-meta-ads');
			}
			if ($description === '') {
				$description = __('Tickets available now.', 'vms-meta-ads');
			}

			$base_preflight = array(
				'settings' => $settings,
				'goal' => $goal,
				'objective' => $objective,
				'optimization_goal' => self::map_optimization_goal(self::resolve_build_optimization($build)),
				'promoted_object' => is_array($promoted_object) ? $promoted_object : array(),
				'lifetime_budget_minor' => $lifetime_budget_minor,
				'start_time_iso8601' => $start_iso,
				'end_time_iso8601' => $end_iso,
				'site_timezone' => VMS_Meta_Ads_Utils::get_site_timezone_name(),
				'meta_account_timezone' => VMS_Meta_Ads_Utils::get_meta_account_timezone($settings)->getName(),
				'allow_multi_advertiser_ads' => !empty($copy['multi_advertiser_ads']) ? 1 : 0,
				'targeting' => (array) ($targeting_preview['targeting'] ?? array()),
				'targeting_input' => $targeting_payload,
				'targeting_location_rows' => (array) ($targeting_preview['location_rows'] ?? array()),
				'targeting_unresolved_locations' => (array) ($targeting_preview['unresolved_locations'] ?? array()),
				'destination_url' => $destination_url,
				'page_id' => trim((string) ($settings['meta_page_id'] ?? '')),
				'ig_actor_id' => trim((string) ($settings['meta_ig_actor_id'] ?? '')),
				'campaign_name' => sanitize_text_field((string) (($copy['campaign_name'] ?? '') ?: ('Event Plan ' . $event_plan_id . ' — ' . $tier_label))),
				'adset_name' => $tier_label . ' — ' . self::summarize_targeting($targeting_payload),
				'creative_name' => sanitize_text_field((string) (($first_variant['creative_name'] ?? '') ?: 'Variant 1 Creative')),
				'ad_name' => sanitize_text_field((string) (($first_variant['ad_name'] ?? '') ?: 'Variant 1')),
				'primary_text' => sanitize_textarea_field((string) (($first_variant['primary_text'] ?? ($copy['primary_text_variants'][0] ?? '')) ?: '')),
				'headline' => $headline,
				'description' => $description,
				'cta_type' => self::map_meta_link_cta((string) ($copy['cta_suggestion'] ?? 'LEARN_MORE'), $destination_url),
				'creative_images' => $shared_images,
				'requested_placements_payload' => $placements_payload,
				'effective_placements_payload' => $effective_placements_payload,
				'ad_variants' => $ad_variants,
			);

			$recipe_payload = is_array($copy['campaign_recipe_payload'] ?? null) ? (array) $copy['campaign_recipe_payload'] : array();
			$recipe_key = sanitize_key((string) ($recipe_payload['recipe_key'] ?? ''));
			$adset_preflights = array();
			if (in_array($recipe_key, array('clean_room_full_push', 'clean_room_full_push_v2'), true)) {
				$adset_preflights = self::build_dry_run_recipe_adset_preflights($base_preflight, $recipe_payload, $settings, $build_id, $event_plan_id, $blockers, $warnings);
			} else {
				$adset_preflights[] = array_merge($base_preflight, array(
					'key' => $tier_key,
					'label' => $tier_label,
					'variants' => self::build_variant_definitions_from_preflight($base_preflight),
					'blockers' => array(),
					'warnings' => array(),
				));
			}

			$adset_previews = array();
			foreach ($adset_preflights as $adset_preflight) {
				$adset_preview = self::build_dry_run_adset_preview($settings, $adset_preflight, $shared_images);
				$adset_previews[] = $adset_preview;
				self::merge_dry_run_messages($blockers, (array) ($adset_preview['blockers'] ?? array()));
				self::merge_dry_run_messages($warnings, (array) ($adset_preview['warnings'] ?? array()));
			}

			$request_plan = array(
				'campaign' => self::build_dry_run_campaign_request_preview($settings, (string) ($base_preflight['campaign_name'] ?? ''), (string) ($base_preflight['objective'] ?? 'OUTCOME_TRAFFIC')),
				'shared_image_uploads' => self::build_dry_run_image_upload_requests($settings, $shared_images, 'shared'),
				'adsets' => $adset_previews,
			);

			$summary = array(
				'campaign_requests' => 1,
				'adset_requests' => count($adset_previews),
				'creative_requests' => 0,
				'ad_requests' => 0,
				'image_upload_requests' => count((array) ($request_plan['shared_image_uploads'] ?? array())),
				'video_upload_requests' => 0,
				'blocker_count' => count($blockers),
				'warning_count' => count($warnings),
			);
			foreach ($adset_previews as $adset_preview) {
				$variants = !empty($adset_preview['variants']) && is_array($adset_preview['variants']) ? (array) $adset_preview['variants'] : array();
				foreach ($variants as $variant_preview) {
					$summary['creative_requests']++;
					$summary['ad_requests']++;
					$summary['image_upload_requests'] += count((array) ($variant_preview['image_uploads'] ?? array()));
					if (!empty($variant_preview['video_upload'])) {
						$summary['video_upload_requests']++;
					}
				}
			}
			$placements_overview = self::collect_dry_run_placements_overview($adset_previews);

			return array(
				'dry_run_mode' => 'no_network',
				'publish_safe' => true,
				'build_id' => $build_id,
				'event_plan_id' => $event_plan_id,
				'create_ready' => empty($blockers),
				'generated_local' => self::current_local_time(),
				'module_version' => defined('VMS_MA_VERSION') ? (string) VMS_MA_VERSION : '',
				'connection_state' => $connection_state,
				'dsa_readiness' => array(
					'beneficiary' => sanitize_text_field((string) ($dsa_readiness['beneficiary'] ?? '')),
					'payor' => sanitize_text_field((string) ($dsa_readiness['payor'] ?? '')),
					'ready' => !empty($dsa_readiness['ready']),
					'warnings' => array_values((array) ($dsa_readiness['warnings'] ?? array())),
					'note' => !empty($dsa_readiness['ready'])
						? __('DSA beneficiary/payor are configured in MAB settings and will be included in future ad-set create payloads. Meta may not echo those optional fields back in read-only ad-set API responses, so verify Advertiser/Payer in Ads Manager before publishing. Existing Meta objects are not updated until an explicit update or recreate step is approved.', 'vms-meta-ads')
						: __('DSA beneficiary/payor are not fully configured in MAB settings yet. Future create payloads will omit missing values until they are filled in.', 'vms-meta-ads'),
				),
				'build_snapshot' => array(
					'status' => sanitize_key((string) ($build['status'] ?? 'draft')),
					'goal' => $goal,
					'objective' => $objective,
					'creative_mode' => $creative_mode,
					'destination_url' => $destination_url,
					'budget_minor' => $lifetime_budget_minor,
					'preset_mode' => $preset,
					'schedule_window_label' => $tier_label,
					'tier_count' => (int) ($schedule_support['tier_count'] ?? 0),
					'strategy_template' => sanitize_key((string) ($copy['strategy_template'] ?? 'custom')),
					'campaign_recipe' => $recipe_key,
				),
				'schedule_support' => array(
					'preset_mode' => $preset,
					'preset_label' => (string) ($schedule_support['preset_label'] ?? self::schedule_preset_label($preset)),
					'tier_count' => (int) ($schedule_support['tier_count'] ?? 0),
					'direct_create_supported' => !empty($schedule_support['supported']),
					'message' => !empty($schedule_support['supported']) ? '' : (string) ($schedule_support['create_message'] ?? ''),
					'window_label' => $tier_label,
					'window_key' => $tier_key,
				),
				'summary' => $summary,
				'blockers' => array_values($blockers),
				'warnings' => array_values($warnings),
				'placements_overview' => $placements_overview,
				'request_plan' => $request_plan,
			);
		}

		private static function preview_connection_settings(): array
		{
			$settings = VMS_Meta_Ads_Utils::get_settings();
			$source = 'mab_settings';
			$use_local_override = !empty($settings['meta_ad_account_override']);
			if (!$use_local_override) {
				$social = apply_filters('vms_social_meta_connection', null);
				if (is_array($social) && !empty($social['ad_account_id'])) {
					$settings = array_merge($settings, array(
						'meta_ad_account_id' => (string) ($social['ad_account_id'] ?? ''),
						'meta_page_id' => (string) ($social['page_id'] ?? ''),
						'meta_ig_actor_id' => (string) ($social['ig_actor_id'] ?? ''),
						'meta_graph_version' => (string) ($social['graph_version'] ?? $settings['meta_graph_version']),
						'meta_access_token_encrypted' => (string) ($social['access_token_encrypted'] ?? ''),
					));
					$source = 'social_connection';
				}
			}
			$settings['meta_ad_account_id'] = ltrim(trim((string) ($settings['meta_ad_account_id'] ?? '')), 'act_');
			$settings['_connection_source'] = $source;
			return $settings;
		}

		private static function build_dry_run_connection_state(array $settings): array
		{
			$token = VMS_Meta_Ads_Utils::decrypt_token((string) ($settings['meta_access_token_encrypted'] ?? ''));
			$token_present = trim($token) !== '';
			return array(
				'api_enabled' => !empty($settings['enable_api_create']),
				'phase' => max(1, (int) ($settings['vms_ma_phase'] ?? 1)),
				'meta_graph_version' => (string) ($settings['meta_graph_version'] ?? 'v24.0'),
				'meta_ad_account_id' => trim((string) ($settings['meta_ad_account_id'] ?? '')),
				'meta_ad_account_id_present' => trim((string) ($settings['meta_ad_account_id'] ?? '')) !== '',
				'meta_page_id' => trim((string) ($settings['meta_page_id'] ?? '')),
				'meta_page_id_present' => trim((string) ($settings['meta_page_id'] ?? '')) !== '',
				'meta_ig_actor_id' => trim((string) ($settings['meta_ig_actor_id'] ?? '')),
				'meta_ig_actor_id_present' => trim((string) ($settings['meta_ig_actor_id'] ?? '')) !== '',
				'meta_pixel_id' => trim((string) ($settings['meta_pixel_id'] ?? '')),
				'meta_pixel_id_present' => trim((string) ($settings['meta_pixel_id'] ?? '')) !== '',
				'token_state' => $token_present ? 'present' : 'missing',
				'connection_fresh' => self::dry_run_connection_fresh($settings),
				'meta_last_test_ok_gmt' => (string) ($settings['meta_last_test_ok_gmt'] ?? ''),
				'meta_app_mode' => sanitize_key((string) ($settings['meta_app_mode'] ?? '')),
				'connection_source' => sanitize_key((string) ($settings['_connection_source'] ?? 'mab_settings')),
			);
		}

		private static function dry_run_connection_fresh(array $settings): bool
		{
			$raw = trim((string) ($settings['meta_last_test_ok_gmt'] ?? ''));
			if ($raw === '') {
				return false;
			}
			$ts = strtotime($raw . ' UTC');
			if ($ts === false) {
				return false;
			}
			return (time() - $ts) <= DAY_IN_SECONDS;
		}

		private static function infer_schedule_preset_mode(array $build): string
		{
			$schedule = is_array($build['schedule_payload'] ?? null) ? (array) $build['schedule_payload'] : array();
			$saved_preset = sanitize_key((string) ($schedule['preset_mode'] ?? ''));
			if ($saved_preset !== '') {
				return $saved_preset;
			}

			$tiers = !empty($build['tiers']) && is_array($build['tiers']) ? array_values(array_filter((array) $build['tiers'], 'is_array')) : array();
			if (empty($tiers)) {
				return 'flat_run';
			}

			$key = sanitize_key((string) (($tiers[0]['tier_key'] ?? '')));
			switch ($key) {
				case 'manual':
					return 'manual_dates';
				case 'flat_run':
					return 'flat_run';
				case 'simple_7':
					return 'simple_7_day';
				case 'simple_14':
					return 'simple_14_day';
				case 'simple_30':
					return 'simple_30_day';
				case 'd30':
				case 'd14':
				case 'd7':
					return 'promo_bundle_30_14_7';
				case 'v30':
				case 'v14':
				case 'v7':
				case 'v48':
					return 'video_tribute_push';
				case 'promo':
					return 'flat_run';
				default:
					return 'flat_run';
			}
		}

		private static function schedule_preset_label(string $preset): string
		{
			switch (sanitize_key($preset)) {
				case 'video_tribute_push':
					return __('Video-Led Ticket Push', 'vms-meta-ads');
				case 'promo_bundle_30_14_7':
					return __('Promo Bundle 30/14/7', 'vms-meta-ads');
				case 'simple_7_day':
					return __('Simple 7 day', 'vms-meta-ads');
				case 'simple_14_day':
					return __('Simple 14 day', 'vms-meta-ads');
				case 'simple_30_day':
					return __('Simple 30 day', 'vms-meta-ads');
				case 'manual_dates':
					return __('Manual dates', 'vms-meta-ads');
				case 'flat_run':
				default:
					return __('Flat run', 'vms-meta-ads');
			}
		}

		private static function resolve_schedule_create_support(array $build): array
		{
			$preset = self::infer_schedule_preset_mode($build);
			$preset_label = self::schedule_preset_label($preset);
			$tiers = !empty($build['tiers']) && is_array($build['tiers']) ? array_values(array_filter((array) $build['tiers'], 'is_array')) : array();
			$tier_count = count($tiers);
			$first_tier = is_array($tiers[0] ?? null) ? (array) $tiers[0] : array();
			$tier_key = sanitize_key((string) ($first_tier['tier_key'] ?? $preset)) ?: 'flat_run';
			$tier_label = sanitize_text_field((string) ($first_tier['tier_label'] ?? $preset_label)) ?: $preset_label;

			if ($tier_count <= 1) {
				return array(
					'preset' => $preset,
					'preset_label' => $preset_label,
					'tier_count' => $tier_count,
					'tier_key' => $tier_key,
					'tier_label' => $tier_label,
					'supported' => true,
					'dry_run_message' => '',
					'create_message' => '',
				);
			}

			return array(
				'preset' => $preset,
				'preset_label' => $preset_label,
				'tier_count' => $tier_count,
				'tier_key' => $tier_key,
				'tier_label' => $tier_label,
				'supported' => false,
				'dry_run_message' => sprintf(
					/* translators: 1: schedule preset label, 2: number of windows */
					__('The saved draft uses the %1$s schedule and currently expands into %2$d windows. Dry run can still preview the first remaining window only, but direct Meta create/update currently supports a single schedule window. Switch Step B to Flat run, Simple 7 day, Simple 14 day, Simple 30 day, or Manual dates, or shorten the calendar until one window remains, then save draft.', 'vms-meta-ads'),
					$preset_label,
					$tier_count
				),
				'create_message' => sprintf(
					/* translators: 1: schedule preset label, 2: number of windows */
					__('The saved draft uses the %1$s schedule and currently expands into %2$d windows. Direct Meta create/update currently supports a single schedule window only. Switch Step B to Flat run, Simple 7 day, Simple 14 day, Simple 30 day, or Manual dates, or shorten the calendar until one window remains, then save draft.', 'vms-meta-ads'),
					$preset_label,
					$tier_count
				),
			);
		}

		private static function build_dry_run_recipe_adset_preflights(array $base_preflight, array $recipe_payload, array $settings, int $build_id, int $event_plan_id, array &$blockers, array &$warnings): array
		{
			$adsets = !empty($recipe_payload['adsets']) && is_array($recipe_payload['adsets']) ? array_values((array) $recipe_payload['adsets']) : array();
			if (empty($adsets)) {
				self::append_dry_run_message($blockers, __('Clean-room recipe is missing saved ad-set definitions.', 'vms-meta-ads'));
				return array();
			}

			$out = array();
			$all_variants = !empty($base_preflight['ad_variants']) && is_array($base_preflight['ad_variants']) ? array_values((array) $base_preflight['ad_variants']) : self::build_variant_definitions_from_preflight($base_preflight);
			foreach ($adsets as $index => $adset) {
				if (!is_array($adset)) {
					continue;
				}
				$key = sanitize_key((string) ($adset['key'] ?? ('adset_' . ($index + 1)))) ?: ('adset_' . ($index + 1));
				$label = sanitize_text_field((string) ($adset['label'] ?? ('Ad Set ' . ($index + 1))));
				$local_blockers = array();
				$local_warnings = array();
				$adset_budget = max(0, absint($adset['budget_amount_minor'] ?? 0));
				$budget_floor = self::validate_minimum_meta_budget_per_day(array(
					'budget_amount_minor' => $adset_budget,
					'start_time' => (string) ($base_preflight['start_time_iso8601'] ?? ''),
					'end_time' => (string) ($base_preflight['end_time_iso8601'] ?? ''),
				));
				if (is_wp_error($budget_floor)) {
					self::append_dry_run_message($local_blockers, sprintf(__('Recipe ad set "%s" is below Meta minimum budget guidance.', 'vms-meta-ads'), $label));
				}

				$audience = is_array($adset['audience'] ?? null) ? (array) $adset['audience'] : array();
				$targeting_payload = array(
					'targeting_address' => sanitize_text_field((string) ($audience['targeting_address'] ?? '')),
					'locations' => sanitize_textarea_field((string) ($audience['locations'] ?? '')),
					'radius_miles' => max(1, absint($audience['radius_miles'] ?? 25)),
					'age_min' => max(13, absint($audience['age_min'] ?? 21)),
					'age_max' => max(13, absint($audience['age_max'] ?? 65)),
					'interests' => array(),
					'require_explicit_locations' => !empty($audience['require_explicit_locations']) ? 1 : 0,
				);
				$placements = !empty($adset['placements']) && is_array($adset['placements']) ? array_values(array_filter(array_map('sanitize_key', (array) $adset['placements']))) : array();
				$placements_payload = array('mode' => 'manual', 'placements' => $placements);
				$placement_resolution = self::resolve_effective_placements_for_create($placements_payload, (string) ($base_preflight['ig_actor_id'] ?? ''));
				if (is_wp_error($placement_resolution)) {
					self::append_dry_run_message($local_blockers, $placement_resolution->get_error_message());
				} else {
					$placements_payload = (array) ($placement_resolution['placements_payload'] ?? $placements_payload);
					self::merge_dry_run_messages($local_warnings, (array) ($placement_resolution['warnings'] ?? array()));
				}

				$targeting_preview = self::build_local_targeting_preview($settings, $targeting_payload, $placements_payload, $event_plan_id);
				self::merge_dry_run_messages($local_blockers, (array) ($targeting_preview['blockers'] ?? array()));
				self::merge_dry_run_messages($local_warnings, (array) ($targeting_preview['warnings'] ?? array()));

				$variant_mode = sanitize_key((string) ($adset['variant_mode'] ?? 'standard'));
				$variants = self::select_recipe_variants($all_variants, $variant_mode, $label, $key);
				if (in_array($key, array('fb_right_column', 'fb_right_column_support'), true) && empty($base_preflight['creative_images']['square'])) {
					self::append_dry_run_message($local_blockers, sprintf(__('Recipe ad set "%s" needs a square static image for Right Column support.', 'vms-meta-ads'), $label));
				}
				if (!empty($recipe_payload['require_vertical_video']) && in_array($key, array('vertical_video_reels_stories', 'promo_video_reels'), true)) {
					$has_video_variant = false;
					foreach ($variants as $variant) {
						$media_mode = sanitize_key((string) ($variant['media_mode'] ?? 'shared'));
						if (in_array($media_mode, array('video', 'video_placeholder'), true)) {
							$has_video_variant = true;
							break;
						}
					}
					if (!$has_video_variant) {
						self::append_dry_run_message($local_blockers, __('Vertical Reels/Stories ad set is configured to require a vertical video, but no video variant is present.', 'vms-meta-ads'));
					}
				}

				$out[] = array_merge($base_preflight, array(
					'key' => $key,
					'label' => $label,
					'adset_name' => sanitize_text_field((string) ($adset['name'] ?? $label)),
					'lifetime_budget_minor' => $adset_budget,
					'targeting' => (array) ($targeting_preview['targeting'] ?? array()),
					'targeting_input' => $targeting_payload,
					'targeting_location_rows' => (array) ($targeting_preview['location_rows'] ?? array()),
					'targeting_unresolved_locations' => (array) ($targeting_preview['unresolved_locations'] ?? array()),
					'requested_placements_payload' => array('mode' => 'manual', 'placements' => $placements),
					'effective_placements_payload' => $placements_payload,
					'variants' => $variants,
					'blockers' => $local_blockers,
					'warnings' => $local_warnings,
				));
				self::merge_dry_run_messages($blockers, $local_blockers);
				self::merge_dry_run_messages($warnings, $local_warnings);
			}

			return $out;
		}

		private static function build_dry_run_adset_preview(array $settings, array $adset_preflight, array $shared_images): array
		{
			$key = sanitize_key((string) ($adset_preflight['key'] ?? 'flat_run')) ?: 'flat_run';
			$label = sanitize_text_field((string) ($adset_preflight['label'] ?? __('Ad Set', 'vms-meta-ads')));
			$variants = !empty($adset_preflight['variants']) && is_array($adset_preflight['variants']) ? array_values((array) $adset_preflight['variants']) : self::build_variant_definitions_from_preflight($adset_preflight);
			$variant_previews = array();
			$blockers = !empty($adset_preflight['blockers']) && is_array($adset_preflight['blockers']) ? array_values((array) $adset_preflight['blockers']) : array();
			$warnings = !empty($adset_preflight['warnings']) && is_array($adset_preflight['warnings']) ? array_values((array) $adset_preflight['warnings']) : array();
			$placements_preview = self::build_dry_run_placements_preview(
				(array) ($adset_preflight['requested_placements_payload'] ?? array()),
				(array) ($adset_preflight['effective_placements_payload'] ?? array()),
				!empty($adset_preflight['ig_actor_id'])
			);

			foreach ($variants as $variant) {
				$variant_preview = self::build_dry_run_variant_preview($settings, $adset_preflight, $variant, $shared_images, $key);
				$variant_previews[] = $variant_preview;
				self::merge_dry_run_messages($blockers, (array) ($variant_preview['blockers'] ?? array()));
				self::merge_dry_run_messages($warnings, (array) ($variant_preview['warnings'] ?? array()));
			}

			return array(
				'key' => $key,
				'label' => $label,
				'targeting_input' => (array) ($adset_preflight['targeting_input'] ?? array()),
				'targeting_payload' => (array) ($adset_preflight['targeting'] ?? array()),
				'targeting_location_rows' => (array) ($adset_preflight['targeting_location_rows'] ?? array()),
				'targeting_unresolved_locations' => (array) ($adset_preflight['targeting_unresolved_locations'] ?? array()),
				'placements_payload' => (array) ($adset_preflight['effective_placements_payload'] ?? array()),
				'placements_preview' => $placements_preview,
				'adset_request' => self::build_dry_run_adset_request_preview($settings, $adset_preflight, '{{campaign_id}}'),
				'variants' => $variant_previews,
				'blockers' => $blockers,
				'warnings' => $warnings,
			);
		}

		private static function collect_dry_run_placements_overview(array $adset_previews): array
		{
			$out = array();
			foreach ($adset_previews as $adset_preview) {
				if (!is_array($adset_preview)) {
					continue;
				}
				$placements_preview = is_array($adset_preview['placements_preview'] ?? null) ? (array) $adset_preview['placements_preview'] : array();
				$out[] = array(
					'key' => sanitize_key((string) ($adset_preview['key'] ?? '')),
					'label' => sanitize_text_field((string) ($adset_preview['label'] ?? __('Ad Set', 'vms-meta-ads'))),
					'requested_mode' => sanitize_key((string) ($placements_preview['requested_mode'] ?? 'automatic')),
					'requested_mode_label' => sanitize_text_field((string) ($placements_preview['requested_mode_label'] ?? self::placement_mode_label('automatic'))),
					'requested_placement_labels' => array_values((array) ($placements_preview['requested_placement_labels'] ?? array())),
					'effective_mode' => sanitize_key((string) ($placements_preview['effective_mode'] ?? 'automatic')),
					'effective_mode_label' => sanitize_text_field((string) ($placements_preview['effective_mode_label'] ?? self::placement_mode_label('automatic'))),
					'placement_labels' => array_values((array) ($placements_preview['placement_labels'] ?? array())),
					'platform_labels' => (array) ($placements_preview['platform_labels'] ?? array()),
					'summary' => sanitize_text_field((string) ($placements_preview['summary'] ?? '')),
					'requested_summary' => sanitize_text_field((string) ($placements_preview['requested_summary'] ?? '')),
					'requested_differs' => !empty($placements_preview['requested_differs']),
					'count' => max(0, (int) ($placements_preview['count'] ?? 0)),
				);
			}
			return $out;
		}

		private static function build_dry_run_placements_preview(array $requested_payload, array $effective_payload, bool $has_ig_actor): array
		{
			$requested_mode = sanitize_key((string) ($requested_payload['mode'] ?? 'automatic')) ?: 'automatic';
			$effective_mode = sanitize_key((string) ($effective_payload['mode'] ?? $requested_mode)) ?: $requested_mode;
			$requested_matrix = self::resolve_asset_feed_placement_matrix($requested_payload, $has_ig_actor);
			$effective_matrix = self::resolve_asset_feed_placement_matrix($effective_payload, $has_ig_actor);
			$requested_keys = self::placement_keys_from_matrix($requested_matrix);
			$effective_keys = self::placement_keys_from_matrix($effective_matrix);
			$requested_labels = self::placement_labels_from_keys($requested_keys);
			$effective_labels = self::placement_labels_from_keys($effective_keys);

			return array(
				'requested_mode' => $requested_mode,
				'requested_mode_label' => self::placement_mode_label($requested_mode),
				'requested_placement_keys' => $requested_keys,
				'requested_placement_labels' => $requested_labels,
				'effective_mode' => $effective_mode,
				'effective_mode_label' => self::placement_mode_label($effective_mode),
				'placement_keys' => $effective_keys,
				'placement_labels' => $effective_labels,
				'platform_labels' => self::group_placement_labels($effective_keys),
				'summary' => self::format_placement_label_list($effective_labels),
				'requested_summary' => self::format_placement_label_list($requested_labels),
				'requested_differs' => $requested_mode !== $effective_mode || $requested_keys !== $effective_keys,
				'count' => count($effective_keys),
			);
		}

		private static function placement_mode_label(string $mode): string
		{
			return sanitize_key($mode) === 'manual'
				? __('Manual placements', 'vms-meta-ads')
				: __('Advantage+ placements (automatic)', 'vms-meta-ads');
		}

		private static function placement_keys_from_matrix(array $matrix): array
		{
			$order = array('fb_feed', 'fb_profile_feed', 'fb_right_column', 'fb_search', 'fb_story', 'fb_reels', 'ig_feed', 'ig_search', 'ig_explore', 'ig_story', 'ig_reels');
			$out = array();
			foreach ($order as $key) {
				if (!empty($matrix[$key])) {
					$out[] = $key;
				}
			}
			return $out;
		}

		private static function placement_labels_from_keys(array $keys): array
		{
			$labels = array();
			foreach ($keys as $key) {
				$labels[] = self::placement_key_label((string) $key);
			}
			return array_values(array_filter($labels, static function ($label) {
				return is_string($label) && trim($label) !== '';
			}));
		}

		private static function placement_key_label(string $key): string
		{
			switch (sanitize_key($key)) {
				case 'fb_feed':
					return __('Facebook Feed', 'vms-meta-ads');
				case 'fb_profile_feed':
					return __('Facebook Profile Feed', 'vms-meta-ads');
				case 'fb_right_column':
					return __('Facebook Right Column', 'vms-meta-ads');
				case 'fb_search':
					return __('Facebook Search Results', 'vms-meta-ads');
				case 'fb_story':
					return __('Facebook Stories', 'vms-meta-ads');
				case 'fb_reels':
					return __('Facebook Reels', 'vms-meta-ads');
				case 'ig_feed':
					return __('Instagram Feed', 'vms-meta-ads');
				case 'ig_search':
					return __('Instagram Search Results', 'vms-meta-ads');
				case 'ig_explore':
					return __('Instagram Explore Home', 'vms-meta-ads');
				case 'ig_story':
					return __('Instagram Stories', 'vms-meta-ads');
				case 'ig_reels':
					return __('Instagram Reels', 'vms-meta-ads');
				default:
					return sanitize_text_field($key);
			}
		}

		private static function group_placement_labels(array $keys): array
		{
			$groups = array(
				'facebook' => array(),
				'instagram' => array(),
			);
			foreach ($keys as $key) {
				$key = sanitize_key((string) $key);
				$label = self::placement_key_label($key);
				if (strpos($key, 'ig_') === 0) {
					$groups['instagram'][] = $label;
				} else {
					$groups['facebook'][] = $label;
				}
			}
			$groups['facebook'] = array_values(array_unique(array_filter($groups['facebook'])));
			$groups['instagram'] = array_values(array_unique(array_filter($groups['instagram'])));
			if (empty($groups['facebook'])) {
				unset($groups['facebook']);
			}
			if (empty($groups['instagram'])) {
				unset($groups['instagram']);
			}
			return $groups;
		}

		private static function format_placement_label_list(array $labels): string
		{
			$labels = array_values(array_filter(array_map('sanitize_text_field', $labels)));
			return empty($labels) ? '' : implode(', ', $labels);
		}

			private static function build_dry_run_variant_preview(array $settings, array $preflight, array $variant, array $shared_images, string $adset_key): array
			{
			$variant_key = sanitize_key((string) ($variant['variant_key'] ?? 'v1')) ?: 'v1';
			$scope = $adset_key . ':' . $variant_key;
			$media_mode = sanitize_key((string) ($variant['media_mode'] ?? 'shared'));
			$blockers = array();
			$warnings = array();
			$image_uploads = array();
			$video_upload = array();
			$creative_request = array();

			if ($media_mode === 'video') {
				$video_asset = self::attachment_video_asset_payload(absint($variant['media_video_id'] ?? 0));
				if (empty($video_asset)) {
					self::append_dry_run_message($blockers, sprintf(__('Variant "%s" is set to video, but the selected WordPress video asset could not be resolved.', 'vms-meta-ads'), (string) ($variant['label'] ?? $variant_key)));
					} else {
						$video_upload = self::build_dry_run_video_upload_request($settings, $video_asset, $scope);
						$video_payload = self::build_dry_run_video_creative_payload($preflight, $variant, '{{uploaded_video_id:' . $scope . '}}', $shared_images);
						$creative_request = self::build_dry_run_creative_request_preview($settings, $preflight, array(
							'primary_payload' => self::apply_creative_feature_opt_outs($settings, $video_payload, $preflight, true),
							'fallback_payloads' => array(
								array(
									'label' => __('Final clean fallback payload', 'vms-meta-ads'),
									'payload' => $video_payload,
								),
							),
						));
				}
			} else {
				$images = $shared_images;
				if ($media_mode === 'image') {
					$images = self::resolve_variant_image_assets($variant, $shared_images);
					$image_uploads = self::build_dry_run_image_upload_requests($settings, $images, $scope);
					$images = self::with_dry_run_image_hash_placeholders($images, $scope);
				} else {
					$images = self::with_dry_run_image_hash_placeholders($shared_images, 'shared');
				}

				$blueprint = self::build_creative_request_blueprint($preflight, $variant, $images);
				$single_image = is_array($blueprint['single_image'] ?? null) ? (array) $blueprint['single_image'] : array();
				$story_spec_raw = (string) ($single_image['object_story_spec'] ?? '');
				$has_image_ref = strpos($story_spec_raw, 'image_hash') !== false || strpos($story_spec_raw, 'picture') !== false;
				if (!$has_image_ref) {
					self::append_dry_run_message($blockers, sprintf(__('Variant "%s" has no resolvable image asset for creative build.', 'vms-meta-ads'), (string) ($variant['label'] ?? $variant_key)));
				}
				if ($media_mode === 'video_placeholder') {
					self::append_dry_run_message($warnings, sprintf(__('Variant "%s" is still using a video placeholder and will need the actual video swapped in Ads Manager.', 'vms-meta-ads'), (string) ($variant['label'] ?? $variant_key)));
					}
					$creative_request = self::build_dry_run_creative_request_preview($settings, $preflight, array(
						'primary_payload' => self::apply_creative_feature_opt_outs($settings, (array) ($blueprint['asset_feed_with_rules'] ?? array()), $preflight, true),
						'fallback_payloads' => array_values(array_filter(array(
							array(
								'label' => __('Retry base creative payload without optional feature overrides', 'vms-meta-ads'),
								'payload' => (array) ($blueprint['asset_feed_with_rules'] ?? array()),
							),
							!empty($blueprint['asset_feed_without_rules']) ? array(
								'label' => __('Retry without asset customization rules (clean payload)', 'vms-meta-ads'),
								'payload' => (array) $blueprint['asset_feed_without_rules'],
							) : array(),
							!empty($blueprint['single_image']) ? array(
								'label' => __('Fallback to single-image creative (final clean payload)', 'vms-meta-ads'),
								'payload' => (array) $blueprint['single_image'],
							) : array(),
						))),
					));
			}

			return array(
				'variant_key' => $variant_key,
				'label' => sanitize_text_field((string) ($variant['label'] ?? strtoupper($variant_key))),
				'media_mode' => $media_mode !== '' ? $media_mode : 'shared',
				'image_uploads' => $image_uploads,
				'video_upload' => $video_upload,
				'creative_request' => $creative_request,
				'ad_request' => self::build_dry_run_ad_request_preview(
					$settings,
					sanitize_text_field((string) ($variant['ad_name'] ?? ('Ad ' . strtoupper($variant_key)))),
					'{{adset_id:' . $adset_key . '}}',
					'{{creative_id:' . $scope . '}}'
				),
				'blockers' => $blockers,
				'warnings' => $warnings,
			);
		}

		private static function build_dry_run_campaign_request_preview(array $settings, string $campaign_name, string $objective): array
		{
			$candidates = self::campaign_payload_candidates($campaign_name, $objective);
			$validation = self::validate_paused_campaign_payload_candidates($candidates);
			return array(
				'operation' => 'create_campaign',
				'method' => 'POST',
				'endpoint' => self::preview_ad_account_endpoint($settings) . '/campaigns',
				'primary_payload' => (array) ($candidates[0] ?? array()),
				'fallback_payloads' => array_values(array_slice($candidates, 1)),
				'paused_status_verified' => !is_wp_error($validation),
				'paused_status_message' => is_wp_error($validation) ? $validation->get_error_message() : '',
			);
		}

		private static function build_dry_run_adset_request_preview(array $settings, array $preflight, string $campaign_id_ref): array
		{
			return array(
				'operation' => 'create_adset',
				'method' => 'POST',
				'endpoint' => self::preview_ad_account_endpoint($settings) . '/adsets',
				'payload' => array(
					'name' => (string) ($preflight['adset_name'] ?? 'Flat Run'),
					'campaign_id' => $campaign_id_ref,
					'billing_event' => 'IMPRESSIONS',
					'optimization_goal' => (string) ($preflight['optimization_goal'] ?? 'LINK_CLICKS'),
					'bid_strategy' => 'LOWEST_COST_WITHOUT_CAP',
					'status' => self::STATUS_PAUSED,
					'lifetime_budget' => (string) ((int) ($preflight['lifetime_budget_minor'] ?? 0)),
					'start_time' => (string) ($preflight['start_time_iso8601'] ?? ''),
					'end_time' => (string) ($preflight['end_time_iso8601'] ?? ''),
					'targeting' => wp_json_encode((array) ($preflight['targeting'] ?? array())),
				) + self::adset_promoted_object_payload((array) ($preflight['promoted_object'] ?? array())) + self::adset_dsa_payload($settings),
			);
		}

		private static function build_dry_run_ad_request_preview(array $settings, string $ad_name, string $adset_id_ref, string $creative_id_ref): array
		{
			return array(
				'operation' => 'create_ad',
				'method' => 'POST',
				'endpoint' => self::preview_ad_account_endpoint($settings) . '/ads',
				'payload' => array(
					'name' => $ad_name,
					'adset_id' => $adset_id_ref,
					'status' => self::STATUS_PAUSED,
					'creative' => wp_json_encode(array('creative_id' => $creative_id_ref)),
				),
			);
		}

			private static function build_dry_run_creative_request_preview(array $settings, array $preflight, array $payloads): array
			{
				$primary_payload = is_array($payloads['primary_payload'] ?? null) ? (array) $payloads['primary_payload'] : array();
				if (empty($primary_payload)) {
					$primary_payload = array();
				}
				$fallback_payloads = !empty($payloads['fallback_payloads']) && is_array($payloads['fallback_payloads']) ? array_values((array) $payloads['fallback_payloads']) : array();
				$normalized_fallbacks = array();
				$seen_signatures = array();
				$primary_signature = md5(wp_json_encode($primary_payload));
				$seen_signatures[$primary_signature] = true;
				foreach ($fallback_payloads as $fallback) {
					$payload = is_array($fallback['payload'] ?? null) ? (array) $fallback['payload'] : array();
					$signature = md5(wp_json_encode($payload));
					if (isset($seen_signatures[$signature])) {
						continue;
					}
					$seen_signatures[$signature] = true;
					$normalized_fallbacks[] = array(
						'label' => sanitize_text_field((string) ($fallback['label'] ?? __('Fallback creative payload', 'vms-meta-ads'))),
						'payload' => $payload,
					);
				}
				return array(
					'operation' => 'create_creative',
					'method' => 'POST',
					'endpoint' => self::preview_ad_account_endpoint($settings) . '/adcreatives',
					'primary_payload' => $primary_payload,
					'fallback_payloads' => $normalized_fallbacks,
				);
			}

		private static function build_dry_run_video_creative_payload(array $preflight, array $variant, string $video_id_ref, array $images): array
		{
			$thumb_url = '';
			foreach (array('square', 'wide', 'vertical') as $kind) {
				$asset = is_array($images[$kind] ?? null) ? (array) $images[$kind] : array();
				$maybe_url = trim((string) ($asset['url'] ?? ''));
				if ($maybe_url !== '') {
					$thumb_url = $maybe_url;
					break;
				}
			}
			$video_data = array(
				'video_id' => $video_id_ref,
				'message' => (string) ($variant['primary_text'] ?? ''),
				'title' => (string) ($variant['headline'] ?? ''),
				'link_description' => (string) ($variant['description'] ?? ''),
				'call_to_action' => array(
					'type' => (string) ($preflight['cta_type'] ?? 'LEARN_MORE'),
					'value' => array('link' => (string) ($preflight['destination_url'] ?? '')),
				),
			);
			if ($thumb_url !== '') {
				$video_data['image_url'] = $thumb_url;
			}
			$story_spec = array(
				'page_id' => (string) ($preflight['page_id'] ?? ''),
				'video_data' => $video_data,
			);
			if (!empty($preflight['ig_actor_id'])) {
				$story_spec['instagram_user_id'] = (string) $preflight['ig_actor_id'];
			}
			return array(
				'name' => (string) ($variant['creative_name'] ?? 'Video Creative'),
				'link_url' => (string) ($preflight['destination_url'] ?? ''),
				'object_story_spec' => wp_json_encode($story_spec),
			);
		}

		private static function build_dry_run_image_upload_requests(array $settings, array $creative_images, string $scope): array
		{
			$out = array();
			foreach (array('square', 'vertical', 'wide') as $kind) {
				$asset = is_array($creative_images[$kind] ?? null) ? (array) $creative_images[$kind] : array();
				if (empty($asset)) {
					continue;
				}
				$out[] = array(
					'operation' => 'upload_adimage_' . $kind,
					'scope' => $scope,
					'method' => 'POST',
					'endpoint' => self::preview_ad_account_endpoint($settings) . '/adimages',
					'payload' => self::build_dry_run_image_upload_payload($asset, $kind),
				);
			}
			return $out;
		}

		private static function build_dry_run_image_upload_payload(array $asset, string $kind): array
		{
			$payload = array(
				'name' => sanitize_file_name((string) ($asset['filename'] ?? ($kind . '.jpg'))),
			);
			$url = esc_url_raw((string) ($asset['url'] ?? ''));
			if ($url !== '') {
				$payload['url'] = $url;
				return $payload;
			}

			$file = trim((string) ($asset['file'] ?? ''));
			if ($file !== '') {
				$payload['bytes'] = '<omitted in dry run>';
				$payload['dry_run_source_file'] = $file;
			}

			return $payload;
		}

		private static function build_dry_run_video_upload_request(array $settings, array $asset, string $scope): array
		{
			return array(
				'operation' => 'upload_creative_video',
				'scope' => $scope,
				'method' => 'POST',
				'endpoint' => self::preview_ad_account_endpoint($settings) . '/advideos',
				'payload' => array(
					'name' => sanitize_file_name((string) ($asset['filename'] ?? 'variant-video.mp4')),
					'file_url' => esc_url_raw((string) ($asset['url'] ?? '')),
				),
			);
		}

		private static function with_dry_run_image_hash_placeholders(array $images, string $scope): array
		{
			$out = array(
				'square' => array(),
				'vertical' => array(),
				'wide' => array(),
			);
			foreach (array('square', 'vertical', 'wide') as $kind) {
				$asset = is_array($images[$kind] ?? null) ? (array) $images[$kind] : array();
				if (empty($asset)) {
					continue;
				}
				$asset['hash'] = '{{uploaded_image_hash:' . $scope . ':' . $kind . '}}';
				$out[$kind] = $asset;
			}
			return $out;
		}

		private static function build_local_targeting_preview(array $settings, array $targeting_payload, array $placements_payload, int $event_plan_id = 0): array
		{
			$age_min = max(13, absint($targeting_payload['age_min'] ?? 21));
			$age_max = max($age_min, absint($targeting_payload['age_max'] ?? 65));
			$gender = sanitize_key((string) ($targeting_payload['gender'] ?? 'all'));
			if (!in_array($gender, array('all', 'women', 'men'), true)) {
				$gender = 'all';
			}
			$audience_targeting = array();
			$interest_ids = array();
			$advantage_audience = 0;
			$meta_genders = array();
			if (class_exists('VMS_Meta_Ads_Audience_Targeting_Service')) {
				$audience_targeting = VMS_Meta_Ads_Audience_Targeting_Service::normalize_state(
					is_array($targeting_payload['audience_targeting'] ?? null) ? (array) $targeting_payload['audience_targeting'] : array(),
					array('gender' => $gender)
				);
				$interest_ids = VMS_Meta_Ads_Audience_Targeting_Service::interest_ids_for_meta($audience_targeting);
				$meta_genders = VMS_Meta_Ads_Audience_Targeting_Service::gender_for_meta($audience_targeting);
				$advantage_audience = !empty($audience_targeting['advantage_audience']) ? 1 : 0;
				$gender = (string) ($audience_targeting['gender'] ?? $gender);
			}
			$targeting = array(
				'age_min' => $age_min,
				'age_max' => $age_max,
				'targeting_automation' => array(
					'advantage_audience' => $advantage_audience,
				),
			);
			$warnings = array();
			$blockers = array();
			if (!empty($meta_genders)) {
				$targeting['genders'] = array_values($meta_genders);
			}
			if (class_exists('VMS_Meta_Ads_Audience_Targeting_Service')) {
				$audience_summary = VMS_Meta_Ads_Audience_Targeting_Service::build_summary($audience_targeting, array(
					'targeting_address' => (string) ($targeting_payload['targeting_address'] ?? ''),
					'radius_miles' => (int) ($targeting_payload['radius_miles'] ?? 15),
					'age_min' => $age_min,
					'age_max' => $age_max,
					'gender' => $gender,
					'placements_mode' => (string) ($placements_payload['mode'] ?? 'automatic'),
				));
				self::merge_dry_run_messages($warnings, (array) ($audience_summary['warnings'] ?? array()));
			}
			$geo_preview = self::build_local_geo_locations_preview($settings, $targeting_payload, $event_plan_id);
			self::merge_dry_run_messages($warnings, (array) ($geo_preview['warnings'] ?? array()));
			self::merge_dry_run_messages($blockers, (array) ($geo_preview['blockers'] ?? array()));
			$geo_locations = is_array($geo_preview['geo_locations'] ?? null) ? (array) $geo_preview['geo_locations'] : array();
			if (!empty($geo_locations)) {
				$targeting['geo_locations'] = $geo_locations;
			}

			if (empty($interest_ids) && !empty($targeting_payload['interests']) && is_array($targeting_payload['interests'])) {
				foreach ((array) $targeting_payload['interests'] as $id) {
					$id = trim((string) $id);
					if ($id !== '' && ctype_digit($id)) {
						$interest_ids[] = $id;
					}
				}
			}
			if (!empty($interest_ids)) {
				$targeting['flexible_spec'] = array(
					array(
						'interests' => array_map(static function ($id) {
							return array('id' => (string) $id);
						}, $interest_ids),
					),
				);
			}

			$placements_mode = (string) ($placements_payload['mode'] ?? 'automatic');
			$placements = !empty($placements_payload['placements']) && is_array($placements_payload['placements']) ? $placements_payload['placements'] : array();
			if ($placements_mode === 'manual' && !empty($placements)) {
				$targeting = array_merge($targeting, self::build_manual_placements_targeting($placements));
			}

			return array(
				'targeting' => $targeting,
				'location_rows' => (array) ($geo_preview['location_rows'] ?? array()),
				'unresolved_locations' => (array) ($geo_preview['unresolved_locations'] ?? array()),
				'blockers' => $blockers,
				'warnings' => $warnings,
			);
		}

		private static function build_local_geo_locations_preview(array $settings, array $targeting_payload, int $event_plan_id = 0): array
		{
			$radius_default = max(1, absint($targeting_payload['radius_miles'] ?? 15));
			$event_context = self::resolve_event_plan_location_context($event_plan_id);
			$geo_locations = array(
				'custom_locations' => array(),
				'zips' => array(),
				'cities' => array(),
			);
			$warnings = array();
			$blockers = array();
			$location_rows = array();
			$unresolved_locations = array();
			$primary_anchor = trim((string) ($targeting_payload['targeting_address'] ?? ''));
			$locations_value = $targeting_payload['locations'] ?? '';
			$require_explicit_locations = !empty($targeting_payload['require_explicit_locations']);
			$allow_city_state_locations = !empty($targeting_payload['allow_city_state_locations']) || $require_explicit_locations;

			$append_location = function (string $label, int $radius, bool $prefer_radius) use (&$geo_locations, &$warnings, &$blockers, &$location_rows, &$unresolved_locations, $event_context, $allow_city_state_locations) {
				$radius = max(1, $radius);
				$label = trim($label);
				if ($label === '') {
					return;
				}
				$type = self::classify_targeting_location_label($label);
				$location_rows[] = array(
					'label' => $label,
					'radius_miles' => $radius,
					'type' => $type,
				);
				$normalized_key = strtolower(preg_replace('/[^a-z0-9]+/i', '', $label)) . ':' . $radius;

				if ($type === 'city_state') {
					if (!$allow_city_state_locations) {
						self::append_dry_run_message($blockers, sprintf(__('Location "%s" is city/state targeting, which is only supported in the dedicated Outer Towns field.', 'vms-meta-ads'), $label));
						$unresolved_locations[] = array('label' => $label, 'type' => $type, 'reason' => 'city_state_not_allowed_here');
						return;
					}
					$parts = self::split_city_state_location_label($label);
					if (empty($parts)) {
						$unresolved_locations[] = array('label' => $label, 'type' => $type, 'reason' => 'invalid_city_state_format');
						return;
					}
					$placeholder_key = '__PREVIEW_CITY__::' . strtolower($parts['state_code']) . '::' . sanitize_title((string) $parts['city']);
					$geo_locations['cities'][$placeholder_key] = array(
						'key' => $placeholder_key,
						'radius' => $radius,
						'distance_unit' => 'mile',
					);
					self::append_dry_run_message($warnings, sprintf(__('Dry run used a placeholder Meta city key for "%s". Real create will require a live Meta geo lookup for that city/state row.', 'vms-meta-ads'), $label));
					return;
				}

				if ($type === 'zip') {
					$zip_key = self::build_zip_key($label, (string) ($event_context['country'] ?? 'US'));
					if ($zip_key === '') {
						$unresolved_locations[] = array('label' => $label, 'type' => $type, 'reason' => 'invalid_zip');
						return;
					}
					$geo_locations['zips'][$zip_key] = array('key' => $zip_key);
					if ($prefer_radius) {
						self::append_dry_run_message($warnings, sprintf(__('Dry run preview kept ZIP "%s" as a ZIP polygon. Live create may resolve it into a radius-based custom location when Meta credentials are connected.', 'vms-meta-ads'), $label));
					}
					return;
				}

				if ($type !== 'address') {
					self::append_dry_run_message($blockers, sprintf(__('Location "%s" must be a city/state, ZIP, or full street address.', 'vms-meta-ads'), $label));
					$unresolved_locations[] = array('label' => $label, 'type' => $type, 'reason' => 'unsupported_location_format');
					return;
				}

				$geo_locations['custom_locations'][$normalized_key] = self::build_custom_location_spec(
					$label,
					$radius,
					self::location_context_matches_label($event_context, $label)
						? $event_context
						: self::raw_location_context($label, $event_context)
				);
			};

			if ($primary_anchor !== '') {
				if (!self::is_precise_location_label($primary_anchor)) {
					self::append_dry_run_message($blockers, __('Primary targeting address must be a full street address or ZIP.', 'vms-meta-ads'));
				} else {
					$append_location($primary_anchor, $radius_default, true);
				}
			}

			if (is_array($locations_value) && !empty($locations_value)) {
				foreach ($locations_value as $location_row) {
					if (!is_array($location_row)) {
						continue;
					}
					$label = trim((string) (($location_row['label'] ?? '') ?: ($location_row['query'] ?? '')));
					if ($label === '') {
						continue;
					}
					$radius = max(1, absint($location_row['radius_miles'] ?? $radius_default));
					$append_location($label, $radius, true);
				}
			} else {
				$locations_raw = trim((string) $locations_value);
				if ($locations_raw !== '') {
					$lines = preg_split('/\r\n|\r|\n/', $locations_raw);
					foreach ((array) $lines as $line) {
						$line = trim((string) $line);
						if ($line === '' || strpos($line, '#') === 0) {
							continue;
						}
						$parts = array_map('trim', explode('|', $line, 2));
						$label = trim((string) ($parts[0] ?? ''));
						if ($label === '') {
							continue;
						}
						$radius = $radius_default;
						if (array_key_exists(1, $parts)) {
							$radius_raw = trim((string) $parts[1]);
							if ($radius_raw !== '' && preg_match('/^[0-9]+(?:\.[0-9]+)?(?:\s*(?:mi|mile|miles))?$/i', $radius_raw)) {
								$radius = max(1, (int) round((float) preg_replace('/[^0-9.]/', '', $radius_raw)));
							}
						}
						$append_location($label, $radius, true);
					}
				}
			}

			if (empty($geo_locations['custom_locations']) && empty($geo_locations['zips']) && empty($geo_locations['cities'])) {
				if ($require_explicit_locations) {
					self::append_dry_run_message($blockers, __('Listed-only targeting requires at least one explicit city/state, ZIP, or full address row.', 'vms-meta-ads'));
				} else {
					$event_anchor = self::event_context_anchor_label($event_context);
					if ($event_anchor !== '' && self::is_precise_location_label($event_anchor)) {
						$append_location($event_anchor, $radius_default, true);
					}
				}
			}

			$geo_locations['custom_locations'] = array_values(array_filter($geo_locations['custom_locations'], 'is_array'));
			$geo_locations['zips'] = array_values(array_filter($geo_locations['zips'], 'is_array'));
			$geo_locations['cities'] = array_values(array_filter($geo_locations['cities'], 'is_array'));

			if (empty($geo_locations['custom_locations']) && empty($geo_locations['zips']) && empty($geo_locations['cities'])) {
				self::append_dry_run_message($blockers, __('Audience targeting could not be resolved into a Meta geo payload preview.', 'vms-meta-ads'));
			}
			if (empty($geo_locations['custom_locations'])) {
				unset($geo_locations['custom_locations']);
			}
			if (empty($geo_locations['zips'])) {
				unset($geo_locations['zips']);
			}
			if (empty($geo_locations['cities'])) {
				unset($geo_locations['cities']);
			}

			return array(
				'geo_locations' => $geo_locations,
				'location_rows' => $location_rows,
				'unresolved_locations' => $unresolved_locations,
				'blockers' => $blockers,
				'warnings' => $warnings,
			);
		}

		private static function preview_ad_account_endpoint(array $settings): string
		{
			$ad_account_id = trim((string) ($settings['meta_ad_account_id'] ?? ''));
			if ($ad_account_id === '') {
				return 'act_<missing_ad_account_id>';
			}
			return VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint($ad_account_id);
		}

		private static function append_dry_run_message(array &$messages, string $message): void
		{
			$message = trim(wp_strip_all_tags($message));
			if ($message === '' || in_array($message, $messages, true)) {
				return;
			}
			$messages[] = $message;
		}

		private static function merge_dry_run_messages(array &$messages, array $incoming): void
		{
			foreach ($incoming as $message) {
				self::append_dry_run_message($messages, (string) $message);
			}
		}

		private static function log_dry_run_attempt(array $preview): int
		{
			if (!function_exists('vms_api_attempt_log')) {
				return 0;
			}
			$build_id = max(0, (int) ($preview['build_id'] ?? 0));
			return vms_api_attempt_log(array(
				'user_id' => get_current_user_id(),
				'provider_slug' => 'meta_ads',
				'module_slug' => 'vms-facebook-ads',
				'operation' => 'dry_run_bundle',
				'context' => 'ad_builder',
				'method' => 'LOCAL',
				'endpoint' => 'meta-dry-run/build/' . $build_id,
				'http_status' => 200,
				'duration_ms' => 0,
				'request_payload_json' => array(
					'build_id' => $build_id,
					'event_plan_id' => (int) ($preview['event_plan_id'] ?? 0),
					'dry_run_mode' => (string) ($preview['dry_run_mode'] ?? 'no_network'),
				),
				'response_body_json' => $preview,
			));
		}
  
		public static function create_paused_bundle(int $build_id)
		{
			$build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
			if (is_wp_error($build)) {
				return $build;
			}

			if (!vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to create Meta ads.', 'vms-meta-ads'), array('status' => 403));
			}
			if (!self::is_enabled()) {
				return new WP_Error('api_disabled', __('Meta API is disabled in settings. Enable API mode first.', 'vms-meta-ads'), array('status' => 400));
			}

			$build_status = sanitize_key((string) ($build['status'] ?? 'draft'));
			if ($build_status === 'archived') {
				return new WP_Error('archived_build', __('This build is archived. Duplicate it as a Fresh Draft before creating paused Meta drafts.', 'vms-meta-ads'), array('status' => 409));
			}

			$existing_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			$known_meta_ids = self::build_known_meta_ids_payload($existing_ids);
			$has_existing_meta_ids = !empty($known_meta_ids['campaign_id'])
				|| !empty($known_meta_ids['adset_ids'])
				|| !empty($known_meta_ids['creative_ids'])
				|| !empty($known_meta_ids['ad_ids']);
			if ($has_existing_meta_ids) {
				return new WP_Error(
					'linked_build_blocked',
					__('This build already has Meta IDs or a stale Meta link attached. Duplicate as Fresh Draft, Scrap / Archive Build, or Reset Meta Link before creating a new paused Meta campaign.', 'vms-meta-ads'),
					array(
						'status' => 409,
						'known_meta_ids' => $known_meta_ids,
						'reset_meta_link_warning' => __('Reset Meta Link only unlinks local IDs. It does not delete or archive anything in Meta.', 'vms-meta-ads'),
					)
				);
			}
			$existing_signature = sanitize_text_field((string) ($existing_ids['meta_signature'] ?? ''));
			$current_signature = self::build_create_signature($build);
			if ($existing_signature !== '' && $current_signature !== '' && $existing_signature !== $current_signature) {
				$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
				$allow_recreate = false;
				if ($event_plan_id > 0) {
					$live_raw = (string) get_post_meta($event_plan_id, 'vms_ma_meta_status', true);
					$live_state = strtolower(trim($live_raw));
					$allow_recreate = in_array($live_state, array('', 'draft', 'error', 'paused', 'partial', 'ended'), true);
				}
				if (!$allow_recreate) {
					$message = __('This build changed after Meta assets were created, and the linked campaign appears live or not safely paused. Pause or reset the Meta link before recreating from this draft.', 'vms-meta-ads');
					return new WP_Error('live_recreate_blocked', $message, array('status' => 409));
				}

				$cleared_for_recreate = self::clear_existing_create_ids_for_recreate($build, $existing_ids, 'build_changed_since_last_create');
				if (is_wp_error($cleared_for_recreate)) {
					return $cleared_for_recreate;
				}
				$build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
				if (is_wp_error($build)) {
					return $build;
				}
				$existing_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			}

			$lock = self::acquire_lock($build_id, 'meta_create');
			if (is_wp_error($lock)) {
				return $lock;
			}

			$preflight = self::preflight_create_paused($build);
			if (is_wp_error($preflight)) {
				self::release_lock($build_id, 'meta_create');
				return $preflight;
			}
			$settings = (array) ($preflight['settings'] ?? array());
			$variant_defs = !empty($preflight['recipe_adsets']) && is_array($preflight['recipe_adsets'])
				? self::flatten_recipe_variant_definitions((array) $preflight['recipe_adsets'])
				: self::build_variant_definitions_from_preflight($preflight);
			$ids = array(
				'campaign_id' => '',
				'adset_id' => '',
				'creative_id' => '',
				'ad_id' => '',
				'creative_ids' => array(),
				'ad_ids' => array(),
				'ad_variants_meta' => array(),
				'adset_ids' => array(),
				'adsets_meta' => array(),
				'campaign_recipe' => '',
			);
			$result = array(
				'campaign' => self::empty_object_result(),
				'adset' => self::empty_object_result(),
				'creative' => self::empty_object_result(),
				'ad' => self::empty_object_result(),
				'ad_variants' => array(),
			);

			vms_ma_log('meta_create_requested', array('build_id' => $build_id), $build_id);

			if (is_array($existing_ids)) {
				foreach (array('campaign_id', 'adset_id', 'creative_id', 'ad_id') as $k) {
					if (!empty($existing_ids[$k])) {
						$ids[$k] = sanitize_text_field((string) $existing_ids[$k]);
					}
				}
				if (!empty($existing_ids['creative_ids']) && is_array($existing_ids['creative_ids'])) {
					$ids['creative_ids'] = array_values(array_filter(array_map('sanitize_text_field', (array) $existing_ids['creative_ids'])));
				}
				if (!empty($existing_ids['ad_ids']) && is_array($existing_ids['ad_ids'])) {
					$ids['ad_ids'] = array_values(array_filter(array_map('sanitize_text_field', (array) $existing_ids['ad_ids'])));
				}
				if (!empty($existing_ids['ad_variants_meta']) && is_array($existing_ids['ad_variants_meta'])) {
					$ids['ad_variants_meta'] = array_values((array) $existing_ids['ad_variants_meta']);
				}
				if (!empty($existing_ids['adset_ids']) && is_array($existing_ids['adset_ids'])) {
					$ids['adset_ids'] = array_values(array_filter(array_map('sanitize_text_field', (array) $existing_ids['adset_ids'])));
				}
				if (!empty($existing_ids['adsets_meta']) && is_array($existing_ids['adsets_meta'])) {
					$ids['adsets_meta'] = (array) $existing_ids['adsets_meta'];
				}
				if (!empty($existing_ids['campaign_recipe'])) {
					$ids['campaign_recipe'] = sanitize_key((string) $existing_ids['campaign_recipe']);
				}
			}

			$existing_variant_meta = self::normalize_existing_variant_meta($existing_ids, $variant_defs);
			$fully_created = true;
			foreach ($existing_variant_meta as $row) {
				if (empty($row['ad_id'])) {
					$fully_created = false;
					break;
				}
			}
			if (!empty($existing_variant_meta) && $fully_created) {
				self::release_lock($build_id, 'meta_create');
				return new WP_Error(
					'already_created',
					__('This build already created all requested ads in Meta. Clear existing Meta IDs before retry, or Clone Build to create a new ad.', 'vms-meta-ads'),
					array('status' => 409, 'ad_id' => (string) ($existing_variant_meta[0]['ad_id'] ?? ''))
				);
			}

			if (self::has_reusable_meta_status_objects($existing_ids)) {
				$reusable_status = self::assert_reusable_meta_ids_are_paused($existing_ids, $settings);
				if (is_wp_error($reusable_status)) {
					self::release_lock($build_id, 'meta_create');
					return $reusable_status;
				}
			}

			$result['campaign']['attempted'] = true;
			$campaign_response = null;
			$campaign_was_existing = ($ids['campaign_id'] !== '');
			if ($campaign_was_existing) {
				$campaign_response = array('id' => $ids['campaign_id']);
			} else {
				$objective_candidates = self::campaign_objective_candidates((string) $preflight['objective']);
				$campaign_path = VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/campaigns';
				foreach ($objective_candidates as $index => $objective_candidate) {
					$payload_candidates = self::campaign_payload_candidates((string) $preflight['campaign_name'], (string) $objective_candidate);
					$paused_candidate_check = self::validate_paused_campaign_payload_candidates($payload_candidates);
					if (is_wp_error($paused_candidate_check)) {
						self::release_lock($build_id, 'meta_create');
						return $paused_candidate_check;
					}
					foreach ($payload_candidates as $payload_index => $campaign_payload) {
						$campaign_response = self::meta_post_json($settings, $campaign_path, $campaign_payload, 'create_campaign', $build_id);
						if (is_wp_error($campaign_response) && self::is_invalid_parameter_error($campaign_response)) {
							$campaign_response = self::meta_post($settings, $campaign_path, self::campaign_payload_for_form($campaign_payload), 'create_campaign', $build_id);
						}
						if (!is_wp_error($campaign_response)) {
							$preflight['objective'] = (string) $objective_candidate;
							break 2;
						}
						$can_retry_payload = $payload_index < (count($payload_candidates) - 1);
						if ($can_retry_payload && self::is_invalid_parameter_error($campaign_response) && !self::is_objective_error($campaign_response)) {
							continue;
						}
						break;
					}
					$can_retry_objective = $index < (count($objective_candidates) - 1);
					if (!$can_retry_objective || !is_wp_error($campaign_response) || !self::is_invalid_parameter_error($campaign_response) || !self::is_objective_error($campaign_response)) {
						break;
					}
				}
			}
			if (is_wp_error($campaign_response)) {
				$campaign_response = self::wrap_step_error('Campaign', $campaign_response);
				$result['campaign']['error'] = $campaign_response->get_error_message();
				self::persist_create_partial($build, $ids, $result, $campaign_response->get_error_message(), $settings);
				self::release_lock($build_id, 'meta_create');
				return self::wrap_partial_create_error($campaign_response, $ids, $settings);
			}
			$ids['campaign_id'] = self::extract_created_id((array) $campaign_response, 'campaign');
			if ($ids['campaign_id'] === '') {
				$error = new WP_Error('meta_campaign_missing_id', __('Meta campaign create returned no ID.', 'vms-meta-ads'), array('status' => 502));
				$result['campaign']['error'] = $error->get_error_message();
				self::persist_create_partial($build, $ids, $result, $error->get_error_message(), $settings);
				self::release_lock($build_id, 'meta_create');
				return self::wrap_partial_create_error($error, $ids, $settings);
			}
			$result['campaign']['id'] = $ids['campaign_id'];
			$result['campaign']['changed'] = !$campaign_was_existing;
			$result['campaign']['status'] = $campaign_was_existing ? 'EXISTING' : self::STATUS_PAUSED;

			if (!empty($preflight['recipe_adsets']) && is_array($preflight['recipe_adsets'])) {
				$recipe_success = self::create_paused_recipe_bundle($build, $preflight, $ids, $result, $settings, $existing_ids, $build_id);
				self::release_lock($build_id, 'meta_create');
				return $recipe_success;
			}

			$result['adset']['attempted'] = true;
			$adset_was_existing = ($ids['adset_id'] !== '');
			$adset_response = null;
			if ($adset_was_existing) {
				$adset_response = array('id' => $ids['adset_id']);
			} else {
				$adset_response = self::meta_post(
					$settings,
					VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/adsets',
					array(
						'name' => (string) $preflight['adset_name'],
						'campaign_id' => $ids['campaign_id'],
						'billing_event' => 'IMPRESSIONS',
						'optimization_goal' => (string) $preflight['optimization_goal'],
						'bid_strategy' => 'LOWEST_COST_WITHOUT_CAP',
						'status' => self::STATUS_PAUSED,
						'lifetime_budget' => (string) ((int) $preflight['lifetime_budget_minor']),
						'start_time' => (string) $preflight['start_time_iso8601'],
						'end_time' => (string) $preflight['end_time_iso8601'],
						'targeting' => wp_json_encode((array) $preflight['targeting']),
					) + self::adset_promoted_object_payload((array) ($preflight['promoted_object'] ?? array())) + self::adset_dsa_payload($settings),
					'create_adset',
					$build_id
				);
			}
			if (is_wp_error($adset_response)) {
				$adset_response = self::wrap_step_error('Ad Set', $adset_response);
				$result['adset']['error'] = $adset_response->get_error_message();
				self::persist_create_partial($build, $ids, $result, $adset_response->get_error_message(), $settings);
				self::release_lock($build_id, 'meta_create');
				return self::wrap_partial_create_error($adset_response, $ids, $settings);
			}
			$ids['adset_id'] = self::extract_created_id((array) $adset_response, 'adset');
			if ($ids['adset_id'] === '') {
				$error = new WP_Error('meta_adset_missing_id', __('Meta ad set create returned no ID.', 'vms-meta-ads'), array('status' => 502));
				$result['adset']['error'] = $error->get_error_message();
				self::persist_create_partial($build, $ids, $result, $error->get_error_message(), $settings);
				self::release_lock($build_id, 'meta_create');
				return self::wrap_partial_create_error($error, $ids, $settings);
			}
			$result['adset']['id'] = $ids['adset_id'];
			$result['adset']['changed'] = !$adset_was_existing;
			$result['adset']['status'] = $adset_was_existing ? 'EXISTING' : self::STATUS_PAUSED;

			$needs_uploaded_images = false;
			foreach ($existing_variant_meta as $variant_meta) {
				if (empty($variant_meta['creative_id'])) {
					$needs_uploaded_images = true;
					break;
				}
			}
			$shared_images = is_array($preflight['creative_images'] ?? null) ? (array) $preflight['creative_images'] : array();
			if ($needs_uploaded_images) {
				$shared_images = self::upload_creative_images_to_meta($settings, $shared_images, $build_id);
			}

			$any_retry_used = false;
			foreach ($variant_defs as $index => $variant) {
				$variant_meta = is_array($existing_variant_meta[$index] ?? null) ? (array) $existing_variant_meta[$index] : array();
				$variant_result = array(
					'variant_key' => (string) ($variant['variant_key'] ?? ('v' . ($index + 1))),
					'label' => (string) ($variant['label'] ?? ('Variant ' . ($index + 1))),
					'creative' => self::empty_object_result(),
					'ad' => self::empty_object_result(),
				);

				$creative_id = sanitize_text_field((string) ($variant_meta['creative_id'] ?? ''));
				$ad_id = sanitize_text_field((string) ($variant_meta['ad_id'] ?? ''));

				$variant_result['creative']['attempted'] = true;
				if ($creative_id !== '') {
					$variant_result['creative']['id'] = $creative_id;
					$variant_result['creative']['changed'] = false;
					$variant_result['creative']['status'] = 'EXISTING';
				} else {
					$creative_response = self::create_creative_for_variant($settings, $preflight, $variant, $shared_images, $build_id);
					if (is_wp_error($creative_response)) {
						$creative_response = self::wrap_step_error('Creative', $creative_response);
						$variant_result['creative']['error'] = $creative_response->get_error_message();
						$result['creative']['error'] = $creative_response->get_error_message();
						$result['ad_variants'][] = $variant_result;
						$ids['ad_variants_meta'][] = array(
							'variant_key' => (string) $variant_result['variant_key'],
							'label' => (string) $variant_result['label'],
							'creative_id' => '',
							'ad_id' => $ad_id,
						);
						self::persist_create_partial($build, $ids, $result, $creative_response->get_error_message(), $settings);
						self::release_lock($build_id, 'meta_create');
						return self::wrap_partial_create_error($creative_response, $ids, $settings);
					}
					$creative_id = self::extract_created_id((array) $creative_response, 'creative');
					if ($creative_id === '') {
						$error = new WP_Error('meta_creative_missing_id', __('Meta creative create returned no ID.', 'vms-meta-ads'), array('status' => 502));
						$variant_result['creative']['error'] = $error->get_error_message();
						$result['creative']['error'] = $error->get_error_message();
						$result['ad_variants'][] = $variant_result;
						self::persist_create_partial($build, $ids, $result, $error->get_error_message(), $settings);
						self::release_lock($build_id, 'meta_create');
						return self::wrap_partial_create_error($error, $ids, $settings);
					}
					$variant_result['creative']['id'] = $creative_id;
					$variant_result['creative']['changed'] = true;
					$variant_result['creative']['status'] = self::STATUS_PAUSED;
				}

				$variant_result['ad']['attempted'] = true;
				if ($ad_id !== '') {
					$variant_result['ad']['id'] = $ad_id;
					$variant_result['ad']['changed'] = false;
					$variant_result['ad']['status'] = 'EXISTING';
				} else {
						$variant_preflight = $preflight;
					$variant_preflight['ad_name'] = (string) ($variant['ad_name'] ?? ('Variant ' . ($index + 1)));
					$ad_attempt = self::create_ad_with_single_retry($settings, $variant_preflight, array(
						'adset_id' => $ids['adset_id'],
						'creative_id' => $creative_id,
					), $build_id);
					$ad_response = $ad_attempt['response'];
					if (!empty($ad_attempt['retried'])) {
						$any_retry_used = true;
						$variant_result['ad']['retry_used'] = true;
					}
					if (is_wp_error($ad_response)) {
						$fallback_attempt = self::retry_ad_action_with_standard_creative(
							$settings,
							$preflight,
							$variant,
							$shared_images,
							(string) $ids['adset_id'],
							(string) $variant_preflight['ad_name'],
							$ad_response,
							$build_id
						);
						if (!empty($fallback_attempt['handled'])) {
							$ad_response = $fallback_attempt['response'] ?? $ad_response;
							if (!empty($fallback_attempt['creative_id'])) {
								$creative_id = sanitize_text_field((string) $fallback_attempt['creative_id']);
								$variant_result['creative']['id'] = $creative_id;
							}
							if (!empty($fallback_attempt['warning'])) {
								$result['warnings'][] = sanitize_text_field((string) $fallback_attempt['warning']);
							}
							if (!empty($fallback_attempt['retried'])) {
								$any_retry_used = true;
								$variant_result['ad']['retry_used'] = true;
							}
						}
					}
					if (is_wp_error($ad_response)) {
						$ad_response = self::wrap_step_error('Ad', $ad_response);
						$variant_result['ad']['error'] = $ad_response->get_error_message();
						$result['ad']['error'] = $ad_response->get_error_message();
						$result['ad_variants'][] = $variant_result;
						$ids['ad_variants_meta'][] = array(
							'variant_key' => (string) $variant_result['variant_key'],
							'label' => (string) $variant_result['label'],
							'creative_id' => $creative_id,
							'ad_id' => '',
						);
						self::persist_create_partial($build, $ids, $result, $ad_response->get_error_message(), $settings);
						self::release_lock($build_id, 'meta_create');
						return self::wrap_partial_create_error($ad_response, $ids, $settings);
					}
					$ad_id = self::extract_created_id((array) $ad_response, 'ad');
					if ($ad_id === '') {
						$error = new WP_Error('meta_ad_missing_id', __('Meta ad create returned no ID.', 'vms-meta-ads'), array('status' => 502));
						$variant_result['ad']['error'] = $error->get_error_message();
						$result['ad']['error'] = $error->get_error_message();
						$result['ad_variants'][] = $variant_result;
						self::persist_create_partial($build, $ids, $result, $error->get_error_message(), $settings);
						self::release_lock($build_id, 'meta_create');
						return self::wrap_partial_create_error($error, $ids, $settings);
					}
					$variant_result['ad']['id'] = $ad_id;
					$variant_result['ad']['changed'] = true;
					$variant_result['ad']['status'] = self::STATUS_PAUSED;
				}

				$ids['ad_variants_meta'][] = array(
					'variant_key' => (string) $variant_result['variant_key'],
					'label' => (string) $variant_result['label'],
					'creative_id' => $creative_id,
					'ad_id' => $ad_id,
				);
				$ids['creative_ids'][] = $creative_id;
				$ids['ad_ids'][] = $ad_id;
				$result['ad_variants'][] = $variant_result;
			}

			$ids['creative_ids'] = array_values(array_unique(array_filter($ids['creative_ids'])));
			$ids['ad_ids'] = array_values(array_unique(array_filter($ids['ad_ids'])));
			$ids['creative_id'] = (string) ($ids['creative_ids'][0] ?? '');
			$ids['ad_id'] = (string) ($ids['ad_ids'][0] ?? '');

			$first_variant_result = is_array($result['ad_variants'][0] ?? null) ? (array) $result['ad_variants'][0] : array();
			if (!empty($first_variant_result['creative']) && is_array($first_variant_result['creative'])) {
				$result['creative'] = (array) $first_variant_result['creative'];
			}
			if (!empty($first_variant_result['ad']) && is_array($first_variant_result['ad'])) {
				$result['ad'] = (array) $first_variant_result['ad'];
			}
			$result['ad']['variant_count'] = count($result['ad_variants']);

			$success_warnings = !empty($preflight['warnings']) && is_array($preflight['warnings']) ? array_values($preflight['warnings']) : array();
			if (!empty($any_retry_used)) {
				$success_warnings[] = __('At least one ad create step failed once and was retried automatically without recreating the campaign or ad set.', 'vms-meta-ads');
			}
			if (count($result['ad_variants']) > 1) {
				$success_warnings[] = sprintf(__('Created %d ad variants under one campaign/ad set.', 'vms-meta-ads'), count($result['ad_variants']));
			}
			$success = self::persist_create_success($build, $ids, $result, $settings, $success_warnings);
			self::release_lock($build_id, 'meta_create');
			return $success;
		}


		private static function flatten_recipe_variant_definitions(array $recipe_adsets): array
		{
			$out = array();
			foreach ($recipe_adsets as $adset) {
				if (!is_array($adset)) {
					continue;
				}
				$adset_key = sanitize_key((string) ($adset['key'] ?? 'adset')) ?: 'adset';
				foreach ((array) ($adset['variants'] ?? array()) as $index => $variant) {
					if (!is_array($variant)) {
						continue;
					}
					$variant['adset_key'] = $adset_key;
					$variant['variant_key'] = sanitize_key((string) ($variant['variant_key'] ?? ('v' . ($index + 1)))) ?: ('v' . ($index + 1));
					$out[] = $variant;
				}
			}
			return $out;
		}

		private static function normalize_existing_recipe_meta(array $existing_ids, array $recipe_adsets): array
		{
			$rows = !empty($existing_ids['ad_variants_meta']) && is_array($existing_ids['ad_variants_meta']) ? array_values((array) $existing_ids['ad_variants_meta']) : array();
			$by_key = array();
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$adset_key = sanitize_key((string) ($row['adset_key'] ?? ''));
				$variant_key = sanitize_key((string) ($row['variant_key'] ?? ''));
				if ($adset_key === '' || $variant_key === '') {
					continue;
				}
				$by_key[$adset_key . '::' . $variant_key] = array(
					'adset_key' => $adset_key,
					'variant_key' => $variant_key,
					'label' => sanitize_text_field((string) ($row['label'] ?? '')),
					'adset_id' => sanitize_text_field((string) ($row['adset_id'] ?? '')),
					'creative_id' => sanitize_text_field((string) ($row['creative_id'] ?? '')),
					'ad_id' => sanitize_text_field((string) ($row['ad_id'] ?? '')),
				);
			}

			$adsets_meta = !empty($existing_ids['adsets_meta']) && is_array($existing_ids['adsets_meta']) ? (array) $existing_ids['adsets_meta'] : array();
			$out = array();
			foreach ($recipe_adsets as $adset) {
				if (!is_array($adset)) {
					continue;
				}
				$adset_key = sanitize_key((string) ($adset['key'] ?? 'adset')) ?: 'adset';
				$adset_id = '';
				if (!empty($adsets_meta[$adset_key]) && is_array($adsets_meta[$adset_key])) {
					$adset_id = sanitize_text_field((string) ($adsets_meta[$adset_key]['adset_id'] ?? ''));
				}
				$out[$adset_key] = array(
					'adset_id' => $adset_id,
					'variants' => array(),
				);
				foreach ((array) ($adset['variants'] ?? array()) as $index => $variant) {
					if (!is_array($variant)) {
						continue;
					}
					$variant_key = sanitize_key((string) ($variant['variant_key'] ?? ('v' . ($index + 1)))) ?: ('v' . ($index + 1));
					$row = $by_key[$adset_key . '::' . $variant_key] ?? array();
					if ($adset_id === '' && !empty($row['adset_id'])) {
						$adset_id = sanitize_text_field((string) $row['adset_id']);
						$out[$adset_key]['adset_id'] = $adset_id;
					}
					$out[$adset_key]['variants'][$variant_key] = $row;
				}
			}
			return $out;
		}

		private static function create_paused_recipe_bundle(array $build, array $preflight, array $ids, array $result, array $settings, array $existing_ids, int $build_id)
		{
			$recipe_adsets = !empty($preflight['recipe_adsets']) && is_array($preflight['recipe_adsets']) ? array_values((array) $preflight['recipe_adsets']) : array();
			if (empty($recipe_adsets)) {
				return new WP_Error('missing_recipe_adsets', __('Clean-room recipe did not produce any ad sets.', 'vms-meta-ads'), array('status' => 400));
			}

			$existing_recipe_meta = self::normalize_existing_recipe_meta($existing_ids, $recipe_adsets);
			$needs_uploaded_images = true;
			$shared_images = is_array($preflight['creative_images'] ?? null) ? (array) $preflight['creative_images'] : array();
			if ($needs_uploaded_images) {
				$shared_images = self::upload_creative_images_to_meta($settings, $shared_images, $build_id);
			}

			$ids['adset_ids'] = !empty($ids['adset_ids']) && is_array($ids['adset_ids']) ? array_values((array) $ids['adset_ids']) : array();
			$ids['adsets_meta'] = !empty($ids['adsets_meta']) && is_array($ids['adsets_meta']) ? (array) $ids['adsets_meta'] : array();
			$ids['campaign_recipe'] = sanitize_key((string) ($preflight['recipe_key'] ?? 'clean_room_full_push'));
			$result['adsets'] = array();
			$any_retry_used = false;

			foreach ($recipe_adsets as $adset_index => $adset_preflight) {
				if (!is_array($adset_preflight)) {
					continue;
				}
				$adset_key = sanitize_key((string) ($adset_preflight['key'] ?? ('adset_' . ($adset_index + 1)))) ?: ('adset_' . ($adset_index + 1));
				$adset_label = sanitize_text_field((string) ($adset_preflight['label'] ?? ('Ad Set ' . ($adset_index + 1))));
				$existing_adset = is_array($existing_recipe_meta[$adset_key] ?? null) ? (array) $existing_recipe_meta[$adset_key] : array();
				$adset_id = sanitize_text_field((string) ($existing_adset['adset_id'] ?? ''));
				$adset_result = array(
					'key' => $adset_key,
					'label' => $adset_label,
					'adset' => self::empty_object_result(),
					'ads' => array(),
				);
				$adset_result['adset']['attempted'] = true;

				if ($adset_id !== '') {
					$adset_response = array('id' => $adset_id);
					$adset_result['adset']['changed'] = false;
					$adset_result['adset']['status'] = 'EXISTING';
				} else {
					$adset_response = self::meta_post(
						$settings,
						VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/adsets',
						array(
							'name' => (string) ($adset_preflight['adset_name'] ?? $adset_label),
							'campaign_id' => $ids['campaign_id'],
							'billing_event' => 'IMPRESSIONS',
							'optimization_goal' => (string) ($adset_preflight['optimization_goal'] ?? $preflight['optimization_goal'] ?? 'LINK_CLICKS'),
							'bid_strategy' => 'LOWEST_COST_WITHOUT_CAP',
							'status' => self::STATUS_PAUSED,
							'lifetime_budget' => (string) ((int) ($adset_preflight['lifetime_budget_minor'] ?? 0)),
							'start_time' => (string) ($adset_preflight['start_time_iso8601'] ?? $preflight['start_time_iso8601'] ?? ''),
							'end_time' => (string) ($adset_preflight['end_time_iso8601'] ?? $preflight['end_time_iso8601'] ?? ''),
							'targeting' => wp_json_encode((array) ($adset_preflight['targeting'] ?? $preflight['targeting'] ?? array())),
						) + self::adset_promoted_object_payload((array) ($adset_preflight['promoted_object'] ?? $preflight['promoted_object'] ?? array())) + self::adset_dsa_payload($settings),
						'create_recipe_adset_' . $adset_key,
						$build_id
					);
				}

				if (is_wp_error($adset_response)) {
					$adset_response = self::wrap_step_error($adset_label . ' Ad Set', $adset_response);
					$adset_result['adset']['error'] = $adset_response->get_error_message();
					$result['adsets'][] = $adset_result;
					self::persist_create_partial($build, $ids, $result, $adset_response->get_error_message(), $settings);
					return self::wrap_partial_create_error($adset_response, $ids, $settings);
				}
				$adset_id = self::extract_created_id((array) $adset_response, 'adset');
				if ($adset_id === '') {
					$error = new WP_Error('meta_recipe_adset_missing_id', sprintf(__('%s create returned no ad set ID.', 'vms-meta-ads'), $adset_label), array('status' => 502));
					$adset_result['adset']['error'] = $error->get_error_message();
					$result['adsets'][] = $adset_result;
					self::persist_create_partial($build, $ids, $result, $error->get_error_message(), $settings);
					return self::wrap_partial_create_error($error, $ids, $settings);
				}
				$adset_result['adset']['id'] = $adset_id;
				if (!isset($adset_result['adset']['changed']) || $adset_result['adset']['changed'] === null) {
					$adset_result['adset']['changed'] = empty($existing_adset['adset_id']);
					$adset_result['adset']['status'] = self::STATUS_PAUSED;
				}
				$ids['adset_ids'][] = $adset_id;
				$ids['adsets_meta'][$adset_key] = array(
					'adset_id' => $adset_id,
					'label' => $adset_label,
				);
				if (empty($ids['adset_id'])) {
					$ids['adset_id'] = $adset_id;
				}

				$variants = !empty($adset_preflight['variants']) && is_array($adset_preflight['variants']) ? array_values((array) $adset_preflight['variants']) : array();
				$existing_variants = is_array($existing_adset['variants'] ?? null) ? (array) $existing_adset['variants'] : array();
				foreach ($variants as $variant_index => $variant) {
					if (!is_array($variant)) {
						continue;
					}
					$variant_key = sanitize_key((string) ($variant['variant_key'] ?? ('v' . ($variant_index + 1)))) ?: ('v' . ($variant_index + 1));
					$variant_label = sanitize_text_field((string) ($variant['label'] ?? ('Variant ' . ($variant_index + 1))));
					$variant_meta = is_array($existing_variants[$variant_key] ?? null) ? (array) $existing_variants[$variant_key] : array();
					$creative_id = sanitize_text_field((string) ($variant_meta['creative_id'] ?? ''));
					$ad_id = sanitize_text_field((string) ($variant_meta['ad_id'] ?? ''));
					$variant_result = array(
						'adset_key' => $adset_key,
						'adset_label' => $adset_label,
						'variant_key' => $variant_key,
						'label' => $variant_label,
						'creative' => self::empty_object_result(),
						'ad' => self::empty_object_result(),
					);

					$variant_result['creative']['attempted'] = true;
					if ($creative_id !== '') {
						$variant_result['creative']['id'] = $creative_id;
						$variant_result['creative']['changed'] = false;
						$variant_result['creative']['status'] = 'EXISTING';
					} else {
						$creative_response = self::create_creative_for_variant($settings, $adset_preflight, $variant, $shared_images, $build_id);
						if (is_wp_error($creative_response)) {
							$creative_response = self::wrap_step_error($adset_label . ' Creative', $creative_response);
							$variant_result['creative']['error'] = $creative_response->get_error_message();
							$result['ad_variants'][] = $variant_result;
							$adset_result['ads'][] = $variant_result;
							$result['adsets'][] = $adset_result;
							self::persist_create_partial($build, $ids, $result, $creative_response->get_error_message(), $settings);
							return self::wrap_partial_create_error($creative_response, $ids, $settings);
						}
						$creative_id = self::extract_created_id((array) $creative_response, 'creative');
						if ($creative_id === '') {
							$error = new WP_Error('meta_recipe_creative_missing_id', sprintf(__('%s creative create returned no ID.', 'vms-meta-ads'), $variant_label), array('status' => 502));
							$variant_result['creative']['error'] = $error->get_error_message();
							$result['ad_variants'][] = $variant_result;
							$adset_result['ads'][] = $variant_result;
							$result['adsets'][] = $adset_result;
							self::persist_create_partial($build, $ids, $result, $error->get_error_message(), $settings);
							return self::wrap_partial_create_error($error, $ids, $settings);
						}
						$variant_result['creative']['id'] = $creative_id;
						$variant_result['creative']['changed'] = true;
						$variant_result['creative']['status'] = self::STATUS_PAUSED;
					}

					$variant_result['ad']['attempted'] = true;
					if ($ad_id !== '') {
						$variant_result['ad']['id'] = $ad_id;
						$variant_result['ad']['changed'] = false;
						$variant_result['ad']['status'] = 'EXISTING';
					} else {
						$variant_preflight = $adset_preflight;
						$variant_preflight['ad_name'] = (string) ($variant['ad_name'] ?? ($adset_label . ' - ' . $variant_label));
						$ad_attempt = self::create_ad_with_single_retry($settings, $variant_preflight, array(
							'adset_id' => $adset_id,
							'creative_id' => $creative_id,
						), $build_id);
						$ad_response = $ad_attempt['response'];
						if (!empty($ad_attempt['retried'])) {
							$any_retry_used = true;
							$variant_result['ad']['retry_used'] = true;
						}
						if (is_wp_error($ad_response)) {
							$fallback_attempt = self::retry_ad_action_with_standard_creative(
								$settings,
								$adset_preflight,
								$variant,
								$shared_images,
								$adset_id,
								(string) $variant_preflight['ad_name'],
								$ad_response,
								$build_id
							);
							if (!empty($fallback_attempt['handled'])) {
								$ad_response = $fallback_attempt['response'] ?? $ad_response;
								if (!empty($fallback_attempt['creative_id'])) {
									$creative_id = sanitize_text_field((string) $fallback_attempt['creative_id']);
									$variant_result['creative']['id'] = $creative_id;
								}
								if (!empty($fallback_attempt['warning'])) {
									$result['warnings'][] = sanitize_text_field((string) $fallback_attempt['warning']);
								}
							}
						}
						if (is_wp_error($ad_response)) {
							$ad_response = self::wrap_step_error($adset_label . ' Ad', $ad_response);
							$variant_result['ad']['error'] = $ad_response->get_error_message();
							$result['ad_variants'][] = $variant_result;
							$adset_result['ads'][] = $variant_result;
							$result['adsets'][] = $adset_result;
							self::persist_create_partial($build, $ids, $result, $ad_response->get_error_message(), $settings);
							return self::wrap_partial_create_error($ad_response, $ids, $settings);
						}
						$ad_id = self::extract_created_id((array) $ad_response, 'ad');
						if ($ad_id === '') {
							$error = new WP_Error('meta_recipe_ad_missing_id', sprintf(__('%s ad create returned no ID.', 'vms-meta-ads'), $variant_label), array('status' => 502));
							$variant_result['ad']['error'] = $error->get_error_message();
							$result['ad_variants'][] = $variant_result;
							$adset_result['ads'][] = $variant_result;
							$result['adsets'][] = $adset_result;
							self::persist_create_partial($build, $ids, $result, $error->get_error_message(), $settings);
							return self::wrap_partial_create_error($error, $ids, $settings);
						}
						$variant_result['ad']['id'] = $ad_id;
						$variant_result['ad']['changed'] = true;
						$variant_result['ad']['status'] = self::STATUS_PAUSED;
					}

					$ids['creative_ids'][] = $creative_id;
					$ids['ad_ids'][] = $ad_id;
					if (empty($ids['creative_id'])) {
						$ids['creative_id'] = $creative_id;
					}
					if (empty($ids['ad_id'])) {
						$ids['ad_id'] = $ad_id;
					}
					$ids['ad_variants_meta'][] = array(
						'adset_key' => $adset_key,
						'adset_label' => $adset_label,
						'adset_id' => $adset_id,
						'variant_key' => $variant_key,
						'label' => $variant_label,
						'creative_id' => $creative_id,
						'ad_id' => $ad_id,
					);
					$adset_result['ads'][] = $variant_result;
					$result['ad_variants'][] = $variant_result;
				}
				$result['adsets'][] = $adset_result;
			}

			$ids['adset_ids'] = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) $ids['adset_ids']))));
			$ids['creative_ids'] = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) $ids['creative_ids']))));
			$ids['ad_ids'] = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) $ids['ad_ids']))));
			$ids['creative_id'] = (string) ($ids['creative_id'] ?: ($ids['creative_ids'][0] ?? ''));
			$ids['ad_id'] = (string) ($ids['ad_id'] ?: ($ids['ad_ids'][0] ?? ''));
			$ids['adset_id'] = (string) ($ids['adset_id'] ?: ($ids['adset_ids'][0] ?? ''));

			$first_variant_result = is_array($result['ad_variants'][0] ?? null) ? (array) $result['ad_variants'][0] : array();
			$result['creative'] = is_array($first_variant_result['creative'] ?? null) ? (array) $first_variant_result['creative'] : self::empty_object_result();
			$result['ad'] = is_array($first_variant_result['ad'] ?? null) ? (array) $first_variant_result['ad'] : self::empty_object_result();
			$result['ad']['variant_count'] = count($result['ad_variants']);
			$result['adset'] = is_array($result['adsets'][0]['adset'] ?? null) ? (array) $result['adsets'][0]['adset'] : self::empty_object_result();
			$result['adset']['adset_count'] = count($result['adsets']);

			$warnings = !empty($preflight['warnings']) && is_array($preflight['warnings']) ? array_values($preflight['warnings']) : array();
			$warnings[] = sprintf(__('Clean-room recipe created %1$d paused ad sets and %2$d paused ads. Review in Meta before publishing.', 'vms-meta-ads'), count($result['adsets']), count($result['ad_variants']));
			if (!empty($any_retry_used)) {
				$warnings[] = __('At least one ad create step failed once and was retried automatically without recreating the campaign.', 'vms-meta-ads');
			}
			return self::persist_create_success($build, $ids, $result, $settings, $warnings);
		}

		public static function go_live(int $build_id)
		{
			return self::go_live_build($build_id);
		}

		public static function go_live_build(int $build_id)
		{
			$resolved = self::resolve_event_from_build($build_id);
			if (is_wp_error($resolved)) {
				return $resolved;
			}
			return self::go_live_event_plan((int) $resolved['event_plan_id'], (array) $resolved['build']);
		}

		public static function go_live_event_plan(int $event_plan_id, ?array $resolved_build = null)
		{
			$lock = self::acquire_lock($event_plan_id, 'meta_go_live_event');
			if (is_wp_error($lock)) {
				return $lock;
			}

			$build = $resolved_build;
			if (!is_array($build)) {
				$build = self::resolve_build_by_event_plan($event_plan_id);
			}
			if (is_wp_error($build)) {
				self::release_lock($event_plan_id, 'meta_go_live_event');
				return $build;
			}

			$preflight = self::preflight_go_live($event_plan_id, $build);
			if (is_wp_error($preflight)) {
				self::release_lock($event_plan_id, 'meta_go_live_event');
				return $preflight;
			}
			$ids = (array) $preflight['ids'];

			$steps = array(
				'campaign' => array('id' => $ids['campaign_id'], 'target' => self::STATUS_ACTIVE),
			);
			$seen_adsets = array();
			$adset_ids = !empty($ids['adset_ids']) && is_array($ids['adset_ids']) ? array_values((array) $ids['adset_ids']) : array((string) ($ids['adset_id'] ?? ''));
			foreach ($adset_ids as $index => $adset_variant_id) {
				$adset_variant_id = sanitize_text_field((string) $adset_variant_id);
				if ($adset_variant_id === '' || isset($seen_adsets[$adset_variant_id])) {
					continue;
				}
				$seen_adsets[$adset_variant_id] = true;
				$steps['adset_' . ($index + 1)] = array('id' => $adset_variant_id, 'target' => self::STATUS_ACTIVE);
			}
			$seen_ads = array();
			$ad_ids = !empty($ids['ad_ids']) && is_array($ids['ad_ids']) ? array_values((array) $ids['ad_ids']) : array((string) ($ids['ad_id'] ?? ''));
			foreach ($ad_ids as $index => $ad_variant_id) {
				$ad_variant_id = sanitize_text_field((string) $ad_variant_id);
				if ($ad_variant_id === '' || isset($seen_ads[$ad_variant_id])) {
					continue;
				}
				$seen_ads[$ad_variant_id] = true;
				$steps['ad_variant_' . ($index + 1)] = array('id' => $ad_variant_id, 'target' => self::STATUS_ACTIVE);
			}
			$result = self::run_status_updates((int) ($build['id'] ?? 0), $steps, array('rollback_on_partial' => true));
			$refresh = self::build_status_snapshot($ids);
			$outcome = !empty($result['ok']) ? 'ok' : (!empty($result['rolled_back']) ? 'error' : 'partial');
			self::update_event_plan_after_action($event_plan_id, 'go_live', $outcome, $refresh, $result, (bool) ($result['rolled_back'] ?? false));
			self::release_lock($event_plan_id, 'meta_go_live_event');

			$response = array(
				'ok' => !empty($result['ok']),
				'result' => (array) ($result['result'] ?? array()),
				'rolled_back' => !empty($result['rolled_back']),
				'message' => (string) ($result['message'] ?? ''),
				'updated_local' => self::current_local_time(),
				'campaign' => (array) ($refresh['campaign'] ?? self::unknown_status('')),
				'adset' => (array) ($refresh['adset'] ?? self::unknown_status('')),
				'adsets' => array_values(is_array($refresh['adsets'] ?? null) ? (array) $refresh['adsets'] : array()),
				'adset_count' => (int) ($refresh['adset_count'] ?? 0),
				'ad' => (array) ($refresh['ad'] ?? self::unknown_status('')),
				'ad_account_id' => (string) ($refresh['ad_account_id'] ?? ''),
				'open_in_meta_url' => (string) ($refresh['open_in_meta_url'] ?? ''),
				'ad_variants' => array_values(is_array($refresh['ad_variants'] ?? null) ? (array) $refresh['ad_variants'] : array()),
				'ad_variant_count' => (int) ($refresh['ad_variant_count'] ?? 0),
			);

			if (!empty($response['ok']) && strtoupper((string) ($response['ad']['effective_status'] ?? '')) !== self::STATUS_ACTIVE) {
				$response['delivery_warning'] = __('Meta shows this as not delivering yet. This can happen during review or if targeting is too narrow.', 'vms-meta-ads');
			}

			return $response;
		}

		public static function pause_all_event_plan(int $event_plan_id, ?array $resolved_build = null)
		{
			$lock = self::acquire_lock($event_plan_id, 'meta_pause_all_event');
			if (is_wp_error($lock)) {
				return $lock;
			}

			$build = $resolved_build;
			if (!is_array($build)) {
				$build = self::resolve_build_by_event_plan($event_plan_id);
			}
			if (is_wp_error($build)) {
				self::release_lock($event_plan_id, 'meta_pause_all_event');
				return $build;
			}
			$ids = self::resolve_meta_ids($build);
			if (is_wp_error($ids)) {
				self::release_lock($event_plan_id, 'meta_pause_all_event');
				return $ids;
			}

			if (!self::is_enabled()) {
				self::release_lock($event_plan_id, 'meta_pause_all_event');
				return new WP_Error('api_disabled', __('Meta API is disabled in settings. Enable API mode first.', 'vms-meta-ads'), array('status' => 400));
			}

			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				self::release_lock($event_plan_id, 'meta_pause_all_event');
				return $settings;
			}

			$steps = array();
			$seen_ads = array();
			$ad_ids = !empty($ids['ad_ids']) && is_array($ids['ad_ids']) ? array_values((array) $ids['ad_ids']) : array((string) ($ids['ad_id'] ?? ''));
			foreach ($ad_ids as $index => $ad_variant_id) {
				$ad_variant_id = sanitize_text_field((string) $ad_variant_id);
				if ($ad_variant_id === '' || isset($seen_ads[$ad_variant_id])) {
					continue;
				}
				$seen_ads[$ad_variant_id] = true;
				$steps['ad_variant_' . ($index + 1)] = array('id' => $ad_variant_id, 'target' => self::STATUS_PAUSED);
			}
			$seen_adsets = array();
			$adset_ids = !empty($ids['adset_ids']) && is_array($ids['adset_ids']) ? array_values((array) $ids['adset_ids']) : array((string) ($ids['adset_id'] ?? ''));
			foreach ($adset_ids as $index => $adset_variant_id) {
				$adset_variant_id = sanitize_text_field((string) $adset_variant_id);
				if ($adset_variant_id === '' || isset($seen_adsets[$adset_variant_id])) {
					continue;
				}
				$seen_adsets[$adset_variant_id] = true;
				$steps['adset_' . ($index + 1)] = array('id' => $adset_variant_id, 'target' => self::STATUS_PAUSED);
			}
			$steps['campaign'] = array('id' => $ids['campaign_id'], 'target' => self::STATUS_PAUSED);
			$result = self::run_status_updates((int) ($build['id'] ?? 0), $steps, array('rollback_on_partial' => false));
			$refresh = self::build_status_snapshot($ids, $settings);
			$outcome = !empty($result['ok']) ? 'ok' : 'error';
			self::update_event_plan_after_action($event_plan_id, 'pause_all', $outcome, $refresh, $result, false);
			self::release_lock($event_plan_id, 'meta_pause_all_event');

			return array(
				'ok' => !empty($result['ok']),
				'result' => (array) ($result['result'] ?? array()),
				'rolled_back' => false,
				'message' => (string) ($result['message'] ?? ''),
				'updated_local' => self::current_local_time(),
				'campaign' => (array) ($refresh['campaign'] ?? self::unknown_status('')),
				'adset' => (array) ($refresh['adset'] ?? self::unknown_status('')),
				'adsets' => array_values(is_array($refresh['adsets'] ?? null) ? (array) $refresh['adsets'] : array()),
				'adset_count' => (int) ($refresh['adset_count'] ?? 0),
				'ad' => (array) ($refresh['ad'] ?? self::unknown_status('')),
				'ad_account_id' => (string) ($refresh['ad_account_id'] ?? ''),
				'open_in_meta_url' => (string) ($refresh['open_in_meta_url'] ?? ''),
				'ad_variants' => array_values(is_array($refresh['ad_variants'] ?? null) ? (array) $refresh['ad_variants'] : array()),
				'ad_variant_count' => (int) ($refresh['ad_variant_count'] ?? 0),
			);
		}


		public static function reset_meta_link(int $build_id)
		{
			if (!vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to reset Meta links.', 'vms-meta-ads'), array('status' => 403));
			}

			$build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
			if (is_wp_error($build)) {
				return $build;
			}

			$existing_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			$cleared = self::clear_existing_create_ids_for_recreate($build, $existing_ids, 'manual_reset_meta_link');
			if (is_wp_error($cleared)) {
				return $cleared;
			}

			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			if ($event_plan_id > 0) {
				self::update_event_plan_after_action($event_plan_id, 'refresh_status', 'ok', array(
					'campaign' => self::unknown_status(''),
					'adset' => self::unknown_status(''),
					'ad' => self::unknown_status(''),
					'ad_account_id' => '',
					'open_in_meta_url' => 'https://adsmanager.facebook.com/',
				), array('ok' => true, 'result' => array()), false);
			}

			return array(
				'ok' => true,
				'message' => __('Meta link reset. This Event Plan is no longer linked to saved Meta IDs. Reset Meta Link only removes the local references; it does not delete or archive any Meta campaign, ad set, ad, or creative objects.', 'vms-meta-ads'),
				'campaign' => self::unknown_status(''),
				'adset' => self::unknown_status(''),
				'ad' => self::unknown_status(''),
				'updated_local' => self::current_local_time(),
				'ad_account_id' => '',
				'open_in_meta_url' => 'https://adsmanager.facebook.com/',
				'ad_variants' => array(),
				'ad_variant_count' => 0,
			);
		}

		public static function refresh_status(int $event_plan_id, ?array $resolved_build = null)
		{
			if (!vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to refresh Meta status.', 'vms-meta-ads'), array('status' => 403));
			}

			$build = $resolved_build;
			if (!is_array($build)) {
				$build = self::resolve_build_by_event_plan($event_plan_id);
			}
			if (is_wp_error($build)) {
				return $build;
			}

			$ids = self::resolve_meta_ids($build);
			if (is_wp_error($ids)) {
				return $ids;
			}

			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$snapshot = self::build_status_snapshot($ids, $settings);
			self::update_event_plan_after_action($event_plan_id, 'refresh_status', 'ok', $snapshot, array('ok' => true, 'result' => array()), false);
			$adset_budget = self::fetch_adset_budget((string) $ids['adset_id'], $settings);
			$drift = self::build_drift_report((array) $build, $ids, $settings);
			$local_meta_status = self::derive_local_meta_status($snapshot, 'refresh_status', 'ok');
			$readiness = self::build_post_create_readiness($build, $ids, $snapshot, $settings);

			$message = __('Meta status refreshed.', 'vms-meta-ads');
			if ($ids['campaign_id'] !== '' && ($ids['adset_id'] === '' || $ids['ad_id'] === '')) {
				$message = __('Partial Meta link found. Campaign exists locally, but Ad Set and/or Ad IDs are still missing.', 'vms-meta-ads');
			}

			return array(
				'ok' => true,
				'message' => $message,
				'campaign' => (array) ($snapshot['campaign'] ?? self::unknown_status($ids['campaign_id'])),
				'adset' => (array) ($snapshot['adset'] ?? self::unknown_status($ids['adset_id'])),
				'adsets' => array_values(is_array($snapshot['adsets'] ?? null) ? (array) $snapshot['adsets'] : array()),
				'adset_count' => (int) ($snapshot['adset_count'] ?? 0),
				'ad' => (array) ($snapshot['ad'] ?? self::unknown_status($ids['ad_id'])),
				'updated_local' => self::current_local_time(),
				'local_meta_status' => $local_meta_status,
				'local_meta_label' => self::local_meta_status_label($local_meta_status),
				'readiness' => $readiness,
				'ad_account_id' => (string) ($snapshot['ad_account_id'] ?? ''),
				'open_in_meta_url' => (string) ($snapshot['open_in_meta_url'] ?? ''),
				'budget_sync' => self::build_budget_sync_state($build, $event_plan_id, is_wp_error($adset_budget) ? null : $adset_budget),
				'drift' => $drift,
				'ad_variants' => array_values(is_array($snapshot['ad_variants'] ?? null) ? (array) $snapshot['ad_variants'] : array()),
				'ad_variant_count' => (int) ($snapshot['ad_variant_count'] ?? 0),
			);
		}

		public static function refresh_status_for_build(int $build_id)
		{
			$resolved = self::resolve_event_from_build($build_id);
			if (is_wp_error($resolved)) {
				return $resolved;
			}
			return self::refresh_status((int) $resolved['event_plan_id'], (array) $resolved['build']);
		}

		public static function discover_existing_campaigns(int $event_plan_id, int $build_id = 0)
		{
			if (!vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to search Meta ads.', 'vms-meta-ads'), array('status' => 403));
			}
			if ($event_plan_id < 1) {
				return new WP_Error('invalid_event_plan', __('Choose an Event Plan before searching Meta.', 'vms-meta-ads'), array('status' => 400));
			}

			$event = class_exists('VMS_Meta_Ads_Event_Plans_Service') ? VMS_Meta_Ads_Event_Plans_Service::get_event_plan($event_plan_id) : null;
			if (!is_array($event)) {
				return new WP_Error('event_not_found', __('Event Plan could not be loaded for Meta discovery.', 'vms-meta-ads'), array('status' => 404));
			}

			$build = null;
			if ($build_id > 0) {
				$maybe_build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
				if (is_wp_error($maybe_build)) {
					return $maybe_build;
				}
				$build = (array) $maybe_build;
			}

			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$needles = self::build_discovery_needles($event, is_array($build) ? $build : array());
			$campaigns = self::fetch_recent_campaigns($settings);
			if (is_wp_error($campaigns)) {
				return $campaigns;
			}

			$candidates = array();
			foreach ($campaigns as $campaign) {
				if (!is_array($campaign)) {
					continue;
				}
				$campaign_score = self::score_meta_object_match((string) ($campaign['name'] ?? ''), $needles);
				if ($campaign_score < 8) {
					continue;
				}
				$adsets = self::fetch_campaign_adsets((string) ($campaign['id'] ?? ''), $settings);
				if (is_wp_error($adsets)) {
					continue;
				}
				foreach ($adsets as $adset) {
					if (!is_array($adset)) {
						continue;
					}
					$ads = self::fetch_adset_ads((string) ($adset['id'] ?? ''), $settings);
					if (is_wp_error($ads)) {
						$ads = array();
					}
					$score = $campaign_score + self::score_meta_object_match((string) ($adset['name'] ?? ''), $needles);
					$matched_urls = array();
					foreach ($ads as $ad) {
						if (!is_array($ad)) {
							continue;
						}
						$score += self::score_meta_object_match((string) ($ad['name'] ?? ''), $needles);
						$ad_url = self::extract_ad_destination_url($ad);
						if ($ad_url !== '') {
							$matched_urls[] = $ad_url;
							$score += self::score_url_match($ad_url, $needles);
						}
					}
					if ($score < 20) {
						continue;
					}
					$ad_ids = array();
					foreach ($ads as $ad) {
						if (is_array($ad) && !empty($ad['id'])) {
							$ad_ids[] = sanitize_text_field((string) $ad['id']);
						}
					}
					$ids = array(
						'campaign_id' => sanitize_text_field((string) ($campaign['id'] ?? '')),
						'adset_id' => sanitize_text_field((string) ($adset['id'] ?? '')),
						'ad_id' => (string) ($ad_ids[0] ?? ''),
						'ad_ids' => $ad_ids,
					);
					$candidate = array(
						'score' => min(100, (int) $score),
						'confidence' => self::format_discovery_confidence((int) $score),
						'campaign_id' => $ids['campaign_id'],
						'campaign_name' => sanitize_text_field((string) ($campaign['name'] ?? '')),
						'campaign_status' => sanitize_text_field((string) (($campaign['effective_status'] ?? '') ?: ($campaign['configured_status'] ?? ($campaign['status'] ?? 'UNKNOWN')))),
						'objective' => sanitize_text_field((string) ($campaign['objective'] ?? '')),
						'adset_id' => $ids['adset_id'],
						'adset_name' => sanitize_text_field((string) ($adset['name'] ?? '')),
						'adset_status' => sanitize_text_field((string) (($adset['effective_status'] ?? '') ?: ($adset['configured_status'] ?? 'UNKNOWN'))),
						'ad_ids' => $ad_ids,
						'ad_count' => count($ad_ids),
						'budget_minor' => absint(($adset['lifetime_budget'] ?? 0) ?: ($adset['daily_budget'] ?? 0)),
						'budget_type' => absint($adset['lifetime_budget'] ?? 0) > 0 ? 'lifetime' : (absint($adset['daily_budget'] ?? 0) > 0 ? 'daily' : ''),
						'start_time' => sanitize_text_field((string) ($adset['start_time'] ?? '')),
						'end_time' => sanitize_text_field((string) ($adset['end_time'] ?? '')),
						'audience_summary' => self::summarize_meta_targeting(is_array($adset['targeting'] ?? null) ? (array) $adset['targeting'] : array()),
						'matched_urls' => array_values(array_unique(array_filter(array_map('esc_url_raw', $matched_urls)))),
						'open_in_meta_url' => self::build_ads_manager_url((string) ($settings['meta_ad_account_id'] ?? '')),
						'ids' => $ids,
					);
					if (is_array($build)) {
						$candidate['drift'] = self::build_drift_report($build, $ids, $settings);
					}
					$candidates[] = $candidate;
				}
			}

			usort($candidates, static function ($a, $b): int {
				return ((int) ($b['score'] ?? 0)) <=> ((int) ($a['score'] ?? 0));
			});
			$candidates = array_slice($candidates, 0, 12);

			update_post_meta($event_plan_id, 'vms_ma_last_discovery_local', self::current_local_time());
			update_post_meta($event_plan_id, 'vms_ma_last_discovery_json', wp_json_encode(array(
				'count' => count($candidates),
				'needles' => $needles,
				'updated_local' => self::current_local_time(),
			)));

			return array(
				'ok' => true,
				'message' => count($candidates) ? __('Possible Meta campaigns found. Review before linking.', 'vms-meta-ads') : __('No likely Meta campaigns were found for this event.', 'vms-meta-ads'),
				'event_plan_id' => $event_plan_id,
				'build_id' => $build_id,
				'updated_local' => self::current_local_time(),
				'candidates' => $candidates,
				'ad_account_id' => ltrim((string) ($settings['meta_ad_account_id'] ?? ''), 'act_'),
				'open_in_meta_url' => self::build_ads_manager_url((string) ($settings['meta_ad_account_id'] ?? '')),
			);
		}

		public static function adopt_existing_bundle(int $build_id, array $payload)
		{
			if (!vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to link Meta ads.', 'vms-meta-ads'), array('status' => 403));
			}
			$build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
			if (is_wp_error($build)) {
				return $build;
			}
			if (empty($payload['confirm_adopt'])) {
				return new WP_Error('confirmation_required', __('Confirm that you want to link this saved build to the selected live Meta campaign.', 'vms-meta-ads'), array('status' => 400));
			}
			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$campaign_id = sanitize_text_field((string) ($payload['campaign_id'] ?? ''));
			$adset_id = sanitize_text_field((string) ($payload['adset_id'] ?? ''));
			$ad_ids = array_values(array_filter(array_map('sanitize_text_field', (array) ($payload['ad_ids'] ?? array()))));
			$ad_id = sanitize_text_field((string) ($payload['ad_id'] ?? ($ad_ids[0] ?? '')));
			if ($ad_id !== '' && !in_array($ad_id, $ad_ids, true)) {
				array_unshift($ad_ids, $ad_id);
			}
			if ($campaign_id === '' || $adset_id === '') {
				return new WP_Error('missing_meta_ids', __('Campaign and ad set IDs are required to link an existing Meta campaign.', 'vms-meta-ads'), array('status' => 400));
			}
			if (empty($ad_ids)) {
				$ads = self::fetch_adset_ads($adset_id, $settings);
				if (!is_wp_error($ads)) {
					foreach ($ads as $ad) {
						if (is_array($ad) && !empty($ad['id'])) {
							$ad_ids[] = sanitize_text_field((string) $ad['id']);
						}
					}
				}
			}
			$ad_ids = array_values(array_unique(array_filter($ad_ids)));
			$ad_id = (string) ($ad_ids[0] ?? $ad_id);

			$ids = array(
				'campaign_id' => $campaign_id,
				'adset_id' => $adset_id,
				'creative_id' => '',
				'ad_id' => $ad_id,
				'creative_ids' => array(),
				'ad_ids' => $ad_ids,
				'ad_variants_meta' => array(),
				'adoption_source' => 'existing_meta_campaign',
				'source_of_truth' => 'meta',
				'adopted_local' => self::current_local_time(),
			);
			$ids['adopted_summary'] = self::build_adoption_summary((array) $build, $ids, $settings, $payload);
			foreach ($ad_ids as $index => $existing_ad_id) {
				$ids['ad_variants_meta'][] = array(
					'variant_key' => 'v' . ($index + 1),
					'label' => 'Ad ' . ($index + 1),
					'ad_id' => $existing_ad_id,
					'creative_id' => '',
					'adset_id' => $adset_id,
				);
			}

			$snapshot = self::build_status_snapshot($ids, $settings);
			$any_active = self::snapshot_has_active_object($snapshot);
			$build_status = $any_active ? 'live' : 'meta_created_paused';
			$tier_status = $any_active ? self::STATUS_ACTIVE : self::STATUS_PAUSED;
			$persisted = self::persist_create_ids((array) $build, $ids, '', $build_status, $tier_status);
			if (is_wp_error($persisted)) {
				return $persisted;
			}

			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			if ($event_plan_id > 0) {
				update_post_meta($event_plan_id, 'vms_ma_meta_campaign_id', $campaign_id);
				update_post_meta($event_plan_id, 'vms_ma_meta_adset_id', $adset_id);
				update_post_meta($event_plan_id, 'vms_ma_meta_ad_id', $ad_id);
				update_post_meta($event_plan_id, 'vms_ma_meta_status', $any_active ? 'live' : 'paused');
				update_post_meta($event_plan_id, 'vms_ma_meta_last_status_snapshot_json', wp_json_encode(array_merge($snapshot, array('updated_local' => self::current_local_time()))));
				self::append_event_log($event_plan_id, array(
					'local_timestamp' => self::current_local_time(),
					'action' => 'adopt_existing_meta_campaign',
					'outcome' => 'ok',
					'adopted_ids' => $ids,
					'user_id' => get_current_user_id(),
				));
			}
			vms_ma_log('meta_existing_campaign_adopted', array('build_id' => $build_id, 'ids' => $ids), $build_id);

			if (class_exists('VMS_Meta_Ads_Prefill_Service') && $event_plan_id > 0) {
				VMS_Meta_Ads_Prefill_Service::flush_prefill_cache($event_plan_id);
			}

			$updated_build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
			if (!is_wp_error($updated_build)) {
				$persisted_meta_ids = is_array($updated_build['meta_ids'] ?? null) ? (array) $updated_build['meta_ids'] : array();
				if (trim((string) ($persisted_meta_ids['campaign_id'] ?? '')) === '' || trim((string) ($persisted_meta_ids['adset_id'] ?? '')) === '') {
					return new WP_Error('adoption_not_persisted', __('Meta campaign was found, but the link did not persist on the saved build. Nothing was changed in Meta; refresh and try again.', 'vms-meta-ads'), array('status' => 500));
				}
			}
			return array(
				'ok' => true,
				'message' => $any_active ? __('Existing active Meta campaign linked. Meta is now treated as the source of truth until you review drift.', 'vms-meta-ads') : __('Existing paused Meta campaign linked.', 'vms-meta-ads'),
				'build' => is_wp_error($updated_build) ? null : $updated_build,
				'ids' => $ids,
				'campaign' => (array) ($snapshot['campaign'] ?? self::unknown_status($campaign_id)),
				'adset' => (array) ($snapshot['adset'] ?? self::unknown_status($adset_id)),
				'ad' => (array) ($snapshot['ad'] ?? self::unknown_status($ad_id)),
				'ad_variants' => array_values(is_array($snapshot['ad_variants'] ?? null) ? (array) $snapshot['ad_variants'] : array()),
				'ad_variant_count' => (int) ($snapshot['ad_variant_count'] ?? 0),
				'drift' => self::build_drift_report((array) $build, $ids, $settings),
				'adopted_summary' => is_array($ids['adopted_summary'] ?? null) ? (array) $ids['adopted_summary'] : array(),
				'ad_account_id' => (string) ($snapshot['ad_account_id'] ?? ''),
				'open_in_meta_url' => (string) ($snapshot['open_in_meta_url'] ?? ''),
				'updated_local' => self::current_local_time(),
			);
		}

		public static function sync_budget_build(int $build_id, array $args = array())
		{
			if (!vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to sync Meta budgets.', 'vms-meta-ads'), array('status' => 403));
			}
			$resolved = self::resolve_event_from_build($build_id);
			if (is_wp_error($resolved)) {
				return $resolved;
			}
			return self::sync_budget_for_build((array) $resolved['build'], array_merge($args, array('event_plan_id' => (int) $resolved['event_plan_id'])));
		}


		public static function update_existing_build(int $build_id)
		{
			if (!vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to update Meta ads.', 'vms-meta-ads'), array('status' => 403));
			}
			$resolved = self::resolve_event_from_build($build_id);
			if (is_wp_error($resolved)) {
				return $resolved;
			}

			$build = (array) $resolved['build'];
			$event_plan_id = (int) $resolved['event_plan_id'];
			$lock = self::acquire_lock($build_id, 'meta_update');
			if (is_wp_error($lock)) {
				return $lock;
			}

			$preflight = self::preflight_create_paused($build);
			if (is_wp_error($preflight)) {
				self::release_lock($build_id, 'meta_update');
				return $preflight;
			}

			if (!empty($preflight['recipe_adsets']) && is_array($preflight['recipe_adsets'])) {
				self::release_lock($build_id, 'meta_update');
				return new WP_Error('multi_adset_update_not_supported', __('This clean-room recipe contains multiple ad sets. For this pass, create the recipe paused, review in Meta, and use Reset/Clone if you need a fresh replacement.', 'vms-meta-ads'), array('status' => 409));
			}

			$settings = (array) ($preflight['settings'] ?? array());
			$existing_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			$ids = self::resolve_meta_ids($build);
			if (is_wp_error($ids)) {
				self::release_lock($build_id, 'meta_update');
				return $ids;
			}
			if (empty($ids['adset_id'])) {
				self::release_lock($build_id, 'meta_update');
				return new WP_Error('missing_meta_ids', __('Create in Meta (PAUSED) first so there is an ad set to update.', 'vms-meta-ads'), array('status' => 409));
			}

			$variant_defs = self::build_variant_definitions_from_preflight((array) $preflight);
			$variant_rows = self::normalize_existing_variant_meta($existing_ids, $variant_defs);
			$raw_existing_variant_rows = !empty($existing_ids['ad_variants_meta']) && is_array($existing_ids['ad_variants_meta']) ? array_values((array) $existing_ids['ad_variants_meta']) : array();
			$has_any_ad = false;
			foreach ($variant_rows as $variant_row) {
				if (!empty($variant_row['ad_id'])) {
					$has_any_ad = true;
					break;
				}
			}
			if (!$has_any_ad && empty($ids['ad_id'])) {
				self::release_lock($build_id, 'meta_update');
				return new WP_Error('missing_meta_ids', __('Create in Meta (PAUSED) first so there is an ad to update.', 'vms-meta-ads'), array('status' => 409));
			}

			$warnings = !empty($preflight['warnings']) && is_array($preflight['warnings']) ? array_values($preflight['warnings']) : array();
			$result = array(
				'ok' => true,
				'changed' => true,
				'campaign' => self::empty_object_result(),
				'adset' => self::empty_object_result(),
				'creative' => self::empty_object_result(),
				'ad' => self::empty_object_result(),
				'ad_variants' => array(),
				'warnings' => $warnings,
			);

			$current_adset = self::fetch_adset_state((string) $ids['adset_id'], $settings);
			$adset_has_started = false;
			$adset_is_active = false;
			$adset_requires_replacement = false;
			$old_adset_id = (string) ($ids['adset_id'] ?? '');
			$old_variant_ad_ids = array_values(array_filter(array_map('sanitize_text_field', !empty($ids['ad_ids']) && is_array($ids['ad_ids']) ? (array) $ids['ad_ids'] : array())));
			if (empty($old_variant_ad_ids)) {
				foreach ($variant_rows as $variant_row) {
					$maybe_old_ad_id = sanitize_text_field((string) ($variant_row['ad_id'] ?? ''));
					if ($maybe_old_ad_id !== '') {
						$old_variant_ad_ids[] = $maybe_old_ad_id;
					}
				}
			}
			$old_variant_ad_ids = array_values(array_unique($old_variant_ad_ids));

			$adset_payload = array(
				'name' => (string) ($preflight['adset_name'] ?? 'Flat Run'),
				'end_time' => (string) ($preflight['end_time_iso8601'] ?? ''),
				'optimization_goal' => (string) ($preflight['optimization_goal'] ?? 'LINK_CLICKS'),
				'targeting' => wp_json_encode((array) ($preflight['targeting'] ?? array())),
			);
			if (!is_wp_error($current_adset)) {
				$current_start_time = (string) ($current_adset['start_time'] ?? '');
				$adset_has_started = self::has_meta_datetime_started($current_start_time);
				$current_effective = strtoupper((string) (($current_adset['effective_status'] ?? '') ?: ($current_adset['configured_status'] ?? 'UNKNOWN')));
				$adset_is_active = ($current_effective === self::STATUS_ACTIVE);
				$targeting_changed = self::targeting_payload_differs((array) ($current_adset['targeting'] ?? array()), (array) ($preflight['targeting'] ?? array()));
				$optimization_changed = strtoupper((string) ($current_adset['optimization_goal'] ?? '')) !== strtoupper((string) ($preflight['optimization_goal'] ?? ''));
				$adset_requires_replacement = $adset_has_started && ($targeting_changed || $optimization_changed);

				if ($adset_requires_replacement) {
					$result['warnings'][] = __('Audience or delivery settings changed on a started Meta ad set, so VMS created a replacement ad set to ensure Meta uses the latest targeting.', 'vms-meta-ads');
				} else {
					if (!$adset_has_started && !empty($preflight['start_time_iso8601'])) {
						$adset_payload['start_time'] = (string) $preflight['start_time_iso8601'];
					} elseif (!empty($preflight['start_time_iso8601'])) {
						$result['warnings'][] = __('Start time was left unchanged because this Meta ad set has already started.', 'vms-meta-ads');
					}

					$current_budget_minor = (int) ($current_adset['budget_minor'] ?? 0);
					$target_budget_minor = (int) ($preflight['lifetime_budget_minor'] ?? 0);
					$current_budget_field = (string) ($current_adset['field_name'] ?? '');
					$budget_changed = ($target_budget_minor > 0 && ($current_budget_field !== 'lifetime_budget' || $current_budget_minor !== $target_budget_minor));
					if ($budget_changed) {
						if ($adset_has_started) {
							$result['warnings'][] = __('Budget was left unchanged on the running Meta ad set. Use Sync Budget to Meta for budget-only changes after launch.', 'vms-meta-ads');
						} else {
							$adset_payload['lifetime_budget'] = (string) $target_budget_minor;
						}
					}
				}
			} elseif (!empty($preflight['start_time_iso8601'])) {
				$adset_payload['start_time'] = (string) $preflight['start_time_iso8601'];
				$adset_payload['lifetime_budget'] = (string) ((int) ($preflight['lifetime_budget_minor'] ?? 0));
			}

			if ($adset_requires_replacement) {
				$replacement_start = self::current_meta_time_iso8601($settings);
				$replacement_payload = self::build_replacement_adset_payload($preflight, (string) ($ids['campaign_id'] ?? ''), $replacement_start);
				$replacement_response = self::meta_post(
					$settings,
					VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/adsets',
					$replacement_payload,
					'create_replacement_adset',
					$build_id
				);
				if (is_wp_error($replacement_response)) {
					self::release_lock($build_id, 'meta_update');
					return self::wrap_step_error('Ad Set replacement', $replacement_response);
				}
				$new_adset_id = self::extract_created_id((array) $replacement_response, 'adset');
				if ($new_adset_id === '') {
					self::release_lock($build_id, 'meta_update');
					return new WP_Error('meta_adset_missing_id', __('Meta replacement ad set create returned no ID.', 'vms-meta-ads'), array('status' => 502));
				}
				$ids['adset_id'] = $new_adset_id;
				$result['adset'] = array(
					'id' => $new_adset_id,
					'attempted' => true,
					'changed' => true,
					'status' => 'REPLACED',
				);
			} else {
				$adset_response = self::meta_post($settings, (string) $ids['adset_id'], $adset_payload, 'update_adset', $build_id);
				if (is_wp_error($adset_response)) {
					self::release_lock($build_id, 'meta_update');
					return self::wrap_step_error('Ad Set update', $adset_response);
				}
				$result['adset'] = array(
					'id' => (string) $ids['adset_id'],
					'attempted' => true,
					'changed' => true,
					'status' => 'UPDATED',
				);
			}

			$shared_images = self::upload_creative_images_to_meta($settings, (array) ($preflight['creative_images'] ?? array()), $build_id);
			$updated_variant_rows = array();
			$creative_ids = array();
			$ad_ids = array();
			$first_creative_id = '';
			$first_ad_id = '';
			$aggregate_ad_changed = false;
			$current_ad_status = self::fetch_object_status((string) ($ids['ad_id'] ?? ''));
			$current_ad_effective = is_wp_error($current_ad_status) ? 'UNKNOWN' : strtoupper((string) (($current_ad_status['effective_status'] ?? '') ?: ($current_ad_status['configured_status'] ?? 'UNKNOWN')));

			foreach ($variant_defs as $index => $variant) {
				$variant = is_array($variant) ? $variant : array();
				$variant_meta = is_array($variant_rows[$index] ?? null) ? (array) $variant_rows[$index] : array();
				$variant_label = sanitize_text_field((string) ($variant['label'] ?? ($variant_meta['label'] ?? ('Variant ' . ($index + 1)))));
				$creative_response = self::create_creative_for_variant($settings, (array) $preflight, $variant, $shared_images, $build_id);
				if (is_wp_error($creative_response)) {
					self::release_lock($build_id, 'meta_update');
					return self::wrap_step_error($variant_label . ' creative update', $creative_response);
				}
				$new_creative_id = self::extract_created_id((array) $creative_response, 'creative');
				if ($new_creative_id === '') {
					self::release_lock($build_id, 'meta_update');
					return new WP_Error('meta_creative_missing_id', sprintf(__('%s creative update returned no creative ID.', 'vms-meta-ads'), $variant_label), array('status' => 502));
				}

				$ad_id = sanitize_text_field((string) ($variant_meta['ad_id'] ?? ''));
				$created_new_ad = false;
				$ad_name = sanitize_text_field((string) ($variant['ad_name'] ?? ($variant_label . ' Link')));
				if ($ad_id !== '' && !$adset_requires_replacement) {
					$update_payload = array(
						'name' => $ad_name,
						'creative' => wp_json_encode(array('creative_id' => $new_creative_id)),
					);
					$update_ad_response = self::meta_post($settings, $ad_id, $update_payload, 'update_ad', $build_id);
					if (is_wp_error($update_ad_response)) {
						$fallback_attempt = self::retry_ad_action_with_standard_creative(
							$settings,
							(array) $preflight,
							$variant,
							$shared_images,
							(string) $ids['adset_id'],
							$ad_name,
							$update_ad_response,
							$build_id,
							$ad_id
						);
						if (!empty($fallback_attempt['handled'])) {
							$update_ad_response = $fallback_attempt['response'] ?? $update_ad_response;
							if (!empty($fallback_attempt['creative_id'])) {
								$new_creative_id = sanitize_text_field((string) $fallback_attempt['creative_id']);
							}
							if (!empty($fallback_attempt['warning'])) {
								$result['warnings'][] = sanitize_text_field((string) $fallback_attempt['warning']);
							}
						}
					}
					if (is_wp_error($update_ad_response)) {
						self::release_lock($build_id, 'meta_update');
						return self::wrap_step_error($variant_label . ' ad update', $update_ad_response);
					}
				} else {
					$created_new_ad = true;
					$create_ad = self::create_ad_with_single_retry($settings, array('ad_name' => $ad_name), array(
						'adset_id' => (string) $ids['adset_id'],
						'creative_id' => $new_creative_id,
					), $build_id);
					$create_ad_response = $create_ad['response'] ?? null;
					if (is_wp_error($create_ad_response)) {
						$fallback_attempt = self::retry_ad_action_with_standard_creative(
							$settings,
							(array) $preflight,
							$variant,
							$shared_images,
							(string) $ids['adset_id'],
							$ad_name,
							$create_ad_response,
							$build_id
						);
						if (!empty($fallback_attempt['handled'])) {
							$create_ad_response = $fallback_attempt['response'] ?? $create_ad_response;
							if (!empty($fallback_attempt['creative_id'])) {
								$new_creative_id = sanitize_text_field((string) $fallback_attempt['creative_id']);
							}
							if (!empty($fallback_attempt['warning'])) {
								$result['warnings'][] = sanitize_text_field((string) $fallback_attempt['warning']);
							}
						}
					}
					if (is_wp_error($create_ad_response)) {
						self::release_lock($build_id, 'meta_update');
						return self::wrap_step_error($variant_label . ' ad create', $create_ad_response);
					}
					$ad_id = self::extract_created_id((array) $create_ad_response, 'ad');
					if ($ad_id === '') {
						self::release_lock($build_id, 'meta_update');
						return new WP_Error('meta_ad_missing_id', sprintf(__('%s ad update returned no ad ID.', 'vms-meta-ads'), $variant_label), array('status' => 502));
					}
					if ($current_ad_effective === self::STATUS_ACTIVE && !$adset_requires_replacement) {
						$result['warnings'][] = sprintf(__('%s was added as a new PAUSED ad. Review it before going live.', 'vms-meta-ads'), $variant_label);
					}
				}

				$creative_ids[] = $new_creative_id;
				$ad_ids[] = $ad_id;
				if ($first_creative_id === '') {
					$first_creative_id = $new_creative_id;
				}
				if ($first_ad_id === '') {
					$first_ad_id = $ad_id;
				}
				$updated_variant_rows[] = array(
					'variant_key' => sanitize_key((string) ($variant['variant_key'] ?? ($variant_meta['variant_key'] ?? ('v' . ($index + 1))))) ?: ('v' . ($index + 1)),
					'label' => $variant_label !== '' ? $variant_label : ('Variant ' . ($index + 1)),
					'creative_id' => $new_creative_id,
					'ad_id' => $ad_id,
				);
				$result['ad_variants'][] = array(
					'label' => $variant_label !== '' ? $variant_label : ('Variant ' . ($index + 1)),
					'creative_id' => $new_creative_id,
					'ad_id' => $ad_id,
					'changed' => true,
					'created_new_ad' => $created_new_ad,
				);
				$aggregate_ad_changed = true;
			}

			if ($adset_requires_replacement && $adset_is_active) {
				$activation_error = self::activate_replacement_bundle($settings, (string) ($ids['adset_id'] ?? ''), $ad_ids, $build_id);
				if (is_wp_error($activation_error)) {
					self::release_lock($build_id, 'meta_update');
					return self::wrap_step_error('Replacement activation', $activation_error);
				}
				self::pause_replaced_bundle($settings, $old_adset_id, $old_variant_ad_ids, $build_id);
				$result['warnings'][] = __('The previous Meta ad set and linked ads were paused after the replacement audience went live.', 'vms-meta-ads');
			} elseif ($adset_requires_replacement) {
				self::pause_replaced_bundle($settings, $old_adset_id, $old_variant_ad_ids, $build_id);
				$result['warnings'][] = __('The previous Meta ad set was paused and the replacement bundle was left paused to match the prior state.', 'vms-meta-ads');
			}

			if (count($raw_existing_variant_rows) > count($updated_variant_rows)) {
				$extra_count = count($raw_existing_variant_rows) - count($updated_variant_rows);
				if (!$adset_requires_replacement) {
					$result['warnings'][] = sprintf(_n('Meta still has %d extra linked ad variant that was left untouched.', 'Meta still has %d extra linked ad variants that were left untouched.', $extra_count, 'vms-meta-ads'), $extra_count);
				}
				for ($i = count($updated_variant_rows); $i < count($raw_existing_variant_rows); $i++) {
					$row = is_array($raw_existing_variant_rows[$i] ?? null) ? (array) $raw_existing_variant_rows[$i] : array();
					if (!empty($row) && !$adset_requires_replacement) {
						$updated_variant_rows[] = array(
							'variant_key' => sanitize_key((string) ($row['variant_key'] ?? ('v' . ($i + 1)))) ?: ('v' . ($i + 1)),
							'label' => sanitize_text_field((string) ($row['label'] ?? ('Variant ' . ($i + 1)))) ?: ('Variant ' . ($i + 1)),
							'creative_id' => sanitize_text_field((string) ($row['creative_id'] ?? '')),
							'ad_id' => sanitize_text_field((string) ($row['ad_id'] ?? '')),
						);
						if (!empty($row['creative_id'])) {
							$creative_ids[] = sanitize_text_field((string) $row['creative_id']);
						}
						if (!empty($row['ad_id'])) {
							$ad_ids[] = sanitize_text_field((string) $row['ad_id']);
						}
					}
				}
			}

			$ids['creative_id'] = $first_creative_id !== '' ? $first_creative_id : (string) ($ids['creative_id'] ?? '');
			$ids['ad_id'] = $first_ad_id !== '' ? $first_ad_id : (string) ($ids['ad_id'] ?? '');
			$ids['creative_ids'] = array_values(array_filter(array_unique(array_map('sanitize_text_field', $creative_ids))));
			$ids['ad_ids'] = array_values(array_filter(array_unique(array_map('sanitize_text_field', $ad_ids))));
			$ids['ad_variants_meta'] = $updated_variant_rows;
			$result['creative'] = array(
				'id' => (string) $ids['creative_id'],
				'attempted' => true,
				'changed' => !empty($ids['creative_ids']),
				'status' => 'UPDATED',
			);
			$result['ad'] = array(
				'id' => (string) $ids['ad_id'],
				'attempted' => true,
				'changed' => $aggregate_ad_changed,
				'status' => $adset_requires_replacement ? 'REPLACED' : 'UPDATED',
				'variant_count' => count($updated_variant_rows),
			);

			$persisted = self::persist_create_ids($build, $ids, '', 'meta_created', '');
			if (is_wp_error($persisted)) {
				self::release_lock($build_id, 'meta_update');
				return $persisted;
			}

			$snapshot = self::build_status_snapshot($ids, $settings);
			$adset_budget = self::fetch_adset_budget((string) $ids['adset_id'], $settings);
			self::update_event_plan_after_action($event_plan_id, 'update_existing', 'ok', $snapshot, array('ok' => true, 'result' => $result), false);
			self::release_lock($build_id, 'meta_update');

			$message = __('Linked Meta assets were updated from the latest saved draft.', 'vms-meta-ads');
			if ($adset_requires_replacement) {
				$message = __('Linked Meta assets were updated by replacing the running ad set with the latest saved audience and placements.', 'vms-meta-ads');
			} elseif (count($result['ad_variants']) > 1) {
				$message = sprintf(__('Linked Meta assets were updated from the latest saved draft across %d ad variants.', 'vms-meta-ads'), count($result['ad_variants']));
			}

			return array(
				'ok' => true,
				'changed' => true,
				'message' => $message,
				'campaign' => (array) ($snapshot['campaign'] ?? self::unknown_status((string) ($ids['campaign_id'] ?? ''))),
				'adset' => (array) ($snapshot['adset'] ?? self::unknown_status((string) ($ids['adset_id'] ?? ''))),
				'adsets' => array_values(is_array($snapshot['adsets'] ?? null) ? (array) $snapshot['adsets'] : array()),
				'adset_count' => (int) ($snapshot['adset_count'] ?? 0),
				'ad' => (array) ($snapshot['ad'] ?? self::unknown_status((string) ($ids['ad_id'] ?? ''))),
				'ad_variants' => array_values(is_array($snapshot['ad_variants'] ?? null) ? (array) $snapshot['ad_variants'] : array()),
				'ad_variant_count' => (int) ($snapshot['ad_variant_count'] ?? count($updated_variant_rows)),
				'ad_account_id' => (string) ($snapshot['ad_account_id'] ?? ''),
				'open_in_meta_url' => (string) ($snapshot['open_in_meta_url'] ?? ''),
				'budget_sync' => self::build_budget_sync_state($build, $event_plan_id, is_wp_error($adset_budget) ? null : $adset_budget),
				'updated_local' => self::current_local_time(),
				'warnings' => array_values(array_filter(array_map('sanitize_text_field', $result['warnings']))),
			);
		}


		private static function build_replacement_adset_payload(array $preflight, string $campaign_id, string $start_time_iso8601): array
		{
			$settings = is_array($preflight['settings'] ?? null) ? (array) $preflight['settings'] : array();
			$payload = array(
				'name' => (string) ($preflight['adset_name'] ?? 'Flat Run'),
				'campaign_id' => $campaign_id,
				'billing_event' => 'IMPRESSIONS',
				'optimization_goal' => (string) ($preflight['optimization_goal'] ?? 'LINK_CLICKS'),
				'bid_strategy' => 'LOWEST_COST_WITHOUT_CAP',
				'status' => self::STATUS_PAUSED,
				'lifetime_budget' => (string) ((int) ($preflight['lifetime_budget_minor'] ?? 0)),
				'end_time' => (string) ($preflight['end_time_iso8601'] ?? ''),
				'targeting' => wp_json_encode((array) ($preflight['targeting'] ?? array())),
			);
			if ($start_time_iso8601 !== '') {
				$payload['start_time'] = $start_time_iso8601;
			}
			return $payload + self::adset_dsa_payload($settings);
		}

		private static function current_meta_time_iso8601(array $settings = array()): string
		{
			try {
				$dt = new DateTimeImmutable('now', VMS_Meta_Ads_Utils::get_meta_account_timezone($settings));
			} catch (Exception $e) {
				$dt = new DateTimeImmutable('now', new DateTimeZone('UTC'));
			}
			return $dt->format('c');
		}

		private static function targeting_payload_differs(array $current_targeting, array $desired_targeting): bool
		{
			return self::targeting_compare_snapshot($current_targeting) !== self::targeting_compare_snapshot($desired_targeting);
		}

		private static function targeting_compare_snapshot(array $targeting): array
		{
			$geo = is_array($targeting['geo_locations'] ?? null) ? (array) $targeting['geo_locations'] : array();
			$custom_locations = array();
			foreach ((array) ($geo['custom_locations'] ?? array()) as $row) {
				if (!is_array($row)) {
					continue;
				}
				$custom_locations[] = array(
					'address_string' => sanitize_text_field((string) ($row['address_string'] ?? '')),
					'latitude' => isset($row['latitude']) ? (string) $row['latitude'] : '',
					'longitude' => isset($row['longitude']) ? (string) $row['longitude'] : '',
					'radius' => absint($row['radius'] ?? 0),
					'distance_unit' => sanitize_text_field((string) ($row['distance_unit'] ?? 'mile')),
					'country' => sanitize_text_field((string) ($row['country'] ?? '')),
				);
			}
			usort($custom_locations, static function ($a, $b) {
				return strcmp(wp_json_encode($a), wp_json_encode($b));
			});

			$zips = array();
			foreach ((array) ($geo['zips'] ?? array()) as $row) {
				if (!is_array($row)) {
					continue;
				}
				$zips[] = sanitize_text_field((string) ($row['key'] ?? ''));
			}
			sort($zips);

			$cities = array();
			foreach ((array) ($geo['cities'] ?? array()) as $row) {
				if (!is_array($row)) {
					continue;
				}
				$cities[] = sanitize_text_field((string) ($row['key'] ?? ''));
			}
			sort($cities);

			$interests = array();
			foreach ((array) ($targeting['flexible_spec'][0]['interests'] ?? array()) as $interest_row) {
				if (!is_array($interest_row)) {
					continue;
				}
				$interests[] = sanitize_text_field((string) ($interest_row['id'] ?? ''));
			}
			sort($interests);

			$publisher_platforms = array_values(array_filter(array_map('sanitize_text_field', (array) ($targeting['publisher_platforms'] ?? array()))));
			$facebook_positions = array_values(array_filter(array_map('sanitize_text_field', (array) ($targeting['facebook_positions'] ?? array()))));
			$instagram_positions = array_values(array_filter(array_map('sanitize_text_field', (array) ($targeting['instagram_positions'] ?? array()))));
			$device_platforms = array_values(array_filter(array_map('sanitize_text_field', (array) ($targeting['device_platforms'] ?? array()))));
			sort($publisher_platforms);
			sort($facebook_positions);
			sort($instagram_positions);
			sort($device_platforms);

			return array(
				'age_min' => absint($targeting['age_min'] ?? 0),
				'age_max' => absint($targeting['age_max'] ?? 0),
				'custom_locations' => $custom_locations,
				'zips' => $zips,
				'cities' => $cities,
				'interests' => $interests,
				'publisher_platforms' => $publisher_platforms,
				'facebook_positions' => $facebook_positions,
				'instagram_positions' => $instagram_positions,
				'device_platforms' => $device_platforms,
				'targeting_automation' => self::normalize_targeting_compare_value((array) ($targeting['targeting_automation'] ?? array())),
			);
		}

		private static function normalize_targeting_compare_value($value)
		{
			if (!is_array($value)) {
				return is_scalar($value) ? (string) $value : $value;
			}
			$normalized = array();
			foreach ($value as $key => $item) {
				$normalized[$key] = self::normalize_targeting_compare_value($item);
			}
			ksort($normalized);
			return $normalized;
		}

		private static function activate_replacement_bundle(array $settings, string $adset_id, array $ad_ids, int $build_id = 0)
		{
			$adset_id = trim($adset_id);
			if ($adset_id === '') {
				return new WP_Error('missing_adset_id', __('Replacement Meta ad set ID is missing.', 'vms-meta-ads'));
			}
			$activate_adset = self::meta_post($settings, $adset_id, array('status' => self::STATUS_ACTIVE), 'activate_replacement_adset', $build_id);
			if (is_wp_error($activate_adset)) {
				return $activate_adset;
			}
			$activated_ads = array();
			foreach ($ad_ids as $ad_id) {
				$ad_id = sanitize_text_field((string) $ad_id);
				if ($ad_id === '') {
					continue;
				}
				$activate_ad = self::meta_post($settings, $ad_id, array('status' => self::STATUS_ACTIVE), 'activate_replacement_ad', $build_id);
				if (is_wp_error($activate_ad)) {
					self::meta_post($settings, $adset_id, array('status' => self::STATUS_PAUSED), 'rollback_replacement_adset', $build_id);
					foreach ($activated_ads as $activated_ad_id) {
						self::meta_post($settings, $activated_ad_id, array('status' => self::STATUS_PAUSED), 'rollback_replacement_ad', $build_id);
					}
					return $activate_ad;
				}
				$activated_ads[] = $ad_id;
			}
			return array('ok' => true);
		}

		private static function pause_replaced_bundle(array $settings, string $adset_id, array $ad_ids, int $build_id = 0): void
		{
			$adset_id = trim($adset_id);
			if ($adset_id !== '') {
				self::meta_post($settings, $adset_id, array('status' => self::STATUS_PAUSED), 'pause_replaced_adset', $build_id);
			}
			foreach ($ad_ids as $ad_id) {
				$ad_id = sanitize_text_field((string) $ad_id);
				if ($ad_id !== '') {
					self::meta_post($settings, $ad_id, array('status' => self::STATUS_PAUSED), 'pause_replaced_ad', $build_id);
				}
			}
		}

		public static function run_scheduled_budget_syncs(): void
		{
			$event_plan_ids = get_posts(array(
				'post_type' => 'vms_event_plan',
				'post_status' => array('publish', 'future', 'draft', 'pending', 'private'),
				'fields' => 'ids',
				'posts_per_page' => -1,
				'meta_key' => 'vms_ma_auto_budget_sync_enabled',
				'meta_value' => '1',
				'orderby' => 'ID',
				'order' => 'ASC',
			));
			if (empty($event_plan_ids)) {
				return;
			}
			foreach ((array) $event_plan_ids as $event_plan_id) {
				$event_plan_id = (int) $event_plan_id;
				if ($event_plan_id < 1) {
					continue;
				}
				$build = self::resolve_build_by_event_plan($event_plan_id);
				if (is_wp_error($build)) {
					continue;
				}
				$budget = is_array($build['budget_payload'] ?? null) ? (array) $build['budget_payload'] : array();
				if (empty($budget['auto_sync_budget_enabled'])) {
					continue;
				}
				$result = self::sync_budget_for_build($build, array(
					'event_plan_id' => $event_plan_id,
					'source' => 'scheduled',
					'allow_no_permission' => true,
				));
				if (is_wp_error($result)) {
					vms_ma_log('error', array(
						'where' => 'scheduled_budget_sync',
						'event_plan_id' => $event_plan_id,
						'message' => $result->get_error_message(),
						'error' => true,
					), (int) ($build['id'] ?? 0));
				}
			}
		}

		private static function sync_budget_for_build(array $build, array $args = array())
		{
			$allow_no_permission = !empty($args['allow_no_permission']);
			if (!$allow_no_permission && !vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to sync Meta budgets.', 'vms-meta-ads'), array('status' => 403));
			}
			if (!self::is_enabled()) {
				return new WP_Error('api_disabled', __('Meta API is disabled in settings. Enable API mode first.', 'vms-meta-ads'), array('status' => 400));
			}

			$event_plan_id = (int) ($args['event_plan_id'] ?? ($build['event_plan_id'] ?? 0));
			$source = sanitize_key((string) ($args['source'] ?? 'manual'));
			$build_id = (int) ($build['id'] ?? 0);
			if ($build_id < 1 || $event_plan_id < 1) {
				return new WP_Error('invalid_build', __('A saved build linked to an Event Plan is required for budget sync.', 'vms-meta-ads'), array('status' => 400));
			}

			$lock = self::acquire_lock($event_plan_id, 'meta_budget_sync');
			if (is_wp_error($lock)) {
				return $lock;
			}

			$ids = self::resolve_meta_ids($build);
			if (is_wp_error($ids)) {
				self::release_lock($event_plan_id, 'meta_budget_sync');
				return $ids;
			}

			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				self::release_lock($event_plan_id, 'meta_budget_sync');
				return $settings;
			}

			$target = self::resolve_budget_sync_target($build);
			if (is_wp_error($target)) {
				self::release_lock($event_plan_id, 'meta_budget_sync');
				return $target;
			}

			$adset_budget = self::fetch_adset_budget((string) $ids['adset_id'], $settings);
			if (is_wp_error($adset_budget)) {
				self::release_lock($event_plan_id, 'meta_budget_sync');
				return $adset_budget;
			}

			$field_name = sanitize_key((string) ($adset_budget['field_name'] ?? ''));
			$current_minor = (int) ($adset_budget['budget_minor'] ?? 0);
			if ($field_name !== 'lifetime_budget') {
				self::release_lock($event_plan_id, 'meta_budget_sync');
				return new WP_Error('unsupported_budget_type', __('Budget sync currently supports plugin-created lifetime-budget ad sets only.', 'vms-meta-ads'), array('status' => 400));
			}

			$changed = false;
			$message = __('Meta budget already matched the saved draft budget.', 'vms-meta-ads');
			if ($current_minor !== (int) $target['budget_minor']) {
				$update = self::update_adset_budget((string) $ids['adset_id'], $field_name, (int) $target['budget_minor'], $settings, $build_id);
				if (is_wp_error($update)) {
					self::release_lock($event_plan_id, 'meta_budget_sync');
					return $update;
				}
				$changed = true;
				$message = ($source === 'scheduled')
					? __('Scheduled budget sync updated Meta to match the saved draft.', 'vms-meta-ads')
					: __('Meta budget updated to match the saved draft.', 'vms-meta-ads');
			}

			$refreshed_budget = self::fetch_adset_budget((string) $ids['adset_id'], $settings);
			$snapshot = self::build_status_snapshot($ids, $settings);
			$budget_sync = self::build_budget_sync_state($build, $event_plan_id, is_wp_error($refreshed_budget) ? null : $refreshed_budget, $message);

			update_post_meta($event_plan_id, 'vms_ma_meta_last_budget_sync_local', self::current_local_time());
			update_post_meta($event_plan_id, 'vms_ma_meta_last_budget_sync_json', wp_json_encode(array(
				'source' => $source,
				'changed' => $changed ? 1 : 0,
				'field_name' => $field_name,
				'before_minor' => $current_minor,
				'after_minor' => (int) ($budget_sync['meta_budget_minor'] ?? $current_minor),
				'draft_minor' => (int) ($budget_sync['draft_budget_minor'] ?? 0),
				'updated_local' => self::current_local_time(),
			)));

			self::append_event_log($event_plan_id, array(
				'local_timestamp' => self::current_local_time(),
				'action' => 'budget_sync',
				'outcome' => $changed ? 'ok' : 'noop',
				'source' => $source,
				'field_name' => $field_name,
				'before_minor' => $current_minor,
				'after_minor' => (int) ($budget_sync['meta_budget_minor'] ?? $current_minor),
				'draft_minor' => (int) ($budget_sync['draft_budget_minor'] ?? 0),
				'user_id' => $allow_no_permission ? 0 : get_current_user_id(),
			));

			self::release_lock($event_plan_id, 'meta_budget_sync');

			return array(
				'ok' => true,
				'changed' => $changed,
				'message' => $message,
				'updated_local' => self::current_local_time(),
				'campaign' => (array) ($snapshot['campaign'] ?? self::unknown_status($ids['campaign_id'])),
				'adset' => (array) ($snapshot['adset'] ?? self::unknown_status($ids['adset_id'])),
				'adsets' => array_values(is_array($snapshot['adsets'] ?? null) ? (array) $snapshot['adsets'] : array()),
				'adset_count' => (int) ($snapshot['adset_count'] ?? 0),
				'ad' => (array) ($snapshot['ad'] ?? self::unknown_status($ids['ad_id'])),
				'ad_account_id' => (string) ($snapshot['ad_account_id'] ?? ''),
				'open_in_meta_url' => (string) ($snapshot['open_in_meta_url'] ?? ''),
				'budget_sync' => $budget_sync,
				'ad_variants' => array_values(is_array($snapshot['ad_variants'] ?? null) ? (array) $snapshot['ad_variants'] : array()),
				'ad_variant_count' => (int) ($snapshot['ad_variant_count'] ?? 0),
			);
		}

		private static function validate_minimum_meta_budget_per_day(array $tier)
		{
			$budget_minor = absint($tier['budget_amount_minor'] ?? 0);
			if ($budget_minor < 1) {
				return new WP_Error('invalid_budget', __('Saved draft budget is invalid. Re-save the draft before syncing.', 'vms-meta-ads'), array('status' => 400));
			}

			$start_raw = sanitize_text_field((string) ($tier['start_time'] ?? ''));
			$end_raw = sanitize_text_field((string) ($tier['end_time'] ?? ''));
			if ($start_raw === '' || $end_raw === '') {
				return new WP_Error('invalid_schedule', __('Schedule dates are invalid. Save draft again before sending to Meta.', 'vms-meta-ads'), array('status' => 400));
			}

			try {
				$start = new DateTimeImmutable($start_raw, wp_timezone());
				$end = new DateTimeImmutable($end_raw, wp_timezone());
			} catch (Exception $e) {
				return new WP_Error('invalid_schedule', __('Schedule dates are invalid. Save draft again before sending to Meta.', 'vms-meta-ads'), array('status' => 400));
			}

			$seconds = max(0, $end->getTimestamp() - $start->getTimestamp());
			if ($seconds < 1) {
				return new WP_Error('invalid_schedule', __('Schedule dates are invalid. Save draft again before sending to Meta.', 'vms-meta-ads'), array('status' => 400));
			}

			$avg_daily_minor = ($budget_minor * DAY_IN_SECONDS) / $seconds;
			if ($avg_daily_minor < 100) {
				return new WP_Error('budget_below_meta_floor', __('Meta often rejects ad sets below about $1.00/day. Increase budget or shorten the run window, then save draft again.', 'vms-meta-ads'), array('status' => 400));
			}

			return true;
		}

		private static function resolve_budget_sync_target(array $build)
		{
			$tier = self::resolve_create_tier($build);
			if (is_wp_error($tier)) {
				return $tier;
			}
			$budget_check = self::validate_minimum_meta_budget_per_day($tier);
			if (is_wp_error($budget_check)) {
				return $budget_check;
			}
			$budget_minor = absint($tier['budget_amount_minor'] ?? 0);
			if ($budget_minor < 1) {
				$budget = is_array($build['budget_payload'] ?? null) ? (array) $build['budget_payload'] : array();
				$budget_minor = absint($budget['total_budget_minor'] ?? 0);
			}
			if ($budget_minor < 1) {
				return new WP_Error('invalid_budget', __('Saved draft budget is invalid. Re-save the draft before syncing.', 'vms-meta-ads'), array('status' => 400));
			}
			return array(
				'budget_minor' => $budget_minor,
				'field_name' => 'lifetime_budget',
			);
		}

		private static function fetch_adset_budget(string $adset_id, ?array $settings = null)
		{
			$state = self::fetch_adset_state($adset_id, $settings);
			if (is_wp_error($state)) {
				return $state;
			}
			return array(
				'id' => sanitize_text_field((string) ($state['id'] ?? $adset_id)),
				'name' => sanitize_text_field((string) ($state['name'] ?? '')),
				'field_name' => sanitize_text_field((string) ($state['field_name'] ?? '')),
				'budget_minor' => absint($state['budget_minor'] ?? 0),
				'daily_budget' => absint($state['daily_budget'] ?? 0),
				'lifetime_budget' => absint($state['lifetime_budget'] ?? 0),
				'start_time' => sanitize_text_field((string) ($state['start_time'] ?? '')),
				'end_time' => sanitize_text_field((string) ($state['end_time'] ?? '')),
				'configured_status' => sanitize_text_field((string) ($state['configured_status'] ?? 'UNKNOWN')),
				'effective_status' => sanitize_text_field((string) ($state['effective_status'] ?? 'UNKNOWN')),
			);
		}

		private static function fetch_adset_state(string $adset_id, ?array $settings = null)
		{
			$adset_id = trim($adset_id);
			if ($adset_id === '') {
				return new WP_Error('missing_adset_id', __('Meta ad set ID is missing.', 'vms-meta-ads'));
			}
			if ($settings === null) {
				$settings = self::connection_settings();
			}
			if (is_wp_error($settings)) {
				return $settings;
			}
			$full_fields = 'id,name,daily_budget,lifetime_budget,start_time,end_time,configured_status,effective_status,optimization_goal,targeting,promoted_object,issues_info,recommendations,dsa_beneficiary,dsa_payor';
			$fallback_fields = 'id,name,daily_budget,lifetime_budget,start_time,end_time,configured_status,effective_status,optimization_goal,targeting,promoted_object,issues_info';
			$response = self::meta_get_request(
				$settings,
				$adset_id,
				array('fields' => $full_fields),
				'fetch_adset_budget',
				'ad_builder'
			);
			if (is_wp_error($response)) {
				return new WP_Error('meta_budget_read_failed', __('Meta ad set budget could not be read.', 'vms-meta-ads'));
			}
			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if (self::should_retry_meta_get_without_optional_fields($code, $body, array('recommendations', 'dsa_beneficiary', 'dsa_payor'))) {
				$response = self::meta_get_request(
					$settings,
					$adset_id,
					array('fields' => $fallback_fields),
					'fetch_adset_budget_fallback',
					'ad_builder'
				);
				if (is_wp_error($response)) {
					return new WP_Error('meta_budget_read_failed', __('Meta ad set budget could not be read.', 'vms-meta-ads'));
				}
				$code = (int) wp_remote_retrieve_response_code($response);
				$body = json_decode((string) wp_remote_retrieve_body($response), true);
			}
			if ($code < 200 || $code >= 300 || !is_array($body) || isset($body['error'])) {
				$meta_error = self::extract_meta_error(is_array($body) ? $body : array(), $code);
				return new WP_Error('meta_budget_read_failed', sprintf(__('Meta ad set lookup failed: %s', 'vms-meta-ads'), $meta_error['message']));
			}
			$lifetime = absint($body['lifetime_budget'] ?? 0);
			$daily = absint($body['daily_budget'] ?? 0);
			$field_name = $lifetime > 0 ? 'lifetime_budget' : ($daily > 0 ? 'daily_budget' : '');
			$budget_minor = $lifetime > 0 ? $lifetime : $daily;
			return array(
				'id' => sanitize_text_field((string) ($body['id'] ?? $adset_id)),
				'name' => sanitize_text_field((string) ($body['name'] ?? '')),
				'field_name' => $field_name,
				'budget_minor' => $budget_minor,
				'daily_budget' => $daily,
				'lifetime_budget' => $lifetime,
				'start_time' => sanitize_text_field((string) ($body['start_time'] ?? '')),
				'end_time' => sanitize_text_field((string) ($body['end_time'] ?? '')),
				'configured_status' => sanitize_text_field((string) ($body['configured_status'] ?? 'UNKNOWN')),
				'effective_status' => sanitize_text_field((string) ($body['effective_status'] ?? 'UNKNOWN')),
				'optimization_goal' => sanitize_text_field((string) ($body['optimization_goal'] ?? '')),
				'targeting' => is_array($body['targeting'] ?? null) ? (array) $body['targeting'] : array(),
				'promoted_object' => is_array($body['promoted_object'] ?? null) ? (array) $body['promoted_object'] : array(),
				'issues_info' => isset($body['issues_info']) ? $body['issues_info'] : null,
				'recommendations' => is_array($body['recommendations'] ?? null) ? array_values((array) $body['recommendations']) : array(),
				'dsa_beneficiary' => sanitize_text_field((string) ($body['dsa_beneficiary'] ?? '')),
				'dsa_payor' => sanitize_text_field((string) ($body['dsa_payor'] ?? '')),
			);
		}

		private static function has_meta_datetime_started(string $meta_datetime): bool
		{
			$meta_datetime = trim($meta_datetime);
			if ($meta_datetime === '') {
				return false;
			}
			try {
				$start = new DateTimeImmutable($meta_datetime);
				$now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
			} catch (Exception $e) {
				return false;
			}
			return $start->getTimestamp() <= $now->getTimestamp();
		}

		private static function update_adset_budget(string $adset_id, string $field_name, int $budget_minor, array $settings, int $build_id = 0)
		{
			$adset_id = trim($adset_id);
			$field_name = sanitize_key($field_name);
			$budget_minor = absint($budget_minor);
			if ($adset_id === '' || $budget_minor < 1) {
				return new WP_Error('invalid_budget_update', __('Meta budget update is missing required values.', 'vms-meta-ads'));
			}
			if (!in_array($field_name, array('daily_budget', 'lifetime_budget'), true)) {
				return new WP_Error('invalid_budget_field', __('Meta budget field is invalid.', 'vms-meta-ads'));
			}
			$response = self::meta_post(
				$settings,
				$adset_id,
				array($field_name => (string) $budget_minor),
				'update_adset_budget',
				$build_id
			);
			if (is_wp_error($response)) {
				return new WP_Error('meta_budget_update_failed', $response->get_error_message(), $response->get_error_data());
			}
			return array('ok' => true);
		}

		private static function build_budget_sync_state(array $build, int $event_plan_id, ?array $adset_budget = null, string $message = ''): array
		{
			$budget = is_array($build['budget_payload'] ?? null) ? (array) $build['budget_payload'] : array();
			$target = self::resolve_budget_sync_target($build);
			$draft_budget_minor = is_wp_error($target) ? 0 : (int) ($target['budget_minor'] ?? 0);
			$meta_budget_minor = is_array($adset_budget) ? (int) ($adset_budget['budget_minor'] ?? 0) : null;
			$last_sync_local = sanitize_text_field((string) get_post_meta($event_plan_id, 'vms_ma_meta_last_budget_sync_local', true));
			return array(
				'auto_enabled' => !empty($budget['auto_sync_budget_enabled']) ? 1 : 0,
				'draft_budget_minor' => $draft_budget_minor,
				'meta_budget_minor' => $meta_budget_minor,
				'matches' => ($meta_budget_minor !== null) ? ((int) $meta_budget_minor === (int) $draft_budget_minor) : 0,
				'field_name' => is_array($adset_budget) ? (string) ($adset_budget['field_name'] ?? '') : '',
				'last_sync_local' => $last_sync_local,
				'message' => $message,
			);
		}

		public static function test_connection()
		{
			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$preflight = self::preflight_permissions($settings);
			if (is_wp_error($preflight)) {
				return $preflight;
			}

			$response = self::meta_get_request(
				$settings,
				VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint($settings['meta_ad_account_id']),
				array('fields' => 'id,name,timezone_name,timezone_offset_hours_utc'),
				'test_connection',
				'settings'
			);

			if (is_wp_error($response)) {
				vms_ma_log('error', array(
					'where' => 'test_connection',
					'message' => $response->get_error_message(),
					'response_code' => 0,
					'error' => true,
				));
				return new WP_Error('meta_connection_failed', __('Meta connection test failed before a response was received.', 'vms-meta-ads'), array(
					'details' => array(
						'type' => 'transport_error',
						'message' => $response->get_error_message(),
					),
				));
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || (is_array($body) && isset($body['error']))) {
				$meta_error = self::extract_meta_error($body, $code);
				vms_ma_log('error', array(
					'where' => 'test_connection',
					'response_code' => $code,
					'type' => $meta_error['type'],
					'code' => $meta_error['code'],
					'fbtrace_id' => $meta_error['fbtrace_id'],
					'message' => $meta_error['message'],
					'error' => true,
				));
				return new WP_Error(
					'meta_connection_failed',
					__('Meta rejected the connection test. Verify token and ad account permissions.', 'vms-meta-ads'),
					array('details' => $meta_error)
				);
			}

			$current = VMS_Meta_Ads_Utils::get_settings();
			$current['meta_last_test_ok_gmt'] = current_time('mysql', true);
			$detected_timezone = VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) ($body['timezone_name'] ?? ''));
			if ($detected_timezone !== '') {
				$current['meta_account_timezone_detected'] = $detected_timezone;
			}
			VMS_Meta_Ads_Utils::update_settings($current);

			vms_ma_log('meta_create_response', array('where' => 'test_connection', 'response_code' => $code));
			return array('ok' => true, 'code' => $code, 'timezone_name' => $detected_timezone);
		}

		public static function get_connection_status_snapshot(): array
		{
			global $wpdb;

			$settings = self::preview_connection_settings();
			$settings_with_token = self::status_settings_with_token($settings);
			$inventory = self::build_connection_status_inventory($settings_with_token);
			$warnings = array();
			$mismatch_warnings = array();

			$permissions = self::empty_connection_status_check();
			$ad_account = self::empty_connection_status_check();
			$page_lookup = self::empty_connection_status_check();
			$page_direct = self::empty_connection_status_check();
			$instagram = self::empty_connection_status_check();
			$pixel_lookup = self::empty_connection_status_check();

			if ($inventory['token_present']) {
				$permissions = self::run_connection_status_check(
					$settings_with_token,
					'me/permissions',
					array(),
					'readonly_status_permissions'
				);

				$has_account = $inventory['meta_ad_account_id'] !== '';
				$has_page = $inventory['meta_page_id'] !== '';
				$has_ig = $inventory['meta_ig_actor_id'] !== '';
				$has_pixel = $inventory['meta_pixel_id'] !== '';

				if ($has_account) {
					$ad_account = self::run_connection_status_check(
						$settings_with_token,
						VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint($inventory['meta_ad_account_id']),
						array('fields' => 'id,name,timezone_name,timezone_offset_hours_utc'),
						'readonly_status_ad_account'
					);
					$pixel_lookup = self::run_connection_status_check(
						$settings_with_token,
						VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint($inventory['meta_ad_account_id']) . '/adspixels',
						array('fields' => 'id,name', 'limit' => 200),
						'readonly_status_pixels'
					);
				}

				$page_lookup = self::run_connection_status_check(
					$settings_with_token,
					'me/accounts',
					array('fields' => 'id,name,link,username,instagram_business_account{id}', 'limit' => 100),
					'readonly_status_pages'
				);

				if ($has_page) {
					$page_direct = self::run_connection_status_check(
						$settings_with_token,
						$inventory['meta_page_id'],
						array('fields' => 'id,name,link,username,instagram_business_account{id}'),
						'readonly_status_page'
					);
				}

				if ($has_ig) {
					$instagram = self::run_connection_status_check(
						$settings_with_token,
						$inventory['meta_ig_actor_id'],
						array('fields' => 'id,username,name'),
						'readonly_status_instagram'
					);
				}
			} else {
				self::append_dry_run_message($warnings, __('No saved Meta access token is available for a read-only status check.', 'vms-meta-ads'));
			}

			$permission_summary = self::summarize_connection_status_permissions($permissions);
			if (!empty($permission_summary['non_blocking_missing'])) {
				self::append_dry_run_message($warnings, __('`pages_read_engagement` is not granted. That does not currently block this read-only status audit.', 'vms-meta-ads'));
			}
			foreach ((array) ($permission_summary['warnings'] ?? array()) as $warning) {
				self::append_dry_run_message($warnings, (string) $warning);
			}

			$ad_account_summary = self::summarize_connection_status_ad_account($inventory, $ad_account);
			$page_lookup_summary = self::summarize_connection_status_pages($inventory, $page_lookup);
			$page_direct_summary = self::summarize_connection_status_page($inventory, $page_direct);
			$instagram_summary = self::summarize_connection_status_instagram($inventory, $instagram);
			$pixel_summary = self::summarize_connection_status_pixel($inventory, $pixel_lookup);

			$page_match = is_array($page_lookup_summary['stored_page'] ?? null) ? (array) $page_lookup_summary['stored_page'] : array();
			if (!empty($page_lookup_summary['lookup_ok']) && empty($page_lookup_summary['stored_page_found']) && $inventory['meta_page_id'] !== '') {
				$mismatch_warnings[] = __('Stored Facebook Page ID was not found in `me/accounts` for this token.', 'vms-meta-ads');
			}
			if (!empty($page_match['ig_actor_id']) && $inventory['meta_ig_actor_id'] !== '' && (string) $page_match['ig_actor_id'] !== $inventory['meta_ig_actor_id']) {
				$mismatch_warnings[] = __('Stored Instagram account ID differs from the Instagram account connected to the stored Facebook Page.', 'vms-meta-ads');
			}
			if (!empty($page_direct_summary['connected_ig_actor_id']) && $inventory['meta_ig_actor_id'] !== '' && (string) $page_direct_summary['connected_ig_actor_id'] !== $inventory['meta_ig_actor_id']) {
				$mismatch_warnings[] = __('Stored Instagram account ID differs from the direct Facebook Page lookup response.', 'vms-meta-ads');
			}
			if (!empty($pixel_summary['lookup_ok']) && empty($pixel_summary['stored_pixel_found']) && $inventory['meta_pixel_id'] !== '') {
				$mismatch_warnings[] = __('Stored Pixel ID was not found under the stored ad account.', 'vms-meta-ads');
			}
			if ($inventory['meta_ad_account_id'] !== '' && empty($ad_account_summary['reachable'])) {
				$mismatch_warnings[] = __('Stored Meta ad account is not reachable with the saved token.', 'vms-meta-ads');
			}

			foreach ($mismatch_warnings as $warning) {
				self::append_dry_run_message($warnings, $warning);
			}

			$token = self::summarize_connection_status_token($inventory, $permissions, array(
				$ad_account,
				$page_lookup,
				$page_direct,
				$instagram,
				$pixel_lookup,
			));

			$latest_dry_run = $wpdb->get_row(
				"SELECT id, created_at, operation, method, endpoint, http_status FROM {$wpdb->prefix}vms_api_attempts WHERE operation = 'dry_run_bundle' ORDER BY id DESC LIMIT 1",
				ARRAY_A
			);

			$attempt_rows = function_exists('vms_api_attempt_get_recent')
				? (array) vms_api_attempt_get_recent('meta_ads', 12, 'connection_status')
				: array();
			$recent_attempts = array();
			foreach ($attempt_rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$recent_attempts[] = array(
					'id' => (int) ($row['id'] ?? 0),
					'created_at' => (string) ($row['created_at'] ?? ''),
					'operation' => (string) ($row['operation'] ?? ''),
					'method' => (string) ($row['method'] ?? ''),
					'endpoint' => (string) ($row['endpoint'] ?? ''),
					'http_status' => isset($row['http_status']) ? (int) $row['http_status'] : null,
					'error_code' => (string) ($row['error_code'] ?? ''),
					'error_message' => (string) ($row['error_message'] ?? ''),
				);
			}

			return array(
				'checked_local' => self::current_local_time(),
				'read_only' => true,
				'non_mutating' => true,
				'copy' => array(
					'intro' => __('This status check uses read-only Meta GET requests only. It does not update MAB settings, refresh tokens, or create Meta objects.', 'vms-meta-ads'),
					'test_connection_note' => __('Test Connection is separate and updates saved verification/timezone fields on success. Use this panel for safe audits.', 'vms-meta-ads'),
				),
				'summary' => self::build_connection_status_summary($inventory, $token, $ad_account_summary, $page_lookup_summary, $page_direct_summary, $instagram_summary, $pixel_summary, $permission_summary, $warnings),
				'inventory' => $inventory,
				'token' => $token,
				'permissions' => $permission_summary,
				'assets' => array(
					'ad_account' => $ad_account_summary,
					'page_lookup' => $page_lookup_summary,
					'page' => $page_direct_summary,
					'instagram' => $instagram_summary,
					'pixel' => $pixel_summary,
				),
				'mismatch_warnings' => array_values($mismatch_warnings),
				'warnings' => array_values($warnings),
				'last_local_dry_run' => is_array($latest_dry_run) ? $latest_dry_run : null,
				'recent_attempts' => $recent_attempts,
			);
		}

		public static function list_pages()
		{
			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$response = self::meta_get_request(
				$settings,
				'me/accounts',
				array(
					'fields' => 'id,name,instagram_business_account{id}',
					'limit' => 100,
				),
				'list_pages',
				'settings'
			);
			if (is_wp_error($response)) {
				return new WP_Error('meta_pages_lookup_failed', __('Could not load Pages from Meta.', 'vms-meta-ads'));
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || !is_array($body)) {
				return new WP_Error('meta_pages_lookup_failed', __('Meta rejected page lookup.', 'vms-meta-ads'));
			}
			if (isset($body['error'])) {
				$meta_error = self::extract_meta_error($body, $code);
				return new WP_Error('meta_pages_lookup_failed', $meta_error['message']);
			}

			$items = array();
			$data = isset($body['data']) && is_array($body['data']) ? $body['data'] : array();
			foreach ($data as $row) {
				$item = self::normalize_page_lookup_item(is_array($row) ? $row : array());
				if ($item === array()) {
					continue;
				}
				$items[] = $item;
			}

			return array('items' => $items);
		}

		public static function resolve_page_reference(string $page_ref)
		{
			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$reference = self::normalize_page_reference($page_ref);
			if ($reference === '') {
				return new WP_Error('meta_page_resolve_failed', __('Enter a Facebook Page URL, Page ID, or page username first.', 'vms-meta-ads'));
			}

			$response = self::meta_get_request(
				$settings,
				$reference,
				array('fields' => 'id,name,instagram_business_account{id}'),
				'resolve_page_reference',
				'settings'
			);
			if (is_wp_error($response)) {
				return new WP_Error('meta_page_resolve_failed', __('Could not load that Facebook Page from Meta.', 'vms-meta-ads'));
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || !is_array($body)) {
				return new WP_Error('meta_page_resolve_failed', __('Meta rejected that Facebook Page reference.', 'vms-meta-ads'));
			}
			if (isset($body['error'])) {
				$meta_error = self::extract_meta_error($body, $code);
				return new WP_Error('meta_page_resolve_failed', $meta_error['message']);
			}

			$item = self::normalize_page_lookup_item($body);
			if ($item === array()) {
				return new WP_Error('meta_page_resolve_failed', __('Meta found the Page lookup request, but did not return a usable Page ID.', 'vms-meta-ads'));
			}

			return array('item' => $item);
		}

		private static function normalize_page_lookup_item(array $row): array
		{
			$page_id = trim((string) ($row['id'] ?? ''));
			if ($page_id === '') {
				return array();
			}
			$ig_actor_id = '';
			if (!empty($row['instagram_business_account']) && is_array($row['instagram_business_account'])) {
				$ig_actor_id = trim((string) ($row['instagram_business_account']['id'] ?? ''));
			}
			return array(
				'id' => $page_id,
				'name' => sanitize_text_field((string) ($row['name'] ?? ('Page ' . $page_id))),
				'link' => esc_url_raw((string) ($row['link'] ?? '')),
				'username' => sanitize_text_field((string) ($row['username'] ?? '')),
				'ig_actor_id' => $ig_actor_id,
			);
		}

		private static function status_settings_with_token(array $settings): array
		{
			$settings['meta_ad_account_id'] = ltrim(trim((string) ($settings['meta_ad_account_id'] ?? '')), 'act_');
			$settings['token'] = VMS_Meta_Ads_Utils::decrypt_token((string) ($settings['meta_access_token_encrypted'] ?? ''));
			return $settings;
		}

		private static function empty_connection_status_check(): array
		{
			return array(
				'ok' => false,
				'http_status' => 0,
				'body' => null,
				'error' => null,
			);
		}

		private static function run_connection_status_check(array $settings, string $path, array $query, string $operation): array
		{
			$token = trim((string) ($settings['token'] ?? ''));
			if ($token === '') {
				return array(
					'ok' => false,
					'http_status' => 0,
					'body' => null,
					'error' => array(
						'type' => 'missing_token',
						'code' => 0,
						'subcode' => 0,
						'message' => __('Saved Meta token is missing.', 'vms-meta-ads'),
						'fbtrace_id' => '',
						'response_code' => 0,
					),
				);
			}

			$response = self::meta_get_request(
				$settings,
				$path,
				$query,
				$operation,
				'connection_status'
			);

			if (is_wp_error($response)) {
				return array(
					'ok' => false,
					'http_status' => 0,
					'body' => null,
					'error' => array(
						'type' => 'transport_error',
						'code' => 0,
						'subcode' => 0,
						'message' => $response->get_error_message(),
						'fbtrace_id' => '',
						'response_code' => 0,
					),
				);
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code >= 200 && $code < 300 && is_array($body) && !isset($body['error'])) {
				return array(
					'ok' => true,
					'http_status' => $code,
					'body' => $body,
					'error' => null,
				);
			}

			return array(
				'ok' => false,
				'http_status' => $code,
				'body' => is_array($body) ? $body : null,
				'error' => self::extract_meta_error($body, $code),
			);
		}

		private static function build_connection_status_inventory(array $settings): array
		{
			$token_present = trim((string) ($settings['token'] ?? '')) !== '';
			$last_verified_gmt = trim((string) ($settings['meta_last_test_ok_gmt'] ?? ''));
			$stored_page_url = esc_url_raw((string) ($settings['facebook_page_url'] ?? ''));

			return array(
				'connection_source' => sanitize_key((string) ($settings['_connection_source'] ?? 'mab_settings')),
				'meta_graph_version' => sanitize_text_field((string) ($settings['meta_graph_version'] ?? 'v24.0')),
				'meta_ad_account_id' => trim((string) ($settings['meta_ad_account_id'] ?? '')),
				'meta_page_id' => trim((string) ($settings['meta_page_id'] ?? '')),
				'meta_ig_actor_id' => trim((string) ($settings['meta_ig_actor_id'] ?? '')),
				'meta_pixel_id' => trim((string) ($settings['meta_pixel_id'] ?? '')),
				'facebook_page_url' => $stored_page_url,
				'facebook_page_slug' => self::extract_facebook_page_slug($stored_page_url),
				'meta_account_timezone' => VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) ($settings['meta_account_timezone'] ?? '')),
				'meta_account_timezone_detected' => VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) ($settings['meta_account_timezone_detected'] ?? '')),
				'meta_app_mode' => sanitize_key((string) ($settings['meta_app_mode'] ?? '')),
				'meta_app_mode_updated_gmt' => sanitize_text_field((string) ($settings['meta_app_mode_updated_gmt'] ?? '')),
				'meta_last_test_ok_gmt' => $last_verified_gmt,
				'meta_last_test_age_hours' => self::hours_since_gmt($last_verified_gmt),
				'token_present' => $token_present,
				'token_redacted' => $token_present ? __('Saved token present (redacted).', 'vms-meta-ads') : __('No saved token.', 'vms-meta-ads'),
				'token_fresh_within_24h' => self::dry_run_connection_fresh($settings),
				'enable_api_create' => !empty($settings['enable_api_create']) ? 1 : 0,
				'vms_ma_phase' => max(1, (int) ($settings['vms_ma_phase'] ?? 1)),
				'meta_ad_account_override' => !empty($settings['meta_ad_account_override']) ? 1 : 0,
			);
		}

		private static function summarize_connection_status_permissions(array $result): array
		{
			$relevant = array('ads_read', 'ads_management', 'pages_show_list', 'pages_read_engagement', 'business_management', 'instagram_basic');
			$granted = array();
			$other = array();
			$has_permission_payload = !empty($result['ok']) && !empty($result['body']['data']) && is_array($result['body']['data']);
			if ($has_permission_payload) {
				foreach ($result['body']['data'] as $item) {
					if (!is_array($item)) {
						continue;
					}
					$perm = sanitize_key((string) ($item['permission'] ?? ''));
					$status = sanitize_key((string) ($item['status'] ?? ''));
					if ($perm === '') {
						continue;
					}
					if ($status === 'granted') {
						$granted[] = $perm;
					} else {
						$other[] = $perm . ':' . $status;
					}
				}
			}
			sort($granted);
			sort($other);
			$missing = $has_permission_payload ? array_values(array_diff($relevant, $granted)) : array();
			$non_blocking = array_values(array_intersect($missing, array('pages_read_engagement')));
			$blocking = array_values(array_diff($missing, $non_blocking));

			$warnings = array();
			if (!empty($non_blocking)) {
				$warnings[] = __('`pages_read_engagement` is missing from granted permissions. That is visible here, but it is not currently blocking the read-only audit.', 'vms-meta-ads');
			}

			$state = 'ready';
			if (!empty($blocking) || empty($result['ok'])) {
				$state = 'error';
			} elseif (!empty($non_blocking)) {
				$state = 'warning';
			}

			return array(
				'state' => $state,
				'reachable' => !empty($result['ok']),
				'http_status' => (int) ($result['http_status'] ?? 0),
				'granted' => $granted,
				'missing_relevant' => $missing,
				'blocking_missing' => $blocking,
				'non_blocking_missing' => $non_blocking,
				'other_statuses' => $other,
				'error' => $result['error'] ?? null,
				'warnings' => $warnings,
			);
		}

		private static function summarize_connection_status_ad_account(array $inventory, array $result): array
		{
			$body = is_array($result['body'] ?? null) ? (array) $result['body'] : array();
			$reachable = !empty($result['ok']);
			return array(
				'state' => $reachable ? 'ready' : ($inventory['meta_ad_account_id'] !== '' ? 'error' : 'warning'),
				'stored_id' => $inventory['meta_ad_account_id'],
				'reachable' => $reachable,
				'lookup_ok' => $reachable,
				'resolved_id' => trim((string) ($body['id'] ?? '')),
				'resolved_name' => sanitize_text_field((string) ($body['name'] ?? '')),
				'timezone_name' => VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) ($body['timezone_name'] ?? '')),
				'timezone_offset_hours_utc' => $body['timezone_offset_hours_utc'] ?? null,
				'http_status' => (int) ($result['http_status'] ?? 0),
				'error' => $result['error'] ?? null,
			);
		}

		private static function summarize_connection_status_pages(array $inventory, array $result): array
		{
			$items = array();
			if (!empty($result['body']['data']) && is_array($result['body']['data'])) {
				foreach ($result['body']['data'] as $row) {
					$item = self::normalize_page_lookup_item(is_array($row) ? (array) $row : array());
					if ($item !== array()) {
						$items[] = $item;
					}
				}
			}
			$stored_page = array();
			foreach ($items as $item) {
				if ((string) ($item['id'] ?? '') === $inventory['meta_page_id']) {
					$stored_page = $item;
					break;
				}
			}
			return array(
				'state' => !empty($result['ok']) ? 'ready' : ($inventory['meta_page_id'] !== '' ? 'warning' : 'warning'),
				'lookup_ok' => !empty($result['ok']),
				'http_status' => (int) ($result['http_status'] ?? 0),
				'page_count' => count($items),
				'stored_page_found' => !empty($stored_page),
				'stored_page' => !empty($stored_page) ? $stored_page : null,
				'items' => $items,
				'error' => $result['error'] ?? null,
			);
		}

		private static function summarize_connection_status_page(array $inventory, array $result): array
		{
			$item = self::normalize_page_lookup_item(is_array($result['body'] ?? null) ? (array) $result['body'] : array());
			$reachable = !empty($result['ok']);
			$link = esc_url_raw((string) ($item['link'] ?? ''));
			$username = sanitize_text_field((string) ($item['username'] ?? ''));
			return array(
				'state' => $reachable ? 'ready' : ($inventory['meta_page_id'] !== '' ? 'error' : 'warning'),
				'stored_id' => $inventory['meta_page_id'],
				'reachable' => $reachable,
				'lookup_ok' => $reachable,
				'resolved_id' => (string) ($item['id'] ?? ''),
				'resolved_name' => sanitize_text_field((string) ($item['name'] ?? '')),
				'resolved_url' => $link,
				'resolved_slug' => $username !== '' ? $username : self::extract_facebook_page_slug($link),
				'connected_ig_actor_id' => (string) ($item['ig_actor_id'] ?? ''),
				'http_status' => (int) ($result['http_status'] ?? 0),
				'error' => $result['error'] ?? null,
			);
		}

		private static function summarize_connection_status_instagram(array $inventory, array $result): array
		{
			$body = is_array($result['body'] ?? null) ? (array) $result['body'] : array();
			$reachable = !empty($result['ok']);
			return array(
				'state' => $reachable ? 'ready' : ($inventory['meta_ig_actor_id'] !== '' ? 'warning' : 'warning'),
				'stored_id' => $inventory['meta_ig_actor_id'],
				'reachable' => $reachable,
				'lookup_ok' => $reachable,
				'resolved_id' => trim((string) ($body['id'] ?? '')),
				'username' => sanitize_text_field((string) ($body['username'] ?? '')),
				'name' => sanitize_text_field((string) ($body['name'] ?? '')),
				'http_status' => (int) ($result['http_status'] ?? 0),
				'error' => $result['error'] ?? null,
			);
		}

		private static function summarize_connection_status_pixel(array $inventory, array $result): array
		{
			$items = array();
			if (!empty($result['body']['data']) && is_array($result['body']['data'])) {
				foreach ($result['body']['data'] as $row) {
					if (!is_array($row)) {
						continue;
					}
					$pixel_id = trim((string) ($row['id'] ?? ''));
					if ($pixel_id === '') {
						continue;
					}
					$items[] = array(
						'id' => $pixel_id,
						'name' => sanitize_text_field((string) ($row['name'] ?? ('Pixel ' . $pixel_id))),
					);
				}
			}

			$stored_pixel = array();
			foreach ($items as $item) {
				if ((string) ($item['id'] ?? '') === $inventory['meta_pixel_id']) {
					$stored_pixel = $item;
					break;
				}
			}

			return array(
				'state' => !empty($result['ok']) ? (!empty($stored_pixel) || $inventory['meta_pixel_id'] === '' ? 'ready' : 'warning') : ($inventory['meta_pixel_id'] !== '' ? 'error' : 'warning'),
				'stored_id' => $inventory['meta_pixel_id'],
				'reachable' => !empty($result['ok']),
				'lookup_ok' => !empty($result['ok']),
				'pixel_count' => count($items),
				'stored_pixel_found' => !empty($stored_pixel),
				'stored_pixel' => !empty($stored_pixel) ? $stored_pixel : null,
				'items' => $items,
				'http_status' => (int) ($result['http_status'] ?? 0),
				'error' => $result['error'] ?? null,
			);
		}

		private static function summarize_connection_status_token(array $inventory, array $permissions, array $other_checks): array
		{
			$status = 'missing';
			$reason = __('No saved Meta access token is available.', 'vms-meta-ads');
			$state = 'error';

			if (!empty($inventory['token_present'])) {
				$status = 'unknown';
				$reason = __('Token presence is known locally, but read-only Meta checks could not confirm its status yet.', 'vms-meta-ads');
				$state = 'warning';

				$error = is_array($permissions['error'] ?? null) ? (array) $permissions['error'] : array();
				$error_code = (int) ($error['code'] ?? 0);
				$message = strtolower((string) ($error['message'] ?? ''));

				if (!empty($permissions['ok'])) {
					$status = 'valid';
					$reason = __('Read-only Meta permissions check succeeded with the saved token.', 'vms-meta-ads');
					$state = 'ready';
				} elseif ($error_code === 190) {
					$status = (strpos($message, 'expired') !== false || strpos($message, 'session has expired') !== false) ? 'expired' : 'invalid';
					$reason = (string) ($error['message'] ?? __('Meta rejected the saved token.', 'vms-meta-ads'));
					$state = 'error';
				} else {
					foreach ($other_checks as $check) {
						if (!is_array($check) || empty($check['ok'])) {
							continue;
						}
						$status = 'valid';
						$reason = __('At least one read-only Meta object check succeeded with the saved token.', 'vms-meta-ads');
						$state = 'ready';
						break;
					}
				}
			}

			return array(
				'state' => $state,
				'present' => !empty($inventory['token_present']),
				'status' => $status,
				'status_label' => ucfirst($status),
				'redacted' => (string) $inventory['token_redacted'],
				'last_verified_gmt' => (string) ($inventory['meta_last_test_ok_gmt'] ?? ''),
				'last_verified_age_hours' => $inventory['meta_last_test_age_hours'],
				'fresh_within_24h' => !empty($inventory['token_fresh_within_24h']),
				'reason' => $reason,
			);
		}

		private static function build_connection_status_summary(array $inventory, array $token, array $ad_account, array $page_lookup, array $page_direct, array $instagram, array $pixel, array $permissions, array $warnings): array
		{
			$state = 'ready';
			$label = __('Connected', 'vms-meta-ads');
			$reasons = array();

			if ($token['state'] === 'error' || $ad_account['state'] === 'error' || $page_direct['state'] === 'error') {
				$state = 'error';
				$label = __('Needs attention', 'vms-meta-ads');
			} elseif (
				$token['state'] === 'warning'
				|| $permissions['state'] === 'warning'
				|| $page_lookup['state'] === 'warning'
				|| $instagram['state'] === 'warning'
				|| $pixel['state'] === 'warning'
				|| !empty($warnings)
			) {
				$state = 'warning';
				$label = __('Review warnings', 'vms-meta-ads');
			}

			if ((int) $inventory['enable_api_create'] === 0) {
				$reasons[] = __('API create remains disabled.', 'vms-meta-ads');
			}
			if ((int) $inventory['vms_ma_phase'] === 1) {
				$reasons[] = __('MAB remains in phase 1 / no-spend mode.', 'vms-meta-ads');
			}
			if (!empty($warnings)) {
				$reasons[] = sprintf(_n('%d warning surfaced during the read-only check.', '%d warnings surfaced during the read-only check.', count($warnings), 'vms-meta-ads'), count($warnings));
			}

			return array(
				'state' => $state,
				'label' => $label,
				'note' => __('This panel uses read-only Meta GET checks only and does not update local settings or create Meta objects.', 'vms-meta-ads'),
				'reasons' => $reasons,
			);
		}

		private static function extract_facebook_page_slug(string $url): string
		{
			$url = trim($url);
			if ($url === '') {
				return '';
			}
			$parts = wp_parse_url($url);
			if (empty($parts['path'])) {
				return '';
			}
			$path = trim((string) $parts['path'], '/');
			if ($path === '' || $path === 'profile.php') {
				return '';
			}
			$segments = array_values(array_filter(explode('/', $path), 'strlen'));
			return !empty($segments) ? sanitize_title((string) $segments[0]) : '';
		}

		private static function hours_since_gmt(string $gmt): ?int
		{
			$gmt = trim($gmt);
			if ($gmt === '') {
				return null;
			}
			$timestamp = strtotime($gmt . ' UTC');
			if ($timestamp === false) {
				return null;
			}
			return max(0, (int) floor((time() - $timestamp) / HOUR_IN_SECONDS));
		}

		private static function normalize_page_reference(string $page_ref): string
		{
			$page_ref = trim(wp_strip_all_tags($page_ref));
			if ($page_ref === '') {
				return '';
			}

			if (preg_match('/^\d+$/', $page_ref)) {
				return $page_ref;
			}

			if (strpos($page_ref, 'facebook.com') !== false) {
				$parts = wp_parse_url($page_ref);
				if (empty($parts['host'])) {
					return '';
				}
				$path = trim((string) ($parts['path'] ?? ''), '/');
				if ($path === 'profile.php') {
					parse_str((string) ($parts['query'] ?? ''), $query_args);
					$profile_id = trim((string) ($query_args['id'] ?? ''));
					return preg_match('/^\d+$/', $profile_id) ? $profile_id : '';
				}
				$segments = array_values(array_filter(explode('/', $path)));
				if (empty($segments)) {
					return '';
				}
				$first = trim((string) ($segments[0] ?? ''));
				if ($first === '' || in_array($first, array('pages', 'pg', 'share', 'profile.php'), true)) {
					return '';
				}
				return sanitize_text_field($first);
			}

			return sanitize_text_field($page_ref);
		}

		private static function resolve_event_from_build(int $build_id)
		{
			$build = VMS_Meta_Ads_Builds_Service::get_build($build_id);
			if (is_wp_error($build)) {
				return $build;
			}
			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			if ($event_plan_id < 1) {
				return new WP_Error('missing_event_plan', __('This build is not linked to an Event Plan.', 'vms-meta-ads'), array('status' => 400));
			}
			return array('event_plan_id' => $event_plan_id, 'build' => $build);
		}

		private static function resolve_build_by_event_plan(int $event_plan_id)
		{
			if ($event_plan_id < 1) {
				return new WP_Error('invalid_event_plan', __('A valid Event Plan ID is required.', 'vms-meta-ads'), array('status' => 400));
			}
			$items = VMS_Meta_Ads_Builds_Service::list_builds(array(
				'event_plan_id' => $event_plan_id,
				'limit' => 1,
			));
			if (empty($items)) {
				return new WP_Error('missing_build', __('Save Draft first. No Meta Ads draft exists for this Event Plan yet.', 'vms-meta-ads'), array('status' => 400));
			}
			return (array) reset($items);
		}


		private static function validate_creative_lockdown_controls(array $build)
		{
			$copy = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
			$placements = is_array($build['placements_payload'] ?? null) ? (array) $build['placements_payload'] : array();
			$meta_controls = is_array($placements['meta_controls'] ?? null) ? (array) $placements['meta_controls'] : array();
			$policy = sanitize_key((string) (($meta_controls['creative_automation_policy'] ?? '') ?: ($copy['creative_automation_policy'] ?? 'off')));
			if ($policy === '') {
				$policy = 'off';
			}
			$multi_advertiser = !empty($meta_controls['multi_advertiser_ads']) || !empty($copy['multi_advertiser_ads']);
			$errors = array();
			if ($policy !== 'off') {
				$errors[] = __('Advantage+ creative policy must be Off / preserve creative.', 'vms-meta-ads');
			}
			if ($multi_advertiser) {
				$errors[] = __('Multi-advertiser ads must be Off.', 'vms-meta-ads');
			}
			if (!empty($errors)) {
				return new WP_Error(
					'creative_lockdown_required',
					sprintf(__('Creative Lockdown blocked this Meta action: %s Save the draft with lockdown settings before creating or publishing.', 'vms-meta-ads'), implode(' ', $errors)),
					array('status' => 400)
				);
			}
			return true;
		}

		private static function preflight_go_live(int $event_plan_id, array $build)
		{
			if (!vms_ma_current_user_can_manage()) {
				return new WP_Error('forbidden', __('You do not have permission to publish Meta ads.', 'vms-meta-ads'), array('status' => 403));
			}
			if (!self::is_enabled()) {
				return new WP_Error('api_disabled', __('Meta API is disabled in settings. Enable API mode first.', 'vms-meta-ads'), array('status' => 400));
			}
			$settings = VMS_Meta_Ads_Utils::get_settings();
			if ((int) ($settings['vms_ma_phase'] ?? 1) < 3) {
				return new WP_Error('phase_gated', __('Go Live is disabled until phase 3 is enabled.', 'vms-meta-ads'), array('status' => 400));
			}
			$dsa_readiness = self::validate_dsa_publish_readiness($settings);
			if (is_wp_error($dsa_readiness)) {
				return $dsa_readiness;
			}
			$connection_ok = self::connection_recent_or_readonly_verify();
			if (is_wp_error($connection_ok)) {
				return $connection_ok;
			}
			$settings = VMS_Meta_Ads_Utils::get_settings();

			$post = get_post($event_plan_id);
			if (!$post || $post->post_type !== 'vms_event_plan') {
				return new WP_Error('event_plan_not_found', __('Event Plan not found.', 'vms-meta-ads'), array('status' => 404));
			}
			if (!current_user_can('edit_post', $event_plan_id)) {
				return new WP_Error('cannot_edit_event_plan', __('You cannot edit this Event Plan.', 'vms-meta-ads'), array('status' => 403));
			}

			$ids = self::resolve_meta_ids($build);
			if (is_wp_error($ids)) {
				return $ids;
			}

			$creative_mode = sanitize_key((string) ($build['creative_mode'] ?? 'dark_post'));
			if ($creative_mode !== 'dark_post') {
				return new WP_Error('creative_mode_unsupported', __('Go Live currently supports Dark Post Link Ad only. Switch creative mode to Dark Post Link Ad.', 'vms-meta-ads'), array('status' => 400));
			}
			$lockdown_ok = self::validate_creative_lockdown_controls($build);
			if (is_wp_error($lockdown_ok)) {
				return $lockdown_ok;
			}

			$destination_url = esc_url_raw((string) ($build['destination_url'] ?? ''));
			if ($destination_url === '' || !wp_http_validate_url($destination_url)) {
				return new WP_Error('missing_destination_url', __('Destination URL is missing or invalid. Fix Step A and save draft.', 'vms-meta-ads'), array('status' => 400));
			}

			$budget = is_array($build['budget_payload'] ?? null) ? (array) $build['budget_payload'] : array();
			$total_budget_minor = absint($budget['total_budget_minor'] ?? 0);
			$max_lifetime = absint($settings['budget_max_lifetime_minor'] ?? 0);
			if ($total_budget_minor < 1 || ($max_lifetime > 0 && $total_budget_minor > $max_lifetime)) {
				return new WP_Error('invalid_budget', __('Budget is invalid for Go Live. Recheck Step E and save draft.', 'vms-meta-ads'), array('status' => 400));
			}

			$schedule = is_array($build['schedule_payload'] ?? null) ? (array) $build['schedule_payload'] : array();
			$event_start_raw = sanitize_text_field((string) ($schedule['event_start'] ?? ''));
			$preset = sanitize_key((string) ($schedule['preset_mode'] ?? 'flat_run'));
			$end_buffer_hours = max(0, absint($schedule['end_buffer_hours'] ?? 2));
			$end_time_raw = '';
			if (!empty($schedule['tiers']) && is_array($schedule['tiers'])) {
				foreach ((array) $schedule['tiers'] as $tier) {
					if (!is_array($tier)) {
						continue;
					}
					$candidate = sanitize_text_field((string) ($tier['end_time'] ?? ''));
					if ($candidate !== '' && $candidate > $end_time_raw) {
						$end_time_raw = $candidate;
					}
				}
			}
			if ($end_time_raw === '') {
				return new WP_Error('missing_schedule_end', __('Schedule end is missing. Recalculate Step E and save draft.', 'vms-meta-ads'), array('status' => 400));
			}
			$site_timezone = wp_timezone();
			$meta_timezone = VMS_Meta_Ads_Utils::get_meta_account_timezone($settings);
			try {
				$end_dt = (new DateTimeImmutable($end_time_raw, $site_timezone))->setTimezone($meta_timezone);
			} catch (Exception $e) {
				return new WP_Error('invalid_schedule_end', __('Schedule end time is invalid. Save draft again before Go Live.', 'vms-meta-ads'), array('status' => 400));
			}
			$now = new DateTimeImmutable('now', $meta_timezone);
			if ($end_dt <= $now) {
				return new WP_Error('schedule_elapsed', __('Schedule already ended. Update schedule end before Go Live.', 'vms-meta-ads'), array('status' => 400));
			}

			if ($preset !== 'manual_dates' && $event_start_raw !== '') {
				try {
					$event_start_dt = (new DateTimeImmutable($event_start_raw, $site_timezone))->setTimezone($meta_timezone);
					$expected_end = $event_start_dt->sub(new DateInterval('PT' . $end_buffer_hours . 'H'));
					$delta = abs($expected_end->getTimestamp() - $end_dt->getTimestamp());
					if ($delta > 300) {
						return new WP_Error('schedule_end_mismatch', __('Schedule end no longer matches Event Start minus end buffer. Recompute schedule in Step E and save draft.', 'vms-meta-ads'), array('status' => 400));
					}
				} catch (Exception $e) {
					return new WP_Error('invalid_event_start', __('Event start time is invalid. Re-open Event Plan and save draft again.', 'vms-meta-ads'), array('status' => 400));
				}
			}

			return array('ok' => true, 'ids' => $ids);
		}

		private static function preflight_create_paused(array $build)
		{
			if (!self::is_enabled()) {
				return new WP_Error('api_disabled', __('Meta API is disabled in settings. Enable API mode first.', 'vms-meta-ads'), array('status' => 400));
			}
			$connection_ok = self::connection_recent_or_readonly_verify();
			if (is_wp_error($connection_ok)) {
				return $connection_ok;
			}
			$settings = VMS_Meta_Ads_Utils::get_settings();

			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			$build_id = max(0, (int) ($build['id'] ?? 0));
			if ($event_plan_id < 1) {
				return new WP_Error('missing_event_plan', __('Save Draft first. This build is not linked to an Event Plan.', 'vms-meta-ads'), array('status' => 400));
			}
			$post = get_post($event_plan_id);
			if (!$post || $post->post_type !== 'vms_event_plan') {
				return new WP_Error('event_plan_not_found', __('Event Plan not found.', 'vms-meta-ads'), array('status' => 404));
			}
			if (!current_user_can('edit_post', $event_plan_id)) {
				return new WP_Error('cannot_edit_event_plan', __('You cannot edit this Event Plan.', 'vms-meta-ads'), array('status' => 403));
			}

			$creative_mode = sanitize_key((string) ($build['creative_mode'] ?? 'dark_post'));
			if ($creative_mode !== 'dark_post') {
				return new WP_Error('creative_mode_unsupported', __('Create in Meta currently supports Dark Post Link Ad only.', 'vms-meta-ads'), array('status' => 400));
			}
			$lockdown_ok = self::validate_creative_lockdown_controls($build);
			if (is_wp_error($lockdown_ok)) {
				return $lockdown_ok;
			}

			$schedule_support = self::resolve_schedule_create_support($build);
			$preset = (string) ($schedule_support['preset'] ?? 'flat_run');
			if (empty($schedule_support['supported'])) {
				return new WP_Error('preset_unsupported', (string) ($schedule_support['create_message'] ?? __('Direct Meta create/update currently supports a single schedule window only. Switch Step B to Flat run, save draft, then create in Meta.', 'vms-meta-ads')), array('status' => 400));
			}
			$tier = self::resolve_create_tier($build);
			if (is_wp_error($tier)) {
				return $tier;
			}
			$tier_label = sanitize_text_field((string) ($tier['tier_label'] ?? ($schedule_support['tier_label'] ?? self::schedule_preset_label($preset))));
			if ($tier_label === '') {
				$tier_label = self::schedule_preset_label($preset);
			}

			$site_timezone = wp_timezone();
			$meta_timezone = VMS_Meta_Ads_Utils::get_meta_account_timezone($settings);
			$start_iso = self::to_meta_iso8601((string) ($tier['start_time'] ?? ''), $settings);
			$end_iso = self::to_meta_iso8601((string) ($tier['end_time'] ?? ''), $settings);
			if ($start_iso === '' || $end_iso === '') {
				return new WP_Error('invalid_schedule', __('Schedule dates are invalid. Save draft again before creating in Meta.', 'vms-meta-ads'), array('status' => 400));
			}
			try {
				$end_dt = (new DateTimeImmutable((string) ($tier['end_time'] ?? ''), $site_timezone))->setTimezone($meta_timezone);
				$now = new DateTimeImmutable('now', $meta_timezone);
				if ($end_dt <= $now) {
					return new WP_Error('schedule_elapsed', __('Schedule already ended. Update schedule in Step E and save draft.', 'vms-meta-ads'), array('status' => 400));
				}
			} catch (Exception $e) {
				return new WP_Error('invalid_schedule', __('Schedule dates are invalid. Save draft again before creating in Meta.', 'vms-meta-ads'), array('status' => 400));
			}

			$destination_url = esc_url_raw((string) ($build['utm_url'] ?? $build['destination_url'] ?? ''));
			if ($destination_url === '' || !wp_http_validate_url($destination_url)) {
				return new WP_Error('missing_destination_url', __('Destination URL is missing or invalid. Fix Step A and save draft.', 'vms-meta-ads'), array('status' => 400));
			}

			$lifetime_budget_minor = absint($tier['budget_amount_minor'] ?? 0);
			$max_lifetime = absint($settings['budget_max_lifetime_minor'] ?? 0);
			if ($lifetime_budget_minor < 1 || ($max_lifetime > 0 && $lifetime_budget_minor > $max_lifetime)) {
				return new WP_Error('invalid_budget', __('Budget is invalid for Create in Meta. Recheck Step E and save draft.', 'vms-meta-ads'), array('status' => 400));
			}
			$budget_floor_check = self::validate_minimum_meta_budget_per_day($tier);
			if (is_wp_error($budget_floor_check)) {
				return $budget_floor_check;
			}

			$connection = self::connection_settings();
			if (is_wp_error($connection)) {
				return $connection;
			}
			$page_id = trim((string) ($connection['meta_page_id'] ?? ''));
			if ($page_id === '') {
				return new WP_Error('missing_page_id', __('Page ID is missing. Open Settings and set Meta Page ID before creating.', 'vms-meta-ads'), array('status' => 400));
			}

			$copy = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
			$ad_variants = self::resolve_copy_ad_variants($copy, $event_plan_id);
			$first_variant = is_array($ad_variants[0] ?? null) ? (array) $ad_variants[0] : array();
			$primary_text = sanitize_textarea_field((string) (($first_variant['primary_text'] ?? ($copy['primary_text_variants'][0] ?? '')) ?: ''));
			$headline = sanitize_text_field((string) (($first_variant['headline'] ?? ($copy['headline_variants'][0] ?? '')) ?: ''));
			$description = sanitize_text_field((string) (($first_variant['description'] ?? ($copy['description_variants'][0] ?? '')) ?: ''));
			if ($description === '') {
				$description = __('Tickets available now.', 'vms-meta-ads');
			}
			$cta_type = self::map_meta_link_cta((string) ($copy['cta_suggestion'] ?? 'LEARN_MORE'), $destination_url);
			$resolved_creative_assets = self::resolve_creative_image_assets($build);
			if ($headline === '') {
				$headline = __('Get Tickets', 'vms-meta-ads');
			}
			if ($description === '') {
				$venue_name = sanitize_text_field((string) ($copy['venue_name'] ?? ''));
				$description = $venue_name !== '' ? sprintf(__('Live at %s', 'vms-meta-ads'), $venue_name) : __('Tickets available now', 'vms-meta-ads');
			}
			$campaign_name = sanitize_text_field((string) (($copy['campaign_name'] ?? '') ?: ('Event Plan ' . $event_plan_id . ' — ' . $tier_label)));
			$ad_name = sanitize_text_field((string) (($first_variant['ad_name'] ?? ($copy['ad_names'][0] ?? '')) ?: 'Link — Link Clicks'));
			$targeting_payload = is_array($build['targeting_payload'] ?? null) ? (array) $build['targeting_payload'] : array();
			$placements_payload = is_array($build['placements_payload'] ?? null) ? (array) $build['placements_payload'] : array();
			$meta_controls = is_array($placements_payload['meta_controls'] ?? null) ? (array) $placements_payload['meta_controls'] : array();
			$allow_multi_advertiser_ads = !empty($copy['multi_advertiser_ads']) || !empty($meta_controls['multi_advertiser_ads']);
			$ig_actor_id = trim((string) ($connection['meta_ig_actor_id'] ?? ''));
			$placement_resolution = self::resolve_effective_placements_for_create($placements_payload, $ig_actor_id);
			if (is_wp_error($placement_resolution)) {
				return $placement_resolution;
			}
			$effective_placements_payload = (array) ($placement_resolution['placements_payload'] ?? $placements_payload);
			$warnings = !empty($placement_resolution['warnings']) && is_array($placement_resolution['warnings']) ? array_values($placement_resolution['warnings']) : array();
			foreach ((array) (self::dsa_readiness($connection)['warnings'] ?? array()) as $warning) {
				$warnings[] = (string) $warning;
			}
			foreach ($ad_variants as $variant_for_warning) {
				if ((string) ($variant_for_warning['media_mode'] ?? 'shared') === 'video_placeholder') {
					$warnings[] = __('One or more variants are marked as Meta-direct video placeholders. The plugin will create those ads with the selected/shared placeholder image; upload or swap the actual video directly in Meta Ads Manager before going live.', 'vms-meta-ads');
					break;
				}
			}
			$targeting = self::build_manual_targeting($settings, $targeting_payload, $effective_placements_payload, $build_id, $event_plan_id);
			if (is_wp_error($targeting)) {
				return $targeting;
			}
			$optimization = self::resolve_build_optimization($build);
			$goal = sanitize_key((string) ($build['goal'] ?? 'traffic'));
			$objective = sanitize_text_field((string) ($build['objective_meta'] ?? 'OUTCOME_TRAFFIC'));
			if ($goal === 'sales') {
				$objective = 'OUTCOME_SALES';
			}
			$promoted_object = self::build_promoted_object_for_goal($goal, $objective, $connection);
			if (is_wp_error($promoted_object)) {
				return $promoted_object;
			}

			$preflight = array(
				'settings' => $connection,
				'goal' => $goal,
				'objective' => $objective,
				'optimization_goal' => self::map_optimization_goal($optimization),
				'promoted_object' => is_array($promoted_object) ? $promoted_object : array(),
				'lifetime_budget_minor' => $lifetime_budget_minor,
				'start_time_iso8601' => $start_iso,
				'end_time_iso8601' => $end_iso,
				'site_timezone' => VMS_Meta_Ads_Utils::get_site_timezone_name(),
				'meta_account_timezone' => $meta_timezone->getName(),
				'allow_multi_advertiser_ads' => $allow_multi_advertiser_ads ? 1 : 0,
				'targeting' => $targeting,
				'destination_url' => $destination_url,
				'page_id' => $page_id,
				'ig_actor_id' => $ig_actor_id,
				'campaign_name' => $campaign_name,
				'adset_name' => $tier_label . ' — ' . self::summarize_targeting($targeting_payload),
				'creative_name' => $ad_name . ' Creative',
				'ad_name' => $ad_name,
				'primary_text' => $primary_text,
				'headline' => $headline !== '' ? $headline : __('Get Tickets', 'vms-meta-ads'),
				'description' => $description,
				'cta_type' => $cta_type,
				'creative_images' => $resolved_creative_assets,
				'effective_placements_payload' => $effective_placements_payload,
				'ad_variants' => $ad_variants,
				'warnings' => $warnings,
			);

			$recipe_payload = is_array($copy['campaign_recipe_payload'] ?? null) ? (array) $copy['campaign_recipe_payload'] : array();
			$recipe_key = sanitize_key((string) ($recipe_payload['recipe_key'] ?? ''));
			if (in_array($recipe_key, array('clean_room_full_push', 'clean_room_full_push_v2'), true)) {
				$recipe_adsets = self::build_clean_room_recipe_preflights($preflight, $recipe_payload, $settings, $build_id, $event_plan_id);
				if (is_wp_error($recipe_adsets)) {
					return $recipe_adsets;
				}
				$preflight['recipe_key'] = $recipe_key;
				$preflight['recipe_adsets'] = $recipe_adsets;
			}

			return $preflight;
		}


		private static function build_clean_room_recipe_preflights(array $base_preflight, array $recipe_payload, array $settings, int $build_id, int $event_plan_id)
		{
			$enabled_adset_count = absint($recipe_payload['enabled_adset_count'] ?? 0);
			if ($enabled_adset_count < 1) {
				return new WP_Error('recipe_no_enabled_adsets', __('Enable at least one clean-room ad set, save the draft again, and then retry Meta create.', 'vms-meta-ads'), array('status' => 400));
			}
			if (array_key_exists('allocation_valid', $recipe_payload) && empty($recipe_payload['allocation_valid'])) {
				$total_percent = round((float) ($recipe_payload['allocation_total_percent'] ?? 0), 2);
				return new WP_Error('recipe_invalid_allocation_total', sprintf(__('Enabled clean-room ad set allocations must total 100%% before Meta create can run. Current enabled total: %s%%. Save the draft again after fixing the split.', 'vms-meta-ads'), $total_percent), array('status' => 400));
			}
			$adsets = !empty($recipe_payload['adsets']) && is_array($recipe_payload['adsets']) ? array_values((array) $recipe_payload['adsets']) : array();
			if (empty($adsets)) {
				return new WP_Error('missing_recipe_adsets', __('Clean-room recipe is missing ad-set definitions. Save draft again.', 'vms-meta-ads'), array('status' => 400));
			}
			$out = array();
			$all_variants = !empty($base_preflight['ad_variants']) && is_array($base_preflight['ad_variants']) ? array_values((array) $base_preflight['ad_variants']) : self::build_variant_definitions_from_preflight($base_preflight);
			foreach ($adsets as $index => $adset) {
				if (!is_array($adset)) {
					continue;
				}
				$key = sanitize_key((string) ($adset['key'] ?? ('adset_' . ($index + 1)))) ?: ('adset_' . ($index + 1));
				$label = sanitize_text_field((string) ($adset['label'] ?? ('Ad Set ' . ($index + 1))));
				$adset_budget = max(0, absint($adset['budget_amount_minor'] ?? 0));
				$adset_budget_floor = self::validate_minimum_meta_budget_per_day(array(
					'budget_amount_minor' => $adset_budget,
					'start_time' => (string) ($base_preflight['start_time_iso8601'] ?? ''),
					'end_time' => (string) ($base_preflight['end_time_iso8601'] ?? ''),
				));
				if (is_wp_error($adset_budget_floor)) {
					return new WP_Error(
						'recipe_adset_budget_too_low',
						sprintf(__('Clean-room recipe budget for %1$s is only %2$s. Increase total budget, shorten the run window, or use a single-ad-set strategy so each recipe ad set clears Meta minimums.', 'vms-meta-ads'), $label, self::format_minor_budget($adset_budget)),
						array('status' => 400)
					);
				}
				$audience = is_array($adset['audience'] ?? null) ? (array) $adset['audience'] : array();
				$targeting_payload = array(
					'targeting_address' => sanitize_text_field((string) ($audience['targeting_address'] ?? '')),
					'locations' => sanitize_textarea_field((string) ($audience['locations'] ?? '')),
					'radius_miles' => max(1, absint($audience['radius_miles'] ?? 25)),
					'age_min' => max(13, absint($audience['age_min'] ?? 21)),
					'age_max' => max(13, absint($audience['age_max'] ?? 65)),
					'interests' => array(),
					'require_explicit_locations' => !empty($audience['require_explicit_locations']) ? 1 : 0,
				);
				$placements = !empty($adset['placements']) && is_array($adset['placements']) ? array_values(array_filter(array_map('sanitize_key', (array) $adset['placements']))) : array();
				$placements_payload = array('mode' => 'manual', 'placements' => $placements);
				$placement_resolution = self::resolve_effective_placements_for_create($placements_payload, (string) ($base_preflight['ig_actor_id'] ?? ''));
				if (is_wp_error($placement_resolution)) {
					return $placement_resolution;
				}
				$placements_payload = (array) ($placement_resolution['placements_payload'] ?? $placements_payload);
				$targeting = self::build_manual_targeting($settings, $targeting_payload, $placements_payload, $build_id, $event_plan_id);
				if (is_wp_error($targeting)) {
					return $targeting;
				}
				$variant_mode = sanitize_key((string) ($adset['variant_mode'] ?? 'standard'));
				$variants = self::select_recipe_variants($all_variants, $variant_mode, $label, $key);
				if (in_array($key, array('fb_right_column', 'fb_right_column_support'), true) && empty($base_preflight['creative_images']['square'])) {
					return new WP_Error('right_column_static_required', __('Right Column support requires a square/static image. Add a square creative or turn off the Right Column support test.', 'vms-meta-ads'), array('status' => 400));
				}
				if (!empty($recipe_payload['require_vertical_video']) && in_array($key, array('vertical_video_reels_stories', 'promo_video_reels'), true)) {
					$has_video_variant = false;
					foreach ($variants as $variant) {
						$media_mode = sanitize_key((string) ($variant['media_mode'] ?? 'shared'));
						if (in_array($media_mode, array('video', 'video_placeholder'), true)) {
							$has_video_variant = true;
							break;
						}
					}
					if (!$has_video_variant) {
						return new WP_Error('vertical_video_required', __('This recipe is set to require a tall 9:16 video before creating the Reels/Stories ad set. Add a video variant or turn off strict vertical-video checking.', 'vms-meta-ads'), array('status' => 400));
					}
				}
				$out[] = array_merge($base_preflight, array(
					'key' => $key,
					'label' => $label,
					'adset_name' => sanitize_text_field((string) ($adset['name'] ?? $label)),
					'lifetime_budget_minor' => $adset_budget,
					'targeting' => $targeting,
					'effective_placements_payload' => $placements_payload,
					'variants' => $variants,
				));
			}
			return $out;
		}

		private static function select_recipe_variants(array $variants, string $mode, string $adset_label, string $adset_key): array
		{
			$variants = array_values(array_filter($variants, 'is_array'));
			if (empty($variants)) {
				return array();
			}
			$is_video_variant = static function (array $variant): bool {
				$media_mode = sanitize_key((string) ($variant['media_mode'] ?? 'shared'));
				return in_array($media_mode, array('video', 'video_placeholder'), true);
			};
			$slot_for = static function (array $variant): string {
				$slot = sanitize_key((string) ($variant['placement_slot'] ?? 'auto'));
				return in_array($slot, array('auto', 'feed_square_video', 'reels_stories_video'), true) ? $slot : 'auto';
			};
			$selected = array();
			if ($mode === 'single_static') {
				foreach ($variants as $variant) {
					if (!$is_video_variant($variant)) {
						$selected[] = $variant;
						break;
					}
				}
				if (empty($selected)) {
					$selected[] = $variants[0];
				}
			} elseif ($mode === 'feed_static') {
				foreach ($variants as $variant) {
					if (!$is_video_variant($variant)) {
						$selected[] = $variant;
					}
				}
				if (empty($selected)) {
					$selected[] = $variants[0];
				}
			} elseif ($mode === 'feed_video') {
				foreach ($variants as $variant) {
					if ($is_video_variant($variant) && $slot_for($variant) === 'feed_square_video') {
						$selected[] = $variant;
					}
				}
				if (empty($selected)) {
					foreach ($variants as $variant) {
						if ($is_video_variant($variant) && $slot_for($variant) === 'auto') {
							$variant['placement_slot'] = 'feed_square_video';
							$variant['label'] = trim((string) ($variant['label'] ?? '')) !== '' ? (string) $variant['label'] : __('Feed Square Video Placeholder', 'vms-meta-ads');
							$selected[] = $variant;
							break;
						}
					}
				}
				if (empty($selected)) {
					$placeholder = $variants[0];
					$placeholder['variant_key'] = 'feed_square_video_placeholder';
					$placeholder['label'] = __('Feed Square Video Placeholder', 'vms-meta-ads');
					$placeholder['media_mode'] = 'video_placeholder';
					$placeholder['placement_slot'] = 'feed_square_video';
					$placeholder['media_image_id'] = 0;
					$placeholder['media_video_id'] = 0;
					$selected[] = $placeholder;
				}
			} elseif ($mode === 'video_preferred') {
				foreach ($variants as $variant) {
					if ($is_video_variant($variant) && $slot_for($variant) !== 'feed_square_video') {
						$selected[] = $variant;
					}
				}
				if (empty($selected)) {
					$selected[] = $variants[0];
				}
			} else {
				$selected = array_slice($variants, 0, 3);
			}

			$out = array();
			foreach ($selected as $index => $variant) {
				$variant = is_array($variant) ? $variant : array();
				$base_key = sanitize_key((string) ($variant['variant_key'] ?? ('v' . ($index + 1)))) ?: ('v' . ($index + 1));
				$variant['variant_key'] = $base_key;
				$variant['adset_key'] = $adset_key;
				$variant['label'] = sanitize_text_field((string) ($variant['label'] ?? ('Variant ' . ($index + 1))));
				$variant['ad_name'] = sanitize_text_field($adset_label . ' - ' . (string) $variant['label']);
				$variant['creative_name'] = $variant['ad_name'] . ' Creative';
				$out[] = $variant;
			}
			return $out;
		}




		private static function resolve_copy_ad_variants(array $copy, int $event_plan_id = 0): array
		{
			$variants = array();
			$raw = !empty($copy['ad_variants']) && is_array($copy['ad_variants']) ? array_values((array) $copy['ad_variants']) : array();
			if (!empty($raw)) {
				foreach ($raw as $index => $variant) {
					if ($index >= 3) {
						break;
					}
					$variant = is_array($variant) ? $variant : array();
					$label = sanitize_text_field((string) ($variant['label'] ?? ('Variant ' . ($index + 1))));
					$media_mode = sanitize_key((string) ($variant['media_mode'] ?? 'shared'));
					if (!in_array($media_mode, array('shared', 'image', 'video', 'video_placeholder'), true)) {
						$media_mode = 'shared';
					}
					$placement_slot = sanitize_key((string) ($variant['placement_slot'] ?? 'auto'));
					if (!in_array($placement_slot, array('auto', 'feed_square_video', 'reels_stories_video'), true)) {
						$placement_slot = 'auto';
					}
					$media_image_id = absint($variant['media_image_id'] ?? 0);
					$media_video_id = absint($variant['media_video_id'] ?? 0);
					if ($media_mode !== 'image') {
						$media_image_id = 0;
					}
					if ($media_mode !== 'video') {
						$media_video_id = 0;
					}
					$variants[] = array(
						'variant_key' => sanitize_key((string) ($variant['variant_key'] ?? ('v' . ($index + 1)))) ?: ('v' . ($index + 1)),
						'label' => $label !== '' ? $label : ('Variant ' . ($index + 1)),
						'primary_text' => sanitize_textarea_field((string) ($variant['primary_text'] ?? '')),
						'headline' => sanitize_text_field((string) ($variant['headline'] ?? '')),
						'description' => sanitize_text_field((string) ($variant['description'] ?? '')),
						'media_mode' => $media_mode,
						'placement_slot' => $placement_slot,
						'media_image_id' => $media_image_id,
						'media_video_id' => $media_video_id,
						'ad_name' => sanitize_text_field((string) ($variant['ad_name'] ?? '')),
						'creative_name' => sanitize_text_field((string) ($variant['creative_name'] ?? '')),
					);
				}
			}
			if (empty($variants)) {
				$variants[] = array(
					'variant_key' => 'v1',
					'label' => 'Variant 1',
					'primary_text' => sanitize_textarea_field((string) (($copy['primary_text_variants'][0] ?? '') ?: '')),
					'headline' => sanitize_text_field((string) (($copy['headline_variants'][0] ?? '') ?: '')),
					'description' => sanitize_text_field((string) (($copy['description_variants'][0] ?? '') ?: '')),
					'media_mode' => 'shared',
					'placement_slot' => 'auto',
					'media_image_id' => 0,
					'media_video_id' => 0,
					'ad_name' => sanitize_text_field((string) (($copy['ad_names'][0] ?? '') ?: ('Event Plan ' . $event_plan_id . ' — V1'))),
					'creative_name' => sanitize_text_field((string) (($copy['ad_names'][0] ?? '') ?: ('Event Plan ' . $event_plan_id . ' — V1'))) . ' Creative',
				);
			}
			foreach ($variants as $index => $variant) {
				if ((string) ($variant['headline'] ?? '') === '') {
					$variants[$index]['headline'] = __('Get Tickets', 'vms-meta-ads');
				}
				if ((string) ($variant['description'] ?? '') === '') {
					$variants[$index]['description'] = __('Tickets available now.', 'vms-meta-ads');
				}
				if ((string) ($variant['ad_name'] ?? '') === '') {
					$variants[$index]['ad_name'] = 'Event Plan ' . $event_plan_id . ' — ' . strtoupper((string) ($variant['variant_key'] ?? ('v' . ($index + 1))));
				}
				if ((string) ($variant['creative_name'] ?? '') === '') {
					$variants[$index]['creative_name'] = (string) $variants[$index]['ad_name'] . ' Creative';
				}
				if ((string) ($variant['media_mode'] ?? 'shared') === 'image' && (int) ($variant['media_image_id'] ?? 0) < 1) {
					$variants[$index]['media_mode'] = 'shared';
				}
				if ((string) ($variant['media_mode'] ?? 'shared') === 'video' && (int) ($variant['media_video_id'] ?? 0) < 1) {
					$variants[$index]['media_mode'] = 'shared';
				}
				if ((string) ($variants[$index]['media_mode'] ?? 'shared') !== 'image') {
					$variants[$index]['media_image_id'] = 0;
				}
				if ((string) ($variants[$index]['media_mode'] ?? 'shared') !== 'video') {
					$variants[$index]['media_video_id'] = 0;
				}
			}
			return $variants;
		}

		private static function build_variant_definitions_from_preflight(array $preflight): array
		{
			$variants = !empty($preflight['ad_variants']) && is_array($preflight['ad_variants']) ? array_values((array) $preflight['ad_variants']) : array();
			if (empty($variants)) {
				$variants[] = array(
					'variant_key' => 'v1',
					'label' => 'Variant 1',
					'primary_text' => (string) ($preflight['primary_text'] ?? ''),
					'headline' => (string) ($preflight['headline'] ?? ''),
					'description' => (string) ($preflight['description'] ?? ''),
					'media_mode' => 'shared',
					'media_image_id' => 0,
					'media_video_id' => 0,
					'ad_name' => (string) ($preflight['ad_name'] ?? 'Variant 1'),
					'creative_name' => (string) ($preflight['creative_name'] ?? 'Variant 1 Creative'),
				);
			}
			return array_values($variants);
		}

		private static function normalize_existing_variant_meta(array $existing_ids, array $variant_defs): array
		{
			$rows = array();
			$raw = !empty($existing_ids['ad_variants_meta']) && is_array($existing_ids['ad_variants_meta']) ? array_values((array) $existing_ids['ad_variants_meta']) : array();
			$creative_ids = !empty($existing_ids['creative_ids']) && is_array($existing_ids['creative_ids']) ? array_values((array) $existing_ids['creative_ids']) : array();
			$ad_ids = !empty($existing_ids['ad_ids']) && is_array($existing_ids['ad_ids']) ? array_values((array) $existing_ids['ad_ids']) : array();
			foreach ($variant_defs as $index => $variant) {
				$row = is_array($raw[$index] ?? null) ? (array) $raw[$index] : array();
				$creative_id = sanitize_text_field((string) ($row['creative_id'] ?? ($creative_ids[$index] ?? ($index === 0 ? ($existing_ids['creative_id'] ?? '') : ''))));
				$ad_id = sanitize_text_field((string) ($row['ad_id'] ?? ($ad_ids[$index] ?? ($index === 0 ? ($existing_ids['ad_id'] ?? '') : ''))));
				$rows[] = array(
					'variant_key' => sanitize_key((string) ($row['variant_key'] ?? ($variant['variant_key'] ?? ('v' . ($index + 1))))) ?: ('v' . ($index + 1)),
					'label' => sanitize_text_field((string) ($row['label'] ?? ($variant['label'] ?? ('Variant ' . ($index + 1))))) ?: ('Variant ' . ($index + 1)),
					'creative_id' => $creative_id,
					'ad_id' => $ad_id,
				);
			}
			return $rows;
		}

		private static function create_creative_for_variant(array $settings, array $preflight, array $variant, array $images, int $build_id = 0)
		{
			$media_mode = sanitize_key((string) ($variant['media_mode'] ?? 'shared'));
			if ($media_mode === 'video') {
				$video_asset = self::attachment_video_asset_payload(absint($variant['media_video_id'] ?? 0));
				if (empty($video_asset)) {
					return new WP_Error('missing_variant_video', __('Variant video could not be resolved from the selected WordPress media item.', 'vms-meta-ads'), array('status' => 400));
				}
				$video_id = self::upload_single_creative_video_to_meta($settings, $video_asset, $build_id);
				if (is_wp_error($video_id)) {
					return $video_id;
				}
				return self::create_video_creative_for_variant($settings, $preflight, $variant, $video_id, $images, $build_id);
			}

			if ($media_mode === 'image') {
				$images = self::resolve_variant_image_assets($variant, $images);
				$images = self::upload_creative_images_to_meta($settings, $images, $build_id);
			}

			$creative_blueprint = self::build_creative_request_blueprint($preflight, $variant, $images);
			$path = VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/adcreatives';
			$attempt_label = 'create_creative';

			$primary_payload = (array) $creative_blueprint['asset_feed_with_rules'];
			$response = self::meta_post_creative_with_feature_fallbacks(
				$settings,
				$path,
				$primary_payload,
				$preflight,
				$attempt_label,
				$build_id,
				true
			);
			if (!is_wp_error($response)) {
				return $response;
			}
			$last_error = $response;

			if (!empty($creative_blueprint['asset_feed_without_rules']) && self::is_asset_customization_rules_unsupported($response)) {
				vms_ma_log('meta_creative_fallback', array(
					'where' => $attempt_label,
					'build_id' => $build_id,
					'message' => $response->get_error_message(),
					'strategy' => 'remove_asset_customization_rules',
				), $build_id);

				$response = self::meta_post_creative_with_feature_fallbacks(
					$settings,
					$path,
					(array) $creative_blueprint['asset_feed_without_rules'],
					$preflight,
					'create_creative_retry_without_rules',
					$build_id,
					false
				);
				if (!is_wp_error($response)) {
					return $response;
				}
				$last_error = $response;
			}

			if (!empty($creative_blueprint['single_image']) && self::should_fallback_to_standard_creative($response)) {
				vms_ma_log('meta_creative_fallback', array(
					'where' => $attempt_label,
					'build_id' => $build_id,
					'message' => $response->get_error_message(),
					'strategy' => 'single_image_story_spec',
				), $build_id);

				$fallback_response = self::meta_post_creative_with_feature_fallbacks(
					$settings,
					$path,
					(array) $creative_blueprint['single_image'],
					$preflight,
					'create_creative_retry_single_image',
					$build_id,
					false
				);
				if (!is_wp_error($fallback_response)) {
					return $fallback_response;
				}
				$last_error = $fallback_response;
			}

			return $last_error;
		}

		private static function resolve_variant_image_assets(array $variant, array $shared_images): array
		{
			if (sanitize_key((string) ($variant['media_mode'] ?? 'shared')) !== 'image') {
				return $shared_images;
			}
			$asset = self::attachment_asset_payload(absint($variant['media_image_id'] ?? 0));
			if (empty($asset)) {
				return $shared_images;
			}
			return array(
				'square' => $asset,
				'vertical' => array(),
				'wide' => array(),
			);
		}

		private static function create_video_creative_for_variant(array $settings, array $preflight, array $variant, string $video_id, array $images, int $build_id = 0)
		{
			$thumb_url = '';
			foreach (array('square', 'wide', 'vertical') as $kind) {
				$asset = is_array($images[$kind] ?? null) ? (array) $images[$kind] : array();
				$maybe_url = trim((string) ($asset['url'] ?? ''));
				if ($maybe_url !== '') {
					$thumb_url = $maybe_url;
					break;
				}
			}
			$video_data = array(
				'video_id' => $video_id,
				'message' => (string) ($variant['primary_text'] ?? ''),
				'title' => (string) ($variant['headline'] ?? ''),
				'link_description' => (string) ($variant['description'] ?? ''),
				'call_to_action' => array(
					'type' => (string) ($preflight['cta_type'] ?? 'LEARN_MORE'),
					'value' => array('link' => (string) $preflight['destination_url']),
				),
			);
			if ($thumb_url !== '') {
				$video_data['image_url'] = $thumb_url;
			}
			$story_spec = array(
				'page_id' => (string) $preflight['page_id'],
				'video_data' => $video_data,
			);
			if (!empty($preflight['ig_actor_id'])) {
				$story_spec['instagram_user_id'] = (string) $preflight['ig_actor_id'];
			}
			$path = VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/adcreatives';
			$payload = array(
				'name' => (string) ($variant['creative_name'] ?? 'Video Creative'),
				'link_url' => (string) $preflight['destination_url'],
				'object_story_spec' => wp_json_encode($story_spec),
			);
			$response = self::meta_post_creative_with_feature_fallbacks(
				$settings,
				$path,
				$payload,
				$preflight,
				'create_creative_video',
				$build_id,
				true
			);
			return $response;
		}

		private static function resolve_creative_image_assets(array $build): array
		{
			$copy = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
			$assets = is_array($copy['creative_assets'] ?? null) ? (array) $copy['creative_assets'] : array();
			$resolved = array(
				'square' => self::attachment_asset_payload(absint($assets['image_square_id'] ?? 0)),
				'vertical' => self::attachment_asset_payload(absint($assets['image_vertical_id'] ?? 0)),
				'wide' => self::attachment_asset_payload(absint($assets['image_wide_id'] ?? 0)),
			);

			$fallback_id = self::resolve_featured_image_attachment_id($build);
			if ($fallback_id > 0) {
				$fallback_asset = self::attachment_asset_payload($fallback_id);
				if (!empty($fallback_asset)) {
					if (empty($resolved['square'])) {
						$resolved['square'] = $fallback_asset;
					}
					if (empty($resolved['wide'])) {
						$resolved['wide'] = $fallback_asset;
					}
				}
			}

			return array(
				'square' => is_array($resolved['square']) ? $resolved['square'] : array(),
				'vertical' => is_array($resolved['vertical']) ? $resolved['vertical'] : array(),
				'wide' => is_array($resolved['wide']) ? $resolved['wide'] : array(),
			);
		}

		private static function attachment_asset_payload(int $attachment_id): array
		{
			if ($attachment_id < 1) {
				return array();
			}
			$url = (string) wp_get_attachment_url($attachment_id);
			$file = (string) get_attached_file($attachment_id);
			$mime = (string) get_post_mime_type($attachment_id);
			if ($url === '' && $file === '') {
				return array();
			}
			return array(
				'attachment_id' => $attachment_id,
				'url' => $url,
				'file' => $file,
				'filename' => $file !== '' ? wp_basename($file) : ('image-' . $attachment_id . '.jpg'),
				'mime' => $mime,
			);
		}

		private static function attachment_video_asset_payload(int $attachment_id): array
		{
			$asset = self::attachment_asset_payload($attachment_id);
			$mime = strtolower((string) ($asset['mime'] ?? ''));
			if (empty($asset) || strpos($mime, 'video/') !== 0) {
				return array();
			}
			return $asset;
		}

		private static function upload_single_creative_video_to_meta(array $settings, array $asset, int $build_id = 0)
		{
			$file_url = esc_url_raw((string) ($asset['url'] ?? ''));
			if ($file_url === '') {
				return new WP_Error('missing_video_url', __('The selected video is missing a public URL, so Meta could not ingest it.', 'vms-meta-ads'), array('status' => 400));
			}
			$response = self::meta_post(
				$settings,
				VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/advideos',
				array(
					'name' => sanitize_file_name((string) ($asset['filename'] ?? 'variant-video.mp4')),
					'file_url' => $file_url,
				),
				'upload_creative_video',
				$build_id
			);
			if (is_wp_error($response)) {
				return $response;
			}
			$video_id = self::extract_created_id((array) $response, 'video');
			if ($video_id === '') {
				$body = is_array($response['body'] ?? null) ? (array) $response['body'] : array();
				$video_id = sanitize_text_field((string) ($body['id'] ?? ''));
			}
			if ($video_id === '') {
				return new WP_Error('meta_video_missing_id', __('Meta video upload returned no video ID.', 'vms-meta-ads'), array('status' => 502));
			}
			return $video_id;
		}

		private static function resolve_featured_image_attachment_id(array $build): int
		{
			$event_plan_id = absint($build['event_plan_id'] ?? 0);
			if ($event_plan_id > 0) {
				$thumb_id = absint(get_post_thumbnail_id($event_plan_id));
				if ($thumb_id > 0) {
					return $thumb_id;
				}
				$tec_event_id = absint(get_post_meta($event_plan_id, '_vms_tec_event_id', true));
				if ($tec_event_id > 0) {
					$thumb_id = absint(get_post_thumbnail_id($tec_event_id));
					if ($thumb_id > 0) {
						return $thumb_id;
					}
				}
			}
			return 0;
		}

		private static function upload_creative_images_to_meta(array $settings, array $creative_images, int $build_id = 0): array
		{
			$out = array(
				'square' => array(),
				'vertical' => array(),
				'wide' => array(),
			);
			foreach (array('square', 'vertical', 'wide') as $kind) {
				$asset = is_array($creative_images[$kind] ?? null) ? (array) $creative_images[$kind] : array();
				if (empty($asset)) {
					continue;
				}
				$hash = self::upload_single_creative_image_to_meta($settings, $asset, $kind, $build_id);
				if ($hash !== '') {
					$asset['hash'] = $hash;
				}
				$out[$kind] = $asset;
			}
			return $out;
		}

		private static function upload_single_creative_image_to_meta(array $settings, array $asset, string $kind, int $build_id = 0): string
		{
			$body = array(
				'name' => sanitize_file_name((string) ($asset['filename'] ?? ($kind . '.jpg'))),
			);

			$file = trim((string) ($asset['file'] ?? ''));
			if ($file !== '' && file_exists($file) && is_readable($file)) {
				$bytes = @file_get_contents($file);
				if ($bytes !== false && $bytes !== '') {
					$body['bytes'] = base64_encode($bytes);
				}
			}
			if (empty($body['bytes'])) {
				$url = esc_url_raw((string) ($asset['url'] ?? ''));
				if ($url !== '') {
					$body['url'] = $url;
				}
			}
			if (empty($body['bytes']) && empty($body['url'])) {
				return '';
			}

			$response = self::meta_post(
				$settings,
				VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/adimages',
				$body,
				'upload_adimage_' . $kind,
				$build_id
			);
			if (is_wp_error($response)) {
				return '';
			}
			return self::extract_uploaded_image_hash((array) $response);
		}

		private static function extract_uploaded_image_hash(array $response): string
		{
			$body = is_array($response['body'] ?? null) ? (array) $response['body'] : array();
			if (!empty($body['hash']) && is_string($body['hash'])) {
				return sanitize_text_field($body['hash']);
			}
			if (!empty($body['images']) && is_array($body['images'])) {
				foreach ($body['images'] as $image_row) {
					if (is_array($image_row) && !empty($image_row['hash'])) {
						return sanitize_text_field((string) $image_row['hash']);
					}
				}
			}
			return '';
		}

		private static function run_status_updates(int $build_id, array $steps, array $options = array()): array
		{
			$rollback_on_partial = !empty($options['rollback_on_partial']);
			$result = array(
				'ok' => true,
				'rolled_back' => false,
				'message' => __('Action completed.', 'vms-meta-ads'),
				'result' => array(
					'campaign' => self::empty_object_result(),
					'adset' => self::empty_object_result(),
					'ad' => self::empty_object_result(),
				),
			);

			$activated = array();
			foreach ($steps as $key => $step) {
				$object_id = sanitize_text_field((string) ($step['id'] ?? ''));
				$target = strtoupper(sanitize_text_field((string) ($step['target'] ?? '')));
				$result['result'][$key]['attempted'] = true;

				$status = self::fetch_object_status($object_id);
				if (is_wp_error($status)) {
					$result['ok'] = false;
					$result['result'][$key]['error'] = $status->get_error_message();
					$result['message'] = __('Meta status check failed before update.', 'vms-meta-ads');
					break;
				}

				$current = strtoupper((string) ($status['configured_status'] ?? ''));
				if ($current === '' || $current === 'UNKNOWN') {
					$current = strtoupper((string) ($status['effective_status'] ?? ''));
				}
				if ($current === 'ARCHIVED' || $current === 'DELETED') {
					$result['ok'] = false;
					$result['result'][$key]['error'] = __('Meta object is archived or deleted and cannot be changed.', 'vms-meta-ads');
					$result['message'] = __('Go Live cannot continue because one Meta object is archived/deleted.', 'vms-meta-ads');
					break;
				}

				if ($current === $target) {
					$result['result'][$key]['status'] = $target;
					$result['result'][$key]['changed'] = false;
					continue;
				}

				$update = self::update_object_status($object_id, $target);
				if (is_wp_error($update)) {
					$result['ok'] = false;
					$result['result'][$key]['error'] = $update->get_error_message();
					$result['message'] = __('Meta update failed.', 'vms-meta-ads');
					break;
				}
				$result['result'][$key]['status'] = $target;
				$result['result'][$key]['changed'] = true;
				if ($target === self::STATUS_ACTIVE) {
					$activated[] = array('key' => $key, 'id' => $object_id);
				}
			}

			if (!$result['ok'] && $rollback_on_partial && !empty($activated)) {
				$rollback_error = false;
				for ($i = count($activated) - 1; $i >= 0; $i--) {
					$rollback = self::update_object_status((string) $activated[$i]['id'], self::STATUS_PAUSED);
					if (is_wp_error($rollback)) {
						$rollback_error = true;
					}
				}
				$result['rolled_back'] = true;
				$result['message'] = $rollback_error
					? __('Go Live failed and rollback also failed for one or more objects.', 'vms-meta-ads')
					: __('Published partially; rolled back to PAUSED.', 'vms-meta-ads');
			}

			if (!$result['ok']) {
				vms_ma_log('error', array(
					'where' => 'status_update',
					'build_id' => $build_id,
					'result' => $result['result'],
					'message' => $result['message'],
					'error' => true,
				), $build_id);
			}

			return $result;
		}


		private static function persist_create_success(array $build, array $ids, array $result, array $settings, array $warnings = array())
		{
			$ids = self::attach_dsa_payload_marker($ids, $settings);
			$persisted = self::persist_create_ids($build, $ids, '', 'meta_created_paused', self::STATUS_PAUSED);
			if (is_wp_error($persisted)) {
				return $persisted;
			}
			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			$snapshot = self::build_status_snapshot(array(
				'campaign_id' => (string) ($ids['campaign_id'] ?? ''),
				'adset_id' => (string) ($ids['adset_id'] ?? ''),
				'adset_ids' => !empty($ids['adset_ids']) && is_array($ids['adset_ids']) ? (array) $ids['adset_ids'] : array(),
				'adsets_meta' => !empty($ids['adsets_meta']) && is_array($ids['adsets_meta']) ? (array) $ids['adsets_meta'] : array(),
				'ad_id' => (string) ($ids['ad_id'] ?? ''),
				'ad_ids' => !empty($ids['ad_ids']) && is_array($ids['ad_ids']) ? (array) $ids['ad_ids'] : array(),
				'ad_variants_meta' => !empty($ids['ad_variants_meta']) && is_array($ids['ad_variants_meta']) ? (array) $ids['ad_variants_meta'] : array(),
				'campaign_recipe' => sanitize_key((string) ($ids['campaign_recipe'] ?? '')),
			), $settings);
			$local_meta_status = self::derive_local_meta_status($snapshot, 'create_paused', 'ok');
			$readiness = self::build_post_create_readiness($build, $ids, $snapshot, $settings);
			if ($event_plan_id > 0) {
				$snapshot_payload = array(
					'campaign' => $snapshot['campaign'] ?? self::unknown_status((string) ($ids['campaign_id'] ?? '')),
					'adset' => $snapshot['adset'] ?? self::unknown_status((string) ($ids['adset_id'] ?? '')),
					'adsets' => array_values(is_array($snapshot['adsets'] ?? null) ? (array) $snapshot['adsets'] : array()),
					'adset_count' => (int) ($snapshot['adset_count'] ?? 0),
					'ad' => $snapshot['ad'] ?? self::unknown_status((string) ($ids['ad_id'] ?? '')),
					'ad_variants' => array_values(is_array($snapshot['ad_variants'] ?? null) ? (array) $snapshot['ad_variants'] : array()),
					'ad_variant_count' => (int) ($snapshot['ad_variant_count'] ?? 0),
					'ad_account_id' => (string) ($snapshot['ad_account_id'] ?? ''),
					'open_in_meta_url' => (string) ($snapshot['open_in_meta_url'] ?? ''),
					'local_meta_status' => $local_meta_status,
					'local_meta_label' => self::local_meta_status_label($local_meta_status),
					'updated_local' => self::current_local_time(),
				);
				update_post_meta($event_plan_id, 'vms_ma_meta_campaign_id', (string) ($ids['campaign_id'] ?? ''));
				update_post_meta($event_plan_id, 'vms_ma_meta_adset_id', (string) ($ids['adset_id'] ?? ''));
				update_post_meta($event_plan_id, 'vms_ma_meta_ad_id', (string) ($ids['ad_id'] ?? ''));
				update_post_meta($event_plan_id, 'vms_ma_meta_created_local', self::current_local_time());
				update_post_meta($event_plan_id, 'vms_ma_meta_status', $local_meta_status);
				update_post_meta($event_plan_id, 'vms_ma_meta_last_status_snapshot_json', wp_json_encode($snapshot_payload));
				self::append_event_log($event_plan_id, array(
					'local_timestamp' => self::current_local_time(),
					'action' => 'create_paused',
					'outcome' => 'ok',
					'per_object' => $result,
					'created_ids' => $ids,
					'partial_create' => 0,
					'user_id' => get_current_user_id(),
				));
			}
			vms_ma_log('meta_create_response', array(
				'build_id' => (int) ($build['id'] ?? 0),
				'campaign_id' => (string) ($ids['campaign_id'] ?? ''),
				'adset_id' => (string) ($ids['adset_id'] ?? ''),
				'ad_id' => (string) ($ids['ad_id'] ?? ''),
				'ad_ids' => array_values(is_array($ids['ad_ids'] ?? null) ? (array) $ids['ad_ids'] : array()),
				'ok' => true,
			), (int) ($build['id'] ?? 0));

			$message = __('Create in Meta completed. Campaign, ad set, and ad are PAUSED.', 'vms-meta-ads');
			if ($local_meta_status === 'paused_reviewing') {
				$message = __('Create in Meta completed. Meta created paused objects, and one or more ads are still pending review.', 'vms-meta-ads');
			}
			if (($snapshot['adset_count'] ?? 0) > 1) {
				$message = sprintf(__('Create in Meta completed. Campaign, %1$d ad sets, and %2$d ads are PAUSED.', 'vms-meta-ads'), (int) $snapshot['adset_count'], (int) ($snapshot['ad_variant_count'] ?? 0));
			} elseif (($snapshot['ad_variant_count'] ?? 0) > 1) {
				$message = sprintf(__('Create in Meta completed. Campaign, ad set, and %d ads are PAUSED.', 'vms-meta-ads'), (int) $snapshot['ad_variant_count']);
			}
			if (!empty($warnings)) {
				$message .= ' ' . implode(' ', array_map('sanitize_text_field', $warnings));
			}

			return array(
				'ok' => true,
				'result' => $result,
				'ids' => $ids,
				'message' => $message,
				'warnings' => array_values(array_map('sanitize_text_field', $warnings)),
				'updated_local' => self::current_local_time(),
				'campaign' => (array) ($snapshot['campaign'] ?? self::unknown_status((string) ($ids['campaign_id'] ?? ''))),
				'adset' => (array) ($snapshot['adset'] ?? self::unknown_status((string) ($ids['adset_id'] ?? ''))),
				'ad' => (array) ($snapshot['ad'] ?? self::unknown_status((string) ($ids['ad_id'] ?? ''))),
				'ad_variants' => array_values(is_array($snapshot['ad_variants'] ?? null) ? (array) $snapshot['ad_variants'] : array()),
				'ad_variant_count' => (int) ($snapshot['ad_variant_count'] ?? 0),
				'local_meta_status' => $local_meta_status,
				'local_meta_label' => self::local_meta_status_label($local_meta_status),
				'readiness' => $readiness,
				'ad_account_id' => (string) ($snapshot['ad_account_id'] ?? ''),
				'open_in_meta_url' => (string) ($snapshot['open_in_meta_url'] ?? ''),
			);
		}


		private static function persist_create_partial(array $build, array $ids, array $result, string $message, ?array $settings = null): void
		{
			if (is_array($settings)) {
				$ids = self::attach_dsa_payload_marker($ids, $settings);
			}
			$ad_ids = !empty($ids['ad_ids']) && is_array($ids['ad_ids']) ? array_values(array_filter(array_map('sanitize_text_field', (array) $ids['ad_ids']))) : array();
			$has_any_id = !empty($ids['campaign_id']) || !empty($ids['adset_id']) || !empty($ids['ad_id']) || !empty($ad_ids);
			self::persist_create_ids($build, $ids, $message, 'error', $has_any_id ? 'ERROR' : '');

			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			if ($event_plan_id < 1) {
				return;
			}

			if (!empty($ids['campaign_id'])) {
				update_post_meta($event_plan_id, 'vms_ma_meta_campaign_id', (string) $ids['campaign_id']);
			}
			if (!empty($ids['adset_id'])) {
				update_post_meta($event_plan_id, 'vms_ma_meta_adset_id', (string) $ids['adset_id']);
			}
			if (!empty($ids['ad_id'])) {
				update_post_meta($event_plan_id, 'vms_ma_meta_ad_id', (string) $ids['ad_id']);
			}
			update_post_meta($event_plan_id, 'vms_ma_meta_status', $has_any_id ? 'partial' : 'error');

			$snapshot = array(
				'campaign' => !empty($ids['campaign_id']) ? self::unknown_status((string) $ids['campaign_id']) : self::status_error('', $message),
				'adset' => !empty($ids['adset_id']) ? self::unknown_status((string) $ids['adset_id']) : self::status_error('', $message),
				'ad' => !empty($ids['ad_id']) ? self::unknown_status((string) $ids['ad_id']) : self::status_error('', $message),
				'ad_variants' => array(),
				'ad_variant_count' => count($ad_ids),
				'ad_account_id' => '',
				'open_in_meta_url' => 'https://adsmanager.facebook.com/',
				'ad_variants' => array(),
				'ad_variant_count' => 0,
			);
			foreach ($ad_ids as $index => $ad_variant_id) {
				$snapshot['ad_variants'][] = self::unknown_status((string) $ad_variant_id) + array(
					'variant_key' => 'v' . ($index + 1),
					'label' => 'Variant ' . ($index + 1),
				);
			}
			if (empty($snapshot['ad_variants']) && !empty($ids['ad_id'])) {
				$snapshot['ad_variants'][] = self::unknown_status((string) $ids['ad_id']) + array(
					'variant_key' => 'v1',
					'label' => 'Variant 1',
				);
				$snapshot['ad_variant_count'] = 1;
			}
			if (is_array($settings)) {
				$ad_account_id = ltrim((string) ($settings['meta_ad_account_id'] ?? ''), 'act_');
				$snapshot['ad_account_id'] = $ad_account_id;
				$snapshot['open_in_meta_url'] = self::build_ads_manager_url($ad_account_id);
			}
			update_post_meta($event_plan_id, 'vms_ma_meta_last_status_snapshot_json', wp_json_encode(array(
				'campaign' => $snapshot['campaign'],
				'adset' => $snapshot['adset'],
				'ad' => $snapshot['ad'],
				'ad_variants' => array_values($snapshot['ad_variants']),
				'ad_variant_count' => (int) $snapshot['ad_variant_count'],
				'ad_account_id' => (string) $snapshot['ad_account_id'],
				'open_in_meta_url' => (string) $snapshot['open_in_meta_url'],
				'updated_local' => self::current_local_time(),
			)));
			self::append_event_log($event_plan_id, array(
				'local_timestamp' => self::current_local_time(),
				'action' => 'create_paused',
				'outcome' => $has_any_id ? 'partial' : 'error',
				'per_object' => $result,
				'created_ids' => $ids,
				'partial_create' => $has_any_id ? 1 : 0,
				'error_message' => sanitize_text_field($message),
				'user_id' => get_current_user_id(),
			));
		}

		private static function has_reusable_meta_status_objects(array $existing_ids): bool
		{
			$known = self::build_known_meta_ids_payload($existing_ids);
			return !empty($known['campaign_id']) || !empty($known['adset_ids']) || !empty($known['ad_ids']);
		}

		private static function assert_reusable_meta_ids_are_paused(array $existing_ids, array $settings)
		{
			$known = self::build_known_meta_ids_payload($existing_ids);
			$status_snapshot = array(
				'campaign' => array(),
				'adsets' => array(),
				'ads' => array(),
			);

			if (!empty($known['campaign_id'])) {
				$campaign_status = self::fetch_object_status((string) $known['campaign_id'], $settings);
				if (is_wp_error($campaign_status)) {
					return self::wrap_partial_create_error(
						new WP_Error(
							'meta_reuse_status_unverified',
							__('Existing Meta campaign status could not be verified. Review the saved Meta IDs in Ads Manager before retrying Create in Meta (PAUSED).', 'vms-meta-ads'),
							array('status' => 409)
						),
						$existing_ids,
						$settings,
						$status_snapshot
					);
				}
				$status_snapshot['campaign'] = $campaign_status;
				if (!self::is_verified_paused_status((array) $campaign_status)) {
					return self::wrap_partial_create_error(
						new WP_Error(
							'meta_reuse_not_paused',
							__('The saved Meta campaign is not safely paused. Review or clean it up in Ads Manager before retrying Create in Meta (PAUSED).', 'vms-meta-ads'),
							array('status' => 409)
						),
						$existing_ids,
						$settings,
						$status_snapshot
					);
				}
			}

			foreach ((array) $known['adset_ids'] as $adset_id) {
				$adset_status = self::fetch_object_status((string) $adset_id, $settings);
				if (is_wp_error($adset_status)) {
					return self::wrap_partial_create_error(
						new WP_Error(
							'meta_reuse_status_unverified',
							__('One or more saved Meta ad sets could not be verified as paused. Review them in Ads Manager before retrying Create in Meta (PAUSED).', 'vms-meta-ads'),
							array('status' => 409)
						),
						$existing_ids,
						$settings,
						$status_snapshot
					);
				}
				$status_snapshot['adsets'][] = $adset_status;
				if (!self::is_verified_paused_status((array) $adset_status)) {
					return self::wrap_partial_create_error(
						new WP_Error(
							'meta_reuse_not_paused',
							__('One or more saved Meta ad sets are not safely paused. Review or clean them up in Ads Manager before retrying Create in Meta (PAUSED).', 'vms-meta-ads'),
							array('status' => 409)
						),
						$existing_ids,
						$settings,
						$status_snapshot
					);
				}
			}

			foreach ((array) $known['ad_ids'] as $ad_id) {
				$ad_status = self::fetch_object_status((string) $ad_id, $settings);
				if (is_wp_error($ad_status)) {
					return self::wrap_partial_create_error(
						new WP_Error(
							'meta_reuse_status_unverified',
							__('One or more saved Meta ads could not be verified as paused. Review them in Ads Manager before retrying Create in Meta (PAUSED).', 'vms-meta-ads'),
							array('status' => 409)
						),
						$existing_ids,
						$settings,
						$status_snapshot
					);
				}
				$status_snapshot['ads'][] = $ad_status;
				if (!self::is_verified_paused_status((array) $ad_status)) {
					return self::wrap_partial_create_error(
						new WP_Error(
							'meta_reuse_not_paused',
							__('One or more saved Meta ads are not safely paused. Review or clean them up in Ads Manager before retrying Create in Meta (PAUSED).', 'vms-meta-ads'),
							array('status' => 409)
						),
						$existing_ids,
						$settings,
						$status_snapshot
					);
				}
			}

			return $status_snapshot;
		}

		private static function is_verified_paused_status(array $status_row): bool
		{
			$configured = self::configured_status_value($status_row);
			$effective = self::effective_status_value($status_row);
			return $configured === self::STATUS_PAUSED && self::is_safe_inactive_status_value($effective);
		}

		private static function build_known_meta_ids_payload(array $ids): array
		{
			$campaign_id = sanitize_text_field((string) ($ids['campaign_id'] ?? ''));
			$adset_ids = !empty($ids['adset_ids']) && is_array($ids['adset_ids']) ? array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) $ids['adset_ids'])))) : array();
			$adset_id = sanitize_text_field((string) ($ids['adset_id'] ?? ''));
			if ($adset_id !== '' && !in_array($adset_id, $adset_ids, true)) {
				array_unshift($adset_ids, $adset_id);
			}
			$creative_ids = !empty($ids['creative_ids']) && is_array($ids['creative_ids']) ? array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) $ids['creative_ids'])))) : array();
			$creative_id = sanitize_text_field((string) ($ids['creative_id'] ?? ''));
			if ($creative_id !== '' && !in_array($creative_id, $creative_ids, true)) {
				array_unshift($creative_ids, $creative_id);
			}
			$ad_ids = !empty($ids['ad_ids']) && is_array($ids['ad_ids']) ? array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) $ids['ad_ids'])))) : array();
			$ad_id = sanitize_text_field((string) ($ids['ad_id'] ?? ''));
			if ($ad_id !== '' && !in_array($ad_id, $ad_ids, true)) {
				array_unshift($ad_ids, $ad_id);
			}

			return array(
				'campaign_id' => $campaign_id,
				'adset_id' => (string) ($adset_ids[0] ?? ''),
				'adset_ids' => $adset_ids,
				'creative_id' => (string) ($creative_ids[0] ?? ''),
				'creative_ids' => $creative_ids,
				'ad_id' => (string) ($ad_ids[0] ?? ''),
				'ad_ids' => $ad_ids,
			);
		}

		private static function build_manual_cleanup_guidance(array $known_meta_ids, string $open_in_meta_url, bool $has_any_id): array
		{
			if (!$has_any_id) {
				return array(
					__('No Meta object IDs were confirmed before this error. Review the connection and create confirmation details before retrying.', 'vms-meta-ads'),
				);
			}

			$guidance = array(
				__('Real paused Meta objects may already exist from this attempt. Review the known IDs below in Ads Manager before retrying.', 'vms-meta-ads'),
				__('If you do not want to keep those Meta objects, manually archive or delete them in Ads Manager before retrying Create in Meta (PAUSED).', 'vms-meta-ads'),
				__('Reset Meta Link only unlinks the local IDs. It does not delete or archive Meta campaign, ad set, ad, or creative objects.', 'vms-meta-ads'),
			);
			if ($open_in_meta_url !== '' && $open_in_meta_url !== 'https://adsmanager.facebook.com/') {
				$guidance[] = __('Use the saved Ads Manager link to review the affected ad account before retrying.', 'vms-meta-ads');
			}
			return $guidance;
		}

		private static function wrap_partial_create_error(WP_Error $error, array $ids, ?array $settings = null, array $status_snapshot = array()): WP_Error
		{
			$data = $error->get_error_data();
			if (!is_array($data)) {
				$data = array();
			}

			$known_meta_ids = self::build_known_meta_ids_payload($ids);
			$has_any_id = !empty($known_meta_ids['campaign_id']) || !empty($known_meta_ids['adset_ids']) || !empty($known_meta_ids['creative_ids']) || !empty($known_meta_ids['ad_ids']);
			$ad_account_id = is_array($settings) ? ltrim((string) ($settings['meta_ad_account_id'] ?? ''), 'act_') : '';
			$open_in_meta_url = $ad_account_id !== '' ? self::build_ads_manager_url($ad_account_id) : 'https://adsmanager.facebook.com/';

			$data['status'] = (int) ($data['status'] ?? 502);
			$data['partial_create'] = $has_any_id ? 1 : 0;
			$data['known_meta_ids'] = $known_meta_ids;
			$data['cleanup_guidance'] = self::build_manual_cleanup_guidance($known_meta_ids, $open_in_meta_url, $has_any_id);
			$data['reset_meta_link_warning'] = __('Reset Meta Link only unlinks local IDs. It does not delete or archive Meta objects in Ads Manager.', 'vms-meta-ads');
			$data['open_in_meta_url'] = $open_in_meta_url;
			$data['expected_status'] = self::STATUS_PAUSED;
			if (!empty($status_snapshot)) {
				$data['status_snapshot'] = $status_snapshot;
			}

			return new WP_Error($error->get_error_code(), $error->get_error_message(), $data);
		}

		private static function build_create_signature(array $build): string
		{
			$signature_payload = array(
				'event_plan_id' => (int) ($build['event_plan_id'] ?? 0),
				'objective_meta' => (string) ($build['objective_meta'] ?? ''),
				'creative_mode' => (string) ($build['creative_mode'] ?? ''),
				'destination_url' => (string) ($build['destination_url'] ?? ''),
				'utm_url' => (string) ($build['utm_url'] ?? ''),
				'copy_payload' => (array) ($build['copy_payload'] ?? array()),
				'targeting_payload' => (array) ($build['targeting_payload'] ?? array()),
				'budget_payload' => (array) ($build['budget_payload'] ?? array()),
				'schedule_payload' => (array) ($build['schedule_payload'] ?? array()),
				'placements_payload' => (array) ($build['placements_payload'] ?? array()),
				'tiers' => !empty($build['tiers']) && is_array($build['tiers']) ? array_values((array) $build['tiers']) : array(),
			);

			$json = wp_json_encode($signature_payload);
			return is_string($json) ? hash('sha256', $json) : '';
		}

		private static function clear_existing_create_ids_for_recreate(array $build, array $existing_ids, string $reason)
		{
			$persisted = self::persist_create_ids(
				$build,
				array(
					'campaign_id' => '',
					'adset_id' => '',
					'creative_id' => '',
					'ad_id' => '',
					'creative_ids' => array(),
					'ad_ids' => array(),
					'ad_variants_meta' => array(),
					'adset_ids' => array(),
					'adsets_meta' => array(),
					'campaign_recipe' => '',
				),
				'',
				'draft',
				''
			);
			if (is_wp_error($persisted)) {
				return $persisted;
			}

			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			if ($event_plan_id > 0) {
				foreach (array(
					'vms_ma_meta_campaign_id',
					'vms_ma_meta_adset_id',
					'vms_ma_meta_ad_id',
					'vms_ma_meta_created_local',
					'vms_ma_meta_status',
					'vms_ma_meta_last_status_snapshot_json',
				) as $meta_key) {
					delete_post_meta($event_plan_id, $meta_key);
				}
				self::append_event_log($event_plan_id, array(
					'local_timestamp' => self::current_local_time(),
					'action' => 'clear_for_recreate',
					'outcome' => 'ok',
					'reason' => sanitize_key($reason),
					'previous_ids' => is_array($existing_ids) ? $existing_ids : array(),
					'user_id' => get_current_user_id(),
				));
			}

			vms_ma_log('meta_create_ids_cleared_for_recreate', array(
				'build_id' => (int) ($build['id'] ?? 0),
				'event_plan_id' => $event_plan_id,
				'reason' => sanitize_key($reason),
				'previous_ids' => is_array($existing_ids) ? $existing_ids : array(),
			), (int) ($build['id'] ?? 0));

			return true;
		}



		private static function sanitize_meta_summary(array $summary): array
		{
			$clean = array();
			$text_fields = array(
				'source_of_truth',
				'adoption_source',
				'campaign_id',
				'campaign_name',
				'campaign_status',
				'adset_id',
				'adset_name',
				'adset_status',
				'audience_summary',
				'budget_type',
				'updated_local',
				'adopted_local',
			);
			foreach ($text_fields as $field) {
				if (isset($summary[$field])) {
					$clean[$field] = sanitize_text_field((string) $summary[$field]);
				}
			}
			foreach (array('budget_minor', 'ad_count', 'score') as $field) {
				if (isset($summary[$field])) {
					$clean[$field] = absint($summary[$field]);
				}
			}
			return $clean;
		}

		private static function build_adoption_summary(array $build, array $ids, array $settings, array $payload = array()): array
		{
			$payload_summary = is_array($payload['candidate'] ?? null) ? (array) $payload['candidate'] : array();
			$campaign_id = sanitize_text_field((string) ($ids['campaign_id'] ?? ''));
			$adset_id = sanitize_text_field((string) ($ids['adset_id'] ?? ''));
			$adset_state = $adset_id !== '' ? self::fetch_adset_state($adset_id, $settings) : null;

			$budget_minor = absint($payload_summary['budget_minor'] ?? 0);
			$budget_type = sanitize_text_field((string) ($payload_summary['budget_type'] ?? ''));
			$adset_name = sanitize_text_field((string) ($payload_summary['adset_name'] ?? ''));
			$adset_status = sanitize_text_field((string) ($payload_summary['adset_status'] ?? ''));
			$audience_summary = sanitize_text_field((string) ($payload_summary['audience_summary'] ?? ''));

			if (is_array($adset_state)) {
				$adset_name = sanitize_text_field((string) ($adset_state['name'] ?? $adset_name));
				$adset_status = sanitize_text_field((string) (($adset_state['effective_status'] ?? '') ?: ($adset_state['configured_status'] ?? $adset_status)));
				$budget_minor = absint($adset_state['budget_minor'] ?? $budget_minor);
				if ($budget_type === '') {
					$budget_type = absint($adset_state['lifetime_budget'] ?? 0) > 0 ? 'lifetime' : (absint($adset_state['daily_budget'] ?? 0) > 0 ? 'daily' : '');
				}
				$audience_summary = self::summarize_meta_targeting(is_array($adset_state['targeting'] ?? null) ? (array) $adset_state['targeting'] : array());
			}

			return self::sanitize_meta_summary(array(
				'source_of_truth' => 'meta',
				'adoption_source' => 'existing_meta_campaign',
				'campaign_id' => $campaign_id,
				'campaign_name' => sanitize_text_field((string) ($payload_summary['campaign_name'] ?? '')),
				'campaign_status' => sanitize_text_field((string) ($payload_summary['campaign_status'] ?? '')),
				'adset_id' => $adset_id,
				'adset_name' => $adset_name,
				'adset_status' => $adset_status,
				'audience_summary' => $audience_summary,
				'budget_minor' => $budget_minor,
				'budget_type' => $budget_type,
				'ad_count' => absint($payload_summary['ad_count'] ?? count((array) ($ids['ad_ids'] ?? array()))),
				'score' => absint($payload_summary['score'] ?? 0),
				'adopted_local' => self::current_local_time(),
			));
		}

		private static function persist_create_ids(array $build, array $ids, string $error_message, string $build_status, string $tier_status)
		{
			global $wpdb;
			$build_id = (int) ($build['id'] ?? 0);
			if ($build_id < 1) {
				return new WP_Error('invalid_build', __('Invalid build for Meta create persistence.', 'vms-meta-ads'));
			}
			$now = current_time('mysql', true);
			$creative_ids = !empty($ids['creative_ids']) && is_array($ids['creative_ids']) ? array_values(array_filter(array_map('sanitize_text_field', (array) $ids['creative_ids']))) : array();
			$ad_ids = !empty($ids['ad_ids']) && is_array($ids['ad_ids']) ? array_values(array_filter(array_map('sanitize_text_field', (array) $ids['ad_ids']))) : array();
			$adset_ids = !empty($ids['adset_ids']) && is_array($ids['adset_ids']) ? array_values(array_filter(array_map('sanitize_text_field', (array) $ids['adset_ids']))) : array();
			if (empty($adset_ids) && !empty($ids['adset_id'])) {
				$adset_ids[] = sanitize_text_field((string) $ids['adset_id']);
			}
			$variant_meta = !empty($ids['ad_variants_meta']) && is_array($ids['ad_variants_meta']) ? array_values((array) $ids['ad_variants_meta']) : array();
			$adsets_meta = array();
			if (!empty($ids['adsets_meta']) && is_array($ids['adsets_meta'])) {
				foreach ((array) $ids['adsets_meta'] as $key => $row) {
					if (!is_array($row)) {
						continue;
					}
					$adset_key = sanitize_key((string) ($row['key'] ?? $key));
					if ($adset_key === '') {
						$adset_key = 'adset_' . (count($adsets_meta) + 1);
					}
					$adsets_meta[$adset_key] = array(
						'key' => $adset_key,
						'label' => sanitize_text_field((string) ($row['label'] ?? '')),
						'adset_id' => sanitize_text_field((string) ($row['adset_id'] ?? '')),
					);
				}
			}
			$campaign_recipe = sanitize_key((string) ($ids['campaign_recipe'] ?? ''));
			$meta_ids = array(
				'campaign_id' => (string) ($ids['campaign_id'] ?? ''),
				'adset_id' => (string) ($ids['adset_id'] ?? ($adset_ids[0] ?? '')),
				'adset_ids' => $adset_ids,
				'adsets_meta' => $adsets_meta,
				'campaign_recipe' => $campaign_recipe,
				'creative_id' => (string) ($ids['creative_id'] ?? ($creative_ids[0] ?? '')),
				'ad_id' => (string) ($ids['ad_id'] ?? ($ad_ids[0] ?? '')),
				'creative_ids' => $creative_ids,
				'ad_ids' => $ad_ids,
				'ad_variants_meta' => $variant_meta,
				'meta_signature' => self::build_create_signature($build),
				'created_local' => self::current_local_time(),
			);
			if (!empty($ids['dsa_payload']) && is_array($ids['dsa_payload'])) {
				$meta_ids['dsa_payload'] = array(
					'dsa_beneficiary' => sanitize_text_field((string) ($ids['dsa_payload']['dsa_beneficiary'] ?? '')),
					'dsa_payor' => sanitize_text_field((string) ($ids['dsa_payload']['dsa_payor'] ?? '')),
				);
			}

			foreach (array('adoption_source', 'source_of_truth', 'adopted_local') as $extra_key) {
				if (!empty($ids[$extra_key])) {
					$meta_ids[$extra_key] = sanitize_text_field((string) $ids[$extra_key]);
				}
			}
			if (!empty($ids['adopted_summary']) && is_array($ids['adopted_summary'])) {
				$meta_ids['adopted_summary'] = self::sanitize_meta_summary((array) $ids['adopted_summary']);
			}

			$updated = $wpdb->update(
				$wpdb->prefix . 'vms_meta_ads_builds',
				array(
					'meta_campaign_id' => $meta_ids['campaign_id'] !== '' ? $meta_ids['campaign_id'] : null,
					'meta_ids' => wp_json_encode($meta_ids),
					'status' => $build_status,
					'error_message' => $error_message !== '' ? $error_message : null,
					'updated_at' => $now,
				),
				array('id' => $build_id),
				array('%s', '%s', '%s', '%s', '%s'),
				array('%d')
			);
			if ($updated === false) {
				return new WP_Error('db_update_failed', __('Unable to persist Meta IDs on build.', 'vms-meta-ads'));
			}

			$tier_id = (int) $wpdb->get_var($wpdb->prepare(
				'SELECT id FROM ' . $wpdb->prefix . 'vms_meta_ads_tiers WHERE build_id = %d ORDER BY start_time ASC LIMIT 1',
				$build_id
			));
			if ($tier_id > 0) {
				$wpdb->update(
					$wpdb->prefix . 'vms_meta_ads_tiers',
					array(
						'meta_adset_id' => $meta_ids['adset_id'] !== '' ? $meta_ids['adset_id'] : null,
						'meta_creative_id' => $meta_ids['creative_id'] !== '' ? $meta_ids['creative_id'] : null,
						'meta_ad_id' => $meta_ids['ad_id'] !== '' ? $meta_ids['ad_id'] : null,
						'meta_status' => $tier_status !== '' ? $tier_status : null,
						'last_error' => $error_message !== '' ? $error_message : null,
						'updated_at' => $now,
					),
					array('id' => $tier_id),
					array('%s', '%s', '%s', '%s', '%s', '%s'),
					array('%d')
				);
			}

			return true;
		}

		private static function resolve_create_tier(array $build)
		{
			if (empty($build['tiers']) || !is_array($build['tiers'])) {
				return new WP_Error('missing_tier', __('No schedule tier exists. Save draft again before creating in Meta.', 'vms-meta-ads'), array('status' => 400));
			}
			$tiers = (array) $build['tiers'];
			usort($tiers, static function ($a, $b): int {
				$left = is_array($a) ? (string) ($a['start_time'] ?? '') : '';
				$right = is_array($b) ? (string) ($b['start_time'] ?? '') : '';
				return strcmp($left, $right);
			});
			$tier = is_array($tiers[0] ?? null) ? (array) $tiers[0] : array();
			if (empty($tier['start_time']) || empty($tier['end_time'])) {
				return new WP_Error('missing_tier_dates', __('Tier dates are missing. Save draft again before creating in Meta.', 'vms-meta-ads'), array('status' => 400));
			}
			return $tier;
		}

		private static function resolve_build_optimization(array $build): string
		{
			if (sanitize_key((string) ($build['goal'] ?? '')) === 'sales' || strtoupper((string) ($build['objective_meta'] ?? '')) === 'OUTCOME_SALES') {
				return 'purchase_conversions';
			}
			$copy_payload = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
			$recipe_payload = is_array($copy_payload['campaign_recipe_payload'] ?? null) ? (array) $copy_payload['campaign_recipe_payload'] : array();
			$candidate = sanitize_key((string) ($recipe_payload['optimization'] ?? ''));
			if (in_array($candidate, array('landing_page_views', 'link_clicks', 'purchase_conversions'), true)) {
				return $candidate;
			}
			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			if ($event_plan_id > 0) {
				$draft_raw = (string) get_post_meta($event_plan_id, 'vms_ma_last_draft_json', true);
				if ($draft_raw !== '') {
					$decoded = json_decode($draft_raw, true);
					if (is_array($decoded)) {
						$candidate = sanitize_key((string) ($decoded['optimization'] ?? ''));
						if (in_array($candidate, array('landing_page_views', 'link_clicks', 'purchase_conversions'), true)) {
							return $candidate;
						}
					}
				}
			}
			return 'link_clicks';
		}

		private static function maybe_clear_stale_existing_create_ids(array $build, array $existing_ids)
		{
			$campaign_id = sanitize_text_field((string) ($existing_ids['campaign_id'] ?? ''));
			$adset_id    = sanitize_text_field((string) ($existing_ids['adset_id'] ?? ''));
			$creative_id = sanitize_text_field((string) ($existing_ids['creative_id'] ?? ''));
			$ad_id       = sanitize_text_field((string) ($existing_ids['ad_id'] ?? ''));

			if ($campaign_id === '') {
				return false;
			}

			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$event_plan_id = (int) ($build['event_plan_id'] ?? 0);
			$build_id      = (int) ($build['id'] ?? 0);
			$meta_key_status = 'vms_ma_meta_status';
			$meta_key_campaign_id = 'vms_ma_meta_campaign_id';
			$meta_key_adset_id = 'vms_ma_meta_adset_id';
			$meta_key_ad_id = 'vms_ma_meta_ad_id';

			// 1) Campaign missing: clear everything.
			$exists = self::meta_object_exists($campaign_id, $settings);
			if (is_wp_error($exists)) {
				return $exists;
			}
			if (!$exists) {
				$blank_ids = array(
					'campaign_id' => '',
					'adset_id'    => '',
					'creative_id' => '',
					'ad_id'       => '',
				);
				self::persist_create_ids($build, $blank_ids, '', '', '');
				if ($event_plan_id > 0) {
					delete_post_meta($event_plan_id, $meta_key_campaign_id);
					delete_post_meta($event_plan_id, $meta_key_adset_id);
					delete_post_meta($event_plan_id, $meta_key_ad_id);
					delete_post_meta($event_plan_id, $meta_key_status);
				}
				vms_ma_log('meta_create_stale_ids_cleared', array(
					'build_id' => $build_id,
					'reason' => 'campaign_missing',
					'campaign_id' => $campaign_id,
				), true);
				return true;
			}

			// 2) Ad set missing: keep campaign, clear downstream.
			if ($adset_id !== '') {
				$exists = self::meta_object_exists($adset_id, $settings);
				if (is_wp_error($exists)) {
					return $exists;
				}
				if (!$exists) {
					$new_ids = array(
						'campaign_id' => $campaign_id,
						'adset_id'    => '',
						'creative_id' => '',
						'ad_id'       => '',
					);
					self::persist_create_ids($build, $new_ids, '', '', '');
					if ($event_plan_id > 0) {
						delete_post_meta($event_plan_id, $meta_key_adset_id);
						delete_post_meta($event_plan_id, $meta_key_ad_id);
						delete_post_meta($event_plan_id, $meta_key_status);
					}
					vms_ma_log('meta_create_stale_ids_cleared', array(
						'build_id' => $build_id,
						'reason' => 'adset_missing',
						'adset_id' => $adset_id,
						'campaign_id' => $campaign_id,
					), true);
					return true;
				}
			}

			// 3) Creative missing: keep campaign + adset, clear downstream.
			if ($creative_id !== '') {
				$exists = self::meta_object_exists($creative_id, $settings);
				if (is_wp_error($exists)) {
					return $exists;
				}
				if (!$exists) {
					$new_ids = array(
						'campaign_id' => $campaign_id,
						'adset_id'    => $adset_id,
						'creative_id' => '',
						'ad_id'       => '',
					);
					self::persist_create_ids($build, $new_ids, '', '', '');
					if ($event_plan_id > 0) {
						delete_post_meta($event_plan_id, $meta_key_ad_id);
						delete_post_meta($event_plan_id, $meta_key_status);
					}
					vms_ma_log('meta_create_stale_ids_cleared', array(
						'build_id' => $build_id,
						'reason' => 'creative_missing',
						'creative_id' => $creative_id,
						'campaign_id' => $campaign_id,
					), true);
					return true;
				}
			}

			// 4) Ad missing: keep upstream, clear ad only.
			if ($ad_id !== '') {
				$exists = self::meta_object_exists($ad_id, $settings);
				if (is_wp_error($exists)) {
					return $exists;
				}
				if (!$exists) {
					$new_ids = array(
						'campaign_id' => $campaign_id,
						'adset_id'    => $adset_id,
						'creative_id' => $creative_id,
						'ad_id'       => '',
					);
					self::persist_create_ids($build, $new_ids, '', '', '');
					if ($event_plan_id > 0) {
						delete_post_meta($event_plan_id, $meta_key_ad_id);
						delete_post_meta($event_plan_id, $meta_key_status);
					}
					vms_ma_log('meta_create_stale_ids_cleared', array(
						'build_id' => $build_id,
						'reason' => 'ad_missing',
						'ad_id' => $ad_id,
						'campaign_id' => $campaign_id,
					), true);
					return true;
				}
			}

			return false;
		}
 
		private static function map_optimization_goal(string $optimization): string
		{
			if ($optimization === 'purchase_conversions') {
				return 'OFFSITE_CONVERSIONS';
			}
			return $optimization === 'landing_page_views' ? 'LANDING_PAGE_VIEWS' : 'LINK_CLICKS';
		}

		private static function build_promoted_object_for_goal(string $goal, string $objective, array $settings)
		{
			$is_sales = sanitize_key($goal) === 'sales' || strtoupper($objective) === 'OUTCOME_SALES';
			if (!$is_sales) {
				return array();
			}
			$pixel_id = preg_replace('/[^0-9]/', '', (string) ($settings['meta_pixel_id'] ?? ''));
			if ($pixel_id === '') {
				return new WP_Error(
					'missing_meta_pixel_id',
					__('Sales / Ticket Purchases needs a Meta Pixel or Dataset ID before creating in Meta. Add it in MAB Settings, save, then return to this draft.', 'vms-meta-ads'),
					array('status' => 400)
				);
			}
			return array(
				'pixel_id' => $pixel_id,
				'custom_event_type' => 'PURCHASE',
			);
		}

		private static function dsa_readiness(array $settings): array
		{
			$beneficiary = sanitize_text_field((string) ($settings['meta_dsa_beneficiary'] ?? ''));
			$payor = sanitize_text_field((string) ($settings['meta_dsa_payor'] ?? ''));
			$warnings = array();
			if ($beneficiary === '') {
				$warnings[] = __('DSA beneficiary is blank. Meta review may require Advertiser / Beneficiary details before publish.', 'vms-meta-ads');
			}
			if ($payor === '') {
				$warnings[] = __('DSA payor is blank. Meta review may require Payer / Payor details before publish.', 'vms-meta-ads');
			}
			return array(
				'beneficiary' => $beneficiary,
				'payor' => $payor,
				'has_beneficiary' => ($beneficiary !== ''),
				'has_payor' => ($payor !== ''),
				'ready' => ($beneficiary !== '' && $payor !== ''),
				'warnings' => $warnings,
			);
		}

		private static function attach_dsa_payload_marker(array $ids, array $settings): array
		{
			$payload = self::adset_dsa_payload($settings);
			if (!empty($payload)) {
				$ids['dsa_payload'] = array(
					'dsa_beneficiary' => sanitize_text_field((string) ($payload['dsa_beneficiary'] ?? '')),
					'dsa_payor' => sanitize_text_field((string) ($payload['dsa_payor'] ?? '')),
				);
			}
			return $ids;
		}

		private static function adset_dsa_payload(array $settings): array
		{
			$dsa = self::dsa_readiness($settings);
			$payload = array();
			if (!empty($dsa['has_beneficiary'])) {
				$payload['dsa_beneficiary'] = (string) $dsa['beneficiary'];
			}
			if (!empty($dsa['has_payor'])) {
				$payload['dsa_payor'] = (string) $dsa['payor'];
			}
			return $payload;
		}

		private static function validate_dsa_publish_readiness(array $settings)
		{
			$dsa = self::dsa_readiness($settings);
			if (!empty($dsa['ready'])) {
				return $dsa;
			}
			return new WP_Error(
				'missing_dsa_readiness',
				__('DSA beneficiary and payor must be filled in before Go Live. Add them in Meta Ads Settings, then retry after another read-only status check.', 'vms-meta-ads'),
				array(
					'status' => 400,
					'readiness' => $dsa,
				)
			);
		}

		private static function adset_promoted_object_payload(array $promoted_object): array
		{
			if (empty($promoted_object)) {
				return array();
			}
			return array('promoted_object' => wp_json_encode($promoted_object));
		}

		private static function meta_object_exists(string $object_id, array $settings)
		{
			$object_id = trim($object_id);
			if ($object_id === '') {
				return false;
			}

			$response = self::meta_get_request(
				$settings,
				$object_id,
				array('fields' => 'id,status,configured_status,effective_status'),
				'verify_existing_object',
				'ad_builder'
			);
			if (is_wp_error($response)) {
				return new WP_Error(
					'existing_id_check_failed',
					__('Could not verify existing Meta object IDs before create.', 'vms-meta-ads'),
					array('status' => 409)
				);
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code >= 200 && $code < 300 && is_array($body) && !empty($body['id'])) {
				$configured = strtoupper(sanitize_text_field((string) ($body['configured_status'] ?? $body['status'] ?? '')));
				$effective = strtoupper(sanitize_text_field((string) ($body['effective_status'] ?? $configured)));
				if (
					$configured === 'ARCHIVED'
					|| $configured === 'DELETED'
					|| $effective === 'ARCHIVED'
					|| $effective === 'DELETED'
				) {
					return false;
				}
				return true;
			}
			if (is_array($body) && isset($body['error'])) {
				$meta_error = self::extract_meta_error($body, $code);
				$message = strtolower((string) ($meta_error['message'] ?? ''));
				$error_code = (int) ($meta_error['code'] ?? 0);
				if (
					$error_code === 803
					|| strpos($message, 'does not exist') !== false
					|| strpos($message, 'unsupported get request') !== false
					|| strpos($message, 'cannot be loaded') !== false
				) {
					return false;
				}
				return new WP_Error(
					'existing_id_check_failed',
					__('Meta ID verification failed before create. Resolve Meta permissions/app mode and retry.', 'vms-meta-ads'),
					array('status' => 409, 'meta' => $meta_error)
				);
			}
			return new WP_Error(
				'existing_id_check_failed',
				__('Meta ID verification returned an unexpected response.', 'vms-meta-ads'),
				array('status' => 409)
			);
		}

		private static function summarize_targeting(array $targeting_payload): string
		{
			$radius = max(1, absint($targeting_payload['radius_miles'] ?? 15));
			$age_min = max(13, absint($targeting_payload['age_min'] ?? 21));
			$age_max = max($age_min, absint($targeting_payload['age_max'] ?? 65));
			return sprintf('Radius %dmi | Ages %d-%d', $radius, $age_min, $age_max);
		}

		private static function resolve_effective_placements_for_create(array $placements_payload, string $ig_actor_id)
		{
			$mode = sanitize_key((string) ($placements_payload['mode'] ?? 'automatic'));
			$placements = !empty($placements_payload['placements']) && is_array($placements_payload['placements']) ? array_values(array_map('sanitize_key', $placements_payload['placements'])) : array();
			$warnings = array();

			if ($mode !== 'manual') {
				$warnings[] = __('Automatic placements are selected. Meta may imply broader placement coverage in Ads Manager than the FB/IG ticket-sales preset shown here. Recheck placement coverage before any Go Live step.', 'vms-meta-ads');
			}

			if ($ig_actor_id !== '') {
				return array(
					'placements_payload' => $placements_payload,
					'warnings' => $warnings,
				);
			}

			if ($mode !== 'manual') {
				$resolved = $placements_payload;
				$resolved['mode'] = 'manual';
				$resolved['placements'] = array('fb_feed', 'fb_profile_feed', 'fb_right_column', 'fb_story', 'fb_reels', 'fb_search');
				$warnings[] = __('No Instagram account is connected to the selected Facebook Page, so this ad was limited to Facebook placements for creation. Connect an Instagram account in Settings to use Instagram placements.', 'vms-meta-ads');
				return array(
					'placements_payload' => $resolved,
					'warnings' => $warnings,
				);
			}

			$instagram_keys = array('ig_feed', 'ig_story', 'ig_reels', 'ig_search', 'ig_explore');
			$had_instagram = false;
			$filtered = array();
			foreach ($placements as $placement) {
				if (in_array($placement, $instagram_keys, true)) {
					$had_instagram = true;
					continue;
				}
				$filtered[] = $placement;
			}

			if (!$had_instagram) {
				return array(
					'placements_payload' => $placements_payload,
					'warnings' => $warnings,
				);
			}

			$filtered = array_values(array_unique($filtered));
			if (empty($filtered)) {
				return new WP_Error(
					'missing_instagram_account_for_manual_placements',
					__('Instagram placements are selected, but no Instagram account is connected to the selected Facebook Page. Connect an Instagram account in Settings or select at least one Facebook placement and try again.', 'vms-meta-ads'),
					array('status' => 400)
				);
			}

			$warnings[] = __('Instagram placements were skipped because no Instagram account is connected to the selected Facebook Page. Connect one in Settings to enable IG Feed, Story, Reels, Explore, and Search placements.', 'vms-meta-ads');

			$resolved = $placements_payload;
			$resolved['mode'] = 'manual';
			$resolved['placements'] = $filtered;

			return array(
				'placements_payload' => $resolved,
				'warnings' => $warnings,
			);
		}

		private static function resolve_asset_feed_placement_matrix(array $placements_payload, bool $has_ig_actor): array
		{
			$matrix = array(
				'fb_feed' => true,
				'fb_profile_feed' => true,
				'fb_right_column' => true,
				'fb_search' => true,
				'fb_story' => true,
				'fb_reels' => true,
				'ig_feed' => $has_ig_actor,
				'ig_search' => $has_ig_actor,
				'ig_explore' => $has_ig_actor,
				'ig_story' => $has_ig_actor,
				'ig_reels' => $has_ig_actor,
			);

			$mode = sanitize_key((string) ($placements_payload['mode'] ?? 'automatic'));
			$placements = !empty($placements_payload['placements']) && is_array($placements_payload['placements']) ? array_values(array_map('sanitize_key', $placements_payload['placements'])) : array();
			if ($mode !== 'manual' || empty($placements)) {
				return $matrix;
			}

			foreach ($matrix as $key => $enabled) {
				$matrix[$key] = in_array($key, $placements, true);
			}

			if (!empty($matrix['ig_search']) && empty($matrix['ig_feed'])) {
				$matrix['ig_feed'] = true;
			}

			if (!$has_ig_actor) {
				$matrix['ig_feed'] = false;
				$matrix['ig_search'] = false;
				$matrix['ig_explore'] = false;
				$matrix['ig_story'] = false;
				$matrix['ig_reels'] = false;
			}

			return $matrix;
		}

		private static function build_asset_customization_spec(array $publisher_platforms, array $facebook_positions = array(), array $instagram_positions = array()): array
		{
			$publisher_platforms = array_values(array_unique(array_filter(array_map('sanitize_key', $publisher_platforms))));
			$facebook_positions = array_values(array_unique(array_filter(array_map('sanitize_key', $facebook_positions))));
			$instagram_positions = array_values(array_unique(array_filter(array_map('sanitize_key', $instagram_positions))));

			$spec = array();
			if (!empty($publisher_platforms)) {
				$spec['publisher_platforms'] = $publisher_platforms;
			}
			if (!empty($facebook_positions)) {
				$spec['facebook_positions'] = $facebook_positions;
			}
			if (!empty($instagram_positions)) {
				$spec['instagram_positions'] = $instagram_positions;
			}
			return $spec;
		}

		private static function build_creative_request_blueprint(array $preflight, array $variant, array $images): array
		{
			$square = is_array($images['square'] ?? null) ? (array) $images['square'] : array();
			$vertical = is_array($images['vertical'] ?? null) ? (array) $images['vertical'] : array();
			$wide = is_array($images['wide'] ?? null) ? (array) $images['wide'] : array();
			$square_url = trim((string) ($square['url'] ?? ''));
			$vertical_url = trim((string) ($vertical['url'] ?? ''));
			$wide_url = trim((string) ($wide['url'] ?? ''));
			$square_hash = trim((string) ($square['hash'] ?? ''));
			$vertical_hash = trim((string) ($vertical['hash'] ?? ''));
			$wide_hash = trim((string) ($wide['hash'] ?? ''));
			$feed_url = $square_url !== '' ? $square_url : $wide_url;
			$feed_hash = $square_hash !== '' ? $square_hash : $wide_hash;
			$use_asset_feed = (($vertical_hash !== '' || $vertical_url !== '') && ($feed_hash !== '' || $feed_url !== '')
				&& (($vertical_hash !== '' && $vertical_hash !== $feed_hash) || ($vertical_url !== '' && $vertical_url !== $feed_url)));

			$creative_name = (string) ($variant['creative_name'] ?? 'Creative');
			$story_spec = array(
				'page_id' => (string) $preflight['page_id'],
				'link_data' => array(
					'link' => (string) $preflight['destination_url'],
					'message' => (string) ($variant['primary_text'] ?? ''),
					'name' => (string) ($variant['headline'] ?? ''),
					'description' => (string) ($variant['description'] ?? ''),
					'call_to_action' => array(
						'type' => (string) ($preflight['cta_type'] ?? 'LEARN_MORE'),
						'value' => array('link' => (string) $preflight['destination_url']),
					),
				),
			);
			if (!empty($preflight['ig_actor_id'])) {
				$story_spec['instagram_user_id'] = (string) $preflight['ig_actor_id'];
			}

			$picture = $feed_url !== '' ? $feed_url : ($vertical_url !== '' ? $vertical_url : ($wide_url !== '' ? $wide_url : ''));
			$image_hash = $feed_hash !== '' ? $feed_hash : ($vertical_hash !== '' ? $vertical_hash : ($wide_hash !== '' ? $wide_hash : ''));
			$single_image = array(
				'name' => $creative_name,
				'link_url' => (string) $preflight['destination_url'],
				'object_type' => 'SHARE',
				'object_story_spec' => '',
			);
			if ($image_hash !== '') {
				$story_spec['link_data']['image_hash'] = $image_hash;
			} elseif ($picture !== '') {
				$story_spec['link_data']['picture'] = $picture;
			}
			$single_image['object_story_spec'] = wp_json_encode($story_spec);

			$result = array(
				'asset_feed_with_rules' => $single_image,
				'asset_feed_without_rules' => array(),
				'single_image' => $single_image,
			);
			if (!$use_asset_feed) {
				return $result;
			}

			$images_spec = array();
			$labels_included = array();
			$placement_matrix = self::resolve_asset_feed_placement_matrix((array) ($preflight['effective_placements_payload'] ?? array()), !empty($preflight['ig_actor_id']));
			if ($feed_hash !== '' || $feed_url !== '') {
				$image_spec = array('adlabels' => array(array('name' => 'IMG_FEED')));
				if ($feed_hash !== '') {
					$image_spec['hash'] = $feed_hash;
				} elseif ($feed_url !== '') {
					$image_spec['url'] = $feed_url;
				}
				$images_spec[] = $image_spec;
				$labels_included['IMG_FEED'] = true;
			}
			if (($vertical_hash !== '' || $vertical_url !== '') && ($vertical_hash !== $feed_hash || $vertical_url !== $feed_url)) {
				$image_spec = array('adlabels' => array(array('name' => 'IMG_VERTICAL')));
				if ($vertical_hash !== '') {
					$image_spec['hash'] = $vertical_hash;
				} elseif ($vertical_url !== '') {
					$image_spec['url'] = $vertical_url;
				}
				$images_spec[] = $image_spec;
				$labels_included['IMG_VERTICAL'] = true;
			}
			if (($wide_hash !== '' || $wide_url !== '') && ($wide_hash !== $feed_hash || $wide_url !== $feed_url) && ($wide_hash !== $vertical_hash || $wide_url !== $vertical_url)) {
				$image_spec = array('adlabels' => array(array('name' => 'IMG_WIDE')));
				if ($wide_hash !== '') {
					$image_spec['hash'] = $wide_hash;
				} elseif ($wide_url !== '') {
					$image_spec['url'] = $wide_url;
				}
				$images_spec[] = $image_spec;
				$labels_included['IMG_WIDE'] = true;
			}
			$asset_rules = array();
			if (!empty($labels_included['IMG_VERTICAL'])) {
				$vertical_platforms = array();
				$vertical_fb_positions = array();
				$vertical_ig_positions = array();
				if (!empty($placement_matrix['fb_story']) || !empty($placement_matrix['fb_reels'])) {
					$vertical_platforms[] = 'facebook';
				}
				if (!empty($placement_matrix['fb_story'])) {
					$vertical_fb_positions[] = 'story';
				}
				if (!empty($placement_matrix['fb_reels'])) {
					$vertical_fb_positions[] = 'facebook_reels';
				}
				if (!empty($placement_matrix['ig_story']) || !empty($placement_matrix['ig_reels'])) {
					$vertical_platforms[] = 'instagram';
				}
				if (!empty($placement_matrix['ig_story'])) {
					$vertical_ig_positions[] = 'story';
				}
				if (!empty($placement_matrix['ig_reels'])) {
					$vertical_ig_positions[] = 'reels';
				}
				$vertical_spec = self::build_asset_customization_spec($vertical_platforms, $vertical_fb_positions, $vertical_ig_positions);
				if (!empty($vertical_spec)) {
					$asset_rules[] = array('customization_spec' => $vertical_spec, 'image_label' => array('name' => 'IMG_VERTICAL'));
				}
			}
			if (!empty($labels_included['IMG_WIDE'])) {
				// Keep the wide asset uploaded for future use, but do not bind it to the
				// Facebook right column. Right column should follow the 1:1 feed image so the
				// small desktop rendering stays consistent with the square asset.
			}
			if (!empty($labels_included['IMG_FEED'])) {
				$feed_platforms = array();
				$feed_fb_positions = array();
				$feed_ig_positions = array();
				if (!empty($placement_matrix['fb_feed'])) {
					$feed_platforms[] = 'facebook';
					$feed_fb_positions[] = 'feed';
				}
				if (!empty($placement_matrix['fb_profile_feed'])) {
					$feed_platforms[] = 'facebook';
					$feed_fb_positions[] = 'profile_feed';
				}
				if (!empty($placement_matrix['fb_right_column'])) {
					$feed_platforms[] = 'facebook';
					$feed_fb_positions[] = 'right_hand_column';
				}
				if (!empty($placement_matrix['fb_search'])) {
					$feed_platforms[] = 'facebook';
					$feed_fb_positions[] = 'search';
				}
				if (!empty($placement_matrix['ig_feed'])) {
					$feed_platforms[] = 'instagram';
					$feed_ig_positions[] = 'stream';
				}
				if (!empty($placement_matrix['ig_search'])) {
					$feed_platforms[] = 'instagram';
					$feed_ig_positions[] = 'ig_search';
				}
				if (!empty($placement_matrix['ig_explore'])) {
					$feed_platforms[] = 'instagram';
					$feed_ig_positions[] = 'explore';
				}
				$feed_spec = self::build_asset_customization_spec($feed_platforms, $feed_fb_positions, $feed_ig_positions);
				if (empty($feed_spec)) {
					$feed_spec = self::build_asset_customization_spec(array('facebook'), array('feed'), array());
				}
				$asset_rules[] = array('customization_spec' => $feed_spec, 'image_label' => array('name' => 'IMG_FEED'));
			}

			$asset_feed_spec = array(
				'ad_formats' => array('SINGLE_IMAGE'),
				'images' => $images_spec,
				'bodies' => array(array('text' => (string) ($variant['primary_text'] ?? ''))),
				'titles' => array(array('text' => (string) ($variant['headline'] ?? ''))),
				'descriptions' => array(array('text' => (string) ($variant['description'] ?? ''))),
				'link_urls' => array(array('website_url' => (string) $preflight['destination_url'])),
				'call_to_action_types' => array((string) ($preflight['cta_type'] ?? 'LEARN_MORE')),
			);
			$asset_story_spec = array(
				'page_id' => (string) $preflight['page_id'],
			);
			if (!empty($preflight['ig_actor_id'])) {
				$asset_story_spec['instagram_user_id'] = (string) $preflight['ig_actor_id'];
			}

			$with_rules = $asset_feed_spec;
			$with_rules['asset_customization_rules'] = $asset_rules;
			$without_rules = $asset_feed_spec;
			$result['asset_feed_with_rules'] = array(
				'name' => $creative_name,
				'link_url' => (string) $preflight['destination_url'],
				'object_story_spec' => wp_json_encode($asset_story_spec),
				'asset_feed_spec' => wp_json_encode($with_rules),
			);
			$result['asset_feed_without_rules'] = array(
				'name' => $creative_name,
				'link_url' => (string) $preflight['destination_url'],
				'object_story_spec' => wp_json_encode($asset_story_spec),
				'asset_feed_spec' => wp_json_encode($without_rules),
			);

			return $result;
		}

			private static function meta_post_creative_with_feature_fallbacks(array $settings, string $path, array $payload, array $preflight, string $operation, int $build_id = 0, bool $include_contextual_multi_ads = true)
			{
				$primary_payload = self::apply_creative_feature_opt_outs($settings, $payload, $preflight, $include_contextual_multi_ads);
				$response = self::meta_post(
					$settings,
					$path,
					$primary_payload,
					$operation,
					$build_id
				);
			if (!is_wp_error($response) || !self::is_degrees_of_freedom_unsupported($response)) {
				return $response;
			}

				if ($include_contextual_multi_ads) {
					$fallback_payload = self::apply_creative_feature_opt_outs($settings, $payload, $preflight, false);
					if ($fallback_payload === $primary_payload) {
						return $response;
					}
					$response = self::meta_post(
						$settings,
						$path,
						$fallback_payload,
						$operation . '_retry_without_contextual_multi_ads_opt_out',
						$build_id
					);
					if (!is_wp_error($response) || !self::is_degrees_of_freedom_unsupported($response)) {
					return $response;
				}
			}

			$response = self::meta_post(
				$settings,
				$path,
				$payload,
				$operation . '_retry_without_feature_opt_outs',
				$build_id
			);

				return $response;
			}

			private static function apply_creative_feature_opt_outs(array $settings, array $payload, array $preflight, bool $include_contextual_multi_ads = true): array
			{
				if (!empty($preflight['allow_multi_advertiser_ads'])) {
					return $payload;
				}
				if (!$include_contextual_multi_ads || !self::should_try_contextual_multi_ads_opt_out($settings, $preflight)) {
					return $payload;
				}
				$payload['degrees_of_freedom_spec'] = wp_json_encode(array(
					'creative_features_spec' => array(
						'contextual_multi_ads' => array('enroll_status' => 'OPT_OUT'),
					),
				));
				return $payload;
			}

			private static function should_try_contextual_multi_ads_opt_out(array $settings, array $preflight): bool
			{
				if (!empty($preflight['allow_multi_advertiser_ads'])) {
					return false;
				}
				$version = self::normalized_graph_version_number((string) ($settings['meta_graph_version'] ?? ''));
				$default_supported = ($version !== '' && version_compare($version, '24.0', '<'));
				return (bool) apply_filters('vms_ma_meta_contextual_multi_ads_opt_out_supported', $default_supported, $version, $settings, $preflight);
			}

			private static function normalized_graph_version_number(string $version): string
			{
				$version = strtolower(trim($version));
				$version = ltrim($version, 'v');
				return preg_match('/^\d+(?:\.\d+)?$/', $version) ? $version : '';
			}

		private static function is_degrees_of_freedom_unsupported(WP_Error $error): bool
		{
			$data = $error->get_error_data();
			$meta = (is_array($data) && !empty($data['meta']) && is_array($data['meta'])) ? (array) $data['meta'] : array();
			$message = strtolower((string) $error->get_error_message());
			$blame_field = strtolower((string) ($meta['blame_field'] ?? ''));
			return strpos($message, 'degrees_of_freedom_spec') !== false
				|| strpos($message, 'creative_features_spec') !== false
				|| strpos($message, 'contextual_multi_ads') !== false
				|| strpos($message, 'standard_enhancements') !== false
				|| strpos($message, 'standard enhancements') !== false
				|| strpos($message, 'enhancements field in creative has been deprecated') !== false
				|| strpos($message, 'choose to set individual features') !== false
				|| strpos($blame_field, 'degrees_of_freedom_spec') !== false
				|| strpos($blame_field, 'creative_features_spec') !== false;
		}

		private static function is_asset_customization_rules_unsupported(WP_Error $error): bool
		{
			$data = $error->get_error_data();
			$meta = (is_array($data) && !empty($data['meta']) && is_array($data['meta'])) ? (array) $data['meta'] : array();
			$message = strtolower((string) $error->get_error_message());
			$blame_field = strtolower((string) ($meta['blame_field'] ?? ''));
			$meta_code = (int) ($meta['code'] ?? 0);

			if ($meta_code !== 100) {
				return false;
			}
			if (strpos($message, 'asset customization rules') !== false && strpos($message, 'not supported') !== false) {
				return true;
			}
			return strpos($blame_field, 'asset_customization_rules') !== false;
		}

		private static function should_fallback_to_standard_creative(WP_Error $error): bool
		{
			if (self::is_asset_customization_rules_unsupported($error)) {
				return true;
			}

			$data = $error->get_error_data();
			$meta = (is_array($data) && !empty($data['meta']) && is_array($data['meta'])) ? (array) $data['meta'] : array();
			$message = strtolower((string) $error->get_error_message());
			$blame_field = strtolower((string) ($meta['blame_field'] ?? ''));
			$meta_code = (int) ($meta['code'] ?? 0);

			if ($meta_code !== 100) {
				return false;
			}
			if (strpos($blame_field, 'asset_feed_spec') !== false) {
				return true;
			}
			if (strpos($blame_field, 'object_story_spec') !== false && strpos($message, 'asset') !== false) {
				return true;
			}
			return strpos($message, 'asset feed') !== false
				|| strpos($message, 'dynamic creative') !== false
				|| strpos($message, 'object_story_spec') !== false;
		}

		private static function build_manual_targeting(array $settings, array $targeting_payload, array $placements_payload = array(), int $build_id = 0, int $event_plan_id = 0)
		{
			$age_min = max(13, absint($targeting_payload['age_min'] ?? 21));
			$age_max = max($age_min, absint($targeting_payload['age_max'] ?? 65));
			if ($age_max < $age_min) {
				$age_max = $age_min;
			}

			$targeting = array(
				'age_min' => $age_min,
				'age_max' => $age_max,
				// Meta now requires explicit audience automation intent on ad set targeting specs.
				// Keep manual audience behavior deterministic by opting out unless/until the builder exposes a user-facing toggle.
				'targeting_automation' => array(
					'advantage_audience' => 0,
				),
			);

			$geo_locations = self::build_targeting_geo_locations($settings, $targeting_payload, $build_id, $event_plan_id);
			if (is_wp_error($geo_locations)) {
				return $geo_locations;
			}
			$targeting['geo_locations'] = $geo_locations;

			$interest_ids = array();
			if (!empty($targeting_payload['interests']) && is_array($targeting_payload['interests'])) {
				foreach ((array) $targeting_payload['interests'] as $id) {
					$id = trim((string) $id);
					if ($id !== '' && ctype_digit($id)) {
						$interest_ids[] = $id;
					}
				}
			}
			if (!empty($interest_ids)) {
				$targeting['flexible_spec'] = array(
					array(
						'interests' => array_map(function ($id) {
							return array('id' => (string) $id);
						}, $interest_ids),
					),
				);
			}

			$placements_mode = (string) ($placements_payload['mode'] ?? 'automatic');
			$placements = !empty($placements_payload['placements']) && is_array($placements_payload['placements']) ? $placements_payload['placements'] : array();
			if ($placements_mode === 'manual' && !empty($placements)) {
				$targeting = array_merge($targeting, self::build_manual_placements_targeting($placements));
			}

			return $targeting;
		}

        private static function build_targeting_geo_locations(array $settings, array $targeting_payload, int $build_id = 0, int $event_plan_id = 0)
        {
            $radius_default = max(1, absint($targeting_payload['radius_miles'] ?? 15));
            $event_context = self::resolve_event_plan_location_context($event_plan_id);
            $geo_locations = array(
                'custom_locations' => array(),
                'zips' => array(),
                'cities' => array(),
            );
            $primary_anchor = trim((string) ($targeting_payload['targeting_address'] ?? ''));
            $locations_value = $targeting_payload['locations'] ?? '';
            $require_explicit_locations = !empty($targeting_payload['require_explicit_locations']);
            $allow_city_state_locations = !empty($targeting_payload['allow_city_state_locations']) || $require_explicit_locations;

            $append_location = function (string $label, int $radius, bool $prefer_radius) use (&$geo_locations, $event_context, $settings, $build_id, $allow_city_state_locations) {
                $radius = max(1, $radius);
                $label = trim($label);
                if ($label === '') {
                    return true;
                }

                $type = self::classify_targeting_location_label($label);
                $normalized_key = strtolower(preg_replace('/[^a-z0-9]+/i', '', $label)) . ':' . $radius;

                if ($type === 'city_state') {
                    if (!$allow_city_state_locations) {
                        return new WP_Error(
                            'city_state_targeting_not_allowed',
                            sprintf(__('Location "%s" looks like a city/state. City/state entries are only supported in the dedicated Outer Towns locations field.', 'vms-meta-ads'), $label),
                            array('status' => 400)
                        );
                    }
                    $resolved = self::resolve_city_location_entry($settings, $label, $radius, $build_id, $event_context);
                    if (is_wp_error($resolved)) {
                        return $resolved;
                    }
                    if (!empty($resolved['custom_location']) && is_array($resolved['custom_location'])) {
                        $geo_locations['custom_locations'][$normalized_key] = (array) $resolved['custom_location'];
                        return true;
                    }
                    if (!empty($resolved['city']) && is_array($resolved['city'])) {
                        $city_key = sanitize_text_field((string) ($resolved['city']['key'] ?? ''));
                        if ($city_key !== '') {
                            $city_entry = array('key' => $city_key);
                            if (!empty($resolved['city']['radius'])) {
                                $city_entry['radius'] = max(1, absint($resolved['city']['radius']));
                                $city_entry['distance_unit'] = sanitize_text_field((string) ($resolved['city']['distance_unit'] ?? 'mile'));
                            }
                            $geo_locations['cities'][$city_key] = $city_entry;
                            return true;
                        }
                    }
                    return new WP_Error(
                        'city_state_targeting_unresolved',
                        sprintf(__('Outer Towns location could not be resolved: "%s". Check spelling or use a ZIP code.', 'vms-meta-ads'), $label),
                        array('status' => 400)
                    );
                }

                if ($type === 'zip') {
                    if ($prefer_radius) {
                        $custom = self::resolve_zip_custom_location_spec($settings, $label, $radius, $build_id, $event_context);
                        if (is_array($custom) && !empty($custom)) {
                            $geo_locations['custom_locations'][$normalized_key] = $custom;
                            return true;
                        }
                    }

                    $zip_key = self::build_zip_key($label, (string) ($event_context['country'] ?? 'US'));
                    if ($zip_key !== '') {
                        $geo_locations['zips'][$zip_key] = array('key' => $zip_key);
                    }
                    return true;
                }

                if ($type !== 'address') {
                    return new WP_Error(
                        'invalid_targeting_location',
                        sprintf(__('Location "%s" must be a city/state, ZIP, or full street address.', 'vms-meta-ads'), $label),
                        array('status' => 400)
                    );
                }

                $geo_locations['custom_locations'][$normalized_key] = self::build_custom_location_spec(
                    $label,
                    $radius,
                    self::location_context_matches_label($event_context, $label)
                        ? $event_context
                        : self::raw_location_context($label, $event_context)
                );
                return true;
            };

            if ($primary_anchor !== '') {
                if (!self::is_precise_location_label($primary_anchor)) {
                    return new WP_Error(
                        'invalid_primary_targeting_location',
                        __('Primary targeting address must be a full street address or ZIP.', 'vms-meta-ads'),
                        array('status' => 400)
                    );
                }
                $result = $append_location($primary_anchor, $radius_default, true);
                if (is_wp_error($result)) {
                    return $result;
                }
            }

            if (is_array($locations_value) && !empty($locations_value)) {
                foreach ($locations_value as $location_row) {
                    if (!is_array($location_row)) {
                        continue;
                    }
                    $label = trim((string) (($location_row['label'] ?? '') ?: ($location_row['query'] ?? '')));
                    if ($label === '') {
                        continue;
                    }
                    $radius = max(1, absint($location_row['radius_miles'] ?? $radius_default));
                    $result = $append_location($label, $radius, true);
                    if (is_wp_error($result)) {
                        return $result;
                    }
                }
            } else {
                $locations_raw = trim((string) $locations_value);
                if ($locations_raw !== '') {
                    $lines = preg_split('/\r\n|\r|\n/', $locations_raw);
                    foreach ((array) $lines as $line_index => $line) {
                        $line = trim((string) $line);
                        if ($line === '' || strpos($line, '#') === 0) {
                            continue;
                        }
                        $parts = array_map('trim', explode('|', $line, 2));
                        $label = trim((string) ($parts[0] ?? ''));
                        if ($label === '') {
                            return new WP_Error(
                                'missing_targeting_location_label',
                                sprintf(__('Audience location row %d is missing a location before the | radius.', 'vms-meta-ads'), $line_index + 1),
                                array('status' => 400)
                            );
                        }
                        $radius = $radius_default;
                        if (array_key_exists(1, $parts)) {
                            $radius_raw = trim((string) $parts[1]);
                            if ($radius_raw === '' || !preg_match('/^[0-9]+(?:\.[0-9]+)?(?:\s*(?:mi|mile|miles))?$/i', $radius_raw)) {
                                return new WP_Error(
                                    'invalid_targeting_location_radius',
                                    sprintf(__('Audience location row %d has an invalid radius: "%s". Use a number of miles.', 'vms-meta-ads'), $line_index + 1, $line),
                                    array('status' => 400)
                                );
                            }
                            $radius = max(1, (int) round((float) preg_replace('/[^0-9.]/', '', $radius_raw)));
                        }
                        $result = $append_location($label, $radius, true);
                        if (is_wp_error($result)) {
                            return $result;
                        }
                    }
                }
            }

            if (empty($geo_locations['custom_locations']) && empty($geo_locations['zips']) && empty($geo_locations['cities'])) {
                if ($require_explicit_locations) {
                    return new WP_Error(
                        'missing_explicit_targeting_location',
                        __('Outer Towns listed-only targeting requires at least one city/state, ZIP, or full street address. MAB will not fall back to the venue radius for this ad set.', 'vms-meta-ads'),
                        array('status' => 400)
                    );
                }
                $event_anchor = self::event_context_anchor_label($event_context);
                if ($event_anchor !== '' && self::is_precise_location_label($event_anchor)) {
                    $result = $append_location($event_anchor, $radius_default, true);
                    if (is_wp_error($result)) {
                        return $result;
                    }
                }
            }

            $geo_locations['custom_locations'] = array_values(array_filter($geo_locations['custom_locations'], 'is_array'));
            $geo_locations['zips'] = array_values(array_filter($geo_locations['zips'], 'is_array'));
            $geo_locations['cities'] = array_values(array_filter($geo_locations['cities'], 'is_array'));

            if (empty($geo_locations['custom_locations']) && empty($geo_locations['zips']) && empty($geo_locations['cities'])) {
                return new WP_Error(
                    'missing_targeting_location',
                    __('Audience location could not be resolved. Select an Event Plan with stored venue address/ZIP data, or enter a city/state, address, or ZIP in Step D before creating in Meta.', 'vms-meta-ads'),
                    array('status' => 400)
                );
            }

            if (empty($geo_locations['custom_locations'])) {
                unset($geo_locations['custom_locations']);
            }
            if (empty($geo_locations['zips'])) {
                unset($geo_locations['zips']);
            }
            if (empty($geo_locations['cities'])) {
                unset($geo_locations['cities']);
            }

            return $geo_locations;
        }

		private static function build_custom_location_spec(string $label, int $radius, array $context = array()): array
		{
			$label = sanitize_text_field($label);
			$address_string = sanitize_text_field((string) ($context['address_string'] ?? $label));
			$country = strtoupper(sanitize_text_field((string) ($context['country'] ?? 'US')));
			if ($country === '') {
				$country = 'US';
			}

			$has_coordinates = isset($context['latitude']) && isset($context['longitude']) && is_numeric($context['latitude']) && is_numeric($context['longitude']);

			$location = array(
				'name' => $label,
				'country' => $country,
				'radius' => max(1, $radius),
				'distance_unit' => 'mile',
			);

			// When coordinates are available, send a coordinate-based custom location and omit
			// address_string. Meta's geo targeting supports latitude/longitude without
			// address_string, and sending a ZIP as an address string can trigger a geocode error.
			if ($has_coordinates) {
				$location['latitude'] = round((float) $context['latitude'], 6);
				$location['longitude'] = round((float) $context['longitude'], 6);
			} elseif ($address_string !== '' || $label !== '') {
				$location['address_string'] = $address_string !== '' ? $address_string : $label;
			}

			return $location;
		}

		private static function resolve_event_plan_location_context(int $event_plan_id): array
		{
			if ($event_plan_id < 1 || !class_exists('VMS_Meta_Ads_Event_Plans_Service')) {
				return array();
			}

			$event = VMS_Meta_Ads_Event_Plans_Service::get_event_plan($event_plan_id);
			if (!is_array($event)) {
				return array();
			}

			return array(
				'label' => sanitize_text_field((string) ($event['location_label'] ?? '')),
				'address_string' => sanitize_text_field((string) ($event['location_address'] ?? '')),
				'zip' => sanitize_text_field((string) ($event['location_zip'] ?? '')),
				'targeting_anchor' => sanitize_text_field((string) ($event['location_targeting_anchor'] ?? '')),
				'has_precise_anchor' => !empty($event['location_has_precise_anchor']),
				'country' => sanitize_text_field((string) ($event['location_country'] ?? 'US')),
				'latitude' => isset($event['location_latitude']) && is_numeric($event['location_latitude']) ? (float) $event['location_latitude'] : null,
				'longitude' => isset($event['location_longitude']) && is_numeric($event['location_longitude']) ? (float) $event['location_longitude'] : null,
			);
		}

		private static function location_context_matches_label(array $context, string $label): bool
		{
			$label = strtolower(preg_replace('/[^a-z0-9]+/i', '', $label));
			if ($label === '') {
				return false;
			}
			$candidates = array(
				(string) ($context['label'] ?? ''),
				(string) ($context['address_string'] ?? ''),
				(string) ($context['targeting_anchor'] ?? ''),
				(string) ($context['zip'] ?? ''),
			);
			foreach ($candidates as $candidate) {
				$candidate = strtolower(preg_replace('/[^a-z0-9]+/i', '', $candidate));
				if ($candidate !== '' && $candidate === $label) {
					return true;
				}
			}
			return false;
		}

		private static function event_context_has_precise_anchor(array $context): bool
		{
			if (!empty($context['has_precise_anchor'])) {
				return true;
			}
			return isset($context['latitude'], $context['longitude'])
				&& is_numeric($context['latitude'])
				&& is_numeric($context['longitude']);
		}

		private static function event_context_anchor_label(array $context): string
		{
			$anchor = trim((string) ($context['targeting_anchor'] ?? ''));
			if ($anchor !== '') {
				return $anchor;
			}
			$anchor = trim((string) ($context['address_string'] ?? ''));
			if ($anchor !== '') {
				return $anchor;
			}
			$anchor = trim((string) ($context['zip'] ?? ''));
			if ($anchor !== '') {
				return $anchor;
			}
			return trim((string) ($context['label'] ?? ''));
		}

		private static function is_precise_location_label(string $label): bool
		{
			$label = trim($label);
			if ($label === '') {
				return false;
			}
			if ((bool) preg_match('/^\d{5}(?:-\d{4})?$/', $label)) {
				return true;
			}
			return strlen($label) >= 8
				&& (bool) preg_match('/[A-Za-z]/', $label)
				&& (bool) preg_match('/\d/', $label);
		}


		private static function is_zip_location_label(string $label): bool
		{
			return (bool) preg_match('/^\d{5}(?:-\d{4})?$/', trim($label));
		}


        private static function classify_targeting_location_label(string $label): string
        {
            $label = trim($label);
            if ($label === '') {
                return 'unknown';
            }
            if (self::is_zip_location_label($label)) {
                return 'zip';
            }
            if (self::is_city_state_location_label($label)) {
                return 'city_state';
            }
            if (self::is_precise_location_label($label)) {
                return 'address';
            }
            return 'unknown';
        }

        private static function is_city_state_location_label(string $label): bool
        {
            $parts = self::split_city_state_location_label($label);
            return !empty($parts);
        }

        private static function split_city_state_location_label(string $label): array
        {
            $label = trim(preg_replace('/\s+/', ' ', $label));
            if ($label === '' || preg_match('/^\d+\s+/', $label)) {
                return array();
            }
            $parts = array_map('trim', explode(',', $label, 2));
            if (count($parts) !== 2 || $parts[0] === '' || $parts[1] === '') {
                return array();
            }
            $city = sanitize_text_field($parts[0]);
            $state = sanitize_text_field($parts[1]);
            $state = preg_replace('/\s+usa?$/i', '', $state);
            $state_norm = strtolower(preg_replace('/[^a-z]/i', '', $state));
            if ($city === '' || $state_norm === '') {
                return array();
            }
            $states = self::us_state_name_map();
            if (strlen($state_norm) === 2) {
                $state_code = strtoupper($state_norm);
                $state_name = $states[$state_code] ?? '';
                if ($state_name === '') {
                    return array();
                }
            } else {
                $state_code = '';
                $state_name = '';
                foreach ($states as $code => $name) {
                    if (strtolower(preg_replace('/[^a-z]/i', '', $name)) === $state_norm) {
                        $state_code = $code;
                        $state_name = $name;
                        break;
                    }
                }
                if ($state_code === '') {
                    return array();
                }
            }
            return array(
                'city' => $city,
                'state_code' => $state_code,
                'state_name' => $state_name,
            );
        }

        private static function us_state_name_map(): array
        {
            return array(
                'AL' => 'Alabama', 'AK' => 'Alaska', 'AZ' => 'Arizona', 'AR' => 'Arkansas', 'CA' => 'California',
                'CO' => 'Colorado', 'CT' => 'Connecticut', 'DE' => 'Delaware', 'FL' => 'Florida', 'GA' => 'Georgia',
                'HI' => 'Hawaii', 'ID' => 'Idaho', 'IL' => 'Illinois', 'IN' => 'Indiana', 'IA' => 'Iowa',
                'KS' => 'Kansas', 'KY' => 'Kentucky', 'LA' => 'Louisiana', 'ME' => 'Maine', 'MD' => 'Maryland',
                'MA' => 'Massachusetts', 'MI' => 'Michigan', 'MN' => 'Minnesota', 'MS' => 'Mississippi', 'MO' => 'Missouri',
                'MT' => 'Montana', 'NE' => 'Nebraska', 'NV' => 'Nevada', 'NH' => 'New Hampshire', 'NJ' => 'New Jersey',
                'NM' => 'New Mexico', 'NY' => 'New York', 'NC' => 'North Carolina', 'ND' => 'North Dakota', 'OH' => 'Ohio',
                'OK' => 'Oklahoma', 'OR' => 'Oregon', 'PA' => 'Pennsylvania', 'RI' => 'Rhode Island', 'SC' => 'South Carolina',
                'SD' => 'South Dakota', 'TN' => 'Tennessee', 'TX' => 'Texas', 'UT' => 'Utah', 'VT' => 'Vermont',
                'VA' => 'Virginia', 'WA' => 'Washington', 'WV' => 'West Virginia', 'WI' => 'Wisconsin', 'WY' => 'Wyoming',
                'DC' => 'District of Columbia',
            );
        }

        private static function resolve_city_location_entry(array $settings, string $label, int $radius, int $build_id = 0, array $event_context = array())
        {
            $parts = self::split_city_state_location_label($label);
            if (empty($parts)) {
                return new WP_Error(
                    'invalid_city_state_location',
                    sprintf(__('Outer Towns location "%s" must be entered as City, ST or City, State.', 'vms-meta-ads'), $label),
                    array('status' => 400)
                );
            }

            $country = strtoupper(sanitize_text_field((string) ($event_context['country'] ?? 'US')));
            if ($country === '') {
                $country = 'US';
            }

            $query_variants = self::city_location_search_query_variants($parts);
            $data = self::meta_city_location_search_candidates($settings, $query_variants, $country, $build_id);
            if (is_wp_error($data)) {
                $meta_error = trim((string) $data->get_error_message());
                $message = sprintf(
                    __('Outer Towns city lookup failed for "%1$s". Use a ZIP code for this row, or download the latest failure bundle.', 'vms-meta-ads'),
                    $label
                );
                if (stripos($meta_error, 'provide valid app id') !== false) {
                    $message = sprintf(
                        __('Outer Towns city lookup failed for "%1$s" because Meta rejected the targeting search request: Provide valid app ID. Use ZIP codes for now, or configure Meta app authentication before using city/state lookup.', 'vms-meta-ads'),
                        $label
                    );
                } elseif ($meta_error !== '') {
                    $message = sprintf(
                        __('Outer Towns city lookup failed for "%1$s" because Meta did not return usable city targeting data. Use a ZIP code for this row, or download the latest failure bundle. Meta detail: %2$s', 'vms-meta-ads'),
                        $label,
                        $meta_error
                    );
                }
                return new WP_Error(
                    'city_state_targeting_search_failed',
                    $message,
                    array('status' => 400, 'meta_error' => $meta_error)
                );
            }

            $matches = array();
            foreach ((array) $data as $row) {
                if (!is_array($row)) {
                    continue;
                }
                if (self::city_location_row_matches_parts($row, $parts, $country)) {
                    $matches[] = $row;
                }
            }

            if (empty($matches)) {
                return new WP_Error(
                    'city_state_targeting_not_found',
                    sprintf(__('Outer Towns location could not be resolved through Meta: "%s". MAB searched for %s and filtered for %s (%s). Check spelling or use a ZIP code.', 'vms-meta-ads'), $label, implode(', ', $query_variants), $parts['state_name'], $parts['state_code']),
                    array('status' => 400)
                );
            }

            if (count($matches) > 1) {
                $unique_keys = array_unique(array_filter(array_map(static function ($row) {
                    return is_array($row) ? (string) ($row['key'] ?? '') : '';
                }, $matches)));
                if (count($unique_keys) > 1) {
                    return new WP_Error(
                        'city_state_targeting_ambiguous',
                        sprintf(__('Outer Towns location is ambiguous in Meta: "%s". Use a ZIP code or full address for that row.', 'vms-meta-ads'), $label),
                        array('status' => 400)
                    );
                }
            }

            $first = !empty($matches[0]) && is_array($matches[0]) ? (array) $matches[0] : array();
            if (empty($first)) {
                return new WP_Error(
                    'city_state_targeting_not_found',
                    sprintf(__('Outer Towns location could not be resolved: "%s". Check spelling or use a ZIP code.', 'vms-meta-ads'), $label),
                    array('status' => 400)
                );
            }

            $lat = isset($first['latitude']) && is_numeric($first['latitude']) ? (float) $first['latitude'] : null;
            $lng = isset($first['longitude']) && is_numeric($first['longitude']) ? (float) $first['longitude'] : null;
            if ($lat !== null && $lng !== null) {
                return array(
                    'custom_location' => self::build_custom_location_spec($label, $radius, array(
                        'country' => $country,
                        'label' => $label,
                        'targeting_anchor' => $label,
                        'latitude' => $lat,
                        'longitude' => $lng,
                    )),
                );
            }

            $key = sanitize_text_field((string) ($first['key'] ?? ''));
            if ($key !== '') {
                $city = array('key' => $key);
                if ($radius > 0) {
                    $city['radius'] = max(1, $radius);
                    $city['distance_unit'] = 'mile';
                }
                return array('city' => $city);
            }

            return new WP_Error(
                'city_state_targeting_missing_key',
                sprintf(__('Outer Towns location could not be resolved: "%s". Check spelling or use a ZIP code.', 'vms-meta-ads'), $label),
                array('status' => 400)
            );
        }

        private static function city_location_search_query_variants(array $parts): array
        {
            $city = trim(sanitize_text_field((string) ($parts['city'] ?? '')));
            $state_name = trim(sanitize_text_field((string) ($parts['state_name'] ?? '')));
            $state_code = strtoupper(trim(sanitize_text_field((string) ($parts['state_code'] ?? ''))));

            $queries = array();
            if ($city !== '' && $state_name !== '') {
                // Meta's UI/API often resolves city targeting more reliably with the state spelled out.
                $queries[] = $city . ', ' . $state_name;
                $queries[] = $city . ' ' . $state_name;
            }
            if ($city !== '' && $state_code !== '') {
                // Keep abbreviation as a later fallback only; do not prefer it.
                $queries[] = $city . ', ' . $state_code;
            }
            if ($city !== '') {
                $queries[] = $city;
            }

            return array_values(array_unique(array_filter(array_map('trim', $queries))));
        }

        private static function meta_city_location_search_candidates(array $settings, array $query_variants, string $country, int $build_id = 0)
        {
            $query_variants = array_values(array_unique(array_filter(array_map(static function ($query) {
                return trim(sanitize_text_field((string) $query));
            }, $query_variants))));
            $country = strtoupper(sanitize_text_field($country));
            if (empty($query_variants)) {
                return new WP_Error('city_state_targeting_missing_city', __('Missing city name for Meta city lookup.', 'vms-meta-ads'));
            }
            if ($country === '') {
                $country = 'US';
            }

            $errors = array();
            $global_candidates = self::meta_city_location_search_path_candidates(
                $settings,
                'search',
                'targeting_city_search',
                $query_variants,
                $country,
                $build_id,
                $errors
            );
            if (!empty($global_candidates)) {
                return array_values($global_candidates);
            }

            $ad_account_id = trim((string) ($settings['meta_ad_account_id'] ?? ''));
            if ($ad_account_id !== '') {
                $account_candidates = self::meta_city_location_search_path_candidates(
                    $settings,
                    VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint($ad_account_id) . '/targetingsearch',
                    'targeting_city_account_search',
                    $query_variants,
                    $country,
                    $build_id,
                    $errors
                );
                if (!empty($account_candidates)) {
                    return array_values($account_candidates);
                }
            }

            if (!empty($errors)) {
                return new WP_Error(
                    'city_state_targeting_search_failed',
                    implode(' | ', array_filter($errors))
                );
            }

            return array();
        }

        private static function meta_city_location_search_path_candidates(array $settings, string $path, string $operation, array $query_variants, string $country, int $build_id, array &$errors): array
        {
            $candidates = array();
            foreach ($query_variants as $query_value) {
                $query_value = trim(sanitize_text_field((string) $query_value));
                if ($query_value === '') {
                    continue;
                }
                $query = array(
                    'type' => 'adgeolocation',
                    'location_types' => wp_json_encode(array('city')),
                    'q' => $query_value,
                    'country_code' => $country,
                    'limit' => 50,
                );

                $response = self::meta_get_request(
                    $settings,
                    $path,
                    $query,
                    $operation,
                    'ad_builder',
                    20,
                    $build_id
                );

                if (is_wp_error($response)) {
                    $errors[] = $operation . ' q="' . $query_value . '": ' . $response->get_error_message();
                    continue;
                }

                $code = (int) wp_remote_retrieve_response_code($response);
                $body_raw = (string) wp_remote_retrieve_body($response);
                $body = json_decode($body_raw, true);
                if ($code >= 200 && $code < 300 && is_array($body) && empty($body['error'])) {
                    $rows = isset($body['data']) && is_array($body['data']) ? $body['data'] : array();
                    foreach ($rows as $row) {
                        if (!is_array($row)) {
                            continue;
                        }
                        $key = (string) ($row['key'] ?? md5(wp_json_encode($row)));
                        $candidates[$key] = $row;
                    }
                    continue;
                }

                if (is_array($body) && isset($body['error']) && is_array($body['error'])) {
                    $errors[] = $operation . ' q="' . $query_value . '": ' . sanitize_text_field((string) ($body['error']['message'] ?? wp_json_encode($body['error'])));
                } else {
                    $errors[] = $operation . ' q="' . $query_value . '": HTTP ' . $code . ' from ' . $path;
                }
            }

            return $candidates;
        }

        private static function city_location_row_matches_parts(array $row, array $parts, string $country): bool
        {
            $city = strtolower(trim((string) ($parts['city'] ?? '')));
            $state_code = strtoupper(trim((string) ($parts['state_code'] ?? '')));
            $state_name = strtolower(trim((string) ($parts['state_name'] ?? '')));
            $country = strtoupper(trim($country));
            if ($city === '' || $state_code === '') {
                return false;
            }

            $row_country = strtoupper(trim((string) (($row['country_code'] ?? '') ?: ($row['country'] ?? $country))));
            if ($row_country !== '' && $country !== '' && $row_country !== $country) {
                return false;
            }

            $row_type = strtolower(trim((string) ($row['type'] ?? '')));
            if ($row_type !== '' && $row_type !== 'city') {
                return false;
            }

            $name = strtolower(trim((string) ($row['name'] ?? '')));
            $canonical = strtolower(trim((string) ($row['canonical_name'] ?? '')));
            $region = strtolower(trim((string) (($row['region'] ?? '') ?: ($row['region_name'] ?? ''))));

            $city_norm = self::normalize_location_match_text($city);
            $name_norm = self::normalize_location_match_text($name);
            $name_tokens = self::location_match_token_string($name);
            $canonical_tokens = self::location_match_token_string($canonical);
            $city_match = $name_norm === $city_norm
                || ($city_norm !== '' && strpos($name_norm, $city_norm . ' ') === 0)
                || ($city_norm !== '' && strpos($canonical_tokens, ' ' . $city_norm . ' ') !== false)
                || ($city_norm !== '' && strpos($name_tokens, ' ' . $city_norm . ' ') !== false);
            if (!$city_match) {
                return false;
            }

            $state_code_norm = strtolower($state_code);
            $state_name_norm = self::normalize_location_match_text($state_name);
            $region_norm = self::normalize_location_match_text($region);
            if ($region_norm !== '') {
                return $region_norm === $state_name_norm || $region_norm === $state_code_norm;
            }

            $state_haystack = $canonical_tokens . ' ' . $name_tokens;
            return strpos($state_haystack, ' ' . $state_name_norm . ' ') !== false || strpos($state_haystack, ' ' . $state_code_norm . ' ') !== false;
        }

        private static function normalize_location_match_text(string $value): string
        {
            return trim(strtolower(preg_replace('/[^a-z0-9]+/i', ' ', $value)));
        }

        private static function location_match_token_string(string $value): string
        {
            $normalized = self::normalize_location_match_text($value);
            return $normalized === '' ? ' ' : ' ' . $normalized . ' ';
        }

		private static function build_zip_key(string $label, string $country = 'US'): string
		{
			$label = trim($label);
			if (!self::is_zip_location_label($label)) {
				return '';
			}
			$country = strtoupper(sanitize_text_field($country));
			if ($country === '') {
				$country = 'US';
			}
			return $country . ':' . preg_replace('/[^0-9\-]/', '', $label);
		}

		private static function raw_location_context(string $label, array $event_context): array
		{
			return array(
				'address_string' => sanitize_text_field($label),
				'country' => sanitize_text_field((string) ($event_context['country'] ?? 'US')),
			);
		}

		private static function build_manual_placements_targeting(array $placements): array
		{
			$publisher_platforms = array();
			$facebook_positions = array();
			$instagram_positions = array();
			$placements = array_values(array_unique(array_map('sanitize_key', $placements)));
			if (in_array('ig_search', $placements, true) && !in_array('ig_feed', $placements, true)) {
				$placements[] = 'ig_feed';
			}

			foreach ($placements as $p) {
				$p = sanitize_key((string) $p);
				switch ($p) {
					case 'fb_feed':
						$publisher_platforms[] = 'facebook';
						$facebook_positions[] = 'feed';
						break;
					case 'fb_profile_feed':
						$publisher_platforms[] = 'facebook';
						$facebook_positions[] = 'profile_feed';
						break;
					case 'fb_right_column':
						$publisher_platforms[] = 'facebook';
						$facebook_positions[] = 'right_hand_column';
						break;
					case 'fb_search':
						$publisher_platforms[] = 'facebook';
						$facebook_positions[] = 'search';
						break;
					case 'fb_story':
						$publisher_platforms[] = 'facebook';
						$facebook_positions[] = 'story';
						break;
					case 'fb_reels':
						$publisher_platforms[] = 'facebook';
						$facebook_positions[] = 'facebook_reels';
						break;
					case 'ig_feed':
						$publisher_platforms[] = 'instagram';
						$instagram_positions[] = 'stream';
						break;
					case 'ig_search':
						$publisher_platforms[] = 'instagram';
						$instagram_positions[] = 'ig_search';
						break;
					case 'ig_explore':
						$publisher_platforms[] = 'instagram';
						$instagram_positions[] = 'explore';
						break;
					case 'ig_story':
						$publisher_platforms[] = 'instagram';
						$instagram_positions[] = 'story';
						break;
					case 'ig_reels':
						$publisher_platforms[] = 'instagram';
						$instagram_positions[] = 'reels';
						break;
					default:
						break;
				}
			}

			$publisher_platforms = array_values(array_unique($publisher_platforms));
			$facebook_positions = array_values(array_unique($facebook_positions));
			$instagram_positions = array_values(array_unique($instagram_positions));

			$out = array();
			if (!empty($publisher_platforms)) {
				$out['publisher_platforms'] = $publisher_platforms;
			}
			if (!empty($facebook_positions)) {
				$out['facebook_positions'] = $facebook_positions;
			}
			if (!empty($instagram_positions)) {
				$out['instagram_positions'] = $instagram_positions;
			}
			return $out;
		}

		private static function resolve_adgeo_city_key(array $settings, string $query, int $build_id = 0): string
		{
			$query = trim($query);
			if ($query === '') {
				return '';
			}
			$response = self::meta_get_request(
				$settings,
				'search',
				array(
					'type' => 'adgeolocation',
					'location_types' => wp_json_encode(array('city')),
					'q' => $query,
					'limit' => 1,
				),
				'targeting_city_search',
				'ad_builder',
				20,
				$build_id
			);
			if (is_wp_error($response)) {
				return '';
			}
			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || !is_array($body)) {
				return '';
			}
			if (isset($body['error'])) {
				return '';
			}
			$data = isset($body['data']) && is_array($body['data']) ? $body['data'] : array();
			if (empty($data) || !is_array($data[0])) {
				return '';
			}
			$key = trim((string) ($data[0]['key'] ?? ''));
			return $key;
		}

		private static function resolve_zip_custom_location_spec(array $settings, string $zip, int $radius, int $build_id = 0, array $event_context = array()): array
		{
			$zip = trim($zip);
			if (!self::is_zip_location_label($zip)) {
				return array();
			}

			$country = strtoupper(sanitize_text_field((string) ($event_context['country'] ?? 'US')));
			if ($country === '') {
				$country = 'US';
			}

			$response = self::meta_get_request(
				$settings,
				'search',
				array(
					'type' => 'adgeolocation',
					'location_types' => wp_json_encode(array('zip')),
					'q' => $zip,
					'country_code' => $country,
					'limit' => 1,
				),
				'targeting_zip_search',
				'ad_builder',
				20,
				$build_id
			);

			if (!is_wp_error($response)) {
				$code = (int) wp_remote_retrieve_response_code($response);
				$body = json_decode((string) wp_remote_retrieve_body($response), true);
				$data = (is_array($body) && !empty($body['data']) && is_array($body['data'])) ? $body['data'] : array();
				$first = !empty($data[0]) && is_array($data[0]) ? (array) $data[0] : array();
				if ($code >= 200 && $code < 300 && !empty($first)) {
					$lat = isset($first['latitude']) && is_numeric($first['latitude']) ? (float) $first['latitude'] : null;
					$lng = isset($first['longitude']) && is_numeric($first['longitude']) ? (float) $first['longitude'] : null;
					if ($lat !== null && $lng !== null) {
						return self::build_custom_location_spec($zip, $radius, array(
							'country' => $country,
							'label' => $zip,
							'targeting_anchor' => $zip,
							'latitude' => $lat,
							'longitude' => $lng,
						));
					}
				}
			}

			// No coordinates means Meta will treat this more reliably as a ZIP polygon than
			// as a geocoded address string. Return empty so the caller can fall back to zips[].
			return array();
		}

		private static function map_meta_link_cta(string $cta_type, string $destination_url = ''): string
		{
			$cta_type = strtoupper(sanitize_key($cta_type));
			$allowed = array('LEARN_MORE', 'GET_OFFER', 'SIGN_UP', 'BOOK_NOW', 'CONTACT_US', 'GET_TICKETS', 'BUY_TICKETS');
			if (!in_array($cta_type, $allowed, true)) {
				return 'LEARN_MORE';
			}

			$host = strtolower((string) wp_parse_url($destination_url, PHP_URL_HOST));
			$is_facebook_family = $host !== '' && (
				$host === 'facebook.com'
				|| $host === 'www.facebook.com'
				|| $host === 'm.facebook.com'
				|| $host === 'fb.me'
				|| $host === 'instagram.com'
				|| $host === 'www.instagram.com'
			);

			if ($cta_type === 'GET_TICKETS') {
				// VMS operator-facing alias. For ticketed concert campaigns, the desired
				// viewer-facing button is Buy Tickets whenever Meta accepts it.
				return 'BUY_TICKETS';
			}

			return $cta_type;
		}

		private static function to_meta_iso8601(string $local_datetime, array $settings = array()): string
		{
			$local_datetime = trim($local_datetime);
			if ($local_datetime === '') {
				return '';
			}
			try {
				$site_dt = new DateTimeImmutable($local_datetime, wp_timezone());
				$dt = $site_dt->setTimezone(VMS_Meta_Ads_Utils::get_meta_account_timezone($settings));
			} catch (Exception $e) {
				return '';
			}
			return $dt->format('c');
		}

		private static function meta_get_request(array $settings, string $path, array $query, string $operation, string $context, int $timeout = 20, int $build_id = 0)
		{
			$path = ltrim($path, '/');
			$query_for_log = $query;
			unset($query_for_log['access_token']);
			$endpoint = $path;
			if (!empty($query_for_log)) {
				$endpoint .= '?' . http_build_query($query_for_log);
			}
			return vms_api_attempt_wrap(
				'meta_ads',
				'vms-facebook-ads',
				$operation,
				$context,
				'GET',
				$endpoint,
				array('query' => $query_for_log),
				static function () use ($settings, $path, $query, $timeout) {
					$url = VMS_Meta_Ads_Meta_Endpoints::build_url($settings, $path);
					$url = add_query_arg(array_merge($query, array('access_token' => (string) ($settings['token'] ?? ''))), $url);
					return wp_remote_get($url, array('timeout' => $timeout));
				}
			);
		}

		private static function meta_post_form_request(array $settings, string $path, array $body, string $operation, string $context, int $timeout = 25, int $build_id = 0)
		{
			$path = ltrim($path, '/');
			$request_body = $body;
			unset($request_body['access_token']);
			return vms_api_attempt_wrap(
				'meta_ads',
				'vms-facebook-ads',
				$operation,
				$context,
				'POST',
				$path,
				array('body' => $request_body, 'format' => 'form'),
				static function () use ($settings, $path, $body, $timeout) {
					$url = VMS_Meta_Ads_Meta_Endpoints::build_url($settings, $path);
					$post_body = $body;
					$post_body['access_token'] = (string) ($settings['token'] ?? '');
					return wp_remote_post($url, array(
						'timeout' => $timeout,
						'body' => $post_body,
					));
				}
			);
		}

		private static function meta_post_json_request(array $settings, string $path, array $body, string $operation, string $context, int $timeout = 25, int $build_id = 0)
		{
			$path = ltrim($path, '/');
			return vms_api_attempt_wrap(
				'meta_ads',
				'vms-facebook-ads',
				$operation,
				$context,
				'POST',
				$path,
				array('body' => $body, 'format' => 'json'),
				static function () use ($settings, $path, $body, $timeout) {
					$url = VMS_Meta_Ads_Meta_Endpoints::build_url($settings, $path);
					$url = add_query_arg(array('access_token' => (string) ($settings['token'] ?? '')), $url);
					return wp_remote_post($url, array(
						'timeout' => $timeout,
						'headers' => array(
							'Content-Type' => 'application/json',
						),
						'body' => wp_json_encode($body),
					));
				}
			);
		}


		private static function create_ad_with_single_retry(array $settings, array $preflight, array $ids, int $build_id = 0): array
		{
			$path = VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/ads';
			$payload = array(
				'name' => (string) $preflight['ad_name'],
				'adset_id' => (string) $ids['adset_id'],
				'status' => self::STATUS_PAUSED,
				'creative' => wp_json_encode(array('creative_id' => (string) $ids['creative_id'])),
			);

			$response = self::meta_post($settings, $path, $payload, 'create_ad', $build_id);
			if (!is_wp_error($response) || !self::should_retry_create_ad_error($response)) {
				return array(
					'response' => $response,
					'retried' => false,
				);
			}

			vms_ma_log('meta_create_ad_retry', array(
				'build_id' => $build_id,
				'adset_id' => (string) ($ids['adset_id'] ?? ''),
				'creative_id' => (string) ($ids['creative_id'] ?? ''),
				'message' => $response->get_error_message(),
			), $build_id);

			sleep(2);
			$retry_response = self::meta_post($settings, $path, $payload, 'create_ad_retry', $build_id);

			return array(
				'response' => $retry_response,
				'retried' => true,
			);
		}

		private static function should_retry_create_ad_error(WP_Error $error): bool
		{
			$data = $error->get_error_data();
			$status = is_array($data) ? (int) ($data['status'] ?? 0) : 0;
			$meta = (is_array($data) && !empty($data['meta']) && is_array($data['meta'])) ? (array) $data['meta'] : array();
			$response_code = (int) ($meta['response_code'] ?? $status);
			$meta_code = (int) ($meta['code'] ?? 0);
			$message = strtolower((string) $error->get_error_message());

			if (in_array($meta_code, array(1, 2, 4, 17, 341, 613), true)) {
				return true;
			}
			if ($response_code === 429 || $response_code >= 500) {
				return true;
			}
			if ($response_code === 0 && $status >= 500) {
				return true;
			}
			return strpos($message, 'before response was received') !== false
				|| strpos($message, 'timeout') !== false
				|| strpos($message, 'temporarily unavailable') !== false
				|| strpos($message, 'please reduce the amount of data') !== false;
		}


		private static function retry_ad_action_with_standard_creative(array $settings, array $preflight, array $variant, array $images, string $adset_id, string $ad_name, WP_Error $error, int $build_id = 0, string $existing_ad_id = ''): array
		{
			if (!self::is_non_dynamic_adset_dynamic_creative_error($error)) {
				return array(
					'handled' => false,
					'response' => $error,
				);
			}

			vms_ma_log('meta_ad_fallback', array(
				'build_id' => $build_id,
				'adset_id' => $adset_id,
				'ad_id' => $existing_ad_id,
				'message' => $error->get_error_message(),
				'strategy' => 'single_image_creative_for_non_dynamic_adset',
			), $build_id);

			$fallback_creative_response = self::create_single_image_creative_for_variant($settings, $preflight, $variant, $images, $build_id);
			if (is_wp_error($fallback_creative_response)) {
				return array(
					'handled' => true,
					'response' => $fallback_creative_response,
				);
			}

			$fallback_creative_id = self::extract_created_id((array) $fallback_creative_response, 'creative');
			if ($fallback_creative_id === '') {
				return array(
					'handled' => true,
					'response' => new WP_Error('meta_creative_missing_id', __('Meta fallback creative create returned no creative ID.', 'vms-meta-ads'), array('status' => 502)),
				);
			}

			$warning = __('Meta rejected the multi-image dynamic creative on this ad set, so VMS fell back to a standard single-image creative using the primary image.', 'vms-meta-ads');

			if ($existing_ad_id !== '') {
				$retry_response = self::meta_post($settings, $existing_ad_id, array(
					'name' => $ad_name,
					'creative' => wp_json_encode(array('creative_id' => $fallback_creative_id)),
				), 'update_ad_retry_single_image', $build_id);

				return array(
					'handled' => true,
					'response' => $retry_response,
					'creative_id' => $fallback_creative_id,
					'retried' => false,
					'warning' => $warning,
				);
			}

			$retry_attempt = self::create_ad_with_single_retry($settings, array('ad_name' => $ad_name), array(
				'adset_id' => $adset_id,
				'creative_id' => $fallback_creative_id,
			), $build_id);

			return array(
				'handled' => true,
				'response' => $retry_attempt['response'] ?? null,
				'creative_id' => $fallback_creative_id,
				'retried' => !empty($retry_attempt['retried']),
				'warning' => $warning,
			);
		}

		private static function create_single_image_creative_for_variant(array $settings, array $preflight, array $variant, array $images, int $build_id = 0)
		{
			$creative_blueprint = self::build_creative_request_blueprint($preflight, $variant, $images);
			$payload = (array) ($creative_blueprint['single_image'] ?? array());
			if (empty($payload)) {
				return new WP_Error('missing_creative_payload', __('Meta single-image creative payload is missing.', 'vms-meta-ads'), array('status' => 500));
			}

			return self::meta_post(
				$settings,
				VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/adcreatives',
				$payload,
				'create_creative_retry_non_dynamic_adset',
				$build_id
			);
		}

		private static function is_non_dynamic_adset_dynamic_creative_error(WP_Error $error): bool
		{
			$data = $error->get_error_data();
			$meta = (is_array($data) && !empty($data['meta']) && is_array($data['meta'])) ? (array) $data['meta'] : array();
			$message = strtolower((string) $error->get_error_message());
			$message_user = strtolower((string) ($meta['message_user'] ?? ''));
			$meta_code = (int) ($meta['code'] ?? 0);
			$subcode = (int) ($meta['subcode'] ?? 0);

			if ($meta_code === 100 && $subcode === 1885998) {
				return true;
			}

			$haystack = trim($message . ' ' . $message_user);
			return strpos($haystack, 'cannot create dynamic creative ad in non-dynamic creative ad set') !== false
				|| strpos($haystack, 'dynamic creative ads can only be created under dynamic creative ad sets') !== false;
		}

		private static function meta_post(array $settings, string $path, array $body, string $where, int $build_id = 0)
		{
			$response = self::meta_post_form_request($settings, $path, $body, $where, 'ad_builder', 25, $build_id);
			if (is_wp_error($response)) {
				vms_ma_log('error', array(
					'where' => $where,
					'message' => $response->get_error_message(),
					'response_code' => 0,
					'error' => true,
				), $build_id);
				return new WP_Error('meta_request_failed', __('Meta request failed before response was received.', 'vms-meta-ads'), array(
					'status' => 502,
					'where' => $where,
				));
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body_json = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || (is_array($body_json) && isset($body_json['error']))) {
				$meta_error = self::extract_meta_error($body_json, $code);
				vms_ma_log('error', array(
					'where' => $where,
					'response_code' => $code,
					'type' => $meta_error['type'],
					'code' => $meta_error['code'],
					'subcode' => $meta_error['subcode'],
					'blame_field' => $meta_error['blame_field'],
					'fbtrace_id' => $meta_error['fbtrace_id'],
					'message' => $meta_error['message'],
					'error' => true,
				), $build_id);
				$message = $meta_error['message'];
				if (!empty($meta_error['message_user']) && $meta_error['message_user'] !== $meta_error['message']) {
					$message .= ' — ' . $meta_error['message_user'];
				}
				return new WP_Error('meta_request_failed', sprintf(__('%1$s failed: %2$s', 'vms-meta-ads'), $where, $message), array(
					'status' => 502,
					'where' => $where,
					'meta' => $meta_error,
				));
			}

			vms_ma_log('meta_create_response', array(
				'where' => $where,
				'response_code' => $code,
				'ok' => true,
			), $build_id);

			return array(
				'code' => $code,
				'body' => is_array($body_json) ? $body_json : array(),
			);
		}

		private static function meta_post_json(array $settings, string $path, array $body, string $where, int $build_id = 0)
		{
			$response = self::meta_post_json_request($settings, $path, $body, $where, 'ad_builder', 25, $build_id);
			if (is_wp_error($response)) {
				vms_ma_log('error', array(
					'where' => $where,
					'message' => $response->get_error_message(),
					'response_code' => 0,
					'error' => true,
				), $build_id);
				return new WP_Error('meta_request_failed', __('Meta request failed before response was received.', 'vms-meta-ads'), array(
					'status' => 502,
					'where' => $where,
				));
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body_json = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || (is_array($body_json) && isset($body_json['error']))) {
				$meta_error = self::extract_meta_error($body_json, $code);
				vms_ma_log('error', array(
					'where' => $where,
					'response_code' => $code,
					'type' => $meta_error['type'],
					'code' => $meta_error['code'],
					'subcode' => $meta_error['subcode'],
					'blame_field' => $meta_error['blame_field'],
					'fbtrace_id' => $meta_error['fbtrace_id'],
					'message' => $meta_error['message'],
					'error' => true,
				), $build_id);
				$message = $meta_error['message'];
				if (!empty($meta_error['message_user']) && $meta_error['message_user'] !== $meta_error['message']) {
					$message .= ' — ' . $meta_error['message_user'];
				}
				return new WP_Error('meta_request_failed', sprintf(__('%1$s failed: %2$s', 'vms-meta-ads'), $where, $message), array(
					'status' => 502,
					'where' => $where,
					'meta' => $meta_error,
				));
			}

			vms_ma_log('meta_create_response', array(
				'where' => $where,
				'response_code' => $code,
				'ok' => true,
			), $build_id);

			return array(
				'code' => $code,
				'body' => is_array($body_json) ? $body_json : array(),
			);
		}

		private static function extract_created_id(array $response, string $object_key): string
		{
			$body = is_array($response['body'] ?? null) ? (array) $response['body'] : array();
			$candidate = sanitize_text_field((string) ($body['id'] ?? ''));
			if ($candidate !== '') {
				return $candidate;
			}
			if ($object_key === 'creative') {
				return sanitize_text_field((string) ($body['creative_id'] ?? ''));
			}
			return '';
		}

		private static function campaign_objective_candidates(string $objective): array
		{
			$objective = sanitize_text_field(trim($objective));
			if ($objective === 'OUTCOME_TRAFFIC') {
				return array('OUTCOME_TRAFFIC');
			}
			if ($objective === 'OUTCOME_SALES') {
				return array('OUTCOME_SALES');
			}
			if ($objective === 'TRAFFIC' || $objective === 'LINK_CLICKS') {
				return array('OUTCOME_TRAFFIC');
			}
			return $objective !== '' ? array($objective, 'OUTCOME_TRAFFIC') : array('OUTCOME_TRAFFIC');
		}
 
		private static function campaign_payload_candidates(string $campaign_name, string $objective): array
		{
			$base = array(
				'name' => $campaign_name,
				'objective' => $objective,
				'status' => self::STATUS_PAUSED,
				'special_ad_categories' => array(),
				// Meta requires this when not using campaign budget optimization.
				'is_adset_budget_sharing_enabled' => false,
			);

			$candidates = array();
			$candidates[] = array_merge($base, array('buying_type' => 'AUCTION'));
			$candidates[] = $base;
			$candidates[] = array_merge($base, array('special_ad_category_country' => array('US')));
			$candidates[] = array_merge($base, array('special_ad_category_country' => array('US'), 'buying_type' => 'AUCTION'));
			$candidates[] = $base;
			return $candidates;
		}

		private static function validate_paused_campaign_payload_candidates(array $candidates)
		{
			foreach ($candidates as $index => $candidate) {
				$candidate = is_array($candidate) ? $candidate : array();
				$status = strtoupper(sanitize_text_field((string) ($candidate['status'] ?? '')));
				if ($status !== self::STATUS_PAUSED) {
					return new WP_Error(
						'campaign_status_not_paused',
						sprintf(
							/* translators: %d is the 1-based fallback index */
							__('Create in Meta (PAUSED) refused to continue because campaign payload candidate #%d was missing explicit status=PAUSED.', 'vms-meta-ads'),
							$index + 1
						),
						array('status' => 500)
					);
				}
			}

			return true;
		}

		private static function campaign_payload_for_form(array $payload): array
		{
			$form = $payload;
			$form['special_ad_categories'] = wp_json_encode(array());
			if (array_key_exists('is_adset_budget_sharing_enabled', $form)) {
				$form['is_adset_budget_sharing_enabled'] = !empty($form['is_adset_budget_sharing_enabled']) ? 'true' : 'false';
			}
			if (isset($form['special_ad_category_country']) && is_array($form['special_ad_category_country'])) {
				$form['special_ad_category_country'] = wp_json_encode(array_values($form['special_ad_category_country']));
			}
			return $form;
		}

		private static function is_invalid_parameter_error(WP_Error $error): bool
		{
			$message = strtolower((string) $error->get_error_message());
			return strpos($message, 'invalid parameter') !== false;
		}

		private static function is_objective_error(WP_Error $error): bool
		{
			$message = strtolower((string) $error->get_error_message());
			return strpos($message, 'objective') !== false;
		}

		private static function wrap_step_error(string $step, WP_Error $error): WP_Error
		{
			$data = $error->get_error_data();
			$details = '';
			if (is_array($data) && !empty($data['meta']) && is_array($data['meta'])) {
				$meta = (array) $data['meta'];
				$parts = array();
				if (!empty($meta['code'])) {
					$parts[] = 'code ' . (string) absint($meta['code']);
				}
				if (!empty($meta['subcode'])) {
					$parts[] = 'subcode ' . (string) absint($meta['subcode']);
				}
				if (!empty($meta['blame_field'])) {
					$parts[] = 'field ' . sanitize_text_field((string) $meta['blame_field']);
				}
				if (!empty($meta['fbtrace_id'])) {
					$parts[] = 'trace ' . sanitize_text_field((string) $meta['fbtrace_id']);
				}
				if (!empty($parts)) {
					$details = ' (' . implode(', ', $parts) . ')';
				}
			}

			return new WP_Error(
				$error->get_error_code(),
				sprintf(__('%1$s failed: %2$s%3$s', 'vms-meta-ads'), sanitize_text_field($step), $error->get_error_message(), $details),
				$data
			);
		}

		private static function fetch_recent_campaigns(array $settings)
		{
			$response = self::meta_get_request(
				$settings,
				VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']) . '/campaigns',
				array(
					'fields' => 'id,name,objective,status,configured_status,effective_status,created_time,updated_time,start_time,stop_time',
					'limit' => 75,
				),
				'discover_campaigns',
				'ad_builder',
				25
			);
			if (is_wp_error($response)) {
				return new WP_Error('meta_discovery_failed', __('Could not search Meta campaigns due to a network error.', 'vms-meta-ads'), array('status' => 400));
			}
			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || !is_array($body) || isset($body['error'])) {
				$meta_error = self::extract_meta_error(is_array($body) ? $body : array(), $code);
				return new WP_Error('meta_discovery_failed', sprintf(__('Meta campaign search failed: %s', 'vms-meta-ads'), $meta_error['message']), array('status' => 400));
			}
			return array_values(is_array($body['data'] ?? null) ? (array) $body['data'] : array());
		}

		private static function fetch_campaign_adsets(string $campaign_id, array $settings)
		{
			$campaign_id = trim($campaign_id);
			if ($campaign_id === '') {
				return array();
			}
			$response = self::meta_get_request(
				$settings,
				$campaign_id . '/adsets',
				array(
					'fields' => 'id,name,daily_budget,lifetime_budget,start_time,end_time,configured_status,effective_status,optimization_goal,targeting',
					'limit' => 25,
				),
				'discover_adsets',
				'ad_builder',
				25
			);
			if (is_wp_error($response)) {
				return $response;
			}
			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || !is_array($body) || isset($body['error'])) {
				$meta_error = self::extract_meta_error(is_array($body) ? $body : array(), $code);
				return new WP_Error('meta_adset_discovery_failed', sprintf(__('Meta ad set search failed: %s', 'vms-meta-ads'), $meta_error['message']));
			}
			return array_values(is_array($body['data'] ?? null) ? (array) $body['data'] : array());
		}

		private static function fetch_adset_ads(string $adset_id, array $settings)
		{
			$adset_id = trim($adset_id);
			if ($adset_id === '') {
				return array();
			}
			$response = self::meta_get_request(
				$settings,
				$adset_id . '/ads',
				array(
					'fields' => 'id,name,configured_status,effective_status,creative{id,name,object_story_spec,asset_feed_spec,url_tags}',
					'limit' => 50,
				),
				'discover_ads',
				'ad_builder',
				25
			);
			if (is_wp_error($response)) {
				return $response;
			}
			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || !is_array($body) || isset($body['error'])) {
				$meta_error = self::extract_meta_error(is_array($body) ? $body : array(), $code);
				return new WP_Error('meta_ad_discovery_failed', sprintf(__('Meta ad search failed: %s', 'vms-meta-ads'), $meta_error['message']));
			}
			return array_values(is_array($body['data'] ?? null) ? (array) $body['data'] : array());
		}

		private static function build_discovery_needles(array $event, array $build = array()): array
		{
			$title = sanitize_text_field((string) ($event['title'] ?? ($build['copy_payload']['event_name'] ?? '')));
			$destination = esc_url_raw((string) (($build['destination_url'] ?? '') ?: ($event['ticket_url'] ?? ($event['event_permalink'] ?? ''))));
			$slug = $destination !== '' ? sanitize_title(wp_parse_url($destination, PHP_URL_PATH) ?: '') : '';
			$date_raw = sanitize_text_field((string) ($event['start_input'] ?? ($event['start_local'] ?? ($build['copy_payload']['event_start'] ?? ''))));
			$date_bits = array();
			$ts = $date_raw !== '' ? strtotime($date_raw) : false;
			if ($ts) {
				$date_bits[] = wp_date('Y-m-d', $ts, wp_timezone());
				$date_bits[] = wp_date('n/j', $ts, wp_timezone());
				$date_bits[] = wp_date('M j', $ts, wp_timezone());
			}
			$tokens = self::important_match_tokens($title . ' ' . str_replace(array('-', '_', '/'), ' ', $slug));
			return array(
				'title' => $title,
				'title_norm' => self::normalize_match_text($title),
				'tokens' => $tokens,
				'destination_url' => $destination,
				'destination_host' => $destination !== '' ? strtolower((string) wp_parse_url($destination, PHP_URL_HOST)) : '',
				'destination_slug' => $slug,
				'date_bits' => array_values(array_unique(array_filter($date_bits))),
			);
		}

		private static function normalize_match_text(string $value): string
		{
			$value = strtolower(wp_strip_all_tags($value));
			$value = preg_replace('/[^a-z0-9]+/', ' ', $value);
			return trim((string) preg_replace('/\s+/', ' ', (string) $value));
		}

		private static function important_match_tokens(string $value): array
		{
			$norm = self::normalize_match_text($value);
			if ($norm === '') {
				return array();
			}
			$stop = array('the', 'and', 'for', 'with', 'this', 'that', 'live', 'music', 'concert', 'tribute', 'tickets', 'ticket', 'event', 'show', 'at', 'in', 'on', 'to', 'a', 'an', 'of');
			$tokens = array();
			foreach (explode(' ', $norm) as $token) {
				$token = trim($token);
				if (strlen($token) < 4 || in_array($token, $stop, true)) {
					continue;
				}
				$tokens[] = $token;
			}
			return array_values(array_unique(array_slice($tokens, 0, 12)));
		}

		private static function score_meta_object_match(string $value, array $needles): int
		{
			$hay = self::normalize_match_text($value);
			if ($hay === '') {
				return 0;
			}
			$score = 0;
			$title_norm = (string) ($needles['title_norm'] ?? '');
			if ($title_norm !== '' && strpos($hay, $title_norm) !== false) {
				$score += 45;
			}
			foreach ((array) ($needles['tokens'] ?? array()) as $token) {
				if ($token !== '' && strpos($hay, (string) $token) !== false) {
					$score += 12;
				}
			}
			foreach ((array) ($needles['date_bits'] ?? array()) as $date_bit) {
				$date_norm = self::normalize_match_text((string) $date_bit);
				if ($date_norm !== '' && strpos($hay, $date_norm) !== false) {
					$score += 8;
				}
			}
			return $score;
		}

		private static function score_url_match(string $url, array $needles): int
		{
			$url = esc_url_raw($url);
			if ($url === '') {
				return 0;
			}
			$score = 0;
			$target = esc_url_raw((string) ($needles['destination_url'] ?? ''));
			if ($target !== '' && untrailingslashit($url) === untrailingslashit($target)) {
				$score += 60;
			}
			$host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
			if ($host !== '' && $host === (string) ($needles['destination_host'] ?? '')) {
				$score += 10;
			}
			$slug = sanitize_title(wp_parse_url($url, PHP_URL_PATH) ?: '');
			$target_slug = (string) ($needles['destination_slug'] ?? '');
			if ($slug !== '' && $target_slug !== '' && ($slug === $target_slug || strpos($slug, $target_slug) !== false || strpos($target_slug, $slug) !== false)) {
				$score += 35;
			}
			return $score;
		}

		private static function extract_ad_destination_url(array $ad): string
		{
			$creative = is_array($ad['creative'] ?? null) ? (array) $ad['creative'] : array();
			$oss = is_array($creative['object_story_spec'] ?? null) ? (array) $creative['object_story_spec'] : array();
			$link_data = is_array($oss['link_data'] ?? null) ? (array) $oss['link_data'] : array();
			foreach (array('link', 'caption') as $field) {
				$candidate = esc_url_raw((string) ($link_data[$field] ?? ''));
				if ($candidate !== '') {
					return $candidate;
				}
			}
			$call_to_action = is_array($link_data['call_to_action'] ?? null) ? (array) $link_data['call_to_action'] : array();
			$cta_value = is_array($call_to_action['value'] ?? null) ? (array) $call_to_action['value'] : array();
			$candidate = esc_url_raw((string) ($cta_value['link'] ?? ''));
			if ($candidate !== '') {
				return $candidate;
			}
			$asset_feed = is_array($creative['asset_feed_spec'] ?? null) ? (array) $creative['asset_feed_spec'] : array();
			foreach ((array) ($asset_feed['link_urls'] ?? array()) as $link_row) {
				if (is_array($link_row) && !empty($link_row['website_url'])) {
					$candidate = esc_url_raw((string) $link_row['website_url']);
					if ($candidate !== '') {
						return $candidate;
					}
				}
			}
			return '';
		}

		private static function format_discovery_confidence(int $score): string
		{
			if ($score >= 70) {
				return 'high';
			}
			if ($score >= 40) {
				return 'medium';
			}
			return 'low';
		}

		private static function summarize_meta_targeting(array $targeting): string
		{
			$parts = array();
			$age_min = absint($targeting['age_min'] ?? 0);
			$age_max = absint($targeting['age_max'] ?? 0);
			$geo = is_array($targeting['geo_locations'] ?? null) ? (array) $targeting['geo_locations'] : array();
			$radius = '';
			if (!empty($geo['custom_locations']) && is_array($geo['custom_locations'])) {
				$first = is_array($geo['custom_locations'][0] ?? null) ? (array) $geo['custom_locations'][0] : array();
				if (!empty($first['radius'])) {
					$radius = absint($first['radius']) . 'mi';
				}
			}
			if ($radius !== '') {
				$parts[] = $radius;
			}
			if ($age_min > 0 && $age_max >= $age_min) {
				$parts[] = 'age ' . $age_min . '-' . $age_max;
			}
			return implode(' • ', $parts);
		}

		private static function build_drift_report(array $build, array $ids, ?array $settings = null): array
		{
			if ($settings === null) {
				$settings = self::connection_settings();
			}
			$rows = array();
			if (is_wp_error($settings) || empty($ids['adset_id'])) {
				return array('status' => 'unknown', 'summary' => __('Drift could not be checked.', 'vms-meta-ads'), 'items' => array());
			}
			$state = self::fetch_adset_state((string) $ids['adset_id'], $settings);
			if (is_wp_error($state)) {
				return array('status' => 'unknown', 'summary' => $state->get_error_message(), 'items' => array());
			}
			$targeting = is_array($build['targeting_payload'] ?? null) ? (array) $build['targeting_payload'] : array();
			$live_targeting = is_array($state['targeting'] ?? null) ? (array) $state['targeting'] : array();
			$expected_age_min = absint($targeting['age_min'] ?? 0);
			$expected_age_max = absint($targeting['age_max'] ?? 0);
			$live_age_min = absint($live_targeting['age_min'] ?? 0);
			$live_age_max = absint($live_targeting['age_max'] ?? 0);
			if ($expected_age_min > 0 && $live_age_min > 0 && ($expected_age_min !== $live_age_min || $expected_age_max !== $live_age_max)) {
				$rows[] = array('field' => 'Audience age', 'expected' => $expected_age_min . '-' . $expected_age_max, 'live' => $live_age_min . '-' . $live_age_max, 'severity' => 'warning');
			}
			$expected_radius = absint($targeting['radius_miles'] ?? 0);
			$live_radius = self::extract_targeting_radius($live_targeting);
			if ($expected_radius > 0 && $live_radius > 0 && $expected_radius !== $live_radius) {
				$rows[] = array('field' => 'Audience radius', 'expected' => $expected_radius . 'mi', 'live' => $live_radius . 'mi', 'severity' => 'warning');
			}
			$expected_budget = 0;
			if (!empty($build['tiers']) && is_array($build['tiers'])) {
				foreach ((array) $build['tiers'] as $tier) {
					if (is_array($tier)) {
						$expected_budget += absint($tier['budget_amount_minor'] ?? 0);
					}
				}
			}
			if ($expected_budget < 1) {
				$budget_payload = is_array($build['budget_payload'] ?? null) ? (array) $build['budget_payload'] : array();
				$expected_budget = absint($budget_payload['total_budget_minor'] ?? 0);
			}
			$live_budget = absint($state['budget_minor'] ?? 0);
			if ($expected_budget > 0 && $live_budget > 0 && abs($expected_budget - $live_budget) >= 100) {
				$rows[] = array('field' => 'Budget', 'expected' => self::format_minor_budget($expected_budget), 'live' => self::format_minor_budget($live_budget), 'severity' => 'warning');
			}
			$optimization = self::map_optimization_goal(self::resolve_build_optimization($build));
			$live_opt = strtoupper((string) ($state['optimization_goal'] ?? ''));
			if ($live_opt !== '' && $optimization !== '' && $live_opt !== $optimization) {
				$rows[] = array('field' => 'Optimization', 'expected' => $optimization, 'live' => $live_opt, 'severity' => 'info');
			}
			$creative_rows = self::build_creative_lock_report_items($build, $ids, $settings);
			if (!empty($creative_rows)) {
				$rows = array_merge($rows, $creative_rows);
			}
			$status = empty($rows) ? 'clean' : 'drift';
			return array(
				'status' => $status,
				'summary' => empty($rows) ? __('No major drift detected against the saved build.', 'vms-meta-ads') : sprintf(_n('%d difference found between the saved build and Meta.', '%d differences found between the saved build and Meta.', count($rows), 'vms-meta-ads'), count($rows)),
				'items' => $rows,
			);
		}


		private static function build_creative_lock_report_items(array $build, array $ids, array $settings): array
		{
			$expected_url = esc_url_raw((string) (($build['utm_url'] ?? '') ?: ($build['destination_url'] ?? '')));
			if ($expected_url === '') {
				return array();
			}
			$ad_ids = !empty($ids['ad_ids']) && is_array($ids['ad_ids']) ? array_values(array_filter(array_map('sanitize_text_field', (array) $ids['ad_ids']))) : array();
			if (empty($ad_ids) && !empty($ids['ad_id'])) {
				$ad_ids[] = sanitize_text_field((string) $ids['ad_id']);
			}
			if (empty($ad_ids)) {
				return array();
			}
			$rows = array();
			$expected_base = self::normalize_url_for_compare($expected_url);
			$checked = 0;
			foreach ($ad_ids as $ad_id) {
				if ($checked >= 12) {
					break;
				}
				$checked++;
				$snapshot = self::fetch_ad_creative_snapshot($ad_id, $settings);
				if (is_wp_error($snapshot)) {
					$rows[] = array('field' => 'Creative QA', 'expected' => 'Readable creative', 'live' => $snapshot->get_error_message(), 'severity' => 'info');
					continue;
				}
				$creative = is_array($snapshot['creative'] ?? null) ? (array) $snapshot['creative'] : array();
				$live_url = self::extract_creative_destination_url($creative);
				if ($live_url !== '' && self::normalize_url_for_compare($live_url) !== $expected_base) {
					$rows[] = array('field' => 'Creative destination', 'expected' => $expected_url, 'live' => $live_url, 'severity' => 'warning');
				}
				$url_tags = sanitize_text_field((string) ($creative['url_tags'] ?? ''));
				$utm_source = strtolower($live_url . '&' . $url_tags);
				if (strpos($utm_source, 'utm_campaign=') === false) {
					$rows[] = array('field' => 'Creative UTM tags', 'expected' => 'utm_campaign present', 'live' => $live_url !== '' ? $live_url : ($url_tags !== '' ? $url_tags : 'No URL tags visible'), 'severity' => 'warning');
				}
			}
			return $rows;
		}

		private static function fetch_ad_creative_snapshot(string $ad_id, array $settings)
		{
			$ad_id = trim($ad_id);
			if ($ad_id === '') {
				return new WP_Error('missing_ad_id', __('Meta ad ID is missing.', 'vms-meta-ads'));
			}
			$full_fields = 'id,name,creative{id,name,object_story_spec,asset_feed_spec,url_tags,degrees_of_freedom_spec}';
			$fallback_fields = 'id,name,creative{id,name,object_story_spec,asset_feed_spec,url_tags}';
			$response = self::meta_get_request(
				$settings,
				$ad_id,
				array('fields' => $full_fields),
				'fetch_ad_creative_qa',
				'ad_builder',
				25
			);
			if (is_wp_error($response)) {
				return new WP_Error('meta_creative_qa_failed', __('Creative QA could not read the ad creative.', 'vms-meta-ads'));
			}
			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if (self::should_retry_meta_get_without_optional_fields($code, $body, array('degrees_of_freedom_spec'))) {
				$response = self::meta_get_request(
					$settings,
					$ad_id,
					array('fields' => $fallback_fields),
					'fetch_ad_creative_qa_fallback',
					'ad_builder',
					25
				);
				if (is_wp_error($response)) {
					return new WP_Error('meta_creative_qa_failed', __('Creative QA could not read the ad creative.', 'vms-meta-ads'));
				}
				$code = (int) wp_remote_retrieve_response_code($response);
				$body = json_decode((string) wp_remote_retrieve_body($response), true);
			}
			if ($code < 200 || $code >= 300 || !is_array($body) || isset($body['error'])) {
				$meta_error = self::extract_meta_error(is_array($body) ? $body : array(), $code);
				return new WP_Error('meta_creative_qa_failed', sprintf(__('Creative QA lookup failed: %s', 'vms-meta-ads'), $meta_error['message']));
			}
			return $body;
		}

		private static function should_retry_meta_get_without_optional_fields(int $code, $body, array $optional_fields): bool
		{
			if ($code >= 200 && $code < 300) {
				return false;
			}
			if (!is_array($body) || empty($body['error']) || !is_array($body['error'])) {
				return false;
			}
			$message = strtolower((string) ($body['error']['message'] ?? ''));
			if ($message === '') {
				return false;
			}
			foreach ($optional_fields as $field) {
				$field = strtolower((string) $field);
				if ($field !== '' && strpos($message, $field) !== false) {
					return true;
				}
			}
			return false;
		}

		private static function extract_creative_destination_url(array $creative): string
		{
			$oss = is_array($creative['object_story_spec'] ?? null) ? (array) $creative['object_story_spec'] : array();
			foreach (array('link_data', 'video_data') as $story_key) {
				$data = is_array($oss[$story_key] ?? null) ? (array) $oss[$story_key] : array();
				foreach (array('link', 'caption') as $field) {
					$candidate = esc_url_raw((string) ($data[$field] ?? ''));
					if ($candidate !== '') {
						return $candidate;
					}
				}
				$cta = is_array($data['call_to_action'] ?? null) ? (array) $data['call_to_action'] : array();
				$cta_value = is_array($cta['value'] ?? null) ? (array) $cta['value'] : array();
				$candidate = esc_url_raw((string) ($cta_value['link'] ?? ''));
				if ($candidate !== '') {
					return $candidate;
				}
			}
			$asset_feed = is_array($creative['asset_feed_spec'] ?? null) ? (array) $creative['asset_feed_spec'] : array();
			foreach ((array) ($asset_feed['link_urls'] ?? array()) as $row) {
				if (!is_array($row)) {
					continue;
				}
				$candidate = esc_url_raw((string) ($row['website_url'] ?? ''));
				if ($candidate !== '') {
					return $candidate;
				}
			}
			return '';
		}

		private static function extract_creative_cta_type(array $creative): string
		{
			$oss = is_array($creative['object_story_spec'] ?? null) ? (array) $creative['object_story_spec'] : array();
			foreach (array('link_data', 'video_data') as $story_key) {
				$data = is_array($oss[$story_key] ?? null) ? (array) $oss[$story_key] : array();
				$cta = is_array($data['call_to_action'] ?? null) ? (array) $data['call_to_action'] : array();
				$type = sanitize_text_field((string) ($cta['type'] ?? ''));
				if ($type !== '') {
					return strtoupper($type);
				}
			}
			$asset_feed = is_array($creative['asset_feed_spec'] ?? null) ? (array) $creative['asset_feed_spec'] : array();
			foreach ((array) ($asset_feed['call_to_action_types'] ?? array()) as $type) {
				$type = sanitize_text_field((string) $type);
				if ($type !== '') {
					return strtoupper($type);
				}
			}
			return '';
		}

		private static function extract_creative_feature_readback(array $creative): array
		{
			$spec = $creative['degrees_of_freedom_spec'] ?? array();
			if (is_string($spec) && $spec !== '') {
				$decoded = json_decode($spec, true);
				$spec = is_array($decoded) ? $decoded : array();
			}
			if (!is_array($spec)) {
				$spec = array();
			}
			$features = is_array($spec['creative_features_spec'] ?? null) ? (array) $spec['creative_features_spec'] : array();
			$standard = is_array($features['standard_enhancements'] ?? null) ? (array) $features['standard_enhancements'] : array();
			$multi = is_array($features['contextual_multi_ads'] ?? null) ? (array) $features['contextual_multi_ads'] : array();
			return array(
				'standard_enhancements' => self::normalized_status_value((string) ($standard['enroll_status'] ?? '')),
				'contextual_multi_ads' => self::normalized_status_value((string) ($multi['enroll_status'] ?? '')),
			);
		}

		private static function extract_live_placement_keys_from_targeting(array $targeting): array
		{
			$platforms = array_values(array_unique(array_filter(array_map('sanitize_key', (array) ($targeting['publisher_platforms'] ?? array())))));
			$facebook_positions = array_values(array_unique(array_filter(array_map('sanitize_key', (array) ($targeting['facebook_positions'] ?? array())))));
			$instagram_positions = array_values(array_unique(array_filter(array_map('sanitize_key', (array) ($targeting['instagram_positions'] ?? array())))));
			if (empty($platforms) && empty($facebook_positions) && empty($instagram_positions)) {
				return array();
			}

			$keys = array();
			foreach ($facebook_positions as $position) {
				$map = array(
					'feed' => 'fb_feed',
					'profile_feed' => 'fb_profile_feed',
					'right_hand_column' => 'fb_right_column',
					'search' => 'fb_search',
					'story' => 'fb_story',
					'reels' => 'fb_reels',
				);
				if (!empty($map[$position])) {
					$keys[] = $map[$position];
				}
			}
			foreach ($instagram_positions as $position) {
				$map = array(
					'stream' => 'ig_feed',
					'search' => 'ig_search',
					'explore' => 'ig_explore',
					'story' => 'ig_story',
					'reels' => 'ig_reels',
				);
				if (!empty($map[$position])) {
					$keys[] = $map[$position];
				}
			}
			return array_values(array_unique(array_filter($keys)));
		}

		private static function build_readiness_item(string $key, string $label, string $state, string $summary, string $detail = ''): array
		{
			$state = sanitize_key($state);
			if (!in_array($state, array('ok', 'warning', 'error'), true)) {
				$state = 'warning';
			}
			return array(
				'key' => sanitize_key($key),
				'label' => sanitize_text_field($label),
				'state' => $state,
				'summary' => sanitize_text_field($summary),
				'detail' => sanitize_text_field($detail),
			);
		}

		private static function summarize_meta_issues_readiness_item(array $adset_state): array
		{
			$recommendations = is_array($adset_state['recommendations'] ?? null) ? array_values((array) $adset_state['recommendations']) : array();
			$issues_info = $adset_state['issues_info'] ?? null;
			$issue_count = is_array($issues_info) ? count($issues_info) : (empty($issues_info) ? 0 : 1);
			$recommendation_count = count($recommendations);
			if ($issue_count > 0) {
				return self::build_readiness_item(
					'meta_issues',
					__('Meta issues / recommendations', 'vms-meta-ads'),
					'error',
					sprintf(__('issues_info %1$d · recommendations %2$d', 'vms-meta-ads'), $issue_count, $recommendation_count),
					__('Meta returned one or more issues_info entries. Treat those as blocking until manual review confirms they are harmless.', 'vms-meta-ads')
				);
			}
			if ($recommendation_count > 0) {
				return self::build_readiness_item(
					'meta_issues',
					__('Meta issues / recommendations', 'vms-meta-ads'),
					'warning',
					sprintf(__('issues_info %1$d · recommendations %2$d', 'vms-meta-ads'), $issue_count, $recommendation_count),
					__('Meta returned recommendations. Review them before any Go Live step, but they are not the same as a failed create.', 'vms-meta-ads')
				);
			}
			return self::build_readiness_item(
				'meta_issues',
				__('Meta issues / recommendations', 'vms-meta-ads'),
				'ok',
				__('No API issues_info or recommendations returned.', 'vms-meta-ads'),
				__('No extra Meta review hints were returned for this ad set.', 'vms-meta-ads')
			);
		}

		private static function persisted_dsa_payload_from_build(array $build): array
		{
			$meta_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			$payload = is_array($meta_ids['dsa_payload'] ?? null) ? (array) $meta_ids['dsa_payload'] : array();
			return array(
				'dsa_beneficiary' => sanitize_text_field((string) ($payload['dsa_beneficiary'] ?? '')),
				'dsa_payor' => sanitize_text_field((string) ($payload['dsa_payor'] ?? '')),
			);
		}

		private static function build_post_create_dsa_readiness_item(array $build, array $settings, array $adset_state): array
		{
			$dsa_beneficiary = sanitize_text_field((string) ($adset_state['dsa_beneficiary'] ?? ''));
			$dsa_payor = sanitize_text_field((string) ($adset_state['dsa_payor'] ?? ''));
			$settings_dsa = self::dsa_readiness($settings);
			$persisted_payload = self::persisted_dsa_payload_from_build($build);
			$readback_present = ($dsa_beneficiary !== '' && $dsa_payor !== '');
			$configured = !empty($settings_dsa['ready']);
			$sent_in_payload = ($persisted_payload['dsa_beneficiary'] !== '' && $persisted_payload['dsa_payor'] !== '');
			if (!$sent_in_payload && $configured) {
				$sent_in_payload = true;
				$persisted_payload = array(
					'dsa_beneficiary' => sanitize_text_field((string) ($settings_dsa['beneficiary'] ?? '')),
					'dsa_payor' => sanitize_text_field((string) ($settings_dsa['payor'] ?? '')),
				);
			}
			$issues_info = $adset_state['issues_info'] ?? null;
			$issue_count = is_array($issues_info) ? count($issues_info) : (empty($issues_info) ? 0 : 1);
			$not_returned_by_meta = !$readback_present;
			$manual_review_recommended = false;
			$not_blocking_optional = false;

			if ($readback_present) {
				$item = self::build_readiness_item(
					'dsa',
					__('DSA advertiser / payer', 'vms-meta-ads'),
					'ok',
					__('DSA beneficiary and payor are present on the ad set.', 'vms-meta-ads'),
					sprintf(__('Beneficiary: %1$s · Payor: %2$s', 'vms-meta-ads'), $dsa_beneficiary, $dsa_payor)
				);
			} elseif (!$configured) {
				$item = self::build_readiness_item(
					'dsa',
					__('DSA advertiser / payer', 'vms-meta-ads'),
					'warning',
					__('DSA beneficiary/payor are not configured in MAB settings.', 'vms-meta-ads'),
					__('Future create payloads will omit missing DSA values until Settings are filled in. Treat this as a readiness warning before any Go Live step.', 'vms-meta-ads')
				);
			} else {
				$manual_review_recommended = true;
				$not_blocking_optional = ($issue_count === 0);
				$detail = sprintf(
					__('Configured Beneficiary: %1$s · Configured Payor: %2$s. These values were prepared for the create payload, but Meta did not return them in ad-set readback. Ads Manager may treat Advertiser/Payer as optional. Verify there before publishing; this does not mean the paused create failed.', 'vms-meta-ads'),
					sanitize_text_field((string) ($persisted_payload['dsa_beneficiary'] ?? ($settings_dsa['beneficiary'] ?? ''))),
					sanitize_text_field((string) ($persisted_payload['dsa_payor'] ?? ($settings_dsa['payor'] ?? '')))
				);
				if ($issue_count > 0) {
					$detail .= ' ' . __('Meta also returned issues_info for this ad set, so treat those issues as blocking until manual review.', 'vms-meta-ads');
				}
				$item = self::build_readiness_item(
					'dsa',
					__('DSA advertiser / payer', 'vms-meta-ads'),
					'warning',
					__('Advertiser/Payer values were configured and sent, but Meta did not return them in API readback.', 'vms-meta-ads'),
					$detail
				);
			}

			$item['classification'] = array(
				'configured' => $configured,
				'sent_in_payload' => $sent_in_payload,
				'not_returned_by_meta' => $not_returned_by_meta,
				'manual_ads_manager_review_recommended' => $manual_review_recommended,
				'not_blocking_optional' => $not_blocking_optional,
				'readback_present' => $readback_present,
			);
			return $item;
		}

		private static function summarize_status_readiness_item(string $key, string $label, array $row): array
		{
			$configured = self::configured_status_value($row);
			$effective = self::effective_status_value($row);
			$summary = $configured . ' / ' . $effective;
			if (self::is_active_status_value($configured) || self::is_active_status_value($effective)) {
				return self::build_readiness_item($key, $label, 'error', $summary, __('Active delivery is not safe for a paused-review workflow.', 'vms-meta-ads'));
			}
			if (self::is_problem_status_value($configured) || self::is_problem_status_value($effective)) {
				return self::build_readiness_item($key, $label, 'error', $summary, __('Meta reported a non-paused status that needs manual review.', 'vms-meta-ads'));
			}
			if (self::is_reviewing_status_value($configured) || self::is_reviewing_status_value($effective)) {
				return self::build_readiness_item($key, $label, 'warning', $summary, __('Meta is still reviewing this object. It is safely inactive, but not fully settled yet.', 'vms-meta-ads'));
			}
			if ($configured === self::STATUS_PAUSED && $effective === self::STATUS_PAUSED) {
				return self::build_readiness_item($key, $label, 'ok', $summary, __('Paused and inactive.', 'vms-meta-ads'));
			}
			if (self::is_safe_inactive_status_value($configured) && self::is_safe_inactive_status_value($effective)) {
				return self::build_readiness_item($key, $label, 'warning', $summary, __('Inactive, but the effective status is not a clean PAUSED state yet.', 'vms-meta-ads'));
			}
			return self::build_readiness_item($key, $label, 'error', $summary, __('Status could not be classified safely.', 'vms-meta-ads'));
		}

		private static function expected_placement_readiness(array $build, array $settings): array
		{
			$placements_payload = is_array($build['placements_payload'] ?? null) ? (array) $build['placements_payload'] : array();
			$ig_actor_id = trim((string) ($settings['meta_ig_actor_id'] ?? ''));
			$resolved_payload = $placements_payload;
			$warnings = array();
			$resolution = self::resolve_effective_placements_for_create($placements_payload, $ig_actor_id);
			if (is_array($resolution)) {
				$resolved_payload = (array) ($resolution['placements_payload'] ?? $placements_payload);
				$warnings = array_values(array_filter(array_map('sanitize_text_field', (array) ($resolution['warnings'] ?? array()))));
			}
			$mode = sanitize_key((string) ($resolved_payload['mode'] ?? 'automatic'));
			$matrix = self::resolve_asset_feed_placement_matrix($resolved_payload, $ig_actor_id !== '');
			$keys = self::placement_keys_from_matrix($matrix);
			$labels = self::placement_labels_from_keys($keys);
			return array(
				'mode' => $mode === 'manual' ? 'manual' : 'automatic',
				'mode_label' => self::placement_mode_label($mode),
				'keys' => $keys,
				'labels' => $labels,
				'summary' => self::format_placement_label_list($labels),
				'warnings' => $warnings,
			);
		}

		private static function build_post_create_readiness(array $build, array $ids, array $snapshot, ?array $settings = null): array
		{
			if ($settings === null) {
				$settings = self::connection_settings();
			}
			if (is_wp_error($settings)) {
				return array(
					'state' => 'warning',
					'items' => array(
						self::build_readiness_item('readiness', __('Readiness', 'vms-meta-ads'), 'warning', __('Read-only readiness could not load connection settings.', 'vms-meta-ads')),
					),
					'notes' => array(),
				);
			}

			$items = array(
				self::summarize_status_readiness_item('campaign_status', __('Campaign status', 'vms-meta-ads'), (array) ($snapshot['campaign'] ?? array())),
				self::summarize_status_readiness_item('adset_status', __('Ad set status', 'vms-meta-ads'), (array) ($snapshot['adset'] ?? array())),
				self::summarize_status_readiness_item('ad_status', __('Ad status', 'vms-meta-ads'), (array) ($snapshot['ad'] ?? array())),
			);

			$adset_state = !empty($ids['adset_id']) ? self::fetch_adset_state((string) $ids['adset_id'], $settings) : null;
			$creative_snapshot = !empty($ids['ad_id']) ? self::fetch_ad_creative_snapshot((string) $ids['ad_id'], $settings) : null;
			$creative = is_array($creative_snapshot) && is_array($creative_snapshot['creative'] ?? null) ? (array) $creative_snapshot['creative'] : array();
			$notes = array();

			if (is_wp_error($adset_state)) {
				$items[] = self::build_readiness_item('geo_targeting', __('Geo targeting', 'vms-meta-ads'), 'warning', __('Ad set targeting could not be read back yet.', 'vms-meta-ads'), $adset_state->get_error_message());
			} else {
				$targeting = is_array($adset_state['targeting'] ?? null) ? (array) $adset_state['targeting'] : array();
				$geo = is_array($targeting['geo_locations'] ?? null) ? (array) $targeting['geo_locations'] : array();
				$custom_count = count((array) ($geo['custom_locations'] ?? array()));
				$city_count = count((array) ($geo['cities'] ?? array()));
				$zip_count = count((array) ($geo['zips'] ?? array()));
				$region_count = count((array) ($geo['regions'] ?? array()));
				$radius = self::extract_targeting_radius($targeting);
				$geo_present = ($custom_count + $city_count + $zip_count + $region_count) > 0;
				$geo_summary = $geo_present
					? sprintf(__('custom %1$d · cities %2$d · zips %3$d · radius %4$dmi', 'vms-meta-ads'), $custom_count, $city_count, $zip_count, $radius)
					: __('No readable geo targeting was returned.', 'vms-meta-ads');
				$items[] = self::build_readiness_item('geo_targeting', __('Geo targeting', 'vms-meta-ads'), $geo_present ? 'ok' : 'error', $geo_summary, $geo_present ? __('Meta returned location targeting for this ad set.', 'vms-meta-ads') : __('Ads Manager warnings about locations should be treated as real until this reads back cleanly.', 'vms-meta-ads'));

				$promoted_object = is_array($adset_state['promoted_object'] ?? null) ? (array) $adset_state['promoted_object'] : array();
				$pixel_id = sanitize_text_field((string) ($promoted_object['pixel_id'] ?? ''));
				$pixel_state = $pixel_id !== '' ? 'ok' : 'warning';
				$pixel_summary = $pixel_id !== '' ? sprintf(__('Pixel %s attached', 'vms-meta-ads'), $pixel_id) : __('No pixel read back on the ad set.', 'vms-meta-ads');
				$items[] = self::build_readiness_item('pixel', __('Pixel / promoted object', 'vms-meta-ads'), $pixel_state, $pixel_summary, $pixel_id !== '' ? sanitize_text_field((string) ($promoted_object['custom_event_type'] ?? '')) : __('Sales / purchase flows should show a pixel and PURCHASE event before publish.', 'vms-meta-ads'));

				$items[] = self::build_post_create_dsa_readiness_item($build, $settings, $adset_state);
				$items[] = self::summarize_meta_issues_readiness_item($adset_state);

				$expected_placements = self::expected_placement_readiness($build, $settings);
				$live_placement_keys = self::extract_live_placement_keys_from_targeting($targeting);
				$placement_state = 'ok';
				$placement_detail = __('Expected placements match the saved MAB build.', 'vms-meta-ads');
				if ($expected_placements['mode'] !== 'manual') {
					$placement_state = 'warning';
					$placement_detail = __('Automatic placements are configured. Meta may imply broader placement coverage in edit UI. Recheck review/readiness before any Go Live step.', 'vms-meta-ads');
				} elseif (empty($live_placement_keys)) {
					$placement_state = 'warning';
					$placement_detail = __('Live placement keys were not readable from targeting. Review Ads Manager before publish.', 'vms-meta-ads');
				} else {
					$expected_keys = array_values(array_unique(array_filter(array_map('sanitize_key', (array) $expected_placements['keys']))));
					sort($expected_keys);
					$live_sorted = array_values(array_unique(array_filter(array_map('sanitize_key', $live_placement_keys))));
					sort($live_sorted);
					if ($expected_keys !== $live_sorted) {
						$placement_state = 'warning';
						$placement_detail = sprintf(__('Expected %1$s · Live %2$s', 'vms-meta-ads'), self::format_placement_label_list(self::placement_labels_from_keys($expected_keys)), self::format_placement_label_list(self::placement_labels_from_keys($live_sorted)));
					}
				}
				if (!empty($expected_placements['warnings'])) {
					$notes = array_merge($notes, (array) $expected_placements['warnings']);
				}
				$items[] = self::build_readiness_item('placements', __('Placements', 'vms-meta-ads'), $placement_state, trim((string) $expected_placements['mode_label'] . ' · ' . (string) $expected_placements['summary']), $placement_detail);
			}

			if (is_wp_error($creative_snapshot)) {
				$items[] = self::build_readiness_item('creative_readback', __('Creative readback', 'vms-meta-ads'), 'warning', __('Creative readback is not available yet.', 'vms-meta-ads'), $creative_snapshot->get_error_message());
			} else {
				$expected_destination = esc_url_raw((string) (($build['utm_url'] ?? '') ?: ($build['destination_url'] ?? '')));
				$copy = is_array($build['copy_payload'] ?? null) ? (array) $build['copy_payload'] : array();
				$expected_cta = self::map_meta_link_cta((string) (($copy['cta_suggestion'] ?? '') ?: ($copy['cta_type'] ?? 'LEARN_MORE')), $expected_destination);
				$live_destination = self::extract_creative_destination_url($creative);
				$live_cta = self::extract_creative_cta_type($creative);
				$cta_matches = ($expected_cta !== '' && $live_cta !== '' && strtoupper($expected_cta) === strtoupper($live_cta));
				$url_matches = ($expected_destination !== '' && $live_destination !== '' && self::normalize_url_for_compare($expected_destination) === self::normalize_url_for_compare($live_destination));
				$creative_state = ($cta_matches && $url_matches) ? 'ok' : 'warning';
				$creative_summary = sprintf(__('CTA %1$s · Destination %2$s', 'vms-meta-ads'), $live_cta !== '' ? $live_cta : __('unreadable', 'vms-meta-ads'), $live_destination !== '' ? $live_destination : __('unreadable', 'vms-meta-ads'));
				$creative_detail = ($cta_matches && $url_matches)
					? __('CTA and destination read back as expected.', 'vms-meta-ads')
					: sprintf(__('Expected CTA %1$s and destination %2$s.', 'vms-meta-ads'), $expected_cta !== '' ? $expected_cta : __('missing', 'vms-meta-ads'), $expected_destination !== '' ? $expected_destination : __('missing', 'vms-meta-ads'));
				$items[] = self::build_readiness_item('cta_destination', __('CTA / destination', 'vms-meta-ads'), $creative_state, $creative_summary, $creative_detail);

				$feature_readback = self::extract_creative_feature_readback($creative);
				$multi_status = (string) ($feature_readback['contextual_multi_ads'] ?? '');
				$multi_state = $multi_status === 'OPT_OUT' ? 'ok' : ($multi_status === '' ? 'warning' : 'error');
				$multi_summary = $multi_status === 'OPT_OUT' ? __('Readback says Multi-advertiser ads are off.', 'vms-meta-ads') : ($multi_status !== '' ? sprintf(__('Readback returned %s.', 'vms-meta-ads'), $multi_status) : __('Readback did not expose Multi-advertiser state.', 'vms-meta-ads'));
				$multi_detail = __('Meta edit screens may show stale/default enhancement checkboxes. Do not save manual edits without confirming Review still shows Multi-advertiser ads Off and Advantage+ creative Off.', 'vms-meta-ads');
				$items[] = self::build_readiness_item('multi_advertiser', __('Multi-advertiser ads', 'vms-meta-ads'), $multi_state, $multi_summary, $multi_detail);

				$advantage_status = (string) ($feature_readback['standard_enhancements'] ?? '');
				$advantage_state = $advantage_status === 'OPT_OUT' ? 'ok' : ($advantage_status === '' ? 'warning' : 'error');
				$advantage_summary = $advantage_status === 'OPT_OUT' ? __('Readback says Advantage+ creative is off.', 'vms-meta-ads') : ($advantage_status !== '' ? sprintf(__('Readback returned %s.', 'vms-meta-ads'), $advantage_status) : __('Readback did not expose Advantage+ creative state.', 'vms-meta-ads'));
				$advantage_detail = __('Meta edit screens may show stale/default enhancement checkboxes. Do not save manual edits without confirming Review still shows Multi-advertiser ads Off and Advantage+ creative Off.', 'vms-meta-ads');
				$items[] = self::build_readiness_item('advantage_creative', __('Advantage+ creative', 'vms-meta-ads'), $advantage_state, $advantage_summary, $advantage_detail);
			}

			$overall = 'ok';
			foreach ($items as $item) {
				$item_state = sanitize_key((string) ($item['state'] ?? 'ok'));
				if ($item_state === 'error') {
					$overall = 'error';
					break;
				}
				if ($item_state === 'warning') {
					$overall = 'warning';
				}
			}

			return array(
				'state' => $overall,
				'items' => array_values($items),
				'notes' => array_values(array_unique(array_filter(array_map('sanitize_text_field', $notes)))),
				'local_meta_status' => self::derive_local_meta_status($snapshot),
				'local_meta_label' => self::local_meta_status_label(self::derive_local_meta_status($snapshot)),
			);
		}

		private static function normalize_url_for_compare(string $url): string
		{
			$parts = wp_parse_url($url);
			if (!is_array($parts)) {
				return trim($url);
			}
			$host = strtolower((string) ($parts['host'] ?? ''));
			$path = '/' . ltrim((string) ($parts['path'] ?? ''), '/');
			$path = rtrim($path, '/');
			return $host . $path;
		}

		private static function extract_targeting_radius(array $targeting): int
		{
			$geo = is_array($targeting['geo_locations'] ?? null) ? (array) $targeting['geo_locations'] : array();
			if (!empty($geo['custom_locations']) && is_array($geo['custom_locations'])) {
				$first = is_array($geo['custom_locations'][0] ?? null) ? (array) $geo['custom_locations'][0] : array();
				return absint($first['radius'] ?? 0);
			}
			return 0;
		}

		private static function format_minor_budget(int $minor): string
		{
			return '$' . number_format($minor / 100, 2);
		}

		private static function normalized_status_value(string $status): string
		{
			return strtoupper(sanitize_text_field($status));
		}

		private static function configured_status_value(array $row): string
		{
			return self::normalized_status_value((string) ($row['configured_status'] ?? 'UNKNOWN'));
		}

		private static function effective_status_value(array $row): string
		{
			$configured = self::configured_status_value($row);
			$effective = self::normalized_status_value((string) ($row['effective_status'] ?? ''));
			return $effective !== '' ? $effective : $configured;
		}

		private static function is_active_status_value(string $status): bool
		{
			return self::normalized_status_value($status) === self::STATUS_ACTIVE;
		}

		private static function is_reviewing_status_value(string $status): bool
		{
			$status = self::normalized_status_value($status);
			return in_array($status, array(
				self::STATUS_PENDING_REVIEW,
				self::STATUS_IN_PROCESS,
				self::STATUS_PREAPPROVED,
			), true);
		}

		private static function is_safe_inactive_status_value(string $status): bool
		{
			$status = self::normalized_status_value($status);
			return in_array($status, array(
				self::STATUS_PAUSED,
				self::STATUS_PENDING_REVIEW,
				self::STATUS_IN_PROCESS,
				self::STATUS_PREAPPROVED,
				self::STATUS_CAMPAIGN_PAUSED,
				self::STATUS_ADSET_PAUSED,
			), true);
		}

		private static function is_problem_status_value(string $status): bool
		{
			$status = self::normalized_status_value($status);
			return in_array($status, array(
				'ERROR',
				'UNKNOWN',
				self::STATUS_DISAPPROVED,
				self::STATUS_REJECTED,
				self::STATUS_WITH_ISSUES,
				self::STATUS_PENDING_BILLING_INFO,
				'ARCHIVED',
				'DELETED',
			), true);
		}

		private static function snapshot_status_rows(array $snapshot): array
		{
			$rows = array();
			foreach (array('campaign', 'adset', 'ad') as $key) {
				if (is_array($snapshot[$key] ?? null)) {
					$rows[] = (array) $snapshot[$key];
				}
			}
			foreach (array('adsets', 'ad_variants') as $list_key) {
				foreach ((array) ($snapshot[$list_key] ?? array()) as $row) {
					if (is_array($row)) {
						$rows[] = (array) $row;
					}
				}
			}
			return $rows;
		}

		private static function derive_local_meta_status(array $snapshot, string $action = 'refresh_status', string $outcome = 'ok'): string
		{
			if ($outcome === 'partial') {
				return 'partial';
			}

			$rows = self::snapshot_status_rows($snapshot);
			if (empty($rows)) {
				return 'error';
			}

			$has_active = false;
			$has_problem = false;
			$has_reviewing = false;
			$all_safe_inactive = true;
			foreach ($rows as $row) {
				$configured = self::configured_status_value($row);
				$effective = self::effective_status_value($row);
				if (self::is_active_status_value($configured) || self::is_active_status_value($effective)) {
					$has_active = true;
				}
				if (self::is_problem_status_value($configured) || self::is_problem_status_value($effective)) {
					$has_problem = true;
				}
				if (self::is_reviewing_status_value($configured) || self::is_reviewing_status_value($effective)) {
					$has_reviewing = true;
				}
				if (!self::is_safe_inactive_status_value($configured) || !self::is_safe_inactive_status_value($effective)) {
					$all_safe_inactive = false;
				}
			}

			if ($has_active) {
				return 'live';
			}
			if ($has_problem) {
				return 'error';
			}
			if ($has_reviewing && $all_safe_inactive) {
				return 'paused_reviewing';
			}
			if ($all_safe_inactive) {
				return 'paused';
			}
			return 'error';
		}

		private static function local_meta_status_label(string $status): string
		{
			switch (sanitize_key($status)) {
				case 'live':
					return __('Live / active', 'vms-meta-ads');
				case 'paused':
					return __('Paused / inactive', 'vms-meta-ads');
				case 'paused_reviewing':
					return __('Paused / pending review', 'vms-meta-ads');
				case 'partial':
					return __('Partial create / needs review', 'vms-meta-ads');
				case 'error':
				default:
					return __('Needs review', 'vms-meta-ads');
			}
		}

		private static function snapshot_has_active_object(array $snapshot): bool
		{
			foreach (self::snapshot_status_rows($snapshot) as $row) {
				if (self::is_active_status_value(self::effective_status_value($row))) {
					return true;
				}
			}
			return false;
		}

		private static function build_status_snapshot(array $ids, ?array $settings = null): array
		{
			if ($settings === null) {
				$settings = self::connection_settings();
			}

			$adset_ids = !empty($ids['adset_ids']) && is_array($ids['adset_ids']) ? array_values(array_filter(array_map('sanitize_text_field', (array) $ids['adset_ids']))) : array();
			if (empty($adset_ids) && !empty($ids['adset_id'])) {
				$adset_ids[] = sanitize_text_field((string) $ids['adset_id']);
			}
			$adsets_meta = !empty($ids['adsets_meta']) && is_array($ids['adsets_meta']) ? (array) $ids['adsets_meta'] : array();
			$variant_meta = !empty($ids['ad_variants_meta']) && is_array($ids['ad_variants_meta']) ? array_values((array) $ids['ad_variants_meta']) : array();
			foreach ($variant_meta as $row) {
				if (!is_array($row)) {
					continue;
				}
				if (!empty($row['adset_id'])) {
					$maybe_adset_id = sanitize_text_field((string) $row['adset_id']);
					if ($maybe_adset_id !== '' && !in_array($maybe_adset_id, $adset_ids, true)) {
						$adset_ids[] = $maybe_adset_id;
					}
				}
			}

			$ad_ids = !empty($ids['ad_ids']) && is_array($ids['ad_ids']) ? array_values(array_filter(array_map('sanitize_text_field', (array) $ids['ad_ids']))) : array();
			if (empty($ad_ids) && !empty($ids['ad_id'])) {
				$ad_ids[] = sanitize_text_field((string) $ids['ad_id']);
			}
			if (empty($ad_ids) && !empty($variant_meta)) {
				foreach ($variant_meta as $row) {
					if (!is_array($row) || empty($row['ad_id'])) {
						continue;
					}
					$ad_ids[] = sanitize_text_field((string) $row['ad_id']);
				}
			}
			$adset_ids = array_values(array_unique(array_filter($adset_ids)));
			$ad_ids = array_values(array_unique(array_filter($ad_ids)));

			if (is_wp_error($settings)) {
				return array(
					'campaign' => self::unknown_status((string) ($ids['campaign_id'] ?? '')),
					'adset' => self::unknown_status((string) ($adset_ids[0] ?? ($ids['adset_id'] ?? ''))),
					'adsets' => array(),
					'adset_count' => count($adset_ids),
					'ad' => self::unknown_status((string) ($ad_ids[0] ?? ($ids['ad_id'] ?? ''))),
					'ad_variants' => array(),
					'ad_variant_count' => count($ad_ids),
					'ad_account_id' => '',
					'open_in_meta_url' => 'https://adsmanager.facebook.com/',
				);
			}

			$campaign = !empty($ids['campaign_id']) ? self::fetch_object_status((string) $ids['campaign_id']) : self::unknown_status('');
			$adsets = array();
			foreach ($adset_ids as $index => $adset_id) {
				$status = $adset_id !== '' ? self::fetch_object_status((string) $adset_id) : self::unknown_status('');
				$status_row = is_wp_error($status) ? self::status_error((string) $adset_id, $status->get_error_message()) : $status;
				$meta_label = '';
				$meta_key = '';
				foreach ($adsets_meta as $key => $meta_row) {
					if (!is_array($meta_row)) {
						continue;
					}
					if (sanitize_text_field((string) ($meta_row['adset_id'] ?? '')) === $adset_id) {
						$meta_key = sanitize_key((string) ($meta_row['key'] ?? $key));
						$meta_label = sanitize_text_field((string) ($meta_row['label'] ?? ''));
						break;
					}
				}
				$status_row['adset_key'] = $meta_key !== '' ? $meta_key : 'adset_' . ($index + 1);
				$status_row['label'] = $meta_label !== '' ? $meta_label : 'Ad Set ' . ($index + 1);
				$adsets[] = $status_row;
			}
			if (empty($adsets)) {
				$single_adset = !empty($ids['adset_id']) ? self::fetch_object_status((string) $ids['adset_id']) : self::unknown_status('');
				$adsets[] = is_wp_error($single_adset) ? self::status_error((string) ($ids['adset_id'] ?? ''), $single_adset->get_error_message()) : $single_adset;
			}

			$ad_variants = array();
			if (!empty($variant_meta)) {
				foreach ($variant_meta as $index => $row) {
					if (!is_array($row)) {
						continue;
					}
					$ad_id = sanitize_text_field((string) ($row['ad_id'] ?? ''));
					if ($ad_id === '') {
						continue;
					}
					$status = self::fetch_object_status($ad_id);
					$status_row = is_wp_error($status) ? self::status_error($ad_id, $status->get_error_message()) : $status;
					$status_row['variant_key'] = sanitize_key((string) ($row['variant_key'] ?? ('v' . ($index + 1)))) ?: ('v' . ($index + 1));
					$status_row['label'] = sanitize_text_field((string) ($row['label'] ?? ('Variant ' . ($index + 1)))) ?: ('Variant ' . ($index + 1));
					$status_row['adset_key'] = sanitize_key((string) ($row['adset_key'] ?? ''));
					$status_row['adset_label'] = sanitize_text_field((string) ($row['adset_label'] ?? ''));
					$status_row['adset_id'] = sanitize_text_field((string) ($row['adset_id'] ?? ''));
					$ad_variants[] = $status_row;
				}
			}
			if (empty($ad_variants)) {
				foreach ($ad_ids as $index => $ad_id) {
					$status = $ad_id !== '' ? self::fetch_object_status((string) $ad_id) : self::unknown_status('');
					$status_row = is_wp_error($status) ? self::status_error((string) $ad_id, $status->get_error_message()) : $status;
					$status_row['variant_key'] = 'v' . ($index + 1);
					$status_row['label'] = 'Variant ' . ($index + 1);
					$ad_variants[] = $status_row;
				}
			}
			if (empty($ad_variants)) {
				$single = !empty($ids['ad_id']) ? self::fetch_object_status((string) $ids['ad_id']) : self::unknown_status('');
				$ad_variants[] = is_wp_error($single) ? self::status_error((string) ($ids['ad_id'] ?? ''), $single->get_error_message()) : $single;
			}

			$aggregate_adset = self::aggregate_status_rows($adsets, (string) ($adset_ids[0] ?? ($ids['adset_id'] ?? '')));
			$aggregate_ad = self::aggregate_status_rows($ad_variants, (string) ($ad_ids[0] ?? ($ids['ad_id'] ?? '')));
			$ad_account_id = ltrim((string) ($settings['meta_ad_account_id'] ?? ''), 'act_');

			return array(
				'campaign' => is_wp_error($campaign) ? self::status_error((string) $ids['campaign_id'], $campaign->get_error_message()) : $campaign,
				'adset' => $aggregate_adset,
				'adsets' => $adsets,
				'adset_count' => count($adsets),
				'ad' => $aggregate_ad,
				'ad_variants' => $ad_variants,
				'ad_variant_count' => count($ad_variants),
				'ad_account_id' => $ad_account_id,
				'open_in_meta_url' => self::build_ads_manager_url($ad_account_id),
			);
		}

		private static function aggregate_status_rows(array $rows, string $fallback_id = ''): array
		{
			if (empty($rows)) {
				return self::unknown_status($fallback_id);
			}
			$configured = array();
			$effective = array();
			foreach ($rows as $row) {
				if (!is_array($row)) {
					continue;
				}
				$configured[] = strtoupper((string) ($row['configured_status'] ?? 'UNKNOWN'));
				$effective[] = strtoupper((string) ($row['effective_status'] ?? ($row['configured_status'] ?? 'UNKNOWN')));
			}
			$configured = array_values(array_unique(array_filter($configured)));
			$effective = array_values(array_unique(array_filter($effective)));
			$base = is_array($rows[0]) ? (array) $rows[0] : self::unknown_status($fallback_id);
			$base['id'] = $fallback_id !== '' ? $fallback_id : (string) ($base['id'] ?? '');
			$base['configured_status'] = count($configured) === 1 ? $configured[0] : 'MIXED';
			$base['effective_status'] = count($effective) === 1 ? $effective[0] : 'MIXED';
			$base['variant_count'] = count($rows);
			return $base;
		}

		private static function resolve_meta_ids(array $build)
		{
			$meta_ids = is_array($build['meta_ids'] ?? null) ? (array) $build['meta_ids'] : array();
			$campaign_id = sanitize_text_field((string) ($meta_ids['campaign_id'] ?? $build['meta_campaign_id'] ?? ''));
			$adset_id = sanitize_text_field((string) ($meta_ids['adset_id'] ?? ''));
			$ad_id = sanitize_text_field((string) ($meta_ids['ad_id'] ?? ''));
			$adset_ids = array();
			if (!empty($meta_ids['adset_ids']) && is_array($meta_ids['adset_ids'])) {
				$adset_ids = array_values(array_filter(array_map('sanitize_text_field', (array) $meta_ids['adset_ids'])));
			}
			if ($adset_id !== '' && !in_array($adset_id, $adset_ids, true)) {
				array_unshift($adset_ids, $adset_id);
			}
			$ad_ids = array();
			if (!empty($meta_ids['ad_ids']) && is_array($meta_ids['ad_ids'])) {
				$ad_ids = array_values(array_filter(array_map('sanitize_text_field', (array) $meta_ids['ad_ids'])));
			}
			if (!empty($meta_ids['ad_variants_meta']) && is_array($meta_ids['ad_variants_meta'])) {
				foreach ((array) $meta_ids['ad_variants_meta'] as $row) {
					if (!is_array($row)) {
						continue;
					}
					if (!empty($row['ad_id'])) {
						$ad_ids[] = sanitize_text_field((string) $row['ad_id']);
					}
					if (!empty($row['adset_id'])) {
						$maybe_adset_id = sanitize_text_field((string) $row['adset_id']);
						if ($maybe_adset_id !== '' && !in_array($maybe_adset_id, $adset_ids, true)) {
							$adset_ids[] = $maybe_adset_id;
						}
					}
				}
			}
			if ($ad_id !== '' && !in_array($ad_id, $ad_ids, true)) {
				array_unshift($ad_ids, $ad_id);
			}

			if ((empty($adset_ids) || empty($ad_ids)) && !empty($build['tiers']) && is_array($build['tiers'])) {
				foreach ((array) $build['tiers'] as $tier) {
					if (!is_array($tier)) {
						continue;
					}
					if (empty($adset_ids) && !empty($tier['meta_adset_id'])) {
						$adset_ids[] = sanitize_text_field((string) $tier['meta_adset_id']);
					}
					if (empty($ad_ids) && !empty($tier['meta_ad_id'])) {
						$ad_ids[] = sanitize_text_field((string) $tier['meta_ad_id']);
					}
				}
			}

			$adset_ids = array_values(array_unique(array_filter($adset_ids)));
			$ad_ids = array_values(array_unique(array_filter($ad_ids)));
			$adset_id = (string) ($adset_ids[0] ?? $adset_id);
			$ad_id = (string) ($ad_ids[0] ?? $ad_id);
			if ($campaign_id === '' || empty($adset_ids) || empty($ad_ids)) {
				return new WP_Error(
					'missing_meta_ids',
					__('Create in Meta (PAUSED) first. Missing campaign/adset/ad IDs for this Event Plan.', 'vms-meta-ads'),
					array('status' => 400)
				);
			}

			return array(
				'campaign_id' => $campaign_id,
				'adset_id' => $adset_id,
				'adset_ids' => $adset_ids,
				'adsets_meta' => !empty($meta_ids['adsets_meta']) && is_array($meta_ids['adsets_meta']) ? (array) $meta_ids['adsets_meta'] : array(),
				'ad_id' => $ad_id,
				'ad_ids' => $ad_ids,
				'ad_variants_meta' => !empty($meta_ids['ad_variants_meta']) && is_array($meta_ids['ad_variants_meta']) ? array_values((array) $meta_ids['ad_variants_meta']) : array(),
				'campaign_recipe' => sanitize_key((string) ($meta_ids['campaign_recipe'] ?? '')),
			);
		}


		private static function connection_recent_or_verify()
		{
			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$manual_timezone = VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) ($settings['meta_account_timezone'] ?? ''));
			$detected_timezone = VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) ($settings['meta_account_timezone_detected'] ?? ''));
			$needs_timezone_detection = ($manual_timezone === '' && $detected_timezone === '');

			$raw = trim((string) ($settings['meta_last_test_ok_gmt'] ?? ''));
			if (!$needs_timezone_detection && $raw !== '') {
				$ts = strtotime($raw . ' UTC');
				if ($ts !== false && (time() - $ts) <= DAY_IN_SECONDS) {
					return true;
				}
			}

			$verify = self::lightweight_verify_connection($settings);
			if (is_wp_error($verify)) {
				return $verify;
			}

			$current = VMS_Meta_Ads_Utils::get_settings();
			$current['meta_last_test_ok_gmt'] = current_time('mysql', true);
			if (is_array($verify) && !empty($verify['timezone_name'])) {
				$current['meta_account_timezone_detected'] = VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) $verify['timezone_name']);
			}
			VMS_Meta_Ads_Utils::update_settings($current);
			return true;
		}

		private static function connection_recent_or_readonly_verify()
		{
			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$manual_timezone = VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) ($settings['meta_account_timezone'] ?? ''));
			$detected_timezone = VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) ($settings['meta_account_timezone_detected'] ?? ''));
			$needs_timezone_detection = ($manual_timezone === '' && $detected_timezone === '');

			$raw = trim((string) ($settings['meta_last_test_ok_gmt'] ?? ''));
			if (!$needs_timezone_detection && $raw !== '') {
				$ts = strtotime($raw . ' UTC');
				if ($ts !== false && (time() - $ts) <= DAY_IN_SECONDS) {
					return true;
				}
			}

			$verify = self::lightweight_verify_connection($settings);
			if (is_wp_error($verify)) {
				return new WP_Error(
					'connection_verify_failed',
					__('Connection is stale or could not be verified read-only. Open Meta Connection Status or Test Connection in Settings before creating paused Meta assets.', 'vms-meta-ads'),
					array('status' => 400)
				);
			}

			return true;
		}

		private static function lightweight_verify_connection(array $settings)
		{
			$response = self::meta_get_request(
				$settings,
				VMS_Meta_Ads_Meta_Endpoints::ad_account_endpoint((string) $settings['meta_ad_account_id']),
				array('fields' => 'account_id,timezone_name,timezone_offset_hours_utc'),
				'connection_verify',
				'settings'
			);
			if (is_wp_error($response)) {
				return new WP_Error('connection_verify_failed', __('Connection verification failed. Open Settings and run Test Connection.', 'vms-meta-ads'), array('status' => 400));
			}
			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || (is_array($body) && isset($body['error']))) {
				return new WP_Error('connection_verify_failed', __('Connection is stale. Open Settings and run Test Connection.', 'vms-meta-ads'), array('status' => 400));
			}
			$timezone = '';
			if (is_array($body) && !empty($body['timezone_name'])) {
				$timezone = VMS_Meta_Ads_Utils::normalize_timezone_identifier((string) $body['timezone_name']);
			}
			return array('ok' => true, 'timezone_name' => $timezone);
		}

		private static function fetch_object_status(string $object_id, ?array $settings = null)
		{
			$object_id = trim($object_id);
			if ($object_id === '') {
				return new WP_Error('missing_object_id', __('Meta object ID is missing.', 'vms-meta-ads'));
			}
			if ($settings === null) {
				$settings = self::connection_settings();
			}
			if (is_wp_error($settings)) {
				return $settings;
			}

			$response = self::meta_get_request(
				$settings,
				$object_id,
				array('fields' => 'configured_status,effective_status,issues_info'),
				'fetch_status',
				'ad_builder',
				25
			);
			if (is_wp_error($response)) {
				return new WP_Error('meta_status_failed', __('Could not refresh Meta status due to a network error.', 'vms-meta-ads'));
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || !is_array($body) || isset($body['error'])) {
				$meta_error = self::extract_meta_error($body, $code);
				return new WP_Error('meta_status_failed', sprintf(__('Meta status refresh failed: %s', 'vms-meta-ads'), $meta_error['message']));
			}

			return self::normalize_status_payload($object_id, $body);
		}

		private static function update_object_status(string $object_id, string $target_status)
		{
			$object_id = trim($object_id);
			$target_status = strtoupper(trim($target_status));
			if ($object_id === '') {
				return new WP_Error('missing_object_id', __('Meta object ID is missing.', 'vms-meta-ads'));
			}
			if ($target_status !== self::STATUS_ACTIVE && $target_status !== self::STATUS_PAUSED) {
				return new WP_Error('invalid_target_status', __('Meta target status is invalid.', 'vms-meta-ads'));
			}

			$settings = self::connection_settings();
			if (is_wp_error($settings)) {
				return $settings;
			}

			$response = self::meta_post_form_request(
				$settings,
				$object_id,
				array('status' => $target_status),
				'update_status',
				'ad_builder',
				25
			);
			if (is_wp_error($response)) {
				return new WP_Error('meta_update_failed', __('Meta status update failed before response was received.', 'vms-meta-ads'));
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code < 200 || $code >= 300 || (is_array($body) && isset($body['error']))) {
				$meta_error = self::extract_meta_error($body, $code);
				return new WP_Error('meta_update_failed', sprintf(__('Meta status update failed: %s', 'vms-meta-ads'), $meta_error['message']));
			}

			return array('ok' => true, 'status' => $target_status);
		}

		private static function normalize_status_payload(string $object_id, array $body): array
		{
			$configured = strtoupper(sanitize_text_field((string) ($body['configured_status'] ?? $body['status'] ?? 'UNKNOWN')));
			$effective = strtoupper(sanitize_text_field((string) ($body['effective_status'] ?? $configured)));
			$issues = isset($body['issues_info']) ? $body['issues_info'] : null;
			return array(
				'id' => sanitize_text_field($object_id),
				'configured_status' => $configured !== '' ? $configured : 'UNKNOWN',
				'effective_status' => $effective !== '' ? $effective : 'UNKNOWN',
				'issues_info' => $issues,
			);
		}

		private static function update_event_plan_after_action(int $event_plan_id, string $action, string $outcome, array $snapshot, array $result, bool $rollback): void
		{
			$status = self::derive_local_meta_status($snapshot, $action, $outcome);

			update_post_meta($event_plan_id, 'vms_ma_meta_status', $status);
			if ($action === 'go_live' && $outcome === 'ok') {
				update_post_meta($event_plan_id, 'vms_ma_meta_last_live_local', self::current_local_time());
			}
			if ($action === 'pause_all' && $outcome === 'ok') {
				update_post_meta($event_plan_id, 'vms_ma_meta_last_pause_local', self::current_local_time());
			}

			$snapshot_payload = array(
				'campaign' => $snapshot['campaign'] ?? self::unknown_status(''),
				'adset' => $snapshot['adset'] ?? self::unknown_status(''),
				'ad' => $snapshot['ad'] ?? self::unknown_status(''),
				'ad_account_id' => (string) ($snapshot['ad_account_id'] ?? ''),
				'open_in_meta_url' => (string) ($snapshot['open_in_meta_url'] ?? ''),
				'local_meta_status' => $status,
				'local_meta_label' => self::local_meta_status_label($status),
				'updated_local' => self::current_local_time(),
			);
			update_post_meta($event_plan_id, 'vms_ma_meta_last_status_snapshot_json', wp_json_encode($snapshot_payload));

			self::append_event_log($event_plan_id, array(
				'local_timestamp' => self::current_local_time(),
				'action' => $action,
				'outcome' => $outcome,
				'per_object' => (array) ($result['result'] ?? array()),
				'rollback_attempted' => $rollback ? 1 : 0,
				'rollback_outcome' => $rollback ? (($outcome === 'ok') ? 'ok' : 'attempted') : 'not_needed',
				'user_id' => get_current_user_id(),
			));
		}

		private static function append_event_log(int $event_plan_id, array $entry): void
		{
			$current = get_post_meta($event_plan_id, 'vms_ma_log', true);
			$items = array();
			if (is_array($current)) {
				$items = $current;
			} elseif (is_string($current) && $current !== '') {
				$decoded = json_decode($current, true);
				if (is_array($decoded)) {
					$items = $decoded;
				}
			}
			$items[] = $entry;
			update_post_meta($event_plan_id, 'vms_ma_log', $items);
		}

		private static function unknown_status(string $id): array
		{
			return array(
				'id' => sanitize_text_field($id),
				'configured_status' => 'UNKNOWN',
				'effective_status' => 'UNKNOWN',
				'issues_info' => null,
			);
		}

		private static function status_error(string $id, string $error): array
		{
			return array(
				'id' => sanitize_text_field($id),
				'configured_status' => 'ERROR',
				'effective_status' => 'ERROR',
				'issues_info' => array('message' => sanitize_text_field($error)),
			);
		}

		private static function empty_object_result(): array
		{
			return array(
				'attempted' => false,
				'changed' => false,
				'status' => '',
				'error' => '',
			);
		}

		private static function build_ads_manager_url(string $ad_account_id): string
		{
			$clean = ltrim(trim($ad_account_id), 'act_');
			if ($clean === '') {
				return 'https://adsmanager.facebook.com/';
			}
			return 'https://adsmanager.facebook.com/adsmanager/manage/campaigns?act=' . rawurlencode($clean);
		}

		private static function current_local_time(): string
		{
			return wp_date('Y-m-d H:i', null, wp_timezone());
		}

		private static function preflight_permissions(array $settings)
		{
			$response = self::meta_get_request(
				$settings,
				'me/permissions',
				array(),
				'preflight_permissions',
				'settings'
			);
			if (is_wp_error($response)) {
				vms_ma_log('error', array(
					'where' => 'preflight_permissions',
					'response_code' => 0,
					'message' => $response->get_error_message(),
					'error' => true,
				));
				return new WP_Error('meta_permission_preflight_failed', __('Meta permission preflight could not be completed.', 'vms-meta-ads'), array(
					'details' => array(
						'type' => 'transport_error',
						'message' => $response->get_error_message(),
					),
				));
			}

			$code = (int) wp_remote_retrieve_response_code($response);
			$body = json_decode((string) wp_remote_retrieve_body($response), true);
			if ($code >= 200 && $code < 300 && is_array($body) && isset($body['data']) && is_array($body['data'])) {
				$granted = array();
				foreach ($body['data'] as $item) {
					if (!is_array($item)) {
						continue;
					}
					$perm_name = sanitize_key((string) ($item['permission'] ?? ''));
					$status = sanitize_key((string) ($item['status'] ?? ''));
					if ($perm_name !== '' && $status === 'granted') {
						$granted[$perm_name] = true;
					}
				}
				if (empty($granted['ads_read']) && empty($granted['ads_management'])) {
					return new WP_Error(
						'meta_permission_missing',
						__('Token missing required permission(s): ads_read/ads_management. Regenerate token and select permissions before Generate Access Token.', 'vms-meta-ads'),
						array(
							'details' => array(
								'type' => 'permission_error',
								'message' => 'ads_read/ads_management missing from granted permissions.',
								'code' => 0,
								'fbtrace_id' => '',
							),
						)
					);
				}
				return array('ok' => true);
			}

			if (is_array($body) && isset($body['error'])) {
				$meta_error = self::extract_meta_error($body, $code);
				vms_ma_log('error', array(
					'where' => 'preflight_permissions',
					'response_code' => $code,
					'type' => $meta_error['type'],
					'code' => $meta_error['code'],
					'fbtrace_id' => $meta_error['fbtrace_id'],
					'message' => $meta_error['message'],
					'error' => true,
				));
			}

			return array('ok' => true, 'fallback' => true);
		}

		private static function extract_meta_error($body, int $response_code): array
		{
			$error = array(
				'type' => 'unknown_error',
				'code' => 0,
				'subcode' => 0,
				'message' => 'Unknown Meta API error.',
				'message_user' => '',
				'blame_field' => '',
				'fbtrace_id' => '',
				'response_code' => $response_code,
			);
			if (!is_array($body) || !isset($body['error']) || !is_array($body['error'])) {
				return $error;
			}
			$meta = $body['error'];
			$error['type'] = sanitize_text_field((string) ($meta['type'] ?? $error['type']));
			$error['code'] = (int) ($meta['code'] ?? 0);
			$error['subcode'] = (int) ($meta['error_subcode'] ?? 0);
			$error['message'] = sanitize_text_field((string) ($meta['message'] ?? $error['message']));
			$error['message_user'] = sanitize_text_field((string) ($meta['error_user_msg'] ?? $meta['error_user_title'] ?? ''));
			$error['fbtrace_id'] = sanitize_text_field((string) ($meta['fbtrace_id'] ?? ''));
			if (!empty($meta['error_data']) && is_array($meta['error_data']) && !empty($meta['error_data']['blame_field_specs'])) {
				$spec = $meta['error_data']['blame_field_specs'];
				if (is_array($spec)) {
					$first = reset($spec);
					if (is_array($first)) {
						$error['blame_field'] = sanitize_text_field((string) implode('.', array_map('strval', $first)));
					}
				}
			}
			return $error;
		}


		private static function maybe_record_app_mode_from_meta_error(array $meta_error): void
		{
			$subcode = (int) ($meta_error['subcode'] ?? 0);
			$message_user = (string) ($meta_error['message_user'] ?? '');
			$message = (string) ($meta_error['message'] ?? '');

			// Meta error subcode 1885183 indicates the app is in Development mode when attempting to create ads creative posts.
			if ($subcode === 1885183) {
				VMS_Meta_Ads_Utils::record_app_mode('development');
				return;
			}

			$hay = strtolower($message_user . ' ' . $message);
			if ($hay !== '' && strpos($hay, 'development mode') !== false) {
				VMS_Meta_Ads_Utils::record_app_mode('development');
			}
		}

		private static function connection_settings()
		{
			$settings = VMS_Meta_Ads_Utils::get_settings();
			$use_local_override = !empty($settings['meta_ad_account_override']);
			if (!$use_local_override) {
				$social = apply_filters('vms_social_meta_connection', null);
				if (is_array($social) && !empty($social['ad_account_id'])) {
					$settings = array_merge($settings, array(
						'meta_ad_account_id' => (string) ($social['ad_account_id'] ?? ''),
						'meta_page_id' => (string) ($social['page_id'] ?? ''),
						'meta_ig_actor_id' => (string) ($social['ig_actor_id'] ?? ''),
						'meta_graph_version' => (string) ($social['graph_version'] ?? $settings['meta_graph_version']),
						'meta_access_token_encrypted' => (string) ($social['access_token_encrypted'] ?? ''),
					));
				}
			}
			$ad_account_id = trim((string) ($settings['meta_ad_account_id'] ?? ''));
			$token_encrypted = (string) ($settings['meta_access_token_encrypted'] ?? '');
			$token = VMS_Meta_Ads_Utils::decrypt_token($token_encrypted);

			if ($ad_account_id === '' || $token === '') {
				return new WP_Error('meta_settings_incomplete', __('Meta settings are incomplete. Provide ad account and token.', 'vms-meta-ads'));
			}

			$settings['meta_ad_account_id'] = ltrim($ad_account_id, 'act_');
			$settings['token'] = $token;
			return $settings;
		}

		private static function acquire_lock(int $key_id, string $action)
		{
			$key = 'vms_ma_lock_' . $key_id . '_' . $action;
			if (get_transient($key)) {
				return new WP_Error('locked', __('A request is already running for this event. Please wait and retry.', 'vms-meta-ads'), array('status' => 409));
			}
			set_transient($key, 1, 120);
			return true;
		}

		private static function release_lock(int $key_id, string $action): void
		{
			$key = 'vms_ma_lock_' . $key_id . '_' . $action;
			delete_transient($key);
		}
	}
}
