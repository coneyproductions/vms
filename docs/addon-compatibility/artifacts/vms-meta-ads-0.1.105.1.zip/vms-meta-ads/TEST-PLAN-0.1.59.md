# TEST PLAN 0.1.59

Goal: confirm website-destination ads no longer rehydrate as Facebook Event when the builder CTA is set to Buy Tickets.

## Steps
1. Install `vms-meta-ads-0.1.59-website-cta-safety.zip`.
2. In the builder, keep the UI CTA on **Buy Tickets** and use a normal Serenade Range event URL as Destination URL.
3. Save Draft.
4. Reset Meta Link.
5. Create in Meta (PAUSED).
6. Open the new ad in Ads Manager.

## Expected
- Destination shows **Website**, not **Facebook event**.
- The destination URL is the Serenade Range event page.
- The rendered CTA may show **Learn More** in Meta because the plugin now uses a Meta-safe offsite CTA for website destinations when Buy Tickets is selected in the builder.

## Regression checks
- Event copy and media still create normally.
- Update Existing Meta Ad still works for the same build.
- Facebook or Instagram platform placements still render.
