# 🚨 Codex Test Plan — VMS Meta Ads Builder 0.1.75

## Goal

Validate the new Sales / Ticket Purchases goal and confirm the clean-room recipe still creates safe paused assets without falling back to Traffic unexpectedly.

## Do not do this unless explicitly instructed

- Do not publish/go-live a live campaign during this regression.
- Do not mutate an existing live campaign unless the operator has identified a disposable test build.
- Do not test on a production event with active paid ads unless the operator confirms the exact build.

## 1. Version / package sanity

1. Install/replace the plugin in the canonical `vms-meta-ads` folder.
2. Confirm plugin header version is `0.1.75`.
3. Confirm `module.json` version is `0.1.75`.
4. Confirm `vms-build.txt` starts with `0.1.75`.
5. Confirm no parallel plugin folder was created.

Expected: one active `vms-meta-ads` plugin at 0.1.75.

## 2. Settings field

1. Open MAB Settings.
2. Confirm a field labeled `Meta Pixel / Dataset ID` appears near the Meta connection fields.
3. Save a numeric Pixel/Dataset ID.
4. Reload settings and confirm it persists.

Expected: saved ID remains visible and does not clear the access token.

## 3. Builder goal UI

1. Open Meta Ads Builder.
2. Select a ticketed Event Plan.
3. Choose `Clean-Room Concert Campaign - Full Push v2`.
4. Open Step E.

Expected:

- Goal is `Sales / Ticket Purchases`.
- Optimization is `Purchase conversions`.
- The sales help card is visible.
- If Pixel/Dataset ID is saved, no missing-pixel warning appears.
- If Pixel/Dataset ID is blank, a clear warning appears.

## 4. Save draft payload

1. Configure the v2 clean-room recipe.
2. Save Draft.
3. Read the saved build through the Builder API or available debug tooling.

Expected saved values:

- `goal = sales`
- `objective_meta = OUTCOME_SALES`
- last draft JSON has `optimization = purchase_conversions`
- clean-room recipe payload includes `goal = sales`, `objective_meta = OUTCOME_SALES`, `optimization = purchase_conversions`, and `conversion_event = PURCHASE`

## 5. Missing Pixel guardrail

1. Temporarily clear `Meta Pixel / Dataset ID` in MAB Settings.
2. Save a Sales / Ticket Purchases build.
3. Click Create in Meta on a disposable test build.

Expected:

- Create is blocked before Meta object creation.
- Error clearly says Sales / Ticket Purchases needs a Meta Pixel or Dataset ID.
- No campaign/ad set/ad is created.

Restore the Pixel/Dataset ID before continuing.

## 6. Paused Meta create preflight — disposable test only

Use only a disposable test event/build.

1. Save a Sales / Ticket Purchases v2 clean-room build with a valid Pixel/Dataset ID.
2. Click Create in Meta.
3. Keep all created objects PAUSED.
4. Inspect the Meta API diagnostic bundle for each ad set create request.

Expected:

- Campaign objective: `OUTCOME_SALES`.
- Ad set optimization: `OFFSITE_CONVERSIONS`.
- Each recipe ad set includes a promoted object with the saved Pixel/Dataset ID and `PURCHASE` event.
- No fallback campaign is created as `OUTCOME_TRAFFIC`.
- Created campaign/ad sets/ads remain paused.

## 7. Legacy / non-sales regression

1. Select `Low-Budget Local Reminder` or `Last-Minute Push`.
2. Confirm goal remains Traffic-oriented.
3. Save Draft.
4. Confirm saved objective remains traffic-oriented and no Pixel/Dataset ID is required.

Expected: non-sales builds still save/create like before.

## 8. Wording cleanup regression

1. Open Step A with an event that has more than one saved draft.
2. Confirm labels say `Campaign draft` and `Create New Campaign Draft`.
3. Click Create New Campaign Draft.
4. Save Draft.

Expected: a new build is created without overwriting the prior draft.

## Report back

Include:

- Site URL tested
- Plugin version observed
- Event Plan / Build ID used
- Whether live Meta create was skipped or run against a disposable test build
- Any Meta API error bundles if Sales create fails
