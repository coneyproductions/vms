# VMS Meta Ads Builder 0.1.79 Test Plan

## Version checks

1. Confirm plugin header shows `0.1.79`.
2. Confirm `VMS_MA_VERSION` is `0.1.79`.
3. Confirm `module.json` version is `0.1.79`.
4. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.79`.

## Recipe preview regression

1. Open an Event Plan in MAB.
2. Select **Clean-Room Concert Campaign - Full Push v2**.
3. Confirm the recipe preview shows all default v2 ad sets:
   - Core Radius - Feeds
   - Feed Video - Square 1:1
   - Vertical Video - Reels/Stories
   - Outer Towns - Feeds 50+
4. Confirm **Facebook Right Column Support Test** appears only after enabling the optional Right Column support test.

## Feed video placeholder path

1. Leave all variants on default/shared media.
2. Confirm preview still shows **Feed Video - Square 1:1**.
3. Confirm its status is **Placeholder** or otherwise indicates that the 1:1 video should be swapped/uploaded in Meta.
4. Save Draft.
5. Create in Meta as paused assets.
6. Confirm Meta contains a separate Feed Video ad set and a paused placeholder ad under that ad set.
7. Confirm the operator can replace/swap the placeholder with the actual 1:1 video before publishing.

## Explicit feed-square variant path

1. In Ad Variants, set one variant to **Video placeholder - upload video in Meta**.
2. Set that variant's **Placement intent** to **Feed square video (1:1)**.
3. Confirm the preview refreshes immediately and the Feed Video row no longer looks missing.
4. Save Draft.
5. Create in Meta as paused assets.
6. Confirm the Feed Video ad set contains the feed-square video placeholder/variant only.

## Reels/Stories separation

1. Add or mark a separate video variant for **Reels/Stories portrait video (9:16)**.
2. Save Draft.
3. Create in Meta as paused assets.
4. Confirm the Reels/Stories ad set does not receive the feed-square variant.
5. Confirm the Feed Video ad set does not receive the Reels/Stories portrait variant.

## Manual Meta QA before publish

Before going live in Meta, confirm:

- Feed Video ad set uses Facebook Feed + Instagram Feed only.
- Reels/Stories ad set uses Reels/Stories placements only.
- The 1:1 feed video was swapped/uploaded if a placeholder was created.
- The 9:16 portrait video was swapped/uploaded if a placeholder was created.
- Website Highlights / Web Highlight / Show Spotlights are off.
- Multi-advertiser ads are off.
- Schedule timezone matches the intended event/site timezone.
