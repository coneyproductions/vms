# VMS Meta Ads Builder 0.1.79 — Always Include Feed 1:1 Video Ad Set

## Purpose

Version 0.1.78 added the Feed Square Video ad set only when an ad variant was explicitly marked with the feed-square placement intent. Real-world testing showed that this was too hidden: the Clean-Room v2 preview could still show only three ad sets and make it look like MAB was not creating the 1:1 feed-video structure.

Version 0.1.79 makes the Clean-Room v2 recipe explicit and predictable: **Feed static**, **Feed Video - Square 1:1**, and **Vertical Video - Reels/Stories** are always separate ad-set groups in the preview and in the campaign recipe payload.

## Changes

- Clean-Room v2 recipe preview now always includes:
  - Core Radius - Feeds
  - Feed Video - Square 1:1
  - Vertical Video - Reels/Stories
  - Outer Towns - Feeds 50+
  - Optional Facebook Right Column Support Test only when enabled
- Feed Video - Square 1:1 now receives a dedicated budget allocation by default:
  - 15% when Right Column is off
  - 15% when Right Column support test is on
- If the operator explicitly marks a video/video-placeholder variant as **Feed square video (1:1)**, that variant is routed into the Feed Video ad set.
- If no explicit feed-square variant exists, MAB creates a safe **Feed Square Video Placeholder** ad in the Feed Video ad set so the operator can swap/upload the 1:1 video directly in Meta before publishing.
- Changing a variant's media source or placement intent now refreshes the recipe preview immediately.
- Checklist wording now avoids implying that Feed Square Video is optional in Clean-Room v2.

## Why this matters

The operator needs clear confirmation before creating the Meta campaign. If the preview only shows a static feed group and a Reels/Stories group, it is not obvious that a separate 1:1 feed video ad will exist. The v2 recipe should show the final intended Meta structure before creation.

## Expected Clean-Room v2 structure

| Ad set | Placement intent | Creative |
|---|---|---|
| Core Radius - Feeds | Facebook Feed + Instagram Feed | Square/static feed creative |
| Feed Video - Square 1:1 | Facebook Feed + Instagram Feed | Square 1:1 video or placeholder |
| Vertical Video - Reels/Stories | Reels + Stories | Tall 9:16 video or placeholder |
| Outer Towns - Feeds 50+ | Facebook Feed + Instagram Feed | Square/static feed creative |
| Facebook Right Column Support Test | Facebook Right Column only | Static 1:1 image; only when enabled |

## Notes

- The Feed Video placeholder is intentionally paused with the rest of the recipe.
- The operator should still review the paused Meta assets and swap/upload the actual 1:1 video before publishing if the placeholder was used.
- Website Highlights / Show Spotlights and Multi-advertiser ads must still be manually checked in Meta before going live.

## Version markers

- Plugin header: `0.1.79`
- `VMS_MA_VERSION`: `0.1.79`
- `module.json`: `0.1.79`
- `vms-build.txt`: `0.1.79`
