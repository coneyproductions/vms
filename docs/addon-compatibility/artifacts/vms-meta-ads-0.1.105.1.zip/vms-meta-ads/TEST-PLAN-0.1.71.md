# TEST PLAN — VMS Meta Ads Builder 0.1.71

## Goal

Verify that 0.1.71 preserves the 0.1.70 fixes while restoring the manual **Start tour** button.

## Required safety rule

Do **not** invoke live-changing Meta actions during this test:

- Create in Meta
- Update Existing Meta Ad
- Go Live
- Pause
- Budget Sync

## Test event

Use staging Event Plan 2515 if still available:

- Buffet Beach: Jimmy Buffet tribute

## Steps

### 1. Confirm version

Open:

`/wp-content/plugins/vms-meta-ads/vms-build.txt`

Expected:

- Version is `0.1.71`.

### 2. Confirm no auto-tour with explicit tour=0

Open the builder URL with:

`event_plan_id=2515&prefill=1&tour=0`

Expected:

- No Driver/VMS tour overlay appears automatically.
- Page controls are clickable immediately.

### 3. Confirm no auto-tour with prefill only

Open the builder URL with:

`event_plan_id=2515&prefill=1`

Expected:

- No Driver/VMS tour overlay appears automatically.
- Page controls are clickable immediately.

### 4. Confirm manual Start tour works

On the same builder page, click:

**Start tour**

Expected:

- A tour popover/overlay opens.
- The first step should be the builder event-picking guidance, such as “Pick an event...”.
- `window.vmsMaTours` may be present after script fallback; if it is present, it should include `builder`.
- Closing/dismissing the tour works.

### 5. Confirm explicit tour=1 still works

Open the builder URL with:

`event_plan_id=2515&prefill=1&tour=1`

Expected:

- The tour may auto-open because it was explicitly requested.
- Closing/dismissing the tour works.

### 6. Confirm saved build hydration remains fixed

Reload the builder with:

`event_plan_id=2515&prefill=1&tour=0`

Expected:

- Saved-build list fully hydrates.
- For Buffet Beach staging, the list should include the known builds if still present: `27, 26, 25, 24, 23, 22, 15` in newest-first order.
- If staging artifacts were cleaned up, verify that all builds returned by the API are visible in the UI.

### 7. Confirm discovery linked-state remains fixed

Load adopted/live build `#25` if still present, then click:

**Find Existing Meta Campaigns**

Expected:

- Selected build remains `#25`.
- Hidden build ID, dropdown, detail line, and selected card stay synchronized.
- Campaign `6935199138516` / ad set `6935199142316` renders as **Linked to this build**, not as adoptable.

### 8. Safety check

Expected:

- No live-changing Meta actions were invoked.
- Existing linked Meta IDs do not change.

## Pass criteria

0.1.71 passes if:

- Tour does not auto-launch for prefilled builder loads unless `tour=1` is explicit.
- Manual **Start tour** opens the tour.
- Build hydration and discovery linked-state behavior remain fixed.
- No live Meta campaign state changes occur.
