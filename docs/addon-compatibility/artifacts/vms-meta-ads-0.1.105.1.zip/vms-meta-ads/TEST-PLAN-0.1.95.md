# TEST PLAN 0.1.95

## Static
- `php -l includes/services-event-plans.php`
- `php -l includes/admin/screens/ads-builder.php`
- `node --check assets/ads-builder.js`

## Local No-Spend
- Confirm locked-state builder URL still returns `403` when the premium gate is absent.
- Temporarily enable `meta_ads_builder` and load the builder.
- Confirm `window.vmsMaBuilderPerf.location_mode === "read_only"`.
- Confirm the initial Event Plan seed is small (`<= 20` expected from the builder screen config).
- Confirm Event Plan search loads on demand and selected-event detail still hydrates fields.
- Confirm dry run still works with zero `graph.facebook.com` requests.
- Confirm `meta-create` without confirmation is rejected, and `meta-create` with confirmation is still blocked by `api_disabled` while no-spend gates remain on.
- Confirm the read-only Meta Connection Status panel still loads.

## Staging No-Spend
- Deploy `vms-meta-ads 0.1.95` only.
- Keep VMS core at `0.2.24.711`.
- Keep `enable_api_create=0` and `vms_ma_phase=1`.
- Measure builder load time, settings page load time, status panel time, and dry-run time.
- Confirm staging builder load does not emit the old `vms-ma-ads-builder -> vms_sync_tec_venue_from_vms_venue -> wp_update_post` error-log stack.
- Confirm no Meta mutation requests occur.
