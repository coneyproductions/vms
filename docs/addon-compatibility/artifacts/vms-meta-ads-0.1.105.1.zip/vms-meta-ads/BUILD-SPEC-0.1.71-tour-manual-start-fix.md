# VMS Meta Ads Builder 0.1.71 — Manual Start Tour Fix

## Purpose

0.1.70 fixed the unwanted global VMS tour auto-launch and the Meta discovery linked-state regression, but Codex found that the local **Start tour** button became a no-op on staging because `window.vmsMaTours` was absent on the builder page.

This patch keeps the auto-tour suppression from 0.1.70 while restoring the manual builder tour.

## Scope

### 1. Keep builder tours out of the global VMS tour catalog

The Meta Ads Builder tour should not be registered into the global VMS tour catalog by default. This prevents the VMS core tour runner from auto-launching the builder tour before the Meta Ads Builder local `data-tour-autorun`, `prefill`, and `tour=0` guards run.

### 2. Restore manual Start tour behavior

`assets/tours.js` now reconstructs a local builder tour when:

- the current screen is the builder screen,
- `window.vmsMaTours.builder` is unavailable, and
- the already-localized `window.VMS_MA.tourSteps` payload is available.

This allows the local **Start tour** button to launch the builder tour even when the global catalog payload is intentionally absent.

### 3. Do not reintroduce auto-launch

The fallback tour config only makes manual launch possible. It does not override the existing prefill/tour auto-launch guards.

Expected behavior:

- `prefill=1&tour=0` does not auto-open the tour.
- `prefill=1` does not auto-open the tour.
- Clicking **Start tour** manually opens the tour.
- `tour=1` may explicitly open the tour.

### 4. Cache/dependency hardening

`assets/tours.js` now uses a filemtime-based version and depends on `vms-ma-ads-builder`, so the `VMS_MA` payload is available before the tour fallback runs.

## Files changed

- `assets/tours.js`
- `includes/bootstrap.php`
- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `BUILD-SPEC-0.1.71-tour-manual-start-fix.md`
- `TEST-PLAN-0.1.71.md`

## Non-goals

This patch does not change Meta campaign adoption, discovery, drift detection, API creation, budget sync, or live Meta campaign state.
