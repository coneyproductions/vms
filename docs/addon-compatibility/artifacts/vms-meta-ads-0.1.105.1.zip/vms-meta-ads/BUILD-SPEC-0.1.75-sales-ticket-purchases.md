# VMS Meta Ads Builder 0.1.75 — Sales / Ticket Purchases Goal

## Purpose

Add a real ticket-sales campaign goal to MAB so event campaigns can be built around website Purchase conversion optimization instead of only Traffic / Landing Page Views.

This is a first implementation pass. The campaign/ad sets still create as **PAUSED** for Meta review before publishing.

## Scope

### 1. Builder goal selector

Add a new Step E goal:

- `Sales / Ticket Purchases`

When selected:

- Optimization is forced to `Purchase conversions`.
- The sales help card appears.
- The Builder warns if no Meta Pixel / Dataset ID is saved in MAB Settings.
- Copy-pack output includes Purchase conversion event status.

### 2. Ticketed strategy defaults

Ticketed concert strategies now default to Sales / Ticket Purchases instead of Traffic:

- Clean-Room Concert Campaign - Full Push v2
- Clean-Room Concert Campaign - Full Push legacy compatibility path
- Ticketed Concert - Video-Led Local Push
- Standard Ticket Push

Low-budget / last-minute reminder recipes remain traffic-oriented for now.

### 3. Settings

Adds a settings field:

- `Meta Pixel / Dataset ID`

This is required only for Sales / Ticket Purchases create actions.

### 4. Save normalization

Server-side build saving now accepts:

- `goal = sales`
- `optimization = purchase_conversions`
- `objective_meta = OUTCOME_SALES`

Server-side normalization forces `purchase_conversions` when `goal=sales`, even if the browser sends a stale optimization value.

### 5. Meta create mapping

When the saved build goal is Sales / Ticket Purchases:

- Campaign objective becomes `OUTCOME_SALES`.
- Ad set optimization becomes `OFFSITE_CONVERSIONS`.
- Ad set `promoted_object` includes:
  - saved Pixel/Dataset ID
  - `custom_event_type = PURCHASE`

The missing-pixel case blocks create with a clear message instead of silently falling back to Traffic.

### 6. Clean-room recipe compatibility

Multi-ad-set clean-room creation receives the same Sales / Purchase conversion mapping on every recipe ad set.

### 7. Wording cleanup

The Step A local-draft labels were softened:

- `Linked build` → `Campaign draft`
- `Start New Linked Build` → `Create New Campaign Draft`
- Saved-build messages now refer to campaign drafts instead of linked builds.

This keeps “link” language reserved for adopting or reconciling an existing Meta campaign.

## Safety / non-goals

- Does not automatically publish campaigns.
- Does not fetch or validate live Pixel event quality from Meta yet.
- Does not add separate square/tall video asset upload slots yet.
- Does not change PixelYourSite configuration.
- Does not invoke live Meta create/update/go-live during package validation.

## Files changed

- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `assets/ads-builder.js`
- `assets/admin.css`
- `includes/admin/enqueue.php`
- `includes/admin/screens/ads-builder.php`
- `includes/admin/screens/settings.php`
- `includes/meta-api/client.php`
- `includes/services-ad-builds.php`
