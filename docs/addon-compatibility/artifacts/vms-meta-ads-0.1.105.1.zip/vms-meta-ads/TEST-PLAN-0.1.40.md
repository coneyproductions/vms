# VMS Meta Ads Builder 0.1.40 Test Plan

## Focus areas
- Multi-ad variant creation
- Variant persistence after Save Draft / reload
- Refresh Status / Go Live / Pause All with multiple ads
- Ad spec paste/export tools
- Existing budget sync still works

## Smoke test
1. Open Meta Ads Builder.
2. Select an Event Plan and fill normal required fields.
3. In Creative, enter Variant 1 copy and also fill Variant 2 and Variant 3 copy.
4. Save Draft.
5. Reload the build and confirm all three variants are still present.
6. Use Export Current Settings and confirm JSON appears in the Ad Spec box.
7. Clear the box, paste the export back in, click Apply Pasted Spec, and confirm fields repopulate.
8. Click Create in Meta (PAUSED).
9. Confirm success message mentions the correct number of ads when using more than one variant.
10. Click Refresh Status and confirm the Ad Variants summary populates.
11. Click Go Live, then Refresh Status, then Pause All, and confirm status changes still work.
12. Run Sync Budget to Meta and confirm no regression versus prior versions.

## Regression checks
- Single-ad build still saves and creates normally when Variant 2 and Variant 3 are blank.
- Existing older builds can still refresh status and pause/go live.
- Copy Pack Output shows the variant copy instead of only one ad block.

## Notes
- Best tested first in PAUSED mode.
- Variant copy is most meaningful with Dark Post mode.
- If a spec import fails, try exporting a working build first and use that exported shape as the template.
