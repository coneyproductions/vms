# VMS Meta Ads Builder 0.1.72 — Tour Local Fallback Fix

## Purpose

Restore the Meta Ads Builder manual/explicit tour launch without reintroducing the global VMS tour auto-launch behavior that was blocking staging clicks.

0.1.70 removed the Builder tour from the global VMS tour catalog by default so the core tour runner would stop auto-opening. That fixed the unwanted overlay, but staging then had no `window.vmsMaTours.builder` payload and the manual **Start tour** button became a no-op. 0.1.71 rebuilt the local payload, but the Builder script still returned early when `window.VMS_Tour.start` was unavailable, so the local tour payload was never registered/used.

## Implementation

### `assets/tours.js`

- Removed the early hard return when `window.VMS_Tour.start` is unavailable.
- Rebuilds `window.vmsMaTours.builder` from `window.VMS_MA.tourSteps` when the global tour catalog payload is absent.
- Keeps manual **Start tour** wired even when the global VMS tour engine is unavailable.
- Adds a launch chain:
  1. Use the core `window.VMS_Tour.start` engine when available.
  2. Fall back to Driver.js directly when available.
  3. Fall back to a lightweight local tour renderer if neither engine is available.
- Keeps `tour=1` explicit launch behavior working through the same chain.
- Preserves `prefill=1` and `tour=0` no-auto-launch behavior.

### `assets/admin.css`

- Added minimal styles for the local fallback renderer:
  - backdrop
  - popover
  - step progress
  - Back/Next/Done buttons
  - temporary target outline

## Safety / Non-goals

- Does not re-register the Builder tour with the global VMS tour catalog.
- Does not change saved build hydration, Meta reconciliation, adoption, or discovery logic.
- Does not invoke or alter any live Meta campaign/ad/ad-set action.
- Local fallback only appears when the operator explicitly clicks **Start tour** or uses `tour=1`.

## Versioning

Updated to `0.1.72` in:

- `vms-meta-ads.php` plugin header
- `VMS_MA_VERSION`
- `module.json`
- `vms-build.txt`
