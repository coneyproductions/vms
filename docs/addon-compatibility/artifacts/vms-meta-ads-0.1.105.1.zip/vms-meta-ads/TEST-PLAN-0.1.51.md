# VMS Meta Ads Builder — Test Plan 0.1.51

## Goal
Verify that switching Event Plans and loading settings-only templates can no longer leak old variant media into a different event's ad draft.

## Install / setup
1. Install `0.1.51`.
2. Confirm the plugin reports `0.1.51` in WordPress.
3. Use two different Event Plans with clearly different event names, dates, ticket URLs, and creatives.

## Test A — event switch clears stale variant media
1. Open Event Plan A in the Meta Ads Builder.
2. Set shared images.
3. Set Variant 1 to `Custom image` and choose a very obvious image from Event A.
4. Optionally set Variant 2 to a custom video or image from Event A.
5. Save Draft.
6. Switch the builder to Event Plan B.
7. Confirm these reset immediately before saving:
   - shared square / vertical / wide images
   - Variant 1 media mode returns to `Use shared media`
   - Variant 1 custom image/video IDs are cleared
   - Variant 2 and Variant 3 text/media overrides are blank/reset
8. Confirm the main copy is reseeded for Event B.
9. Save Draft for Event B.

### Expected
- No Event A custom variant media remains attached after switching to Event B.
- Event B draft starts clean and only shows Event B details unless manually reselected.

## Test B — settings-only template does not reattach old variant media
1. On Event Plan A, choose a custom Variant 1 image or video.
2. Save Draft.
3. Save a template that includes audience / placements / budget only.
4. Switch to Event Plan B.
5. Apply that template.
6. Confirm these stay cleared after template apply:
   - shared images if template omitted them
   - Variant 1 custom image/video override
   - Variant 2 and Variant 3 custom media overrides
7. Confirm Event B destination URL and event-specific copy are not replaced by Event A media.
8. Save Draft.

### Expected
- Template apply does not resurrect Event A media selections.
- Event B remains event-correct unless you explicitly pick new media.

## Test C — create/update Meta after reset
1. With Event Plan B now clean, pick only the intended Event B media.
2. Save Draft.
3. Run `Create In Meta (PAUSED)` or `Update Existing Meta Ad`.
4. Review the resulting ad in Meta / feed preview.

### Expected
- Primary text, image/video creative, and destination URL all belong to Event B.
- No cross-event image/video or obvious stale headline/card mismatch appears.

## Test D — regression check for multi-variant flow
1. Create a valid multi-variant draft intentionally:
   - Variant 1 shared image
   - Variant 2 custom video
2. Save Draft.
3. Reload the page for the same Event Plan.
4. Confirm those intended selections still persist for the same event.

### Expected
- Same-event persistence still works.
- Only cross-event/template bleed is removed.
