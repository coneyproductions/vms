# VMS Meta Ads Builder 0.1.43 Test Plan

## Goal
Confirm legacy templates no longer carry forward creative images or other event-scoped fields when loaded.

## Steps
1. Open an Event Plan in Meta Ads Builder that currently has square / vertical / wide creative images selected.
2. Load an older saved template that previously caused prior-event images to reappear.
3. Confirm the image previews clear instead of loading the old template art.
4. Confirm audience / placements / budget / CTA from the template still apply normally.
5. Save the draft, refresh the page, and load the same template again.
6. Confirm the template remains clean on subsequent loads.

## Expected
- Old creative image IDs stored in legacy templates are ignored and stripped.
- Template load no longer reintroduces prior-event square / vertical / wide images.
- Reusable template settings still apply normally.
