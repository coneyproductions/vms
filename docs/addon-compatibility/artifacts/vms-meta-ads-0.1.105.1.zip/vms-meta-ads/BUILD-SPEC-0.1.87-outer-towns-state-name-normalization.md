# VMS Meta Ads Builder 0.1.87 — Outer Towns State Name Normalization

## Goal

Make Outer Towns city/state targeting more reliable by preferring full state names when querying Meta location search. Operators may still enter abbreviations such as `Athens, TX`, but MAB normalizes the lookup path to try `Athens, Texas` before abbreviation or city-only fallbacks.

## Changes

- City/state resolver now builds multiple Meta search queries in this order:
  1. `City, State Name`
  2. `City State Name`
  3. `City, ST`
  4. `City`
- Meta search candidates are aggregated across query variants and both global/account targeting search endpoints when available.
- Matching now accepts city names returned as `Athens, TX` as well as canonical names and region fields.
- Error messages list the query variants attempted and show the full state name plus abbreviation used for filtering.
- Step D placeholder now uses full state names.
- Helper text recommends spelling out the state name while still accepting abbreviations.
- Listed-only mode still never falls back to venue radius.

## Files touched

- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `includes/admin/screens/ads-builder.php`
- `includes/meta-api/client.php`
- `includes/services-ad-builds.php`
- `TEST-PLAN-0.1.87.md`
