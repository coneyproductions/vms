# VMS Meta Ads Builder 0.1.68 — Build Dropdown + Selection Polish

## Goal

Make saved linked builds easier to verify and switch between after the 0.1.67 timestamp/order fix. Codex confirmed the API returned the full correctly ordered build list, but the builder dropdown UI could appear to surface only the currently selected build.

## Changes

### Visible saved-build card list

Step A now includes a visible list below the linked-build dropdown:

- shows all builds loaded for the selected Event Plan
- displays newest-first order as returned by the `/ad-builds` endpoint
- marks the current build as **Loaded**
- provides a **Load** button for every other build
- shows status summaries for Draft, Live, Paused in Meta, error/attention, and Meta source-of-truth builds

### Dropdown hydration hardening

The front-end build cache now guards against a later single-build refresh collapsing a previously loaded full build collection for the same Event Plan. This protects the UI after adoption, refresh, save draft, and status refresh paths where a single updated build object may be returned.

### Clearer source-of-truth visibility

Build rows now make it easier to see when a build is linked to an adopted/live Meta campaign and when Meta is being treated as the source of truth.

## Non-goals

This pass does not add Meta API health checks, preflight validation, Safe Mode, or live-changing Meta actions.

## Files changed

- `assets/ads-builder.js`
- `assets/admin.css`
- `includes/admin/screens/ads-builder.php`
- `vms-meta-ads.php`
- `module.json`
- `vms-build.txt`
- `BUILD-SPEC-0.1.68-build-dropdown-polish.md`
- `TEST-PLAN-0.1.68.md`
