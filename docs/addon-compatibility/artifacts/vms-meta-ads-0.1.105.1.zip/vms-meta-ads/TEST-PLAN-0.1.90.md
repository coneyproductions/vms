# MAB 0.1.90 Test Plan — Phase 1B Safety Hardening

## A. Package / version

1. Confirm the release ZIP contains one canonical top-level folder: `vms-meta-ads/`.
2. Confirm plugin header version is `0.1.90`.
3. Confirm `VMS_MA_VERSION` is `0.1.90`.
4. Confirm `module.json` version is `0.1.90`.
5. Confirm `module.json` requires VMS core `0.2.24.711`.
6. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.90`.

## B. Static validation

Run from the unpacked plugin directory:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/admin/api-diagnostics.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.90-phase-1b-safety-hardening.zip
```

## C. Premium-module gate matrix

1. Empty `vms_premium_modules_enabled` list:
   - locked notice appears
   - direct builder URL is denied
2. `meta_ads_builder` explicitly disabled:
   - locked notice appears
   - direct builder URL is denied
3. `meta_ads_builder` explicitly enabled with VMS core active:
   - builder loads normally
4. VMS core loads before MAB:
   - builder still loads normally
5. MAB loads before VMS core:
   - builder still loads after the deferred gate runs
6. VMS core inactive/missing:
   - `module system unavailable` notice appears
   - direct builder URL is denied

## D. Dry-run smoke

1. Keep `enable_api_create` off.
2. Open a future Event Plan in Meta Ads Builder.
3. Save the draft and click `Preview Meta Dry Run`.
4. Confirm the draft save succeeds.
5. Confirm a local `wp_vms_api_attempts` row is written for the dry run.
6. Confirm the preview renders:
   - blockers
   - campaign / ad set / creative / ad structure
   - CTA
   - destination URL
   - age
   - geo rows
   - placements
   - schedule support details, including whether the saved build currently resolves to one window or multiple windows
7. Confirm the dry-run copy states that no Meta API calls are made and no spend occurs.
8. Confirm zero requests are made to `graph.facebook.com`.

## G. Schedule-window validation

1. Confirm `Flat run`, `Simple 7 day`, `Simple 14 day`, `Simple 30 day`, and `Manual dates` each save as one schedule window and do not raise a schedule-support warning in dry run.
2. Confirm `Video-Led Ticket Push` and `Promo Bundle 30/14/7` still allow `Preview Meta Dry Run`, but only warn when the saved build currently resolves to multiple schedule windows.
3. Confirm a tiered preset that collapses to one remaining window no longer shows a stale `Flat run preset required` blocker.
4. Confirm `Create in Meta (PAUSED)` and `Update Existing Meta Ad` stay gated client-side whenever the current builder state still produces more than one schedule window.
5. Confirm dry run still makes zero requests to `graph.facebook.com` while rendering the first-window request structure that direct create would use today.

## E. Audience / destination regression

1. Confirm the clean-room default age renders as `30-65+`.
2. Confirm Outer Towns no longer silently defaults to `45-65`.
3. Confirm CTA remains `BUY_TICKETS`.
4. Confirm destination remains the website / event ticket URL, not a Facebook event URL.

## F. Admin UI / containment regression

1. Confirm builder page shows no PHP fatals.
2. Confirm no browser console errors occur on initial builder load.
3. Confirm empty Meta status on a build with no created Meta objects no longer produces a JS error.
4. Confirm the standard WordPress VMS left rail remains compact and does not list Meta Ads Builder directly.
5. Confirm Meta Ads Builder remains discoverable through the VMS navigation / directory and by direct URL.
