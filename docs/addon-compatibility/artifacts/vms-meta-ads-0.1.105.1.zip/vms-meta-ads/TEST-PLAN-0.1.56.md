# VMS Meta Ads Builder 0.1.56 Test Plan

## Focus
- Asset-feed creative creation succeeds again with shared square + vertical media
- Website-link dark post updates no longer fail on object_story_spec
- If creative fallback fails, the surfaced error should be the final retry error, not the first asset-feed error

## Checks
1. Install 0.1.56 over 0.1.55.
2. Open the same linked build that failed on create_creative.
3. Keep shared square + vertical media enabled.
4. Click Update Existing Meta Ad.
5. Confirm no object_story_spec invalid error appears.
6. Open in Ads Manager and verify the ad still points to the intended website URL.
7. If Meta still rejects the creative, confirm the notice/diagnostic reflects the final retry attempt rather than the first attempt.
