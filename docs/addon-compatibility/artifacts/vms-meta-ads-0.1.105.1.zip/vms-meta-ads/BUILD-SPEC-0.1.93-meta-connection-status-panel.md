# BUILD SPEC 0.1.93

## Summary
- Add a dedicated non-mutating Meta Connection Status REST endpoint and settings-screen panel.
- Keep all checks read-only: Meta GET requests only, no local settings writes, no token refresh, no Meta object mutation.
- Preserve the existing `Test Connection` workflow and label it clearly as the settings-updating verification path.

## Scope
- New REST endpoint: `GET /wp-json/vms-ma/v1/meta-connection-status`
- New server snapshot builder in `VMS_Meta_Ads_Meta_Client`
- New settings-panel UI and client rendering in `assets/settings.js`
- New settings-screen copy distinguishing read-only status from `Test Connection`
- No schema changes
- Requires VMS core `0.2.24.711`

## Status Payload
- Token present / redacted status
- Token validity classification from read-only checks
- Graph version
- Ad account reachability, resolved name, timezone
- Page reachability, resolved name, stored URL / slug
- Instagram reachability, username / name
- Pixel reachability, resolved name
- Granted permissions
- Missing relevant permissions
- Mismatch warnings
- Latest local dry-run summary when available

## Safety
- Works while `enable_api_create=0`
- Works while `vms_ma_phase=1`
- Logs attempts with `readonly_status_*` operations under `connection_status`
- Does not call create/update/delete/publish endpoints
