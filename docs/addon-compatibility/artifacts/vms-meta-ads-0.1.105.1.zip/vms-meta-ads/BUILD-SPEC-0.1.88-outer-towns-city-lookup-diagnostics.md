# VMS Meta Ads Builder 0.1.88 Build Spec

## Title
Outer Towns City Lookup Diagnostics + State Matcher Hardening

## Goal
Harden the 0.1.87 city/state targeting resolver after live Meta diagnostics showed the ad-account targeting search endpoint can fail with `(#200) Provide valid app ID`, even when the city query sequence is correct.

## Changes

1. **Prefer global targeting search before ad-account fallback**
   - Run all `/search?type=adgeolocation` city lookup variants first.
   - Only try `act_<ad_account_id>/targetingsearch` if the global search returns no candidates.
   - This prevents a valid global lookup from being obscured by a later ad-account App ID failure.

2. **Improve city lookup failure messages**
   - If Meta returns `Provide valid app ID`, show a targeted operator message explaining that city lookup failed because Meta rejected the targeting search request.
   - Recommend ZIP code fallback or fixing Meta app authentication.

3. **Harden state matching**
   - Accept rows where Meta returns state information only in `name`, such as `Athens, TX`, even when `region` and `canonical_name` are blank.
   - Continue rejecting wrong-state rows like `Athens, Georgia` / `Athens, GA`.

4. **Improve diagnostics visibility**
   - Recent API diagnostic rows now show the endpoint/query string in addition to operation name, so city lookup attempts are easier to audit.

## Non-goals
- Do not add a Meta App ID settings UI yet.
- Do not weaken the listed-only safety guard.
- Do not fall back to Whitehouse/Tyler/venue radius if city lookup fails.
