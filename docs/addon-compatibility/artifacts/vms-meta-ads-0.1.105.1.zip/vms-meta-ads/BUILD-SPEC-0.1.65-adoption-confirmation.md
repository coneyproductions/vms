# VMS Meta Ads Builder 0.1.65 — Adoption Confirmation Polish

## Purpose

0.1.64 successfully introduced Meta campaign discovery/adoption, but the post-adoption UI was not explicit enough. After linking an existing Meta campaign, the dropdown and build details could still display the saved draft's original targeting, making it look like the adoption may not have worked.

## Scope

This pass makes adoption success unmistakable and preserves the important distinction between:

- the saved builder draft values; and
- the active Meta campaign that is now the source of truth.

## Requirements

### 1. Persist adopted Meta summary

When an existing Meta campaign is adopted, save a compact summary into the build's `meta_ids` payload:

- source of truth = Meta
- adoption source = existing Meta campaign
- campaign ID/name/status
- ad set ID/name/status
- live audience summary
- live budget amount/type
- number of ads found
- adoption timestamp

### 2. Improve linked build labels

When a build has an adopted Meta summary, the build dropdown should prefer the live Meta summary instead of only showing stale saved draft targeting.

Expected behavior:

- before adoption, label can show saved draft values;
- after adoption, label should show `Live in Meta` plus live Meta audience/budget details;
- saved draft differences should remain visible in the build detail line instead of silently overwriting them.

### 3. Add linked campaign confirmation card

After adoption and on later page loads, the reconciliation panel should display a compact linked-state card showing:

- linked active Meta campaign
- Meta source of truth
- campaign/ad set details
- live audience/budget
- warning that saved draft settings may still differ

### 4. Prevent repeated adoption confusion

If discovery finds the already-linked campaign again, its card should be marked Linked and the adoption button disabled.

### 5. Preserve safety

This pass must not create, pause, publish, update, or overwrite any Meta campaign. It only improves local display and saved adoption metadata.
