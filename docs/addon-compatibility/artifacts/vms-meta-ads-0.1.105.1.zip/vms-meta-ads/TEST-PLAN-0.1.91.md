# MAB 0.1.91 Test Plan — Schedule Support Cleanup

## A. Package / version

1. Confirm the release ZIP contains one canonical top-level folder: `vms-meta-ads/`.
2. Confirm plugin header version is `0.1.91`.
3. Confirm `VMS_MA_VERSION` is `0.1.91`.
4. Confirm `module.json` version is `0.1.91`.
5. Confirm `module.json` still requires VMS core `0.2.24.711`.
6. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.91`.
7. Confirm `vms_ma_db_version` upgrades to `4` after install/activation.

## B. Static validation

Run from the unpacked plugin directory:

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/ads-builder.js
node --check assets/admin/api-diagnostics.js
node --check assets/guidance.js
node --check assets/help-mode.js
node --check assets/settings.js
node --check assets/tours.js
zip -T ../vms-meta-ads-0.1.91-schedule-support-cleanup.zip
```

## C. Default strategy / preset

1. Open a fresh builder session with no build selected.
2. Confirm the selected strategy is `Ticketed Concert - Direct-Create Safe Push`.
3. Confirm the selected preset is `Simple 14 day`.
4. Confirm age defaults render as `30-65+`.
5. Confirm CTA remains `BUY_TICKETS`.
6. Confirm the destination still stays on the website event/ticket URL.

## D. Dry-run schedule matrix

1. Flat-run build:
   - `Preview Meta Dry Run` succeeds locally
   - `schedule_support.direct_create_supported = true`
   - no stale `Flat run preset required` warning appears
2. Non-flat single-window build (`simple_7_day`, `simple_14_day`, `simple_30_day`, or `manual_dates`):
   - dry run succeeds locally
   - `schedule_support.direct_create_supported = true`
   - no stale `Flat run preset required` warning appears
3. Multi-window build (`video_tribute_push` or `promo_bundle_30_14_7` with more than one remaining window):
   - dry run still succeeds locally
   - `schedule_support.direct_create_supported = false`
   - warning explains that only a single saved schedule window is create-compatible in this phase
   - preview still renders the first remaining window request structure
4. Confirm every dry run still logs to `wp_vms_api_attempts`.
5. Confirm zero requests are made to `graph.facebook.com`.
6. Confirm saving a new `Simple 14 day` draft succeeds and does not hit a tier-key DB error.

## E. Direct create/update gating

1. Confirm create/update preflight remains blocked for multi-window builds.
2. Confirm the builder UI surfaces the single-window requirement before create/update.
3. Confirm non-flat single-window presets remain eligible for create/update once settings/credentials/phase gates are satisfied.

## F. Payload integrity

1. Confirm dry-run preview remains explicit about:
   - campaign / ad set / creative / ad structure
   - CTA
   - destination URL
   - age
   - geo rows
   - placements
   - `schedule_support`
2. Confirm Outer Towns does not silently fall back to `45-65`.
3. Confirm vertical/square placement handling still renders explicitly in preview output.

## G. Runtime smoke

1. Confirm no PHP fatals are introduced by the patch.
2. Confirm authenticated browser smoke loads the builder with no JS console errors and no page errors.
3. Confirm the dry-run UI copy still states that no Meta API calls are made and no spend occurs.
4. Confirm the tier schema migration allows `simple_14` / `simple_30` rows to save in `wp_vms_meta_ads_tiers`.
