# VMS Meta Ads Builder 0.1.41 Test Plan

## Scope
Validate the new dirty-state lockout and the new **Update Existing Meta Ad** flow on an already linked build.

## 🚨 Priority test sequence
1. Open an Event Plan that already has a linked Meta build.
2. Confirm **Refresh Status**, **Update Existing Meta Ad**, **Sync Budget to Meta**, and status chips load normally.
3. Change one or more fields such as:
   - age min / age max
   - radius
   - locations
   - interests
   - headline / primary text
4. Confirm the unsaved-changes warning appears.
5. Confirm these buttons are disabled until save:
   - Create in Meta (PAUSED)
   - Update Existing Meta Ad
   - Sync Budget to Meta
   - Go Live
6. Confirm **Refresh Status** still works.
7. Confirm **Pause All** still works when the linked ad is active.
8. Click **Save Draft**.
9. Confirm the unsaved-changes warning disappears.
10. Confirm **Update Existing Meta Ad** becomes available again.
11. Click **Update Existing Meta Ad**.
12. Confirm success messaging appears.
13. Click **Refresh Status**.
14. Verify in Ads Manager that the audience/copy changes were pushed to the linked assets.

## Budget-specific follow-up
1. Change only the budget.
2. Confirm **Sync Budget to Meta** disables until **Save Draft**.
3. Save Draft.
4. Click **Sync Budget to Meta**.
5. Confirm the budget sync state updates and matches Meta.

## New draft behavior
1. Open an Event Plan with no existing ad draft.
2. Confirm the builder shows the warning that a draft must be saved first.
3. Confirm Create / Update / Sync / Go Live stay unavailable until Save Draft.
4. Save Draft.
5. Confirm Create in Meta (PAUSED) becomes available once connection/phase requirements are satisfied.

## Variant coverage
1. Test with a single-variant build.
2. Test with a multi-variant build.
3. For a multi-variant build, change Variant 2 or Variant 3 copy.
4. Save Draft.
5. Run **Update Existing Meta Ad**.
6. Verify each linked variant is still represented correctly in the status summary.

## Regression checks
- Save Template still works.
- Apply Template still works.
- Export Copy Pack still works.
- Refresh Status still works on older single-ad builds.
- Reset Meta Link still clears the local IDs without deleting assets in Meta.

## Notes to watch for
- Any Meta API error when updating live ads should surface clearly in the builder.
- If extra legacy variants remain linked in Meta, the builder should warn rather than silently hide them.
- If Update Existing Meta Ad fails, confirm no critical/admin page crash occurs.
