# BUILD SPEC 0.1.95

## Summary
- Keep initial MAB builder render read-only and lightweight.
- Remove write-capable TEC venue resolution from builder Event Plan seeding and selected-event detail fetches.
- Reduce the initial Event Plan seed and move additional discovery to on-demand search.

## Scope
- `includes/services-event-plans.php`
  - Replace write-capable TEC venue resolution with read-only meta lookups.
  - Reduce overscan for Event Plan collection queries.
  - Expose lightweight admin-only trace metadata for recent list/detail fetches.
- `includes/admin/screens/ads-builder.php`
  - Reduce initial builder Event Plan seed to 20.
  - Add search/reset controls and admin-only perf metadata on the wrapper.
- `assets/ads-builder.js`
  - Add on-demand Event Plan search against the existing read-only REST collection.
  - Preserve selected-event detail fetches and dry-run/create guardrails.

## Safety
- No Meta mutation behavior changes.
- No DB schema changes.
- No VMS core package required.
- `enable_api_create=0` and `vms_ma_phase=1` remain the no-spend baseline.
