# Codex Test Plan — VMS Meta Ads Builder 0.1.67

## Goal

Verify that 0.1.67 fixes zero timestamps, build ordering, and adopted/live Meta action state without mutating live Meta campaigns.

🚨 **Do not invoke live-changing Meta actions unless explicitly requested.** For this pass, avoid Create in Meta, Update Existing Meta Ad, Go Live, Pause, and Budget Sync unless the user separately approves a live-action test.

## Install / smoke

1. Install/activate `vms-meta-ads-0.1.67-timestamp-action-hardening.zip` on staging.
2. Confirm the plugin version shows `0.1.67`.
3. Open the Meta Ads Builder page.
4. Confirm the guided tour does **not** auto-launch and block clicks.
5. Confirm the **Start tour** button still starts the tour manually.

## Timestamp regression

1. Select a staging Event Plan.
2. Start a new linked build.
3. Save Draft.
4. Refresh the page.
5. Inspect the build dropdown/API response.
6. Confirm `created_at` and `updated_at` are real timestamps, not `0000-00-00 00:00:00`.
7. Make a harmless copy-only change and Save Draft again.
8. Refresh and confirm `updated_at` advances or remains a valid non-zero timestamp.

## Legacy zero timestamp repair

1. If staging has existing builds with `0000-00-00 00:00:00`, load the builder/build list endpoint.
2. Confirm legacy rows are repaired or no longer returned with zero timestamps.
3. Confirm no fatal errors occur if no zero timestamp rows exist.

## Build ordering

1. Create two new staging test builds for the same Event Plan.
2. Refresh builds.
3. Confirm the newest valid build appears ahead of older builds.
4. Confirm any legacy repaired/zero-date artifacts do not incorrectly override newer builds.

## Adopted existing Meta build action state

Use an already adopted build from the prior 0.1.66 test or re-adopt a known staging-safe Meta campaign without changing Meta.

1. Select the adopted/live build.
2. Refresh the page.
3. Confirm the linked build still displays as Live in Meta / Meta source of truth.
4. Scroll to Step G / Actions.
5. Confirm **Create in Meta (PAUSED)** is disabled or clearly unavailable because the build already has Meta IDs.
6. Confirm **Update Existing Meta Ad** does **not** say “Create in Meta first.”
7. Confirm the action guidance tells the operator to review drift before pushing builder changes.
8. Do not click Update unless separately authorized.

## Save Draft linkage regression

1. On the adopted build, make a harmless copy-only change.
2. Save Draft.
3. Refresh.
4. Confirm the build remains linked to the same Meta campaign/ad set/ad IDs.
5. Confirm timestamps remain valid and non-zero.

## Pass criteria

- No zero timestamps on newly saved/updated builds.
- Build ordering is stable and newest valid builds appear first.
- Existing adopted Meta build remains linked after Save Draft and refresh.
- Create action is unavailable for already-linked builds.
- Update action recognizes saved Meta IDs and no longer says “Create first.”
- Guided tour no longer auto-blocks testing/admin clicks.
- No live Meta campaign/ad/ad set state is changed during this test.
