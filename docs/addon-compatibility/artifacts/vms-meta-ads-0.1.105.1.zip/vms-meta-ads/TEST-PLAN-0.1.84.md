# VMS Meta Ads Builder 0.1.84 Test Plan

## A. Version/package validation
1. Confirm the installed plugin directory is `vms-meta-ads/`.
2. Confirm plugin header reports `0.1.84`.
3. Confirm `VMS_MA_VERSION` reports `0.1.84`.
4. Confirm `module.json` reports `0.1.84`.
5. Confirm `vms-build.txt` starts with `VMS Meta Ads Builder build 0.1.84`.
6. Confirm release zip contains one canonical top-level directory: `vms-meta-ads/`.

## B. Static validation
1. Run PHP lint across all plugin PHP files.
2. Run `node --check` for:
   - `assets/ads-builder.js`
   - `assets/admin/api-diagnostics.js`
   - `assets/guidance.js`
   - `assets/help-mode.js`
   - `assets/settings.js`
   - `assets/tours.js`
3. Run `zip -T` against the packaged release zip.

## C. Clean-room preview copy validation
1. Open MAB in wp-admin.
2. Choose `Clean-Room Concert Campaign - Full Push v2`.
3. Set Step D age min to `45` and age max to `65+`.
4. Expand the clean-room recipe preview/checklist.
5. Confirm the Outer Towns preview row shows the current Step D age range instead of hardcoded `50+`.
6. Confirm the checklist layout summary says `Outer Towns Feeds (45-65+)` or the equivalent current Step D age range.

## D. Regression spot-check
1. Keep `Clean-Room Concert Campaign - Full Push v2` selected.
2. Set Outer Towns targeting mode to `Listed towns/ZIPs only`.
3. Leave Outer Towns ZIPs/full addresses empty.
4. Try Save Draft or Create in Meta.
5. Expected: MAB still blocks with an error requiring at least one precise ZIP or full address.

## E. Live paused-create validation
1. Use a fresh Event Plan or reset/clone the existing Meta link.
2. Enter explicit Outer Towns ZIPs/full addresses.
3. Set a non-50+ Step D age range such as `45` to `65+`.
4. Click Create in Meta (PAUSED).
5. Expected: MAB first saves the latest draft, then creates paused assets.
6. In Ads Manager, verify Outer Towns age matches Step D and listed-only mode does not fall back to the primary venue radius.
