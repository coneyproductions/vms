# Codex Test Plan — VMS Meta Ads Builder 0.1.65

🚨 **Codex testing requested: adoption confirmation and no-Meta-mutation safety.**

## Setup

Use an Event Plan with:

- a saved Ads Builder build whose saved draft targeting differs from the live Meta ad set; and
- an existing active Meta campaign discoverable through Step A reconciliation.

## Test 1 — Adopted summary persistence

1. Select the Event Plan.
2. Click **Find Existing Meta Campaigns**.
3. Adopt the matching active Meta campaign.
4. Inspect the build record after adoption.

Expected:

- build status becomes `live` when Meta campaign/ad set/ad are active;
- `meta_ids` includes `source_of_truth: meta`;
- `meta_ids` includes `adoption_source: existing_meta_campaign`;
- `meta_ids.adopted_summary` includes live campaign/ad set/audience/budget details.

## Test 2 — Dropdown and build detail clarity

1. Reload the Ads Builder page.
2. Select the same Event Plan/build.

Expected:

- linked build dropdown says `Live in Meta` and shows live Meta summary, not only stale saved draft targeting;
- build detail line includes `Meta source of truth`;
- saved draft targeting differences are still visible as saved draft values.

## Test 3 — Linked confirmation card

1. Reload the Ads Builder page after adoption.
2. Open Step A.

Expected:

- Meta reconciliation panel shows a linked active Meta campaign card without needing to run discovery again;
- card shows campaign/ad set/audience/budget details;
- card warns that saved builder settings may still differ and drift should be reviewed before pushing updates.

## Test 4 — Re-discovery marks already linked campaign

1. Click **Find Existing Meta Campaigns** again after adoption.

Expected:

- already-linked campaign card is marked Linked;
- adoption button is disabled/replaced with `Linked to this build`;
- no duplicate adoption action is encouraged.

## Test 5 — No Meta mutation

During all tests, verify the plugin does not:

- create a new campaign;
- publish an ad;
- pause an ad;
- overwrite budget/audience/creative;
- push saved builder settings to Meta.

Adoption confirmation is local state/display only.
