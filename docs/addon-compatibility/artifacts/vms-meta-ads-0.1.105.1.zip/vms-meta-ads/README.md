# VMS Meta Ads Builder

Meta Ads Builder provides a guided wizard for crafting Meta (Facebook + Instagram) copy packs, exploring promo schedule presets, previewing dry-run Meta payloads, and optionally releasing paused campaigns to Meta when live create is deliberately enabled.

## Installation
1. Drop the `vms-meta-ads` folder into `wp-content/plugins`.
2. Activate the plugin via the WordPress Plugins screen.
3. Enable premium access for module slug `meta_ads_builder` in VMS licensing.
4. Visit the VMS Marketing & Social hub or All VMS Pages to open Meta Ads Builder / Meta Ads Settings.
5. Install VMS core `0.2.24.711` or newer. This add-on now fails closed until the VMS premium-module registry is available and can verify the `meta_ads_builder` module gate.
6. Let the plugin finish its DB upgrade on first admin load. Current MAB DB version remains `4`; `0.1.98` does not introduce any new schema change.

## Premium Add-on Registration
- This plugin registers itself as premium module slug `meta_ads_builder`.
- Core module metadata is exposed through `vms_register_module()` / `vms_get_registered_modules()`.
- Runtime gating uses `vms_module_is_enabled('meta_ads_builder')`.
- If the VMS module system is unavailable or the module cannot be verified as registered, MAB stays locked instead of loading admin functionality accidentally.
- Licensing defaults to option `vms_premium_modules_enabled` (array of slugs), and can be overridden with:
  - `vms_premium_module_licensed`
  - `vms_module_enabled`

## Settings
- Budget clamps live in cents (`budget_max_daily_minor` / `budget_max_lifetime_minor`).
- Radius & age defaults drive the simple audience builder.
- Toggle API creation only when you have an ad account and valid token. Keep it off for no-spend validation and dry runs.
- Tokens are stored encrypted and masked.
- Use the new `Meta Connection Status` panel for a read-only audit of the saved Meta connection. It does not update settings, refresh tokens, or create Meta objects.
- `Test Connection` remains available and still updates the saved connection verification/timezone fields on success.

## Testing / Dry Run Mode
1. Open Meta Ads Builder from the Marketing & Social hub, All VMS Pages, or direct admin URL.
2. Step through Source → Strategy → Creative → Audience → Budget.
3. New builds now start on a direct-create-safe `Simple 14 day` schedule strategy. Tiered presets remain available for preview/export/manual planning.
4. Save the draft and use `Preview Meta Dry Run`.
5. Confirm the preview shows the campaign/ad set/creative request structure, blockers/warnings, schedule support details, CTA, destination URL, age, geo rows, and a readable placement summary above the raw JSON preview.
6. Confirm no Meta API call is made and no spend can occur.

## Paused-Create Readiness
- `0.1.96` keeps paused review states safer and more operator-readable. If Meta temporarily reports `PENDING_REVIEW` while every object is still inactive, MAB now classifies that as a paused review state instead of a generic error.
- DSA readiness now uses Meta's `dsa_beneficiary` and `dsa_payor` field names. Missing values are surfaced as readiness warnings and block `Go Live` until the operator fills them in.
- `0.1.97` keeps the dry-run request-plan in sync with the real create payload by surfacing `dsa_beneficiary` and `dsa_payor` directly in the ad set preview when configured.
- `0.1.98` downgrades configured-and-sent DSA values that Meta does not echo in ad-set readback into an advisory Ads Manager review item, instead of implying the paused create failed. Real `issues_info` remain blocking.
- The direct-create-safe default strategy now starts on an explicit FB/IG manual placement set. Automatic placements remain available, but MAB warns that Meta edit UI can imply broader coverage and should be rechecked before any `Go Live` step.
- Post-create status refresh now exposes a compact readiness checklist for campaign/ad set/ad states, geo targeting, pixel, CTA/destination, placements, DSA fields, Multi-advertiser, Advantage+ creative, and Meta `issues_info` / `recommendations`.

## Builder Performance Safety
- `0.1.95` keeps the initial builder render read-only. Opening the builder no longer uses the write-capable TEC venue helper path that could reach `wp_update_post()` through venue sync side effects.
- The initial Event Plan picker seed is intentionally small and read-only. Search loads more on demand instead of preloading hundreds of Event Plans on first paint.
- If location data is incomplete, the builder uses read-only venue/event meta and falls back to a safe placeholder instead of trying to backfill TEC venue records during page render.
- Admin-only builder perf metadata is exposed in `window.vmsMaBuilderPerf` and matching wrapper `data-*` attributes for seed count, read-only location mode, query count, and render timing. It does not add noisy logging by default.

## Meta Connection Status
1. Open `Meta Ads Settings`.
2. Use `Run Read-Only Status Check`.
3. Confirm the panel reports token presence/status, Graph version, ad account/page/Instagram/pixel reachability, granted permissions, missing relevant permissions, mismatch warnings, and the latest local dry-run summary.
4. Confirm the panel states it is read-only and does not update settings or create Meta objects.

## Enabling Meta API Create
1. Enter ad account/page/IG actor IDs and a valid access token.
2. Toggle _Enable API create_ to ON.
3. Run the builder and click _Create PAUSED_ to test only after a final operator review. Live actions remain gated behind settings, credentials, and confirmation.

## Create Paused Safety Guardrails
- `0.1.94` guarantees every campaign create retry/fallback payload explicitly requests `status=PAUSED`.
- `Create in Meta (PAUSED)` now opens a final confirmation modal summarizing campaign name, event, budget, schedule, destination, placements, account/page/pixel, and expected paused status.
- The server rejects `meta-create` requests that do not include the explicit confirmation flag, even if a caller bypasses the browser UI.
- If a partial Meta create occurs, the builder now surfaces all known Meta IDs, paused-status verification details, an Ads Manager link, and manual cleanup guidance.
- Reusing saved partial Meta IDs now requires a read-only paused-status check first. Unknown or active statuses block retry until manual review.

## Guided Tour
- The guided tour starts automatically on first load (can be reset via settings).
- Click _Start Tour_ or use Help Mode toggles to replay guidance.

## Social Sharer Integration
- Social Sharer can provide shared post assets via `vms_ma_post_asset_create`/`list`/`get` helpers.
- Register a filter on `vms_social_meta_connection` to expose ad account+token details.

## Troubleshooting
- _Permissions_: Ensure the current user has the capability defined by VMS (fallback `manage_options`).
- _Builder missing from the compact left rail_: expected current VMS behavior. Use the Marketing & Social hub, All VMS Pages, or the direct admin URL.
- _Tiered preset warning_: expected in this phase when the saved build still expands into multiple schedule windows. Dry run can still preview the first remaining window, but direct Meta create/update remains single-window only.
- _Placements card_: `0.1.92` adds a readable dry-run placement summary for both automatic/default and manual flows. Placement behavior itself is unchanged.
- _Meta Connection Status_: `0.1.93` adds a separate read-only audit panel. Use that for safe status checks; keep `Test Connection` for the older verification path that updates local timestamps/timezone details.
- _Create in Meta (PAUSED)_: `0.1.94` adds a final confirmation modal and server-side confirmation requirement. If create stops on a partial error, use the surfaced Meta IDs and Ads Manager link for manual cleanup review before retrying.
- _Slow builder load_: `0.1.95` removes the write-capable TEC venue sync path from the builder event-picker render and reduces the initial Event Plan seed. If the builder is still slow, treat production use as off-peak preferred until the surrounding VMS/analytics stack is profiled further.
- _Pending review after paused create_: `0.1.96` treats `PENDING_REVIEW` as a safe paused-review state while objects remain inactive. Review the readiness panel and Ads Manager before any later publish step.
- _DSA advertiser / payer warnings_: `0.1.96` surfaces missing `dsa_beneficiary` / `dsa_payor` values in Settings, paused-create readback, and Go Live readiness. `0.1.97` also mirrors those configured values in the dry-run ad-set request preview. `0.1.98` treats configured-and-sent values that Meta does not return in ad-set readback as advisory when Meta returned no blocking `issues_info`; verify Advertiser/Payer in Ads Manager before publish.
- _Placement readiness_: `0.1.96` defaults the direct-create-safe strategy to explicit FB/IG manual placements and surfaces placement-mode/readback warnings if automatic placements or unexpected live placements show up.
- _Meta edit UI inconsistency_: `0.1.98` keeps Review/readback as the source of truth for Multi-advertiser ads and Advantage+ creative. Meta edit screens can show stale/default checkboxes, so do not save manual edits unless Review still shows both Off.
- _Token invalid_: Rotate the token and verify via the Settings → Test Connection button.
- _Ad account inaccessible_: Verify the `act_` formatting and that the token belongs to that account.
