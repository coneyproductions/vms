# TEST PLAN — VMS Meta Ads Builder 0.1.70

## Safety rule

Do not invoke live-changing Meta actions during this test:

- Create in Meta
- Update Existing Meta Ad
- Go Live
- Pause
- Budget Sync

## Setup

Use staging Event Plan 2515, Buffet Beach, with the known adopted/live build #25 linked to campaign `6935199138516` and ad set `6935199142316`.

## Tests

### 1. Confirm version

Open `wp-content/plugins/vms-meta-ads/vms-build.txt` and confirm 0.1.70 is active.

### 2. No guided tour auto-launch with explicit tour=0

Open the builder URL with `event_plan_id=2515&prefill=1&tour=0`.

Expected:

- no Driver overlay appears automatically
- no tour popover intercepts clicks
- saved-build list remains usable immediately

### 3. No guided tour auto-launch with no tour parameter

Open the builder URL with `event_plan_id=2515&prefill=1` and no `tour` parameter.

Expected:

- no Driver overlay appears automatically
- no tour popover intercepts clicks

### 4. Manual Start tour still works

Click **Start tour**.

Expected:

- the tour opens manually
- closing the tour returns control to the builder

### 5. Build list still hydrates fully

On fresh reload, confirm the saved build dropdown/card list includes all expected builds returned by the API and remains ordered newest-first.

Expected known order for Buffet Beach at time of prior test:

`27, 26, 25, 24, 23, 22, 15`

### 6. Discovery renders linked candidate correctly

Load build #25, which should show **Live in Meta • Meta source of truth**. Click **Find Existing Meta Campaigns**.

Expected:

- build #25 remains selected
- hidden build ID remains #25
- dropdown/detail/card remain synchronized
- campaign `6935199138516` / ad set `6935199142316` appears as **Linked to this build**
- it does not show **Adopt / Link this Meta campaign** for that same candidate

### 7. No live Meta mutations

Confirm no live-changing Meta actions were invoked and the linked IDs did not change.
