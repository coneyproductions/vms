# TEST PLAN 0.1.94

## Static
- `php -l` on changed PHP files
- `node --check` on `assets/ads-builder.js`

## Local
- Keep `enable_api_create=0`
- Keep `vms_ma_phase=1`
- Confirm `Create in Meta (PAUSED)` remains gated even if the confirmation modal can render
- Confirm the server rejects `meta-create` without `confirm_create_paused`
- Confirm dry run remains local-only with zero Meta mutation calls
- Confirm the warning banner and partial-create guidance panel render without console/page errors

## Staging
- Deploy `vms-meta-ads 0.1.94` only
- Keep VMS core at `0.2.24.711`
- Clamp `enable_api_create=0`
- Clamp `vms_ma_phase=1`
- Run dry run and Meta Connection Status only
- Confirm no create/update/delete/publish endpoint is called
- Confirm create confirmation copy renders cleanly in the builder

## Safety Assertions
- Every campaign payload candidate contains `status=PAUSED`
- Multi-window direct create remains blocked
- Partial retry requires read-only paused-status verification or returns cleanup guidance
- Production remains untouched in this phase
