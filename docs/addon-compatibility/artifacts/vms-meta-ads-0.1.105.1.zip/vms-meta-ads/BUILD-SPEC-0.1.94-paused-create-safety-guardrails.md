# BUILD SPEC 0.1.94

## Summary
- Harden the paused-create path before any first real Meta object creation test.
- Guarantee explicit `status=PAUSED` on every campaign create payload candidate and fallback candidate.
- Add final operator confirmation in both the UI and server request body for `Create in Meta (PAUSED)`.
- Surface partial-create cleanup guidance and block unsafe reuse of previously created Meta IDs.

## Scope
- `includes/meta-api/client.php`
- `includes/rest/controllers/class-ad-builds-controller.php`
- `includes/admin/screens/ads-builder.php`
- `includes/admin/enqueue.php`
- `assets/ads-builder.js`
- `assets/admin.css`
- No schema changes
- Requires VMS core `0.2.24.711`

## Safety Changes
- Campaign payload candidates now inherit explicit `status=PAUSED` from a shared base payload.
- A validator refuses to continue if any campaign payload candidate is missing paused status.
- Create preflight now prefers the non-mutating connection-readiness check.
- Stored partial Meta IDs are verified read-only and must still be paused before reuse.
- Partial create errors return known Meta IDs, status snapshots, cleanup guidance, and Ads Manager links.

## UI Changes
- New create-preflight modal for `Create in Meta (PAUSED)`.
- Modal summary includes campaign name, event, budget, schedule, destination URL, placements, account/page/pixel, and expected status.
- Builder warning banner distinguishes Dry Run, Create in Meta (PAUSED), and Go Live when MAB is above no-spend mode.
