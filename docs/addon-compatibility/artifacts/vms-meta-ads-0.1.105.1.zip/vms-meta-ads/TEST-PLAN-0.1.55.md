# VMS Meta Ads Builder 0.1.55 — Test Plan

## Focus
Confirm website-link creatives created from shared/default media stay wired to the website destination in Meta Ads Manager.

## Test Steps
1. Install `vms-meta-ads-0.1.55-website-destination-fix.zip`.
2. Open a linked build that uses **Dark Post Link Ad** and **Default Shared Media**.
3. Save Draft, then click **Update Existing Meta Ad**.
4. Open the ad in Meta Ads Manager.
5. Confirm **Destination** is **Website**, not **Facebook event**.
6. Confirm the CTA still points to the event page on the website.
7. Confirm square/vertical shared assets still preview correctly.

## Regression Checks
- Create in Meta (PAUSED) still works for a fresh build.
- Variant image/video overrides still work.
- Instagram Search placement no longer throws the prior enum error.
