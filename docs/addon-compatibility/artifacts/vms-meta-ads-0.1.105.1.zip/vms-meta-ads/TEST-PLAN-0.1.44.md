# VMS Meta Ads Builder — Test Plan 0.1.44

## Focus
- Budget floor guidance before Meta rejects low spend windows
- Age Min field should allow normal typing/editing
- Meta actions should stay blocked when current schedule averages below about $1/day

## Test 1 — Age Min editing
1. Open Ads Builder.
2. Click into **Age min**.
3. Change `13` or `21` to `30` in one normal edit pass.
4. Confirm the field does **not** snap back while typing.
5. Click elsewhere.
6. Confirm the final value remains valid and stable.

## Test 2 — Budget floor warning appears
1. Choose an Event Plan with a future date far enough out to create a long run window.
2. Enter a very small total budget.
3. Confirm Step E shows a visible warning about the practical `$1.00/day` Meta floor.
4. Confirm the warning clears after either raising budget or shortening the run window enough.

## Test 3 — Meta actions blocked below floor
1. Save a draft while Step E is still below the warning threshold.
2. Confirm one or more Meta-facing buttons are disabled or blocked with an explanation:
   - Create in Meta (PAUSED)
   - Update Existing Meta Ad
   - Sync Budget to Meta
   - Go Live
3. Confirm the message tells the operator to raise budget or shorten the run window.

## Test 4 — Happy path after fixing budget
1. Raise the budget enough to clear the warning.
2. Save Draft.
3. Confirm Meta-facing actions become available again (subject to normal linked-draft/API rules).
4. Run **Update Existing Meta Ad** or **Sync Budget to Meta**.
5. Confirm a normal success or refresh path occurs instead of the prior rejection loop.
