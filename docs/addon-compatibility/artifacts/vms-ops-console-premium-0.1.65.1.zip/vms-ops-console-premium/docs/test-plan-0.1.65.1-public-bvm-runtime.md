# VMS Ops Console Premium 0.1.65.1 Test Plan

- Load with public Backstage Venue Manager 1.2.0 and no active historical VMS plugin.
- Confirm Ops menus/PWA and REST routes register.
- Confirm venue, event-plan, check-in-close, admissions, pass, and BVM admin helpers resolve through public APIs.
- Confirm existing Ops options/tables and PWA business behavior remain unchanged.
