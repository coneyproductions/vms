(function () {
    'use strict';

    var METRICS = {
        estimated_event_net: {
            label: 'Estimated Event Net',
            type: 'currency'
        },
        ticket_revenue: {
            label: 'Total Ticket Revenue',
            type: 'currency'
        },
        tickets_sold: {
            label: 'Total Tickets Sold',
            type: 'count'
        },
        attendance_total: {
            label: 'Total Attendance',
            type: 'count'
        },
        concession_sales: {
            label: 'Concession Sales',
            type: 'currency'
        }
    };

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function formatValue(value, metricKey, currencySymbol) {
        var metric = METRICS[metricKey] || METRICS.estimated_event_net;
        var absValue = Math.abs(Number(value) || 0);

        if (metric.type === 'currency') {
            var sign = Number(value) < 0 ? '-' : '';
            return sign + currencySymbol + absValue.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        return Math.round(Number(value) || 0).toLocaleString();
    }

    function initDetails(portal) {
        portal.querySelectorAll('.vmsip-details-toggle').forEach(function (button) {
            button.addEventListener('click', function () {
                var detailsId = button.getAttribute('aria-controls');
                if (!detailsId) {
                    return;
                }

                var row = document.getElementById(detailsId);
                if (!row) {
                    return;
                }

                var expanded = button.getAttribute('aria-expanded') === 'true';
                var showLabel = button.getAttribute('data-show-label') || 'Show details';
                var hideLabel = button.getAttribute('data-hide-label') || 'Hide details';
                button.setAttribute('aria-expanded', expanded ? 'false' : 'true');
                button.textContent = expanded ? showLabel : hideLabel;
                row.hidden = expanded;
            });
        });
    }

    function buildSvg(payload, metricKey) {
        var svg = payload.svg;
        var records = payload.records;
        var currencySymbol = payload.currencySymbol;
        var legend = payload.legend;
        var summary = payload.summary;
        var metric = METRICS[metricKey] || METRICS.estimated_event_net;

        if (!records.length) {
            svg.innerHTML = '';
            legend.innerHTML = '';
            summary.textContent = 'No completed-event chart data available.';
            return;
        }

        var width = 820;
        var height = 360;
        var padding = {
            top: 24,
            right: 24,
            bottom: 58,
            left: 78
        };
        var chartWidth = width - padding.left - padding.right;
        var chartHeight = height - padding.top - padding.bottom;

        var actualValues = records.map(function (record) {
            var value = record.metrics[metricKey];
            return value === null || value === '' || typeof value === 'undefined' ? null : Number(value);
        });
        var projectedValues = records.map(function (record) {
            var value = record.projected[metricKey];
            return value === null || value === '' || typeof value === 'undefined' ? null : Number(value);
        });
        var actualPoints = actualValues.filter(function (value) {
            return value !== null;
        });
        var projectedPoints = projectedValues.filter(function (value) {
            return value !== null;
        });

        var allValues = actualPoints.slice();
        projectedPoints.forEach(function (value) {
            allValues.push(value);
        });

        if (!allValues.length) {
            svg.innerHTML = '';
            legend.innerHTML = '';
            summary.textContent = 'No completed-event chart data is available for this metric yet.';
            return;
        }

        var minValue = Math.min.apply(null, allValues);
        var maxValue = Math.max.apply(null, allValues);
        var spread = maxValue - minValue;
        var paddingAmount = spread === 0 ? Math.max(Math.abs(maxValue) * 0.15, 1) : spread * 0.12;
        var domainMin = minValue - paddingAmount;
        var domainMax = maxValue + paddingAmount;
        var domainRange = domainMax - domainMin || 1;

        var xStep = records.length > 1 ? chartWidth / (records.length - 1) : 0;
        var labelStep = Math.max(1, Math.ceil(records.length / 6));
        var gridLines = 5;

        function xForIndex(index) {
            return padding.left + (xStep * index);
        }

        function yForValue(value) {
            return padding.top + ((domainMax - value) / domainRange) * chartHeight;
        }

        function buildPath(values) {
            return values.reduce(function (segments, value, index) {
                if (value === null) {
                    return segments;
                }

                var previous = index > 0 ? values[index - 1] : null;
                var prefix = previous === null ? 'M' : 'L';
                segments.push(prefix + xForIndex(index).toFixed(2) + ' ' + yForValue(value).toFixed(2));
                return segments;
            }, []).join(' ');
        }

        var actualPath = buildPath(actualValues);
        var projectedPath = projectedPoints.length ? buildPath(projectedValues) : '';

        var gridMarkup = '';
        for (var i = 0; i < gridLines; i += 1) {
            var ratio = i / (gridLines - 1);
            var gridY = padding.top + (chartHeight * ratio);
            var gridValue = domainMax - (domainRange * ratio);

            gridMarkup += '<line x1="' + padding.left + '" y1="' + gridY.toFixed(2) + '" x2="' + (width - padding.right) + '" y2="' + gridY.toFixed(2) + '" stroke="#d7dee6" stroke-width="1" />';
            gridMarkup += '<text x="' + (padding.left - 12) + '" y="' + (gridY + 4).toFixed(2) + '" text-anchor="end" font-size="12" fill="#516174">' + escapeHtml(formatValue(gridValue, metricKey, currencySymbol)) + '</text>';
        }

        var xAxisMarkup = '';
        records.forEach(function (record, index) {
            if (records.length > 1 && index % labelStep !== 0 && index !== records.length - 1) {
                return;
            }

            xAxisMarkup += '<text x="' + xForIndex(index).toFixed(2) + '" y="' + (height - 18) + '" text-anchor="middle" font-size="12" fill="#516174">' + escapeHtml(record.shortLabel) + '</text>';
        });

        var actualPointsMarkup = records.map(function (record, index) {
            if (actualValues[index] === null) {
                return '';
            }
            var x = xForIndex(index);
            var y = yForValue(actualValues[index]);
            return '<circle cx="' + x.toFixed(2) + '" cy="' + y.toFixed(2) + '" r="4" fill="#244260"><title>' +
                escapeHtml(record.eventTitle + ' (' + record.dateLabel + '): ' + formatValue(actualValues[index], metricKey, currencySymbol)) +
                '</title></circle>';
        }).join('');

        var projectedPointsMarkup = projectedPoints.length ? projectedValues.map(function (value, index) {
            if (value === null) {
                return '';
            }

            var x = xForIndex(index);
            var y = yForValue(value);
            return '<circle cx="' + x.toFixed(2) + '" cy="' + y.toFixed(2) + '" r="3.5" fill="#8a6b1f"><title>' +
                escapeHtml(records[index].eventTitle + ' (' + records[index].dateLabel + '): Projected ' + formatValue(value, metricKey, currencySymbol)) +
                '</title></circle>';
        }).join('') : '';

        svg.setAttribute('aria-label', metric.label + ' across ' + records.length + ' events');
        svg.innerHTML = '' +
            '<rect x="' + padding.left + '" y="' + padding.top + '" width="' + chartWidth + '" height="' + chartHeight + '" fill="#ffffff" stroke="#d7dee6" stroke-width="1" />' +
            gridMarkup +
            (actualPath ? '<path d="' + actualPath + '" fill="none" stroke="#244260" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />' : '') +
            (projectedPath ? '<path d="' + projectedPath + '" fill="none" stroke="#8a6b1f" stroke-width="3" stroke-dasharray="7 6" stroke-linecap="round" stroke-linejoin="round" />' : '') +
            actualPointsMarkup +
            projectedPointsMarkup +
            xAxisMarkup;

        legend.innerHTML = (actualPath ? '<span class="vmsip-chart-legend-item"><span class="vmsip-chart-legend-line"></span>Actual</span>' : '') +
            (projectedPath ? '<span class="vmsip-chart-legend-item"><span class="vmsip-chart-legend-line vmsip-chart-legend-line--projected"></span>Projected</span>' : '');
        summary.textContent = 'Showing ' + metric.label + ' for ' + records.length + ' completed events.';
    }

    function initChart(portal) {
        var dataNode = portal.querySelector('.vmsip-chart-data');
        var svg = portal.querySelector('.vmsip-chart');
        var select = portal.querySelector('.vmsip-chart-select');
        var legend = portal.querySelector('.vmsip-chart-legend');
        var summary = portal.querySelector('.vmsip-chart-summary');

        if (!dataNode || !svg || !select || !legend || !summary) {
            return;
        }

        var parsed;

        try {
            parsed = JSON.parse(dataNode.textContent || '{}');
        } catch (error) {
            summary.textContent = 'Chart data could not be loaded.';
            return;
        }

        var payload = {
            records: Array.isArray(parsed.records) ? parsed.records : [],
            currencySymbol: parsed.currencySymbol || '$',
            svg: svg,
            legend: legend,
            summary: summary
        };

        function render() {
            buildSvg(payload, select.value || 'estimated_event_net');
        }

        select.addEventListener('change', render);
        render();
    }

    function initPortal(portal) {
        initDetails(portal);
        initChart(portal);
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.vmsip-portal').forEach(initPortal);
    });
}());
