# VMS Investor Portal 0.2.3 Test Plan

- Load with public Backstage Venue Manager 1.2.0 and no active historical VMS plugin.
- Confirm the Investor Portal page registers in the public BVM admin registry.
- Confirm event-plan, ticketing, staffing, goals, admissions, and reporting providers resolve through public APIs.
- Confirm existing stored financials and calculated metrics render without changing stored data or permissions.
