<?php

defined('ABSPATH') || exit;

final class VMS_Investor_Portal
{
    public const ROLE_INVESTOR = 'vms_investor';
    public const CAP_VIEW = 'vms_view_investor_portal';
    public const CAP_MANAGE = 'vms_manage_investor_financials';
    public const MENU_SLUG = 'vms-investor-portal';
    public const SHORTCODE = 'vms_investor_portal';
    public const DB_VERSION = '1.3.0';
    public const OPTION_DB_VERSION = 'vms_investor_portal_db_version';
    public const SAVE_ACTION = 'vms_investor_portal_save_financials';
    public const REFRESH_EVENT_ACTION = 'vms_investor_portal_refresh_event';
    public const REFRESH_BATCH_ACTION = 'vms_investor_portal_refresh_batch';
    public const SNAPSHOT_VERSION = '1';
    public const SNAPSHOT_STATUS_FRESH = 'fresh';
    public const SNAPSHOT_STATUS_STALE = 'stale';
    public const SNAPSHOT_STATUS_MISSING = 'missing';
    public const SNAPSHOT_STATUS_ERROR = 'error';

    /** @var self|null */
    private static $instance = null;

    /** @var array<int,array<string,mixed>> */
    private $event_context_cache = array();

    /** @var array<string,array<string,mixed>> */
    private $ticket_actuals_cache = array();

    /** @var array<string,array<string,mixed>> */
    private $attendance_actuals_cache = array();

    /** @var array<string,array<string,mixed>> */
    private $metrics_snapshot_payload_cache = array();

    /** @var string */
    private $refresh_guard_reserved_memory = '';

    /** @var array<string,mixed>|null */
    private $refresh_shutdown_guard = null;

    public static function instance(): self
    {
        if (!(self::$instance instanceof self)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public static function activate(): void
    {
        self::install_schema();
        self::ensure_roles_and_caps();
    }

    private function metrics_provider(): VMS_Investor_Metrics_Provider
    {
        return VMS_Investor_Metrics_Provider::instance();
    }

    private function __construct()
    {
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('plugins_loaded', array($this, 'maybe_upgrade_database'));
        add_action('plugins_loaded', array($this, 'maybe_sync_roles_and_caps'));
        add_action('init', array($this, 'register_shortcode'));
        add_action('admin_init', array($this, 'redirect_investors_from_admin'));
        add_action('admin_menu', array($this, 'register_admin_menu_fallback'), 99);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('vms_admin_register_pages', array($this, 'register_vms_admin_page'), 30);
        add_action('admin_post_' . self::SAVE_ACTION, array($this, 'handle_admin_save'));
        add_action('admin_post_' . self::REFRESH_EVENT_ACTION, array($this, 'handle_refresh_event'));
        add_action('admin_post_' . self::REFRESH_BATCH_ACTION, array($this, 'handle_refresh_batch'));
        add_filter('show_admin_bar', array($this, 'maybe_hide_admin_bar'));
    }

    public function load_textdomain(): void
    {
        load_plugin_textdomain(
            'vms-investor-portal',
            false,
            dirname(plugin_basename(VMS_INVESTOR_PORTAL_FILE)) . '/languages'
        );
    }

    public function maybe_upgrade_database(): void
    {
        $installed_version = (string) get_option(self::OPTION_DB_VERSION, '');

        if ($installed_version !== self::DB_VERSION) {
            self::install_schema();
        }
    }

    public function maybe_sync_roles_and_caps(): void
    {
        $investor_role = get_role(self::ROLE_INVESTOR);
        $admin_role = get_role('administrator');
        $needs_sync = false;

        if (!$investor_role || !$investor_role->has_cap(self::CAP_VIEW) || !$investor_role->has_cap('read')) {
            $needs_sync = true;
        }

        if (!$admin_role || !$admin_role->has_cap(self::CAP_MANAGE)) {
            $needs_sync = true;
        }

        if ($needs_sync) {
            self::ensure_roles_and_caps();
        }
    }

    public function register_shortcode(): void
    {
        add_shortcode(self::SHORTCODE, array($this, 'render_shortcode'));
    }

    public function maybe_hide_admin_bar(bool $show): bool
    {
        if ($this->is_investor_only_user()) {
            return false;
        }

        return $show;
    }

    public function redirect_investors_from_admin(): void
    {
        if (!is_admin() || !$this->is_investor_only_user()) {
            return;
        }

        if (wp_doing_ajax()) {
            return;
        }

        $script_name = isset($_SERVER['PHP_SELF']) ? wp_basename((string) wp_unslash($_SERVER['PHP_SELF'])) : '';

        if (in_array($script_name, array('admin-ajax.php', 'async-upload.php', 'admin-post.php'), true)) {
            return;
        }

        wp_safe_redirect($this->get_portal_page_url());
        exit;
    }

    public function register_vms_admin_page(): void
    {
        if (!vms_investor_has_core_function('vms_register_admin_page')) {
            return;
        }

        vms_investor_call_core_function('vms_register_admin_page', array(
            'id' => self::MENU_SLUG,
            'slug' => self::MENU_SLUG,
            'page_title' => __('Investor Financials', 'vms-investor-portal'),
            'menu_title' => __('Investor Portal', 'vms-investor-portal'),
            'capability' => self::CAP_MANAGE,
            'callback' => array($this, 'render_admin_page'),
            'section' => 'reports_finance',
            'order' => 45,
            'source' => 'vms-investor-portal',
            'description' => __('Investor-facing event actuals, overrides, and projections.', 'vms-investor-portal'),
            'register' => true,
        ));
    }

    public function register_admin_menu_fallback(): void
    {
        if ($this->has_vms_parent_menu()) {
            if (vms_investor_has_core_function('vms_register_admin_page')) {
                return;
            }

            add_submenu_page(
                $this->get_vms_parent_slug(),
                __('Investor Financials', 'vms-investor-portal'),
                __('Investor Portal', 'vms-investor-portal'),
                self::CAP_MANAGE,
                self::MENU_SLUG,
                array($this, 'render_admin_page')
            );

            return;
        }

        add_menu_page(
            __('Investor Financials', 'vms-investor-portal'),
            __('Investor Portal', 'vms-investor-portal'),
            self::CAP_MANAGE,
            self::MENU_SLUG,
            array($this, 'render_admin_page'),
            'dashicons-chart-area',
            58
        );
    }

    public function enqueue_admin_assets(string $hook_suffix): void
    {
        unset($hook_suffix);

        $page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';

        if ($page !== self::MENU_SLUG) {
            return;
        }

        $this->register_style();
        wp_enqueue_style('vms-investor-portal');
    }

    public function handle_admin_save(): void
    {
        if (!current_user_can(self::CAP_MANAGE)) {
            wp_die(esc_html__('You do not have permission to update investor financials.', 'vms-investor-portal'));
        }

        check_admin_referer(self::SAVE_ACTION, 'vms_investor_portal_nonce');

        $display_event_id = isset($_POST['event_id']) ? absint(wp_unslash($_POST['event_id'])) : 0;
        $view = $this->normalize_admin_view($_POST['vmsip_view'] ?? 'recent_past');
        $post = $display_event_id > 0 ? get_post($display_event_id) : null;

        if (!$post instanceof WP_Post) {
            wp_safe_redirect($this->get_admin_page_url(array(
                'vmsip_error' => 'invalid_event',
                'vmsip_view' => $view,
            )));
            exit;
        }

        $context = $this->get_event_context($post);
        $existing = $this->get_financial_record_for_context($context);
        $stored_event_id = $existing ? (int) $existing['event_id'] : $display_event_id;
        $now = current_time('mysql');

        $ticket_revenue_override = $this->sanitize_decimal_input($_POST['ticket_revenue_override'] ?? '', true);
        $tickets_sold_override = $this->sanitize_integer_input($_POST['tickets_sold_override'] ?? '', true);
        $attendance_total_override = $this->sanitize_integer_input($_POST['attendance_total_override'] ?? '', true);
        $concession_sales_override = $this->sanitize_decimal_input($_POST['concession_sales_override'] ?? ($_POST['concession_sales'] ?? ''), true);
        $labor_cost_override = $this->sanitize_decimal_input($_POST['labor_cost_override'] ?? ($_POST['labor_cost'] ?? ''), true);
        $concession_cost_override = $this->sanitize_decimal_input($_POST['concession_cost_override'] ?? ($_POST['concession_cost'] ?? ''), true);
        $ad_spend_override = $this->sanitize_decimal_input($_POST['ad_spend_override'] ?? ($_POST['ad_spend'] ?? ''), true);
        $performer_cost_override = $this->sanitize_decimal_input($_POST['performer_cost_override'] ?? ($_POST['performer_cost'] ?? ''), true);
        $other_expenses_override = $this->sanitize_decimal_input($_POST['other_expenses_override'] ?? ($_POST['other_expenses'] ?? ''), true);
        $estimated_tax_override = $this->sanitize_decimal_input($_POST['estimated_tax_override'] ?? '', true);
        $estimated_event_net_override = $this->sanitize_decimal_input($_POST['estimated_event_net_override'] ?? '', true);

        $data = array(
            'event_id' => $stored_event_id,
            'ticket_revenue' => null !== $ticket_revenue_override ? $ticket_revenue_override : '0.00',
            'tickets_sold' => null !== $tickets_sold_override ? $tickets_sold_override : 0,
            'attendance_total' => null !== $attendance_total_override ? $attendance_total_override : 0,
            'ticket_revenue_override' => $ticket_revenue_override,
            'tickets_sold_override' => $tickets_sold_override,
            'attendance_total_override' => $attendance_total_override,
            'ticket_revenue_source' => $existing ? sanitize_text_field((string) ($existing['ticket_revenue_source'] ?? '')) : '',
            'tickets_sold_source' => $existing ? sanitize_text_field((string) ($existing['tickets_sold_source'] ?? '')) : '',
            'attendance_source' => $existing ? sanitize_text_field((string) ($existing['attendance_source'] ?? '')) : '',
            'concession_sales' => null !== $concession_sales_override ? $concession_sales_override : '0.00',
            'labor_cost' => null !== $labor_cost_override ? $labor_cost_override : '0.00',
            'concession_cost' => null !== $concession_cost_override ? $concession_cost_override : '0.00',
            'ad_spend' => null !== $ad_spend_override ? $ad_spend_override : '0.00',
            'performer_cost' => null !== $performer_cost_override ? $performer_cost_override : '0.00',
            'other_expenses' => null !== $other_expenses_override ? $other_expenses_override : '0.00',
            'concession_sales_override' => $concession_sales_override,
            'labor_cost_override' => $labor_cost_override,
            'concession_cost_override' => $concession_cost_override,
            'ad_spend_override' => $ad_spend_override,
            'performer_cost_override' => $performer_cost_override,
            'other_expenses_override' => $other_expenses_override,
            'estimated_tax_override' => $estimated_tax_override,
            'estimated_event_net_override' => $estimated_event_net_override,
            'notes' => sanitize_textarea_field(wp_unslash($_POST['notes'] ?? '')),
            'projected_ticket_revenue' => $this->sanitize_decimal_input($_POST['projected_ticket_revenue'] ?? '', true),
            'projected_tickets_sold' => $this->sanitize_integer_input($_POST['projected_tickets_sold'] ?? '', true),
            'projected_attendance_total' => $this->sanitize_integer_input($_POST['projected_attendance_total'] ?? '', true),
            'projected_concession_sales' => $this->sanitize_decimal_input($_POST['projected_concession_sales'] ?? '', true),
            'projected_event_net' => $this->sanitize_decimal_input($_POST['projected_event_net'] ?? '', true),
            'projection_notes' => sanitize_textarea_field(wp_unslash($_POST['projection_notes'] ?? '')),
            'updated_by' => get_current_user_id(),
            'updated_at' => $now,
        );

        global $wpdb;

        $formats = array(
            '%d',
            '%s',
            '%d',
            '%d',
            '%s',
            '%d',
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%d',
            '%d',
            '%s',
            '%s',
            '%s',
            '%d',
            '%s',
        );

        if ($existing) {
            $wpdb->update(
                $this->table_name(),
                $data,
                array('event_id' => $stored_event_id),
                $formats,
                array('%d')
            );
        } else {
            $data['created_at'] = $now;
            $wpdb->insert(
                $this->table_name(),
                $data,
                array_merge($formats, array('%s'))
            );
        }

        wp_safe_redirect($this->get_admin_page_url(array(
            'vmsip_updated' => 1,
            'vmsip_view' => $view,
            'event_id' => $display_event_id,
        )));
        exit;
    }

    public function handle_refresh_event(): void
    {
        if (!current_user_can(self::CAP_MANAGE)) {
            wp_die(esc_html__('You do not have permission to refresh investor metrics.', 'vms-investor-portal'));
        }

        $display_event_id = isset($_POST['event_id']) ? absint(wp_unslash($_POST['event_id'])) : 0;
        $view = $this->normalize_admin_view($_POST['vmsip_view'] ?? 'recent_past');
        check_admin_referer(self::REFRESH_EVENT_ACTION . ':' . $display_event_id, 'vms_investor_portal_refresh_nonce');

        if (!$this->refresh_actions_enabled()) {
            $this->store_refresh_feedback(array(
                'scope' => 'event',
                'success_count' => 0,
                'error_count' => 1,
                'successes' => array(),
                'errors' => array(array(
                    'event_id' => $display_event_id,
                    'event_title' => __('Refresh disabled', 'vms-investor-portal'),
                    'message' => $this->refresh_actions_disabled_message(),
                )),
            ));
            wp_safe_redirect($this->get_admin_page_url(array(
                'vmsip_view' => $view,
                'event_id' => $display_event_id,
                'vmsip_refresh_result' => 'event',
                'vmsip_refresh_count' => 0,
                'vmsip_refresh_errors' => 1,
            )));
            exit;
        }

        wp_raise_memory_limit('admin');
        $this->register_refresh_shutdown_guard('event', $view, $display_event_id);

        $post = $display_event_id > 0 ? get_post($display_event_id) : null;
        if (!$post instanceof WP_Post) {
            $this->clear_refresh_shutdown_guard();
            wp_safe_redirect($this->get_admin_page_url(array(
                'vmsip_error' => 'invalid_event',
                'vmsip_view' => $view,
            )));
            exit;
        }

        $context = $this->get_event_context($post);
        $existing = $this->get_financial_record_for_context($context);
        $result = $this->refresh_metrics_snapshot_for_post($post, $context, $existing);
        $success = !empty($result['success']);

        $this->store_refresh_feedback(array(
            'scope' => 'event',
            'success_count' => $success ? 1 : 0,
            'error_count' => $success ? 0 : 1,
            'successes' => $success ? array($this->build_refresh_feedback_item($post, $result, true)) : array(),
            'errors' => $success ? array() : array($this->build_refresh_feedback_item($post, $result, false)),
        ));

        $this->clear_refresh_shutdown_guard();
        wp_safe_redirect($this->get_admin_page_url(array(
            'vmsip_view' => $view,
            'event_id' => $display_event_id,
            'vmsip_refresh_result' => 'event',
            'vmsip_refresh_count' => $success ? 1 : 0,
            'vmsip_refresh_errors' => $success ? 0 : 1,
        )));
        exit;
    }

    public function handle_refresh_batch(): void
    {
        if (!current_user_can(self::CAP_MANAGE)) {
            wp_die(esc_html__('You do not have permission to refresh investor metrics.', 'vms-investor-portal'));
        }

        $view = $this->normalize_admin_view($_POST['vmsip_view'] ?? 'recent_past');
        $scope = $this->normalize_refresh_scope($_POST['refresh_scope'] ?? 'visible');
        check_admin_referer(self::REFRESH_BATCH_ACTION . ':' . $scope . ':' . $view, 'vms_investor_portal_refresh_batch_nonce');

        if (!$this->refresh_actions_enabled()) {
            $this->store_refresh_feedback(array(
                'scope' => $scope,
                'success_count' => 0,
                'error_count' => 1,
                'successes' => array(),
                'errors' => array(array(
                    'event_id' => 0,
                    'event_title' => __('Refresh disabled', 'vms-investor-portal'),
                    'message' => $this->refresh_actions_disabled_message(),
                )),
            ));
            wp_safe_redirect($this->get_admin_page_url(array(
                'vmsip_view' => $view,
                'vmsip_refresh_result' => $scope,
                'vmsip_refresh_count' => 0,
                'vmsip_refresh_errors' => 1,
            )));
            exit;
        }

        if (function_exists('set_time_limit')) {
            @set_time_limit(0);
        }
        wp_raise_memory_limit('admin');
        $this->register_refresh_shutdown_guard($scope, $view, 0);

        if ($scope === 'recent_completed') {
            $entries = array_slice($this->get_admin_events('recent_past'), 0, $this->snapshot_recent_refresh_limit());
        } else {
            $entries = array_slice($this->get_admin_events($view), 0, $this->snapshot_visible_refresh_limit());
        }

        $success_count = 0;
        $error_count = 0;
        $successes = array();
        $errors = array();

        foreach ($entries as $entry) {
            $post = $entry['post'];
            $context = $entry['context'];

            if (!($post instanceof WP_Post) || !is_array($context)) {
                $error_count++;
                $errors[] = array(
                    'event_id' => isset($entry['event_id']) ? absint($entry['event_id']) : 0,
                    'event_title' => __('Unknown event', 'vms-investor-portal'),
                    'message' => __('This event could not be refreshed because its context was invalid.', 'vms-investor-portal'),
                );
                continue;
            }

            try {
                $existing = $this->get_financial_record_for_context($context);
                $result = $this->refresh_metrics_snapshot_for_post($post, $context, $existing);
            } catch (Throwable $exception) {
                $error_count++;
                $errors[] = array(
                    'event_id' => (int) $post->ID,
                    'event_title' => $this->refresh_feedback_event_title($post),
                    'message' => $this->refresh_feedback_message(array($exception->getMessage()), false),
                );
                continue;
            }

            if (!empty($result['success'])) {
                $success_count++;
                $successes[] = $this->build_refresh_feedback_item($post, $result, true);
            } else {
                $error_count++;
                $errors[] = $this->build_refresh_feedback_item($post, $result, false);
            }
        }

        $this->store_refresh_feedback(array(
            'scope' => $scope,
            'success_count' => $success_count,
            'error_count' => $error_count,
            'successes' => $successes,
            'errors' => $errors,
        ));

        $this->clear_refresh_shutdown_guard();
        wp_safe_redirect($this->get_admin_page_url(array(
            'vmsip_view' => $view,
            'vmsip_refresh_result' => $scope,
            'vmsip_refresh_count' => $success_count,
            'vmsip_refresh_errors' => $error_count,
        )));
        exit;
    }

    public function render_admin_page(): void
    {
        if (!current_user_can(self::CAP_MANAGE)) {
            wp_die(esc_html__('You do not have permission to manage investor financials.', 'vms-investor-portal'));
        }

        $view = $this->normalize_admin_view($_GET['vmsip_view'] ?? 'recent_past');
        $events = $this->get_admin_events($view);
        $records_map = $this->get_financial_records_map();
        $updated = isset($_GET['vmsip_updated']) ? absint(wp_unslash($_GET['vmsip_updated'])) : 0;
        $error = isset($_GET['vmsip_error']) ? sanitize_key((string) wp_unslash($_GET['vmsip_error'])) : '';
        $refresh_result = isset($_GET['vmsip_refresh_result']) ? sanitize_key((string) wp_unslash($_GET['vmsip_refresh_result'])) : '';
        $refresh_count = isset($_GET['vmsip_refresh_count']) ? absint(wp_unslash($_GET['vmsip_refresh_count'])) : 0;
        $refresh_errors = isset($_GET['vmsip_refresh_errors']) ? absint(wp_unslash($_GET['vmsip_refresh_errors'])) : 0;
        $refresh_feedback = $this->consume_refresh_feedback();

        echo '<div class="wrap vmsip-admin">';
        echo '<h1>' . esc_html__('Investor Financials', 'vms-investor-portal') . '</h1>';
        echo '<p>' . esc_html__('Auto actuals prefer the VMS/Data Tools reporting model so total ticket revenue and total tickets sold can include both advance and door activity. Checked in / scanned is shown separately and does not replace Total Attendance.', 'vms-investor-portal') . '</p>';

        if ($updated) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Investor financials updated.', 'vms-investor-portal') . '</p></div>';
        } elseif (is_array($refresh_feedback)) {
            $this->render_refresh_feedback_notice($refresh_feedback);
        } elseif ($refresh_result !== '') {
            $refresh_message = $refresh_errors > 0
                ? sprintf(
                    /* translators: 1: refreshed count, 2: error count */
                    __('Metrics refresh finished. %1$s event(s) refreshed, %2$s error(s).', 'vms-investor-portal'),
                    number_format_i18n($refresh_count),
                    number_format_i18n($refresh_errors)
                )
                : sprintf(
                    /* translators: %s: refreshed count */
                    __('Metrics refresh finished. %s event(s) refreshed.', 'vms-investor-portal'),
                    number_format_i18n($refresh_count)
                );
            echo '<div class="notice ' . esc_attr($refresh_errors > 0 ? 'notice-warning' : 'notice-success') . ' is-dismissible"><p>' . esc_html($refresh_message) . '</p></div>';
        } elseif ($error === 'invalid_event') {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('The selected event could not be saved.', 'vms-investor-portal') . '</p></div>';
        }

        $this->render_admin_view_tabs($view);

        if (empty($events)) {
            echo '<div class="notice notice-warning"><p>' . esc_html__('No reportable events were found for this view. Adjust the event post type or reportable-event filters if your event records live somewhere else.', 'vms-investor-portal') . '</p></div>';
            echo '</div>';
            return;
        }

        $this->render_admin_refresh_toolbar($view);
        echo '<div class="vmsip-admin-list">';

        foreach ($events as $entry) {
            $post = $entry['post'];
            $context = $entry['context'];

            if (!($post instanceof WP_Post) || !is_array($context)) {
                continue;
            }

            $record = $this->get_financial_record_for_context($context, $records_map);
            if (!$record) {
                $record = $this->default_record((int) $post->ID);
            }

            $display = $this->build_display_record($post, $record, $context);
            $metrics = isset($display['metrics']) && is_array($display['metrics']) ? $display['metrics'] : array();
            $edit_link = get_edit_post_link((int) $post->ID, '');

            echo '<section class="vmsip-admin-card">';
            echo '<header class="vmsip-admin-card__header">';
            echo '<div>';
            echo '<h2>' . esc_html($display['event_title']) . '</h2>';
            echo '<p class="vmsip-admin-card__meta">';
            echo esc_html($display['event_date_label']);
            if ($display['event_end_label'] !== '' && $display['event_end_label'] !== $display['event_date_label']) {
                echo ' <span class="vmsip-admin-card__separator">|</span> ';
                echo esc_html(sprintf(__('Ends %s', 'vms-investor-portal'), $display['event_end_label']));
            }
            echo ' <span class="vmsip-admin-card__separator">|</span> ';
            echo '<code>#' . esc_html((string) $display['event_id']) . '</code>';
            echo ' <span class="vmsip-admin-card__separator">|</span> ';
            echo esc_html($display['post_type_label']);
            echo ' <span class="vmsip-admin-card__separator">|</span> ';
            echo esc_html($display['event_status_label']);
            echo '</p>';
            echo '</div>';

            echo '<div class="vmsip-admin-card__actions">';
            echo '<div class="vmsip-admin-net-preview">' . $this->format_metric_net_badge($display['metrics']['estimated_event_net'] ?? array()) . '</div>';
            $this->render_admin_refresh_event_form((int) $display['event_id'], $view);
            if ($edit_link) {
                echo '<p><a class="button button-secondary" href="' . esc_url($edit_link) . '">' . esc_html__('Edit Event', 'vms-investor-portal') . '</a></p>';
            }
            echo '</div>';
            echo '</header>';

            if ($display['snapshot_status_notice'] !== '') {
                echo '<p class="vmsip-source-note">' . esc_html($display['snapshot_status_notice']) . '</p>';
            }

            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field(self::SAVE_ACTION, 'vms_investor_portal_nonce');
            echo '<input type="hidden" name="action" value="' . esc_attr(self::SAVE_ACTION) . '">';
            echo '<input type="hidden" name="event_id" value="' . esc_attr((string) $display['event_id']) . '">';
            echo '<input type="hidden" name="vmsip_view" value="' . esc_attr($view) . '">';

            echo '<section class="vmsip-admin-section">';
            echo '<h3>' . esc_html__('Auto Actuals and Overrides', 'vms-investor-portal') . '</h3>';
            echo '<div class="vmsip-admin-auto-grid">';
            $this->render_admin_metric_from_payload($metrics['ticket_revenue'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'ticket_revenue_override',
                'override_value' => $record['ticket_revenue_override'],
            ));
            $this->render_admin_metric_from_payload($metrics['tickets_sold'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'tickets_sold_override',
                'override_value' => $record['tickets_sold_override'],
            ));
            $this->render_admin_metric_from_payload($metrics['attendance_total'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'attendance_total_override',
                'override_value' => $record['attendance_total_override'],
            ));
            $this->render_admin_metric_from_payload($metrics['checked_in_scanned'] ?? array(), (int) $display['event_id'], array(
                'readonly' => true,
                'hide_display_source' => true,
                'help_text' => __('Informational only. Checked-in scans do not replace Total Attendance.', 'vms-investor-portal'),
            ));
            $this->render_admin_metric_from_payload($metrics['concession_sales'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'concession_sales_override',
                'override_value' => $record['concession_sales_override'],
            ));
            $this->render_admin_metric_from_payload($metrics['labor_cost'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'labor_cost_override',
                'override_value' => $record['labor_cost_override'],
            ));
            $this->render_admin_metric_from_payload($metrics['concession_cost'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'concession_cost_override',
                'override_value' => $record['concession_cost_override'],
            ));
            $this->render_admin_metric_from_payload($metrics['ad_spend'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'ad_spend_override',
                'override_value' => $record['ad_spend_override'],
            ));
            $this->render_admin_metric_from_payload($metrics['performer_cost'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'performer_cost_override',
                'override_value' => $record['performer_cost_override'],
            ));
            $this->render_admin_metric_from_payload($metrics['other_expenses'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'other_expenses_override',
                'override_value' => $record['other_expenses_override'],
            ));
            $this->render_admin_metric_from_payload($metrics['estimated_sales_tax'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'estimated_tax_override',
                'override_value' => $record['estimated_tax_override'],
                'help_text' => __('Based on VMS/Square sales records. For internal review only. Do not use this figure for state sales tax filing.', 'vms-investor-portal'),
            ));
            $this->render_admin_metric_from_payload($metrics['estimated_event_net'] ?? array(), (int) $display['event_id'], array(
                'field_name' => 'estimated_event_net_override',
                'override_value' => $record['estimated_event_net_override'],
            ));
            echo '</div>';
            echo '</section>';

            echo '<section class="vmsip-admin-section">';
            echo '<h3>' . esc_html__('Read-only Source Metrics', 'vms-investor-portal') . '</h3>';
            echo '<div class="vmsip-admin-auto-grid">';
            $this->render_admin_metric_from_payload($metrics['online_ticket_sales'] ?? array(), (int) $display['event_id'], array('readonly' => true));
            $this->render_admin_metric_from_payload($metrics['door_ticket_sales'] ?? array(), (int) $display['event_id'], array('readonly' => true));
            $this->render_admin_metric_from_payload($metrics['online_tickets_sold'] ?? array(), (int) $display['event_id'], array('readonly' => true));
            $this->render_admin_metric_from_payload($metrics['door_tickets_sold'] ?? array(), (int) $display['event_id'], array('readonly' => true));
            $this->render_admin_metric_from_payload($metrics['website_addons'] ?? array(), (int) $display['event_id'], array('readonly' => true));
            $this->render_admin_metric_from_payload($metrics['bar_sales'] ?? array(), (int) $display['event_id'], array('readonly' => true));
            $this->render_admin_metric_from_payload($metrics['food_sales'] ?? array(), (int) $display['event_id'], array('readonly' => true));
            $this->render_admin_metric_from_payload($metrics['merch_sales'] ?? array(), (int) $display['event_id'], array('readonly' => true));
            $this->render_admin_metric_from_payload($metrics['other_direct_costs'] ?? array(), (int) $display['event_id'], array('readonly' => true));
            echo '</div>';
            echo '</section>';

            echo '<section class="vmsip-admin-section">';
            echo '<h3>' . esc_html__('Notes', 'vms-investor-portal') . '</h3>';
            echo '<div class="vmsip-admin-field vmsip-admin-field--full">';
            echo '<label for="vmsip-notes-' . esc_attr((string) $display['event_id']) . '">' . esc_html__('Notes', 'vms-investor-portal') . '</label>';
            echo '<textarea id="vmsip-notes-' . esc_attr((string) $display['event_id']) . '" name="notes" rows="4">' . esc_textarea((string) $record['notes']) . '</textarea>';
            echo '</div>';
            echo '</section>';

            echo '<details class="vmsip-admin-diagnostics">';
            echo '<summary>' . esc_html__('Metric Diagnostics', 'vms-investor-portal') . '</summary>';
            echo '<p class="description">' . esc_html__('Each displayed number below lists its auto source, manual override state, and any warnings returned by the provider chain.', 'vms-investor-portal') . '</p>';
            $this->render_admin_diagnostics_panel($metrics, array(
                'snapshot_status_label' => (string) $display['snapshot_status_label'],
                'snapshot_source_label' => (string) $display['snapshot_source_label'],
                'snapshot_last_refreshed_label' => (string) $display['snapshot_last_refreshed_label'],
                'snapshot_notice' => (string) $display['snapshot_status_notice'],
                'snapshot_warnings' => (array) $display['snapshot_warnings'],
                'snapshot_last_error' => (string) $display['snapshot_last_error'],
            ));
            echo '</details>';

            echo '<details class="vmsip-admin-projection"' . ($display['has_projection'] ? ' open' : '') . '>';
            echo '<summary>' . esc_html__('Projection / Estimate', 'vms-investor-portal') . '</summary>';
            echo '<p class="description">' . esc_html__('Projected values are optional. Keep them clearly separated from actual results.', 'vms-investor-portal') . '</p>';
            echo '<div class="vmsip-admin-grid">';
            $this->render_admin_currency_field('projected_ticket_revenue', __('Projected Total Ticket Revenue', 'vms-investor-portal'), $record['projected_ticket_revenue'], true, (int) $display['event_id']);
            $this->render_admin_integer_field('projected_tickets_sold', __('Projected Total Tickets Sold', 'vms-investor-portal'), $record['projected_tickets_sold'], true, (int) $display['event_id']);
            $this->render_admin_integer_field('projected_attendance_total', __('Projected Total Attendance', 'vms-investor-portal'), $record['projected_attendance_total'], true, (int) $display['event_id']);
            $this->render_admin_currency_field('projected_concession_sales', __('Projected Concession Sales', 'vms-investor-portal'), $record['projected_concession_sales'], true, (int) $display['event_id']);
            $this->render_admin_currency_field('projected_event_net', __('Projected Event Net', 'vms-investor-portal'), $record['projected_event_net'], true, (int) $display['event_id']);
            echo '</div>';
            echo '<div class="vmsip-admin-field vmsip-admin-field--full">';
            echo '<label for="vmsip-projection-notes-' . esc_attr((string) $display['event_id']) . '">' . esc_html__('Projection Notes', 'vms-investor-portal') . '</label>';
            echo '<textarea id="vmsip-projection-notes-' . esc_attr((string) $display['event_id']) . '" name="projection_notes" rows="3">' . esc_textarea((string) $record['projection_notes']) . '</textarea>';
            echo '</div>';
            echo '</details>';

            echo '<div class="vmsip-admin-actions">';
            echo '<button type="submit" class="button button-primary">' . esc_html__('Save Financials', 'vms-investor-portal') . '</button>';
            echo '</div>';
            echo '</form>';
            echo '</section>';
        }

        echo '</div>';
        echo '</div>';
    }

    public function render_shortcode(array $atts = array(), string $content = '', string $tag = ''): string
    {
        unset($atts, $content, $tag);

        $this->register_style();
        wp_enqueue_style('vms-investor-portal');

        if (!is_user_logged_in()) {
            $login_url = wp_login_url($this->current_request_url());

            return sprintf(
                '<div class="vmsip-portal vmsip-portal--message"><p>%s <a href="%s">%s</a></p></div>',
                esc_html__('You must be logged in to view the investor portal.', 'vms-investor-portal'),
                esc_url($login_url),
                esc_html__('Log in', 'vms-investor-portal')
            );
        }

        if (!current_user_can(self::CAP_VIEW) && !current_user_can('manage_options')) {
            return '<div class="vmsip-portal vmsip-portal--message"><p>' . esc_html__('Access denied. Your account is not approved for the investor portal.', 'vms-investor-portal') . '</p></div>';
        }

        $records_map = $this->get_financial_records_map();
        $past_records = $this->build_records_from_entries($this->get_frontend_events('past'), $records_map, 'desc');
        $upcoming_records = $this->build_records_from_entries($this->get_frontend_events('upcoming'), $records_map, 'asc');
        $spotlight = !empty($past_records) ? $past_records[0] : null;
        $has_any_projection = $this->records_have_projection(array_merge($past_records, $upcoming_records));

        $this->register_script();
        wp_enqueue_script('vms-investor-portal');

        $portal_instance = wp_unique_id('vmsip-');
        $chart_title_id = $portal_instance . '-chart-title';
        $metric_select_id = $portal_instance . '-metric';
        $chart_records = $past_records;
        usort($chart_records, array($this, 'sort_display_records_ascending'));

        $chart_payload = array();
        foreach ($chart_records as $record) {
            $record_metrics = isset($record['metrics']) && is_array($record['metrics']) ? $record['metrics'] : array();
            $chart_payload[] = array(
                'eventId' => (int) $record['event_id'],
                'eventTitle' => (string) $record['event_title'],
                'dateLabel' => (string) $record['event_date_label'],
                'shortLabel' => (string) $record['event_short_label'],
                'metrics' => array(
                    'estimated_event_net' => !empty($record_metrics['estimated_event_net']['available']) ? (float) ($record_metrics['estimated_event_net']['value'] ?? 0.0) : null,
                    'ticket_revenue' => !empty($record_metrics['ticket_revenue']['available']) ? (float) ($record_metrics['ticket_revenue']['value'] ?? 0.0) : null,
                    'tickets_sold' => !empty($record_metrics['tickets_sold']['available']) ? (int) ($record_metrics['tickets_sold']['value'] ?? 0) : null,
                    'attendance_total' => !empty($record_metrics['attendance_total']['available']) ? (int) ($record_metrics['attendance_total']['value'] ?? 0) : null,
                    'concession_sales' => !empty($record_metrics['concession_sales']['available']) ? (float) ($record_metrics['concession_sales']['value'] ?? 0.0) : null,
                ),
                'projected' => array(
                    'estimated_event_net' => $record['projected_event_net'],
                    'ticket_revenue' => $record['projected_ticket_revenue'],
                    'tickets_sold' => $record['projected_tickets_sold'],
                    'attendance_total' => $record['projected_attendance_total'],
                    'concession_sales' => $record['projected_concession_sales'],
                ),
            );
        }

        ob_start();

        echo '<section class="vmsip-portal">';
        echo '<header class="vmsip-portal__header">';
        echo '<h2>' . esc_html__('Investor Portal', 'vms-investor-portal') . '</h2>';
        echo '<p>' . esc_html__('Event Performance Summary', 'vms-investor-portal') . '</p>';
        echo '<p class="vmsip-portal__intro">' . esc_html__('Actuals shown where available. Manual estimates may be included for expenses not tracked by VMS.', 'vms-investor-portal') . '</p>';
        echo '<p class="vmsip-portal__intro">' . esc_html__('Total ticket revenue and total tickets sold use the venue reporting model when available so advance and door activity stay combined. Checked-in scans are shown separately from total attendance.', 'vms-investor-portal') . '</p>';
        echo '</header>';

        if (empty($past_records) && empty($upcoming_records)) {
            echo '<div class="vmsip-empty"><p>' . esc_html__('No reportable event data is available yet.', 'vms-investor-portal') . '</p></div>';
            echo '</section>';
            return (string) ob_get_clean();
        }

        if (is_array($spotlight)) {
            $spotlight_metrics = isset($spotlight['metrics']) && is_array($spotlight['metrics']) ? $spotlight['metrics'] : array();
            echo '<section class="vmsip-spotlight">';
            echo '<div class="vmsip-section-head">';
            echo '<h3>' . esc_html__('Most Recent Completed Show', 'vms-investor-portal') . '</h3>';
            echo '<p>' . esc_html($spotlight['event_date_label']) . ' <span class="vmsip-section-separator">|</span> ' . esc_html($spotlight['event_title']) . '</p>';
            echo '</div>';
            echo '<div class="vmsip-spotlight__grid">';
            $this->render_frontend_metric_card(
                __('Estimated Event Net', 'vms-investor-portal'),
                $this->format_metric_display_value($spotlight_metrics['estimated_event_net'] ?? array()),
                !empty($spotlight_metrics['estimated_event_net']['available']) && ((float) ($spotlight_metrics['estimated_event_net']['value'] ?? 0.0) < 0) ? 'negative' : (!empty($spotlight_metrics['estimated_event_net']['available']) ? 'positive' : '')
            );
            $this->render_frontend_metric_card(__('Total Ticket Revenue', 'vms-investor-portal'), $this->format_metric_display_value($spotlight_metrics['ticket_revenue'] ?? array()));
            $this->render_frontend_metric_card(__('Total Tickets Sold', 'vms-investor-portal'), $this->format_metric_display_value($spotlight_metrics['tickets_sold'] ?? array()));
            $this->render_frontend_metric_card(__('Total Attendance', 'vms-investor-portal'), $this->format_metric_display_value($spotlight_metrics['attendance_total'] ?? array()));
            $this->render_frontend_metric_card(__('Concession / On-site Sales', 'vms-investor-portal'), $this->format_metric_display_value($spotlight_metrics['concession_sales'] ?? array()));
            echo '</div>';
            echo '<p class="vmsip-source-note">' . esc_html($this->build_source_note($spotlight)) . '</p>';
            if ($spotlight['snapshot_status_notice'] !== '') {
                echo '<p class="vmsip-source-note">' . esc_html($spotlight['snapshot_status_notice']) . '</p>';
            }
            echo '</section>';
        }

        if (!empty($past_records)) {
            echo '<section class="vmsip-chart-panel" aria-labelledby="' . esc_attr($chart_title_id) . '">';
            echo '<div class="vmsip-chart-panel__header">';
            echo '<div>';
            echo '<h3 id="' . esc_attr($chart_title_id) . '">' . esc_html__('Event Performance Over Time', 'vms-investor-portal') . '</h3>';
            echo '<p class="vmsip-chart-panel__caption">' . esc_html__('Completed events only. Historical points run oldest to newest.', 'vms-investor-portal') . '</p>';
            echo '</div>';
            echo '<label class="vmsip-metric-selector" for="' . esc_attr($metric_select_id) . '">';
            echo '<span>' . esc_html__('Metric', 'vms-investor-portal') . '</span>';
            echo '<select id="' . esc_attr($metric_select_id) . '" class="vmsip-chart-select">';
            echo '<option value="estimated_event_net">' . esc_html__('Estimated Event Net', 'vms-investor-portal') . '</option>';
            echo '<option value="ticket_revenue">' . esc_html__('Total Ticket Revenue', 'vms-investor-portal') . '</option>';
            echo '<option value="tickets_sold">' . esc_html__('Total Tickets Sold', 'vms-investor-portal') . '</option>';
            echo '<option value="attendance_total">' . esc_html__('Total Attendance', 'vms-investor-portal') . '</option>';
            echo '<option value="concession_sales">' . esc_html__('Concession / On-site Sales', 'vms-investor-portal') . '</option>';
            echo '</select>';
            echo '</label>';
            echo '</div>';
            echo '<div class="vmsip-chart-shell">';
            echo '<svg class="vmsip-chart" viewBox="0 0 820 360" role="img" aria-label="' . esc_attr__('Event performance chart', 'vms-investor-portal') . '"></svg>';
            echo '</div>';
            echo '<div class="vmsip-chart-legend" aria-live="polite"></div>';
            echo '<p class="vmsip-chart-summary" aria-live="polite"></p>';
            echo '<script type="application/json" class="vmsip-chart-data">' . wp_json_encode(array(
                'currencySymbol' => $this->currency_symbol(),
                'records' => $chart_payload,
            )) . '</script>';
            echo '</section>';
        }

        if (!empty($past_records)) {
            echo '<section class="vmsip-history">';
            echo '<div class="vmsip-section-head">';
            echo '<h3>' . esc_html__('Past Events', 'vms-investor-portal') . '</h3>';
            echo '<p>' . esc_html__('Completed reportable events, newest first.', 'vms-investor-portal') . '</p>';
            echo '</div>';
            echo '<div class="vmsip-table-wrap">';
            echo '<table class="vmsip-table">';
            echo '<thead><tr>';
            echo '<th scope="col">' . esc_html__('Date', 'vms-investor-portal') . '</th>';
            echo '<th scope="col">' . esc_html__('Event', 'vms-investor-portal') . '</th>';
            echo '<th scope="col">' . esc_html__('Estimated Event Net', 'vms-investor-portal') . '</th>';
            echo '<th scope="col">' . esc_html__('Total Ticket Revenue', 'vms-investor-portal') . '</th>';
            echo '<th scope="col">' . esc_html__('Total Tickets Sold', 'vms-investor-portal') . '</th>';
            echo '<th scope="col">' . esc_html__('Total Attendance', 'vms-investor-portal') . '</th>';
            echo '<th scope="col">' . esc_html__('Concession / On-site Sales', 'vms-investor-portal') . '</th>';
            echo '<th scope="col">' . esc_html__('Details', 'vms-investor-portal') . '</th>';
            echo '</tr></thead>';
            echo '<tbody>';

            foreach ($past_records as $record) {
                $details_id = $portal_instance . '-details-' . absint($record['event_id']);
                $metrics = isset($record['metrics']) && is_array($record['metrics']) ? $record['metrics'] : array();
                echo '<tr>';
                echo '<td>' . esc_html($record['event_date_label']) . '</td>';
                echo '<td>' . esc_html($record['event_title']) . '</td>';
                echo '<td>' . $this->format_metric_net_badge($metrics['estimated_event_net'] ?? array()) . '</td>';
                echo '<td>' . esc_html($this->format_metric_display_value($metrics['ticket_revenue'] ?? array())) . '</td>';
                echo '<td>' . esc_html($this->format_metric_display_value($metrics['tickets_sold'] ?? array())) . '</td>';
                echo '<td>' . esc_html($this->format_metric_display_value($metrics['attendance_total'] ?? array())) . '</td>';
                echo '<td>' . esc_html($this->format_metric_display_value($metrics['concession_sales'] ?? array())) . '</td>';
                echo '<td><button type="button" class="vmsip-details-toggle" aria-expanded="false" aria-controls="' . esc_attr($details_id) . '" data-show-label="' . esc_attr__('Show details', 'vms-investor-portal') . '" data-hide-label="' . esc_attr__('Hide details', 'vms-investor-portal') . '">' . esc_html__('Show details', 'vms-investor-portal') . '</button></td>';
                echo '</tr>';

                echo '<tr id="' . esc_attr($details_id) . '" class="vmsip-details-row" hidden>';
                echo '<td colspan="8">';
                echo '<div class="vmsip-details-panel">';
                echo '<p class="vmsip-source-note">' . esc_html($this->build_source_note($record)) . '</p>';
                if ($record['snapshot_status_notice'] !== '') {
                    echo '<p class="vmsip-source-note">' . esc_html($record['snapshot_status_notice']) . '</p>';
                }
                if (!empty($record['metric_warnings'])) {
                    echo '<div class="vmsip-source-warnings">';
                    foreach ((array) $record['metric_warnings'] as $warning_line) {
                        echo '<p class="vmsip-source-note">' . esc_html((string) $warning_line) . '</p>';
                    }
                    echo '</div>';
                }
                echo '<div class="vmsip-details-grid">';
                $this->render_frontend_detail_item(__('Total Ticket Revenue', 'vms-investor-portal'), $this->format_metric_display_value($metrics['ticket_revenue'] ?? array()));
                $this->render_frontend_detail_item(__('Advance Ticket Sales', 'vms-investor-portal'), $this->format_optional_currency($record['advance_ticket_revenue']));
                $this->render_frontend_detail_item(__('Door Ticket Sales', 'vms-investor-portal'), $this->format_optional_currency($record['door_ticket_revenue']));
                $this->render_frontend_detail_item(__('Total Tickets Sold', 'vms-investor-portal'), $this->format_metric_display_value($metrics['tickets_sold'] ?? array()));
                $this->render_frontend_detail_item(__('Advance Tickets Sold', 'vms-investor-portal'), $this->format_optional_count($record['advance_tickets_sold']));
                $this->render_frontend_detail_item(__('Door Tickets Sold', 'vms-investor-portal'), $this->format_optional_count($record['door_tickets_sold']));
                $this->render_frontend_detail_item(__('Total Attendance', 'vms-investor-portal'), $this->format_metric_display_value($metrics['attendance_total'] ?? array()));
                $this->render_frontend_detail_item(__('Checked In / Scanned', 'vms-investor-portal'), $this->format_metric_display_value($metrics['checked_in_scanned'] ?? array()));
                $this->render_frontend_detail_item(__('Concession / On-site Sales', 'vms-investor-portal'), $this->format_metric_display_value($metrics['concession_sales'] ?? array()));
                $this->render_frontend_detail_item(__('Bar Sales', 'vms-investor-portal'), $this->format_metric_display_value($metrics['bar_sales'] ?? array()));
                $this->render_frontend_detail_item(__('Food Sales', 'vms-investor-portal'), $this->format_metric_display_value($metrics['food_sales'] ?? array()));
                $this->render_frontend_detail_item(__('Merch Sales', 'vms-investor-portal'), $this->format_metric_display_value($metrics['merch_sales'] ?? array()));
                $this->render_frontend_detail_item(__('Website Add-ons', 'vms-investor-portal'), $this->format_metric_display_value($metrics['website_addons'] ?? array()));
                $this->render_frontend_detail_item(__('Estimated Sales Tax Collected', 'vms-investor-portal'), $this->format_metric_display_value($metrics['estimated_sales_tax'] ?? array()));
                $this->render_frontend_detail_item(__('Labor', 'vms-investor-portal'), $this->format_metric_display_value($metrics['labor_cost'] ?? array()));
                $this->render_frontend_detail_item(__('Concession Costs', 'vms-investor-portal'), $this->format_metric_display_value($metrics['concession_cost'] ?? array()));
                $this->render_frontend_detail_item((string) (($metrics['ad_spend']['label'] ?? __('Advertising', 'vms-investor-portal'))), $this->format_metric_display_value($metrics['ad_spend'] ?? array()));
                $this->render_frontend_detail_item(__('Performer/Vendor Cost', 'vms-investor-portal'), $this->format_metric_display_value($metrics['performer_cost'] ?? array()));
                $this->render_frontend_detail_item(__('Other Direct Costs', 'vms-investor-portal'), $this->format_metric_display_value($metrics['other_direct_costs'] ?? array()));
                $this->render_frontend_detail_item(__('Additional Overhead', 'vms-investor-portal'), $this->format_metric_display_value($metrics['other_expenses'] ?? array()));
                $this->render_frontend_detail_item(__('Estimated Event Net', 'vms-investor-portal'), $this->format_metric_display_value($metrics['estimated_event_net'] ?? array()));
                $this->render_frontend_detail_item(__('Notes', 'vms-investor-portal'), $record['notes'] !== '' ? nl2br(esc_html($record['notes'])) : esc_html__('None', 'vms-investor-portal'), true);
                echo '</div>';
                if (!empty($record['estimated_sales_tax_available'])) {
                    echo '<p class="vmsip-projection-disclaimer">' . esc_html__('Based on VMS/Square sales records. For internal review only. Do not use this figure for state sales tax filing.', 'vms-investor-portal') . '</p>';
                }

                $this->render_frontend_manual_overrides_block($record, $metrics);

                if (!empty($record['has_projection'])) {
                    echo '<div class="vmsip-projected-block">';
                    echo '<h4>' . esc_html__('Projected', 'vms-investor-portal') . '</h4>';
                    echo '<p class="vmsip-projection-disclaimer">' . esc_html__('Projected values are estimates and may differ from final event results.', 'vms-investor-portal') . '</p>';
                    echo '<div class="vmsip-details-grid">';
                    if (null !== $record['projected_ticket_revenue']) {
                        $this->render_frontend_detail_item(__('Projected Total Ticket Revenue', 'vms-investor-portal'), $this->format_currency((float) $record['projected_ticket_revenue']));
                    }
                    if (null !== $record['projected_tickets_sold']) {
                        $this->render_frontend_detail_item(__('Projected Total Tickets Sold', 'vms-investor-portal'), number_format_i18n((int) $record['projected_tickets_sold']));
                    }
                    if (null !== $record['projected_attendance_total']) {
                        $this->render_frontend_detail_item(__('Projected Total Attendance', 'vms-investor-portal'), number_format_i18n((int) $record['projected_attendance_total']));
                    }
                    if (null !== $record['projected_concession_sales']) {
                        $this->render_frontend_detail_item(__('Projected Concession Sales', 'vms-investor-portal'), $this->format_currency((float) $record['projected_concession_sales']));
                    }
                    if (null !== $record['projected_event_net']) {
                        $this->render_frontend_detail_item(__('Projected Event Net', 'vms-investor-portal'), $this->format_currency((float) $record['projected_event_net']));
                    }
                    if ($record['projection_notes'] !== '') {
                        $this->render_frontend_detail_item(__('Projection Notes', 'vms-investor-portal'), nl2br(esc_html($record['projection_notes'])), true);
                    }
                    echo '</div>';
                    echo '</div>';
                }

                echo '</div>';
                echo '</td>';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
            echo '</div>';
            echo '</section>';
        }

        echo '<section class="vmsip-upcoming">';
        echo '<div class="vmsip-section-head">';
        echo '<h3>' . esc_html__('Upcoming / Projected Events', 'vms-investor-portal') . '</h3>';
        echo '<p>' . esc_html__('Future published events are shown separately so projected values are never mixed into historical actuals.', 'vms-investor-portal') . '</p>';
        echo '</div>';

        if (!empty($upcoming_records)) {
            echo '<div class="vmsip-upcoming-list">';
            foreach ($upcoming_records as $record) {
                echo '<article class="vmsip-upcoming-card">';
                echo '<h4>' . esc_html($record['event_title']) . '</h4>';
                echo '<p class="vmsip-upcoming-card__meta">' . esc_html($record['event_date_label']) . ' <span class="vmsip-section-separator">|</span> ' . esc_html($record['event_status_label']) . '</p>';

                if (!empty($record['has_projection'])) {
                    echo '<p class="vmsip-projection-label">' . esc_html__('Projected', 'vms-investor-portal') . '</p>';
                    echo '<div class="vmsip-details-grid">';
                    if (null !== $record['projected_ticket_revenue']) {
                        $this->render_frontend_detail_item(__('Projected Total Ticket Revenue', 'vms-investor-portal'), $this->format_currency((float) $record['projected_ticket_revenue']));
                    }
                    if (null !== $record['projected_tickets_sold']) {
                        $this->render_frontend_detail_item(__('Projected Total Tickets Sold', 'vms-investor-portal'), number_format_i18n((int) $record['projected_tickets_sold']));
                    }
                    if (null !== $record['projected_attendance_total']) {
                        $this->render_frontend_detail_item(__('Projected Total Attendance', 'vms-investor-portal'), number_format_i18n((int) $record['projected_attendance_total']));
                    }
                    if (null !== $record['projected_concession_sales']) {
                        $this->render_frontend_detail_item(__('Projected Concession Sales', 'vms-investor-portal'), $this->format_currency((float) $record['projected_concession_sales']));
                    }
                    if (null !== $record['projected_event_net']) {
                        $this->render_frontend_detail_item(__('Projected Event Net', 'vms-investor-portal'), $this->format_currency((float) $record['projected_event_net']));
                    }
                    echo '</div>';
                    if ($record['projection_notes'] !== '') {
                        echo '<p class="vmsip-upcoming-card__notes">' . nl2br(esc_html($record['projection_notes'])) . '</p>';
                    }
                } else {
                    echo '<p class="vmsip-upcoming-card__empty">' . esc_html__('Projection data has not been entered for this event yet.', 'vms-investor-portal') . '</p>';
                }
            echo '</article>';
            }
            echo '</div>';
        } else {
            echo '<div class="vmsip-empty"><p>' . esc_html__('No upcoming published events are available right now.', 'vms-investor-portal') . '</p></div>';
        }

        if ($has_any_projection) {
            echo '<p class="vmsip-projection-disclaimer">' . esc_html__('Projected values are estimates and may differ from final event results.', 'vms-investor-portal') . '</p>';
        }

        echo '</section>';
        echo '</section>';

        return (string) ob_get_clean();
    }

    private static function install_schema(): void
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table_name = $wpdb->prefix . 'vms_investor_event_financials';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table_name} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
event_id bigint(20) unsigned NOT NULL,
ticket_revenue decimal(12,2) NOT NULL DEFAULT 0.00,
tickets_sold int(10) unsigned NOT NULL DEFAULT 0,
attendance_total int(10) unsigned NOT NULL DEFAULT 0,
concession_sales decimal(12,2) NOT NULL DEFAULT 0.00,
labor_cost decimal(12,2) NOT NULL DEFAULT 0.00,
concession_cost decimal(12,2) NOT NULL DEFAULT 0.00,
ad_spend decimal(12,2) NOT NULL DEFAULT 0.00,
performer_cost decimal(12,2) NOT NULL DEFAULT 0.00,
other_expenses decimal(12,2) NOT NULL DEFAULT 0.00,
notes text NULL,
projected_ticket_revenue decimal(12,2) DEFAULT NULL,
projected_tickets_sold int(10) unsigned DEFAULT NULL,
projected_attendance_total int(10) unsigned DEFAULT NULL,
projected_concession_sales decimal(12,2) DEFAULT NULL,
projected_event_net decimal(12,2) DEFAULT NULL,
projection_notes text NULL,
updated_by bigint(20) unsigned DEFAULT NULL,
created_at datetime NOT NULL,
updated_at datetime NOT NULL,
ticket_revenue_override decimal(12,2) DEFAULT NULL,
tickets_sold_override int(10) unsigned DEFAULT NULL,
attendance_total_override int(10) unsigned DEFAULT NULL,
concession_sales_override decimal(12,2) DEFAULT NULL,
labor_cost_override decimal(12,2) DEFAULT NULL,
concession_cost_override decimal(12,2) DEFAULT NULL,
ad_spend_override decimal(12,2) DEFAULT NULL,
performer_cost_override decimal(12,2) DEFAULT NULL,
other_expenses_override decimal(12,2) DEFAULT NULL,
estimated_tax_override decimal(12,2) DEFAULT NULL,
estimated_event_net_override decimal(12,2) DEFAULT NULL,
ticket_revenue_source varchar(100) DEFAULT NULL,
tickets_sold_source varchar(100) DEFAULT NULL,
attendance_source varchar(100) DEFAULT NULL,
metrics_snapshot_json longtext NULL,
metrics_snapshot_updated_at datetime DEFAULT NULL,
metrics_snapshot_status varchar(20) DEFAULT NULL,
metrics_snapshot_source_hash varchar(64) DEFAULT NULL,
metrics_snapshot_warnings longtext NULL,
metrics_snapshot_version varchar(20) DEFAULT NULL,
metrics_snapshot_last_error text NULL,
PRIMARY KEY  (id),
UNIQUE KEY event_id (event_id)
) {$charset_collate};";

        dbDelta($sql);
        self::migrate_legacy_metric_overrides();
        update_option(self::OPTION_DB_VERSION, self::DB_VERSION);
    }

    private static function migrate_legacy_metric_overrides(): void
    {
        global $wpdb;

        $table_name = $wpdb->prefix . 'vms_investor_event_financials';
        $columns = $wpdb->get_col("DESC {$table_name}", 0);

        if (!is_array($columns) || empty($columns)) {
            return;
        }

        $required = array(
            'ticket_revenue_override',
            'tickets_sold_override',
            'attendance_total_override',
            'concession_sales_override',
            'labor_cost_override',
            'concession_cost_override',
            'ad_spend_override',
            'performer_cost_override',
            'other_expenses_override',
            'estimated_tax_override',
            'estimated_event_net_override',
            'ticket_revenue_source',
            'tickets_sold_source',
            'attendance_source',
        );

        foreach ($required as $column) {
            if (!in_array($column, $columns, true)) {
                return;
            }
        }

        $wpdb->query(
            "UPDATE {$table_name}
            SET
                ticket_revenue_override = CASE
                    WHEN ticket_revenue_override IS NULL AND ticket_revenue <> 0 THEN ticket_revenue
                    ELSE ticket_revenue_override
                END,
                tickets_sold_override = CASE
                    WHEN tickets_sold_override IS NULL AND tickets_sold <> 0 THEN tickets_sold
                    ELSE tickets_sold_override
                END,
                attendance_total_override = CASE
                    WHEN attendance_total_override IS NULL AND attendance_total <> 0 THEN attendance_total
                    ELSE attendance_total_override
                END,
                concession_sales_override = CASE
                    WHEN concession_sales_override IS NULL AND concession_sales <> 0 THEN concession_sales
                    ELSE concession_sales_override
                END,
                labor_cost_override = CASE
                    WHEN labor_cost_override IS NULL AND labor_cost <> 0 THEN labor_cost
                    ELSE labor_cost_override
                END,
                concession_cost_override = CASE
                    WHEN concession_cost_override IS NULL AND concession_cost <> 0 THEN concession_cost
                    ELSE concession_cost_override
                END,
                ad_spend_override = CASE
                    WHEN ad_spend_override IS NULL AND ad_spend <> 0 THEN ad_spend
                    ELSE ad_spend_override
                END,
                performer_cost_override = CASE
                    WHEN performer_cost_override IS NULL AND performer_cost <> 0 THEN performer_cost
                    ELSE performer_cost_override
                END,
                other_expenses_override = CASE
                    WHEN other_expenses_override IS NULL AND other_expenses <> 0 THEN other_expenses
                    ELSE other_expenses_override
                END,
                ticket_revenue_source = CASE
                    WHEN (ticket_revenue_source IS NULL OR ticket_revenue_source = '') AND ticket_revenue_override IS NULL AND ticket_revenue <> 0 THEN 'legacy_manual'
                    ELSE ticket_revenue_source
                END,
                tickets_sold_source = CASE
                    WHEN (tickets_sold_source IS NULL OR tickets_sold_source = '') AND tickets_sold_override IS NULL AND tickets_sold <> 0 THEN 'legacy_manual'
                    ELSE tickets_sold_source
                END,
                attendance_source = CASE
                    WHEN (attendance_source IS NULL OR attendance_source = '') AND attendance_total_override IS NULL AND attendance_total <> 0 THEN 'legacy_manual'
                    ELSE attendance_source
                END"
        );
    }

    private static function ensure_roles_and_caps(): void
    {
        $role = get_role(self::ROLE_INVESTOR);

        if (!$role) {
            $role = add_role(
                self::ROLE_INVESTOR,
                __('VMS Investor', 'vms-investor-portal'),
                array(
                    'read' => true,
                    self::CAP_VIEW => true,
                )
            );
        }

        if ($role instanceof WP_Role) {
            $role->add_cap('read');
            $role->add_cap(self::CAP_VIEW);
        }

        $admin_role = get_role('administrator');

        if ($admin_role instanceof WP_Role) {
            $admin_role->add_cap(self::CAP_MANAGE);
        }
    }

    private function table_name(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'vms_investor_event_financials';
    }

    /**
     * @return array<string,mixed>
     */
    private function default_record(int $event_id = 0): array
    {
        return array(
            'id' => 0,
            'event_id' => $event_id,
            'ticket_revenue' => '0.00',
            'tickets_sold' => 0,
            'attendance_total' => 0,
            'ticket_revenue_override' => null,
            'tickets_sold_override' => null,
            'attendance_total_override' => null,
            'ticket_revenue_source' => '',
            'tickets_sold_source' => '',
            'attendance_source' => '',
            'concession_sales' => '0.00',
            'labor_cost' => '0.00',
            'concession_cost' => '0.00',
            'ad_spend' => '0.00',
            'performer_cost' => '0.00',
            'other_expenses' => '0.00',
            'concession_sales_override' => null,
            'labor_cost_override' => null,
            'concession_cost_override' => null,
            'ad_spend_override' => null,
            'performer_cost_override' => null,
            'other_expenses_override' => null,
            'estimated_tax_override' => null,
            'estimated_event_net_override' => null,
            'metrics_snapshot_json' => null,
            'metrics_snapshot_updated_at' => null,
            'metrics_snapshot_status' => '',
            'metrics_snapshot_source_hash' => '',
            'metrics_snapshot_warnings' => null,
            'metrics_snapshot_version' => '',
            'metrics_snapshot_last_error' => '',
            'notes' => '',
            'projected_ticket_revenue' => null,
            'projected_tickets_sold' => null,
            'projected_attendance_total' => null,
            'projected_concession_sales' => null,
            'projected_event_net' => null,
            'projection_notes' => '',
            'updated_by' => null,
            'created_at' => '',
            'updated_at' => '',
        );
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private function get_financial_records_map(): array
    {
        global $wpdb;

        $rows = $wpdb->get_results("SELECT * FROM {$this->table_name()} ORDER BY updated_at DESC", ARRAY_A);
        $map = array();

        if (!is_array($rows)) {
            return $map;
        }

        foreach ($rows as $row) {
            $normalized = $this->normalize_record($row);
            $map[(int) $normalized['event_id']] = $normalized;
        }

        return $map;
    }

    /**
     * @return array<string,mixed>|null
     */
    private function get_financial_record(int $event_id): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$this->table_name()} WHERE event_id = %d LIMIT 1",
                $event_id
            ),
            ARRAY_A
        );

        if (!is_array($row)) {
            return null;
        }

        return $this->normalize_record($row);
    }

    /**
     * @param array<string,mixed> $context
     * @param array<int,array<string,mixed>>|null $records_map
     * @return array<string,mixed>|null
     */
    private function get_financial_record_for_context(array $context, ?array $records_map = null): ?array
    {
        $records_map = is_array($records_map) ? $records_map : $this->get_financial_records_map();

        foreach ($this->record_lookup_ids_for_context($context) as $event_id) {
            if (isset($records_map[$event_id])) {
                return $records_map[$event_id];
            }
        }

        return null;
    }

    /**
     * @param array<string,mixed> $context
     * @return int[]
     */
    private function record_lookup_ids_for_context(array $context): array
    {
        $ids = array(
            isset($context['post_id']) ? absint($context['post_id']) : 0,
            isset($context['tec_event_id']) ? absint($context['tec_event_id']) : 0,
            isset($context['event_plan_id']) ? absint($context['event_plan_id']) : 0,
        );

        return array_values(array_unique(array_filter($ids)));
    }

    /**
     * @param array<string,mixed> $row
     * @return array<string,mixed>
     */
    private function normalize_record(array $row): array
    {
        $record = $this->default_record(isset($row['event_id']) ? absint($row['event_id']) : 0);

        $record['id'] = isset($row['id']) ? absint($row['id']) : 0;
        $record['ticket_revenue'] = $this->normalize_decimal_string($row['ticket_revenue'] ?? '0');
        $record['tickets_sold'] = isset($row['tickets_sold']) ? absint($row['tickets_sold']) : 0;
        $record['attendance_total'] = isset($row['attendance_total']) ? absint($row['attendance_total']) : 0;
        $record['ticket_revenue_override'] = $this->normalize_nullable_decimal_string($row['ticket_revenue_override'] ?? null);
        $record['tickets_sold_override'] = $this->normalize_nullable_integer($row['tickets_sold_override'] ?? null);
        $record['attendance_total_override'] = $this->normalize_nullable_integer($row['attendance_total_override'] ?? null);
        $record['ticket_revenue_source'] = isset($row['ticket_revenue_source']) ? sanitize_key((string) $row['ticket_revenue_source']) : '';
        $record['tickets_sold_source'] = isset($row['tickets_sold_source']) ? sanitize_key((string) $row['tickets_sold_source']) : '';
        $record['attendance_source'] = isset($row['attendance_source']) ? sanitize_key((string) $row['attendance_source']) : '';
        $record['concession_sales'] = $this->normalize_decimal_string($row['concession_sales'] ?? '0');
        $record['labor_cost'] = $this->normalize_decimal_string($row['labor_cost'] ?? '0');
        $record['concession_cost'] = $this->normalize_decimal_string($row['concession_cost'] ?? '0');
        $record['ad_spend'] = $this->normalize_decimal_string($row['ad_spend'] ?? '0');
        $record['performer_cost'] = $this->normalize_decimal_string($row['performer_cost'] ?? '0');
        $record['other_expenses'] = $this->normalize_decimal_string($row['other_expenses'] ?? '0');
        $record['concession_sales_override'] = $this->normalize_nullable_decimal_string($row['concession_sales_override'] ?? null);
        $record['labor_cost_override'] = $this->normalize_nullable_decimal_string($row['labor_cost_override'] ?? null);
        $record['concession_cost_override'] = $this->normalize_nullable_decimal_string($row['concession_cost_override'] ?? null);
        $record['ad_spend_override'] = $this->normalize_nullable_decimal_string($row['ad_spend_override'] ?? null);
        $record['performer_cost_override'] = $this->normalize_nullable_decimal_string($row['performer_cost_override'] ?? null);
        $record['other_expenses_override'] = $this->normalize_nullable_decimal_string($row['other_expenses_override'] ?? null);
        $record['estimated_tax_override'] = $this->normalize_nullable_decimal_string($row['estimated_tax_override'] ?? null);
        $record['estimated_event_net_override'] = $this->normalize_nullable_decimal_string($row['estimated_event_net_override'] ?? null);
        $record['metrics_snapshot_json'] = isset($row['metrics_snapshot_json']) && '' !== trim((string) $row['metrics_snapshot_json']) ? (string) $row['metrics_snapshot_json'] : null;
        $record['metrics_snapshot_updated_at'] = isset($row['metrics_snapshot_updated_at']) && '' !== trim((string) $row['metrics_snapshot_updated_at']) ? (string) $row['metrics_snapshot_updated_at'] : null;
        $record['metrics_snapshot_status'] = isset($row['metrics_snapshot_status']) ? sanitize_key((string) $row['metrics_snapshot_status']) : '';
        $record['metrics_snapshot_source_hash'] = isset($row['metrics_snapshot_source_hash']) ? sanitize_text_field((string) $row['metrics_snapshot_source_hash']) : '';
        $record['metrics_snapshot_warnings'] = isset($row['metrics_snapshot_warnings']) && '' !== trim((string) $row['metrics_snapshot_warnings']) ? (string) $row['metrics_snapshot_warnings'] : null;
        $record['metrics_snapshot_version'] = isset($row['metrics_snapshot_version']) ? sanitize_text_field((string) $row['metrics_snapshot_version']) : '';
        $record['metrics_snapshot_last_error'] = isset($row['metrics_snapshot_last_error']) ? trim((string) $row['metrics_snapshot_last_error']) : '';
        $record['notes'] = isset($row['notes']) ? trim((string) $row['notes']) : '';
        $record['projected_ticket_revenue'] = $this->normalize_nullable_decimal_string($row['projected_ticket_revenue'] ?? null);
        $record['projected_tickets_sold'] = $this->normalize_nullable_integer($row['projected_tickets_sold'] ?? null);
        $record['projected_attendance_total'] = $this->normalize_nullable_integer($row['projected_attendance_total'] ?? null);
        $record['projected_concession_sales'] = $this->normalize_nullable_decimal_string($row['projected_concession_sales'] ?? null);
        $record['projected_event_net'] = $this->normalize_nullable_decimal_string($row['projected_event_net'] ?? null);
        $record['projection_notes'] = isset($row['projection_notes']) ? trim((string) $row['projection_notes']) : '';
        $record['updated_by'] = isset($row['updated_by']) && '' !== (string) $row['updated_by'] ? absint($row['updated_by']) : null;
        $record['created_at'] = isset($row['created_at']) ? (string) $row['created_at'] : '';
        $record['updated_at'] = isset($row['updated_at']) ? (string) $row['updated_at'] : '';

        return $record;
    }

    private function metrics_snapshot_ttl(): int
    {
        $ttl = (int) apply_filters('vms_investor_portal_metrics_snapshot_ttl', 6 * HOUR_IN_SECONDS);

        return max(300, $ttl);
    }

    private function snapshot_recent_refresh_limit(): int
    {
        $limit = (int) apply_filters('vms_investor_portal_snapshot_recent_refresh_limit', 10);

        return max(1, $limit);
    }

    private function snapshot_visible_refresh_limit(): int
    {
        $limit = (int) apply_filters('vms_investor_portal_snapshot_visible_refresh_limit', 25);

        return max(1, $limit);
    }

    private function normalize_refresh_scope($value): string
    {
        $value = sanitize_key((string) $value);
        $allowed = array('visible', 'recent_completed');

        return in_array($value, $allowed, true) ? $value : 'visible';
    }

    private function refresh_feedback_transient_key(): string
    {
        return 'vmsip_refresh_feedback_' . get_current_user_id();
    }

    /**
     * @param array<string,mixed> $feedback
     */
    private function store_refresh_feedback(array $feedback): void
    {
        set_transient($this->refresh_feedback_transient_key(), $feedback, 5 * MINUTE_IN_SECONDS);
    }

    /**
     * @return array<string,mixed>|null
     */
    private function consume_refresh_feedback(): ?array
    {
        $key = $this->refresh_feedback_transient_key();
        $feedback = get_transient($key);
        delete_transient($key);

        return is_array($feedback) ? $feedback : null;
    }

    /**
     * @param array<string,mixed> $result
     * @return array<string,mixed>
     */
    private function build_refresh_feedback_item(WP_Post $post, array $result, bool $success): array
    {
        $warnings = isset($result['warnings']) && is_array($result['warnings'])
            ? array_values(array_filter(array_map('strval', $result['warnings'])))
            : array();

        return array(
            'event_id' => (int) $post->ID,
            'event_title' => $this->refresh_feedback_event_title($post),
            'message' => $this->refresh_feedback_message($warnings, $success),
            'warnings' => $success ? $warnings : array(),
        );
    }

    private function refresh_feedback_event_title(WP_Post $post): string
    {
        $title = trim((string) get_the_title($post));

        return $title !== ''
            ? $title
            : sprintf(
                /* translators: %d: event ID */
                __('Event #%d', 'vms-investor-portal'),
                (int) $post->ID
            );
    }

    /**
     * @param string[] $warnings
     */
    private function refresh_feedback_message(array $warnings, bool $success): string
    {
        $warnings = array_values(array_filter(array_map('strval', $warnings)));
        if (!$success && !empty($warnings)) {
            return implode(' ', $warnings);
        }

        return $success
            ? (string) __('Metrics snapshot refreshed.', 'vms-investor-portal')
            : (string) __('The metrics snapshot could not be refreshed.', 'vms-investor-portal');
    }

    private function refresh_actions_enabled(): bool
    {
        $default_enabled = !(defined('VMS_INVESTOR_PORTAL_DISABLE_REFRESH') && VMS_INVESTOR_PORTAL_DISABLE_REFRESH);

        return (bool) apply_filters(
            'vms_investor_portal_enable_refresh_actions',
            $default_enabled,
            wp_get_environment_type()
        );
    }

    private function refresh_actions_disabled_message(): string
    {
        return (string) apply_filters(
            'vms_investor_portal_refresh_disabled_message',
            __('Snapshot refresh is currently disabled for this environment. Normal cached rendering is still available.', 'vms-investor-portal'),
            wp_get_environment_type()
        );
    }

    /**
     * @param array<string,mixed> $context
     */
    private function preferred_storage_event_id(array $context, int $fallback = 0): int
    {
        foreach (array('tec_event_id', 'event_plan_id', 'post_id') as $key) {
            $candidate = isset($context[$key]) ? absint($context[$key]) : 0;
            if ($candidate > 0) {
                return $candidate;
            }
        }

        return $fallback > 0 ? $fallback : 0;
    }

    /**
     * @param array<string,mixed> $context
     */
    private function build_metrics_snapshot_source_hash(WP_Post $post, array $context): string
    {
        $post_modified = get_post_modified_time('U', true, $post);
        $tec_post = !empty($context['tec_event_id']) ? get_post((int) $context['tec_event_id']) : null;
        $plan_post = !empty($context['event_plan_id']) ? get_post((int) $context['event_plan_id']) : null;

        return sha1((string) wp_json_encode(array(
            'snapshot_version' => self::SNAPSHOT_VERSION,
            'post_id' => (int) $post->ID,
            'tec_event_id' => (int) ($context['tec_event_id'] ?? 0),
            'event_plan_id' => (int) ($context['event_plan_id'] ?? 0),
            'post_modified' => is_numeric($post_modified) ? (int) $post_modified : 0,
            'tec_modified' => $tec_post instanceof WP_Post ? (int) get_post_modified_time('U', true, $tec_post) : 0,
            'plan_modified' => $plan_post instanceof WP_Post ? (int) get_post_modified_time('U', true, $plan_post) : 0,
            'status' => (string) ($context['event_status_key'] ?? ''),
        )));
    }

    /**
     * @param array<string,mixed> $record
     */
    private function metrics_snapshot_payload_cache_key(array $record): string
    {
        return implode(':', array(
            (string) (int) ($record['event_id'] ?? 0),
            (string) ($record['metrics_snapshot_updated_at'] ?? ''),
            md5((string) ($record['metrics_snapshot_json'] ?? '')),
            md5((string) ($record['updated_at'] ?? '')),
        ));
    }

    /**
     * @param array<string,mixed>|null $state
     * @return array<string,mixed>
     */
    private function get_metrics_payload_for_display(WP_Post $post, array $record, array $context, ?array $state = null): array
    {
        unset($post, $context);

        $cache_key = $this->metrics_snapshot_payload_cache_key($record);
        if (isset($this->metrics_snapshot_payload_cache[$cache_key])) {
            return $this->metrics_snapshot_payload_cache[$cache_key];
        }

        $snapshot_updated_at = isset($record['metrics_snapshot_updated_at']) ? (string) $record['metrics_snapshot_updated_at'] : '';
        $snapshot_payload = $this->decode_json_object($record['metrics_snapshot_json'] ?? null);
        if (empty($snapshot_payload)) {
            $payload = $this->metrics_provider()->empty_snapshot_payload_for_display($record, $snapshot_updated_at);
        } else {
            $payload = $this->metrics_provider()->prepare_snapshot_payload_for_display($snapshot_payload, $record, $snapshot_updated_at);
        }

        if (is_array($state) && !empty($state['last_error'])) {
            $payload['warnings'] = array_values(array_unique(array_merge(
                isset($payload['warnings']) && is_array($payload['warnings']) ? $payload['warnings'] : array(),
                array((string) $state['last_error'])
            )));
        }

        $this->metrics_snapshot_payload_cache[$cache_key] = $payload;

        return $payload;
    }

    private function clear_metrics_snapshot_payload_cache(): void
    {
        $this->metrics_snapshot_payload_cache = array();
    }

    private function register_refresh_shutdown_guard(string $scope, string $view, int $event_id): void
    {
        $this->refresh_guard_reserved_memory = str_repeat('R', 262144);
        $this->refresh_shutdown_guard = array(
            'scope' => $scope,
            'view' => $view,
            'event_id' => $event_id,
        );

        register_shutdown_function(array($this, 'handle_refresh_shutdown_guard'));
    }

    private function clear_refresh_shutdown_guard(): void
    {
        $this->refresh_guard_reserved_memory = '';
        $this->refresh_shutdown_guard = null;
    }

    public function handle_refresh_shutdown_guard(): void
    {
        if (!is_array($this->refresh_shutdown_guard)) {
            return;
        }

        $this->refresh_guard_reserved_memory = '';
        $last_error = error_get_last();
        if (!is_array($last_error)) {
            $this->refresh_shutdown_guard = null;
            return;
        }

        $fatal_types = array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR);
        if (!in_array((int) ($last_error['type'] ?? 0), $fatal_types, true)) {
            $this->refresh_shutdown_guard = null;
            return;
        }

        $scope = sanitize_key((string) ($this->refresh_shutdown_guard['scope'] ?? 'event'));
        $view = $this->normalize_admin_view($this->refresh_shutdown_guard['view'] ?? 'recent_past');
        $event_id = absint($this->refresh_shutdown_guard['event_id'] ?? 0);
        $message = trim((string) ($last_error['message'] ?? ''));
        if ($message === '') {
            $message = __('A fatal error interrupted the metrics refresh.', 'vms-investor-portal');
        } elseif (stripos($message, 'Allowed memory size') !== false) {
            $message = __('The metrics refresh ran out of memory before it could finish. No new snapshot was written.', 'vms-investor-portal');
        }

        $this->store_refresh_feedback(array(
            'scope' => $scope,
            'success_count' => 0,
            'error_count' => 1,
            'successes' => array(),
            'errors' => array(array(
                'event_id' => $event_id,
                'event_title' => $event_id > 0
                    ? sprintf(__('Event #%d', 'vms-investor-portal'), $event_id)
                    : __('Metrics refresh', 'vms-investor-portal'),
                'message' => $message,
            )),
        ));

        $this->refresh_shutdown_guard = null;

        if (!headers_sent()) {
            wp_safe_redirect($this->get_admin_page_url(array(
                'vmsip_view' => $view,
                'event_id' => $event_id,
                'vmsip_refresh_result' => $scope,
                'vmsip_refresh_count' => 0,
                'vmsip_refresh_errors' => 1,
            )));
            exit;
        }
    }

    /**
     * @param array<string,mixed> $context
     * @param array<string,mixed> $record
     * @return array<string,mixed>
     */
    private function get_metrics_snapshot_state(WP_Post $post, array $context, array $record): array
    {
        $has_payload = !empty($record['metrics_snapshot_json']);
        $last_refreshed = isset($record['metrics_snapshot_updated_at']) ? trim((string) $record['metrics_snapshot_updated_at']) : '';
        $stored_status = isset($record['metrics_snapshot_status']) ? sanitize_key((string) $record['metrics_snapshot_status']) : '';
        $last_error = isset($record['metrics_snapshot_last_error']) ? trim((string) $record['metrics_snapshot_last_error']) : '';
        $warnings = $this->decode_json_string_list($record['metrics_snapshot_warnings'] ?? null);

        $status = self::SNAPSHOT_STATUS_MISSING;
        if (!$has_payload) {
            $status = $stored_status === self::SNAPSHOT_STATUS_ERROR ? self::SNAPSHOT_STATUS_ERROR : self::SNAPSHOT_STATUS_MISSING;
        } elseif ($stored_status === self::SNAPSHOT_STATUS_ERROR) {
            $status = self::SNAPSHOT_STATUS_ERROR;
        } else {
            $version_matches = (string) ($record['metrics_snapshot_version'] ?? '') === self::SNAPSHOT_VERSION;
            $source_hash_matches = !empty($record['metrics_snapshot_source_hash'])
                && hash_equals((string) $record['metrics_snapshot_source_hash'], $this->build_metrics_snapshot_source_hash($post, $context));
            $expired = $this->snapshot_is_expired($last_refreshed);
            $status = ($version_matches && $source_hash_matches && !$expired)
                ? self::SNAPSHOT_STATUS_FRESH
                : self::SNAPSHOT_STATUS_STALE;
        }

        $last_refreshed_label = $this->format_snapshot_timestamp($last_refreshed);
        $notice = '';
        $label = __('Missing', 'vms-investor-portal');

        switch ($status) {
            case self::SNAPSHOT_STATUS_FRESH:
                $label = __('Fresh', 'vms-investor-portal');
                break;

            case self::SNAPSHOT_STATUS_STALE:
                $label = __('Stale', 'vms-investor-portal');
                $notice = $last_refreshed_label !== ''
                    ? sprintf(
                        /* translators: %s: last refreshed timestamp */
                        __('Cached metrics may be stale. Last refreshed %s.', 'vms-investor-portal'),
                        $last_refreshed_label
                    )
                    : __('Cached metrics may be stale.', 'vms-investor-portal');
                break;

            case self::SNAPSHOT_STATUS_ERROR:
                $label = __('Error', 'vms-investor-portal');
                if ($has_payload && $last_refreshed_label !== '') {
                    $notice = sprintf(
                        /* translators: %s: last refreshed timestamp */
                        __('Last metrics refresh failed. Showing cached values from %s.', 'vms-investor-portal'),
                        $last_refreshed_label
                    );
                } elseif ($has_payload) {
                    $notice = __('Last metrics refresh failed. Showing the last cached values.', 'vms-investor-portal');
                } else {
                    $notice = __('Metrics have not been refreshed yet.', 'vms-investor-portal');
                }
                break;

            case self::SNAPSHOT_STATUS_MISSING:
            default:
                $label = __('Missing', 'vms-investor-portal');
                $notice = __('Metrics have not been refreshed yet.', 'vms-investor-portal');
                break;
        }

        return array(
            'status' => $status,
            'label' => $label,
            'notice' => $notice,
            'source_label' => __('Cached investor metrics snapshot', 'vms-investor-portal'),
            'last_refreshed' => $last_refreshed,
            'last_refreshed_label' => $last_refreshed_label,
            'warnings' => array_values(array_unique(array_filter($warnings))),
            'last_error' => $last_error,
        );
    }

    private function snapshot_is_expired(string $last_refreshed): bool
    {
        if ($last_refreshed === '') {
            return true;
        }

        $timestamp = mysql2date('U', $last_refreshed, false);
        if (!$timestamp) {
            return true;
        }

        return ((int) $timestamp) < (current_time('timestamp') - $this->metrics_snapshot_ttl());
    }

    private function format_snapshot_timestamp(string $value): string
    {
        if ($value === '') {
            return '';
        }

        return (string) mysql2date(
            trim(get_option('date_format') . ' ' . get_option('time_format')),
            $value,
            false
        );
    }

    /**
     * @param array<string,mixed>|null $existing
     * @return array<string,mixed>
     */
    private function refresh_metrics_snapshot_for_post(WP_Post $post, array $context, ?array $existing = null): array
    {
        $existing = is_array($existing) ? $existing : $this->get_financial_record_for_context($context);
        $stored_event_id = $existing ? (int) $existing['event_id'] : $this->preferred_storage_event_id($context, (int) $post->ID);
        $snapshot_updated_at = current_time('mysql');
        $source_hash = $this->build_metrics_snapshot_source_hash($post, $context);

        try {
            $payload = $this->metrics_provider()->get_event_metrics($post, $context, array());
            $payload = $this->metrics_provider()->sanitize_snapshot_payload_for_storage($payload);
            $warnings = isset($payload['warnings']) && is_array($payload['warnings'])
                ? array_values(array_filter(array_map('strval', $payload['warnings'])))
                : array();
            $encoded_payload = wp_json_encode($payload);
            $encoded_warnings = !empty($warnings) ? wp_json_encode($warnings) : null;

            $saved = $this->persist_metrics_snapshot($stored_event_id, array(
                'metrics_snapshot_json' => is_string($encoded_payload) && $encoded_payload !== '' ? $encoded_payload : '{}',
                'metrics_snapshot_updated_at' => $snapshot_updated_at,
                'metrics_snapshot_status' => self::SNAPSHOT_STATUS_FRESH,
                'metrics_snapshot_source_hash' => $source_hash,
                'metrics_snapshot_warnings' => is_string($encoded_warnings) && $encoded_warnings !== '' ? $encoded_warnings : null,
                'metrics_snapshot_version' => self::SNAPSHOT_VERSION,
                'metrics_snapshot_last_error' => null,
            ), $existing);

            return array(
                'success' => $saved,
                'event_id' => $stored_event_id,
                'warnings' => $warnings,
            );
        } catch (Throwable $exception) {
            $message = trim((string) $exception->getMessage());
            $warnings = $message !== '' ? array($message) : array();
            $encoded_warnings = !empty($warnings) ? wp_json_encode($warnings) : null;

            $this->persist_metrics_snapshot($stored_event_id, array(
                'metrics_snapshot_updated_at' => $snapshot_updated_at,
                'metrics_snapshot_status' => self::SNAPSHOT_STATUS_ERROR,
                'metrics_snapshot_source_hash' => $source_hash,
                'metrics_snapshot_warnings' => is_string($encoded_warnings) && $encoded_warnings !== '' ? $encoded_warnings : null,
                'metrics_snapshot_version' => self::SNAPSHOT_VERSION,
                'metrics_snapshot_last_error' => $message !== '' ? $message : null,
            ), $existing);

            return array(
                'success' => false,
                'event_id' => $stored_event_id,
                'warnings' => $warnings,
            );
        }
    }

    /**
     * @param array<string,mixed>|null $existing
     */
    private function persist_metrics_snapshot(int $stored_event_id, array $snapshot_data, ?array $existing = null): bool
    {
        global $wpdb;

        if ($stored_event_id <= 0) {
            return false;
        }

        $existing = is_array($existing) ? $existing : $this->get_financial_record($stored_event_id);
        $data = array(
            'metrics_snapshot_updated_at' => isset($snapshot_data['metrics_snapshot_updated_at']) ? $snapshot_data['metrics_snapshot_updated_at'] : null,
            'metrics_snapshot_status' => isset($snapshot_data['metrics_snapshot_status']) ? $snapshot_data['metrics_snapshot_status'] : null,
            'metrics_snapshot_source_hash' => isset($snapshot_data['metrics_snapshot_source_hash']) ? $snapshot_data['metrics_snapshot_source_hash'] : null,
            'metrics_snapshot_warnings' => $snapshot_data['metrics_snapshot_warnings'] ?? null,
            'metrics_snapshot_version' => $snapshot_data['metrics_snapshot_version'] ?? null,
            'metrics_snapshot_last_error' => $snapshot_data['metrics_snapshot_last_error'] ?? null,
        );
        if (array_key_exists('metrics_snapshot_json', $snapshot_data)) {
            $data['metrics_snapshot_json'] = $snapshot_data['metrics_snapshot_json'];
        }

        $formats = array();
        foreach ($data as $value) {
            $formats[] = is_string($value) || null === $value ? '%s' : '%d';
        }

        if ($existing) {
            $updated = $wpdb->update(
                $this->table_name(),
                $data,
                array('event_id' => $stored_event_id),
                $formats,
                array('%d')
            );
            $this->clear_metrics_snapshot_payload_cache();

            return false !== $updated;
        }

        $now = current_time('mysql');
        $insert_data = array_merge(array(
            'event_id' => $stored_event_id,
            'created_at' => $now,
            'updated_at' => $now,
        ), $data);
        $insert_formats = array_merge(array('%d', '%s', '%s'), $formats);
        $inserted = $wpdb->insert($this->table_name(), $insert_data, $insert_formats);
        $this->clear_metrics_snapshot_payload_cache();

        return false !== $inserted;
    }

    /**
     * @return array<string,mixed>
     */
    private function decode_json_object($value): array
    {
        if (!is_string($value) || trim($value) === '') {
            return array();
        }

        $decoded = json_decode($value, true);

        return is_array($decoded) ? $decoded : array();
    }

    /**
     * @return string[]
     */
    private function decode_json_string_list($value): array
    {
        if (!is_string($value) || trim($value) === '') {
            return array();
        }

        $decoded = json_decode($value, true);
        if (!is_array($decoded)) {
            return array();
        }

        return array_values(array_filter(array_map('strval', $decoded)));
    }

    /**
     * @return array<int,array{post:WP_Post,context:array<string,mixed>}>
     */
    private function get_admin_events(string $view): array
    {
        return $this->get_reportable_events($view);
    }

    /**
     * @return array<int,array{post:WP_Post,context:array<string,mixed>}>
     */
    private function get_frontend_events(string $view): array
    {
        return $this->get_reportable_events($view);
    }

    /**
     * @return array<int,array{post:WP_Post,context:array<string,mixed>}>
     */
    private function get_reportable_events(string $view): array
    {
        $post_types = $this->get_event_post_types();

        if (empty($post_types)) {
            return array();
        }

        $posts = get_posts(array(
            'post_type' => $post_types,
            'post_status' => $this->get_reportable_post_statuses(),
            'numberposts' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'suppress_filters' => false,
        ));

        if (!is_array($posts) || empty($posts)) {
            return array();
        }

        $deduped = array();

        foreach ($posts as $post) {
            if (!($post instanceof WP_Post)) {
                continue;
            }

            $context = $this->get_event_context($post);

            if (!$this->event_is_reportable($post, $context)) {
                continue;
            }

            $canonical_key = (string) $context['canonical_key'];

            if (!isset($deduped[$canonical_key]) || $this->is_preferred_entry($post, $context, $deduped[$canonical_key])) {
                $deduped[$canonical_key] = array(
                    'post' => $post,
                    'context' => $context,
                );
            }
        }

        $entries = array_values($deduped);

        $entries = array_values(array_filter($entries, function (array $entry) use ($view): bool {
            return $this->entry_matches_view($entry['context'], $view);
        }));

        usort($entries, function (array $a, array $b) use ($view): int {
            $a_ts = isset($a['context']['start_timestamp']) ? (int) $a['context']['start_timestamp'] : 0;
            $b_ts = isset($b['context']['start_timestamp']) ? (int) $b['context']['start_timestamp'] : 0;

            if ($view === 'upcoming') {
                return $a_ts <=> $b_ts;
            }

            return $b_ts <=> $a_ts;
        });

        return $entries;
    }

    /**
     * @param array<string,mixed> $context
     */
    private function entry_matches_view(array $context, string $view): bool
    {
        switch ($view) {
            case 'past':
            case 'recent_past':
                return !empty($context['is_completed']);

            case 'upcoming':
                return !empty($context['is_upcoming']);

            case 'all':
            default:
                return true;
        }
    }

    /**
     * @param array<string,mixed> $existing
     */
    private function is_preferred_entry(WP_Post $candidate_post, array $candidate_context, array $existing): bool
    {
        $existing_post = $existing['post'];
        $existing_context = $existing['context'];

        if (!($existing_post instanceof WP_Post) || !is_array($existing_context)) {
            return true;
        }

        $candidate_score = $this->event_preference_score($candidate_post, $candidate_context);
        $existing_score = $this->event_preference_score($existing_post, $existing_context);

        if ($candidate_score === $existing_score) {
            return (int) $candidate_post->ID > (int) $existing_post->ID;
        }

        return $candidate_score > $existing_score;
    }

    /**
     * @param array<string,mixed> $context
     */
    private function event_preference_score(WP_Post $post, array $context): int
    {
        $post_type = (string) $post->post_type;
        $score = 0;

        if ($post_type === 'tribe_events') {
            $score += 40;
        } elseif ($post_type === 'vms_event') {
            $score += 30;
        } elseif ($post_type === 'vms_event_plan') {
            $score += 10;
        } else {
            $score += 20;
        }

        if ((int) ($context['tec_event_id'] ?? 0) === (int) $post->ID) {
            $score += 10;
        }

        if (!empty($context['start_timestamp'])) {
            $score += 5;
        }

        return $score;
    }

    /**
     * @return array<string,mixed>
     */
    private function get_event_context(WP_Post $post): array
    {
        $post_id = (int) $post->ID;

        if (isset($this->event_context_cache[$post_id])) {
            return $this->event_context_cache[$post_id];
        }

        $post_type = (string) $post->post_type;
        $tec_event_id = $post_type === 'tribe_events' ? $post_id : 0;
        $event_plan_id = $post_type === 'vms_event_plan' ? $post_id : 0;

        if ($tec_event_id <= 0) {
            $tec_event_id = $this->resolve_tec_event_id_for_post($post);
        }

        if ($event_plan_id <= 0) {
            $event_plan_id = $this->resolve_event_plan_id_for_post($post, $tec_event_id);
        }

        $start_timestamp = $this->get_event_start_timestamp($post);
        $end_timestamp = $this->get_event_end_timestamp($post, $start_timestamp);
        $now = current_time('timestamp');

        $context = array(
            'post_id' => $post_id,
            'post_type' => $post_type,
            'post_status' => (string) $post->post_status,
            'tec_event_id' => $tec_event_id,
            'event_plan_id' => $event_plan_id,
            'start_timestamp' => $start_timestamp,
            'end_timestamp' => $end_timestamp,
            'canonical_key' => $this->event_canonical_key($tec_event_id, $event_plan_id, $post_id),
            'is_completed' => $end_timestamp > 0 ? $end_timestamp < $now : $start_timestamp < $now,
            'is_upcoming' => $start_timestamp > 0 ? $start_timestamp >= $now : false,
        );

        $status = $this->resolve_event_status($post, $context);
        $context['event_status_key'] = $status['key'];
        $context['event_status_label'] = $status['label'];
        $context['is_cancelled'] = $status['is_cancelled'];

        $this->event_context_cache[$post_id] = $context;

        return $context;
    }

    private function resolve_tec_event_id_for_post(WP_Post $post): int
    {
        $post_id = (int) $post->ID;
        $candidates = array();

        if ($post->post_type === 'tribe_events') {
            $candidates[] = $post_id;
        }

        if ($post->post_type === 'vms_event_plan') {
            $candidates[] = absint(get_post_meta($post_id, $this->plan_tec_meta_key(), true));
            if (vms_investor_has_core_function('vms_meta_key')) {
                $meta_key = (string) vms_investor_call_core_function('vms_meta_key', 'event_plan', 'tec_event_id');
                if ($meta_key !== '') {
                    $candidates[] = absint(get_post_meta($post_id, $meta_key, true));
                }
            }
        }

        $candidates[] = absint(get_post_meta($post_id, '_vms_tec_event_id', true));
        $candidates[] = absint(get_post_meta($post_id, '_vms_tec_event_post_id', true));
        $candidates[] = absint(get_post_meta($post_id, '_EventPostID', true));

        foreach ($candidates as $candidate) {
            if ($candidate > 0 && get_post($candidate) instanceof WP_Post) {
                return $candidate;
            }
        }

        return 0;
    }

    private function resolve_event_plan_id_for_post(WP_Post $post, int $tec_event_id): int
    {
        $post_id = (int) $post->ID;
        $candidates = array();

        if ($post->post_type === 'vms_event_plan') {
            $candidates[] = $post_id;
        }

        $candidates[] = absint(get_post_meta($post_id, '_vms_event_plan_id', true));

        if ($tec_event_id > 0) {
            if (vms_investor_has_core_function('vms_get_event_plan_for_tec_event')) {
                $candidates[] = absint(vms_investor_call_core_function('vms_get_event_plan_for_tec_event', $tec_event_id));
            }
            if (vms_investor_has_core_function('vms_ticketing_v2_find_plan_id_by_tec_event_id')) {
                $candidates[] = absint(vms_investor_call_core_function('vms_ticketing_v2_find_plan_id_by_tec_event_id', $tec_event_id));
            } elseif (vms_investor_has_core_function('vms_ticketing_v2_find_plan_id_by_tec_event')) {
                $candidates[] = absint(vms_investor_call_core_function('vms_ticketing_v2_find_plan_id_by_tec_event', $tec_event_id));
            }
        }

        foreach ($candidates as $candidate) {
            if ($candidate > 0 && get_post($candidate) instanceof WP_Post) {
                return $candidate;
            }
        }

        return 0;
    }

    private function event_canonical_key(int $tec_event_id, int $event_plan_id, int $post_id): string
    {
        if ($tec_event_id > 0) {
            return 'tec:' . $tec_event_id;
        }

        if ($event_plan_id > 0) {
            return 'plan:' . $event_plan_id;
        }

        return 'post:' . $post_id;
    }

    private function resolve_event_status(WP_Post $post, array $context): array
    {
        $post_status = sanitize_key((string) $post->post_status);
        $status_candidates = array();

        if (!empty($context['event_plan_id']) && vms_investor_has_core_function('vms_event_plan_get_status')) {
            $status_candidates[] = (string) vms_investor_call_core_function('vms_event_plan_get_status', (int) $context['event_plan_id'], 'dashboard');
            $status_candidates[] = (string) vms_investor_call_core_function('vms_event_plan_get_status', (int) $context['event_plan_id'], 'raw');
        }

        if (!empty($context['event_plan_id'])) {
            $status_candidates[] = (string) get_post_meta((int) $context['event_plan_id'], '_vms_event_plan_status', true);
            if (vms_investor_has_core_function('vms_meta_key')) {
                $meta_key = (string) vms_investor_call_core_function('vms_meta_key', 'event_plan', 'status');
                if ($meta_key !== '') {
                    $status_candidates[] = (string) get_post_meta((int) $context['event_plan_id'], $meta_key, true);
                }
            }
        }

        $status_candidates[] = (string) get_post_meta((int) $post->ID, '_EventStatus', true);
        $status_candidates[] = (string) get_post_meta((int) $post->ID, '_tribe_event_status', true);

        foreach ($status_candidates as $candidate) {
            $candidate = trim((string) $candidate);
            if ($candidate === '') {
                continue;
            }
            if (vms_investor_has_core_function('vms_event_plan_status_normalize')) {
                $candidate = (string) vms_investor_call_core_function('vms_event_plan_status_normalize', $candidate);
            }
            $normalized = sanitize_key(strtolower($candidate));
            if ($normalized === 'canceled') {
                $normalized = 'cancelled';
            }
            if ($normalized === 'cancelled') {
                return array(
                    'key' => 'cancelled',
                    'label' => __('Cancelled', 'vms-investor-portal'),
                    'is_cancelled' => true,
                );
            }
        }

        if (!empty($context['is_upcoming'])) {
            return array(
                'key' => 'upcoming',
                'label' => __('Upcoming', 'vms-investor-portal'),
                'is_cancelled' => false,
            );
        }

        if (!empty($context['is_completed'])) {
            return array(
                'key' => 'completed',
                'label' => __('Completed', 'vms-investor-portal'),
                'is_cancelled' => false,
            );
        }

        if ($post_status !== 'publish') {
            return array(
                'key' => $post_status,
                'label' => ucfirst(str_replace('-', ' ', $post_status)),
                'is_cancelled' => false,
            );
        }

        return array(
            'key' => 'live',
            'label' => __('In Progress', 'vms-investor-portal'),
            'is_cancelled' => false,
        );
    }

    private function event_is_reportable(WP_Post $post, array $context): bool
    {
        $exclude_cancelled = (bool) apply_filters('vms_investor_portal_exclude_cancelled_events', true, $post, $context);

        if ($exclude_cancelled && !empty($context['is_cancelled'])) {
            return false;
        }

        $reportable = $this->post_looks_like_event($post, $context);
        $reportable = (bool) apply_filters('vms_investor_portal_event_is_reportable', $reportable, $post, $context);

        return $reportable;
    }

    /**
     * @return string[]
     */
    private function get_event_post_types(): array
    {
        $defaults = array('tribe_events');
        $registered = get_post_types(array(), 'names');

        if (is_array($registered)) {
            foreach ($registered as $post_type) {
                $post_type = (string) $post_type;
                if ($this->is_default_supported_event_post_type($post_type)) {
                    $defaults[] = $post_type;
                }
            }
        }

        foreach (array('vms_event', 'vms_event_plan') as $candidate) {
            if (post_type_exists($candidate)) {
                $defaults[] = $candidate;
            }
        }

        $defaults = array_values(array_unique(array_filter(array_map('sanitize_key', $defaults))));
        $post_types = apply_filters('vms_investor_portal_event_post_types', $defaults);

        if (!is_array($post_types)) {
            return $defaults;
        }

        return array_values(array_unique(array_filter(array_map('sanitize_key', $post_types))));
    }

    private function is_default_supported_event_post_type(string $post_type): bool
    {
        $post_type = sanitize_key($post_type);

        if ($post_type === '' || !post_type_exists($post_type)) {
            return false;
        }

        if (in_array($post_type, array('tribe_events', 'vms_event', 'vms_event_plan'), true)) {
            return true;
        }

        if (strpos($post_type, 'vms_') !== 0 || strpos($post_type, 'event') === false) {
            return false;
        }

        foreach (array('credit', 'ledger', 'log', 'audit', 'note') as $blocked_fragment) {
            if (strpos($post_type, $blocked_fragment) !== false) {
                return false;
            }
        }

        $object = get_post_type_object($post_type);
        if (!$object) {
            return false;
        }

        $label = strtolower(trim((string) ($object->label ?? '')));

        return $label === '' || strpos($label, 'event') !== false;
    }

    /**
     * @return string[]
     */
    private function get_reportable_post_statuses(): array
    {
        $statuses = apply_filters('vms_investor_portal_reportable_post_statuses', array('publish'));

        if (!is_array($statuses)) {
            return array('publish');
        }

        $statuses = array_values(array_unique(array_filter(array_map('sanitize_key', $statuses))));

        return !empty($statuses) ? $statuses : array('publish');
    }

    private function post_looks_like_event(WP_Post $post, array $context): bool
    {
        $post_type = sanitize_key((string) $post->post_type);

        if ($post_type === 'tribe_events') {
            return true;
        }

        if (in_array($post_type, array('vms_event', 'vms_event_plan'), true)) {
            return $this->post_has_event_date_signal($post) || !empty($context['tec_event_id']) || !empty($context['event_plan_id']);
        }

        if ($this->post_has_event_date_signal($post)) {
            return true;
        }

        return !empty($context['tec_event_id']) || !empty($context['event_plan_id']);
    }

    private function post_has_event_date_signal(WP_Post $post): bool
    {
        $meta_keys = array(
            '_EventStartDate',
            '_tribe_EventStartDate',
            '_EventStartDateUTC',
            '_vms_event_plan_start_datetime',
            '_vms_event_start_datetime',
            '_vms_event_start',
            '_vms_event_date',
            'vms_event_date',
            '_vms_event_plan_date',
            'vms_event_plan_date',
            '_event_start_date',
            '_event_date',
        );

        foreach ($meta_keys as $meta_key) {
            $value = trim((string) get_post_meta((int) $post->ID, $meta_key, true));
            if ($this->parse_date_to_timestamp($value) > 0) {
                return true;
            }
        }

        return false;
    }

    private function get_event_start_timestamp(WP_Post $post): int
    {
        $meta_keys = array(
            '_EventStartDate',
            '_tribe_EventStartDate',
            '_EventStartDateUTC',
            '_vms_event_plan_start_datetime',
            '_vms_event_start_datetime',
            '_vms_event_start',
            '_vms_event_date',
            'vms_event_date',
            '_vms_event_plan_date',
            'vms_event_plan_date',
            '_event_start_date',
            '_event_date',
        );

        foreach ($meta_keys as $meta_key) {
            $value = trim((string) get_post_meta((int) $post->ID, $meta_key, true));
            $timestamp = $this->parse_date_to_timestamp($value);

            if ($timestamp > 0) {
                /** @var int $filtered */
                $filtered = (int) apply_filters('vms_investor_portal_event_start_date', $timestamp, $post);
                return $filtered;
            }
        }

        $fallback = $this->parse_date_to_timestamp((string) $post->post_date);
        if ($fallback > 0) {
            /** @var int $filtered */
            $filtered = (int) apply_filters('vms_investor_portal_event_start_date', $fallback, $post);
            return $filtered;
        }

        /** @var int $filtered */
        $filtered = (int) apply_filters('vms_investor_portal_event_start_date', current_time('timestamp'), $post);
        return $filtered;
    }

    private function get_event_end_timestamp(WP_Post $post, int $start_timestamp): int
    {
        $meta_keys = array(
            '_EventEndDate',
            '_tribe_EventEndDate',
            '_EventEndDateUTC',
            '_vms_event_plan_end_datetime',
            '_vms_event_end_datetime',
            '_vms_event_end',
            '_event_end_date',
        );

        foreach ($meta_keys as $meta_key) {
            $value = trim((string) get_post_meta((int) $post->ID, $meta_key, true));
            $timestamp = $this->parse_date_to_timestamp($value);

            if ($timestamp > 0) {
                /** @var int $filtered */
                $filtered = (int) apply_filters('vms_investor_portal_event_end_date', $timestamp, $post, $start_timestamp);
                return $filtered;
            }
        }

        /** @var int $filtered */
        $filtered = (int) apply_filters('vms_investor_portal_event_end_date', $start_timestamp, $post, $start_timestamp);
        return $filtered;
    }

    private function parse_date_to_timestamp(string $value): int
    {
        $value = trim($value);

        if ($value === '') {
            return 0;
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            $value .= ' 00:00:00';
        }

        try {
            $datetime = new DateTimeImmutable($value, wp_timezone());
            return $datetime->getTimestamp();
        } catch (Exception $exception) {
            unset($exception);
        }

        $timestamp = strtotime($value);

        return $timestamp ? (int) $timestamp : 0;
    }

    /**
     * @param array<int,array{post:WP_Post,context:array<string,mixed>}> $entries
     * @param array<int,array<string,mixed>> $records_map
     * @return array<int,array<string,mixed>>
     */
    private function build_records_from_entries(array $entries, array $records_map, string $sort = 'desc'): array
    {
        $records = array();

        foreach ($entries as $entry) {
            $post = $entry['post'];
            $context = $entry['context'];

            if (!($post instanceof WP_Post) || !is_array($context)) {
                continue;
            }

            $record = $this->get_financial_record_for_context($context, $records_map);
            if (!$record) {
                $record = $this->default_record((int) $post->ID);
            }

            $records[] = $this->build_display_record($post, $record, $context);
        }

        usort($records, $sort === 'asc' ? array($this, 'sort_display_records_ascending') : array($this, 'sort_display_records_descending'));

        return $records;
    }

    /**
     * @param array<string,mixed> $record
     * @param array<string,mixed>|null $context
     * @return array<string,mixed>
     */
    private function build_display_record(WP_Post $post, array $record, ?array $context = null): array
    {
        $context = is_array($context) ? $context : $this->get_event_context($post);
        $event_id = (int) $post->ID;
        $snapshot_state = $this->get_metrics_snapshot_state($post, $context, $record);
        $metrics_payload = $this->get_metrics_payload_for_display($post, $record, $context, $snapshot_state);
        $metrics = isset($metrics_payload['metrics']) && is_array($metrics_payload['metrics']) ? $metrics_payload['metrics'] : array();
        $ticket_actuals = isset($metrics_payload['ticket_actuals']) && is_array($metrics_payload['ticket_actuals']) ? $metrics_payload['ticket_actuals'] : array();
        $attendance_actuals = isset($metrics_payload['attendance_actuals']) && is_array($metrics_payload['attendance_actuals']) ? $metrics_payload['attendance_actuals'] : array();
        $metric = static function (string $key) use ($metrics): array {
            return isset($metrics[$key]) && is_array($metrics[$key]) ? $metrics[$key] : array();
        };

        $ticket_revenue_metric = $metric('ticket_revenue');
        $tickets_sold_metric = $metric('tickets_sold');
        $attendance_metric = $metric('attendance_total');
        $checked_in_metric = $metric('checked_in_scanned');
        $concession_metric = $metric('concession_sales');
        $labor_metric = $metric('labor_cost');
        $concession_cost_metric = $metric('concession_cost');
        $ad_spend_metric = $metric('ad_spend');
        $performer_metric = $metric('performer_cost');
        $overhead_metric = $metric('other_expenses');
        $estimated_tax_metric = $metric('estimated_sales_tax');
        $other_direct_metric = $metric('other_direct_costs');
        $estimated_net_metric = $metric('estimated_event_net');

        $ticket_revenue = (float) apply_filters(
            'vms_investor_portal_ticket_revenue',
            (float) ($ticket_revenue_metric['value'] ?? 0.0),
            $event_id,
            $record,
            $context,
            $ticket_actuals
        );
        $tickets_sold = (int) apply_filters(
            'vms_investor_portal_tickets_sold',
            (int) ($tickets_sold_metric['value'] ?? 0),
            $event_id,
            $record,
            $context,
            $ticket_actuals
        );
        $attendance_total = (int) apply_filters(
            'vms_investor_portal_attendance_total',
            (int) ($attendance_metric['value'] ?? 0),
            $event_id,
            $record,
            $context,
            (array) ($attendance_actuals['rows'] ?? array()),
            $attendance_actuals
        );
        $concession_sales = (float) apply_filters(
            'vms_investor_portal_concession_sales',
            (float) ($concession_metric['value'] ?? 0.0),
            $event_id,
            $record,
            $context
        );
        $labor_cost = (float) ($labor_metric['value'] ?? 0.0);
        $concession_cost = (float) ($concession_cost_metric['value'] ?? 0.0);
        $ad_spend = (float) ($ad_spend_metric['value'] ?? 0.0);
        $performer_cost = (float) ($performer_metric['value'] ?? 0.0);
        $other_expenses = (float) ($overhead_metric['value'] ?? 0.0);
        $estimated_event_net = (float) apply_filters(
            'vms_investor_portal_estimated_event_net',
            (float) ($estimated_net_metric['value'] ?? 0.0),
            $event_id,
            $record,
            array(
                'ticket_revenue' => $ticket_revenue,
                'tickets_sold' => $tickets_sold,
                'attendance_total' => $attendance_total,
                'concession_sales' => $concession_sales,
                'labor_cost' => $labor_cost,
                'concession_cost' => $concession_cost,
                'ad_spend' => $ad_spend,
                'performer_cost' => $performer_cost,
                'other_expenses' => $other_expenses,
            ),
            $context
        );

        $ticket_revenue_metric['value'] = $ticket_revenue;
        $tickets_sold_metric['value'] = $tickets_sold;
        $attendance_metric['value'] = $attendance_total;
        $concession_metric['value'] = $concession_sales;
        $estimated_net_metric['value'] = $estimated_event_net;
        $metrics['ticket_revenue'] = $ticket_revenue_metric;
        $metrics['tickets_sold'] = $tickets_sold_metric;
        $metrics['attendance_total'] = $attendance_metric;
        $metrics['concession_sales'] = $concession_metric;
        $metrics['estimated_event_net'] = $estimated_net_metric;

        return array(
            'event_id' => $event_id,
            'event_title' => get_the_title($post),
            'event_timestamp' => (int) ($context['start_timestamp'] ?? 0),
            'event_end_timestamp' => (int) ($context['end_timestamp'] ?? 0),
            'event_date_label' => $this->format_event_date((int) ($context['start_timestamp'] ?? 0)),
            'event_end_label' => $this->format_event_date((int) ($context['end_timestamp'] ?? 0)),
            'event_short_label' => $this->format_event_short_label((int) ($context['start_timestamp'] ?? 0)),
            'event_status_label' => (string) ($context['event_status_label'] ?? ''),
            'snapshot_status' => (string) ($snapshot_state['status'] ?? self::SNAPSHOT_STATUS_MISSING),
            'snapshot_status_label' => (string) ($snapshot_state['label'] ?? __('Missing', 'vms-investor-portal')),
            'snapshot_status_notice' => (string) ($snapshot_state['notice'] ?? ''),
            'snapshot_source_label' => (string) ($snapshot_state['source_label'] ?? __('Cached investor metrics snapshot', 'vms-investor-portal')),
            'snapshot_last_refreshed' => (string) ($snapshot_state['last_refreshed'] ?? ''),
            'snapshot_last_refreshed_label' => (string) ($snapshot_state['last_refreshed_label'] ?? ''),
            'snapshot_warnings' => (array) ($snapshot_state['warnings'] ?? array()),
            'snapshot_last_error' => (string) ($snapshot_state['last_error'] ?? ''),
            'post_type_label' => $this->post_type_label((string) $post->post_type),
            'metrics' => $metrics,
            'metric_warnings' => array_values(array_unique(array_filter(array_merge(
                isset($metrics_payload['warnings']) && is_array($metrics_payload['warnings']) ? $metrics_payload['warnings'] : array(),
                (array) ($snapshot_state['warnings'] ?? array())
            )))),
            'ticket_revenue_auto_available' => !empty($ticket_revenue_metric['auto_available']),
            'tickets_sold_auto_available' => !empty($tickets_sold_metric['auto_available']),
            'ticket_revenue_auto' => (float) ($ticket_revenue_metric['auto_value'] ?? 0.0),
            'tickets_sold_auto' => (int) ($tickets_sold_metric['auto_value'] ?? 0),
            'attendance_total_auto' => (int) ($attendance_metric['auto_value'] ?? 0),
            'attendance_available' => !empty($attendance_metric['auto_available']),
            'advance_ticket_revenue' => !empty($metric('online_ticket_sales')['available']) ? $this->nullable_float($metric('online_ticket_sales')['value'] ?? null) : null,
            'door_ticket_revenue' => !empty($metric('door_ticket_sales')['available']) ? $this->nullable_float($metric('door_ticket_sales')['value'] ?? null) : null,
            'advance_tickets_sold' => !empty($metric('online_tickets_sold')['available']) ? $this->nullable_integer($metric('online_tickets_sold')['value'] ?? null) : null,
            'door_tickets_sold' => !empty($metric('door_tickets_sold')['available']) ? $this->nullable_integer($metric('door_tickets_sold')['value'] ?? null) : null,
            'checked_in_scanned' => (int) ($checked_in_metric['value'] ?? 0),
            'checked_in_available' => !empty($checked_in_metric['available']),
            'ticket_revenue_auto_source_label' => (string) ($ticket_revenue_metric['auto_source_label'] ?? __('Not available', 'vms-investor-portal')),
            'tickets_sold_auto_source_label' => (string) ($tickets_sold_metric['auto_source_label'] ?? __('Not available', 'vms-investor-portal')),
            'attendance_auto_source_label' => (string) ($attendance_metric['auto_source_label'] ?? __('Not available', 'vms-investor-portal')),
            'checked_in_source_label' => (string) ($checked_in_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'ticket_revenue' => $ticket_revenue,
            'tickets_sold' => $tickets_sold,
            'attendance_total' => $attendance_total,
            'ticket_revenue_source_type' => (string) ($ticket_revenue_metric['source_type'] ?? 'not_available'),
            'tickets_sold_source_type' => (string) ($tickets_sold_metric['source_type'] ?? 'not_available'),
            'attendance_source_type' => (string) ($attendance_metric['source_type'] ?? 'not_available'),
            'ticket_revenue_source_label' => (string) ($ticket_revenue_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'tickets_sold_source_label' => (string) ($tickets_sold_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'attendance_source_label' => (string) ($attendance_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'ticket_revenue_breakdown_lines' => (array) ($ticket_revenue_metric['breakdown_lines'] ?? array()),
            'tickets_sold_breakdown_lines' => (array) ($tickets_sold_metric['breakdown_lines'] ?? array()),
            'attendance_breakdown_lines' => (array) ($attendance_metric['breakdown_lines'] ?? array()),
            'ticket_revenue_override_active' => !empty($ticket_revenue_metric['manual_override_active']),
            'tickets_sold_override_active' => !empty($tickets_sold_metric['manual_override_active']),
            'attendance_total_override_active' => !empty($attendance_metric['manual_override_active']),
            'concession_sales' => $concession_sales,
            'labor_cost' => $labor_cost,
            'concession_cost' => $concession_cost,
            'ad_spend' => $ad_spend,
            'performer_cost' => $performer_cost,
            'other_expenses' => $other_expenses,
            'website_addons' => (float) ($metric('website_addons')['value'] ?? 0.0),
            'website_addons_available' => !empty($metric('website_addons')['available']),
            'bar_sales' => (float) ($metric('bar_sales')['value'] ?? 0.0),
            'bar_sales_available' => !empty($metric('bar_sales')['available']),
            'food_sales' => (float) ($metric('food_sales')['value'] ?? 0.0),
            'food_sales_available' => !empty($metric('food_sales')['available']),
            'merch_sales' => (float) ($metric('merch_sales')['value'] ?? 0.0),
            'merch_sales_available' => !empty($metric('merch_sales')['available']),
            'other_direct_costs' => (float) ($other_direct_metric['value'] ?? 0.0),
            'other_direct_costs_available' => !empty($other_direct_metric['available']),
            'estimated_sales_tax' => (float) ($estimated_tax_metric['value'] ?? 0.0),
            'estimated_sales_tax_available' => !empty($estimated_tax_metric['available']),
            'estimated_sales_tax_source_label' => (string) ($estimated_tax_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'estimated_sales_tax_breakdown_lines' => (array) ($estimated_tax_metric['breakdown_lines'] ?? array()),
            'concession_sales_source_type' => (string) ($concession_metric['source_type'] ?? 'not_available'),
            'concession_sales_source_label' => (string) ($concession_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'concession_sales_breakdown_lines' => (array) ($concession_metric['breakdown_lines'] ?? array()),
            'concession_sales_override_active' => !empty($concession_metric['manual_override_active']),
            'labor_cost_source_type' => (string) ($labor_metric['source_type'] ?? 'not_available'),
            'labor_cost_source_label' => (string) ($labor_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'labor_cost_override_active' => !empty($labor_metric['manual_override_active']),
            'concession_cost_source_type' => (string) ($concession_cost_metric['source_type'] ?? 'not_available'),
            'concession_cost_source_label' => (string) ($concession_cost_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'concession_cost_override_active' => !empty($concession_cost_metric['manual_override_active']),
            'ad_spend_source_type' => (string) ($ad_spend_metric['source_type'] ?? 'not_available'),
            'ad_spend_source_label' => (string) ($ad_spend_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'ad_spend_override_active' => !empty($ad_spend_metric['manual_override_active']),
            'performer_cost_source_type' => (string) ($performer_metric['source_type'] ?? 'not_available'),
            'performer_cost_source_label' => (string) ($performer_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'performer_cost_override_active' => !empty($performer_metric['manual_override_active']),
            'other_expenses_source_type' => (string) ($overhead_metric['source_type'] ?? 'not_available'),
            'other_expenses_source_label' => (string) ($overhead_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'other_expenses_breakdown_lines' => (array) ($overhead_metric['breakdown_lines'] ?? array()),
            'other_expenses_override_active' => !empty($overhead_metric['manual_override_active']),
            'estimated_event_net' => $estimated_event_net,
            'estimated_event_net_source_type' => (string) ($estimated_net_metric['source_type'] ?? 'not_available'),
            'estimated_event_net_source_label' => (string) ($estimated_net_metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'estimated_event_net_breakdown_lines' => (array) ($estimated_net_metric['breakdown_lines'] ?? array()),
            'estimated_event_net_override_active' => !empty($estimated_net_metric['manual_override_active']),
            'notes' => (string) $record['notes'],
            'projected_ticket_revenue' => $this->nullable_float($record['projected_ticket_revenue']),
            'projected_tickets_sold' => $this->nullable_integer($record['projected_tickets_sold']),
            'projected_attendance_total' => $this->nullable_integer($record['projected_attendance_total']),
            'projected_concession_sales' => $this->nullable_float($record['projected_concession_sales']),
            'projected_event_net' => $this->nullable_float($record['projected_event_net']),
            'projection_notes' => (string) $record['projection_notes'],
            'has_projection' => $this->record_has_projection($record),
        );
    }

    /**
     * @param array<string,mixed> $record
     * @return array<string,mixed>
     */
    private function resolve_ticket_actuals(WP_Post $post, array $record, array $context): array
    {
        $cache_key = implode(':', array(
            absint($context['tec_event_id'] ?? 0),
            absint($context['event_plan_id'] ?? 0),
            implode(',', $this->get_paid_order_statuses()),
        ));

        if (isset($this->ticket_actuals_cache[$cache_key])) {
            return $this->ticket_actuals_cache[$cache_key];
        }

        $result = array(
            'available' => false,
            'partial_only' => false,
            'ticket_revenue' => 0.0,
            'tickets_sold' => 0,
            'advance_ticket_revenue' => null,
            'door_ticket_revenue' => null,
            'advance_tickets_sold' => null,
            'door_tickets_sold' => null,
            'revenue_source_label' => __('Not available', 'vms-investor-portal'),
            'tickets_source_label' => __('Not available', 'vms-investor-portal'),
            'advance_revenue_source_label' => '',
            'door_revenue_source_label' => '',
            'advance_tickets_source_label' => '',
            'door_tickets_source_label' => '',
        );

        $event_plan_id = (int) ($context['event_plan_id'] ?? 0);
        $tec_event_id = (int) ($context['tec_event_id'] ?? 0);

        if ($event_plan_id > 0 && $this->ensure_data_tools_reporting_module()) {
            try {
                $model = (array) vms_dt_reporting_build_event_model(array(
                    'event_plan_id' => $event_plan_id,
                    'event_from' => '',
                    'event_to' => '',
                    'sold_from' => '',
                    'sold_to' => '',
                    'venue_id' => 0,
                    'square_location_id' => '',
                    'square_scope_mode' => 'full_day',
                    'compare' => 0,
                ));

                $costs = isset($model['costs']) && is_array($model['costs']) ? (array) $model['costs'] : array();
                $summary = isset($model['summary']) && is_array($model['summary']) ? (array) $model['summary'] : array();
                $row = isset($model['row']) && is_array($model['row']) ? (array) $model['row'] : array();

                $advance_ticket_revenue_cents = max(0, (int) ($summary['online_ticket_sales_cents'] ?? ($row['website_ticket_net_cents'] ?? 0)));
                $door_ticket_revenue_cents = max(0, (int) ($summary['door_ticket_sales_cents'] ?? ($row['square_direct_tickets_cents'] ?? 0)));
                $ticket_revenue_cents = max(0, (int) ($costs['ticket_sales_total_cents'] ?? ($summary['total_ticket_sales_cents'] ?? ($advance_ticket_revenue_cents + $door_ticket_revenue_cents))));

                $advance_tickets_sold = max(0, (int) ($row['website_paid_ticket_qty'] ?? ($summary['online_ticket_qty'] ?? 0)));
                $door_tickets_sold = max(0, (int) (($row['square_paid_ticket_qty'] ?? ($row['door_paid_ticket_qty'] ?? ($summary['door_ticket_qty'] ?? 0)))));
                $tickets_sold = max(0, (int) ($costs['paid_ticket_qty_total'] ?? ($advance_tickets_sold + $door_tickets_sold)));

                if ($tickets_sold <= 0 && ($advance_tickets_sold > 0 || $door_tickets_sold > 0)) {
                    $tickets_sold = $advance_tickets_sold + $door_tickets_sold;
                }

                if ($ticket_revenue_cents > 0 || $tickets_sold > 0 || $advance_ticket_revenue_cents > 0 || $door_ticket_revenue_cents > 0 || $advance_tickets_sold > 0 || $door_tickets_sold > 0) {
                    $source_label = __('Data Tools reporting model', 'vms-investor-portal');
                    $result = array(
                        'available' => true,
                        'partial_only' => false,
                        'ticket_revenue' => $ticket_revenue_cents / 100,
                        'tickets_sold' => $tickets_sold,
                        'advance_ticket_revenue' => $advance_ticket_revenue_cents / 100,
                        'door_ticket_revenue' => $door_ticket_revenue_cents / 100,
                        'advance_tickets_sold' => $advance_tickets_sold,
                        'door_tickets_sold' => $door_tickets_sold,
                        'revenue_source_label' => $source_label,
                        'tickets_source_label' => $source_label,
                        'advance_revenue_source_label' => __('WooCommerce online orders', 'vms-investor-portal'),
                        'door_revenue_source_label' => __('Door orders', 'vms-investor-portal'),
                        'advance_tickets_source_label' => __('WooCommerce online orders', 'vms-investor-portal'),
                        'door_tickets_source_label' => __('Door orders', 'vms-investor-portal'),
                    );
                    $this->ticket_actuals_cache[$cache_key] = $result;
                    return $result;
                }
            } catch (Throwable $exception) {
                unset($exception);
            }
        }

        if ($event_plan_id > 0 && vms_investor_has_core_function('vms_event_command_center_get_ticket_reporting_truth')) {
            try {
                $truth = (array) vms_investor_call_core_function('vms_event_command_center_get_ticket_reporting_truth', $event_plan_id);
                if (!empty($truth['available'])) {
                    $source_label = trim((string) ($truth['source_label'] ?? ''));
                    if ($source_label === '') {
                        $source_label = __('VMS ticket reporting', 'vms-investor-portal');
                    }
                    $result = array(
                        'available' => true,
                        'ticket_revenue' => max(0, (int) ($truth['revenue_cents'] ?? 0)) / 100,
                        'tickets_sold' => max(0, (int) ($truth['paid_qty'] ?? 0)),
                        'revenue_source_label' => $source_label,
                        'tickets_source_label' => $source_label,
                    );
                    $this->ticket_actuals_cache[$cache_key] = $result;
                    return $result;
                }
            } catch (Throwable $exception) {
                unset($exception);
            }
        }

        if (vms_investor_has_core_function('vms_ticket_revenue_build_report')) {
            try {
                $report = (array) vms_investor_call_core_function('vms_ticket_revenue_build_report', array(
                    'event_plan_id' => $event_plan_id,
                    'tec_event_id' => $tec_event_id,
                    'recognition_status' => 'all',
                    'order_statuses' => $this->get_paid_order_statuses(),
                    'preview_limit' => 500,
                    'unresolved_limit' => 50,
                ));
                $ticket_revenue = 0.0;
                $tickets_sold = 0;

                foreach ((array) ($report['rows'] ?? array()) as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $item_kind = sanitize_key((string) ($row['item_kind'] ?? 'ticket'));
                    if (in_array($item_kind, array('addon', 'entitlement'), true)) {
                        continue;
                    }
                    $quantity = max(0, (int) ($row['quantity'] ?? 0));
                    $refunded_quantity = max(0, (int) ($row['refunded_quantity'] ?? 0));
                    $net_quantity = max(0, $quantity - $refunded_quantity);
                    $net_cents = max(0, (int) ($row['net_subtotal_cents'] ?? 0));

                    if ($net_cents > 0) {
                        $tickets_sold += $net_quantity;
                    }
                    $ticket_revenue += $net_cents / 100;
                }

                if ($ticket_revenue > 0 || $tickets_sold > 0) {
                    $source_label = __('WooCommerce online orders only', 'vms-investor-portal');
                    $result = array(
                        'available' => false,
                        'partial_only' => true,
                        'ticket_revenue' => 0.0,
                        'tickets_sold' => 0,
                        'advance_ticket_revenue' => $ticket_revenue,
                        'door_ticket_revenue' => null,
                        'advance_tickets_sold' => $tickets_sold,
                        'door_tickets_sold' => null,
                        'revenue_source_label' => __('Total ticket revenue unavailable without door data', 'vms-investor-portal'),
                        'tickets_source_label' => __('Total tickets sold unavailable without door data', 'vms-investor-portal'),
                        'advance_revenue_source_label' => $source_label,
                        'door_revenue_source_label' => '',
                        'advance_tickets_source_label' => $source_label,
                        'door_tickets_source_label' => '',
                    );
                }
            } catch (Throwable $exception) {
                unset($exception);
            }
        }

        $result['ticket_revenue'] = max(0, (float) $result['ticket_revenue']);
        $result['tickets_sold'] = max(0, (int) $result['tickets_sold']);
        $this->ticket_actuals_cache[$cache_key] = $result;

        return $result;
    }

    /**
     * @param array<string,mixed> $record
     * @return array<string,mixed>
     */
    private function resolve_attendance_actuals(WP_Post $post, array $record, array $context, array $ticket_actuals = array()): array
    {
        $this->ensure_data_tools_reporting_module();

        $attendance_event_id = (int) ($context['tec_event_id'] ?? 0);
        $attendance_source = sanitize_key((string) $post->post_type);
        if ($attendance_event_id <= 0) {
            $attendance_event_id = (int) $post->ID;
        }

        $cache_key = $attendance_event_id . ':' . $attendance_source;

        if (isset($this->attendance_actuals_cache[$cache_key])) {
            return $this->attendance_actuals_cache[$cache_key];
        }

        $result = array(
            'available' => false,
            'value' => 0,
            'source_label' => __('Not available', 'vms-investor-portal'),
            'mode' => 'none',
            'ticketed_total' => 0,
            'admissions_total' => 0,
            'true_headcount_total' => 0,
            'checked_in_available' => false,
            'checked_in' => 0,
            'checked_in_source_label' => __('Not available', 'vms-investor-portal'),
            'rows' => array(),
        );

        $checked_in = $this->resolve_checked_in_actuals($attendance_event_id, $attendance_source);
        $result['checked_in_available'] = !empty($checked_in['available']);
        $result['checked_in'] = (int) ($checked_in['value'] ?? 0);
        $result['checked_in_source_label'] = (string) ($checked_in['source_label'] ?? __('Not available', 'vms-investor-portal'));
        $result['rows'] = (array) ($checked_in['rows'] ?? array());

        $event_plan_id = (int) ($context['event_plan_id'] ?? 0);

        if ($event_plan_id > 0) {
            $true_headcount = max(0, (int) get_post_meta($event_plan_id, '_vms_true_headcount', true));
            $true_comp_headcount = max(0, (int) get_post_meta($event_plan_id, '_vms_comp_headcount_true', true));
            $true_headcount_total = $true_headcount > 0 ? $true_headcount + $true_comp_headcount : 0;

            if ($true_headcount_total > 0) {
                $result['available'] = true;
                $result['value'] = $true_headcount_total;
                $result['source_label'] = __('True headcount', 'vms-investor-portal');
                $result['mode'] = 'true_headcount';
                $result['true_headcount_total'] = $true_headcount_total;
                $this->attendance_actuals_cache[$cache_key] = $result;
                return $result;
            }

            $ticketed_total = 0;
            $ticket_source_label = '';
            if (vms_investor_has_core_function('vms_event_command_center_get_ticket_snapshot')) {
                try {
                    $snapshot = (array) vms_investor_call_core_function('vms_event_command_center_get_ticket_snapshot', $event_plan_id);
                    $ticketed_total = max(0, (int) ($snapshot['total_ticket_count'] ?? 0));
                    $ticket_source_label = trim((string) ($snapshot['ticket_source_label'] ?? ''));
                } catch (Throwable $exception) {
                    unset($exception);
                }
            } elseif (!empty($ticket_actuals['available']) && isset($ticket_actuals['tickets_sold'])) {
                $ticketed_total = max(0, (int) $ticket_actuals['tickets_sold']);
                $ticket_source_label = trim((string) ($ticket_actuals['tickets_source_label'] ?? ''));
            }

            $admissions_total = $this->get_admissions_headcount($event_plan_id);
            $attendance_total = max(0, $ticketed_total + $admissions_total);

            if ($attendance_total > 0) {
                $result['available'] = true;
                $result['value'] = $attendance_total;
                $result['mode'] = $admissions_total > 0
                    ? ($ticketed_total > 0 ? 'ticket_plus_admissions' : 'admissions_only')
                    : 'ticket_only';
                $result['ticketed_total'] = $ticketed_total;
                $result['admissions_total'] = $admissions_total;
                if ($admissions_total > 0 && $ticketed_total > 0) {
                    $result['source_label'] = __('Ticket reporting + admissions', 'vms-investor-portal');
                } elseif ($admissions_total > 0) {
                    $result['source_label'] = __('Admissions records', 'vms-investor-portal');
                } elseif ($ticket_source_label !== '') {
                    $result['source_label'] = $ticket_source_label;
                } else {
                    $result['source_label'] = __('Ticket reporting', 'vms-investor-portal');
                }
                $this->attendance_actuals_cache[$cache_key] = $result;
                return $result;
            }
        }

        if (vms_investor_has_core_function('vms_staffing_get_event_plan_headcount_context') && $event_plan_id > 0) {
            try {
                $headcount_context = (array) vms_investor_call_core_function('vms_staffing_get_event_plan_headcount_context', $event_plan_id);
                $headcount = max(0, (int) ($headcount_context['headcount'] ?? 0));
                if (!empty($headcount_context['wired']) && $headcount > 0) {
                    $result['available'] = true;
                    $result['value'] = $headcount;
                    $result['source_label'] = __('Expected attendance', 'vms-investor-portal');
                    $result['mode'] = 'expected_attendance';
                }
            } catch (Throwable $exception) {
                unset($exception);
            }
        }

        $result['value'] = (int) apply_filters(
            'vms_investor_portal_attendance_total',
            (int) $result['value'],
            (int) $post->ID,
            $record,
            $context,
            $result['rows'],
            $result
        );
        $result['available'] = $result['value'] > 0 ? true : !empty($result['available']);

        $this->attendance_actuals_cache[$cache_key] = $result;

        return $result;
    }

    private function ensure_data_tools_reporting_module(): bool
    {
        if (function_exists('vms_dt_reporting_build_event_model')) {
            return true;
        }

        $candidates = array();
        if (defined('VMS_DT_ADMIN_DIR')) {
            $candidates[] = VMS_DT_ADMIN_DIR . 'page-revenue-intelligence.php';
            $candidates[] = VMS_DT_ADMIN_DIR . 'page-reporting-module.php';
        }
        if (defined('WP_PLUGIN_DIR')) {
            $candidates[] = WP_PLUGIN_DIR . '/vms-data-tools/includes/admin/page-revenue-intelligence.php';
            $candidates[] = WP_PLUGIN_DIR . '/vms-data-tools/includes/admin/page-reporting-module.php';
        }

        foreach (array_unique($candidates) as $candidate) {
            if (!is_string($candidate) || $candidate === '' || !is_readable($candidate)) {
                continue;
            }
            require_once $candidate;
            if (function_exists('vms_dt_reporting_build_event_model')) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array<string,mixed>
     */
    private function resolve_checked_in_actuals(int $attendance_event_id, string $attendance_source): array
    {
        $result = array(
            'available' => false,
            'value' => 0,
            'source_label' => __('Not available', 'vms-investor-portal'),
            'rows' => array(),
        );

        if (!function_exists('vms_ops_ticket_get_event_attendees') || $attendance_event_id <= 0) {
            return $result;
        }

        try {
            $rows = (array) vms_ops_ticket_get_event_attendees($attendance_event_id, $attendance_source);
            $count = 0;

            foreach ($rows as $attendee) {
                if (!is_array($attendee)) {
                    continue;
                }

                $kind = sanitize_key((string) ($attendee['kind'] ?? ''));
                if ($kind === 'guest_list') {
                    $count += max(0, (int) ($attendee['checked_in_qty'] ?? 0));
                    continue;
                }

                if (!empty($attendee['checked_in_local']) || !empty($attendee['checked_in'])) {
                    $count++;
                }
            }

            if (!empty($rows) || $count > 0) {
                $result = array(
                    'available' => true,
                    'value' => max(0, $count),
                    'source_label' => __('VMS Ops check-ins', 'vms-investor-portal'),
                    'rows' => $rows,
                );
            }
        } catch (Throwable $exception) {
            unset($exception);
        }

        return $result;
    }

    private function get_admissions_headcount(int $event_plan_id): int
    {
        $event_plan_id = absint($event_plan_id);
        if ($event_plan_id <= 0 || !vms_investor_has_core_function('vms_admission_table_entries')) {
            return 0;
        }

        global $wpdb;
        $table = vms_investor_call_core_function('vms_admission_table_entries');
        if (!$wpdb || !is_string($table) || $table === '') {
            return 0;
        }

        static $table_exists_cache = array();
        if (!array_key_exists($table, $table_exists_cache)) {
            $table_exists_cache[$table] = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table);
        }

        if (empty($table_exists_cache[$table])) {
            return 0;
        }

        return max(0, (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(CASE WHEN status <> 'canceled' THEN party_size ELSE 0 END), 0)
             FROM {$table}
             WHERE event_plan_id = %d",
            $event_plan_id
        )));
    }

    /**
     * @param array<string,mixed> $ticket_actuals
     * @return string[]
     */
    private function build_ticket_revenue_breakdown_lines(array $ticket_actuals): array
    {
        $lines = array();

        if (null !== ($ticket_actuals['advance_ticket_revenue'] ?? null)) {
            $lines[] = sprintf(
                __('Advance / online: %1$s from %2$s.', 'vms-investor-portal'),
                $this->format_currency((float) $ticket_actuals['advance_ticket_revenue']),
                (string) ($ticket_actuals['advance_revenue_source_label'] ?? __('WooCommerce online orders', 'vms-investor-portal'))
            );
        }

        if (null !== ($ticket_actuals['door_ticket_revenue'] ?? null)) {
            $lines[] = sprintf(
                __('Door: %1$s from %2$s.', 'vms-investor-portal'),
                $this->format_currency((float) $ticket_actuals['door_ticket_revenue']),
                (string) ($ticket_actuals['door_revenue_source_label'] ?? __('Door orders', 'vms-investor-portal'))
            );
        }

        if (!empty($ticket_actuals['partial_only'])) {
            $lines[] = __('Only advance / online orders were detected automatically. Use a manual override when door revenue is missing from reporting.', 'vms-investor-portal');
        }

        return $lines;
    }

    /**
     * @param array<string,mixed> $ticket_actuals
     * @return string[]
     */
    private function build_ticket_sold_breakdown_lines(array $ticket_actuals): array
    {
        $lines = array();

        if (null !== ($ticket_actuals['advance_tickets_sold'] ?? null)) {
            $lines[] = sprintf(
                __('Advance / online: %1$s from %2$s.', 'vms-investor-portal'),
                number_format_i18n((int) $ticket_actuals['advance_tickets_sold']),
                (string) ($ticket_actuals['advance_tickets_source_label'] ?? __('WooCommerce online orders', 'vms-investor-portal'))
            );
        }

        if (null !== ($ticket_actuals['door_tickets_sold'] ?? null)) {
            $lines[] = sprintf(
                __('Door: %1$s from %2$s.', 'vms-investor-portal'),
                number_format_i18n((int) $ticket_actuals['door_tickets_sold']),
                (string) ($ticket_actuals['door_tickets_source_label'] ?? __('Door orders', 'vms-investor-portal'))
            );
        }

        if (!empty($ticket_actuals['partial_only'])) {
            $lines[] = __('Only advance / online ticket counts were detected automatically. Use a manual override when door counts are missing from reporting.', 'vms-investor-portal');
        }

        return $lines;
    }

    /**
     * @param array<string,mixed> $attendance_actuals
     * @return string[]
     */
    private function build_attendance_breakdown_lines(array $attendance_actuals): array
    {
        $lines = array();
        $mode = sanitize_key((string) ($attendance_actuals['mode'] ?? ''));
        $ticketed_total = max(0, (int) ($attendance_actuals['ticketed_total'] ?? 0));
        $admissions_total = max(0, (int) ($attendance_actuals['admissions_total'] ?? 0));
        $true_headcount_total = max(0, (int) ($attendance_actuals['true_headcount_total'] ?? 0));

        if ($mode === 'true_headcount' && $true_headcount_total > 0) {
            $lines[] = __('Total attendance is using the saved true headcount on the event plan.', 'vms-investor-portal');
        } elseif ($mode === 'ticket_plus_admissions') {
            $lines[] = sprintf(
                __('Ticket/admitted count: %1$s, plus %2$s from admissions records.', 'vms-investor-portal'),
                number_format_i18n($ticketed_total),
                number_format_i18n($admissions_total)
            );
        } elseif ($mode === 'admissions_only' && $admissions_total > 0) {
            $lines[] = sprintf(
                __('Admissions records: %1$s.', 'vms-investor-portal'),
                number_format_i18n($admissions_total)
            );
        } elseif ($mode === 'ticket_only' && $ticketed_total > 0) {
            $lines[] = sprintf(
                __('Ticket/admitted count from reporting: %1$s.', 'vms-investor-portal'),
                number_format_i18n($ticketed_total)
            );
        }

        if (!empty($attendance_actuals['checked_in_available'])) {
            $lines[] = sprintf(
                __('Checked in / scanned: %1$s from %2$s.', 'vms-investor-portal'),
                number_format_i18n((int) ($attendance_actuals['checked_in'] ?? 0)),
                (string) ($attendance_actuals['checked_in_source_label'] ?? __('VMS Ops check-ins', 'vms-investor-portal'))
            );
        }

        return $lines;
    }

    /**
     * @param array<string,mixed> $record
     * @return array<string,mixed>
     */
    private function resolve_override_value(array $record, string $override_key, string $legacy_key, string $type): array
    {
        $default = array(
            'active' => false,
            'origin' => '',
            'value' => null,
        );

        if (array_key_exists($override_key, $record) && null !== $record[$override_key] && '' !== (string) $record[$override_key]) {
            $default['active'] = true;
            $default['origin'] = 'manual_override';
            $default['value'] = $type === 'decimal' ? (float) $record[$override_key] : (int) $record[$override_key];
            return $default;
        }

        if ($type === 'decimal' && isset($record[$legacy_key]) && (float) $record[$legacy_key] !== 0.0) {
            $default['active'] = true;
            $default['origin'] = 'legacy_manual';
            $default['value'] = (float) $record[$legacy_key];
            return $default;
        }

        if ($type === 'int' && isset($record[$legacy_key]) && (int) $record[$legacy_key] !== 0) {
            $default['active'] = true;
            $default['origin'] = 'legacy_manual';
            $default['value'] = (int) $record[$legacy_key];
            return $default;
        }

        return $default;
    }

    /**
     * @return string[]
     */
    private function get_paid_order_statuses(): array
    {
        $defaults = array();

        if (function_exists('wc_get_order_statuses')) {
            foreach ((array) wc_get_order_statuses() as $status => $label) {
                $slug = sanitize_key(str_replace('wc-', '', (string) $status));

                if ($slug === '') {
                    continue;
                }

                if (preg_match('/cancel|refund|fail|pending|draft|trash/i', $slug)) {
                    continue;
                }

                if (in_array($slug, array('processing', 'completed'), true) || strpos($slug, 'paid') !== false) {
                    $defaults[] = $slug;
                }

                if (preg_match('/paid/i', (string) $label)) {
                    $defaults[] = $slug;
                }
            }
        }

        if (empty($defaults)) {
            $defaults = array('processing', 'completed');
        }

        $statuses = apply_filters('vms_investor_portal_paid_order_statuses', array_values(array_unique($defaults)));

        if (!is_array($statuses) || empty($statuses)) {
            return array('processing', 'completed');
        }

        return array_values(array_unique(array_filter(array_map('sanitize_key', $statuses))));
    }

    private function plan_tec_meta_key(): string
    {
        if (vms_investor_has_core_function('vms_ticket_revenue_plan_tec_meta_key')) {
            return (string) vms_investor_call_core_function('vms_ticket_revenue_plan_tec_meta_key');
        }

        return '_vms_tec_event_id';
    }

    private function format_event_date(int $timestamp): string
    {
        if ($timestamp <= 0) {
            return esc_html__('Unknown date', 'vms-investor-portal');
        }

        return wp_date(get_option('date_format'), $timestamp, wp_timezone());
    }

    private function format_event_short_label(int $timestamp): string
    {
        if ($timestamp <= 0) {
            return '';
        }

        return wp_date('M j', $timestamp, wp_timezone());
    }

    private function post_type_label(string $post_type): string
    {
        $object = get_post_type_object($post_type);

        if ($object && isset($object->labels->singular_name) && is_string($object->labels->singular_name) && $object->labels->singular_name !== '') {
            return $object->labels->singular_name;
        }

        return ucfirst(str_replace(array('_', '-'), ' ', $post_type));
    }

    private function currency_symbol(): string
    {
        if (function_exists('get_woocommerce_currency_symbol')) {
            $currency_code = (string) get_option('woocommerce_currency', 'USD');
            $symbol = get_woocommerce_currency_symbol($currency_code);
            if (is_string($symbol) && $symbol !== '') {
                return html_entity_decode($symbol, ENT_QUOTES, 'UTF-8');
            }
        }

        return '$';
    }

    private function format_currency(float $amount): string
    {
        $sign = $amount < 0 ? '-' : '';
        $formatted = number_format_i18n(abs($amount), 2);

        return $sign . $this->currency_symbol() . $formatted;
    }

    private function format_optional_currency($amount): string
    {
        if (null === $amount || '' === (string) $amount) {
            return __('Not available', 'vms-investor-portal');
        }

        return $this->format_currency((float) $amount);
    }

    private function format_optional_count($value): string
    {
        if (null === $value || '' === (string) $value) {
            return __('Not available', 'vms-investor-portal');
        }

        return number_format_i18n((int) $value);
    }

    private function format_net_badge(float $amount): string
    {
        $is_negative = $amount < 0;
        $class = $is_negative ? 'vmsip-net vmsip-net--negative' : 'vmsip-net vmsip-net--positive';
        $label = $is_negative
            ? __('Estimated Event Net (Negative)', 'vms-investor-portal')
            : __('Estimated Event Net', 'vms-investor-portal');

        return '<span class="' . esc_attr($class) . '">' . esc_html($label . ': ' . $this->format_currency($amount)) . '</span>';
    }

    /**
     * @param array<string,mixed> $metric
     */
    private function format_metric_net_badge(array $metric): string
    {
        if (empty($metric['available'])) {
            return '<span class="vmsip-net vmsip-net--neutral">' . esc_html__('Estimated Event Net: Not available', 'vms-investor-portal') . '</span>';
        }

        return $this->format_net_badge((float) ($metric['value'] ?? 0.0));
    }

    private function manual_override_label(string $origin): string
    {
        if ($origin === 'legacy_manual') {
            return __('Manual override (legacy)', 'vms-investor-portal');
        }

        return __('Manual override', 'vms-investor-portal');
    }

    private function register_style(): void
    {
        if (wp_style_is('vms-investor-portal', 'registered')) {
            return;
        }

        wp_register_style(
            'vms-investor-portal',
            VMS_INVESTOR_PORTAL_URL . 'assets/css/vms-investor-portal.css',
            array(),
            VMS_INVESTOR_PORTAL_VERSION
        );
    }

    private function register_script(): void
    {
        if (wp_script_is('vms-investor-portal', 'registered')) {
            return;
        }

        wp_register_script(
            'vms-investor-portal',
            VMS_INVESTOR_PORTAL_URL . 'assets/js/vms-investor-portal.js',
            array(),
            VMS_INVESTOR_PORTAL_VERSION,
            true
        );
    }

    private function sanitize_decimal_input($value, bool $allow_null = false): ?string
    {
        if (is_array($value)) {
            $value = '';
        }

        $value = wp_unslash((string) $value);
        $value = str_replace(array(',', '$', ' '), '', $value);
        $value = trim($value);

        if ($value === '') {
            return $allow_null ? null : '0.00';
        }

        if (!is_numeric($value)) {
            return $allow_null ? null : '0.00';
        }

        return number_format(max(0, (float) $value), 2, '.', '');
    }

    private function sanitize_integer_input($value, bool $allow_null = false): ?int
    {
        if (is_array($value)) {
            $value = '';
        }

        $value = trim(wp_unslash((string) $value));

        if ($value === '') {
            return $allow_null ? null : 0;
        }

        return max(0, absint($value));
    }

    private function normalize_decimal_string($value): string
    {
        return number_format((float) $value, 2, '.', '');
    }

    private function normalize_nullable_decimal_string($value): ?string
    {
        if (null === $value || '' === (string) $value) {
            return null;
        }

        return number_format((float) $value, 2, '.', '');
    }

    private function normalize_nullable_integer($value): ?int
    {
        if (null === $value || '' === (string) $value) {
            return null;
        }

        return max(0, absint($value));
    }

    private function nullable_float($value): ?float
    {
        if (null === $value || '' === (string) $value) {
            return null;
        }

        return (float) $value;
    }

    private function nullable_integer($value): ?int
    {
        if (null === $value || '' === (string) $value) {
            return null;
        }

        return absint($value);
    }

    /**
     * @param array<string,mixed> $record
     */
    private function record_has_projection(array $record): bool
    {
        foreach (array(
            'projected_ticket_revenue',
            'projected_tickets_sold',
            'projected_attendance_total',
            'projected_concession_sales',
            'projected_event_net',
        ) as $key) {
            if (isset($record[$key]) && null !== $record[$key] && '' !== (string) $record[$key]) {
                return true;
            }
        }

        return trim((string) ($record['projection_notes'] ?? '')) !== '';
    }

    /**
     * @param array<int,array<string,mixed>> $records
     */
    private function records_have_projection(array $records): bool
    {
        foreach ($records as $record) {
            if (!empty($record['has_projection'])) {
                return true;
            }
        }

        return false;
    }

    private function is_investor_only_user(): bool
    {
        return is_user_logged_in() && current_user_can(self::CAP_VIEW) && !current_user_can('manage_options');
    }

    private function get_vms_parent_slug(): string
    {
        if (vms_investor_has_core_function('vms_admin_menu_parent_slug')) {
            return (string) vms_investor_call_core_function('vms_admin_menu_parent_slug');
        }

        return 'vms-dashboard';
    }

    private function has_vms_parent_menu(): bool
    {
        global $menu;

        if (!is_array($menu)) {
            return false;
        }

        $parent_slug = $this->get_vms_parent_slug();

        foreach ($menu as $item) {
            if (is_array($item) && isset($item[2]) && (string) $item[2] === $parent_slug) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string,mixed> $args
     */
    private function get_admin_page_url(array $args = array()): string
    {
        $url = admin_url('admin.php?page=' . self::MENU_SLUG);

        if (!empty($args)) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }

    private function get_portal_page_url(): string
    {
        static $url = null;

        if (null !== $url) {
            return $url;
        }

        global $wpdb;

        $like = '%' . $wpdb->esc_like('[' . self::SHORTCODE) . '%';
        $post_id = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT ID
                FROM {$wpdb->posts}
                WHERE post_status IN ('publish', 'private')
                  AND post_type IN ('page', 'post')
                  AND post_content LIKE %s
                ORDER BY ID ASC
                LIMIT 1",
                $like
            )
        );

        if ($post_id > 0) {
            $permalink = get_permalink($post_id);
            if (is_string($permalink) && $permalink !== '') {
                $url = $permalink;
                return $url;
            }
        }

        $url = home_url('/');

        return $url;
    }

    private function current_request_url(): string
    {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '/';
        return home_url($request_uri);
    }

    private function normalize_admin_view($value): string
    {
        $value = sanitize_key((string) $value);
        $allowed = array('recent_past', 'upcoming', 'all');

        return in_array($value, $allowed, true) ? $value : 'recent_past';
    }

    private function render_admin_view_tabs(string $current_view): void
    {
        $tabs = array(
            'recent_past' => __('Recent Past Events', 'vms-investor-portal'),
            'upcoming' => __('Upcoming Events', 'vms-investor-portal'),
            'all' => __('All Reportable Events', 'vms-investor-portal'),
        );

        echo '<nav class="nav-tab-wrapper vmsip-admin-tabs">';

        foreach ($tabs as $view => $label) {
            $class = 'nav-tab' . ($current_view === $view ? ' nav-tab-active' : '');
            $url = $this->get_admin_page_url(array('vmsip_view' => $view));
            echo '<a class="' . esc_attr($class) . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
        }

        echo '</nav>';
    }

    private function render_admin_refresh_toolbar(string $view): void
    {
        $visible_limit = $this->snapshot_visible_refresh_limit();
        $recent_limit = $this->snapshot_recent_refresh_limit();

        if (!$this->refresh_actions_enabled()) {
            echo '<p class="description">' . esc_html($this->refresh_actions_disabled_message()) . '</p>';
            return;
        }

        echo '<div class="vmsip-admin-actions">';
        $this->render_admin_refresh_batch_form(
            $view,
            'visible',
            sprintf(
                /* translators: %d: event limit */
                __('Refresh Visible Events (up to %d)', 'vms-investor-portal'),
                $visible_limit
            )
        );
        $this->render_admin_refresh_batch_form(
            $view,
            'recent_completed',
            sprintf(
                /* translators: %d: event limit */
                __('Refresh Recent Completed (up to %d)', 'vms-investor-portal'),
                $recent_limit
            )
        );
        echo '</div>';
        echo '<p class="description">' . esc_html__('Cached metrics are used during normal rendering. Refresh actions rebuild snapshots explicitly, and batch refreshes are capped to keep validation runs bounded.', 'vms-investor-portal') . '</p>';
    }

    private function render_admin_refresh_event_form(int $event_id, string $view): void
    {
        if (!$this->refresh_actions_enabled()) {
            return;
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="vmsip-admin-refresh-form">';
        wp_nonce_field(self::REFRESH_EVENT_ACTION . ':' . $event_id, 'vms_investor_portal_refresh_nonce');
        echo '<input type="hidden" name="action" value="' . esc_attr(self::REFRESH_EVENT_ACTION) . '">';
        echo '<input type="hidden" name="event_id" value="' . esc_attr((string) $event_id) . '">';
        echo '<input type="hidden" name="vmsip_view" value="' . esc_attr($view) . '">';
        echo '<button type="submit" class="button button-secondary">' . esc_html__('Refresh Metrics', 'vms-investor-portal') . '</button>';
        echo '</form>';
    }

    private function render_admin_refresh_batch_form(string $view, string $scope, string $label): void
    {
        if (!$this->refresh_actions_enabled()) {
            return;
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="vmsip-admin-refresh-form">';
        wp_nonce_field(self::REFRESH_BATCH_ACTION . ':' . $scope . ':' . $view, 'vms_investor_portal_refresh_batch_nonce');
        echo '<input type="hidden" name="action" value="' . esc_attr(self::REFRESH_BATCH_ACTION) . '">';
        echo '<input type="hidden" name="refresh_scope" value="' . esc_attr($scope) . '">';
        echo '<input type="hidden" name="vmsip_view" value="' . esc_attr($view) . '">';
        echo '<button type="submit" class="button button-secondary">' . esc_html($label) . '</button>';
        echo '</form>';
    }

    /**
     * @param array<string,mixed> $feedback
     */
    private function render_refresh_feedback_notice(array $feedback): void
    {
        $success_count = isset($feedback['success_count']) ? absint($feedback['success_count']) : 0;
        $error_count = isset($feedback['error_count']) ? absint($feedback['error_count']) : 0;
        $successes = isset($feedback['successes']) && is_array($feedback['successes']) ? $feedback['successes'] : array();
        $errors = isset($feedback['errors']) && is_array($feedback['errors']) ? $feedback['errors'] : array();

        $summary = $error_count > 0
            ? sprintf(
                /* translators: 1: refreshed count, 2: error count */
                __('Metrics refresh finished. %1$s event(s) refreshed, %2$s error(s).', 'vms-investor-portal'),
                number_format_i18n($success_count),
                number_format_i18n($error_count)
            )
            : sprintf(
                /* translators: %s: refreshed count */
                __('Metrics refresh finished. %s event(s) refreshed.', 'vms-investor-portal'),
                number_format_i18n($success_count)
            );

        echo '<div class="notice ' . esc_attr($error_count > 0 ? 'notice-warning' : 'notice-success') . ' is-dismissible">';
        echo '<p>' . esc_html($summary) . '</p>';

        if (!empty($successes)) {
            echo '<p><strong>' . esc_html__('Refreshed', 'vms-investor-portal') . '</strong></p><ul>';
            foreach ($successes as $item) {
                if (!is_array($item)) {
                    continue;
                }
                echo '<li><strong>' . esc_html((string) ($item['event_title'] ?? __('Unknown event', 'vms-investor-portal'))) . '</strong>: ' . esc_html((string) ($item['message'] ?? ''));
                if (!empty($item['warnings']) && is_array($item['warnings'])) {
                    foreach ($item['warnings'] as $warning) {
                        echo '<div>' . esc_html((string) $warning) . '</div>';
                    }
                }
                echo '</li>';
            }
            echo '</ul>';
        }

        if (!empty($errors)) {
            echo '<p><strong>' . esc_html__('Errors', 'vms-investor-portal') . '</strong></p><ul>';
            foreach ($errors as $item) {
                if (!is_array($item)) {
                    continue;
                }
                echo '<li><strong>' . esc_html((string) ($item['event_title'] ?? __('Unknown event', 'vms-investor-portal'))) . '</strong>: ' . esc_html((string) ($item['message'] ?? '')) . '</li>';
            }
            echo '</ul>';
        }

        echo '</div>';
    }

    /**
     * @param array<string,mixed> $args
     */
    private function render_admin_auto_metric(array $args): void
    {
        $event_id = isset($args['event_id']) ? absint($args['event_id']) : 0;
        $field_name = isset($args['field_name']) ? (string) $args['field_name'] : '';
        $field_id = 'vmsip-' . ($field_name !== '' ? $field_name : sanitize_title((string) ($args['label'] ?? 'metric'))) . '-' . $event_id;
        $readonly = !empty($args['readonly']);
        $display_source_type = isset($args['display_source_type']) ? (string) $args['display_source_type'] : 'not_available';
        $display_source_label = isset($args['display_source_label']) ? (string) $args['display_source_label'] : '';
        $source_badge = __('Not Available', 'vms-investor-portal');
        if ($display_source_type === 'manual_override') {
            $source_badge = __('Using Manual Override', 'vms-investor-portal');
        } elseif ($display_source_type === 'auto_actual') {
            $source_badge = __('Using Auto Actual', 'vms-investor-portal');
        } elseif ($display_source_type === 'fallback') {
            $source_badge = __('Using Fallback Source', 'vms-investor-portal');
        }
        $override_value = $args['override_value'];
        $breakdown_lines = isset($args['breakdown_lines']) && is_array($args['breakdown_lines']) ? $args['breakdown_lines'] : array();
        $hide_display_source = !empty($args['hide_display_source']);
        $help_text = isset($args['help_text']) ? trim((string) $args['help_text']) : '';
        $warning_lines = isset($args['warning_lines']) && is_array($args['warning_lines']) ? $args['warning_lines'] : array();
        $freshness_timestamp = isset($args['freshness_timestamp']) ? trim((string) $args['freshness_timestamp']) : '';

        echo '<div class="vmsip-admin-metric">';
        echo '<div class="vmsip-admin-metric__header">';
        echo '<h4>' . esc_html((string) ($args['label'] ?? '')) . '</h4>';
        echo '<span class="vmsip-source-chip vmsip-source-chip--' . esc_attr($display_source_type) . '">' . esc_html($source_badge) . '</span>';
        echo '</div>';
        echo '<p class="vmsip-admin-metric__actual"><span>' . esc_html__('Auto Actual', 'vms-investor-portal') . '</span> ' . esc_html((string) ($args['auto_value'] ?? '')) . '</p>';
        echo '<p class="vmsip-admin-metric__meta">' . esc_html((string) ($args['auto_source_label'] ?? '')) . '</p>';
        foreach ($breakdown_lines as $line) {
            echo '<p class="vmsip-admin-metric__meta">' . esc_html((string) $line) . '</p>';
        }
        if (!$hide_display_source && $display_source_label !== '') {
            echo '<p class="vmsip-admin-metric__meta"><strong>' . esc_html__('Investor display source:', 'vms-investor-portal') . '</strong> ' . esc_html($display_source_label) . '</p>';
        }
        if ($freshness_timestamp !== '') {
            echo '<p class="vmsip-admin-metric__meta"><strong>' . esc_html__('Freshness:', 'vms-investor-portal') . '</strong> ' . esc_html($freshness_timestamp) . '</p>';
        }
        foreach ($warning_lines as $warning_line) {
            echo '<p class="vmsip-admin-metric__meta">' . esc_html((string) $warning_line) . '</p>';
        }
        if ($help_text !== '') {
            echo '<p class="vmsip-admin-metric__meta">' . esc_html($help_text) . '</p>';
        }
        if ($readonly) {
            echo '</div>';
            return;
        }
        echo '<label for="' . esc_attr($field_id) . '">' . esc_html__('Manual Override', 'vms-investor-portal') . '</label>';
        echo '<input id="' . esc_attr($field_id) . '" type="' . esc_attr((string) ($args['input_type'] ?? 'number')) . '" inputmode="' . esc_attr((string) ($args['input_mode'] ?? 'decimal')) . '" step="' . esc_attr((string) ($args['input_step'] ?? '0.01')) . '" min="' . esc_attr((string) ($args['input_min'] ?? '0')) . '" name="' . esc_attr($field_name) . '" value="' . esc_attr(null === $override_value ? '' : (string) $override_value) . '" placeholder="' . esc_attr__('Leave blank to use auto actual', 'vms-investor-portal') . '">';
        echo '</div>';
    }

    /**
     * @param array<string,mixed> $metric
     * @param array<string,mixed> $args
     */
    private function render_admin_metric_from_payload(array $metric, int $event_id, array $args = array()): void
    {
        $kind = isset($metric['kind']) ? (string) $metric['kind'] : 'currency';
        $readonly = !empty($args['readonly']);
        $field_name = isset($args['field_name']) ? (string) $args['field_name'] : (string) ($metric['override_key'] ?? '');

        $this->render_admin_auto_metric(array(
            'event_id' => $event_id,
            'field_name' => $field_name,
            'label' => (string) ($metric['label'] ?? ''),
            'auto_value' => $this->format_metric_for_admin($metric, true),
            'auto_source_label' => (string) ($metric['auto_source_label'] ?? __('Not available', 'vms-investor-portal')),
            'display_source_type' => (string) ($metric['source_type'] ?? 'not_available'),
            'display_source_label' => (string) ($metric['source_label'] ?? __('Not available', 'vms-investor-portal')),
            'override_value' => array_key_exists('override_value', $args) ? $args['override_value'] : ($metric['manual_override_value'] ?? null),
            'breakdown_lines' => (array) ($metric['breakdown_lines'] ?? array()),
            'warning_lines' => (array) ($metric['warnings'] ?? array()),
            'freshness_timestamp' => (string) ($metric['freshness_timestamp'] ?? ''),
            'input_type' => $kind === 'count' ? 'number' : 'number',
            'input_mode' => $kind === 'count' ? 'numeric' : 'decimal',
            'input_step' => $kind === 'count' ? '1' : '0.01',
            'input_min' => '0',
            'readonly' => $readonly,
            'hide_display_source' => !empty($args['hide_display_source']),
            'help_text' => isset($args['help_text']) ? (string) $args['help_text'] : '',
        ));
    }

    /**
     * @param array<string,mixed> $metric
     */
    private function format_metric_for_admin(array $metric, bool $auto_value = false): string
    {
        $kind = isset($metric['kind']) ? (string) $metric['kind'] : 'currency';
        $value = $auto_value ? ($metric['auto_value'] ?? null) : ($metric['value'] ?? null);
        $available = $auto_value ? !empty($metric['auto_available']) : !empty($metric['available']);

        if (!$available || null === $value || '' === (string) $value) {
            return (string) __('Not available', 'vms-investor-portal');
        }

        if ($kind === 'count') {
            return (string) number_format_i18n((int) $value);
        }

        return (string) $this->format_currency((float) $value);
    }

    /**
     * @param array<string,array<string,mixed>> $metrics
     * @param array<string,mixed> $snapshot_meta
     */
    private function render_admin_diagnostics_panel(array $metrics, array $snapshot_meta = array()): void
    {
        if (!empty($snapshot_meta)) {
            $snapshot_last_error = isset($snapshot_meta['snapshot_last_error']) ? trim((string) $snapshot_meta['snapshot_last_error']) : '';
            echo '<div class="vmsip-diagnostics-table-wrap">';
            echo '<table class="widefat striped vmsip-diagnostics-table">';
            echo '<tbody>';
            echo '<tr><th scope="row">' . esc_html__('Snapshot Status', 'vms-investor-portal') . '</th><td>' . esc_html((string) ($snapshot_meta['snapshot_status_label'] ?? __('Missing', 'vms-investor-portal'))) . '</td></tr>';
            echo '<tr><th scope="row">' . esc_html__('Last Refreshed', 'vms-investor-portal') . '</th><td>' . esc_html((string) ($snapshot_meta['snapshot_last_refreshed_label'] ?? __('Never', 'vms-investor-portal'))) . '</td></tr>';
            echo '<tr><th scope="row">' . esc_html__('Snapshot Source', 'vms-investor-portal') . '</th><td>' . esc_html((string) ($snapshot_meta['snapshot_source_label'] ?? __('Cached investor metrics snapshot', 'vms-investor-portal'))) . '</td></tr>';
            echo '<tr><th scope="row">' . esc_html__('Last Error', 'vms-investor-portal') . '</th><td>' . esc_html($snapshot_last_error !== '' ? $snapshot_last_error : __('None', 'vms-investor-portal')) . '</td></tr>';
            echo '<tr><th scope="row">' . esc_html__('Snapshot Warnings', 'vms-investor-portal') . '</th><td>';
            $snapshot_notes = array();
            if (!empty($snapshot_meta['snapshot_notice'])) {
                $snapshot_notes[] = (string) $snapshot_meta['snapshot_notice'];
            }
            if (!empty($snapshot_meta['snapshot_warnings']) && is_array($snapshot_meta['snapshot_warnings'])) {
                foreach ($snapshot_meta['snapshot_warnings'] as $warning) {
                    $snapshot_notes[] = (string) $warning;
                }
            }
            if (empty($snapshot_notes)) {
                echo esc_html__('None', 'vms-investor-portal');
            } else {
                foreach ($snapshot_notes as $note) {
                    echo '<div>' . esc_html($note) . '</div>';
                }
            }
            echo '</td></tr>';
            echo '</tbody></table>';
            echo '</div>';
        }

        if (empty($metrics)) {
            echo '<p class="description">' . esc_html__('No diagnostics are available for this event yet.', 'vms-investor-portal') . '</p>';
            return;
        }

        echo '<div class="vmsip-diagnostics-table-wrap">';
        echo '<table class="widefat striped vmsip-diagnostics-table">';
        echo '<thead><tr>';
        echo '<th scope="col">' . esc_html__('Metric', 'vms-investor-portal') . '</th>';
        echo '<th scope="col">' . esc_html__('Displayed', 'vms-investor-portal') . '</th>';
        echo '<th scope="col">' . esc_html__('Auto', 'vms-investor-portal') . '</th>';
        echo '<th scope="col">' . esc_html__('Manual Override', 'vms-investor-portal') . '</th>';
        echo '<th scope="col">' . esc_html__('Source', 'vms-investor-portal') . '</th>';
        echo '<th scope="col">' . esc_html__('Warnings / Notes', 'vms-investor-portal') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($metrics as $metric) {
            if (!is_array($metric)) {
                continue;
            }

            $warnings = isset($metric['warnings']) && is_array($metric['warnings']) ? $metric['warnings'] : array();
            $breakdown_lines = isset($metric['breakdown_lines']) && is_array($metric['breakdown_lines']) ? $metric['breakdown_lines'] : array();
            $notes = array_merge($breakdown_lines, $warnings);
            if (!empty($metric['freshness_timestamp'])) {
                $notes[] = sprintf(
                    /* translators: %s: timestamp */
                    __('Freshness: %s', 'vms-investor-portal'),
                    (string) $metric['freshness_timestamp']
                );
            }

            echo '<tr>';
            echo '<td><strong>' . esc_html((string) ($metric['label'] ?? '')) . '</strong></td>';
            echo '<td>' . esc_html($this->format_metric_for_admin($metric, false)) . '</td>';
            echo '<td>' . esc_html($this->format_metric_for_admin($metric, true)) . '</td>';
            echo '<td>' . esc_html(
                !empty($metric['manual_override_active'])
                    ? $this->format_metric_override_value($metric)
                    : __('None', 'vms-investor-portal')
            ) . '</td>';
            echo '<td>';
            echo '<strong>' . esc_html((string) ($metric['source_label'] ?? __('Not available', 'vms-investor-portal'))) . '</strong>';
            if (!empty($metric['source_key'])) {
                echo '<br><code>' . esc_html((string) $metric['source_key']) . '</code>';
            }
            echo '</td>';
            echo '<td>';
            if (empty($notes)) {
                echo esc_html__('None', 'vms-investor-portal');
            } else {
                foreach ($notes as $note) {
                    echo '<div>' . esc_html((string) $note) . '</div>';
                }
            }
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }

    /**
     * @param array<string,mixed> $metric
     */
    private function format_metric_override_value(array $metric): string
    {
        $kind = isset($metric['kind']) ? (string) $metric['kind'] : 'currency';
        $value = $metric['manual_override_value'] ?? null;

        if (null === $value || '' === (string) $value) {
            return (string) __('None', 'vms-investor-portal');
        }

        if ($kind === 'count') {
            return (string) number_format_i18n((int) $value);
        }

        return (string) $this->format_currency((float) $value);
    }

    private function render_admin_currency_field(string $name, string $label, $value, bool $optional = false, int $event_id = 0): void
    {
        $field_id = 'vmsip-' . $name . '-' . $event_id;
        echo '<div class="vmsip-admin-field">';
        echo '<label for="' . esc_attr($field_id) . '">' . esc_html($label) . '</label>';
        echo '<input id="' . esc_attr($field_id) . '" type="number" inputmode="decimal" step="0.01" min="0" name="' . esc_attr($name) . '" value="' . esc_attr(null === $value && $optional ? '' : (string) $value) . '">';
        echo '</div>';
    }

    private function render_admin_integer_field(string $name, string $label, $value, bool $optional = false, int $event_id = 0): void
    {
        $field_id = 'vmsip-' . $name . '-' . $event_id;
        echo '<div class="vmsip-admin-field">';
        echo '<label for="' . esc_attr($field_id) . '">' . esc_html($label) . '</label>';
        echo '<input id="' . esc_attr($field_id) . '" type="number" inputmode="numeric" step="1" min="0" name="' . esc_attr($name) . '" value="' . esc_attr(null === $value && $optional ? '' : (string) $value) . '">';
        echo '</div>';
    }

    private function render_frontend_metric_card(string $label, string $value, string $modifier = ''): void
    {
        $class = 'vmsip-metric-card';
        if ($modifier !== '') {
            $class .= ' vmsip-metric-card--' . sanitize_html_class($modifier);
        }
        echo '<div class="' . esc_attr($class) . '">';
        echo '<p class="vmsip-detail-item__label">' . esc_html($label) . '</p>';
        echo '<p class="vmsip-metric-card__value">' . esc_html($value) . '</p>';
        echo '</div>';
    }

    private function render_frontend_detail_item(string $label, string $value, bool $allow_html = false): void
    {
        echo '<div class="vmsip-detail-item">';
        echo '<p class="vmsip-detail-item__label">' . esc_html($label) . '</p>';
        echo '<div class="vmsip-detail-item__value">' . ($allow_html ? $value : esc_html($value)) . '</div>';
        echo '</div>';
    }

    /**
     * @param array<string,mixed> $record
     * @param array<string,array<string,mixed>> $metrics
     */
    private function render_frontend_manual_overrides_block(array $record, array $metrics): void
    {
        $override_metrics = array(
            'ticket_revenue' => array(
                'manual_label' => __('Investor Display Uses Manual Total Ticket Revenue', 'vms-investor-portal'),
                'auto_label' => __('Auto Total Ticket Revenue', 'vms-investor-portal'),
            ),
            'tickets_sold' => array(
                'manual_label' => __('Investor Display Uses Manual Total Tickets Sold', 'vms-investor-portal'),
                'auto_label' => __('Auto Total Tickets Sold', 'vms-investor-portal'),
            ),
            'attendance_total' => array(
                'manual_label' => __('Investor Display Uses Manual Total Attendance', 'vms-investor-portal'),
                'auto_label' => __('Auto Total Attendance', 'vms-investor-portal'),
            ),
            'concession_sales' => array(
                'manual_label' => __('Investor Display Uses Manual Concession / On-site Sales', 'vms-investor-portal'),
                'auto_label' => __('Auto Concession / On-site Sales', 'vms-investor-portal'),
            ),
            'labor_cost' => array(
                'manual_label' => __('Investor Display Uses Manual Labor', 'vms-investor-portal'),
                'auto_label' => __('Auto Labor', 'vms-investor-portal'),
            ),
            'concession_cost' => array(
                'manual_label' => __('Investor Display Uses Manual Concession Costs', 'vms-investor-portal'),
                'auto_label' => __('Auto Concession Costs', 'vms-investor-portal'),
            ),
            'ad_spend' => array(
                'manual_label' => __('Investor Display Uses Manual Estimated Advertising', 'vms-investor-portal'),
                'auto_label' => __('Auto Estimated Advertising', 'vms-investor-portal'),
            ),
            'performer_cost' => array(
                'manual_label' => __('Investor Display Uses Manual Performer/Vendor Cost', 'vms-investor-portal'),
                'auto_label' => __('Auto Performer/Vendor Cost', 'vms-investor-portal'),
            ),
            'other_expenses' => array(
                'manual_label' => __('Investor Display Uses Manual Additional Overhead', 'vms-investor-portal'),
                'auto_label' => __('Auto Additional Overhead', 'vms-investor-portal'),
            ),
            'estimated_sales_tax' => array(
                'manual_label' => __('Investor Display Uses Manual Estimated Sales Tax', 'vms-investor-portal'),
                'auto_label' => __('Auto Estimated Sales Tax', 'vms-investor-portal'),
            ),
            'estimated_event_net' => array(
                'manual_label' => __('Investor Display Uses Manual Estimated Event Net', 'vms-investor-portal'),
                'auto_label' => __('Auto Estimated Event Net', 'vms-investor-portal'),
            ),
        );

        $has_manual_overrides = false;
        foreach ($override_metrics as $metric_key => $labels) {
            unset($labels);
            if (!empty($metrics[$metric_key]['manual_override_active'])) {
                $has_manual_overrides = true;
                break;
            }
        }

        if (!$has_manual_overrides) {
            unset($record);
            return;
        }

        echo '<div class="vmsip-manual-block">';
        echo '<h4>' . esc_html__('Manual Overrides', 'vms-investor-portal') . '</h4>';
        echo '<div class="vmsip-details-grid">';

        foreach ($override_metrics as $metric_key => $labels) {
            $metric = isset($metrics[$metric_key]) && is_array($metrics[$metric_key]) ? $metrics[$metric_key] : array();
            if (empty($metric['manual_override_active'])) {
                continue;
            }
            $this->render_frontend_detail_item((string) $labels['manual_label'], $this->format_metric_display_value($metric));
            if (!empty($metric['auto_available'])) {
                $this->render_frontend_detail_item((string) $labels['auto_label'], $this->format_metric_display_value($metric, true));
            }
        }

        echo '</div>';
        echo '</div>';

        unset($record);
    }

    /**
     * @param array<string,mixed> $metric
     */
    private function format_metric_display_value(array $metric, bool $auto_value = false): string
    {
        $kind = isset($metric['kind']) ? (string) $metric['kind'] : 'currency';
        $value = $auto_value ? ($metric['auto_value'] ?? null) : ($metric['value'] ?? null);
        $available = $auto_value ? !empty($metric['auto_available']) : !empty($metric['available']);

        if (!$available || null === $value || '' === (string) $value) {
            return __('Not available', 'vms-investor-portal');
        }

        if ($kind === 'count') {
            return number_format_i18n((int) $value);
        }

        return $this->format_currency((float) $value);
    }

    /**
     * @param array<string,mixed> $record
     */
    private function build_source_note(array $record): string
    {
        return sprintf(
            /* translators: 1: total ticket revenue source, 2: total tickets sold source, 3: total attendance source, 4: checked-in/scanned source */
            __('Total ticket revenue: %1$s. Total tickets sold: %2$s. Total attendance: %3$s. Checked in / scanned: %4$s.', 'vms-investor-portal'),
            (string) ($record['ticket_revenue_source_label'] ?? __('Not available', 'vms-investor-portal')),
            (string) ($record['tickets_sold_source_label'] ?? __('Not available', 'vms-investor-portal')),
            (string) ($record['attendance_source_label'] ?? __('Not available', 'vms-investor-portal')),
            (string) ($record['checked_in_source_label'] ?? __('Not available', 'vms-investor-portal'))
        );
    }

    /**
     * @param array<string,mixed> $a
     * @param array<string,mixed> $b
     */
    private function sort_display_records_descending(array $a, array $b): int
    {
        return ((int) $b['event_timestamp']) <=> ((int) $a['event_timestamp']);
    }

    /**
     * @param array<string,mixed> $a
     * @param array<string,mixed> $b
     */
    private function sort_display_records_ascending(array $a, array $b): int
    {
        return ((int) $a['event_timestamp']) <=> ((int) $b['event_timestamp']);
    }
}
