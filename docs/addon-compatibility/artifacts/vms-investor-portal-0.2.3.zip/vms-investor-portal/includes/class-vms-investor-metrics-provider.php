<?php

defined('ABSPATH') || exit;

final class VMS_Investor_Metrics_Provider
{
    /** @var self|null */
    private static $instance = null;

    /** @var array<string,array<string,mixed>> */
    private $ticket_actuals_cache = array();

    /** @var array<string,array<string,mixed>> */
    private $attendance_actuals_cache = array();

    public static function instance(): self
    {
        if (!(self::$instance instanceof self)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * @param array<string,mixed> $context
     * @param array<string,mixed> $manual_record
     * @return array<string,mixed>
     */
    public function get_event_metrics(WP_Post $post, array $context, array $manual_record = array()): array
    {
        $sources = $this->collect_sources($post, $context);
        $ticket_actuals = $this->resolve_ticket_actuals($post, $context, $sources);
        $attendance_actuals = $this->resolve_attendance_actuals($post, $context, $sources, $ticket_actuals);
        $event_plan_id = (int) ($context['event_plan_id'] ?? 0);
        $source_warnings = $this->merge_warnings(
            (array) ($sources['warnings'] ?? array()),
            (array) ($ticket_actuals['warnings'] ?? array()),
            (array) ($attendance_actuals['warnings'] ?? array())
        );

        $ticket_revenue = $this->build_metric(
            'ticket_revenue',
            __('Total Ticket Revenue', 'vms-investor-portal'),
            'currency',
            array(
                'available' => !empty($ticket_actuals['available']),
                'value' => (float) ($ticket_actuals['ticket_revenue'] ?? 0.0),
                'source_key' => (string) ($ticket_actuals['revenue_source_key'] ?? ''),
                'source_label' => (string) ($ticket_actuals['revenue_source_label'] ?? __('Not available', 'vms-investor-portal')),
                'source_type' => !empty($ticket_actuals['available']) ? 'auto_actual' : (!empty($ticket_actuals['partial_only']) ? 'fallback' : 'not_available'),
                'breakdown_lines' => $this->build_ticket_revenue_breakdown_lines($ticket_actuals),
                'warnings' => (array) ($ticket_actuals['warnings'] ?? array()),
            ),
            $manual_record,
            'ticket_revenue_override',
            'ticket_revenue'
        );

        $tickets_sold = $this->build_metric(
            'tickets_sold',
            __('Total Tickets Sold', 'vms-investor-portal'),
            'count',
            array(
                'available' => !empty($ticket_actuals['available']),
                'value' => (int) ($ticket_actuals['tickets_sold'] ?? 0),
                'source_key' => (string) ($ticket_actuals['tickets_source_key'] ?? ''),
                'source_label' => (string) ($ticket_actuals['tickets_source_label'] ?? __('Not available', 'vms-investor-portal')),
                'source_type' => !empty($ticket_actuals['available']) ? 'auto_actual' : (!empty($ticket_actuals['partial_only']) ? 'fallback' : 'not_available'),
                'breakdown_lines' => $this->build_ticket_sold_breakdown_lines($ticket_actuals),
                'warnings' => (array) ($ticket_actuals['warnings'] ?? array()),
            ),
            $manual_record,
            'tickets_sold_override',
            'tickets_sold'
        );

        $attendance_total = $this->build_metric(
            'attendance_total',
            __('Total Attendance', 'vms-investor-portal'),
            'count',
            array(
                'available' => !empty($attendance_actuals['available']),
                'value' => (int) ($attendance_actuals['value'] ?? 0),
                'source_key' => (string) ($attendance_actuals['source_key'] ?? ''),
                'source_label' => (string) ($attendance_actuals['source_label'] ?? __('Not available', 'vms-investor-portal')),
                'source_type' => !empty($attendance_actuals['available']) ? 'auto_actual' : 'not_available',
                'breakdown_lines' => $this->build_attendance_breakdown_lines($attendance_actuals),
                'warnings' => (array) ($attendance_actuals['warnings'] ?? array()),
            ),
            $manual_record,
            'attendance_total_override',
            'attendance_total'
        );

        $checked_in_scanned = $this->build_metric(
            'checked_in_scanned',
            __('Checked In / Scanned', 'vms-investor-portal'),
            'count',
            array(
                'available' => !empty($attendance_actuals['checked_in_available']),
                'value' => (int) ($attendance_actuals['checked_in'] ?? 0),
                'source_key' => 'vms_ops_ticket_get_event_attendees()',
                'source_label' => (string) ($attendance_actuals['checked_in_source_label'] ?? __('Not available', 'vms-investor-portal')),
                'source_type' => !empty($attendance_actuals['checked_in_available']) ? 'auto_actual' : 'not_available',
                'breakdown_lines' => array(),
                'warnings' => array(),
            )
        );

        $bar_sales_auto = $this->dt_currency_metric(
            (float) (($sources['dt_row']['square_bar_cents'] ?? 0) / 100),
            !empty($sources['dt_model_available']),
            'dt_model.row.square_bar_cents',
            __('Data Tools event model', 'vms-investor-portal'),
            array(),
            (array) ($sources['warnings'] ?? array())
        );
        $food_sales_auto = $this->dt_currency_metric(
            (float) (($sources['dt_row']['square_food_cents'] ?? 0) / 100),
            !empty($sources['dt_model_available']),
            'dt_model.row.square_food_cents',
            __('Data Tools event model', 'vms-investor-portal'),
            array(),
            (array) ($sources['warnings'] ?? array())
        );
        $merch_sales_auto = $this->dt_currency_metric(
            (float) (($sources['dt_row']['square_merch_cents'] ?? 0) / 100),
            !empty($sources['dt_model_available']),
            'dt_model.row.square_merch_cents',
            __('Data Tools event model', 'vms-investor-portal'),
            array(),
            (array) ($sources['warnings'] ?? array())
        );
        $other_onsite_sales_auto = $this->dt_currency_metric(
            (float) (($sources['dt_row']['square_other_cents'] ?? 0) / 100),
            !empty($sources['dt_model_available']),
            'dt_model.row.square_other_cents',
            __('Data Tools event model', 'vms-investor-portal'),
            array(),
            (array) ($sources['warnings'] ?? array())
        );
        $website_addons_auto = $this->dt_currency_metric(
            (float) (($sources['dt_summary']['website_addons_net_cents'] ?? ($sources['dt_row']['website_addon_net_cents'] ?? 0)) / 100),
            !empty($sources['dt_model_available']),
            'dt_model.summary.website_addons_net_cents',
            __('Data Tools event model', 'vms-investor-portal'),
            array(),
            (array) ($sources['warnings'] ?? array())
        );

        $onsite_total_value = 0.0;
        $onsite_available = false;
        if (!empty($sources['dt_model_available'])) {
            $onsite_total_value = (float) (($sources['dt_summary']['onsite_non_ticket_cents'] ?? 0) / 100);
            if ($onsite_total_value <= 0) {
                $onsite_total_value = (float) (
                    (($sources['dt_row']['square_bar_cents'] ?? 0)
                    + ($sources['dt_row']['square_food_cents'] ?? 0)
                    + ($sources['dt_row']['square_merch_cents'] ?? 0)
                    + ($sources['dt_row']['square_other_cents'] ?? 0)) / 100
                );
            }
            $onsite_available = true;
        }

        $concession_sales = $this->build_metric(
            'concession_sales',
            __('Concession / On-site Sales', 'vms-investor-portal'),
            'currency',
            array(
                'available' => $onsite_available,
                'value' => $onsite_total_value,
                'source_key' => 'dt_model.summary.onsite_non_ticket_cents',
                'source_label' => $onsite_available ? __('Data Tools event model', 'vms-investor-portal') : __('Not available', 'vms-investor-portal'),
                'source_type' => $onsite_available ? 'auto_actual' : 'not_available',
                'breakdown_lines' => array_values(array_filter(array(
                    $this->breakdown_line_for_metric(__('Bar sales', 'vms-investor-portal'), $bar_sales_auto, 'currency'),
                    $this->breakdown_line_for_metric(__('Food sales', 'vms-investor-portal'), $food_sales_auto, 'currency'),
                    $this->breakdown_line_for_metric(__('Merch sales', 'vms-investor-portal'), $merch_sales_auto, 'currency'),
                    $this->breakdown_line_for_metric(__('Other on-site sales', 'vms-investor-portal'), $other_onsite_sales_auto, 'currency'),
                ))),
                'warnings' => (array) ($sources['warnings'] ?? array()),
            ),
            $manual_record,
            'concession_sales_override',
            'concession_sales'
        );

        $labor_cost = $this->build_metric(
            'labor_cost',
            __('Labor', 'vms-investor-portal'),
            'currency',
            array(
                'available' => !empty($sources['dt_model_available']),
                'value' => (float) (($sources['dt_costs']['labor_overhead_cents'] ?? 0) / 100),
                'source_key' => 'dt_model.costs.labor_overhead_cents',
                'source_label' => !empty($sources['dt_model_available']) ? __('Data Tools event model', 'vms-investor-portal') : __('Not available', 'vms-investor-portal'),
                'source_type' => !empty($sources['dt_model_available']) ? 'auto_actual' : 'not_available',
                'breakdown_lines' => array(),
                'warnings' => (array) ($sources['warnings'] ?? array()),
            ),
            $manual_record,
            'labor_cost_override',
            'labor_cost'
        );

        $performer_auto_available = !empty($sources['dt_model_available']) || !empty($sources['goals_direct_costs_available']);
        $performer_auto_value = !empty($sources['dt_model_available'])
            ? (float) (($sources['dt_costs']['band_payout_cents'] ?? 0) / 100)
            : (float) (($sources['goals_default_direct_costs_cents'] ?? 0) / 100);
        $performer_breakdown = array();
        $performer_warnings = (array) ($sources['warnings'] ?? array());
        if (empty($sources['dt_model_available']) && !empty($sources['goals_direct_costs_available'])) {
            $performer_warnings[] = __('Fallback direct costs from VMS Goals may include non-performer costs.', 'vms-investor-portal');
        }
        $performer_cost = $this->build_metric(
            'performer_cost',
            __('Performer/Vendor Cost', 'vms-investor-portal'),
            'currency',
            array(
                'available' => $performer_auto_available,
                'value' => $performer_auto_value,
                'source_key' => !empty($sources['dt_model_available']) ? 'dt_model.costs.band_payout_cents' : 'vms_goals_get_default_direct_costs_cents()',
                'source_label' => !empty($sources['dt_model_available']) ? __('Data Tools event model', 'vms-investor-portal') : __('VMS Goals default direct costs', 'vms-investor-portal'),
                'source_type' => $performer_auto_available ? (!empty($sources['dt_model_available']) ? 'auto_actual' : 'fallback') : 'not_available',
                'breakdown_lines' => $performer_breakdown,
                'warnings' => $performer_warnings,
            ),
            $manual_record,
            'performer_cost_override',
            'performer_cost'
        );

        $ad_spend_available = !empty($sources['ad_spend_available']);
        $ad_spend_budget_like = $this->is_budget_like_source(
            (string) ($sources['ad_spend_source_label'] ?? ''),
            (string) ($sources['ad_spend_source_key'] ?? '')
        );
        $ad_spend_label = $ad_spend_budget_like
            ? __('Estimated Advertising', 'vms-investor-portal')
            : __('Advertising', 'vms-investor-portal');
        $ad_spend_source_label = $ad_spend_available
            ? (string) ($sources['ad_spend_source_label'] ?? ($ad_spend_budget_like ? __('Meta Ads budget', 'vms-investor-portal') : __('Advertising', 'vms-investor-portal')))
            : __('Not available', 'vms-investor-portal');
        $ad_spend_breakdown_lines = $ad_spend_budget_like
            ? array(
                __('Auto advertising is using a configured budget source, not confirmed settled ad spend.', 'vms-investor-portal'),
            )
            : array();
        $ad_spend = $this->build_metric(
            'ad_spend',
            $ad_spend_label,
            'currency',
            array(
                'available' => $ad_spend_available,
                'value' => (float) (($sources['ad_spend_cents'] ?? 0) / 100),
                'source_key' => (string) ($sources['ad_spend_source_key'] ?? 'vms_dt_reporting_profitability_ad_spend_data()'),
                'source_label' => $ad_spend_source_label,
                'source_type' => $ad_spend_available ? ($ad_spend_budget_like ? 'fallback' : 'auto_actual') : 'not_available',
                'breakdown_lines' => $ad_spend_breakdown_lines,
                'warnings' => (array) ($sources['ad_spend_warnings'] ?? array()),
            ),
            $manual_record,
            'ad_spend_override',
            'ad_spend'
        );

        $other_direct_costs = $this->build_metric(
            'other_direct_costs',
            __('Other Direct Costs', 'vms-investor-portal'),
            'currency',
            array(
                'available' => !empty($sources['dt_model_available']),
                'value' => (float) (($sources['dt_costs']['other_direct_costs_cents'] ?? 0) / 100),
                'source_key' => 'dt_model.costs.other_direct_costs_cents',
                'source_label' => !empty($sources['dt_model_available']) ? __('Data Tools event model', 'vms-investor-portal') : __('Not available', 'vms-investor-portal'),
                'source_type' => !empty($sources['dt_model_available']) ? 'auto_actual' : 'not_available',
                'breakdown_lines' => array(),
                'warnings' => (array) ($sources['warnings'] ?? array()),
            )
        );

        $concession_cost = $this->build_metric(
            'concession_cost',
            __('Concession Costs', 'vms-investor-portal'),
            'currency',
            array(
                'available' => false,
                'value' => 0.0,
                'source_key' => '',
                'source_label' => __('Not available', 'vms-investor-portal'),
                'source_type' => 'not_available',
                'breakdown_lines' => array(
                    __('No reliable concession cost source is wired yet. Use a manual override when needed.', 'vms-investor-portal'),
                ),
                'warnings' => array(),
            ),
            $manual_record,
            'concession_cost_override',
            'concession_cost'
        );

        $gross_for_overhead_cents = (int) round(
            (($ticket_revenue['auto_value'] ?? 0.0)
            + ($website_addons_auto['value'] ?? 0.0)
            + ($concession_sales['auto_value'] ?? 0.0)) * 100
        );
        $headcount_for_overhead = (int) ($attendance_total['auto_value'] ?? 0);
        $overhead_auto_cents = 0;
        $overhead_available = false;
        $overhead_source_key = '';
        $overhead_source_label = __('Not available', 'vms-investor-portal');
        $overhead_warnings = array();
        if (!empty($sources['goals_overhead_available'])) {
            $overhead_auto_cents = (int) ($sources['goals_overhead_cents'] ?? 0);
            $overhead_available = true;
            $overhead_source_key = 'vms_goals_get_overhead_allocated_cents()';
            $overhead_source_label = __('VMS Goals overhead rules', 'vms-investor-portal');
        } elseif ($event_plan_id > 0 && $this->load_vms_goals_support() && vms_investor_has_core_function('vms_goals_get_settings')) {
            $settings = (array) vms_investor_call_core_function('vms_goals_get_settings');
            $overhead_rules = isset($settings['overhead_rules']) && is_array($settings['overhead_rules']) ? $settings['overhead_rules'] : array();
            if (vms_investor_has_core_function('vms_goals_get_overhead_allocated_cents')) {
                $overhead_auto_cents = max(0, (int) vms_investor_call_core_function('vms_goals_get_overhead_allocated_cents', $gross_for_overhead_cents, $headcount_for_overhead, $overhead_rules));
                $overhead_available = true;
                $overhead_source_key = 'vms_goals_get_overhead_allocated_cents()';
                $overhead_source_label = __('VMS Goals overhead rules', 'vms-investor-portal');
            }
        }
        $other_expenses = $this->build_metric(
            'other_expenses',
            __('Additional Overhead', 'vms-investor-portal'),
            'currency',
            array(
                'available' => $overhead_available,
                'value' => (float) ($overhead_auto_cents / 100),
                'source_key' => $overhead_source_key,
                'source_label' => $overhead_source_label,
                'source_type' => $overhead_available ? 'fallback' : 'not_available',
                'breakdown_lines' => $overhead_available
                    ? array(__('Calculated from VMS Goals overhead allocation rules.', 'vms-investor-portal'))
                    : array(),
                'warnings' => $overhead_warnings,
            ),
            $manual_record,
            'other_expenses_override',
            'other_expenses'
        );

        $tax_breakdown_lines = !empty($sources['dt_model_available'])
            ? array(
                __('Based on VMS/Square sales records. For internal review only. Do not use this figure for state sales tax filing.', 'vms-investor-portal'),
            )
            : array();
        $estimated_tax = $this->build_metric(
            'estimated_sales_tax',
            __('Estimated Sales Tax Collected', 'vms-investor-portal'),
            'currency',
            array(
                'available' => !empty($sources['dt_model_available']),
                'value' => (float) (((
                    (int) ($sources['dt_row']['website_ticket_tax_cents'] ?? 0)
                    + (int) ($sources['dt_row']['website_addon_tax_cents'] ?? 0)
                    + (int) ($sources['dt_row']['square_scope_line_tax_cents'] ?? 0)
                ) / 100)),
                'source_key' => 'dt_model.row.website_ticket_tax_cents + dt_model.row.website_addon_tax_cents + dt_model.row.square_scope_line_tax_cents',
                'source_label' => !empty($sources['dt_model_available']) ? __('VMS/Square sales records', 'vms-investor-portal') : __('Not available', 'vms-investor-portal'),
                'source_type' => !empty($sources['dt_model_available']) ? 'auto_actual' : 'not_available',
                'breakdown_lines' => $tax_breakdown_lines,
                'warnings' => (array) ($sources['warnings'] ?? array()),
            ),
            $manual_record,
            'estimated_tax_override',
            ''
        );

        $gross_basis = ($ticket_revenue['value'] ?? 0.0)
            + ($concession_sales['value'] ?? 0.0)
            + ($website_addons_auto['value'] ?? 0.0);
        $cost_basis = ($labor_cost['value'] ?? 0.0)
            + ($performer_cost['value'] ?? 0.0)
            + ($ad_spend['value'] ?? 0.0)
            + ($other_direct_costs['value'] ?? 0.0)
            + ($concession_cost['value'] ?? 0.0)
            + ($other_expenses['value'] ?? 0.0);
        $net_warnings = $source_warnings;
        $net_auto_available = !empty($sources['dt_model_available'])
            || !empty($ticket_revenue['auto_available'])
            || !empty($concession_sales['auto_available'])
            || !empty($website_addons_auto['available'])
            || !empty($labor_cost['auto_available'])
            || !empty($performer_cost['auto_available'])
            || !empty($ad_spend_available)
            || !empty($other_direct_costs['available'])
            || !empty($concession_cost['auto_available'])
            || !empty($other_expenses['auto_available']);
        if (!empty($sources['dt_model_available'])) {
            $net_warnings[] = __('Estimated Event Net is using a transparent investor presentation basis: ticket sales + website add-ons + on-site sales - displayed costs.', 'vms-investor-portal');
        }
        $estimated_event_net = $this->build_metric(
            'estimated_event_net',
            __('Estimated Event Net', 'vms-investor-portal'),
            'currency',
            array(
                'available' => $net_auto_available,
                'value' => $gross_basis - $cost_basis,
                'source_key' => $net_auto_available ? 'investor_provider.net.transparent_basis' : '',
                'source_label' => !empty($sources['dt_model_available'])
                    ? __('Investor metrics provider transparent basis', 'vms-investor-portal')
                    : ($net_auto_available ? __('Investor metrics provider fallback basis', 'vms-investor-portal') : __('Not available', 'vms-investor-portal')),
                'source_type' => !empty($sources['dt_model_available']) ? 'auto_actual' : ($net_auto_available ? 'fallback' : 'not_available'),
                'breakdown_lines' => $net_auto_available
                    ? array(
                        sprintf(
                            /* translators: 1: gross basis, 2: cost basis */
                            __('Revenue basis %1$s minus displayed costs %2$s.', 'vms-investor-portal'),
                            $this->format_money_for_line($gross_basis),
                            $this->format_money_for_line($cost_basis)
                        ),
                        __('Taxes, tips, and service charges are shown separately and should not be treated as filing-safe accounting numbers.', 'vms-investor-portal'),
                    )
                    : array(),
                'warnings' => $net_auto_available ? $net_warnings : array(),
            ),
            $manual_record,
            'estimated_event_net_override',
            ''
        );

        $metrics = array(
            'ticket_revenue' => $ticket_revenue,
            'online_ticket_sales' => $this->build_metric(
                'online_ticket_sales',
                __('Online Ticket Sales', 'vms-investor-portal'),
                'currency',
                array(
                    'available' => null !== ($ticket_actuals['advance_ticket_revenue'] ?? null),
                    'value' => (float) ($ticket_actuals['advance_ticket_revenue'] ?? 0.0),
                    'source_key' => (string) ($ticket_actuals['advance_revenue_source_key'] ?? ''),
                    'source_label' => (string) ($ticket_actuals['advance_revenue_source_label'] ?? __('Not available', 'vms-investor-portal')),
                    'source_type' => null !== ($ticket_actuals['advance_ticket_revenue'] ?? null) ? 'auto_actual' : 'not_available',
                    'breakdown_lines' => array(),
                    'warnings' => (array) ($ticket_actuals['warnings'] ?? array()),
                )
            ),
            'door_ticket_sales' => $this->build_metric(
                'door_ticket_sales',
                __('Door Ticket Sales', 'vms-investor-portal'),
                'currency',
                array(
                    'available' => null !== ($ticket_actuals['door_ticket_revenue'] ?? null),
                    'value' => (float) ($ticket_actuals['door_ticket_revenue'] ?? 0.0),
                    'source_key' => (string) ($ticket_actuals['door_revenue_source_key'] ?? ''),
                    'source_label' => (string) ($ticket_actuals['door_revenue_source_label'] ?? __('Not available', 'vms-investor-portal')),
                    'source_type' => null !== ($ticket_actuals['door_ticket_revenue'] ?? null) ? 'auto_actual' : 'not_available',
                    'breakdown_lines' => array(),
                    'warnings' => (array) ($ticket_actuals['warnings'] ?? array()),
                )
            ),
            'tickets_sold' => $tickets_sold,
            'online_tickets_sold' => $this->build_metric(
                'online_tickets_sold',
                __('Online Tickets Sold', 'vms-investor-portal'),
                'count',
                array(
                    'available' => null !== ($ticket_actuals['advance_tickets_sold'] ?? null),
                    'value' => (int) ($ticket_actuals['advance_tickets_sold'] ?? 0),
                    'source_key' => (string) ($ticket_actuals['advance_tickets_source_key'] ?? ''),
                    'source_label' => (string) ($ticket_actuals['advance_tickets_source_label'] ?? __('Not available', 'vms-investor-portal')),
                    'source_type' => null !== ($ticket_actuals['advance_tickets_sold'] ?? null) ? 'auto_actual' : 'not_available',
                    'breakdown_lines' => array(),
                    'warnings' => (array) ($ticket_actuals['warnings'] ?? array()),
                )
            ),
            'door_tickets_sold' => $this->build_metric(
                'door_tickets_sold',
                __('Door Tickets Sold', 'vms-investor-portal'),
                'count',
                array(
                    'available' => null !== ($ticket_actuals['door_tickets_sold'] ?? null),
                    'value' => (int) ($ticket_actuals['door_tickets_sold'] ?? 0),
                    'source_key' => (string) ($ticket_actuals['door_tickets_source_key'] ?? ''),
                    'source_label' => (string) ($ticket_actuals['door_tickets_source_label'] ?? __('Not available', 'vms-investor-portal')),
                    'source_type' => null !== ($ticket_actuals['door_tickets_sold'] ?? null) ? 'auto_actual' : 'not_available',
                    'breakdown_lines' => array(),
                    'warnings' => (array) ($ticket_actuals['warnings'] ?? array()),
                )
            ),
            'attendance_total' => $attendance_total,
            'checked_in_scanned' => $checked_in_scanned,
            'concession_sales' => $concession_sales,
            'bar_sales' => $this->build_metric('bar_sales', __('Bar Sales', 'vms-investor-portal'), 'currency', $bar_sales_auto),
            'food_sales' => $this->build_metric('food_sales', __('Food Sales', 'vms-investor-portal'), 'currency', $food_sales_auto),
            'merch_sales' => $this->build_metric('merch_sales', __('Merch Sales', 'vms-investor-portal'), 'currency', $merch_sales_auto),
            'website_addons' => $this->build_metric('website_addons', __('Website Add-ons', 'vms-investor-portal'), 'currency', $website_addons_auto),
            'estimated_sales_tax' => $estimated_tax,
            'labor_cost' => $labor_cost,
            'performer_cost' => $performer_cost,
            'ad_spend' => $ad_spend,
            'other_direct_costs' => $other_direct_costs,
            'concession_cost' => $concession_cost,
            'other_expenses' => $other_expenses,
            'estimated_event_net' => $estimated_event_net,
        );

        return array(
            'metrics' => $metrics,
            'warnings' => $source_warnings,
            'ticket_actuals' => $ticket_actuals,
            'attendance_actuals' => $attendance_actuals,
        );
    }

    /**
     * @param array<string,mixed> $snapshot_payload
     * @return array<string,mixed>
     */
    public function sanitize_snapshot_payload_for_storage(array $snapshot_payload): array
    {
        $payload = $this->normalize_snapshot_payload($snapshot_payload);
        $stripped_paths = array();
        $payload = $this->strip_disallowed_snapshot_keys($payload, $stripped_paths);

        if (!empty($stripped_paths)) {
            $payload_warnings = isset($payload['warnings']) && is_array($payload['warnings']) ? $payload['warnings'] : array();
            $payload_warnings[] = __('Snapshot payload was compacted before storage to remove raw source rows.', 'vms-investor-portal');
            $payload['warnings'] = array_values(array_unique(array_filter(array_map('strval', $payload_warnings))));
        }

        return $payload;
    }

    /**
     * @param array<string,mixed> $snapshot_payload
     * @param array<string,mixed> $manual_record
     * @return array<string,mixed>
     */
    public function prepare_snapshot_payload_for_display(array $snapshot_payload, array $manual_record = array(), string $snapshot_updated_at = ''): array
    {
        $payload = $this->normalize_snapshot_payload($snapshot_payload);
        $payload['metrics'] = $this->apply_manual_overrides_to_metrics(
            isset($payload['metrics']) && is_array($payload['metrics']) ? $payload['metrics'] : array(),
            $manual_record,
            $snapshot_updated_at
        );

        return $payload;
    }

    /**
     * @param array<string,mixed> $manual_record
     * @return array<string,mixed>
     */
    public function empty_snapshot_payload_for_display(array $manual_record = array(), string $snapshot_updated_at = ''): array
    {
        return $this->prepare_snapshot_payload_for_display(array(), $manual_record, $snapshot_updated_at);
    }

    /**
     * @param array<string,mixed> $context
     * @return array<string,mixed>
     */
    private function collect_sources(WP_Post $post, array $context): array
    {
        $event_plan_id = (int) ($context['event_plan_id'] ?? 0);
        $sources = array(
            'warnings' => array(),
            'dt_model_available' => false,
            'dt_row' => array(),
            'dt_summary' => array(),
            'dt_costs' => array(),
            'ad_spend_available' => false,
            'ad_spend_cents' => 0,
            'ad_spend_source_key' => '',
            'ad_spend_source_label' => '',
            'ad_spend_warnings' => array(),
            'goals_direct_costs_available' => false,
            'goals_default_direct_costs_cents' => 0,
            'goals_overhead_available' => false,
            'goals_overhead_cents' => 0,
            'ticket_truth' => array(),
            'ticket_snapshot' => array(),
            'headcount_context' => array(),
        );

        if ($event_plan_id > 0 && $this->load_data_tools_reporting_support()) {
            try {
                $model = (array) vms_dt_reporting_build_event_model(array(
                    'event_plan_id' => $event_plan_id,
                    'event_from' => '',
                    'event_to' => '',
                    'sold_from' => '',
                    'sold_to' => '',
                    'venue_id' => 0,
                    'square_location_id' => '',
                    'square_scope_mode' => 'full_day',
                    'compare' => 0,
                ));
                $sources['dt_model_available'] = !empty($model);
                $sources['dt_row'] = isset($model['row']) && is_array($model['row']) ? (array) $model['row'] : array();
                $sources['dt_summary'] = isset($model['summary']) && is_array($model['summary']) ? (array) $model['summary'] : array();
                $sources['dt_costs'] = isset($model['costs']) && is_array($model['costs']) ? (array) $model['costs'] : array();
                $sources['warnings'] = $this->merge_warnings(
                    (array) ($sources['dt_row']['square_warnings'] ?? array()),
                    (array) ($sources['dt_row']['square_errors'] ?? array()),
                    (array) ($sources['dt_row']['confidence_badges'] ?? array())
                );

                if (function_exists('vms_dt_reporting_profitability_ad_spend_data')) {
                    $ad_spend_data = (array) vms_dt_reporting_profitability_ad_spend_data($event_plan_id, $sources['dt_row']);
                    $ad_spend_cents = max(0, (int) ($ad_spend_data['cents'] ?? 0));
                    if ($ad_spend_cents > 0) {
                        $sources['ad_spend_available'] = true;
                        $sources['ad_spend_cents'] = $ad_spend_cents;
                        $sources['ad_spend_source_key'] = (string) ($ad_spend_data['source'] ?? 'vms_dt_reporting_profitability_ad_spend_data()');
                        $sources['ad_spend_source_label'] = (string) ($ad_spend_data['label'] ?? __('Advertising', 'vms-investor-portal'));
                    }
                }
                unset($model);
            } catch (Throwable $exception) {
                $sources['warnings'][] = sprintf(
                    /* translators: %s: exception message */
                    __('Data Tools event model could not be loaded: %s', 'vms-investor-portal'),
                    $exception->getMessage()
                );
            }
        }

        if ($event_plan_id > 0 && $this->load_vms_goals_support()) {
            if (vms_investor_has_core_function('vms_goals_get_default_direct_costs_cents')) {
                $sources['goals_default_direct_costs_cents'] = max(0, (int) vms_investor_call_core_function('vms_goals_get_default_direct_costs_cents', $event_plan_id));
                $sources['goals_direct_costs_available'] = $sources['goals_default_direct_costs_cents'] > 0;
            }
        }

        if ($event_plan_id > 0 && $this->load_vms_event_command_center_support()) {
            if (vms_investor_has_core_function('vms_event_command_center_get_ticket_reporting_truth')) {
                try {
                    $sources['ticket_truth'] = (array) vms_investor_call_core_function('vms_event_command_center_get_ticket_reporting_truth', $event_plan_id);
                } catch (Throwable $exception) {
                    $sources['warnings'][] = sprintf(
                        __('Ticket reporting truth could not be loaded: %s', 'vms-investor-portal'),
                        $exception->getMessage()
                    );
                }
            }
        }

        if ($event_plan_id > 0) {
            $sources['ticket_snapshot'] = $this->build_ticket_snapshot_summary($event_plan_id, (array) ($sources['ticket_truth'] ?? array()));
        }

        if ($event_plan_id > 0 && $this->load_vms_staffing_support() && vms_investor_has_core_function('vms_staffing_get_event_plan_headcount_context')) {
            try {
                $sources['headcount_context'] = (array) vms_investor_call_core_function('vms_staffing_get_event_plan_headcount_context', $event_plan_id);
            } catch (Throwable $exception) {
                $sources['warnings'][] = sprintf(
                    __('Headcount context could not be loaded: %s', 'vms-investor-portal'),
                    $exception->getMessage()
                );
            }
        }

        $attendance_seed = 0;
        if (!empty($sources['ticket_snapshot'])) {
            $attendance_seed = max(0, (int) ($sources['ticket_snapshot']['total_ticket_count'] ?? 0));
        } elseif (!empty($sources['ticket_truth'])) {
            $attendance_seed = max(0, (int) ($sources['ticket_truth']['total_qty'] ?? 0));
        }

        if ($event_plan_id > 0 && $this->load_vms_goals_support() && vms_investor_has_core_function('vms_goals_get_settings') && vms_investor_has_core_function('vms_goals_get_overhead_allocated_cents')) {
            try {
                $settings = (array) vms_investor_call_core_function('vms_goals_get_settings');
                $overhead_rules = isset($settings['overhead_rules']) && is_array($settings['overhead_rules']) ? (array) $settings['overhead_rules'] : array();
                $gross_cents = max(0, (int) (
                    ($sources['dt_costs']['ticket_sales_total_cents'] ?? 0)
                    + ($sources['dt_summary']['website_addons_net_cents'] ?? ($sources['dt_row']['website_addon_net_cents'] ?? 0))
                    + ($sources['dt_summary']['onsite_non_ticket_cents'] ?? 0)
                ));
                $sources['goals_overhead_cents'] = max(0, (int) vms_investor_call_core_function('vms_goals_get_overhead_allocated_cents', $gross_cents, $attendance_seed, $overhead_rules));
                $sources['goals_overhead_available'] = $sources['goals_overhead_cents'] > 0 || !empty($overhead_rules);
            } catch (Throwable $exception) {
                $sources['warnings'][] = sprintf(
                    __('Overhead allocation could not be loaded: %s', 'vms-investor-portal'),
                    $exception->getMessage()
                );
            }
        }

        unset($post);

        return $sources;
    }

    /**
     * @param array<string,mixed> $context
     * @param array<string,mixed> $sources
     * @return array<string,mixed>
     */
    private function resolve_ticket_actuals(WP_Post $post, array $context, array $sources): array
    {
        $cache_key = implode(':', array(
            absint($context['tec_event_id'] ?? 0),
            absint($context['event_plan_id'] ?? 0),
        ));

        if (isset($this->ticket_actuals_cache[$cache_key])) {
            return $this->ticket_actuals_cache[$cache_key];
        }

        $result = array(
            'available' => false,
            'partial_only' => false,
            'ticket_revenue' => 0.0,
            'tickets_sold' => 0,
            'advance_ticket_revenue' => null,
            'door_ticket_revenue' => null,
            'advance_tickets_sold' => null,
            'door_tickets_sold' => null,
            'revenue_source_key' => '',
            'tickets_source_key' => '',
            'revenue_source_label' => __('Not available', 'vms-investor-portal'),
            'tickets_source_label' => __('Not available', 'vms-investor-portal'),
            'advance_revenue_source_key' => '',
            'door_revenue_source_key' => '',
            'advance_tickets_source_key' => '',
            'door_tickets_source_key' => '',
            'advance_revenue_source_label' => '',
            'door_revenue_source_label' => '',
            'advance_tickets_source_label' => '',
            'door_tickets_source_label' => '',
            'warnings' => array(),
        );

        if (!empty($sources['dt_model_available'])) {
            $row = (array) ($sources['dt_row'] ?? array());
            $summary = (array) ($sources['dt_summary'] ?? array());
            $costs = (array) ($sources['dt_costs'] ?? array());
            $advance_ticket_revenue_cents = max(0, (int) ($summary['online_ticket_sales_cents'] ?? ($row['website_ticket_net_cents'] ?? 0)));
            $door_ticket_revenue_cents = max(0, (int) ($summary['door_ticket_sales_cents'] ?? ($row['square_direct_tickets_cents'] ?? 0)));
            $ticket_revenue_cents = max(0, (int) ($costs['ticket_sales_total_cents'] ?? ($summary['total_ticket_sales_cents'] ?? ($advance_ticket_revenue_cents + $door_ticket_revenue_cents))));
            $advance_tickets_sold = max(0, (int) ($row['website_paid_ticket_qty'] ?? 0));
            $door_tickets_sold = max(0, (int) ($row['square_paid_ticket_qty'] ?? 0));
            $tickets_sold = max(0, (int) ($costs['paid_ticket_qty_total'] ?? 0));
            if ($tickets_sold <= 0 && ($advance_tickets_sold > 0 || $door_tickets_sold > 0)) {
                $tickets_sold = $advance_tickets_sold + $door_tickets_sold;
            }

            $result = array(
                'available' => true,
                'partial_only' => false,
                'ticket_revenue' => $ticket_revenue_cents / 100,
                'tickets_sold' => $tickets_sold,
                'advance_ticket_revenue' => $advance_ticket_revenue_cents / 100,
                'door_ticket_revenue' => $door_ticket_revenue_cents / 100,
                'advance_tickets_sold' => $advance_tickets_sold,
                'door_tickets_sold' => $door_tickets_sold,
                'revenue_source_key' => 'dt_model.costs.ticket_sales_total_cents',
                'tickets_source_key' => 'dt_model.costs.paid_ticket_qty_total',
                'revenue_source_label' => __('Data Tools reporting model', 'vms-investor-portal'),
                'tickets_source_label' => __('Data Tools reporting model', 'vms-investor-portal'),
                'advance_revenue_source_key' => 'dt_model.row.website_ticket_net_cents',
                'door_revenue_source_key' => 'dt_model.row.square_direct_tickets_cents',
                'advance_tickets_source_key' => 'dt_model.row.website_paid_ticket_qty',
                'door_tickets_source_key' => 'dt_model.row.square_paid_ticket_qty',
                'advance_revenue_source_label' => __('WooCommerce online orders', 'vms-investor-portal'),
                'door_revenue_source_label' => __('Door orders', 'vms-investor-portal'),
                'advance_tickets_source_label' => __('WooCommerce online orders', 'vms-investor-portal'),
                'door_tickets_source_label' => __('Door orders', 'vms-investor-portal'),
                'warnings' => $this->merge_warnings(
                    (array) ($row['square_warnings'] ?? array()),
                    (array) ($row['square_errors'] ?? array())
                ),
            );

            $this->ticket_actuals_cache[$cache_key] = $result;
            return $result;
        }

        if (!empty($sources['ticket_truth']['available'])) {
            $truth = (array) $sources['ticket_truth'];
            $result = array(
                'available' => true,
                'partial_only' => false,
                'ticket_revenue' => max(0, (int) ($truth['revenue_cents'] ?? 0)) / 100,
                'tickets_sold' => max(0, (int) ($truth['paid_qty'] ?? 0)),
                'advance_ticket_revenue' => null,
                'door_ticket_revenue' => null,
                'advance_tickets_sold' => null,
                'door_tickets_sold' => null,
                'revenue_source_key' => 'vms_event_command_center_get_ticket_reporting_truth()',
                'tickets_source_key' => 'vms_event_command_center_get_ticket_reporting_truth()',
                'revenue_source_label' => (string) ($truth['source_label'] ?? __('VMS ticket reporting', 'vms-investor-portal')),
                'tickets_source_label' => (string) ($truth['source_label'] ?? __('VMS ticket reporting', 'vms-investor-portal')),
                'advance_revenue_source_key' => '',
                'door_revenue_source_key' => '',
                'advance_tickets_source_key' => '',
                'door_tickets_source_key' => '',
                'advance_revenue_source_label' => '',
                'door_revenue_source_label' => '',
                'advance_tickets_source_label' => '',
                'door_tickets_source_label' => '',
                'warnings' => (array) ($truth['warnings'] ?? array()),
            );
            $this->ticket_actuals_cache[$cache_key] = $result;
            return $result;
        }

        if (vms_investor_has_core_function('vms_ticket_revenue_build_report')) {
            try {
                $report = (array) vms_investor_call_core_function('vms_ticket_revenue_build_report', array(
                    'event_plan_id' => (int) ($context['event_plan_id'] ?? 0),
                    'tec_event_id' => (int) ($context['tec_event_id'] ?? 0),
                    'recognition_status' => 'all',
                    'order_statuses' => $this->get_paid_order_statuses(),
                    'preview_limit' => 500,
                    'unresolved_limit' => 50,
                ));
                $ticket_revenue = 0.0;
                $tickets_sold = 0;
                foreach ((array) ($report['rows'] ?? array()) as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $item_kind = sanitize_key((string) ($row['item_kind'] ?? 'ticket'));
                    if (in_array($item_kind, array('addon', 'entitlement'), true)) {
                        continue;
                    }
                    $quantity = max(0, (int) ($row['quantity'] ?? 0));
                    $refunded_quantity = max(0, (int) ($row['refunded_quantity'] ?? 0));
                    $net_quantity = max(0, $quantity - $refunded_quantity);
                    $net_cents = max(0, (int) ($row['net_subtotal_cents'] ?? 0));
                    if ($net_cents > 0) {
                        $tickets_sold += $net_quantity;
                    }
                    $ticket_revenue += $net_cents / 100;
                }

                if ($ticket_revenue > 0 || $tickets_sold > 0) {
                    $result = array(
                        'available' => false,
                        'partial_only' => true,
                        'ticket_revenue' => 0.0,
                        'tickets_sold' => 0,
                        'advance_ticket_revenue' => $ticket_revenue,
                        'door_ticket_revenue' => null,
                        'advance_tickets_sold' => $tickets_sold,
                        'door_tickets_sold' => null,
                        'revenue_source_key' => '',
                        'tickets_source_key' => '',
                        'revenue_source_label' => __('Total ticket revenue unavailable without door data', 'vms-investor-portal'),
                        'tickets_source_label' => __('Total tickets sold unavailable without door data', 'vms-investor-portal'),
                        'advance_revenue_source_key' => 'vms_ticket_revenue_build_report()',
                        'door_revenue_source_key' => '',
                        'advance_tickets_source_key' => 'vms_ticket_revenue_build_report()',
                        'door_tickets_source_key' => '',
                        'advance_revenue_source_label' => __('WooCommerce online orders only', 'vms-investor-portal'),
                        'door_revenue_source_label' => '',
                        'advance_tickets_source_label' => __('WooCommerce online orders only', 'vms-investor-portal'),
                        'door_tickets_source_label' => '',
                        'warnings' => (array) ($report['warnings'] ?? array()),
                    );
                }
            } catch (Throwable $exception) {
                $result['warnings'][] = sprintf(
                    __('Ticket revenue rows could not be loaded: %s', 'vms-investor-portal'),
                    $exception->getMessage()
                );
            }
        }

        $this->ticket_actuals_cache[$cache_key] = $result;

        unset($post);

        return $result;
    }

    /**
     * @param array<string,mixed> $context
     * @param array<string,mixed> $sources
     * @param array<string,mixed> $ticket_actuals
     * @return array<string,mixed>
     */
    private function resolve_attendance_actuals(WP_Post $post, array $context, array $sources, array $ticket_actuals): array
    {
        $attendance_event_id = (int) ($context['tec_event_id'] ?? 0);
        $attendance_source = sanitize_key((string) $post->post_type);
        if ($attendance_event_id <= 0) {
            $attendance_event_id = (int) $post->ID;
        }
        $cache_key = $attendance_event_id . ':' . $attendance_source;

        if (isset($this->attendance_actuals_cache[$cache_key])) {
            return $this->attendance_actuals_cache[$cache_key];
        }

        $result = array(
            'available' => false,
            'value' => 0,
            'source_key' => '',
            'source_label' => __('Not available', 'vms-investor-portal'),
            'mode' => 'none',
            'ticketed_total' => 0,
            'admissions_total' => 0,
            'true_headcount_total' => 0,
            'checked_in_available' => false,
            'checked_in' => 0,
            'checked_in_source_label' => __('Not available', 'vms-investor-portal'),
            'warnings' => array(),
        );

        $checked_in = $this->resolve_checked_in_actuals($attendance_event_id, $attendance_source);
        $result['checked_in_available'] = !empty($checked_in['available']);
        $result['checked_in'] = (int) ($checked_in['value'] ?? 0);
        $result['checked_in_source_label'] = (string) ($checked_in['source_label'] ?? __('Not available', 'vms-investor-portal'));

        $event_plan_id = (int) ($context['event_plan_id'] ?? 0);
        if ($event_plan_id > 0) {
            $true_headcount = max(0, (int) get_post_meta($event_plan_id, '_vms_true_headcount', true));
            $true_comp_headcount = max(0, (int) get_post_meta($event_plan_id, '_vms_comp_headcount_true', true));
            $true_headcount_total = $true_headcount > 0 ? $true_headcount + $true_comp_headcount : 0;
            if ($true_headcount_total > 0) {
                $result['available'] = true;
                $result['value'] = $true_headcount_total;
                $result['source_key'] = 'meta._vms_true_headcount + meta._vms_comp_headcount_true';
                $result['source_label'] = __('True headcount', 'vms-investor-portal');
                $result['mode'] = 'true_headcount';
                $result['true_headcount_total'] = $true_headcount_total;
                $this->attendance_actuals_cache[$cache_key] = $result;
                return $result;
            }

            $ticketed_total = 0;
            $ticket_source_key = '';
            $ticket_source_label = '';
            if (!empty($sources['ticket_snapshot'])) {
                $ticketed_total = max(0, (int) ($sources['ticket_snapshot']['total_ticket_count'] ?? 0));
                $ticket_source_key = 'vms_event_command_center_get_ticket_snapshot()';
                $ticket_source_label = trim((string) ($sources['ticket_snapshot']['ticket_source_label'] ?? ''));
            } elseif (!empty($sources['headcount_context']['wired'])) {
                $ticketed_total = max(0, (int) ($sources['headcount_context']['headcount'] ?? 0));
                $ticket_source_key = 'vms_staffing_get_event_plan_headcount_context()';
                $ticket_source_label = trim((string) ($sources['headcount_context']['label'] ?? ''));
            } elseif (!empty($ticket_actuals['available'])) {
                $ticketed_total = max(0, (int) ($ticket_actuals['tickets_sold'] ?? 0));
                $ticket_source_key = (string) ($ticket_actuals['tickets_source_key'] ?? '');
                $ticket_source_label = trim((string) ($ticket_actuals['tickets_source_label'] ?? ''));
            }

            $admissions_total = $this->get_admissions_headcount($event_plan_id);
            $attendance_total = max(0, $ticketed_total + $admissions_total);
            if ($attendance_total > 0) {
                $result['available'] = true;
                $result['value'] = $attendance_total;
                $result['mode'] = $admissions_total > 0
                    ? ($ticketed_total > 0 ? 'ticket_plus_admissions' : 'admissions_only')
                    : 'ticket_only';
                $result['ticketed_total'] = $ticketed_total;
                $result['admissions_total'] = $admissions_total;
                $result['source_key'] = $admissions_total > 0
                    ? $ticket_source_key . ' + vms_admission_table_entries()'
                    : $ticket_source_key;
                if ($admissions_total > 0 && $ticketed_total > 0) {
                    $result['source_label'] = __('Ticket reporting + admissions', 'vms-investor-portal');
                } elseif ($admissions_total > 0) {
                    $result['source_label'] = __('Admissions records', 'vms-investor-portal');
                } else {
                    $result['source_label'] = $ticket_source_label !== '' ? $ticket_source_label : __('Ticket reporting', 'vms-investor-portal');
                }
                $this->attendance_actuals_cache[$cache_key] = $result;
                return $result;
            }
        }

        if (!empty($sources['headcount_context']['wired'])) {
            $result['available'] = true;
            $result['value'] = max(0, (int) ($sources['headcount_context']['headcount'] ?? 0));
            $result['source_key'] = 'vms_staffing_get_event_plan_headcount_context()';
            $result['source_label'] = (string) ($sources['headcount_context']['label'] ?? __('Expected attendance', 'vms-investor-portal'));
            $result['mode'] = 'expected_attendance';
        }

        $this->attendance_actuals_cache[$cache_key] = $result;

        return $result;
    }

    /**
     * @return array<string,mixed>
     */
    private function resolve_checked_in_actuals(int $attendance_event_id, string $attendance_source): array
    {
        $result = array(
            'available' => false,
            'value' => 0,
            'source_label' => __('Not available', 'vms-investor-portal'),
        );

        if ($attendance_event_id <= 0) {
            return $result;
        }

        try {
            $tribe_checked_in = $this->count_checked_in_attendees_from_event_tickets($attendance_event_id);
            $local_scan_count = $this->count_checked_in_local_scans($attendance_event_id);
            $guest_list_checked_in = $this->count_checked_in_guest_list_entries($attendance_event_id, $attendance_source);
            $count = max($tribe_checked_in, $local_scan_count) + $guest_list_checked_in;

            if ($count > 0) {
                $result = array(
                    'available' => true,
                    'value' => max(0, $count),
                    'source_label' => __('VMS Ops check-ins', 'vms-investor-portal'),
                );
            }
        } catch (Throwable $exception) {
            unset($exception);
        }

        return $result;
    }

    private function get_admissions_headcount(int $event_plan_id): int
    {
        $event_plan_id = absint($event_plan_id);
        if ($event_plan_id <= 0 || !$this->load_vms_admissions_support() || !vms_investor_has_core_function('vms_admission_table_entries')) {
            return 0;
        }

        global $wpdb;
        $table = vms_investor_call_core_function('vms_admission_table_entries');
        if (!$wpdb || !is_string($table) || $table === '') {
            return 0;
        }

        static $table_exists_cache = array();
        if (!array_key_exists($table, $table_exists_cache)) {
            $table_exists_cache[$table] = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table);
        }

        if (empty($table_exists_cache[$table])) {
            return 0;
        }

        return max(0, (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(CASE WHEN status <> 'canceled' THEN party_size ELSE 0 END), 0)
             FROM {$table}
             WHERE event_plan_id = %d",
            $event_plan_id
        )));
    }

    private function load_data_tools_reporting_support(): bool
    {
        if (function_exists('vms_dt_reporting_build_event_model')) {
            return true;
        }

        foreach ($this->candidate_files(array(
            defined('VMS_DT_ADMIN_DIR') ? VMS_DT_ADMIN_DIR . 'page-revenue-intelligence.php' : '',
            defined('VMS_DT_ADMIN_DIR') ? VMS_DT_ADMIN_DIR . 'page-reporting-module.php' : '',
            defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR . '/vms-data-tools/includes/admin/page-revenue-intelligence.php' : '',
            defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR . '/vms-data-tools/includes/admin/page-reporting-module.php' : '',
        )) as $candidate) {
            require_once $candidate;
            if (function_exists('vms_dt_reporting_build_event_model')) {
                return true;
            }
        }

        return false;
    }

    private function load_vms_goals_support(): bool
    {
        if (vms_investor_has_core_function('vms_goals_get_event_pnl')) {
            return true;
        }

        $core_path = (string) vms_investor_core_constant('VMS_PLUGIN_PATH', '');
        foreach ($this->candidate_files(array(
            $core_path !== '' ? $core_path . 'includes/core/goals-forecast.php' : '',
            defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR . '/vms/includes/core/goals-forecast.php' : '',
        )) as $candidate) {
            require_once $candidate;
            if (vms_investor_has_core_function('vms_goals_get_event_pnl')) {
                return true;
            }
        }

        return false;
    }

    private function load_vms_event_command_center_support(): bool
    {
        if (vms_investor_has_core_function('vms_event_command_center_get_ticket_reporting_truth')) {
            return true;
        }

        $core_path = (string) vms_investor_core_constant('VMS_PLUGIN_PATH', '');
        foreach ($this->candidate_files(array(
            $core_path !== '' ? $core_path . 'includes/admin/event-command-center.php' : '',
            defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR . '/vms/includes/admin/event-command-center.php' : '',
        )) as $candidate) {
            require_once $candidate;
            if (vms_investor_has_core_function('vms_event_command_center_get_ticket_reporting_truth')) {
                return true;
            }
        }

        return false;
    }

    private function load_vms_staffing_support(): bool
    {
        if (vms_investor_has_core_function('vms_staffing_get_event_plan_headcount_context')) {
            return true;
        }

        $core_path = (string) vms_investor_core_constant('VMS_PLUGIN_PATH', '');
        foreach ($this->candidate_files(array(
            $core_path !== '' ? $core_path . 'includes/core/staffing.php' : '',
            defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR . '/vms/includes/core/staffing.php' : '',
        )) as $candidate) {
            require_once $candidate;
            if (vms_investor_has_core_function('vms_staffing_get_event_plan_headcount_context')) {
                return true;
            }
        }

        return false;
    }

    private function load_vms_admissions_support(): bool
    {
        if (vms_investor_has_core_function('vms_admission_table_entries')) {
            return true;
        }

        $core_path = (string) vms_investor_core_constant('VMS_PLUGIN_PATH', '');
        foreach ($this->candidate_files(array(
            $core_path !== '' ? $core_path . 'includes/modules/admissions/db.php' : '',
            defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR . '/vms/includes/modules/admissions/db.php' : '',
        )) as $candidate) {
            require_once $candidate;
            if (vms_investor_has_core_function('vms_admission_table_entries')) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param string[] $paths
     * @return string[]
     */
    private function candidate_files(array $paths): array
    {
        return array_values(array_unique(array_filter($paths, static function ($path): bool {
            return is_string($path) && $path !== '' && is_readable($path);
        })));
    }

    /**
     * @param array<string,mixed> $ticket_truth
     * @return array<string,mixed>
     */
    private function build_ticket_snapshot_summary(int $event_plan_id, array $ticket_truth): array
    {
        $summary = array();
        if ($event_plan_id <= 0) {
            return $summary;
        }

        if (!empty($ticket_truth['available'])) {
            $sold = max(0, (int) ($ticket_truth['paid_qty'] ?? 0));
            $comp_count = max(0, (int) get_post_meta($event_plan_id, '_vms_comp_headcount_forecast', true));
            $comp_count = max($comp_count, max(0, (int) ($ticket_truth['free_qty'] ?? 0)));
            $true_comp_count = max(0, (int) get_post_meta($event_plan_id, '_vms_comp_headcount_true', true));
            if ($true_comp_count > 0) {
                $comp_count = $true_comp_count;
            }

            $total_ticket_count = $sold + $comp_count;
            $reported_total = max(0, (int) ($ticket_truth['total_qty'] ?? 0));
            if ($reported_total > 0) {
                $total_ticket_count = max($total_ticket_count, $reported_total);
            }

            return array(
                'total_ticket_count' => $total_ticket_count,
                'ticket_source_label' => (string) ($ticket_truth['source_label'] ?? __('Ticket reporting', 'vms-investor-portal')),
                'ticket_source_warnings' => isset($ticket_truth['warnings']) && is_array($ticket_truth['warnings'])
                    ? array_values(array_filter(array_map('strval', $ticket_truth['warnings'])))
                    : array(),
            );
        }

        if (vms_investor_has_core_function('vms_event_command_center_get_ticket_snapshot_light')) {
            try {
                $snapshot = (array) vms_investor_call_core_function('vms_event_command_center_get_ticket_snapshot_light', $event_plan_id);
                return array(
                    'total_ticket_count' => max(0, (int) ($snapshot['total_ticket_count'] ?? 0)),
                    'ticket_source_label' => trim((string) ($snapshot['ticket_source_label'] ?? __('Ticket reporting', 'vms-investor-portal'))),
                    'ticket_source_warnings' => isset($snapshot['ticket_source_warnings']) && is_array($snapshot['ticket_source_warnings'])
                        ? array_values(array_filter(array_map('strval', $snapshot['ticket_source_warnings'])))
                        : array(),
                );
            } catch (Throwable $exception) {
                unset($exception);
            }
        }

        return $summary;
    }

    private function count_checked_in_attendees_from_event_tickets(int $event_id): int
    {
        if ($event_id <= 0 || !class_exists('Tribe__Tickets__Tickets') || !method_exists('Tribe__Tickets__Tickets', 'get_event_checkedin_attendees_count')) {
            return 0;
        }

        try {
            return max(0, (int) Tribe__Tickets__Tickets::get_event_checkedin_attendees_count($event_id));
        } catch (Throwable $exception) {
            unset($exception);
        }

        return 0;
    }

    private function count_checked_in_local_scans(int $event_id): int
    {
        if ($event_id <= 0 || !function_exists('vms_ops_table_pc_scan_log')) {
            return 0;
        }

        global $wpdb;
        if (!$wpdb) {
            return 0;
        }

        $table = vms_ops_table_pc_scan_log();
        if (!is_string($table) || $table === '') {
            return 0;
        }

        try {
            return max(0, (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT scan_hash) FROM {$table} WHERE event_id = %d AND result_code = %s AND scan_hash <> '' AND scan_type <> %s",
                $event_id,
                'checked_in',
                'guest_list'
            )));
        } catch (Throwable $exception) {
            unset($exception);
        }

        return 0;
    }

    private function count_checked_in_guest_list_entries(int $event_id, string $event_source): int
    {
        if ($event_id <= 0 || !function_exists('vms_ops_ticket_resolve_event_plan_id_for_guest_list')) {
            return 0;
        }

        $event_plan_id = (int) vms_ops_ticket_resolve_event_plan_id_for_guest_list($event_id, $event_source);
        if ($event_plan_id <= 0 || !$this->load_vms_admissions_support() || !vms_investor_has_core_function('vms_admission_table_entries')) {
            return 0;
        }

        global $wpdb;
        if (!$wpdb) {
            return 0;
        }

        $table = vms_investor_call_core_function('vms_admission_table_entries');
        if (!is_string($table) || $table === '') {
            return 0;
        }

        try {
            return max(0, (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(checked_in_qty), 0) FROM {$table} WHERE event_plan_id = %d AND status IN ('active','partial','checked_in')",
                $event_plan_id
            )));
        } catch (Throwable $exception) {
            unset($exception);
        }

        return 0;
    }

    /**
     * @return array<string,array<string,string>>
     */
    private function metric_blueprints(): array
    {
        return array(
            'ticket_revenue' => array(
                'label' => __('Total Ticket Revenue', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => 'ticket_revenue_override',
                'legacy_key' => 'ticket_revenue',
            ),
            'online_ticket_sales' => array(
                'label' => __('Online Ticket Sales', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'door_ticket_sales' => array(
                'label' => __('Door Ticket Sales', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'tickets_sold' => array(
                'label' => __('Total Tickets Sold', 'vms-investor-portal'),
                'kind' => 'count',
                'override_key' => 'tickets_sold_override',
                'legacy_key' => 'tickets_sold',
            ),
            'online_tickets_sold' => array(
                'label' => __('Online Tickets Sold', 'vms-investor-portal'),
                'kind' => 'count',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'door_tickets_sold' => array(
                'label' => __('Door Tickets Sold', 'vms-investor-portal'),
                'kind' => 'count',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'attendance_total' => array(
                'label' => __('Total Attendance', 'vms-investor-portal'),
                'kind' => 'count',
                'override_key' => 'attendance_total_override',
                'legacy_key' => 'attendance_total',
            ),
            'checked_in_scanned' => array(
                'label' => __('Checked In / Scanned', 'vms-investor-portal'),
                'kind' => 'count',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'concession_sales' => array(
                'label' => __('Concession / On-site Sales', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => 'concession_sales_override',
                'legacy_key' => 'concession_sales',
            ),
            'bar_sales' => array(
                'label' => __('Bar Sales', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'food_sales' => array(
                'label' => __('Food Sales', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'merch_sales' => array(
                'label' => __('Merch Sales', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'website_addons' => array(
                'label' => __('Website Add-ons', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'estimated_sales_tax' => array(
                'label' => __('Estimated Sales Tax Collected', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => 'estimated_tax_override',
                'legacy_key' => '',
            ),
            'labor_cost' => array(
                'label' => __('Labor', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => 'labor_cost_override',
                'legacy_key' => 'labor_cost',
            ),
            'performer_cost' => array(
                'label' => __('Performer/Vendor Cost', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => 'performer_cost_override',
                'legacy_key' => 'performer_cost',
            ),
            'ad_spend' => array(
                'label' => __('Advertising', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => 'ad_spend_override',
                'legacy_key' => 'ad_spend',
            ),
            'other_direct_costs' => array(
                'label' => __('Other Direct Costs', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => '',
                'legacy_key' => '',
            ),
            'concession_cost' => array(
                'label' => __('Concession Costs', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => 'concession_cost_override',
                'legacy_key' => 'concession_cost',
            ),
            'other_expenses' => array(
                'label' => __('Additional Overhead', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => 'other_expenses_override',
                'legacy_key' => 'other_expenses',
            ),
            'estimated_event_net' => array(
                'label' => __('Estimated Event Net', 'vms-investor-portal'),
                'kind' => 'currency',
                'override_key' => 'estimated_event_net_override',
                'legacy_key' => '',
            ),
        );
    }

    /**
     * @param array<string,mixed> $snapshot_payload
     * @return array<string,mixed>
     */
    private function normalize_snapshot_payload(array $snapshot_payload): array
    {
        $metrics = isset($snapshot_payload['metrics']) && is_array($snapshot_payload['metrics']) ? $snapshot_payload['metrics'] : array();
        $normalized_metrics = array();

        foreach ($this->metric_blueprints() as $key => $blueprint) {
            $metric = isset($metrics[$key]) && is_array($metrics[$key]) ? $metrics[$key] : $this->build_unavailable_metric($key, $blueprint);
            $metric['key'] = $key;
            $metric['label'] = (string) ($metric['label'] ?? $blueprint['label']);
            $metric['kind'] = (string) ($metric['kind'] ?? $blueprint['kind']);
            $metric['override_key'] = (string) ($metric['override_key'] ?? $blueprint['override_key']);
            $metric['legacy_key'] = (string) ($metric['legacy_key'] ?? $blueprint['legacy_key']);
            $metric['warnings'] = isset($metric['warnings']) && is_array($metric['warnings']) ? array_values(array_filter(array_map('strval', $metric['warnings']))) : array();
            $metric['breakdown_lines'] = isset($metric['breakdown_lines']) && is_array($metric['breakdown_lines']) ? array_values(array_filter(array_map('strval', $metric['breakdown_lines']))) : array();
            $normalized_metrics[$key] = $metric;
        }

        return array(
            'metrics' => $normalized_metrics,
            'warnings' => isset($snapshot_payload['warnings']) && is_array($snapshot_payload['warnings'])
                ? array_values(array_filter(array_map('strval', $snapshot_payload['warnings'])))
                : array(),
            'ticket_actuals' => $this->normalize_ticket_actuals_snapshot(
                isset($snapshot_payload['ticket_actuals']) && is_array($snapshot_payload['ticket_actuals'])
                    ? $snapshot_payload['ticket_actuals']
                    : array()
            ),
            'attendance_actuals' => $this->normalize_attendance_actuals_snapshot(
                isset($snapshot_payload['attendance_actuals']) && is_array($snapshot_payload['attendance_actuals'])
                    ? $snapshot_payload['attendance_actuals']
                    : array()
            ),
        );
    }

    /**
     * @param array<string,mixed> $ticket_actuals
     * @return array<string,mixed>
     */
    private function normalize_ticket_actuals_snapshot(array $ticket_actuals): array
    {
        return array(
            'available' => !empty($ticket_actuals['available']),
            'partial_only' => !empty($ticket_actuals['partial_only']),
            'ticket_revenue' => isset($ticket_actuals['ticket_revenue']) ? (float) $ticket_actuals['ticket_revenue'] : 0.0,
            'tickets_sold' => isset($ticket_actuals['tickets_sold']) ? (int) $ticket_actuals['tickets_sold'] : 0,
            'advance_ticket_revenue' => array_key_exists('advance_ticket_revenue', $ticket_actuals) && null !== $ticket_actuals['advance_ticket_revenue']
                ? (float) $ticket_actuals['advance_ticket_revenue']
                : null,
            'door_ticket_revenue' => array_key_exists('door_ticket_revenue', $ticket_actuals) && null !== $ticket_actuals['door_ticket_revenue']
                ? (float) $ticket_actuals['door_ticket_revenue']
                : null,
            'advance_tickets_sold' => array_key_exists('advance_tickets_sold', $ticket_actuals) && null !== $ticket_actuals['advance_tickets_sold']
                ? (int) $ticket_actuals['advance_tickets_sold']
                : null,
            'door_tickets_sold' => array_key_exists('door_tickets_sold', $ticket_actuals) && null !== $ticket_actuals['door_tickets_sold']
                ? (int) $ticket_actuals['door_tickets_sold']
                : null,
            'revenue_source_key' => sanitize_text_field((string) ($ticket_actuals['revenue_source_key'] ?? '')),
            'tickets_source_key' => sanitize_text_field((string) ($ticket_actuals['tickets_source_key'] ?? '')),
            'revenue_source_label' => sanitize_text_field((string) ($ticket_actuals['revenue_source_label'] ?? __('Not available', 'vms-investor-portal'))),
            'tickets_source_label' => sanitize_text_field((string) ($ticket_actuals['tickets_source_label'] ?? __('Not available', 'vms-investor-portal'))),
            'advance_revenue_source_key' => sanitize_text_field((string) ($ticket_actuals['advance_revenue_source_key'] ?? '')),
            'door_revenue_source_key' => sanitize_text_field((string) ($ticket_actuals['door_revenue_source_key'] ?? '')),
            'advance_tickets_source_key' => sanitize_text_field((string) ($ticket_actuals['advance_tickets_source_key'] ?? '')),
            'door_tickets_source_key' => sanitize_text_field((string) ($ticket_actuals['door_tickets_source_key'] ?? '')),
            'advance_revenue_source_label' => sanitize_text_field((string) ($ticket_actuals['advance_revenue_source_label'] ?? '')),
            'door_revenue_source_label' => sanitize_text_field((string) ($ticket_actuals['door_revenue_source_label'] ?? '')),
            'advance_tickets_source_label' => sanitize_text_field((string) ($ticket_actuals['advance_tickets_source_label'] ?? '')),
            'door_tickets_source_label' => sanitize_text_field((string) ($ticket_actuals['door_tickets_source_label'] ?? '')),
            'warnings' => isset($ticket_actuals['warnings']) && is_array($ticket_actuals['warnings'])
                ? array_values(array_filter(array_map('strval', $ticket_actuals['warnings'])))
                : array(),
        );
    }

    /**
     * @param array<string,mixed> $attendance_actuals
     * @return array<string,mixed>
     */
    private function normalize_attendance_actuals_snapshot(array $attendance_actuals): array
    {
        return array(
            'available' => !empty($attendance_actuals['available']),
            'value' => isset($attendance_actuals['value']) ? (int) $attendance_actuals['value'] : 0,
            'source_key' => sanitize_text_field((string) ($attendance_actuals['source_key'] ?? '')),
            'source_label' => sanitize_text_field((string) ($attendance_actuals['source_label'] ?? __('Not available', 'vms-investor-portal'))),
            'mode' => sanitize_key((string) ($attendance_actuals['mode'] ?? 'none')),
            'ticketed_total' => isset($attendance_actuals['ticketed_total']) ? (int) $attendance_actuals['ticketed_total'] : 0,
            'admissions_total' => isset($attendance_actuals['admissions_total']) ? (int) $attendance_actuals['admissions_total'] : 0,
            'true_headcount_total' => isset($attendance_actuals['true_headcount_total']) ? (int) $attendance_actuals['true_headcount_total'] : 0,
            'checked_in_available' => !empty($attendance_actuals['checked_in_available']),
            'checked_in' => isset($attendance_actuals['checked_in']) ? (int) $attendance_actuals['checked_in'] : 0,
            'checked_in_source_label' => sanitize_text_field((string) ($attendance_actuals['checked_in_source_label'] ?? __('Not available', 'vms-investor-portal'))),
            'warnings' => isset($attendance_actuals['warnings']) && is_array($attendance_actuals['warnings'])
                ? array_values(array_filter(array_map('strval', $attendance_actuals['warnings'])))
                : array(),
        );
    }

    /**
     * @param array<string,mixed> $payload
     * @param string[] $stripped_paths
     * @return array<string,mixed>
     */
    private function strip_disallowed_snapshot_keys(array $payload, array &$stripped_paths): array
    {
        $disallowed_keys = array(
            'attendees',
            'attendee_rows',
            'ops_attendees',
            'orders',
            'order_rows',
            'raw_rows',
            'raw_json',
            'line_items_json',
            'tenders_json',
            'customer',
            'customers',
            'names',
            'emails',
            'ticket_holders',
            'checkins',
            'admissions_rows',
            'rows',
            'ticket_rows',
            'onsite_rows',
            'dataset',
            'evidence',
        );

        $walk = function ($value, string $path = '') use (&$walk, &$stripped_paths, $disallowed_keys) {
            if (!is_array($value)) {
                return $value;
            }

            $sanitized = array();
            foreach ($value as $key => $item) {
                $key_string = is_string($key) ? sanitize_key($key) : (string) $key;
                $item_path = $path === '' ? $key_string : $path . '.' . $key_string;

                if (is_string($key) && in_array($key_string, $disallowed_keys, true)) {
                    $stripped_paths[] = $item_path;
                    continue;
                }

                $sanitized[$key] = $walk($item, $item_path);
            }

            return $sanitized;
        };

        $result = $walk($payload);

        return is_array($result) ? $result : array();
    }

    /**
     * @param array<string,array<string,mixed>> $metrics
     * @param array<string,mixed> $manual_record
     * @return array<string,array<string,mixed>>
     */
    private function apply_manual_overrides_to_metrics(array $metrics, array $manual_record, string $snapshot_updated_at = ''): array
    {
        $normalized = array();

        foreach ($this->metric_blueprints() as $key => $blueprint) {
            $metric = isset($metrics[$key]) && is_array($metrics[$key]) ? $metrics[$key] : $this->build_unavailable_metric($key, $blueprint);
            $auto_available = array_key_exists('auto_available', $metric)
                ? !empty($metric['auto_available'])
                : (!empty($metric['available']) && (string) ($metric['source_type'] ?? '') !== 'manual_override');
            $label = (string) $blueprint['label'];
            if ($key === 'ad_spend' && $this->is_budget_like_source(
                (string) ($metric['auto_source_label'] ?? ($metric['source_label'] ?? '')),
                (string) ($metric['auto_source_key'] ?? ($metric['source_key'] ?? ''))
            )) {
                $label = __('Estimated Advertising', 'vms-investor-portal');
            }
            $auto = array(
                'available' => $auto_available,
                'value' => array_key_exists('auto_value', $metric)
                    ? $metric['auto_value']
                    : ($metric['value'] ?? ($blueprint['kind'] === 'count' ? 0 : 0.0)),
                'source_key' => isset($metric['auto_source_key']) && (string) $metric['auto_source_key'] !== ''
                    ? (string) $metric['auto_source_key']
                    : ((string) ($metric['source_type'] ?? '') === 'manual_override' ? '' : (string) ($metric['source_key'] ?? '')),
                'source_label' => isset($metric['auto_source_label']) && (string) $metric['auto_source_label'] !== ''
                    ? (string) $metric['auto_source_label']
                    : ((string) ($metric['source_type'] ?? '') === 'manual_override' ? __('Not available', 'vms-investor-portal') : (string) ($metric['source_label'] ?? __('Not available', 'vms-investor-portal'))),
                'source_type' => isset($metric['auto_source_type']) && (string) $metric['auto_source_type'] !== ''
                    ? (string) $metric['auto_source_type']
                    : ((string) ($metric['source_type'] ?? '') === 'manual_override' ? 'not_available' : (string) ($metric['source_type'] ?? 'not_available')),
                'freshness_timestamp' => $snapshot_updated_at !== ''
                    ? $snapshot_updated_at
                    : trim((string) ($metric['freshness_timestamp'] ?? '')),
                'warnings' => isset($metric['warnings']) && is_array($metric['warnings']) ? $metric['warnings'] : array(),
                'breakdown_lines' => isset($metric['breakdown_lines']) && is_array($metric['breakdown_lines']) ? $metric['breakdown_lines'] : array(),
            );

            $rebuilt = $this->build_metric(
                $key,
                $label,
                (string) $blueprint['kind'],
                $auto,
                $manual_record,
                (string) $blueprint['override_key'],
                (string) $blueprint['legacy_key']
            );

            if ($snapshot_updated_at !== '' && !empty($rebuilt['auto_available']) && (string) ($rebuilt['freshness_timestamp'] ?? '') === '') {
                $rebuilt['freshness_timestamp'] = $snapshot_updated_at;
            }

            $normalized[$key] = $rebuilt;
        }

        return $this->rebuild_display_estimated_event_net($normalized, $snapshot_updated_at);
    }

    /**
     * @param array<string,array<string,mixed>> $metrics
     * @return array<string,array<string,mixed>>
     */
    private function rebuild_display_estimated_event_net(array $metrics, string $snapshot_updated_at = ''): array
    {
        if (empty($metrics['estimated_event_net']) || !is_array($metrics['estimated_event_net'])) {
            return $metrics;
        }

        $estimated_metric = $metrics['estimated_event_net'];
        if (!empty($estimated_metric['manual_override_active'])) {
            return $metrics;
        }

        $gross_basis = $this->metric_display_amount($metrics, 'ticket_revenue')
            + $this->metric_display_amount($metrics, 'concession_sales')
            + $this->metric_display_amount($metrics, 'website_addons');
        $cost_basis = $this->metric_display_amount($metrics, 'labor_cost')
            + $this->metric_display_amount($metrics, 'performer_cost')
            + $this->metric_display_amount($metrics, 'ad_spend')
            + $this->metric_display_amount($metrics, 'other_direct_costs')
            + $this->metric_display_amount($metrics, 'concession_cost')
            + $this->metric_display_amount($metrics, 'other_expenses');

        $display_available = $this->metric_display_available($metrics, 'ticket_revenue')
            || $this->metric_display_available($metrics, 'concession_sales')
            || $this->metric_display_available($metrics, 'website_addons')
            || $this->metric_display_available($metrics, 'labor_cost')
            || $this->metric_display_available($metrics, 'performer_cost')
            || $this->metric_display_available($metrics, 'ad_spend')
            || $this->metric_display_available($metrics, 'other_direct_costs')
            || $this->metric_display_available($metrics, 'concession_cost')
            || $this->metric_display_available($metrics, 'other_expenses');

        $component_overrides_active = $this->metric_display_override_active($metrics, 'ticket_revenue')
            || $this->metric_display_override_active($metrics, 'concession_sales')
            || $this->metric_display_override_active($metrics, 'labor_cost')
            || $this->metric_display_override_active($metrics, 'performer_cost')
            || $this->metric_display_override_active($metrics, 'ad_spend')
            || $this->metric_display_override_active($metrics, 'concession_cost')
            || $this->metric_display_override_active($metrics, 'other_expenses');

        $estimated_metric['available'] = $display_available;
        $estimated_metric['value'] = $display_available ? ($gross_basis - $cost_basis) : 0.0;
        $estimated_metric['source_key'] = $display_available
            ? ($component_overrides_active ? 'investor_provider.net.displayed_component_basis' : 'investor_provider.net.transparent_basis')
            : '';
        $estimated_metric['source_label'] = $display_available
            ? ($component_overrides_active
                ? __('Derived from displayed component values', 'vms-investor-portal')
                : __('Investor metrics provider transparent basis', 'vms-investor-portal'))
            : __('Not available', 'vms-investor-portal');
        $estimated_metric['source_type'] = $display_available
            ? ($component_overrides_active ? 'fallback' : ((string) ($estimated_metric['auto_source_type'] ?? 'auto_actual')))
            : 'not_available';
        $estimated_metric['breakdown_lines'] = $display_available
            ? array(
                sprintf(
                    /* translators: 1: gross basis, 2: cost basis */
                    __('Displayed revenue basis %1$s minus displayed costs %2$s.', 'vms-investor-portal'),
                    $this->format_money_for_line($gross_basis),
                    $this->format_money_for_line($cost_basis)
                ),
                $component_overrides_active
                    ? __('Displayed Estimated Event Net reflects the currently displayed revenue and cost values, including manual overrides.', 'vms-investor-portal')
                    : __('Displayed Estimated Event Net reflects the current investor presentation basis.', 'vms-investor-portal'),
            )
            : array();
        $warnings = isset($estimated_metric['warnings']) && is_array($estimated_metric['warnings']) ? $estimated_metric['warnings'] : array();
        if ($component_overrides_active) {
            $warnings[] = __('Displayed Estimated Event Net reflects the currently displayed revenue and cost values, including manual overrides. Auto Estimated Event Net remains available in diagnostics.', 'vms-investor-portal');
        }
        $estimated_metric['warnings'] = array_values(array_unique(array_filter(array_map('strval', $warnings))));
        if ($snapshot_updated_at !== '' && (string) ($estimated_metric['freshness_timestamp'] ?? '') === '' && !empty($estimated_metric['auto_available'])) {
            $estimated_metric['freshness_timestamp'] = $snapshot_updated_at;
        }

        $metrics['estimated_event_net'] = $estimated_metric;

        return $metrics;
    }

    /**
     * @param array<string,array<string,mixed>> $metrics
     */
    private function metric_display_amount(array $metrics, string $key): float
    {
        $metric = isset($metrics[$key]) && is_array($metrics[$key]) ? $metrics[$key] : array();
        if (empty($metric['available']) || !array_key_exists('value', $metric) || null === $metric['value']) {
            return 0.0;
        }

        return (float) $metric['value'];
    }

    /**
     * @param array<string,array<string,mixed>> $metrics
     */
    private function metric_display_available(array $metrics, string $key): bool
    {
        return !empty($metrics[$key]['available']);
    }

    /**
     * @param array<string,array<string,mixed>> $metrics
     */
    private function metric_display_override_active(array $metrics, string $key): bool
    {
        return !empty($metrics[$key]['manual_override_active']);
    }

    /**
     * @param array<string,string> $blueprint
     * @return array<string,mixed>
     */
    private function build_unavailable_metric(string $key, array $blueprint): array
    {
        return $this->build_metric(
            $key,
            (string) $blueprint['label'],
            (string) $blueprint['kind'],
            array(
                'available' => false,
                'value' => $blueprint['kind'] === 'count' ? 0 : 0.0,
                'source_key' => '',
                'source_label' => __('Not available', 'vms-investor-portal'),
                'source_type' => 'not_available',
                'breakdown_lines' => array(),
                'warnings' => array(),
            ),
            array(),
            (string) $blueprint['override_key'],
            (string) $blueprint['legacy_key']
        );
    }

    /**
     * @param array<string,mixed> $manual_record
     * @param array<string,mixed> $auto
     * @return array<string,mixed>
     */
    private function build_metric(
        string $key,
        string $label,
        string $kind,
        array $auto,
        array $manual_record = array(),
        string $override_key = '',
        string $legacy_key = ''
    ): array {
        $auto_available = !empty($auto['available']);
        $auto_value = $auto_available ? ($kind === 'count' ? (int) ($auto['value'] ?? 0) : (float) ($auto['value'] ?? 0.0)) : null;
        $override = $this->resolve_override_value($manual_record, $override_key, $legacy_key, $kind === 'count' ? 'int' : 'decimal');
        $source_type = $auto_available ? (string) ($auto['source_type'] ?? 'auto_actual') : 'not_available';
        $source_key = $auto_available ? (string) ($auto['source_key'] ?? '') : '';
        $source_label = $auto_available ? (string) ($auto['source_label'] ?? __('Not available', 'vms-investor-portal')) : __('Not available', 'vms-investor-portal');
        $warnings = isset($auto['warnings']) && is_array($auto['warnings']) ? array_values(array_filter(array_map('strval', $auto['warnings']))) : array();

        $value = $kind === 'count' ? 0 : 0.0;
        $available = $auto_available;
        if ($override['active']) {
            $value = $kind === 'count' ? (int) $override['value'] : (float) $override['value'];
            $available = true;
            $source_type = 'manual_override';
            $source_key = $override_key !== '' ? 'record.' . $override_key : 'manual_override';
            $source_label = $override['origin'] === 'legacy_manual'
                ? __('Manual override (legacy)', 'vms-investor-portal')
                : __('Manual override', 'vms-investor-portal');
            $warnings[] = __('Manual override is active for this metric.', 'vms-investor-portal');
        } elseif ($auto_available) {
            $value = $kind === 'count' ? (int) $auto_value : (float) $auto_value;
        }

        return array(
            'key' => $key,
            'label' => $label,
            'kind' => $kind,
            'available' => $available,
            'value' => $value,
            'auto_available' => $auto_available,
            'auto_value' => $auto_value,
            'manual_override_active' => !empty($override['active']),
            'manual_override_value' => $override['active'] ? $override['value'] : null,
            'manual_override_origin' => (string) ($override['origin'] ?? ''),
            'source_key' => $source_key,
            'source_label' => $source_label,
            'source_type' => $source_type,
            'auto_source_key' => $auto_available ? (string) ($auto['source_key'] ?? '') : '',
            'auto_source_label' => $auto_available ? (string) ($auto['source_label'] ?? __('Not available', 'vms-investor-portal')) : __('Not available', 'vms-investor-portal'),
            'auto_source_type' => $auto_available ? (string) ($auto['source_type'] ?? 'auto_actual') : 'not_available',
            'freshness_timestamp' => $override['active']
                ? trim((string) ($manual_record['updated_at'] ?? ''))
                : trim((string) ($auto['freshness_timestamp'] ?? '')),
            'warnings' => array_values(array_unique(array_filter($warnings))),
            'breakdown_lines' => isset($auto['breakdown_lines']) && is_array($auto['breakdown_lines'])
                ? array_values(array_filter(array_map('strval', $auto['breakdown_lines'])))
                : array(),
            'override_key' => $override_key,
            'legacy_key' => $legacy_key,
        );
    }

    private function is_budget_like_source(string $label, string $source_key): bool
    {
        $haystack = strtolower(trim($label . ' ' . $source_key));
        if ($haystack === '') {
            return false;
        }

        return false !== strpos($haystack, 'budget')
            || false !== strpos($haystack, 'meta ads')
            || false !== strpos($haystack, 'meta_ads');
    }

    /**
     * @param array<string,mixed> $record
     * @return array<string,mixed>
     */
    private function resolve_override_value(array $record, string $override_key, string $legacy_key, string $type): array
    {
        $default = array(
            'active' => false,
            'origin' => '',
            'value' => null,
        );

        if ($override_key !== '' && array_key_exists($override_key, $record) && null !== $record[$override_key] && '' !== (string) $record[$override_key]) {
            $default['active'] = true;
            $default['origin'] = 'manual_override';
            $default['value'] = $type === 'decimal' ? (float) $record[$override_key] : (int) $record[$override_key];
            return $default;
        }

        if ($legacy_key !== '' && $type === 'decimal' && isset($record[$legacy_key]) && (float) $record[$legacy_key] !== 0.0) {
            $default['active'] = true;
            $default['origin'] = 'legacy_manual';
            $default['value'] = (float) $record[$legacy_key];
            return $default;
        }

        if ($legacy_key !== '' && $type === 'int' && isset($record[$legacy_key]) && (int) $record[$legacy_key] !== 0) {
            $default['active'] = true;
            $default['origin'] = 'legacy_manual';
            $default['value'] = (int) $record[$legacy_key];
            return $default;
        }

        return $default;
    }

    /**
     * @param array<string,mixed> $ticket_actuals
     * @return string[]
     */
    private function build_ticket_revenue_breakdown_lines(array $ticket_actuals): array
    {
        $lines = array();

        if (null !== ($ticket_actuals['advance_ticket_revenue'] ?? null)) {
            $lines[] = sprintf(
                __('Advance / online: %1$s from %2$s.', 'vms-investor-portal'),
                $this->format_money_for_line((float) $ticket_actuals['advance_ticket_revenue']),
                (string) ($ticket_actuals['advance_revenue_source_label'] ?? __('WooCommerce online orders', 'vms-investor-portal'))
            );
        }

        if (null !== ($ticket_actuals['door_ticket_revenue'] ?? null)) {
            $lines[] = sprintf(
                __('Door: %1$s from %2$s.', 'vms-investor-portal'),
                $this->format_money_for_line((float) $ticket_actuals['door_ticket_revenue']),
                (string) ($ticket_actuals['door_revenue_source_label'] ?? __('Door orders', 'vms-investor-portal'))
            );
        }

        if (!empty($ticket_actuals['partial_only'])) {
            $lines[] = __('Only advance / online orders were detected automatically. Use a manual override when door revenue is missing from reporting.', 'vms-investor-portal');
        }

        return $lines;
    }

    /**
     * @param array<string,mixed> $ticket_actuals
     * @return string[]
     */
    private function build_ticket_sold_breakdown_lines(array $ticket_actuals): array
    {
        $lines = array();

        if (null !== ($ticket_actuals['advance_tickets_sold'] ?? null)) {
            $lines[] = sprintf(
                __('Advance / online: %1$s from %2$s.', 'vms-investor-portal'),
                number_format_i18n((int) $ticket_actuals['advance_tickets_sold']),
                (string) ($ticket_actuals['advance_tickets_source_label'] ?? __('WooCommerce online orders', 'vms-investor-portal'))
            );
        }

        if (null !== ($ticket_actuals['door_tickets_sold'] ?? null)) {
            $lines[] = sprintf(
                __('Door: %1$s from %2$s.', 'vms-investor-portal'),
                number_format_i18n((int) $ticket_actuals['door_tickets_sold']),
                (string) ($ticket_actuals['door_tickets_source_label'] ?? __('Door orders', 'vms-investor-portal'))
            );
        }

        if (!empty($ticket_actuals['partial_only'])) {
            $lines[] = __('Only advance / online ticket counts were detected automatically. Use a manual override when door counts are missing from reporting.', 'vms-investor-portal');
        }

        return $lines;
    }

    /**
     * @param array<string,mixed> $attendance_actuals
     * @return string[]
     */
    private function build_attendance_breakdown_lines(array $attendance_actuals): array
    {
        $lines = array();
        $mode = sanitize_key((string) ($attendance_actuals['mode'] ?? ''));
        $ticketed_total = max(0, (int) ($attendance_actuals['ticketed_total'] ?? 0));
        $admissions_total = max(0, (int) ($attendance_actuals['admissions_total'] ?? 0));
        $true_headcount_total = max(0, (int) ($attendance_actuals['true_headcount_total'] ?? 0));

        if ($mode === 'true_headcount' && $true_headcount_total > 0) {
            $lines[] = __('Total attendance is using the saved true headcount on the event plan.', 'vms-investor-portal');
        } elseif ($mode === 'ticket_plus_admissions') {
            $lines[] = sprintf(
                __('Ticket/admitted count: %1$s, plus %2$s from admissions records.', 'vms-investor-portal'),
                number_format_i18n($ticketed_total),
                number_format_i18n($admissions_total)
            );
        } elseif ($mode === 'admissions_only' && $admissions_total > 0) {
            $lines[] = sprintf(
                __('Admissions records: %1$s.', 'vms-investor-portal'),
                number_format_i18n($admissions_total)
            );
        } elseif ($mode === 'ticket_only' && $ticketed_total > 0) {
            $lines[] = sprintf(
                __('Ticket/admitted count from reporting: %1$s.', 'vms-investor-portal'),
                number_format_i18n($ticketed_total)
            );
        } elseif ($mode === 'expected_attendance' && !empty($attendance_actuals['value'])) {
            $lines[] = __('Using expected attendance context because no finalized attendance source was available.', 'vms-investor-portal');
        }

        if (!empty($attendance_actuals['checked_in_available'])) {
            $lines[] = sprintf(
                __('Checked in / scanned: %1$s from %2$s.', 'vms-investor-portal'),
                number_format_i18n((int) ($attendance_actuals['checked_in'] ?? 0)),
                (string) ($attendance_actuals['checked_in_source_label'] ?? __('VMS Ops check-ins', 'vms-investor-portal'))
            );
        }

        return $lines;
    }

    /**
     * @param array<string,mixed> $metric
     */
    private function breakdown_line_for_metric(string $label, array $metric, string $kind): string
    {
        if (empty($metric['available'])) {
            return '';
        }

        $value = $kind === 'currency'
            ? $this->format_money_for_line((float) ($metric['value'] ?? 0.0))
            : number_format_i18n((int) ($metric['value'] ?? 0));

        return sprintf('%1$s: %2$s.', $label, $value);
    }

    /**
     * @param array<int,array<int|string,mixed>> $warning_sets
     * @return string[]
     */
    private function merge_warnings(...$warning_sets): array
    {
        $warnings = array();

        foreach ($warning_sets as $set) {
            if (!is_array($set)) {
                continue;
            }
            foreach ($set as $warning) {
                $warning = trim((string) $warning);
                if ($warning === '') {
                    continue;
                }
                $warnings[] = $warning;
            }
        }

        return array_values(array_unique($warnings));
    }

    /**
     * @param string[] $breakdown_lines
     * @param string[] $warnings
     * @return array<string,mixed>
     */
    private function dt_currency_metric(
        float $value,
        bool $available,
        string $source_key,
        string $source_label,
        array $breakdown_lines = array(),
        array $warnings = array()
    ): array {
        return array(
            'available' => $available && ($value > 0 || $source_key !== ''),
            'value' => max(0, $value),
            'source_key' => $source_key,
            'source_label' => $available ? $source_label : __('Not available', 'vms-investor-portal'),
            'source_type' => $available ? 'auto_actual' : 'not_available',
            'breakdown_lines' => $breakdown_lines,
            'warnings' => $warnings,
        );
    }

    private function format_money_for_line(float $amount): string
    {
        $sign = $amount < 0 ? '-' : '';
        return $sign . '$' . number_format_i18n(abs($amount), 2);
    }

    /**
     * @return string[]
     */
    private function get_paid_order_statuses(): array
    {
        $defaults = array();

        if (function_exists('wc_get_order_statuses')) {
            foreach ((array) wc_get_order_statuses() as $status => $label) {
                $slug = sanitize_key(str_replace('wc-', '', (string) $status));

                if ($slug === '') {
                    continue;
                }

                if (preg_match('/cancel|refund|fail|pending|draft|trash/i', $slug)) {
                    continue;
                }

                if (in_array($slug, array('processing', 'completed'), true) || strpos($slug, 'paid') !== false) {
                    $defaults[] = $slug;
                }

                if (preg_match('/paid/i', (string) $label)) {
                    $defaults[] = $slug;
                }
            }
        }

        if (empty($defaults)) {
            $defaults = array('processing', 'completed');
        }

        $statuses = apply_filters('vms_investor_portal_paid_order_statuses', array_values(array_unique($defaults)));

        if (!is_array($statuses) || empty($statuses)) {
            return array('processing', 'completed');
        }

        return array_values(array_unique(array_filter(array_map('sanitize_key', $statuses))));
    }
}
