<?php
/**
 * Plugin Name: VMS Investor Portal
 * Description: Private investor-facing dashboard for event performance reporting.
 * Version: 0.2.3
 * Author: Coney Productions
 * Text Domain: vms-investor-portal
 */

defined('ABSPATH') || exit;

define('VMS_INVESTOR_PORTAL_VERSION', '0.2.3');
define('VMS_INVESTOR_PORTAL_FILE', __FILE__);
define('VMS_INVESTOR_PORTAL_PATH', plugin_dir_path(__FILE__));
define('VMS_INVESTOR_PORTAL_URL', plugin_dir_url(__FILE__));

require_once VMS_INVESTOR_PORTAL_PATH . 'includes/core-compat.php';
require_once VMS_INVESTOR_PORTAL_PATH . 'includes/class-vms-investor-metrics-provider.php';
require_once VMS_INVESTOR_PORTAL_PATH . 'includes/class-vms-investor-portal.php';

register_activation_hook(__FILE__, array('VMS_Investor_Portal', 'activate'));

VMS_Investor_Portal::instance();
