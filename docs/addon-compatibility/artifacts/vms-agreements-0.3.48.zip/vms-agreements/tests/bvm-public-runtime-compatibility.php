<?php

declare(strict_types=1);

$scenario = $argv[1] ?? '';
if (!in_array($scenario, array('modern', 'legacy', 'old', 'absent'), true)) {
    fwrite(STDERR, "Usage: php tests/bvm-public-runtime-compatibility.php <modern|legacy|old|absent>\n");
    exit(2);
}

define('ABSPATH', __DIR__ . '/');
define('VMSA_MIN_VMS_VERSION', '0.2.24.570');

if ($scenario === 'modern') {
    define('BVMGR_VERSION', '1.2.0');

    function bvmgr_get_event_plan_comp_terms(int $event_plan_id): array
    {
        return array('event_plan_id' => $event_plan_id);
    }
} elseif ($scenario === 'legacy') {
    define('VMS_VERSION', '0.2.24.570');

    function vms_get_event_plan_comp_terms(int $event_plan_id): array
    {
        return array('event_plan_id' => $event_plan_id);
    }
} elseif ($scenario === 'old') {
    define('BVMGR_VERSION', '0.2.24.569');
}

require dirname(__DIR__) . '/includes/helpers.php';

function vmsa_test_assert(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

if ($scenario === 'modern') {
    vmsa_test_assert(vmsa_core_is_loaded(), 'public BVM identity was not detected');
    vmsa_test_assert(vmsa_core_version() === '1.2.0', 'public BVM version was not resolved');
    vmsa_test_assert(vmsa_core_version_ok(), 'public BVM version did not pass the dependency gate');
    vmsa_test_assert(vmsa_core_function_name('vms_get_event_plan_comp_terms') === 'bvmgr_get_event_plan_comp_terms', 'public BVM function was not resolved');
} elseif ($scenario === 'legacy') {
    vmsa_test_assert(vmsa_core_is_loaded(), 'legacy VMS identity was not detected');
    vmsa_test_assert(vmsa_core_version() === '0.2.24.570', 'legacy VMS version was not resolved');
    vmsa_test_assert(vmsa_core_version_ok(), 'minimum supported legacy VMS version did not pass');
    vmsa_test_assert(vmsa_core_function_name('vms_get_event_plan_comp_terms') === 'vms_get_event_plan_comp_terms', 'legacy VMS function was not retained');
} elseif ($scenario === 'old') {
    vmsa_test_assert(vmsa_core_is_loaded(), 'older public BVM identity was not detected');
    vmsa_test_assert(!vmsa_core_version_ok(), 'older public BVM version did not fail closed');
} else {
    vmsa_test_assert(!vmsa_core_is_loaded(), 'missing core identity did not fail closed');
    vmsa_test_assert(vmsa_core_version() === '', 'missing core returned a version');
    vmsa_test_assert(!vmsa_core_version_ok(), 'missing core passed the version gate');
}

fwrite(STDOUT, "PASS: {$scenario}\n");
