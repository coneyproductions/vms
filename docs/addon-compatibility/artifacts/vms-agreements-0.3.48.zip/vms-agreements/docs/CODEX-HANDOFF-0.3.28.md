# Codex Handoff — VMS Agreements 0.3.28

## Package

`vms-agreements-0.3.28-frontend-current-state-fallback-and-stale-hardening.zip`

## Goal

Fix the admin-current/public-stale mismatch for agreement packets and harden packet-generation text cleanup.

## Key changes from 0.3.27

- Version bumped to 0.3.28 in:
  - `vms-agreements.php` plugin header
  - `VMSA_VERSION`
  - `vms-agreements-build.txt`
- `includes/snapshots.php` updates `vmsa_packet_terms_diagnostics()` so public/vendor requests do not falsely mark a packet stale when VMS Core's admin compensation helper is unavailable.
- If `vms_get_event_plan_comp_terms()` is unavailable and the packet snapshot already contains compensation terms, the current-side comparison preserves the packet's stored compensation payload instead of comparing against empty terms.
- Diagnostics now report `comp_helper_available` and any `fallbacks` used.
- `includes/admin.php` displays those new diagnostics fields in the admin Current-State Diagnostics panel.
- `includes/snapshots.php` adds recursive snapshot string cleanup before storing the generated packet hash/snapshot.

## Test focus

1. Install/activate safely.
2. Clear cache once.
3. Open the current packet admin screen and confirm Current-State Diagnostics.
4. Open the exact same packet's public review link and confirm it does not show stale.
5. Confirm vendor portal preview points to the current packet/card state.
6. Confirm newly generated packet title/snapshot does not carry mojibake forward.
7. Confirm manual send and acknowledgement flows still work.

## Repair allowance

Codex may make small, directly related repairs if testing reveals the exact stale mismatch source. If any code changes are made, update version/build markers, changelog/build notes, and test docs consistently before packaging.
