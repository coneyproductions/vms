# Codex Handoff — VMS Agreements 0.3.32

## Package

`vms-agreements-0.3.32-vendor-status-surface-clarity.zip`

## Goal

Tighten admin-side agreement status clarity before real vendor use by adding a vendor-profile Agreements surface and removing “current” wording ambiguity on Event Plans when only historical packets remain.

## Key changes

- Version bumped to `0.3.32` in:
  - `vms-agreements.php` plugin header
  - `VMSA_VERSION`
  - `vms-agreements-build.txt`
- `includes/metaboxes.php`:
  - registers a new `vms_vendor` Agreements metabox
  - shows current needs-review/viewed/current-signed counts plus signed-history count
  - links directly to the current or latest packet from the vendor screen
  - changes Event Plan button copy from **View Current Packet** to **View Latest Packet** when only historical packets remain
  - adds explicit historical-only explanatory text on Event Plans when there is no active packet

## Safety / non-goals

- No packet schema changes
- No email-template changes
- No acknowledgement or cleanup rule changes
- No vendor-portal routing or token validation changes

## Test focus

1. Confirm vendor admin shows agreement status at a glance.
2. Confirm Event Plans no longer imply a historical packet is current.
3. Confirm current/history links still open the expected packet.
4. Re-run send/resend, acknowledgement, and cleanup smoke checks to ensure no regressions.
