# VMS Agreements 0.3.48 Handoff

## Scope

Vendor-portal routing registration repair for Backstage Venue Manager 1.2.0.

## Root cause and change

Agreements already registered a native navigation link and custom-tab content provider, but it did not register `agreements` on BVM's `vms_vendor_portal_allowed_tabs` filter. BVM therefore normalized `?tab=agreements` to `dashboard` before active-state selection and custom rendering.

0.3.48 registers only the `agreements` slug through that public filter. Existing slugs are preserved, and invalid filter values are left for BVM's own fail-closed validation.

## Compatibility and data safety

Existing templates, packets, review tokens, acknowledgement/signature records, hashes, vendor associations, and Event Plan associations do not require migration or regeneration. The repair does not broaden vendor access or change packet queries.

## Package

`vms-agreements-0.3.48-vendor-portal-routing-registration.zip`
