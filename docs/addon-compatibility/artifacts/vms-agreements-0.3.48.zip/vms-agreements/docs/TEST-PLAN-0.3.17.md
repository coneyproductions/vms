# VMS Agreements 0.3.17 Test Plan - Boot / I18n Log Cleanup

## Build Under Test

- VMS Core: `0.2.24.612+`
- VMS Agreements: `0.3.17-boot-i18n-log-cleanup`

## Checks

1. Confirm plugin header reports `0.3.17`.
2. Confirm `VMSA_VERSION` reports `0.3.17`.
3. Confirm `vms-agreements-build.txt` contains:

```text
0.3.17
boot-i18n-log-cleanup
```

4. Clear `debug.log`.
5. Load WP Admin dashboard and **VMS > Agreements**.
6. Confirm no fresh early `vms-agreements` translation notices are logged.
7. Confirm the Agreements item still appears in VMS Planning nav.
8. Confirm the Agreements guided tour still registers and renders normally when launched from the Agreements admin page.
9. Confirm packet generation/view/email/queue behavior remains unchanged.
