# CODEX HANDOFF - VMS Agreements 0.3.8 Printable Copy Readable Width

## Package

`vms-agreements-0.3.8-printable-copy-readable-width.zip`

## Purpose

This is a print-layout-only pass. It makes printable agreement copies more readable by stacking Event, Vendor, and Payment summary cards full-width and rendering Agreement Terms as full-width clause blocks. It intentionally allows normal agreements to overflow to a second page when that is clearer than cramped one-page output.

## Do not change unless a test failure requires it

- Packet schema
- Acknowledgement records
- Review token validation
- Email delivery
- Template editor
- Packet generation/regeneration/void/stale guardrails

## Required test plan

Run `docs/TEST-PLAN-0.3.8.md`.

## Failure/versioning protocol

If code changes are needed, update plugin header version, VMSA_VERSION, vms-agreements-build.txt, CHANGELOG.md, docs/HANDOFF.md, relevant test plan docs, and the package filename before returning a complete replacement zip.
