# Codex Handoff - VMS Agreements 0.3.16

## Build

- Plugin: `vms-agreements`
- Version: `0.3.16`
- Build label: `template-editor-hardening`
- Requires VMS Core: `0.2.24.570+`

## Purpose

This is an admin-side hardening pass for the Template Block Editor. The agreement workflow is already functional; this pass makes it harder for an operator to accidentally leave the template in a broken state and easier to recover required components without hand-editing raw metadata.

## What Changed

- Added a clearer Template Health Check panel with error/warning counts and plain-English consequence text.
- Added an admin-only **Repair Required Components** action in the template editor.
- Repair restores required/protected blocks where missing, disabled, or empty; merges required acknowledgement rows back in; refreshes health metadata; and bumps the template patch version only when stored components changed.
- Template saves now redirect with `template_saved_needs_attention` when blocking health-check errors remain.
- Required editable blocks show clearer badges: Stock wording, Customized wording, or Needs wording.
- Empty required clause bodies show an inline warning explaining that packet generation will be blocked.
- Added CSS for the hardened health panel, status badges, and inline required-clause warning.

## What Did Not Change

- No packet schema changes.
- No review-token validation changes.
- No acknowledgement submission changes.
- No review-link email delivery mechanics or diagnostics changes.
- No operator queue behavior changes.
- No vendor portal behavior changes.
- No public print layout changes.
- No default template wording/content migration changes.

## Files Changed

- `vms-agreements.php`
- `includes/admin.php`
- `includes/template-blocks.php`
- `includes/helpers.php`
- `assets/admin.css`
- `vms-agreements-build.txt`
- `docs/CHANGELOG.md`
- `docs/HANDOFF.md`
- `docs/README.md`
- `docs/TEST-PLAN-0.3.16.md`
- `docs/CODEX-HANDOFF-0.3.16.md`

## Required Test Plan

Run:

- `docs/TEST-PLAN-0.3.16.md`

## 🚨 Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small, Codex must update all relevant version markers and packaging docs in the same pass before returning a repaired zip.

At minimum, update:

1. Plugin header version.
2. `VMSA_VERSION`.
3. `vms-agreements-build.txt`.
4. `docs/CHANGELOG.md`.
5. Relevant test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale version numbers or stale build notes.
