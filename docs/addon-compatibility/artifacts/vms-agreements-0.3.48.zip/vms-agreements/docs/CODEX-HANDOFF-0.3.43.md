# VMS Agreements 0.3.43 Codex Handoff

## Goal
Standardize the visual typography hierarchy across both the vendor-facing HTML agreement and print/PDF output, and make an unacknowledged printed packet physically executable without changing substantive agreement terms.

## Changes
- Defines one effective four-level agreement typography system for screen and print: document title, section heading, subsection heading, and body text.
- Applies the body size consistently to summary detail rows, payment lists, bonus table/note, production responsibilities, production schedule, agreement body paragraphs, and acknowledgement copy.
- Uses weight/spacing instead of extra font-size variations for labels and emphasis.
- Print/PDF uses the same hierarchy at compact point sizes; the repeating packet identity footer remains intentionally smaller as print metadata.
- Adds a print-only Physical Signatures panel for unacknowledged packets with Vendor and Venue execution lines.
- Once a packet has electronic acknowledgement proof, blank physical signature lines are not rendered.

## Compatibility
- Presentation-only CSS changes do not alter packet snapshots or hashes.
- The physical-signature panel is derived from already-snapshotted Vendor legal identity and Venue contracting identity and does not mutate packet data.
- Existing electronically acknowledged packets remain valid and print with acknowledgement proof.
