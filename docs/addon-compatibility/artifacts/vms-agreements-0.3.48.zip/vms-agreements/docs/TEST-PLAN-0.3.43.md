# VMS Agreements 0.3.43 Test Plan

## HTML typography
1. Open an unacknowledged vendor Agreement Packet review page.
2. Confirm the packet uses a consistent hierarchy for document title, section headings, subsection headings, and body text.
3. Confirm Event/Vendor details, Compensation/Payment Terms, bonus table/note, Production Responsibilities, Production Schedule, Agreement Text, and signer area no longer use visibly unrelated one-off font sizes.
4. Confirm mobile layouts still stack without clipping or overlap.

## Print / PDF typography
1. Open Print / Save as PDF.
2. Confirm the same hierarchy is preserved at print-appropriate sizes.
3. Confirm summary rows, bonus table/note, production rows, clauses, and acknowledgement status use the shared print body size.
4. Confirm the existing packet identity footer remains readable and visually subordinate.
5. Confirm no text overlap or clipping in print preview.

## Physical signatures
1. Print an unacknowledged packet and confirm a Physical Signatures panel is present.
2. Confirm Vendor side shows snapshotted legal contracting name plus Signature, Printed name, Title / capacity if applicable, and Date lines.
3. Confirm Venue side shows snapshotted contracting party plus Signature, Printed name, Title / capacity, and Date lines.
4. Acknowledge a packet electronically and re-open print view; confirm blank physical-signature lines are replaced by the normal acknowledgement proof path.

## Regression
- Contract wording, payment method/timing, bonus rules, production schedule, weather/nonperformance terms, phone formatting, packet hashes, and acknowledgement flow remain unchanged.
- All plugin PHP files pass `php -l` and the release ZIP passes `unzip -t`.
