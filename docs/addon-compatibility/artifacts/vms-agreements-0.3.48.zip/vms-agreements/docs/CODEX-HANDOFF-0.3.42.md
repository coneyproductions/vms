# VMS Agreements 0.3.42 Codex Handoff

## Goal
Close the remaining Reputation agreement gaps around objective production timing, artist-friendly weather cancellation, safety-related refusal to proceed, and consistent phone-number presentation.

## Changes
- Adds Agreement Setup Production Schedule fields:
  - Arrival / load-in — required.
  - Soundcheck starts — required.
  - Soundcheck complete by — required.
  - Load-out / venue vacate by — optional; when blank the packet says it will be communicated by Venue.
- New packets snapshot the Production Schedule and include it in the terms hash/current-vs-stale comparison.
- Public review, print/PDF, formal Agreement Text, admin packet review, and Event Plan read-only Agreement status surface the agreed schedule.
- Weather/safety cancellation now uses an objective 24-hour cutoff measured from the scheduled arrival/load-in time in the acknowledged packet:
  - 24+ hours before arrival/load-in: no base guarantee, except separately agreed nonrefundable amount/approved expense.
  - Inside 24 hours: 100% of base guarantee, whether or not Vendor has departed or arrived.
  - Approx. 72-hour forecast review is expressly a planning goal, not a payment cutoff.
- If an otherwise owed cancellation payment is to be credited toward a rescheduled engagement, both parties must accept that treatment in writing.
- No-show/nonperformance language now covers unjustified refusal/material delay in load-in, setup, soundcheck, or performance while preserving Vendor personnel's right not to work during rain on the uncovered stage or another immediate unsafe condition.
- Venue Rules treats the packet Production Schedule as the agreed baseline and preserves the acknowledged arrival/load-in time as the weather-cutoff anchor unless both sides agree in writing to change it before the cutoff.
- Formats 10-digit North American phone numbers as `(###) ###-####` throughout Agreements. An 11-digit value beginning with `1` is normalized to the same format. Non-10-digit values are left unchanged rather than guessed.
- Exact-match migration updates untouched stock 0.3.41 Agreement Scope, Weather/Safety, No-show/Nonperformance, Venue Rules, and terms-review acknowledgement language while preserving customized operator wording.

## Compatibility
- Historical packet terms hashes remain valid because Production Schedule enters the hash only when the stored snapshot contains that structure.
- New/regenerated packets require arrival/load-in plus soundcheck start/end before generation.
- A stale 0.3.37 Event Plan browser tab cannot wipe later Production Schedule values because schedule fields are only rewritten when those inputs are actually submitted.
