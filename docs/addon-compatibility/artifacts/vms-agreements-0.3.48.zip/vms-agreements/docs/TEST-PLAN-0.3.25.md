# VMS Agreements 0.3.25 Test Plan — Stale Hash + Admin Preview Mojibake Fix

## Scope

This patch repairs two issues found after 0.3.24:

1. A freshly regenerated packet could still show **Event Plan terms changed since packet generation**.
2. Admin-side Agreement Text Preview could still show mojibake fragments such as `â€`.

## What changed

- Uses an Agreements-owned compensation hash based only on structured compensation terms.
- Adds stable canonical agreement terms-hash comparison that excludes volatile fields such as edit URL, modified timestamp, generated packet IDs, and health-check wording.
- Canonicalizes text in terms-hash comparisons through display/mojibake cleanup.
- Applies final display cleanup to the admin Agreement Text Preview output.
- Expands truncated mojibake repair for `â€` fragments with odd whitespace/control-byte remnants.

## Manual test steps

1. Install and activate `vms-agreements-0.3.25-stale-hash-and-preview-mojibake-fix.zip`.
2. Confirm activation does not fatal-error.
3. Open an existing packet that showed funky characters in **Agreement Text Preview**.
4. Confirm the admin Agreement Text Preview no longer shows raw `â€`, `â€“`, `â€”`, `â€™`, `â€œ`, `â€�`, `â€¦`, or stray `Â` fragments.
5. Regenerate/supersede the current packet for the same Event Plan/vendor.
6. Open the new packet in admin and confirm the terms badge shows **Current**.
7. Open the vendor portal/dashboard for the same vendor and confirm the current agreement card does **not** show **Event Plan terms changed since packet generation** immediately after regeneration.
8. Make a real Event Plan term change that should affect the agreement, such as changing date/time/vendor/compensation/template wording.
9. Confirm the packet then shows stale/needs regeneration.
10. Regenerate again and confirm the warning clears.
11. Confirm 0.3.24 behavior remains:
    - generated packets do not auto-send,
    - admin shows **Not yet sent** until the review email is sent,
    - vendor portal Agreements badge/action-needed banner appears for unsigned agreements,
    - operator/admin signed-notification email sends after acknowledgement.

## Regression checks

- Print / Save PDF still works and remains compact.
- Bonus payout table still renders.
- Vendor review link still opens.
- Vendor acknowledgement still records proof and sends signer confirmation.
- Packet email audit trail still records review email, signer confirmation email, and operator signed-notification email when applicable.

## Codex note

Codex may make small, directly related repairs if testing reveals a regression. If code changes are made, update the VMS Agreements version/build markers, changelog/build notes, and packaged filename consistently before returning the zip.
