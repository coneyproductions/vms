# VMS Agreements 0.3.31 Test Plan — Admin Test Packet Cleanup Tools

## Scope

This patch adds admin-only cleanup tools for test packet clutter without changing the 0.3.29 current/stale/hash behavior or the 0.3.30 Agreement Packet language updates.

## What changed

- Agreement Packet admin detail screens now include a **Testing / Cleanup** section for managers.
- One action deletes unacknowledged generated/sent/viewed/superseded/voided packets for the same Event Plan.
- A second action deletes only stale/history packets for the same Event Plan.
- Packets with acknowledgement history are always skipped, even if they are now superseded or voided.
- Event Plan packet pointers and admin/vendor-portal packet queries refresh after cleanup.

## Manual test steps

1. Install and activate `vms-agreements-0.3.31-admin-test-packet-cleanup-tools.zip`.
2. Confirm version markers:
   - plugin header `0.3.31`
   - `VMSA_VERSION` `0.3.31`
   - `vms-agreements-build.txt` slug `admin-test-packet-cleanup-tools`
3. Generate several packets for one Event Plan so the packet view and history become cluttered.
4. Open one Agreement Packet admin detail screen.
5. Confirm a **Testing / Cleanup** section appears near the bottom of the screen.
6. Confirm the section is only visible to Agreement Packet admins/managers.
7. Confirm both cleanup actions require the confirmation checkbox before submission.
8. Run **Delete unacknowledged packets for this Event Plan**.
9. Confirm packets with statuses `generated`, `sent`, `viewed`, `superseded`, and `voided` are hard-deleted when they do not contain acknowledgement history.
10. Confirm acknowledged packets, including superseded/voided packets with acknowledgement records, are skipped.
11. Confirm the admin notice reports deleted and skipped counts.
12. Recreate clutter if needed and run **Delete stale/history packets for this Event Plan**.
13. Confirm only superseded, voided, or stale packets are deleted.
14. Confirm the current generated/sent/viewed packet is not deleted by the stale/history action.
15. Confirm vendor portal history/counts no longer show deleted packets.
16. Generate one fresh packet after cleanup.
17. Confirm current/stale behavior still works and a fresh current packet remains acknowledgeable when current.

## Regression checks

- Confirm the 0.3.29 raw-title/current-state parity fix still holds for the same packet ID in admin and public review.
- Confirm the 0.3.30 Agreement Packet terminology remains unchanged on vendor-facing review, proof, print/PDF, and default email text.
- Confirm cleanup actions never delete acknowledged packets by default.
- Confirm Event Plan metabox **Latest packet** links no longer point to deleted packets after cleanup.
- Confirm manual email sending remains operator-triggered only.
