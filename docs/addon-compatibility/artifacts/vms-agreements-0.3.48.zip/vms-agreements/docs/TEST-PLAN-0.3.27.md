# VMS Agreements 0.3.27 Test Plan — Current-State Diagnostics + Generation Cleanup

## Scope

This patch is a diagnostic and hardening pass for packets that appear current in admin but stale on the public/vendor side, plus a generation-time cleanup pass for mojibake text.

## What changed

- Adds an admin-only **Agreement Current-State Diagnostics** panel to packet detail screens.
- Uses a shared canonical fingerprint for current/stale decisions and diagnostics.
- Cleans event/vendor/venue/template text before storing new packet snapshots and packet titles.
- Adds stronger no-cache headers and a packet revision query arg to public review/print links.
- Formats generated/audit timestamps using the WordPress site timezone display format.

## Manual test steps

1. Install and activate `vms-agreements-0.3.27-current-state-diagnostics-and-generation-cleanup.zip`.
2. Clear page/object cache once after installation.
3. Open the known agreement packet for the affected vendor/event.
4. Confirm the packet admin screen loads with no fatal error.
5. Confirm the top status pill and the new **Agreement Current-State Diagnostics** panel agree.
6. Open the diagnostics panel and record:
   - Stored hash
   - Packet canonical hash
   - Current Event Plan hash
   - Field-level differences, if any
7. If diagnostics says no field-level differences, confirm the packet is shown as current.
8. Click **Open Vendor Review** from that exact packet screen.
9. Confirm the vendor/public review URL uses the same packet ID and includes a `vmsa_rev` query arg.
10. Confirm the public review page status agrees with the admin packet diagnostics.
11. Regenerate/supersede the packet once.
12. Confirm the newly generated packet title and snapshot cards do not show mojibake such as `â€`, `â€“`, `Ã¢â‚¬`, or stray `Â`.
13. Confirm the vendor portal Agreements tab/card points to the newest current packet, not an older superseded/stale packet.
14. Confirm generated/audit timestamps display in the WordPress site timezone and readable date/time format.

## Regression checks

- Vendor review email remains manual-send only.
- **Not yet sent** flag still appears before manual email send.
- Vendor portal Action Needed banner and Agreements badge still appear for unsigned packets.
- Print / Save PDF still opens.
- Acknowledgement still sends signer confirmation and operator notification.

## Codex focus

Codex should prioritize capturing the diagnostics table if any packet still reports stale after regeneration. The field-level differences are now the source of truth for the next repair.
