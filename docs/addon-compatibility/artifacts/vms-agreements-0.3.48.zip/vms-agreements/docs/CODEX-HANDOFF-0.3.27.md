# Codex Handoff — VMS Agreements 0.3.27

## Package

`vms-agreements-0.3.27-current-state-diagnostics-and-generation-cleanup.zip`

## Goal

Stop guessing about current/stale disagreement and expose exactly which field is causing the mismatch. Also prevent mojibake from being stored into newly generated packet snapshots/titles.

## Key changes from 0.3.26

- Version bumped to 0.3.27 in:
  - `vms-agreements.php` plugin header
  - `VMSA_VERSION`
  - `vms-agreements-build.txt`
- `includes/snapshots.php` now includes canonical diagnostics helpers:
  - `vmsa_snapshot_terms_canonical_payload()`
  - `vmsa_diff_terms_payloads()`
  - `vmsa_packet_terms_diagnostics()`
- `vmsa_packet_current_terms_status()` now returns diagnostics and treats an empty canonical diff as current.
- Packet generation now cleans event title, vendor fields, venue name, and template title before storing the packet snapshot.
- `includes/admin.php` adds an admin-only **Agreement Current-State Diagnostics** panel on packet detail screens.
- Public review and vendor-portal agreement rendering call `vmsa_disable_public_cache()`.
- Review/print URLs include `vmsa_rev` to reduce stale cache reuse.
- Generated timestamps in admin list/audit output now use `vmsa_format_audit_datetime()`.

## Test focus

1. Activation safety.
2. Current/stale consistency between admin packet screen and public review URL.
3. Diagnostics panel output when stale appears.
4. Mojibake cleanup on newly generated packets.
5. Vendor portal uses newest active packet after regeneration.
6. Timezone-correct generated/audit display.

## Important note

If a packet still appears stale, do not keep regenerating repeatedly. Open the diagnostics panel and capture the field-level differences. That table should identify the exact value still drifting between packet generation and current Event Plan snapshot.
