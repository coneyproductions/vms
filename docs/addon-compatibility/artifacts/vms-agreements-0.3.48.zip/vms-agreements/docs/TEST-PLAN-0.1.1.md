# VMS Agreements 0.1.1 Test Plan — Menu + Packet Generation Hotfix

## Install / Activation

1. Upload and replace the existing `vms-agreements` plugin.
2. Confirm WordPress shows VMS Agreements version `0.1.1`.
3. Confirm VMS Core `0.2.24.567` or newer is active.

## Menu Visibility

1. Open any VMS admin screen.
2. Confirm the VMS top navigation appears as usual.
3. Open the Planning dropdown.
4. Confirm `Agreements` appears near Event Plans.
5. Click `Agreements`.
6. Confirm the URL uses `admin.php?page=vms-agreements`.
7. Confirm the Agreement Packets screen renders.

## Legacy URL Redirect

1. Visit `wp-admin/admin.php?page=vmsa-agreements`.
2. Confirm it redirects to `wp-admin/admin.php?page=vms-agreements`.

## Event Plan Sidebar Generate Packet

1. Open an Event Plan with a primary vendor assigned.
2. In the Agreement Packet sidebar box, click `Generate Packet` or `Generate New Packet`.
3. Confirm it does not send you to the WordPress Pages list.
4. Confirm it redirects to the Agreements page with a generated packet selected.
5. Confirm the packet contains event, vendor, compensation, deposit, template, and hash details.

## Agreements Page Generate Form

1. Open VMS → Planning → Agreements.
2. Choose an Event Plan from the dropdown.
3. Click `Generate Agreement Packet`.
4. Confirm it generates a packet and redirects back to the Agreements page.

## Regression

1. Confirm old generated packets still appear in Recent Packets.
2. Confirm voiding a packet still works.
3. Confirm stale/current packet status still renders.
