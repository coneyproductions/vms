# VMS Agreements 0.3.15 Test Plan - Template Health Check Alignment

## Build Under Test

- VMS Core: `0.2.24.570+`
- VMS Agreements: `0.3.15-template-health-check-alignment`
- Plugin folder must remain: `vms-agreements`

## 🚨 Codex Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small, Codex must update all relevant version markers and packaging docs in the same pass before returning a repaired zip.

At minimum, update:

1. Plugin header version.
2. Version constants.
3. Build file.
4. Changelog/build notes.
5. Test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale version numbers or stale build notes.

## 1. Install / Build Metadata

1. Install/replace VMS Core `0.2.24.570+`.
2. Install/replace VMS Agreements `0.3.15`.
3. Confirm the installed folder is exactly `vms-agreements`.
4. Confirm the plugin header reports `0.3.15`.
5. Confirm `VMSA_VERSION` reports `0.3.15`.
6. Confirm `vms-agreements-build.txt` contains:

```text
0.3.15
template-health-check-alignment
```

## 2. PHP Lint

Run PHP lint against all plugin PHP files:

```bash
find wp-content/plugins/vms-agreements -name '*.php' -print0 | xargs -0 -n1 php -l
```

Expected: no syntax errors.

## 3. Stock Template Health Check

On a site already migrated to the 0.3.14 polished stock template:

1. Open **VMS > Agreements** as an admin.
2. Open the default agreement template health status.
3. Confirm the stock Audit Disclosure no longer produces:
   - `Audit disclosure may be missing this concept: hash`
4. Confirm the default template health check passes, or at minimum has no audit-disclosure warning related to `hash`.

Expected: the polished default phrase `packet verification records` satisfies the packet-verification/audit-record concept.

## 4. Health Check Alternative Wording Regression

If practical, test a temporary custom template edit for the Audit Disclosure.

Confirm the health check accepts at least one of these styles:

- Explicit technical wording: `terms hash` / `compensation hash`
- Friendly wording: `packet verification records`
- Friendly wording: `verification records`
- Friendly wording: `packet ID`

Expected: operators are not forced to expose raw hash wording in vendor-facing agreement language.

## 5. Health Check Warning Still Works

If practical, temporarily remove all packet-verification/audit-record language from a copy of the Audit Disclosure while leaving other fields intact.

Expected:

- The health check still warns that the audit disclosure may be missing the packet verification record concept.
- The warning is about `packet verification record`, not the literal raw concept `hash`.

## 6. Existing Workflow Spot Checks

Confirm unchanged behavior for:

1. Operator Agreement Queue rendering.
2. Fresh packet generation from a valid upcoming Event Plan.
3. Review-link email send and 0.3.12 delivery guardrails.
4. Public review open path `generated/sent -> viewed`.
5. Public acknowledgement submit path `viewed -> acknowledged`.
6. Acknowledgement proof display.
7. Print / Save PDF standalone shell.
8. Vendor portal Agreements tab and collapsed Agreement History.
9. Historical superseded/voided tokenized links returning unavailable/403.

## 7. Report Back

Report:

- Whether the stock default template health check is clean.
- Whether friendly packet-verification wording satisfies the health check.
- Whether removing verification language still creates an appropriate warning.
- Whether any workflow regressions appeared.
- Any code changes made, including required version/build/doc updates if repairs were needed.
