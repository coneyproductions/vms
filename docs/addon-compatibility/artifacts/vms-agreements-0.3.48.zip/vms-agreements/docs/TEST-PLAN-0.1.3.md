# VMS Agreements 0.1.3 Test Plan — Snapshot Accuracy + Cleanup

## Purpose

This pass protects packet accuracy before vendor-facing acknowledgement is added.

## Prerequisites

- VMS Core `0.2.24.567` or newer is active.
- VMS Agreements `0.1.3` is installed in the existing `vms-agreements` folder.
- At least one Event Plan has a primary vendor.

## Checks

1. Open **VMS → Planning → Agreements**.
2. Generate a packet for an Event Plan with known show time, such as `7:00 PM – 9:00 PM`.
3. Confirm the packet Event card shows the same local show time as the Event Plan editor.
   - This specifically verifies that time-only values are not shifted by server/WP timezone conversion.
4. Confirm the Event card shows a readable VMS status, such as Draft, Ready, Published, or Cancelled.
5. Confirm an Event Plan with no deposit terms shows:
   - `Deposit / advance: No deposit required.`
6. Add or edit deposit terms on a test Event Plan, then generate a fresh packet.
   - Confirm amount, status, treatment, due date, paid date, and notes render cleanly when present.
7. Confirm existing older packets that no longer match the current snapshot are marked stale, then generate a new packet to make it current.
8. Confirm **Generate New Packet from Current Event Plan** still supersedes the prior current packet.
9. Confirm **Void Packet** still marks the packet voided.
10. Confirm the guided tour still appears for `admin:vms-agreements`.

## Expected Result

Agreement packets show local Event Plan times correctly, event status is no longer blank, deposit text is readable, and stale detection still protects changed terms.

## Notes

Older packets generated before this build may show stale because the event status snapshot was corrected. That is expected; regenerate the packet before sending it to a vendor.
