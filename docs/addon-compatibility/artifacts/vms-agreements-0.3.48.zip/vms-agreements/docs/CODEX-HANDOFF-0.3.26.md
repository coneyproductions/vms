# Codex Handoff — VMS Agreements 0.3.26

## Package

`vms-agreements-0.3.26-cache-timezone-stale-and-mojibake-hardening.zip`

## Goal

Fix the remaining production issues reported after 0.3.25: vendor portal stale warning immediately after regeneration, generated times showing wrong timezone, and lingering truncated mojibake in admin packet title/preview.

## Key changes

- Version bumped to 0.3.26 in:
  - `vms-agreements.php` plugin header
  - `VMSA_VERSION`
  - `vms-agreements-build.txt`
- `includes/helpers.php`:
  - `vmsa_repair_mojibake_text()` now catches additional double-encoded and truncated `â€` / `Ã¢â‚¬` fragments.
  - `vmsa_format_audit_datetime()` now parses site-local MySQL timestamps using `wp_timezone()` instead of `strtotime()` first, preventing a timezone double-shift.
- `includes/snapshots.php`:
  - `vmsa_canonicalize_terms_hash_value()` now strips volatile keys from canonical hash payloads.
  - `vmsa_snapshot_terms_hash_payload()` now builds a narrower contract-significant fingerprint to avoid false stale states from derived/admin-context values.

## Test focus

1. Activation safety.
2. Regenerate packet and confirm admin header says Current.
3. Vendor portal card should not show stale immediately after regeneration.
4. Generated time should match WordPress/local site timezone.
5. Mojibake should be gone from admin packet title and Agreement Text Preview.
6. Manual-send and signed-notification behavior from 0.3.24 remains intact.

## Repair allowance

During testing/troubleshooting, Codex may make small, directly related repairs when feasible. If any code is changed, update version/build markers, changelog/build notes, and test docs consistently before packaging.
