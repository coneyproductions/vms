# VMS Agreements 0.1.4 Test Plan

## Purpose

Confirm the Agreements add-on adopts the VMS admin shell and fixes minor layout spacing without changing packet storage or generation behavior.

## Browser checks

1. Install and replace the existing `vms-agreements` plugin with version `0.1.4`.
2. Open `VMS -> Planning -> Agreements` or direct URL `wp-admin/admin.php?page=vms-agreements`.
3. Confirm the page renders with the shared VMS admin shell/top navigation when VMS Core supports it.
4. Confirm the Agreements page is still associated with the Planning cluster.
5. Confirm the intro, Generate Packet, Default Template, packet viewer, and Recent Packets areas still render.
6. Confirm the Event Plan label in the Generate Packet card appears above the dropdown with clean spacing.
7. Generate a new packet from a valid Event Plan.
8. Confirm packet generation still redirects to the packet viewer.
9. Confirm Agreement Text Preview and Audit Trail have visible vertical spacing between them.
10. Confirm the packet viewer still shows Event, Vendor/Venue, Template, Compensation Snapshot, Acknowledgements, Agreement Text Preview, Audit Trail, and Recent Packets.

## Regression checks

- The Generate Agreement Packet button is clickable when VMS Core 0.2.24.567+ is active.
- Existing packets remain visible in Recent Packets.
- Generating a new packet still supersedes the previous current packet for the same Event Plan/vendor.
- Stale/current terms pills still work.
- Event Plan sidebar packet generation still routes to the generated packet view.

## Notes

This is a visual/admin-shell polish pass only. It should not modify packet data, agreement text, hashes, or acknowledgement records.
