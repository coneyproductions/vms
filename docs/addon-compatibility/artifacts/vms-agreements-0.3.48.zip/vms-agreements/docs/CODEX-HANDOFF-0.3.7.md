# CODEX HANDOFF - VMS Agreements 0.3.7 Printable Copy Legibility Cleanup

## Package
`vms-agreements-0.3.7-printable-copy-legibility-cleanup.zip`

## Intent
This is a print/readability-only pass. It improves the saved PDF/print agreement copy so the Agreement Terms section is compact but readable.

## What changed
- Agreement Terms in the print view now render as structured clause blocks instead of one continuous nl2br text block.
- Print CSS now lays short clause blocks into two columns in print mode to preserve one-page output where practical.
- Clause headings are visually separated from their matching clause text.

## What should not change
- Packet snapshot schema.
- Review token validation.
- Email delivery.
- Acknowledgement record structure.
- Template editor behavior.
- Regeneration, stale, void, or supersede guardrails.

## Test plan
Run `docs/TEST-PLAN-0.3.7.md`.

## Failure / Version Protocol
If code is edited, update all version/build markers and docs in the same pass:
- plugin header version
- `VMSA_VERSION`
- `vms-agreements-build.txt`
- changelog
- README/HANDOFF as applicable
- relevant test plan docs
- package filename

Return a complete replacement zip only.
