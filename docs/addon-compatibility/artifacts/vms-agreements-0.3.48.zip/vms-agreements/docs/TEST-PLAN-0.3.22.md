# VMS Agreements 0.3.22 Test Plan — Compact Print Summary Layout

## Scope

This patch keeps the 0.3.18 activation hotfix and the bonus payout table work from 0.3.20/0.3.21, then tightens the standalone Print / Save as PDF agreement copy so the agreement is more likely to fit on one printed page.

## What changed

- Restores a side-by-side compact grid for the Event, Vendor, and Payment summary cards in the print/PDF shell.
- Reduces print/PDF spacing inside the top summary cards.
- Reduces the Bonus payout schedule table font size, padding, and spacing in print mode.
- Keeps the mobile/narrow-screen fallback as a single-column stack.

## Manual test steps

1. Install and activate `vms-agreements-0.3.22-print-compact-summary-and-bonus-table.zip`.
2. Confirm activation does not fatal-error.
3. Open an agreement packet for an Event Plan that uses base pay plus a per-paid-ticket bonus.
4. Open **Print / Save PDF**.
5. Confirm the Event, Vendor, and Payment cards display side by side on normal desktop width.
6. Confirm the Bonus payout schedule appears under Booking & Payment Summary.
7. Confirm the table heading says **Paid ticket sales** when that is the configured count source.
8. Open browser print preview and confirm:
   - Print actions are hidden.
   - Top summary cards remain side by side.
   - Bonus payout table is visibly smaller and more compact.
   - Agreement still remains readable.
   - The sample packet is closer to one printed page than 0.3.21.
9. Resize the browser below mobile width and confirm the summary cards stack into one column.

## Codex note

Codex may make small, directly related code repairs if testing reveals a regression, and must update the VMS Agreements version/build markers consistently if code changes are made.
