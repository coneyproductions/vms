# VMS Agreements 0.3.32 Test Plan — Vendor Status Surface Clarity

## Scope

This patch improves operator/vendor status clarity without changing packet generation, token validation, email delivery, acknowledgement storage, or cleanup rules.

## What changed

- Adds an **Agreements** metabox on `vms_vendor` admin screens.
- Vendor admin now shows current needs-review/viewed/signed counts plus signed-history count.
- Event Plan metabox no longer labels a historical packet as the “Current Packet” when no active packet exists.
- Event Plan metabox now explains when the latest packet is historical-only and whether it still matches current Event Plan terms.

## Manual test steps

1. Install and activate `vms-agreements-0.3.32-vendor-status-surface-clarity.zip`.
2. Confirm version markers:
   - plugin header `0.3.32`
   - `VMSA_VERSION` `0.3.32`
   - `vms-agreements-build.txt` slug `vendor-status-surface-clarity`
3. Open a vendor with one current unsigned packet and at least one signed historical packet.
4. Confirm the new vendor-side **Agreements** metabox appears.
5. Confirm the metabox shows counts for:
   - `Needs review`
   - `Viewed`
   - `Current signed`
   - `Signed history`
6. Confirm the metabox links to the current packet when one exists.
7. Acknowledge or supersede packets so the vendor has history but no active packet.
8. Confirm the vendor metabox now shows the latest historical packet and clearly says no current packet is active.
9. Open the Event Plan metabox for the same booking while a current packet exists.
10. Confirm the button says **View Current Packet**.
11. Remove the active packet so only historical packets remain.
12. Confirm the Event Plan metabox button changes to **View Latest Packet** instead of **View Current Packet**.
13. Confirm the Event Plan metabox explains that the shown packet is historical-only.
14. Confirm the historical-only note changes depending on whether the packet still matches current Event Plan terms or is stale.

## Regression checks

- Confirm packet generation/resupersede still works from the Event Plan metabox.
- Confirm vendor portal agreement cards/counts still render.
- Confirm cleanup tools still skip acknowledged packets by default.
- Confirm public review, print/PDF, email send/resend, and acknowledgement flows remain unchanged.
