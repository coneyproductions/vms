# VMS Agreements 0.3.48 - Vendor Portal Routing Registration

This release registers the native `agreements` slug through Backstage Venue Manager's public vendor-portal allowlist. It fixes the partial-integration state where the Agreements link and pending badge rendered, but direct or clicked navigation was normalized back to Dashboard before Agreements could receive active styling or render its content callback.

The repair is routing-only. It preserves BVM-authorized vendor context, packet ownership queries, review/print links, acknowledgement and signature behavior, empty states, and every existing core or companion portal tab.

# VMS Agreements 0.3.29 - Raw Title Current-State and Vendor Portal Selection Fix

This pass corrects two concrete root causes behind the packet-current/public-stale confusion. First, Agreements now reads raw post titles instead of filtered `get_the_title()` output when it builds packet titles, snapshots, and current-state hashes, so admin/public requests cannot disagree just because one request decoded Event Plan title entities differently. Second, the vendor portal now treats the latest current packet per Event Plan as the primary card and demotes stale/outdated packets into history instead of keeping an older stale packet actionable.

Key points for 0.3.29:

- Uses raw `post_title` plus entity/mojibake cleanup before packet title, snapshot, and hash storage.
- Keeps newly generated packets from carrying forward broken punctuation into admin/vendor review/print surfaces.
- Makes vendor portal counts and the Action Needed CTA follow the same latest current packet source of truth.
- Adds `docs/TEST-PLAN-0.3.29.md` and `docs/CODEX-HANDOFF-0.3.29.md`.

# VMS Agreements 0.3.21 - Print Bonus Payout Table

This polish pass keeps the 0.3.18 activation hotfix and 0.3.20 bonus payout table behavior, then adds the same payout table to the standalone Print / Save as PDF agreement copy.

Key points for 0.3.21:

- Keeps activation light from 0.3.18.
- Adds the bonus payout schedule table to the printable agreement copy so the print/PDF view does not reference a missing table.
- Uses paid ticket sales as the default bonus count basis.
- Replaces the wordy step-bonus explanation in packet rendering with a payout schedule table using the same structure as the Event Plan preview.
- Adds `docs/TEST-PLAN-0.3.21.md` and `docs/CODEX-HANDOFF-0.3.21.md`.

# VMS Agreements 0.3.18 - Activation + Bonus Clarity

This hotfix keeps plugin activation light and clarifies Base + attendance/ticket-sales bonus wording in generated agreement packets.

Key points for 0.3.18:

- Defers default template creation/checking out of the activation hook and into the existing admin-init manager path.
- Uses paid ticket sales as the default count basis for bonus wording.
- Clarifies that a 100 threshold plus 50-ticket step means the first bonus is at 150 paid ticket sales.
- Adds `docs/TEST-PLAN-0.3.18.md` and `docs/CODEX-HANDOFF-0.3.18.md`.

# VMS Agreements 0.3.17 - Boot / I18n Log Cleanup

This build is a targeted debug-log cleanup pass. It does not change packet behavior; it adds explicit textdomain boot and hardens early nav/tour label generation so normal requests stop generating repeated `vms-agreements` early translation notices.

Key points for 0.3.17:

- Requires VMS Core `0.2.24.612+` for the matched debug-log cleanup pass.
- Keeps packet schema, queue behavior, vendor portal behavior, review links, acknowledgement flow, and print rendering unchanged.
- Adds `docs/TEST-PLAN-0.3.17.md` and `docs/CODEX-HANDOFF-0.3.17.md`.

# VMS Agreements 0.3.16 - Template Editor Hardening

This build adds admin-side guardrails to the agreement Template Block Editor. The health panel now makes blocking errors and warnings more obvious, required editable blocks show whether their wording is stock/customized/broken, and admins can use **Repair Required Components** to restore required/protected blocks and acknowledgement rows without raw metadata work.

Key points:

- Requires VMS Core `0.2.24.570+`.
- Keeps packet schema, review tokens, acknowledgement flow, email diagnostics, operator queue, vendor portal, default language, and print rendering unchanged.
- Adds `docs/TEST-PLAN-0.3.16.md` and `docs/CODEX-HANDOFF-0.3.16.md`.

# VMS Agreements

- 0.3.21 adds the bonus payout schedule table to the standalone Print / Save as PDF agreement copy so the printable agreement does not reference a missing table.
VMS Agreements is a premium add-on plugin for Venue Management System (VMS). It is intentionally separate from VMS Core.

## Purpose

This add-on creates agreement packets from VMS Event Plans. A packet captures a point-in-time snapshot of:

- Event Plan title, date, time, venue, and status
- Primary vendor name and contact details
- Event Plan compensation structure
- Event Plan deposit / advance terms
- Template name and template version
- Compensation hash and full terms hash
- Vendor acknowledgement records

## Dependency

Requires VMS Core `0.2.24.570` or newer.

The deposit fields intentionally live in VMS Core because deposits are part of the actual booking compensation terms. This add-on reads those terms and preserves them in agreement packets.

## Current Scope - 0.3.20

0.3.15 keeps the validated 0.3.13 operator queue and the 0.3.14 language polish, then aligns the Template Health Check with the friendlier default audit-disclosure wording. The default template should not warn solely because it says packet verification records instead of the literal word hash. This pass does not change packet schema, review-token behavior, acknowledgement submission, email delivery guardrails, operator queue behavior, vendor portal behavior, or print rendering.

Included:

- Separate installable add-on plugin
- Private Agreement Template storage
- Private Agreement Packet storage
- Default template creation
- Polished stock default agreement clauses for cancellation/event viability, payment timing, rider handling, no-show/nonperformance, venue rules, and audit disclosure
- Safe language-default migration that updates unchanged stock 0.3.13 templates while preserving operator-customized text
- Agreement submenu under VMS Planning
- Packet generation from Event Plans
- Guardrails to avoid accidental duplicate current packets
- Guardrails preventing new packet generation for cancelled or past Event Plans
- Generate Packet dropdown limited to upcoming, non-cancelled Event Plans with a primary vendor
- Regenerate / Supersede workflow
- Snapshot capture of compensation and deposit terms
- Terms-current / stale detection
- Event Plan side metabox showing latest packet state
- Admin packet viewer
- Operator Agreement Queue grouping Stale, Generated, Sent, Viewed, Acknowledged, and Superseded/Voided History packets
- Queue actions for Open Packet, Event Plan, Email/Resend Review, and Print/PDF where safe
- Clean packet display titles that avoid repeated event/vendor names
- ASCII-safe UI punctuation to avoid odd character rendering
- Secure tokenized Vendor Review Link
- Public vendor-facing agreement review page
- Required acknowledgement checkboxes placed inline with the public review content they confirm
- Signer name/email capture
- Vendor acknowledgement audit record capture
- Printed acknowledgement proof for the vendor and admin
- Review link view tracking
- Review link regeneration
- Public acknowledgement UX that keeps content review confirmations near the relevant Booking Summary/submit sections
- Email Review Link action from the admin packet viewer
- Review email send/resend tracking
- Review email audit trail records
- Review-link email send diagnostics for wp_mail failures, wp_mail success hooks, and pre_wp_mail short-circuits
- Admin packet viewer warning when the last review-link email send failed or was intercepted
- New Sent packet status after a review email is successfully sent before the vendor views the link
- Structured Template Block Editor
- Protected required blocks for event, vendor, compensation, deposit, audit, and acknowledgement proof
- Editable clause blocks for cancellation/viability, payment timing, rider handling, no-show/nonperformance, venue rules, and additional terms
- Template Health Check that flags missing required blocks, empty critical clauses, missing required acknowledgements, and weakened audit disclosure concepts
- Packet generation is blocked when the active template health check has errors
- Template version bump on save so future packets point to the updated wording while existing packets retain their original snapshot
- Editable review-link and acknowledgement-confirmation email templates
- Email Template Health Check requiring the review email to include the secure review link token
- Optional one-time operator note before sending or resending the vendor review email
- Automatic acknowledgement confirmation email to the signer after submission
- Mobile-readable stock email defaults with clearer compensation, deposit, and payment-summary sections
- `{payment_summary_email}` token for line-broken payment-summary email output
- Safe upgrade migration for unchanged 0.3.2 and 0.3.13 stock email templates
- Public printable agreement copy view from the vendor review page
- Admin packet viewer Print / Save PDF action
- Print-friendly styling for browser print / save-as-PDF workflows
- Vendor portal pending agreements renderer
- Native vendor portal Agreements tab and dashboard-card integration via VMS Core portal hooks
- `[vmsa_vendor_agreements]` shortcode retained as fallback/manual placement
- Vendor-facing agreement status cards for Needs Review, Viewed, Acknowledged, Superseded, and Voided packets
- Review Agreement and Print / Save PDF buttons that reuse the existing secure tokenized public links

Not included yet:

- Server-side PDF generation library
- Automated review reminders
- Clause bypass UI
- Rider upload workflow
- True signature/drawing field

## Canonical Source of Truth

For compensation and deposit terms, the Event Plan remains the source of truth. Agreement packets are snapshots of that source of truth at the time the packet was generated.

## Agreement Acknowledgement Rule

If a packet is regenerated, the old packet is preserved as superseded history. Any acknowledgement attached to that old packet remains historical proof only. The new current packet must be acknowledged again.

## Public Review Link

Each active packet has a secure Vendor Review Link. Opening that link changes the packet from `Generated` or `Sent` to `Viewed` and records view timestamps. When the vendor submits the acknowledgement form, the packet becomes `Acknowledged` and the proof details are printed back to the vendor and shown in the admin packet viewer.

Regenerating the Vendor Review Link invalidates the previous copied link for that same packet.

## Closed Event Guardrail

Cancelled and past Event Plans cannot generate new agreement packets. Existing packets remain viewable for history and can still be voided when appropriate.

## Template Block Editor

The agreement template is intentionally structured instead of being one large freeform document. Operators can edit clause wording and optional sections, but protected data blocks keep event, vendor, compensation, deposit, acknowledgement, and audit proof elements anchored to the generated packet snapshot. Saving the template increments the template version used by future packets.


## 0.3.15 Template Health Check Alignment

0.3.15 fixes the follow-up warning found during 0.3.14 Codex testing: the stock migrated template could still warn that the Audit Disclosure was missing the concept `hash`, even though the polished default wording intentionally uses friendlier packet-verification language. The health check now accepts either explicit hash wording or practical alternatives such as packet verification records, verification records, packet ID, or recorded packet.

## 0.3.14 Agreement Language Polish

0.3.14 improves the stock agreement clauses, acknowledgement labels, and email copy so new/default packets read more like practical vendor booking agreements. It includes a safe migration for unchanged stock 0.3.13 language only; customized text is preserved.

## 0.3.1 Payment Summary Clarification

Agreement packets now include a generated Payment summary that distinguishes total agreed payment or known base/guarantee, deposit/advance amount and status, and the remaining final payment balance when calculable.

## 0.3.2 Email Template Foundation

Agreement email copy is now operator-editable. The Review Link Email must retain `{review_link}` so the vendor can open the secure agreement packet. The Acknowledgement Confirmation Email is sent automatically to the signer after acknowledgement and can include `{acknowledgement_proof}` to print the recorded proof details back to the signer.


## 0.3.4 notes

Requires VMS Core 0.2.24.568+. Adds vendor-facing payment summary cleanup using core final payment timing and method fields, including ACH / Direct Deposit.


## 0.3.5 Printable Copy Notes

Agreement packets now have a Print / Save as PDF workflow that uses the secure packet review token. This first pass relies on the browser print dialog instead of a server-side PDF library, keeping the feature lightweight and easy to test. Acknowledged packets include acknowledgement proof in the printable copy.

## 0.3.6 Printable Copy Cleanup Notes

This version keeps the browser print / save-as-PDF approach but makes the printable copy more compact. The standalone print route uses a dedicated compact renderer, removes internal status badges, includes the event title in the summary, deduplicates the booking/payment blocks from the agreement text, and omits `wp_footer()` to prevent theme footer content or galleries from appearing in saved PDFs.

## 0.3.7 Printable Copy Legibility Notes

Printable agreement terms now render as structured clause blocks, not one continuous line-broken paragraph. Print CSS keeps headings and clause text visually grouped and uses a compact two-column print layout for short clause blocks when practical. This pass does not change packet storage, review tokens, acknowledgement records, email delivery, template editing, or regeneration guardrails.


## 0.3.8 Printable Copy Readable Width Notes

0.3.8 intentionally favors readability over forcing every agreement onto one page. The printable booking/payment summary now stacks the Event, Vendor, and Payment sections full-width, and Agreement Terms render as full-width clause blocks. The copy may overflow to a second page for longer agreements, which is acceptable when it improves readability. No agreement data model, acknowledgement, token, email, or generation guardrail behavior changed.

## 0.3.9 Vendor Portal Pending Agreements Notes

0.3.9 adds a vendor-facing agreements area for logged-in vendors. It can be rendered with `[vmsa_vendor_agreements]` or by VMS Core portal hooks if available. The portal list is additive and reuses the existing secure tokenized review/print links, so the email review-link workflow remains intact.

Active packets show Review Agreement and Print / Save PDF actions. Superseded and voided packets are shown as historical records only because inactive packets are intentionally rejected by the public review route.

## 0.3.10 Vendor Portal Core Hook Integration Notes

0.3.10 moves Pending Agreements from shortcode-only fallback toward native portal behavior. With VMS Core `0.2.24.569+`, the Agreements list can render automatically after the vendor dashboard cards through `vms_vendor_portal_dashboard_after_cards`. It also registers an **Agreements** tab through the native vendor portal nav/custom-tab extension points.

The shortcode `[vmsa_vendor_agreements]` remains available, but normal installation should not depend on manually placing it. Existing tokenized email review links, secure print links, acknowledgement flow, packet schema, and regeneration/void guardrails are unchanged.

## 0.3.11 Vendor Portal History Cleanup Notes

0.3.11 keeps the native portal behavior from 0.3.10, but moves superseded and voided packets into a collapsed Agreement History section so vendors see the current agreement first. Historical packets remain visible for recordkeeping but render as compact cards.

This version also cleans up flat-fee wording for new packets and display-cleans older stored packet summaries where possible.

## 0.3.13 Operator Agreement Queue Notes

0.3.13 adds an operator-facing queue above Recent Packets on the Agreements admin page. It groups active follow-ups by state, keeps acknowledged/history sections collapsed by default, and reuses the existing 0.3.12 email handler so queue email/resend actions keep the same diagnostics and failure guardrails. Packet storage, public review links, print links, acknowledgement handling, and vendor portal behavior are intentionally unchanged.

## 0.3.12 Review Email Delivery Verification Notes

0.3.12 is a narrow repair/diagnostic pass after Codex testing found that admin-side Email Review Link sends could update packet audit/meta while Mailpit did not receive a new review-link email. Review-link sends now capture WordPress mail diagnostics and do not advance packet sent metadata/status when delivery is intercepted by `pre_wp_mail` or fails through `wp_mail_failed`/`wp_mail`.

Acknowledgement confirmation emails, packet review URLs, vendor portal rendering, print rendering, acknowledgement submission, and packet schema are intentionally unchanged.
