# VMS Agreements 0.3.16 Test Plan - Template Editor Hardening

## Build Under Test

- VMS Core: `0.2.24.570+`
- VMS Agreements: `0.3.16-template-editor-hardening`
- Plugin folder must remain: `vms-agreements`

## 🚨 Codex Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small, Codex must update all relevant version markers and packaging docs in the same pass before returning a repaired zip.

At minimum, update:

1. Plugin header version.
2. Version constants.
3. Build file.
4. Changelog/build notes.
5. Test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale version numbers or stale build notes.

## 1. Install / Build Metadata

1. Install/replace VMS Core `0.2.24.570+`.
2. Install/replace VMS Agreements `0.3.16`.
3. Confirm the installed folder is exactly `vms-agreements`.
4. Confirm the plugin header reports `0.3.16`.
5. Confirm `VMSA_VERSION` reports `0.3.16`.
6. Confirm `vms-agreements-build.txt` contains:

```text
0.3.16
template-editor-hardening
```

## 2. PHP Lint

Run PHP lint against all plugin PHP files:

```bash
find wp-content/plugins/vms-agreements -name '*.php' -print0 | xargs -0 -n1 php -l
```

Expected: no syntax errors.

## 3. Clean Template Editor Baseline

1. Open **VMS > Agreements** as an admin.
2. Open the default agreement template editor.
3. Confirm the Template Health Check panel shows status, error count, and warning count.
4. Confirm a healthy stock template shows no blocking errors.
5. Confirm the **Repair Required Components** button is visible and does not create a fatal error when used on a healthy template.
6. Confirm the template patch version only bumps if the repair action actually changes stored required components.

Expected: healthy template remains usable and the UI clearly distinguishes passed/warning/error states.

## 4. Broken Required Clause Save Warning

Temporarily edit a required editable clause, such as **Payment Timing**, and remove its body text.

Expected:

1. Save completes without a fatal error.
2. Redirect notice is a warning, not a plain success.
3. Health panel shows a blocking error for the empty required clause.
4. The affected block shows **Needs wording** and an inline warning.
5. Attempting to generate a fresh packet from this template is blocked by the existing `template_unhealthy` guardrail.

Restore the clause before continuing, or use the repair action in the next section.

## 5. Repair Required Components

With a required clause empty or required acknowledgements missing:

1. Click **Repair Required Components**.
2. Confirm the required empty clause is restored to safe default wording.
3. Confirm required acknowledgement rows are present again.
4. Confirm the Template Health Check refreshes.
5. Confirm the template patch version bumps when repair changed stored data.
6. Confirm a fresh packet can be generated after repair.

Expected: repair fixes required/protected components without changing packet schema or old packet snapshots.

## 6. Customized vs Stock Wording Badges

1. Customize one required editable clause with non-stock wording.
2. Save the template.
3. Confirm that block shows a **Customized wording** badge.
4. Confirm unchanged editable blocks show **Stock wording**.
5. Confirm optional disabled blocks still show as optional/disabled rather than broken.

Expected: operators can see which clauses are customized versus stock without reading every block line by line.

## 7. Existing Workflow Regression Checks

Confirm unchanged behavior for:

1. Operator Agreement Queue rendering and bucket counts.
2. Fresh packet generation from a valid upcoming Event Plan using a healthy template.
3. Review-link email send and 0.3.12 delivery guardrails.
4. Public review open path `generated/sent -> viewed`.
5. Public acknowledgement submit path `viewed -> acknowledged`.
6. Acknowledgement proof display.
7. Print / Save PDF standalone shell.
8. Vendor portal Agreements tab and collapsed Agreement History.
9. Historical superseded/voided tokenized links returning unavailable/403.

## 8. Report Back

Report:

- Whether the template editor showed the new health panel, counts, badges, and repair action.
- Whether an empty required clause saved with a warning and blocked generation.
- Whether repair restored required components and refreshed health.
- Whether customized/stock/needs-wording badges were accurate.
- Whether any workflow regressions appeared.
- Any code changes made, including required version/build/doc updates if repairs were needed.
