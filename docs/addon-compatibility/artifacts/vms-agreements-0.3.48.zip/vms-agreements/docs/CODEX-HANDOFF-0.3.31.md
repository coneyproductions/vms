# Codex Handoff — VMS Agreements 0.3.31

## Package

`vms-agreements-0.3.31-admin-test-packet-cleanup-tools.zip`

## Goal

Add admin-only cleanup tools so test/regeneration packet clutter can be removed safely without deleting acknowledged agreement history.

## Key changes

- Version bumped to `0.3.31` in:
  - `vms-agreements.php` plugin header
  - `VMSA_VERSION`
  - `vms-agreements-build.txt`
- `includes/admin.php`:
  - registers a new `admin_post` cleanup handler
  - adds a **Testing / Cleanup** section on packet detail screens
  - adds an unacknowledged-packet hard-delete action for the same Event Plan
  - adds a stale/history hard-delete action for the same Event Plan
  - refreshes `_vmsa_latest_packet_id` after cleanup and keeps redirects on a surviving packet when possible
- `includes/helpers.php`:
  - adds cleanup result notices with deleted/skipped counts
  - adds a cleanup-confirmation-required notice
- Cleanup logic protects acknowledged packets by checking acknowledgement history, not just current status. That means superseded or voided packets with stored acknowledgement records are skipped instead of deleted.
- Cleanup invalidation uses post-cache cleanup plus a `vmsa_after_packet_cleanup` hook for any site-specific cache/transient layers outside the plugin. VMS Agreements itself does not currently store vendor-portal packet lists in transients.

## Safety / non-goals

- The 0.3.29 raw-title/current/stale/hash fix was not changed.
- The 0.3.30 Agreement Packet language consistency work was not changed.
- Default cleanup actions do not delete acknowledged packets.
- `wp_delete_post($packet_id, true)` is used intentionally for hard deletes of eligible test packets only.

## Test focus

1. Create packet clutter for one Event Plan and confirm the new cleanup section appears on the packet detail screen.
2. Confirm unacknowledged generated/sent/viewed/superseded/voided packets are deleted by the broad cleanup action.
3. Confirm stale/history cleanup deletes only superseded, voided, or stale packets and leaves the current generated/sent/viewed packet intact.
4. Confirm acknowledged packets are skipped even if they are historical.
5. Confirm vendor portal history/counts refresh after cleanup.
6. Generate one fresh packet after cleanup and confirm normal current/stale behavior still works.
