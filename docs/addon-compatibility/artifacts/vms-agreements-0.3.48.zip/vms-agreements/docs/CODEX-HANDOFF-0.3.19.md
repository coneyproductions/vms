# VMS Agreements 0.3.19 Codex Handoff - Bonus Wording Polish

## Goal

Verify that agreement packet compensation summaries use concise bonus wording that matches the Event Plan pay-preview style more closely, while still making paid ticket sales the default count basis.

## What Changed

- `includes/snapshots.php` now formats step bonuses as:

  `Bonus: No bonus is earned through 100 paid ticket sales. Add $250.00 every 50 paid ticket sales after that.`

- The prior 0.3.18 activation hotfix is preserved.
- No packet schema, acknowledgement, review-token, email, queue, or vendor-portal behavior is intentionally changed.

## Test Focus

Use `docs/TEST-PLAN-0.3.19.md`. The key scenario is an Event Plan with:

- Base fee: $1,500.00
- Bonus threshold/start count: 100
- Step size: 50
- Step bonus: $250.00

The generated packet should not imply a bonus at 100. It should say paid ticket sales by default, not generic attendees/headcount.

## Repair Protocol

Codex may make small, directly-related code repairs when feasible during testing/troubleshooting. If code changes are made, update the VMS Agreements version/build number consistently across the plugin header, `VMSA_VERSION`, `vms-agreements-build.txt`, changelog/test docs, and package filename.
