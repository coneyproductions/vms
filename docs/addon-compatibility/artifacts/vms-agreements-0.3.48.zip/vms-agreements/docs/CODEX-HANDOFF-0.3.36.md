# Codex Handoff - VMS Agreements 0.3.36

## Package

`vms-agreements-0.3.36-print-summary-layout-repair.zip`

## Goal

Repair the printable Agreement Packet Summary after the 0.3.34 contract hardening added legal contracting identity and final-payment detail to a print layout that 0.3.22 had optimized around three side-by-side summary cards. The Reputation acceptance PDF exposed real label/value collisions and excessive unused page space.

## Changes

- Public review and print summary use a two-plus-one layout: Event Details + Vendor Details side-by-side, Compensation Terms full-width underneath.
- Bonus payout renderer wraps the table and qualifying-ticket explanation in a responsive two-column layout.
- Print CSS gives identity and compensation rows different label widths appropriate to their content.
- Agreement Terms panel is allowed to break between clauses while individual clauses retain break-inside protection.
- Print-only Acknowledgement Status copy now says the Vendor submits their acknowledgement.

## Non-goals / unchanged

- No agreement-clause changes.
- No compensation calculations or payout values change.
- No packet schema, snapshot, terms hash, compensation hash, acknowledgement, readiness, send/resend, supersede, or void logic changes.

## Acceptance fixture

Render the September 12, 2026 Reputation agreement. The first page should have no overlapping summary labels, the bonus note should sit beside the payout table, and Agreement Terms should begin in the remaining page-1 space rather than being pushed wholesale to page 2.
