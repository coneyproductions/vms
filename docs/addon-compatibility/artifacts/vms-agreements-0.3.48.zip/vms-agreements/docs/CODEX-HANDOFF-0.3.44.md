# VMS Agreements 0.3.44 Codex Handoff

## Goal
Reduce agreement duplication, make cancellation language easier for artists to understand, soften adversarial clause naming without weakening protections, explicitly name lightning/weather examples, and align printable signature execution lines.

## Changes
- HTML review now renders only formal clause blocks under **Agreement Terms**; Event/Vendor/Compensation/Deposit/Production details remain once in the Agreement Packet Summary.
- Agreement Packet Scope now incorporates the Summary by reference instead of restating all booking fields.
- Weather / Safety Cancellation is split into short readable paragraphs with a scan-friendly payment list and explicit examples including rain, lightning, severe thunderstorms, high winds, flooding, and extreme heat.
- Low Ticket Sales / Event Viability Cancellation uses a scan-friendly payment list.
- **Vendor Cancellation / Performance Issues** replaces threatening No-Show/Nonperformance stock heading while still addressing unapproved cancellation, failure to appear, material lateness, refusal, early departure, unsafe-work concerns, and direct/cover costs.
- Payment Timing is shortened to avoid repeating the structured Payment Terms.
- Physical signature identity blocks use equal reserved height so Vendor/Venue signature, printed-name, title/capacity, and date lines align.
- Exact-match migration updates untouched stock language/titles while preserving custom operator edits.

## Compatibility
- Existing acknowledged packet snapshots remain historical evidence and are not rewritten.
- New/regenerated packets receive the new substantive clause wording.
- HTML de-duplication and signature alignment are presentation changes; clause wording changes require regeneration when the new wording should govern a booking.
