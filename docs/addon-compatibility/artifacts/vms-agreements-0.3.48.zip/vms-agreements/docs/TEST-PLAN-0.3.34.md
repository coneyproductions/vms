# VMS Agreements 0.3.34 Test Plan

## Static / package

1. PHP lint all plugin PHP files.
2. Confirm version markers are 0.3.34.
3. Confirm no 0.3.33 runtime version markers remain.

## Agreement Defaults

1. Open Agreements.
2. Confirm Agreement Defaults card appears.
3. With legal contracting party blank, confirm new packet generation is unavailable/blocked.
4. Set legal contracting party to `Coney Productions LLC d/b/a Serenade Range`.
5. Set standard final-payment fallback to `5` calendar days and save.

## Reputation acceptance fixture

1. Open the September 12, 2026 Reputation Event Plan.
2. Confirm locked compensation remains base $1,500 with the existing payout table.
3. Generate/supersede a fresh Agreement Packet.
4. Confirm Event Details show venue `Serenade Range` and contracting party `Coney Productions LLC d/b/a Serenade Range`.
5. Confirm Payment summary shows 5 days after event when Event Plan timing is otherwise blank; explicit Event Plan timing must override fallback.
6. Confirm payout table is followed by the qualifying-paid-ticket explanation and non-cumulative/highest-threshold rule.
7. Confirm Agreement Terms include Performance / Live-Band Commitment, Weather / Safety Cancellation, Event Viability / Ticket-Demand Cancellation, Production / Technical / Hospitality Terms, Vendor Cancellation / No-Show / Nonperformance, Independent Contractor / Tax Documentation, Changes to Agreed Terms, and Governing Law / Dispute Resolution.
8. Confirm rain clause addresses the uncovered stage and unsafe electrical/stage conditions.
9. Confirm vendor review and Print / Save PDF surfaces show the same terms.
10. Acknowledge only after operator/business review of the fresh packet.

## Upgrade safety

1. On a copy of 0.3.33 data with untouched stock clauses, load wp-admin and confirm stock clauses upgrade to 0.3.34 wording.
2. On a copy with one deliberately customized editable clause, confirm that clause is preserved while missing new required blocks are added.
3. Confirm existing acknowledged/superseded packets retain their original stored snapshot and proof.
