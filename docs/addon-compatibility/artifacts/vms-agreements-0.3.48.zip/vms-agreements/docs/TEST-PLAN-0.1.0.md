# VMS Agreements 0.1.0 Test Plan

🚨 **Codex / browser testing recommended before using with real vendor agreements.**

## Install / Activation

1. Upload and activate `vms-agreements` alongside VMS Core `0.2.24.567` or newer.
2. Confirm there is a new **VMS → Agreements** submenu.
3. Confirm no fatal errors or PHP warnings appear.
4. Confirm `VMS Agreements is installed but inactive` notice appears if VMS Core is disabled on a test site.

## Default Template

1. Open **VMS → Agreements**.
2. Confirm the Default Template card shows:
   - Default Booking Agreement
   - Version `1.0.0`
   - 3 acknowledgements

## Generate Packet

1. Create or open an Event Plan with:
   - Event date
   - Start/end time
   - Venue
   - Primary vendor
   - Compensation terms
   - Deposit terms if desired
2. Open **VMS → Agreements**.
3. Choose that Event Plan and click **Generate Agreement Packet**.
4. Confirm the generated packet viewer opens.
5. Confirm packet snapshot shows event, vendor, venue, compensation, deposit, template version, comp hash, and terms hash.

## Event Plan Metabox

1. Open the same Event Plan editor.
2. Confirm the side metabox shows the latest Agreement Packet.
3. Confirm the packet status appears as Generated.
4. Confirm terms status appears as Current.

## Stale Detection

1. Change compensation or deposit terms on the Event Plan.
2. Return to the packet viewer.
3. Confirm the packet shows a warning that Event Plan terms changed.
4. Generate a new packet.
5. Confirm the previous packet is marked Superseded and the new packet is Current.

## Void Packet

1. Open a generated packet.
2. Click **Void Packet**.
3. Confirm status changes to Voided.
4. Confirm voiding does not delete the packet.

## Regression Checks

1. Confirm VMS Core Event Plan saving still works.
2. Confirm compensation/deposit fields still save in VMS Core.
3. Confirm no public-facing agreement pages are exposed yet.
4. Confirm no vendor-facing acknowledgement link is generated yet.
