# VMS Agreements 0.3.38 Test Plan

## Event Plan sidebar
1. Open an Event Plan with a primary vendor.
2. Confirm the Agreement Packet metabox does not contain editable identity or production controls.
3. Confirm it summarizes legal party, representative, and production readiness.
4. Confirm **Complete/Review Agreement Setup** opens the Agreements screen for this Event Plan.
5. Confirm **View Current Packet** is still available when a packet exists.

## Agreement Setup persistence
1. Open Agreement Setup for an upcoming Event Plan.
2. Enter/override legal contracting name and representative/contact.
3. Answer Yes/No for Stage, House Sound / PA, Stage Lighting, and Sound Engineer and confirm review.
4. Click **Save Agreement Setup** and confirm values persist after reload.
5. Change a value and click **Save & View Current Packet**; confirm the changed value is saved before the packet view opens.
6. Return to Agreement Setup and confirm the existing packet reports stale when saved material terms differ.

## Generation
1. From the main Agreements screen, confirm upcoming non-cancelled Event Plans with a primary vendor appear even when agreement setup is incomplete.
2. Open an incomplete plan and confirm the setup form is shown.
3. Complete required fields and use **Save & Generate Packet**.
4. Confirm a new packet snapshots identity and production terms.
5. With a current packet, change a term and use **Save & Regenerate / Supersede**; confirm old packet is preserved as history and the new packet becomes current.

## Regression
- Cancelled and past plans cannot generate new packets.
- Missing primary vendor still blocks setup/generation.
- Missing Venue legal contracting party still blocks generation and points to Agreement Defaults.
- Existing 0.3.37 Event Plan metadata loads into the new setup view without migration.
