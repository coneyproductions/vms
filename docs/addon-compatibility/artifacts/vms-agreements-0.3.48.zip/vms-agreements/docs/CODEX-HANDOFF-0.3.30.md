# Codex Handoff — VMS Agreements 0.3.30

## Package

`vms-agreements-0.3.30-agreement-language-consistency-audit.zip`

## Goal

Standardize vendor-facing agreement terminology so the generated Agreement Packet, acknowledgement UI, proof output, stale messaging, vendor portal, and default emails all describe the same concepts the same way.

## Key changes

- Version bumped to `0.3.30` in:
  - `vms-agreements.php` plugin header
  - `VMSA_VERSION`
  - `vms-agreements-build.txt`
- `includes/template-blocks.php`:
  - adds a required protected **Agreement Packet Scope** block
  - updates stock **Acknowledgement & Audit Record** and **Acknowledgement Proof** copy
  - upgrades unchanged stock template bodies/blocks/ack labels from older defaults to the new wording
- `includes/cpt.php`:
  - updates the stock fallback template body
  - replaces the stock acknowledgement checkbox labels with the new Agreement Packet terminology
- `includes/public.php`:
  - standardizes public review and print/PDF headings and submit copy
  - adds a vendor-facing stale-message helper so public users do not see internal **Event Plan** wording
  - updates acknowledgement-proof output to show packet ID plus Packet Verification Records
- `includes/vendor-portal.php`:
  - uses the same vendor-facing stale message helper as the public review page
  - aligns summary labels with **Compensation Terms** and **Deposit / Advance Terms**
  - preserves the 0.3.29 latest-current packet selection logic
- `includes/email-templates.php`:
  - rewrites stock review/acknowledgement/operator email defaults around **Agreement Packet** terminology
  - upgrades unchanged stock email bodies in place
  - expands acknowledgement proof email tokens to include packet ID and Packet Verification Records

## Safety / non-goals

- The 0.3.29 raw-title, decode, and mojibake cleanup path was not changed.
- The 0.3.29 current/stale/hash logic was not changed beyond vendor-facing message presentation.
- No automatic email sends were added.
- Existing customized template/email wording is preserved unless it exactly matched prior stock defaults.
- Existing generated packets remain historical snapshots.

## Test focus

1. Generate one new packet and confirm the agreement text starts with **Agreement Packet Scope**.
2. Confirm no formal acknowledgement text still says `booking details`.
3. Confirm public review, vendor portal, proof output, print/PDF, and default emails use **Agreement Packet** terminology consistently.
4. Confirm stale vendor/public messaging no longer mentions **Event Plan**.
5. Confirm admin diagnostics/internal messaging can still use **Event Plan** wording.
6. Confirm 0.3.29 current/stale parity and latest-current vendor-portal selection still behave correctly.
