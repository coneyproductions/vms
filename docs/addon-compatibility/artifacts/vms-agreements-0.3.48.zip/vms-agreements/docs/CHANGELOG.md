# VMS Agreements Changelog

## 0.3.48 - 2026-09-01

- Registers the native `agreements` vendor-portal slug through Backstage Venue Manager's public `vms_vendor_portal_allowed_tabs` filter.
- Fixes direct and clicked Agreements navigation falling back to Dashboard even though the Agreements link and pending-count badge were visible.
- Preserves all existing core and companion portal tabs while keeping the existing BVM-authorized vendor context, packet query, acknowledgement, signature, review-link, and empty-state behavior unchanged.
- Adds focused routing coverage for the full portal allowlist, active state, badge count, one/no-agreement rendering, acknowledged actions, and cross-vendor packet isolation.

## 0.3.47 - 2026-08-31

- Restores Agreements dependency detection with the public Backstage Venue Manager package by accepting its `BVMGR_VERSION` runtime identity.
- Retains legacy `VMS_VERSION` compatibility for older VMS Core installations.
- Uses one resolved core-version value for both dependency gating and the installed-version notice.
- Does not change agreement records, snapshots, hashes, acknowledgements, templates, notifications, permissions, nonces, or business rules.

## 0.3.46 - 2026-08-22

- Rebalances the top Agreement Packet Summary so **Event Details** receives slightly more horizontal space and the long Venue contracting-party value no longer feels squeezed.
- Reduces the reserved Vendor Details label width from the 0.3.45 overlap fix while preserving safe wrapping, giving Vendor values adequate room without reintroducing label/value collisions.
- Applies the same balance to the standalone HTML print-copy view and actual print/PDF output; mobile remains single-column.
- Presentation-only release; no agreement wording, packet data, hashes, acknowledgement behavior, or business rules changed.

## 0.3.45 - 2026-08-22

- Prevents long Vendor Details labels from colliding with their values in the standalone HTML print-copy preview.
- Reserves additional label width for the Vendor Details card while keeping the Event Details card compact.
- Adds safe wrapping for detail labels and a print-specific width that preserves the two-column PDF summary without overlap.
- Presentation-only release; no agreement wording, packet data, hashes, acknowledgement behavior, or business rules changed.

## 0.3.44 - 2026-08-21

- Streamlines the vendor-facing HTML agreement so the visual Agreement Packet Summary is not repeated again inside the formal Agreement Terms; the Summary is expressly incorporated into the agreement instead.
- Simplifies stock weather/safety language into shorter paragraphs and a clear payment list, explicitly naming rain, lightning, severe thunderstorms, high winds, flooding, and extreme heat as examples.
- Renames the stock **Vendor Cancellation / No-Show / Nonperformance** clause to the less adversarial **Vendor Cancellation / Performance Issues** while preserving the same core protections for safety concerns, delays, cancellation, failure to appear, and materially incomplete performance.
- Renames the stock ticket-demand clause to **Low Ticket Sales / Event Viability Cancellation** and presents the 7-day/50%/arrival payment rules as an easy-to-scan list.
- Shortens the Payment Timing clause so it supplements rather than repeats the structured Payment Terms already shown in Compensation Terms.
- Aligns the Vendor and Venue physical-signature lines by reserving equal identity-header height before the execution lines.
- Adds exact-match migration for untouched stock 0.3.42/0.3.43 clause bodies/titles and acknowledgement wording while preserving operator-customized language.

## 0.3.43 - 2026-08-21

- Standardizes vendor-facing agreement typography across both the HTML review and the print/PDF copy using a four-level hierarchy: document title, section heading, subsection heading, and body text.
- Overrides prior accumulated one-off sizes for summary cards, compensation/payment lists, bonus tables/notes, production responsibilities/schedule, agreement clauses, and acknowledgement text so the packet reads as one designed document.
- Keeps print/PDF sizing compact and consistent while preserving the existing two-column summary, bonus layout, and loose-page identity footer.
- Adds a **Physical Signatures** section to unacknowledged printable copies with Vendor and Venue signature, printed-name, title/capacity, and date lines.
- Electronically acknowledged print copies continue to show acknowledgement proof rather than blank physical-signature lines.
- No contract wording, compensation logic, payment method, production schedule, weather rules, packet hashes, or acknowledgement evidence changes in this release.

## 0.3.42 - 2026-08-21

- Adds booking-specific **Production Schedule** fields to Agreement Setup: required arrival/load-in, required soundcheck start, required soundcheck completion, and optional load-out/venue-vacate time.
- Includes those schedule terms in new packet snapshots, terms hashes, public/print summaries, formal Agreement Text, admin packet review, and Event Plan read-only Agreement status.
- Uses the scheduled arrival/load-in time as the objective anchor for the weather-cancellation payment cutoff.
- Replaces the prior arrival-based 0%/50%/100% weather ladder with the agreed 24-hour rule: cancellation at least 24 hours before scheduled arrival/load-in owes no base guarantee; cancellation inside 24 hours owes 100% of the base guarantee.
- Keeps approximately 72-hour forecast review as a planning goal rather than a payment trigger.
- Adds balanced safety/nonperformance language: Vendor may raise specific safety concerns, nobody is required to work during rain on the uncovered stage or another immediate unsafe condition, and unjustified refusal/material delay in load-in/setup/soundcheck/performance may be treated as nonperformance.
- Formats U.S./Canada 10-digit vendor phone numbers throughout Agreements as **(###) ###-####**, including new snapshots, public/print views, admin packet review, and agreement emails; historical raw 10-digit packet values are formatted at display time.
- Exact-match migration updates untouched stock 0.3.41 weather, nonperformance, and venue-rules clauses while preserving customized operator language.

## 0.3.41 - 2026-08-21

- Cleans Final Payment setup alignment and hides the custom Other-method field until it is needed.
- Presents payment timing/method as a readable **Payment Terms** list inside Compensation Terms and before the bonus payout schedule in formal Agreement Text.
- Defines the Venue-provided House Sound / PA standard package around the agreed input list: confirmed microphones/stands, DI boxes, monitor wedges, and ordinary house audio cabling.
- Makes instruments, personal/instrument cabling, specialty/wireless gear, and in-ear monitoring systems Vendor-provided unless expressly accepted otherwise in writing; compatible console monitor sends may be supplied when available.
- Requires advance disclosure of stage plots/input lists and nonstandard technical requirements.
- Expands Venue Rules to cover reasonable written arrival/load-in, setup, soundcheck, performance, strike/load-out, and venue-vacate scheduling without forcing every logistics adjustment to become a material contract amendment.
- Exact-match migration updates untouched stock 0.3.40 clause wording while preserving customized operator language.

## 0.3.40 - 2026-08-21

- Makes final payment method a required Agreement Setup prerequisite for new/regenerated packets.
- Adds a **Final Payment** section to Agreement Setup showing the resolved payment timing plus a required payment-method selector: Check, Cash, ACH / Direct Deposit, Zelle, Venmo, PayPal, or Other.
- When **Other** is selected, requires a specific manual payment-method description.
- Writes the selection to VMS Core's existing Event Plan final-payment method fields rather than creating an Agreements-only duplicate.
- Existing packet compensation rendering already includes payment method when present; 0.3.40 ensures new packets cannot omit it.
- Event Plan Agreement Packet status now shows the resolved payment method or **Needs setup**.
- Preserves already-open 0.3.37 Event Plan editor compatibility without clearing a payment method that was later set in Agreements.
- Does not change the agreement clause wording, acknowledgement schema, public review token behavior, or historical packet evidence.

## 0.3.39 - 2026-08-21

- Makes Agreement Text section headings visibly bold on the vendor review page without changing stored template wording, packet snapshots, hashes, or acknowledgement evidence.
- Also bolds generated Compensation subheads such as **Bonus payout schedule** and **Payment summary** for clearer scanability.
- Adds a small repeating print/PDF identity footer with event name, event date, packet ID, and agreement version so separated printed pages can still be associated with the correct agreement.
- No contract terms, business rules, generation readiness, payment logic, or acknowledgement behavior changed from 0.3.38.

## 0.3.38 - 2026-08-21

- Moves Vendor legal/contract identity and booking-specific Production Responsibilities out of the WordPress Event Plan editor and into a dedicated **Agreement Setup** workflow on the VMS Agreements screen.
- Keeps those values attached to the Event Plan for snapshot/current-vs-stale verification, but makes Agreements the editing surface so agreement-only fields are not mixed into general Event Plan editing.
- Fixes the unsaved-value trap where clicking **View Current Packet** from the Event Plan sidebar navigated away without submitting newly entered agreement fields.
- Event Plan Agreement Packet metabox is now read-only status/navigation: it summarizes legal party, representative, production readiness, and packet status, then links to Agreement Setup or the stored packet.
- Agreement Setup saves through its own nonce-protected admin action and provides save-aware actions for **Save & View Current Packet** and **Save & Generate/Regenerate**, so those actions persist the form before navigating.
- The main Agreements Generate card now opens Agreement Setup for any upcoming, non-cancelled Event Plan with a primary vendor, including plans that still need identity/production answers.
- Generation readiness diagnostics now direct identity and production blockers to Agreement Setup rather than telling operators to save the Event Plan.

## 0.3.37 - 2026-08-21

- Adds explicit Vendor legal / contracting name and Vendor representative/contact identity to new packet snapshots, public review, printable copies, formal agreement text, and terms hashes.
- Vendor legal identity prefills from the VMS payee/legal name and falls back to the VMS Contact Person; both legal identity and representative can be overridden per Event Plan before packet generation.
- Adds required booking-specific Yes/No Production Responsibilities for Stage, House Sound / PA, Stage Lighting, and Sound Engineer.
- Requires operators to confirm those production answers before packet generation.
- Production responsibilities are snapshotted and included in packet-current/stale diagnostics.
- Public signer name/email fields prefill from the packet representative/contact and vendor email but remain editable by the actual signer.
- Updates stock Agreement Packet Scope wording to name the legal Vendor party and representative/contact. Customized clause wording remains preserved by the stock-language migration rules.

## 0.3.36 - 2026-08-21

- Reworks Agreement Packet Summary from three cramped side-by-side cards into Event Details + Vendor Details side-by-side with Compensation Terms full-width below.
- Places the qualifying-paid-ticket explanation beside the bonus payout table on wide/print layouts, eliminating unused horizontal space.
- Restores practical label/value widths so Contracting party and Compensation terms no longer collide with their values.
- Allows the Agreement Terms panel to continue across pages while keeping individual clauses together, eliminating the large blank lower half of page 1.
- Fixes the print-only unacknowledged status sentence to say the Vendor submits their acknowledgement rather than submits the Agreement Packet.
- Does not change agreement clauses, packet schema, hashes, snapshots, compensation logic, acknowledgement records, or generation eligibility.

# 0.3.35 - Generation Readiness Diagnostics

## 0.3.35 - 2026-08-21

- Replaces the Event Plan sidebar's generic cancelled/past generation warning with the actual blocking reason.
- Missing Agreement Defaults now explicitly identify the Legal contracting party requirement and link directly to Agreement Defaults.
- Cancelled, past, missing-vendor, and missing-Event-Plan states now have distinct operator guidance instead of sharing one misleading message.
- Packet-detail guardrails use the same readiness diagnostic source so Agreements surfaces stay consistent.
- Does not change agreement text, packet schema, hashes, acknowledgement records, compensation, or generation eligibility rules from 0.3.34.

# 0.3.33 - Public Review Cache Safety

## 0.3.34 - 2026-08-21

- Hardened default agreement language for live-band performance, weather/rain safety, event viability, payment timing, riders, nonperformance, independent-contractor/W-9 terms, amendments, and Texas dispute handling.
- Added qualifying paid-ticket bonus language: discounted paid tickets count; free/comps/refunds/cancellations/known chargebacks/non-revenue admissions do not; highest threshold wins and tiers are not cumulative.
- Added Agreement Defaults for legal contracting identity and standard final-payment fallback.
- New packets snapshot the legal contracting identity and include it in the terms hash.
- Stock 0.3.33 template wording upgrades safely; customized editable clauses are preserved.
- Clarified public acknowledgement-status wording.

- Moves no-cache handling for public agreement review and acknowledgement requests earlier in the request lifecycle so public packet links send explicit no-store headers before render and on acknowledgement redirects.
- Strengthens cache-bypass flags and response headers for public agreement routes by setting `DONOTCACHE*`/`DONOTMINIFY`/`DONOTCDN`, removing `ETag` and `Last-Modified`, and sending `Cache-Control`, `Pragma`, `Expires`, and `Surrogate-Control` directives together.
- Forces a fresh Event Plan post-cache refresh before each public review context computes current vs stale packet terms, so the public route always compares against the latest linked Event Plan state.
- Preserves packet generation, send/resend rules, acknowledgement storage, operator signed-notification emails, cleanup behavior, and admin workflows from 0.3.32.
- Vendor portal status counts now show `Current signed` separately from `Signed history`, so acknowledged history is no longer under-reported when no active packet exists.

# 0.3.32 - Vendor Status Surface Clarity

- Adds an admin-side **Agreements** metabox on `vms_vendor` screens so operators can see current unsigned/viewed/signed counts plus signed packet history without opening the vendor portal.
- Fixes Event Plan metabox wording so a historical packet is no longer presented as the **Current Packet** when no active packet exists.
- Adds explicit historical-only messaging on Event Plans, including whether the latest packet still matches the current Event Plan terms or has gone stale.
- Preserves packet generation, email send/resend, public review, acknowledgement storage, operator signed-notification emails, and cleanup rules from 0.3.31.

# 0.3.31 - Admin Test Packet Cleanup Tools

- Adds an admin-only **Testing / Cleanup** section on Agreement Packet detail screens.
- Adds a hard-delete action to remove unacknowledged test packets for the same Event Plan when their statuses are generated, sent, viewed, superseded, or voided.
- Adds a second hard-delete action to remove only stale/history packets for the same Event Plan, keeping the current generated/sent/viewed packet intact.
- Protects acknowledged packets by treating acknowledgement history as status-or-history, so superseded/voided packets with vendor acknowledgements are skipped instead of deleted.
- Refreshes the Event Plan's `_vmsa_latest_packet_id`, cleans relevant post caches, and exposes a `vmsa_after_packet_cleanup` hook for any site-specific cache invalidation after cleanup runs.
- Adds cleanup result notices with deleted/skipped counts while preserving the 0.3.29 current/stale/hash fix and the 0.3.30 Agreement Packet language consistency work.

# 0.3.30 - Agreement Language Consistency Audit

- Standardizes vendor-facing agreement language around **Agreement Packet**, **Event Details**, **Vendor Details**, **Compensation Terms**, **Deposit / Advance Terms**, **Agreement Terms**, **Acknowledgement Record**, and **Packet Verification Records**.
- Adds a required protected **Agreement Packet Scope** block to the generated agreement text so new packets define the scope of the document before the event/vendor/compensation sections.
- Replaces the stock acknowledgement checkbox labels plus the stock **Acknowledgement & Audit Record** and **Acknowledgement Proof** blocks with more explicit Agreement Packet terminology.
- Updates public review, print/PDF, vendor-portal, proof-display, and default email copy so vendor-facing stale notices no longer mention **Event Plan** and acknowledgement/audit language uses **agreement version** instead of vendor-facing **packet version** wording.
- Adds exact-match upgrade paths for unchanged stock template text and unchanged stock email templates, while leaving customized operator wording untouched.
- Preserves the 0.3.29 raw-title/mojibake cleanup and latest-current vendor-portal packet-selection fixes without changing the underlying current/stale/hash logic.

# 0.3.29 - Raw Title Current-State and Vendor Portal Selection Fix

- Fixes a false public/vendor stale mismatch where Agreements hashed filtered `get_the_title()` output while wp-admin decoded Event Plan title entities differently than public/vendor-portal requests.
- Switches agreement snapshot/title sourcing to raw `post_title` values plus entity/mojibake cleanup before packet title generation, snapshot storage, and terms-hash calculation.
- Prevents newly generated packets from carrying forward mojibake or encoded title fragments when the source Event Plan/vendor/venue/template titles contain broken punctuation.
- Vendor portal now promotes only the latest current packet per Event Plan as the primary actionable card and moves superseded, voided, and outdated/stale packets into history instead of letting an older stale packet stay front-and-center.
- Vendor portal counts and the Action Needed banner now follow the same latest-current packet source of truth instead of counting stale packets as actionable.

# 0.3.28 - Frontend Current-State Fallback and Stale Hardening

- Fixes a public/vendor review mismatch where the admin packet screen could show **Current** while the public review page showed **Event Plan terms changed since packet generation** for the same packet.
- Adds a frontend-safe fallback in packet current-state diagnostics: if VMS Core's admin compensation helper is not loaded on a public/vendor-portal request, VMS Agreements preserves the packet's stored compensation terms for the current-side comparison instead of comparing against an empty compensation payload.
- Keeps Event Plan title/date/time, venue, vendor, and template fields in the current-state comparison so genuinely changed agreement details can still be detected.
- Adds diagnostics visibility for whether the VMS compensation helper was available and which fallback, if any, was used.
- Recursively cleans snapshot strings during packet generation so newly generated snapshots/post titles do not keep carrying mojibake text forward.

# 0.3.27 - Current-State Diagnostics and Generation Cleanup

- Adds an admin-only **Agreement Current-State Diagnostics** panel on packet detail screens so stale/current mismatches can be traced by field instead of guessed.
- Shows stored terms hash, packet canonical hash, current Event Plan hash, whether stored hash matches the packet, whether the packet matches the current Event Plan, and up to 40 field-level differences.
- Normalizes event, vendor, venue, and template text during packet generation so new packet snapshots and packet titles do not keep carrying mojibake forward.
- Uses the same canonical agreement-fingerprint payload for current/stale checks and diagnostics. If the canonical field diff is empty, the packet is treated as current even if old volatile hashes disagree.
- Adds stronger no-cache behavior and a packet revision query arg for public vendor review/print URLs and vendor-portal agreement output, reducing false stale displays from page cache.
- Formats generated/audit timestamps through the WordPress site timezone instead of rendering raw database timestamps in admin lists/audit trails.
- Keeps the 0.3.24 manual-send workflow, vendor action flags, and operator signed-notification email behavior.

# 0.3.26 - Cache/Timezone/Stale/Mojibake Hardening

- Fixes generated/audit time display by parsing VMS Agreements audit timestamps as WordPress-site-local time instead of letting PHP reinterpret timezone-less MySQL strings as server time and shift them again.
- Hardens packet current/stale comparison to use a narrower contract-significant fingerprint instead of derived/admin-context values that can change immediately after generation.
- Keeps stale detection focused on event title/date/time, venue, vendor contact, structured compensation terms, and template acknowledgement/body identity.
- Expands mojibake cleanup for truncated `â€` fragments and double-encoded punctuation sequences that can survive inside packet titles and Agreement Text Preview output.
- Preserves manual-send agreement behavior, vendor action flags, and operator signed-notification email behavior from 0.3.24/0.3.25.

# 0.3.25 - Stale Hash and Preview Mojibake Fix

- Fixes a false-stale condition where a newly generated/regenerated packet could immediately show **Event Plan terms changed since packet generation**.
- Changes Agreements compensation hashing to use only the structured compensation terms captured from VMS Core, avoiding adjacent/volatile Event Plan meta from making a fresh packet look stale.
- Adds a stable canonical agreement terms-hash comparison that ignores volatile fields such as generated packet IDs, edit URLs, post modified timestamps, and health-check wording.
- Canonicalizes text for terms-hash comparison with the same mojibake/display cleanup used in the UI, so repaired punctuation does not create false stale warnings.
- Applies display cleanup to the admin Agreement Text Preview output.
- Expands mojibake repair for truncated `â€` fragments that survive with unusual whitespace/control bytes.
- Preserves the 0.3.24 manual-send flags, vendor portal action flags, and operator signed-notification email behavior.

# 0.3.24 - Agreement Action Flags and Signed Notifications

- Keeps agreement packet generation manual-only: packets stay in a clear **Generated / Not yet sent** state until the operator emails the vendor review link.
- Adds a more explicit unsent notice in the admin packet Email Review Link card when a packet has been generated but no vendor review email has been sent yet.
- Adds a vendor-portal Agreements tab badge showing how many current agreements still need attention.
- Adds a more prominent vendor-portal Action Needed banner when one or more agreements are waiting for review/acknowledgement.
- Keeps vendor-facing agreement cards/status counts, but makes unsigned agreements harder to miss from the portal dashboard flow.
- Adds a new operator signed-notification email template and automatically emails operator/admin recipients (default: WordPress admin email, filterable) when a vendor acknowledges an agreement.
- Records the operator signed-notification email in the packet email audit trail and stores send-result metadata.
- Expands the Email Template Editor so review email, signer confirmation email, and operator signed-notification email can all be customized in one place.

# 0.3.23 - Agreement Mojibake Display Cleanup

- Adds a display-only mojibake repair helper for common UTF-8 punctuation artifacts such as `â€“`, `â€”`, `â€™`, `â€œ`, `â€�`, `â€¦`, and stray `Â` fragments.
- Applies the cleanup to packet titles, admin packet views, operator queue rows, public/vendor review pages, print/PDF agreement copy, agreement text preview, vendor portal cards, acknowledgement labels/proof, and review/acknowledgement email token rendering.
- Keeps stored packet snapshots and terms/compensation hashes intact so existing generated packets are not invalidated solely by display cleanup.
- Updates packet title normalization so an event title with mojibake punctuation can still match the correctly encoded vendor title and avoid duplicated event/vendor names in the packet header.
- Preserves the 0.3.18 activation hotfix and 0.3.22 compact print/PDF bonus-table layout.

# 0.3.21 - Print Bonus Payout Table

## 0.3.22 - Print compact summary and bonus table

- Restored compact side-by-side Event/Vendor/Payment summary cards for the standalone print/PDF agreement copy.
- Reduced print-mode spacing and font size for the top summary cards.
- Reduced Bonus payout schedule table spacing and font size so base-plus-bonus packets are more likely to fit on one printed page.
- Preserved the 0.3.18 activation hotfix and 0.3.20/0.3.21 bonus payout table behavior.


- Adds the bonus payout schedule table to the standalone Print / Save as PDF agreement copy.
- Ensures `Bonus: see payout table below` is never shown in the printable Booking & Payment Summary without the actual table immediately below it.
- Keeps the 0.3.18 activation-time safety cleanup and 0.3.20 payout-table behavior intact.
- Adds 0.3.21 Codex handoff and test plan.

# 0.3.20 - Bonus Payout Table

- Replaces the wordy step-bonus agreement explanation with a concise "Bonus: see payout table below" summary plus an actual payout schedule table.
- The payout schedule uses the Event Plan-style table structure: count basis / payout, starting with the no-bonus threshold row and then each bonus step.
- Defaults the count basis to paid ticket sales unless the Event Plan terms explicitly specify a different basis.
- Adds the bonus payout schedule to the admin packet Compensation Snapshot, the public/vendor Booking Summary, and the plain-text Agreement Text Preview.
- Keeps the 0.3.18 activation hotfix intact.
- Adds 0.3.20 Codex handoff and test plan.

# 0.3.19 - Bonus Wording Polish

- Shortens Base + attendance/ticket-sales bonus summary wording so generated packets read more like the Event Plan pay preview.
- Keeps the default bonus basis as paid ticket sales.
- For a 100 threshold and 50-ticket step, agreement wording now reads: `Bonus: No bonus is earned through 100 paid ticket sales. Add $250.00 every 50 paid ticket sales after that.`
- Keeps the 0.3.18 lightweight activation hotfix unchanged.
- Adds 0.3.19 Codex handoff and test plan.

# 0.3.18 - Activation + Bonus Clarity

- Keeps activation lightweight by deferring default-template creation/checking to the existing admin-init manager path instead of performing heavier template writes during the activation hook.
- Stores a one-time `vmsa_needs_default_template_check` flag on activation and clears it after the admin-side default template check completes.
- Updates Base + attendance/ticket-sales bonus agreement wording to default to paid ticket sales instead of raw attendees.
- Clarifies step bonuses so a threshold of 100 and step size of 50 reads as no bonus on the first 100 paid ticket sales, then the first bonus at 150 paid ticket sales.
- Adds 0.3.18 Codex handoff and test plan.

# 0.3.17 - Boot / I18n Log Cleanup

- Adds explicit textdomain loading on `init`.
- Hardens the Agreements Planning-nav and guided-tour registries so they return raw English strings before WordPress reaches `after_setup_theme`, preventing repeated early `vms-agreements` translation notices in `debug.log`.
- Keeps packet schema, template health behavior, queue behavior, vendor portal behavior, review links, acknowledgement flow, and print rendering unchanged.
- Adds 0.3.17 Codex handoff and test plan for the debug-log cleanup pass.

# 0.3.16 - Template Editor Hardening

- Adds a stronger Template Health Check panel in the Template Block Editor with visible error/warning counts and plain-English consequences.
- Adds an admin-only **Repair Required Components** action for the agreement template editor.
- The repair action restores required/protected template components to safe defaults where missing, disabled, or empty, merges required acknowledgement rows back in, refreshes health metadata, and bumps the template patch version when a repair changes stored template data.
- Template saves now redirect with a warning notice when blocking health-check errors remain instead of showing a plain success state.
- Required editable blocks now show clearer status badges such as Stock wording, Customized wording, or Needs wording.
- Empty required clauses now show an inline warning explaining that packet generation will be blocked until wording is restored.
- Keeps packet schema, review tokens, acknowledgement submission, email delivery diagnostics, operator queue behavior, vendor portal behavior, default clause wording, and print rendering unchanged.
- Adds 0.3.16 Codex handoff and test plan with explicit repair/versioning protocol.

# 0.3.15 - Template Health Check Alignment

- Aligns Template Health Check audit-disclosure validation with the polished 0.3.14 vendor-facing language.
- Stops requiring the literal word `hash` in the stock Audit Disclosure clause.
- Accepts friendlier wording such as packet verification records, verification records, packet ID, or recorded packet while still accepting explicit terms/compensation hash language for operators who prefer it.
- Keeps underlying terms hash, compensation hash, packet snapshots, stale detection, acknowledgement proof, review tokens, operator queue behavior, vendor portal behavior, email delivery guardrails, and print rendering unchanged.
- Adds 0.3.15 Codex handoff and test plan with explicit repair/versioning protocol.

# 0.3.14 - Agreement Language Polish

- Polished the stock default agreement language so new packets read less like placeholder scaffolding and more like a usable vendor booking agreement.
- Expanded the default Cancellation / Event Viability clause to cover safety, severe weather, event viability/ticket demand, operational readiness, vendor availability, force majeure, documentation, notice, reschedule/release handling, and payment/deposit implications.
- Clarified Payment Timing language so deposits/advances, variable compensation, refunds, comps/exclusions, documented adjustments, final payment timing, and payment method are easier to understand.
- Clarified Technical / Hospitality Rider Handling language, including venue-provided production details and the rule that unapproved, late, or conflicting rider terms are not binding unless accepted in writing.
- Clarified No-show / Nonperformance language without introducing a default flat penalty.
- Expanded Venue Rules / Expectations language around load-in, safety, staff directions, lawful conduct, and prompt notice of issues affecting arrival/performance/safety.
- Updated default acknowledgement checkbox copy to be more plain-English and less raw-hash-focused.
- Updated default Review Link and Acknowledgement Confirmation email copy for clearer vendor-facing wording.
- Added a safe default-language migration that updates only unchanged stock 0.3.13 template clauses, acknowledgement labels, and email templates while preserving operator-customized text.
- Bumps the default template version when the stock agreement language migration changes the installed template, so stale-packet detection can do its job.
- Keeps packet schema, review tokens, acknowledgement records, email delivery guardrails, operator queue behavior, vendor portal behavior, and print rendering unchanged.
- Adds 0.3.14 Codex handoff and test plan with explicit repair/versioning protocol.

# 0.3.13 - Operator Agreement Queue

- Added an operator-facing **Operator Agreement Queue** to the Agreements admin page above **Recent Packets**.
- Groups packets into Stale / Needs Regeneration, Generated - Not Sent, Sent - Not Viewed, Viewed - Not Acknowledged, Acknowledged, and Superseded / Voided History.
- Adds summary count pills so operators can quickly see how many packets are waiting in each state.
- Keeps active follow-up sections open by default while acknowledged/history sections stay collapsed by default.
- Queue rows show packet, event/date, vendor/email, packet status, terms status, last activity, and compact actions.
- Adds queue actions for Open Packet, Event Plan, Email/Resend Review, and Print/PDF where safe.
- Stale packets do not expose queue email actions; operators are directed to open the packet and regenerate safely.
- Superseded and voided packets remain historical-only and do not expose active queue email/review actions.
- Reuses the existing 0.3.12 review-link email handler so queue email sends retain delivery diagnostics and failure guardrails.
- Adds admin CSS for the queue, responsive table behavior, and a guided tour step.
- Keeps packet schema, public review links, print links, acknowledgement flow, vendor portal layout, and review-token validation unchanged.
- Adds 0.3.13 Codex handoff and test plan with explicit repair/versioning protocol.

# 0.3.12 - Review Email Delivery Verification

- Added a review-link email send diagnostic wrapper for the admin packet viewer action.
- Captures `wp_mail_failed`, `wp_mail_succeeded`, and `pre_wp_mail` short-circuit behavior for review-link email sends.
- Adds lightweight diagnostic fields to review-link email audit records, including `wp_mail_return`, `wp_mail_succeeded_action`, `pre_wp_mail_short_circuit`, and `wp_mail_failed_code`.
- Prevents VMS Agreements from marking a packet as sent when review-link email delivery is intercepted by a `pre_wp_mail` filter before PHPMailer handles the message.
- Keeps packet status, sent timestamp, send count, and last-sent metadata unchanged when review-link email delivery is not confirmed.
- Shows the last review-link email error in the admin packet viewer email box.
- Adds review-link email headers `X-VMSA-Email-Type` and `X-VMSA-Packet-ID` to make local Mailpit/log inspection easier.
- Keeps acknowledgement confirmation email behavior, packet schema, public review links, print links, vendor portal layout, and acknowledgement flow unchanged.
- Adds 0.3.12 Codex handoff and test plan with explicit repair/versioning protocol.

# 0.3.11 - Vendor Portal History Cleanup

- Collapsed superseded and voided vendor portal packets into a default-closed **Agreement History** section so the current/actionable agreement stays easy to find.
- Historical packets now render as compact record cards instead of full agreement cards.
- Active/current packets still render expanded with Review Agreement and Print / Save PDF actions.
- Updated compensation summary wording so simple flat-fee packets read `Flat fee: $1,500.00` instead of `Flat fee; Base/flat: $1,500.00`.
- Added compatibility cleanup for older stored packet snapshots so existing packets display cleaner wording without needing regeneration.
- Reduced duplicate public/print Booking Summary labeling by changing the event row label to `Event name`.
- Bumped minimum recommended VMS Core requirement to `0.2.24.570+`, matching the current tested Core baseline after the vendor portal pattern-preference fix.
- Added 0.3.11 Codex handoff and test plan with explicit repair/versioning protocol.

# 0.3.10 - Vendor Portal Core Hook Integration

- Added native VMS vendor portal nav integration through `vms_vendor_portal_nav_links`.
- Added an Agreements portal tab using Core's existing `vms_vendor_portal_render_custom_tab` filter.
- Updated dashboard auto-rendering to use the stable Core `vms_vendor_portal_dashboard_after_cards` hook and hide itself when the linked vendor has no packets.
- Reads vendor IDs from the Core-provided portal context first, improving admin preview and avoiding fragile logged-in-user guessing when Core already knows the active vendor.
- Keeps `[vmsa_vendor_agreements]` as a fallback/manual placement option, not the normal integration path.
- Keeps tokenized email review links, public review pages, print links, acknowledgement flow, packet schema, and regeneration guardrails unchanged.
- Requires VMS Core `0.2.24.569+` so the dashboard card and portal tab are available through stable Core extension points.
- Added 0.3.10 Codex handoff and test plan.

# 0.3.9 - Vendor Portal Pending Agreements

- Added vendor-facing agreement portal renderer in `includes/vendor-portal.php`.
- Added `[vmsa_vendor_agreements]` shortcode for safe placement inside the vendor portal or a vendor account page.
- Added defensive portal hooks for likely VMS vendor portal card/section areas while preserving shortcode fallback.
- Vendor portal now lists packets tied to the logged-in vendor profile by `_vmsa_vendor_id`.
- Shows Needs Review, Viewed, Acknowledged, Superseded, and Voided statuses.
- Active packets expose Review Agreement and Print / Save PDF buttons using the existing secure tokenized public review/print links.
- Superseded and voided packets remain historical-only and do not expose review/print actions.
- Added front-end portal styling and logged-in front-end stylesheet loading for portal cards.
- Kept email review-link flow, packet snapshots, acknowledgement submission, print rendering, regeneration guardrails, and token validation unchanged.
- Added 0.3.9 Codex handoff and test plan.

# 0.3.8 - Printable Copy Readable Width

- Changed printable agreement summary cards to full-width stacked sections instead of compressed side-by-side cards.
- Changed printable Agreement Terms to full-width clause blocks instead of two-column print squeezing.
- Increased print readability slightly even if normal agreements spill to a second page.
- Kept packet schema, acknowledgement records, review tokens, email delivery, template editor, and regeneration guardrails unchanged.

# 0.3.7 - Printable Copy Legibility Cleanup

- Rendered printable Agreement Terms as structured clause blocks instead of one continuous line-broken text blob.
- Added print-specific clause styling so clause headings stay visually connected to their matching text.
- Added two-column print layout for short clause blocks to preserve compact one-page output where practical.
- Kept printable summary, acknowledgement proof/status, review token behavior, email delivery, packet schema, and generation guardrails unchanged.

# 0.3.6 - Printable Copy Cleanup

- Tightened the standalone print/save-as-PDF view so agreement copies are much more compact and targeted for one to two pages when normal clause text is used.
- Added the event title to the printable Booking & Payment Summary.
- Removed internal packet status pills from printable copies.
- Replaced the print view body with a dedicated compact print renderer that avoids duplicating event/vendor/compensation/deposit blocks inside both the summary and agreement text.
- Print copies now render only the editable agreement clauses plus audit disclosure after the booking/payment summary.
- Removed `wp_footer()` from the standalone print shell so theme footer galleries or other footer-injected content cannot leak into saved PDFs.
- Added tighter print CSS, smaller print typography, reduced margins/padding, and print page margins.
- No packet snapshot schema, acknowledgement records, review token validation, email delivery, template editor, or regeneration guardrail behavior changed.

# 0.3.5 - Printable Agreement Copy

- Added a public printable agreement copy view using the existing secure review token plus `vmsa_print=1`.
- Added Print / Save as PDF actions on the public vendor review page and admin packet viewer.
- Printable copy uses a clean standalone shell instead of the full site header/footer.
- Printable copy includes booking summary, agreement text, and acknowledgement proof when a packet has been acknowledged.
- Unacknowledged printable copies clearly state that acknowledgement proof is not yet recorded.
- Added print CSS to hide action buttons and reduce shadows/backgrounds when printing or saving as PDF.
- No packet snapshot schema, acknowledgement records, review token validation, email delivery, regeneration, or template block behavior changed.


# 0.3.4 - Final Payment Method and Vendor Payment Summary Cleanup

- Requires VMS Core 0.2.24.568+ so agreement packets can snapshot core final payment timing and method terms.
- Vendor-facing public review no longer shows internal Event Plan publication/status in the Booking Summary.
- Payment summaries now include expected final payment timing and payment method when supplied by VMS Core, including `ACH / Direct Deposit`.
- Payment summary displays as separate readable lines on public review, admin packet viewer, agreement text, and emails.
- Deposit notes remain captured in snapshots but are not printed in the default vendor-facing deposit summary unless the operator adds custom agreement clause wording.
- No review token, acknowledgement audit, packet regeneration, or email-send guardrail behavior changed.


- Improved the stock Review Link Email and Acknowledgement Confirmation Email copy for mobile readability.
- Split compensation, deposit / advance, and payment summary into clearer sections instead of dense inline paragraphs.
- Added `{payment_summary_email}` token that renders payment-summary breakdown lines with simple bullets for email bodies.
- Softened vendor-facing email audit wording so emails reference packet verification records instead of exposing raw terms hash / compensation hash wording.
- Added a safe upgrade migration that updates unchanged 0.3.2 stock email templates to the improved 0.3.3 defaults while preserving operator-customized templates.
- No packet snapshot schema, review token validation, acknowledgement guardrail, template block rendering, or email send guardrail behavior changed.

# 0.3.2 - Email Template + Confirmation Email Foundation

- Added editable email templates for the vendor Review Link Email and the Acknowledgement Confirmation Email.
- Added an Email Template Editor from the Agreements admin Default Template card.
- Added an Email Template Health Check that flags missing/empty review email content and blocks review-link sending when the review email body is missing `{review_link}`.
- Added an Available Tokens panel for email templates, including event, vendor, venue, compensation, deposit, payment summary, review link, operator note, signer, acknowledgement, IP, version, and hash tokens.
- Added an optional one-time operator note field before sending/resending the vendor review link email.
- Review-link emails now render from the operator-editable email template instead of fixed hardcoded copy.
- Added automatic acknowledgement confirmation email after the vendor/signing contact acknowledges a packet.
- Added audit trail entries for acknowledgement confirmation emails alongside review-link email sends.
- No packet snapshot schema, review token validation, acknowledgement guardrail, or template block rendering behavior changed.

# 0.3.1 - Payment Summary Wording

- Replaced unclear deposit treatment wording such as "Creditable toward final pay" with clearer wording: "Applies toward the total payment."
- Added generated Payment summary output to public review, admin packet viewer, agreement text rendering, and review emails.
- Payment summary now shows total agreed payment or known base/guarantee, deposit/advance amount and status, and final payment balance after deposit/advance when calculable.
- Clarifies that deposit/advance is part of the total payment, not extra pay.
- Variable compensation packets now state that final payment may change according to the captured compensation terms.
- No token, acknowledgement, email-send, packet-generation, or storage guardrail behavior changed.

# Changelog

## 0.3.0 - Template Block Editor + Health Check

`0.3.0` adds the first structured template editor foundation. This is intentionally not a giant freeform agreement editor. It uses protected required blocks plus editable clause blocks so operators can customize wording without accidentally removing the Event Plan, vendor, compensation, deposit, acknowledgement, or audit record foundation.

### Added

- Template Block Editor opened from the Agreements admin screen.
- Protected required blocks for event details, vendor details, compensation terms, deposit / advance terms, audit disclosure, and acknowledgement proof.
- Editable clause blocks for cancellation / event viability, payment timing, technical / hospitality rider handling, no-show / nonperformance, venue rules / expectations, and additional terms.
- Template Health Check with errors/warnings for missing required blocks, disabled required blocks, empty critical clause text, missing required acknowledgement checkboxes, and weakened audit disclosure concepts.
- Template version patch bump whenever blocks are saved, so future packets use the revised version while existing packets keep their captured version.
- Packet generation block when the active template health check has errors.
- Structured block rendering in packet previews and the public Vendor Review page.
- New required acknowledgement confirming the signer is authorized to acknowledge the agreement on behalf of the vendor.
- `TEST-PLAN-0.3.0.md`.

### Not Changed

- No packet acknowledgement record schema change beyond future packets including the additional required acknowledgement row.
- No review token/link behavior changes.
- No email delivery logic changes.
- No PDF generation.
- No vendor portal agreement list/card yet.

## 0.2.3 - Generation Eligibility + Title Cleanup

`0.2.3` tightens agreement generation guardrails and cleans admin/public display issues found while testing live packets.

### Changed

- Cancelled Event Plans can no longer generate new agreement packets.
- Past Event Plans can no longer generate new agreement packets.
- The Generate Packet dropdown now lists only upcoming, non-cancelled Event Plans with a primary vendor.
- Direct admin-post generation requests are blocked for cancelled/past Event Plans, even if the URL is manually reused.
- Event Plan metabox and packet viewer explain that new packet generation is closed for cancelled/past events while preserving existing packet history.
- Packet titles now avoid repeating the same event/vendor name when both are identical.
- Existing packet views use a cleaned display title even if the stored post title was generated before this fix.
- UI punctuation in PHP output was normalized to ASCII hyphens/placeholders to avoid mojibake/crazy-character rendering on sites with odd charset/plugin interactions.
- Added `TEST-PLAN-0.2.3.md`.

### Not Changed

- Existing packets remain viewable.
- Existing acknowledgement records remain untouched.
- Existing review links, email records, hashes, and snapshot structures remain unchanged.
- Voiding remains available for existing active packets.

## 0.2.2 — Email Review Link Foundation

`0.2.2` adds the first admin-side email delivery layer for vendor agreement review links.

### Added

- **Email Review Link to Vendor** action in the admin packet viewer.
- Resend support after the first email is sent.
- `Sent` packet status when a generated packet is emailed before it has been viewed.
- Review email send count, last sent timestamp, last recipient, and sender user ID metadata.
- `_vmsa_email_records` audit entries for successful and failed email attempts.
- Audit Trail display for review email sends.
- Guardrails blocking email delivery for stale, voided, superseded, acknowledged, or missing-vendor-email packets.
- `TEST-PLAN-0.2.2.md`.

### Not Changed

- No public acknowledgement schema changes.
- No review token/link behavior changes.
- No editable email template UI yet.
- No automatic reminders yet.


## 0.2.1 — Inline Acknowledgement UX

`0.2.1` moves the public vendor-facing acknowledgement checkboxes next to the agreement content they confirm. Event/vendor/compensation and deposit confirmations now appear directly below the Booking Summary content, while the audit-record acknowledgement remains near signer details and submit.

### Changed

- Public review form now wraps the agreement content so required checkboxes can appear inline with the relevant sections.
- Booking Summary displays the event/vendor/compensation acknowledgement and deposit / advance acknowledgement directly under the related summary content.
- Signer Details & Submit card now contains signer name/email plus the audit-record acknowledgement and final submit button.
- Added public CSS for inline acknowledgement rows.
- Added `TEST-PLAN-0.2.1.md`.

### Not Changed

- No packet storage changes.
- No acknowledgement record schema changes.
- No token/link changes.
- No hash or guardrail changes.

## 0.2.0 — Vendor Acknowledgement Foundation

`0.2.0` adds the first vendor-facing review and acknowledgement workflow.

### Added

- Secure tokenized Vendor Review Link for each active agreement packet.
- Public agreement review page showing event, venue, vendor, compensation, deposit / advance terms, and agreement text.
- Required signer name and signer email fields.
- Required acknowledgement checkboxes based on the packet template acknowledgement definitions.
- Public acknowledgement submission handler for logged-in and logged-out vendors.
- Audit capture for acknowledgement date/time, GMT date/time, signer identity, IP address, browser/user agent, user account ID when logged in, template ID/version, terms hash, compensation hash, Event Plan ID, vendor ID, and per-checkbox acknowledgement records.
- Printed acknowledgement proof on the vendor-facing page after submission.
- Admin packet viewer proof display for each acknowledgement line.
- Admin audit trail display with readable acknowledgement details instead of raw JSON.
- Review link first-viewed / last-viewed / view-count tracking.
- Review link regeneration action; regenerating the link invalidates prior copied links for that packet.
- `viewed` packet status once the public review link has been opened.
- Public CSS for the vendor review page.
- `TEST-PLAN-0.2.0.md`.

### Guardrails

- Superseded or voided packets cannot be reviewed publicly.
- Stale packets can be viewed but cannot be acknowledged.
- Already acknowledged packets show proof and do not show a second submit form.
- Regenerated packets still require fresh acknowledgement because old acknowledgements remain tied to the superseded historical packet.

## 0.1.5 — Packet Generation Guardrails

`0.1.5` prevents ordinary Generate Packet submissions from silently creating another current packet when one already exists. Operators must deliberately use Regenerate / Supersede to create a new current packet.

## 0.1.4 — VMS Admin Theme Polish

`0.1.4` aligned the Agreements admin screen with the shared VMS admin shell and cleaned spacing in the packet viewer and Generate Packet card.

## 0.1.3 — Snapshot Accuracy + Cleanup

`0.1.3` fixed Event Plan time display for packet snapshots, captured canonical Event Plan status labels, and cleaned deposit summary wording.

## 0.1.2 — Button + Guided Tour Hotfix

`0.1.2` fixed the disabled Generate Agreement Packet button and registered the first guided tour for the Agreements screen.

## 0.1.1 — Menu / Generate Packet Hotfix

`0.1.1` switched the admin page slug to `vms-agreements`, registered the page in the VMS Planning navigation, redirected legacy admin URLs, and fixed Event Plan sidebar packet generation by avoiding nested forms.

## 0.1.0 — Packet Foundation

`0.1.0` introduced the standalone premium add-on foundation: private template storage, private packet storage, Event Plan packet generation, compensation/deposit snapshots, hashes, stale detection, Event Plan metabox, admin packet viewer, and initial docs.
