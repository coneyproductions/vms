# VMS Agreements 0.3.46 Test Plan

## Top summary balance
1. Open an existing packet's **Print / Save as PDF** HTML view.
2. Confirm Event Details is slightly wider than Vendor Details.
3. Confirm **Contracting party** and `Coney Productions LLC d/b/a Serenade Range` read without feeling squeezed or colliding.
4. Confirm Vendor Details labels still wrap safely and do not overlap their values.
5. Confirm Vendor / act, legal contracting name, representative/contact, email, and phone remain readable.

## PDF / physical print
1. Print or Save as PDF.
2. Confirm the same Event/Vendor width balance is retained.
3. Confirm no labels or values overlap or clip.

## Responsive
1. At widths 700px and below, confirm Event and Vendor cards stack to one column.

## Regression
- No agreement wording changes.
- Existing packet does not become stale and does not require regeneration.
- All PHP files pass `php -l`; release ZIP passes `unzip -t`.
