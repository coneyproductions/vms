# VMS Agreements 0.1.5 Test Plan — Packet Generation Guardrails

## Goal

Confirm that packet generation no longer casually creates duplicate active agreement packets and that intentional regeneration is explicit.

## Required setup

- VMS Core 0.2.24.567 or newer active.
- VMS Agreements 0.1.5 active.
- At least one Event Plan with a primary vendor assigned.

## Tests

### 1. First packet generation still works

1. Open **VMS → Planning → Agreements**.
2. Choose an Event Plan with no existing agreement packet.
3. Click **Generate Agreement Packet**.

Expected:

- A packet is created.
- Packet status is **Generated**.
- Terms status is **Current**.

### 2. Ordinary duplicate generation is blocked

1. Return to the Generate Packet card.
2. Select the same Event Plan again.
3. Click **Generate Agreement Packet**.

Expected:

- No new packet is created immediately.
- The existing current packet opens.
- A warning notice explains that a current packet already exists and regeneration must be deliberate.

### 3. Intentional regeneration works

1. From the packet viewer, click **Regenerate / Supersede Current Packet**.

Expected:

- A new current packet is created.
- The previous packet is preserved and marked **Superseded**.
- The Recent Packets table shows only one current packet for that Event Plan/vendor.

### 4. Event Plan side metabox guardrail

1. Open the Event Plan edit screen.
2. Inspect the **Agreement Packet** metabox.

Expected:

- The metabox shows **View Current Packet** as the primary action when a packet exists.
- **Regenerate / Supersede** appears as a deliberate secondary action.
- Helper copy explains that regeneration preserves history and creates a new current packet.

### 5. Future acknowledgement safety note

After the vendor-facing acknowledgement flow exists, repeat the regeneration flow against an acknowledged packet.

Expected future behavior:

- The acknowledged packet is preserved as superseded history.
- The new packet requires fresh vendor acknowledgement.
- The warning text clearly states that a fresh acknowledgement is required.
