# VMS Agreements 0.3.41 Test Plan

## Agreement Setup layout
1. Open Agreements → Agreement Setup.
2. Confirm Payment method is aligned on its own row.
3. Confirm Other payment method is hidden for a standard payment method.
4. Select Other and confirm the custom method field appears and becomes required.

## Compensation / payment presentation
1. Generate a packet with a base guarantee, attendance-bonus schedule, final-payment timing, and payment method.
2. Confirm Agreement Packet Summary shows **Payment Terms** as a readable list inside Compensation Terms.
3. Confirm formal Agreement Text orders Compensation terms → Payment terms → Bonus payout schedule.
4. Confirm Payment terms renders as bullets rather than an inline hyphen run.
5. Confirm payment method and final-payment timing match Agreement Setup / VMS Core.

## Technical scope
1. Set House Sound / PA to Yes and generate a packet.
2. Confirm the Production Responsibilities summary notes that House Sound / PA uses the Venue-confirmed standard house package and that Vendor supplies IEM/specialty/wireless gear unless accepted in writing.
3. Confirm Production / Technical / Hospitality Terms state Venue-confirmed house PA, standard microphones/stands, DI boxes, stage monitor wedges, and ordinary house audio cabling for the agreed input list.
4. Confirm Vendor responsibility for instruments, instrument/pedalboard cables, specialty/wireless equipment, and IEM hardware is explicit.
5. Confirm Vendor must disclose a stage plot/input list and nonstandard requirements reasonably in advance.

## Production schedule / access
1. Confirm Venue Rules / Performance Expectations expressly covers arrival/load-in, setup, soundcheck, performance, strike/load-out, and venue-vacate timing.
2. Confirm reasonable logistical schedule updates communicated by Venue do not require a new packet unless the packet makes a fixed time a material term.

## Migration / regression
- Untouched stock 0.3.40 Payment Timing, Production / Technical / Hospitality, and Venue Rules clauses migrate to 0.3.41 wording.
- A customized version of any of those clauses remains untouched.
- Existing historical packet snapshots remain readable and unchanged.
- Vendor identity, production Yes/No fields, payment-method requirement, acknowledgement flow, print identity footer, and generation diagnostics continue to work.
- All plugin PHP files pass `php -l`.
