# Codex Handoff - VMS Agreements 0.3.12

## Build

- Plugin: VMS Agreements
- Version: `0.3.12`
- Build label: `review-email-delivery-verification`
- Required VMS Core: `0.2.24.570+`
- Folder must remain: `vms-agreements`

## Why This Build Exists

Testing of VMS Agreements 0.3.11 mostly passed, but admin-side **Email Review Link** sends updated packet audit/meta as sent while Mailpit did not receive a new review-link email. Tokenized review URLs worked directly, and acknowledgement confirmation emails did reach Mailpit, so the issue appeared specific to the review-link send path or local delivery/capture behavior for that path.

## What Changed

- Added review-link email delivery diagnostics through `vmsa_send_mail_with_diagnostics()`.
- The admin packet viewer review-link send action now records:
  - `wp_mail_return`
  - `wp_mail_succeeded_action`
  - `pre_wp_mail_short_circuit`
  - `pre_wp_mail_return_type`
  - `wp_mail_failed`
  - `wp_mail_failed_code`
  - `error`
- Review-link send success now requires `wp_mail` success without `wp_mail_failed` and without `pre_wp_mail` short-circuit interception.
- If delivery is intercepted or fails, the packet is not marked sent, send count is not incremented, generated status does not advance to sent, and the admin packet viewer shows the last email error.
- Added `X-VMSA-Email-Type: review_link_email` and `X-VMSA-Packet-ID` headers for easier Mailpit/log inspection.

## Intentionally Unchanged

- Packet schema.
- Review token validation.
- Public review route.
- Public print route.
- Vendor portal layout/history behavior.
- Acknowledgement submission flow.
- Acknowledgement confirmation email behavior.
- Regenerate/supersede/void guardrails.

## Test Plan

Run:

```text
docs/TEST-PLAN-0.3.12.md
```

Focus especially on admin-side **Email Review Link** delivery to Mailpit and whether packet sent metadata/status changes only when a review-link email is actually accepted through the non-intercepted WordPress mail path.

## 🚨 Codex Repair / Versioning Protocol

If Codex makes any code repair during testing, no matter how small, update all relevant version markers and packaging docs before returning a modified zip.

At minimum update:

1. Plugin header version.
2. `VMSA_VERSION`.
3. `vms-agreements-build.txt`.
4. `docs/CHANGELOG.md`.
5. Test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale versioning, stale build notes, or stale package naming.
