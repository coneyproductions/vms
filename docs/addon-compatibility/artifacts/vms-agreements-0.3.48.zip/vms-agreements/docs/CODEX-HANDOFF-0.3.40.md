# VMS Agreements 0.3.40 Codex Handoff

## Goal
Close the last material omission discovered during the Reputation agreement review: every new agreement must state **how final payment will be made**, not only when it is due.

## Implementation
- Agreement Setup now includes a required Final Payment section.
- Payment method options mirror the VMS Core compensation model: Check, Cash, ACH / Direct Deposit, Zelle, Venmo, PayPal, and Other.
- Selecting Other requires a manual description.
- Agreements writes directly to VMS Core's canonical Event Plan meta keys for `final_payment_method` and `final_payment_method_other`.
- Agreement generation is blocked with a specific readiness diagnostic until payment method is complete.
- The existing payment-summary renderer automatically places the selected method into the summary, formal Agreement Text, print/PDF output, and snapshot compensation hash.
- Event Plan's read-only Agreements metabox displays payment-method readiness.

## Compatibility
The 0.3.38+ Agreement Setup workflow is the editing surface. The legacy save compatibility path for an already-open 0.3.37 Event Plan editor intentionally does not supply payment fields; the shared update helper preserves any existing Core payment method when those keys are absent.

## Acceptance target
For the Reputation packet, Agreement Setup should show the 5-day timing plus a required payment method. After the operator selects the actual method and regenerates/supersedes, the new packet must visibly state that method before it is sent for acknowledgement.
