# VMS Agreements 0.3.20 Codex Handoff - Bonus Payout Table

## Why this patch exists

The prior 0.3.19 wording still depended on a sentence to explain the bonus structure. That was not clear enough because a threshold/start count of 100 with a 50-ticket step can be misread as earning a bonus at 100. The Event Plan preview table is clearer: it shows 100 as the base-only payout and 150 as the first bonus payout.

## What changed

- `includes/snapshots.php`
  - Adds helpers to build step-bonus payout rows from captured compensation terms.
  - Defaults the bonus count basis to paid ticket sales unless terms explicitly say otherwise.
  - Keeps the compensation summary short: `Bonus: see payout table below.` when table rows can be generated.
- `includes/template-blocks.php`
  - Adds a plain-text bonus payout schedule under Compensation Terms in Agreement Text Preview.
- `includes/admin.php`
  - Adds an HTML Bonus payout schedule table to the admin packet Compensation Snapshot.
- `includes/public.php`
  - Adds an HTML Bonus payout schedule table to the public/vendor Booking Summary.
- `assets/admin.css` and `assets/public.css`
  - Adds table spacing/visual polish.

## Main test case

Use `docs/TEST-PLAN-0.3.20.md`. The key case is:

- Base fee `$1,500.00`
- Start/threshold count `100`
- Step size `50`
- Step bonus `$250.00`
- Expected table:
  - 100 => `$1,500.00`
  - 150 => `$1,750.00`
  - 200 => `$2,000.00`
  - 250 => `$2,250.00`
  - 300 => `$2,500.00`
  - 350 => `$2,750.00`

The table header should say **Paid ticket sales** unless an explicit alternate count basis is stored in the Event Plan terms.

## Activation note

The 0.3.18 activation hotfix remains in place. Activation should stay light and should not create default templates directly inside the activation hook.

## Repair allowance

Codex may make small, directly-related code repairs when feasible during testing/troubleshooting. If code changes are made, update the VMS Agreements version/build number consistently across the plugin header, `VMSA_VERSION`, `vms-agreements-build.txt`, changelog/test docs, and package filename.
