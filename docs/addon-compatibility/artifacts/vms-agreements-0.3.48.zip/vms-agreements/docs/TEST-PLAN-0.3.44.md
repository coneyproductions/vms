# VMS Agreements 0.3.44 Test Plan

## HTML de-duplication
1. Open a current vendor Agreement Packet review page.
2. Confirm Event Details, Vendor Details, Compensation/Payment Terms, bonus schedule, Production Responsibilities, and Production Schedule appear once in Agreement Packet Summary.
3. Confirm the next card is titled **Agreement Terms** and begins with Agreement Packet Scope followed by formal clauses rather than repeating generated summary fields.

## Cancellation readability
1. Regenerate a packet from the untouched stock template.
2. Confirm **Weather / Safety Cancellation** explicitly names rain, lightning, severe thunderstorms, high winds, flooding, and extreme heat.
3. Confirm the ~72-hour planning goal and 24-hour payment cutoff remain unchanged.
4. Confirm the payment outcomes render as an easy-to-scan list.
5. Confirm **Low Ticket Sales / Event Viability Cancellation** clearly shows 7+ days = no base guarantee, less than 7 days = 50%, and arrived/ready = 100%.

## Performance-issue tone
1. Confirm the stock heading is **Vendor Cancellation / Performance Issues** with no “No-Show” heading language.
2. Confirm the clause still protects real safety concerns and does not require work during rain on the uncovered stage or another immediate unsafe condition.
3. Confirm unapproved cancellation, failure to appear, material lateness, refusal, early departure, and materially incomplete service remain covered without an automatic flat penalty.

## Physical signatures
1. Open Print / Save as PDF for an unacknowledged packet.
2. Confirm Vendor and Venue identity blocks reserve equal height.
3. Confirm Signature, Printed name, Title/capacity, and Date lines begin at matching vertical positions in both columns.

## Migration / regression
- Untouched stock 0.3.42/0.3.43 bodies and titles upgrade to 0.3.44 wording.
- A deliberately customized clause body/title is preserved.
- Compensation rules, payment method, production schedule, phone formatting, packet hashing, and acknowledgement evidence remain unchanged.
- All plugin PHP files pass `php -l`; release ZIP passes `unzip -t`.
