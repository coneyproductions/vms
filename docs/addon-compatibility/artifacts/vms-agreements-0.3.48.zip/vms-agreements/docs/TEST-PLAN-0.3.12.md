# VMS Agreements 0.3.12 Test Plan - Review Email Delivery Verification

## Build Under Test

- VMS Core: `0.2.24.570+`
- VMS Agreements: `0.3.12-review-email-delivery-verification`
- Plugin folder must remain: `vms-agreements`

## 🚨 Codex Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small, Codex must update all relevant version markers and packaging docs in the same pass before returning a repaired zip.

At minimum, update:

1. Plugin header version.
2. Version constants.
3. Build file.
4. Changelog/build notes.
5. Test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale version numbers or stale build notes.

## 1. Install / Build Metadata

1. Install/replace VMS Core `0.2.24.570+`.
2. Install/replace VMS Agreements `0.3.12`.
3. Confirm the installed folder is exactly `vms-agreements`.
4. Confirm the plugin header reports `0.3.12`.
5. Confirm `VMSA_VERSION` reports `0.3.12`.
6. Confirm `vms-agreements-build.txt` contains:

```text
0.3.12
review-email-delivery-verification
```

## 2. PHP Lint

Run PHP lint against all plugin PHP files:

```bash
find wp-content/plugins/vms-agreements -name '*.php' -print0 | xargs -0 -n1 php -l
```

Expected: no syntax errors.

## 3. Generate a Current Packet

1. Create or use an upcoming Event Plan with a primary vendor.
2. Ensure the vendor snapshot has a valid email address.
3. Generate a fresh agreement packet.
4. Confirm the packet opens in the admin packet viewer.
5. Confirm the packet starts as `Generated` unless a prior email/view action already changed it.

## 4. Admin Email Review Link - Successful Delivery

1. Open the admin packet viewer for the current packet.
2. Use **Email Review Link to Vendor**.
3. Confirm the admin notice reports that the review email was sent.
4. Confirm Mailpit receives a new review-link email.
5. Confirm the email includes the secure review URL.
6. If Mailpit exposes headers, confirm the email includes:
   - `X-VMSA-Email-Type: review_link_email`
   - `X-VMSA-Packet-ID: [packet id]`
7. Confirm the packet audit trail includes a `Vendor review link email` record marked sent.
8. Confirm the email audit record includes diagnostic fields:
   - `wp_mail_return`
   - `wp_mail_succeeded_action`
   - `pre_wp_mail_short_circuit`
   - `wp_mail_failed`
   - `wp_mail_failed_code`
9. Confirm packet sent metadata updated only after the successful send:
   - `_vmsa_review_email_sent_at`
   - `_vmsa_review_email_sent_to`
   - `_vmsa_review_email_sent_by`
   - `_vmsa_review_email_send_count`
10. If packet status was `generated`, confirm it advances to `sent` only after the successful send.

## 5. Review Link Open Path Regression

1. Open the review URL from the received email.
2. Confirm the public review page renders.
3. Confirm packet view tracking updates:
   - `_vmsa_first_viewed_at`
   - `_vmsa_last_viewed_at`
   - `_vmsa_view_count`
4. Confirm packet status moves from `sent` to `viewed` when applicable.

## 6. Failure / Intercept Path

If practical, add a temporary local-only test filter that short-circuits `pre_wp_mail` during a review-link send, then remove it immediately after the test.

Expected when the review-link send is intercepted or fails:

1. Admin notice reports the review email could not be sent.
2. Mailpit does not receive the review-link email.
3. Packet status does not advance from `generated` to `sent`.
4. `_vmsa_review_email_send_count` does not increase.
5. `_vmsa_review_email_sent_at`, `_vmsa_review_email_sent_to`, and `_vmsa_review_email_sent_by` are not updated for that failed/intercepted send.
6. `_vmsa_review_email_last_error` is stored.
7. The admin packet viewer shows the last email error in the Email Review Link box.
8. The audit trail records a failed `Vendor review link email` entry with diagnostic details.

Remove the temporary mail-intercept filter before continuing.

## 7. Acknowledgement Confirmation Regression

1. Open the packet public review URL.
2. Complete the acknowledgement form with signer name/email.
3. Submit acknowledgement.
4. Confirm the packet status becomes `acknowledged`.
5. Confirm acknowledgement proof renders publicly and in the admin packet viewer.
6. Confirm Mailpit receives the acknowledgement confirmation email.
7. Confirm this behavior is unchanged from 0.3.11.

## 8. Vendor Portal Regression

1. Log in as or preview the linked vendor.
2. Confirm the Agreements tab appears when the vendor has packets.
3. Confirm the current/actionable packet appears expanded.
4. Confirm superseded/voided packets remain in collapsed Agreement History.
5. Confirm Review Agreement and Print / Save PDF buttons still use the secure tokenized URLs.
6. Confirm vendors with no packets do not see unnecessary Agreements clutter.

## 9. Public / Print Route Regression

1. Open the public review route for a current packet.
2. Open the print route for the same packet.
3. Confirm no fatal errors.
4. Confirm inactive/superseded tokenized links still return the expected unavailable/403 behavior.
5. Confirm print view still uses the standalone print shell and does not leak site footer/gallery content.

## Out of Scope

- Operator-facing agreement queue.
- Automated reminders.
- Server-side PDF generation.
- Clause bypass UI.
- Rider uploads.
- Hard-delete cleanup for test packets.
