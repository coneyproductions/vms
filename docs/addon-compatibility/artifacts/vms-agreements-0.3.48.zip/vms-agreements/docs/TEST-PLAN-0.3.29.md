# VMS Agreements 0.3.29 Test Plan — Raw Title Current-State + Vendor Portal Selection Fix

## Scope

This patch fixes two specific failures:

- the same packet can show **Current** in admin but stale on the public/vendor review page because current-state comparison used request-filtered titles
- vendor portal can keep treating an older stale packet as the primary actionable card when a newer current packet exists

## What changed

- Agreements now reads raw `post_title` values, decodes stored entities, and runs mojibake cleanup before packet title generation, snapshot storage, and terms-hash calculation.
- Vendor portal now promotes only the latest current packet per Event Plan into the primary list/counts/CTA and moves superseded, voided, and outdated packets into history.

## Manual test steps

1. Install and activate `vms-agreements-0.3.29-raw-title-current-state-and-vendor-portal-selection-fix.zip`.
2. Confirm version markers:
   - plugin header `0.3.29`
   - `VMSA_VERSION` `0.3.29`
   - `vms-agreements-build.txt` slug `raw-title-current-state-and-vendor-portal-selection-fix`
3. Open one known current packet on the admin Agreements screen.
4. Open **Agreement Current-State Diagnostics** and confirm:
   - Stored hash matches packet: Yes
   - Packet matches current Event Plan: Yes
5. Click **Open Vendor Review** for that exact packet ID.
6. Confirm the public review page for the same packet does not show the stale warning and the signer section is enabled when the packet is still unsigned.
7. Use a known punctuation-heavy Event Plan title such as `My Kinda Party – A Jason Aldean tribute`.
8. Generate one fresh packet only if needed for verification.
9. Confirm the new packet title/snapshot/admin preview/vendor review/print view do not show `â€`, `â€“`, `â€”`, stray `Â`, or entity fragments like `&#8211;`.
10. Open the vendor portal preview for the related vendor.
11. Confirm the primary agreement card and Action Needed CTA point to the latest current packet for that Event Plan.
12. Confirm stale/superseded/voided packets appear under history instead of the primary actionable card list.
13. Confirm a stale older packet is not counted as Needs review/Viewed in the primary header counts.
14. Confirm admin audit timestamps still display as WordPress-local human time rather than raw DB time.

## Regression checks

- Confirm stale packets remain blocked from acknowledgement.
- Confirm superseded and voided packets remain historical/inactive.
- Confirm manual vendor review emails still send only when the operator clicks the email action.
- Confirm print/PDF still opens from a current packet review link.
- Confirm existing acknowledgement records remain attached to their original packet history.

## Codex note

If production still reports a same-packet admin/public mismatch after this build, capture the exact packet ID from both screens first. The vendor portal issue and the title-filter hash mismatch are separate failure modes and can look similar when only the event title is compared by eye.
