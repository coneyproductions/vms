# VMS Agreements 0.3.38 Codex Handoff

## Goal
Move agreement-specific identity and production editing from the Event Plan editor into VMS Agreements and remove the unsaved-navigation trap.

## Changes
- Adds a dedicated Agreement Setup view addressed by `vmsa_setup_event_plan`.
- Adds `admin_post_vmsa_save_event_plan_agreement_setup` for independent agreement-term persistence.
- Keeps `_vmsa_vendor_*` and `_vmsa_production_*` metadata on the Event Plan so existing snapshot/current-stale logic remains intact.
- Event Plan metabox becomes read-only status/navigation and no longer asks the operator to edit agreement fields inside the WordPress post form.
- Agreement Setup offers save-aware View and Generate/Regenerate actions.
- Main Agreements Generate card now opens setup instead of directly generating only fully-ready plans.

## Regression expectations
- Existing 0.3.37 saved identity/production metadata must load unchanged in Agreement Setup.
- Existing packets remain immutable snapshots.
- Current/stale hash behavior is unchanged.
- Direct generation guardrails still enforce legal identity, representative, production confirmation, contracting entity, date/status, and primary vendor.
