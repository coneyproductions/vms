# Codex Handoff - VMS Agreements 0.3.17

## Build

- Plugin: `vms-agreements`
- Version: `0.3.17`
- Build label: `boot-i18n-log-cleanup`
- Requires VMS Core: `0.2.24.612+`

## Purpose

This is a debug-log cleanup pass. It adds explicit textdomain loading and hardens the early Planning-nav / guided-tour registries so the Agreements add-on stops generating early `vms-agreements` translation notices during normal requests.

## What Changed

- Added `init` textdomain loading in `vms-agreements.php`.
- Replaced early nav/tour registry translations with runtime-safe labels that return raw English before `after_setup_theme`.
- Kept packet generation, queue behavior, vendor portal behavior, template editor behavior, and print behavior unchanged.

## Files Changed

- `vms-agreements.php`
- `includes/admin.php`
- `vms-agreements-build.txt`
- `docs/CHANGELOG.md`
- `docs/README.md`
- `docs/HANDOFF.md`
- `docs/TEST-PLAN-0.3.17.md`
- `docs/CODEX-HANDOFF-0.3.17.md`

## Required Test Plan

- `docs/TEST-PLAN-0.3.17.md`
