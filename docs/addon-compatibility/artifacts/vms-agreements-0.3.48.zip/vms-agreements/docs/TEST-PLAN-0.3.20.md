# VMS Agreements 0.3.20 Test Plan - Bonus Payout Table

## Purpose

Verify that the agreement packet no longer relies on a wordy bonus sentence and instead renders the step-bonus payout structure as a table similar to the Event Plan preview.

## Preconditions

- VMS Core is active and meets the VMS Agreements minimum version requirement.
- VMS Agreements 0.3.20 is installed as the only active `vms-agreements` plugin directory.
- Test with an Event Plan using Base + Attendance Bonus / step bonus terms:
  - Base fee: `$1,500.00`
  - Start/threshold count: `100`
  - Step size: `50`
  - Step bonus: `$250.00`
  - Count basis should be paid ticket sales unless explicitly configured otherwise.

## Activation smoke test

1. Deactivate and activate VMS Agreements 0.3.20.
2. Confirm there is no fatal error on activation.
3. Confirm `vms-agreements-build.txt` reports `0.3.20`.
4. Confirm the plugin header and `VMSA_VERSION` both report `0.3.20`.
5. Load Agreement Packets admin and confirm the page opens normally.

## Bonus payout table regression

1. Generate or open an agreement packet for the Event Plan described above.
2. In the packet admin view, confirm Compensation Snapshot shows a **Bonus payout schedule** table.
3. Confirm the table header uses **Paid ticket sales**, not generic attendance/attendees.
4. Confirm the table rows show this structure:

   | Paid ticket sales | Payout |
   | --- | --- |
   | 100 | $1,500.00 |
   | 150 | $1,750.00 |
   | 200 | $2,000.00 |
   | 250 | $2,250.00 |
   | 300 | $2,500.00 |
   | 350 | $2,750.00 |

5. Confirm the first bonus is clearly at 150 paid ticket sales and the 100 row remains the base-only payout.
6. Confirm the old misleading wording such as `starts at 100 attendees` does not appear in the generated packet text.
7. Open the vendor/public review link and confirm the Booking Summary displays the same bonus payout schedule table.
8. Open Print / Save as PDF mode and confirm the table remains visible and readable.
9. Confirm the Agreement Text Preview includes the same schedule as a plain-text table under Compensation Terms.

## Adjacent regression checks

1. Generate a flat-fee-only agreement packet and confirm no empty bonus table appears.
2. Generate or review a non-step compensation structure and confirm it still renders without errors.
3. Confirm deposit/advance summary and payment summary still render below the compensation terms.
4. Confirm an acknowledged packet still shows acknowledgement proof normally.

## Codex repair allowance

Codex may make small, directly-related code repairs when feasible during testing/troubleshooting. If code changes are made, update the VMS Agreements version/build number consistently across the plugin header, `VMSA_VERSION`, `vms-agreements-build.txt`, changelog/test docs, and package filename.
