# Codex Handoff — VMS Agreements 0.3.25

## Package

`vms-agreements-0.3.25-stale-hash-and-preview-mojibake-fix.zip`

## Goal

Fix two regressions observed after 0.3.24:

- Freshly regenerated packets can still appear stale in the vendor portal/admin.
- Admin Agreement Text Preview can still show residual mojibake such as `â€`.

## Key changes from 0.3.24

- Version bumped to 0.3.25 in:
  - `vms-agreements.php` plugin header
  - `VMSA_VERSION`
  - `vms-agreements-build.txt`
- `includes/snapshots.php`
  - Uses an Agreements-owned compensation hash based on `vms_get_event_plan_comp_terms()` output.
  - Adds canonical terms-hash helper functions.
  - Excludes volatile fields from canonical terms comparison, including edit URL, modified timestamp, generated packet IDs, and health-check wording.
  - Uses canonical hash comparison as a fallback in `vmsa_packet_current_terms_status()`.
- `includes/admin.php`
  - Applies `vmsa_display_text()` to the final Agreement Text Preview output.
- `includes/helpers.php`
  - Expands mojibake cleanup for truncated `â€` fragments with unusual whitespace/control-byte remnants.

## Test focus

1. Activation safety.
2. Admin Agreement Text Preview no longer shows residual mojibake.
3. Fresh packet regeneration clears the false stale warning.
4. Real Event Plan/agreement term changes still mark packets stale.
5. Another regeneration clears the stale warning.
6. 0.3.24 manual-send, vendor action flag, and operator signed-notification behavior remains intact.

## Repair allowance

During testing/troubleshooting, Codex may make small, directly related repairs when feasible. If any code is changed, update version/build markers, changelog/build notes, and test docs consistently before packaging.
