# Codex Handoff — VMS Agreements 0.3.29

## Package

`vms-agreements-0.3.29-raw-title-current-state-and-vendor-portal-selection-fix.zip`

## Goal

Fix the real current/stale mismatch source and stop the vendor portal from preferring stale/older packets when a newer current packet exists.

## Root cause

- Agreements was rebuilding current-state snapshots from `get_the_title()`, which is request-filtered. VMS Core decodes Event Plan title entities on wp-admin requests, but not on public/vendor-portal requests, so the exact same packet could hash as Current in admin and stale on the public side.
- Vendor portal primary-card logic treated every non-superseded/non-voided packet as current-list material, so an older stale packet could still count as actionable and remain visible ahead of the newer current packet.

## Key changes

- Version bumped to `0.3.29` in:
  - `vms-agreements.php` plugin header
  - `VMSA_VERSION`
  - `vms-agreements-build.txt`
- `includes/helpers.php` adds `vmsa_get_post_title_text()`:
  - reads raw `post_title`
  - double-decodes HTML entities when present
  - runs the existing mojibake cleanup before packet use
- Snapshot/title generation now uses that raw-title helper for:
  - packet titles
  - Event Plan snapshot title
  - venue snapshot title
  - vendor snapshot title
  - template display title
- `includes/vendor-portal.php` now:
  - partitions packets into latest current per Event Plan versus history
  - removes stale packets from primary counts and the Action Needed CTA
  - sends superseded, voided, and outdated packets into the history group

## Test focus

1. Confirm admin/public current-state parity on the exact same packet ID.
2. Confirm a fresh packet with a punctuation-heavy Event Plan title no longer stores mojibake or entity-fragment titles.
3. Confirm vendor portal primary cards/CTA point to the latest current packet, not a stale older packet.
4. Confirm stale/historical packets remain visible for recordkeeping but are no longer primary actionable cards.
5. Confirm timestamps still display in WordPress local time.

## Notes

- This pass does not rewrite old Event Plan titles in core VMS data.
- Existing acknowledgements/history are preserved.
- The local SQL snapshot available during this investigation did not contain the production packet IDs `5549`, `5555`, or `5558`, so the fix was derived from the live code path and the local dump's canonical packet data model rather than a direct production row read.
