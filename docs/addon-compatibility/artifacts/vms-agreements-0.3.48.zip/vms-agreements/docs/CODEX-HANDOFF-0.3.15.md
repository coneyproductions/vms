# Codex Handoff - VMS Agreements 0.3.15

## Build

- Plugin: `vms-agreements`
- Version: `0.3.15`
- Build label: `template-health-check-alignment`
- Requires VMS Core: `0.2.24.570+`

## Purpose

This is a narrow follow-up to the 0.3.14 language-polish pass. Codex found that the migrated stock template still warned: `Audit disclosure may be missing this concept: hash`. The default agreement language intentionally uses friendlier packet-verification wording, so the health check should accept that without forcing raw hash terminology into vendor-facing text.

## What Changed

- Updated the Audit Disclosure Template Health Check concept scan.
- Replaced the literal-only `hash` requirement with a packet-verification-record concept.
- Accepted phrases include:
  - `packet verification`
  - `verification record`
  - `verification records`
  - `packet id`
  - `terms hash`
  - `compensation hash`
  - `hash`
  - `recorded packet`
- Added a small helper for concept phrase matching.

## What Did Not Change

- No packet schema changes.
- No review-token validation changes.
- No acknowledgement submission changes.
- No review-link email delivery mechanics or diagnostics changes.
- No operator queue behavior changes.
- No vendor portal behavior changes.
- No public print layout changes.
- No default template body migration changes.
- No email template changes.

## Files Changed

- `vms-agreements.php`
- `includes/template-blocks.php`
- `vms-agreements-build.txt`
- `docs/CHANGELOG.md`
- `docs/HANDOFF.md`
- `docs/README.md`
- `docs/TEST-PLAN-0.3.15.md`
- `docs/CODEX-HANDOFF-0.3.15.md`

## Required Test Plan

Run:

- `docs/TEST-PLAN-0.3.15.md`

## 🚨 Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small, Codex must update all relevant version markers and packaging docs in the same pass before returning a repaired zip.

At minimum, update:

1. Plugin header version.
2. `VMSA_VERSION`.
3. `vms-agreements-build.txt`.
4. `docs/CHANGELOG.md`.
5. Relevant test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale version numbers or stale build notes.
