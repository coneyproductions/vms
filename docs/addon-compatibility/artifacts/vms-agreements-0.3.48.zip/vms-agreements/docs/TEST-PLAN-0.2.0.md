# VMS Agreements 0.2.0 Test Plan — Vendor Acknowledgement Foundation

## Scope

This build adds the first vendor-facing agreement review and acknowledgement flow.

## Preflight

- VMS Core `0.2.24.567` or newer is active.
- VMS Agreements `0.2.0` is active.
- At least one Event Plan has a primary vendor and compensation terms.
- A current agreement packet has been generated for the Event Plan.

## Admin Checks

1. Open **VMS → Planning → Agreements**.
2. Open a current agreement packet.
3. Confirm the **Vendor Review Link** card appears.
4. Confirm the review link input is selectable/copyable.
5. Click **Open Vendor Review** and confirm it opens the public review page in a new tab.
6. Click **Regenerate Link** and confirm the packet page reloads with the `review_token_regenerated` notice.
7. Confirm an older copied link no longer works after token regeneration.

## Public Review Checks

1. Open the current Vendor Review Link while logged out or in a private browser window.
2. Confirm the public page shows:
   - Event summary
   - Vendor details
   - Compensation terms
   - Deposit / advance terms
   - Agreement text
   - Required acknowledgement checkboxes
   - Signer name and signer email fields
3. Submit without checking all acknowledgements.
4. Confirm the page returns with a missing-required notice.
5. Complete signer fields and all acknowledgement checkboxes.
6. Submit the acknowledgement.
7. Confirm the page returns with a success notice and prints recorded acknowledgement details:
   - Signer name/email
   - Acknowledged date/time
   - IP address
   - Agreement version
   - Terms hash
   - Compensation hash
8. Refresh the public page and confirm the form is no longer shown after acknowledgement.

## Admin Audit Checks

1. Return to the packet viewer in wp-admin.
2. Confirm packet status changed to **Acknowledged**.
3. Confirm each acknowledgement line shows printed proof details instead of “Not yet acknowledged.”
4. Confirm Audit Trail shows:
   - First viewed timestamp
   - Last viewed timestamp
   - Review link view count
   - Signer name/email
   - IP address
   - User account or “Not logged in”
   - Agreement version
   - Terms hash
   - Compensation hash
   - Browser/user agent

## Guardrail Checks

1. Change a compensation or Event Plan term after packet generation but before acknowledgement.
2. Open the Vendor Review Link.
3. Confirm acknowledgement is blocked because the packet is stale.
4. Regenerate / Supersede the packet.
5. Confirm the old packet is preserved as Superseded.
6. Confirm the new current packet requires a fresh acknowledgement.
7. Void a packet and confirm the public review link no longer allows review.

## Notes

This build intentionally does not add email sending, PDFs, template editing, rider uploads, or clause bypass UI.
