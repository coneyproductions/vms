# VMS Agreements 0.3.2 Test Plan - Email Template + Confirmation Email Foundation

Codex / browser testing recommended before using with real vendor agreements.

## 1. Install / Replace

1. Upload and replace the existing `vms-agreements` plugin folder with this build.
2. Confirm WordPress shows VMS Agreements version `0.3.2`.
3. Confirm VMS Core `0.2.24.567+` is active.

## 2. Email Template Editor

1. Open VMS > Planning > Agreements.
2. In the Default Template card, click Edit Email Templates.
3. Confirm the Email Template Editor loads.
4. Confirm it shows:
   - Review Link Email subject/body
   - Acknowledgement Confirmation Email subject/body
   - Available Tokens panel
   - Email Template Health Check
5. Save without changes.
6. Confirm the success notice appears and the health check still passes.

## 3. Required Review Link Token Guardrail

1. Open Edit Email Templates.
2. Temporarily remove `{review_link}` from the Review Link Email body.
3. Save.
4. Confirm the health check reports an error requiring `{review_link}`.
5. Restore `{review_link}` and save again.
6. Confirm the health check passes.

## 4. Review Link Email Send

1. Open an active current packet with a vendor email address.
2. Enter a short optional note in Email Review Link.
3. Click Email Review Link to Vendor or Resend Review Link Email.
4. Confirm the admin notice says the email was sent.
5. Confirm the email received by the vendor includes:
   - customized subject/body
   - event name/date/time
   - compensation summary
   - deposit/advance summary
   - payment summary
   - optional operator note
   - secure review link
6. Confirm the Audit Trail records the vendor review link email send.

## 5. Review Email Health Blocks Send

1. Remove `{review_link}` from the Review Link Email body again and save.
2. Open a current packet.
3. Attempt to email the review link.
4. Confirm sending is blocked with an email template health notice.
5. Restore `{review_link}` and save before continuing.

## 6. Acknowledgement Confirmation Email

1. Open the vendor review link in a private/incognito window.
2. Complete all acknowledgement checkboxes and signer fields.
3. Submit the acknowledgement.
4. Confirm the vendor-facing page shows acknowledgement proof.
5. Confirm the signer receives the acknowledgement confirmation email.
6. Confirm the confirmation email includes:
   - event summary
   - payment summary
   - acknowledgement proof
   - review link
7. Return to the admin packet viewer.
8. Confirm the Audit Trail includes the acknowledgement confirmation email record.

## 7. Regression Checks

Confirm these still work:

- Packet generation guardrail: ordinary Generate opens existing current packet instead of duplicating it.
- Regenerate / Supersede still creates a fresh current packet requiring new acknowledgement.
- Stale packets cannot be emailed or acknowledged.
- Voided/superseded packets cannot be publicly reviewed.
- Acknowledged packets do not show a second public submit form.
- Existing agreement template block editor still saves and increments agreement template version.

## Notes

This build does not add automated reminders, PDF generation, vendor portal agreement cards, or clause bypass UI.
