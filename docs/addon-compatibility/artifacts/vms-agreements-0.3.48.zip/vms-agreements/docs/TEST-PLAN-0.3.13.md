# VMS Agreements 0.3.13 Test Plan - Operator Agreement Queue

## Build Under Test

- VMS Core: `0.2.24.570+`
- VMS Agreements: `0.3.13-operator-agreement-queue`
- Plugin folder must remain: `vms-agreements`

## 🚨 Codex Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small, Codex must update all relevant version markers and packaging docs in the same pass before returning a repaired zip.

At minimum, update:

1. Plugin header version.
2. Version constants.
3. Build file.
4. Changelog/build notes.
5. Test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale version numbers or stale build notes.

## 1. Install / Build Metadata

1. Install/replace VMS Core `0.2.24.570+`.
2. Install/replace VMS Agreements `0.3.13`.
3. Confirm the installed folder is exactly `vms-agreements`.
4. Confirm the plugin header reports `0.3.13`.
5. Confirm `VMSA_VERSION` reports `0.3.13`.
6. Confirm `vms-agreements-build.txt` contains:

```text
0.3.13
operator-agreement-queue
```

## 2. PHP Lint

Run PHP lint against all plugin PHP files:

```bash
find wp-content/plugins/vms-agreements -name '*.php' -print0 | xargs -0 -n1 php -l
```

Expected: no syntax errors.

## 3. Admin Queue Rendering

1. Open **VMS > Agreements**.
2. Confirm the new **Operator Agreement Queue** card appears above **Recent Packets**.
3. Confirm the queue renders without fatal errors when packets already exist.
4. Confirm the summary count pills appear for:
   - Stale
   - Generated
   - Sent
   - Viewed
   - Acknowledged
   - History
5. Confirm **Recent Packets** still renders below the queue.

## 4. Queue Bucket Classification

Create or use packet fixtures covering these states:

1. `generated` current packet.
2. `sent` current packet.
3. `viewed` current packet.
4. `acknowledged` current packet.
5. `superseded` packet.
6. `voided` packet, if practical.
7. Stale packet where the Event Plan changed after packet generation.

Expected:

- Stale active packets appear under **Stale / Needs Regeneration**.
- `generated` current packets appear under **Generated - Not Sent**.
- `sent` current packets appear under **Sent - Not Viewed**.
- `viewed` current packets appear under **Viewed - Not Acknowledged**.
- `acknowledged` packets appear under **Acknowledged**.
- `superseded` and `voided` packets appear under **Superseded / Voided History**.

## 5. Queue Default Expansion Behavior

1. Confirm Stale, Generated, Sent, and Viewed sections open by default when they contain rows.
2. Confirm Acknowledged and Superseded / Voided History sections are collapsed by default when they contain rows.
3. Confirm the empty-state message appears when no active follow-ups need attention.

## 6. Queue Row Content

For each visible row, confirm the queue shows readable values for:

- Packet title/link.
- Event name and event date.
- Vendor name and vendor email where available.
- Packet status pill.
- Terms status pill.
- Last activity such as generated, sent, viewed, acknowledged, superseded, or voided date.
- Clean pay wording such as `Flat fee: $600.00`, not dirty `Flat fee; Base/flat` wording.

## 7. Queue Actions

For active/current rows, confirm the action buttons behave correctly:

1. **Open Packet** opens the admin packet viewer.
2. **Event Plan** opens the linked Event Plan editor when an Event Plan is available.
3. **Email Review** appears for eligible generated/current packets with a vendor email.
4. **Resend Email** appears for eligible sent/viewed packets after at least one successful send.
5. **Print / PDF** opens the secure tokenized print route for active packets.
6. Historical rows show as historical-only and do not expose active email actions.
7. Stale rows do not expose email actions and tell the operator to open the packet to regenerate safely.

## 8. Queue Email Action Regression

1. From the queue, click **Email Review** on an eligible generated packet.
2. Confirm the existing admin-post handler sends the review-link email.
3. Confirm Mailpit receives the email.
4. Confirm the packet status advances `generated -> sent` only after successful delivery.
5. Confirm the packet moves from **Generated - Not Sent** to **Sent - Not Viewed** after refresh.
6. Confirm the queue email action does not bypass the 0.3.12 delivery diagnostics or failure guardrails.

## 9. Existing Workflow Regressions

Confirm unchanged behavior for:

1. Admin packet viewer rendering.
2. Admin Email Review Link card with optional note.
3. Public review link open path.
4. Public acknowledgement form.
5. Acknowledgement confirmation email.
6. Public/print route using the standalone print shell.
7. Vendor portal Agreements tab and collapsed Agreement History.
8. Fallback shortcode `[vmsa_vendor_agreements]`.

## Out of Scope

- Automated reminders.
- Server-side PDF generation.
- Clause bypass UI.
- Rider uploads.
- Hard-delete cleanup for test packets.
- New packet schema fields.
