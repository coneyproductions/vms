# VMS Agreements 0.3.47 Test Plan

## Dependency matrix

1. Load with public Backstage Venue Manager 1.2.0 (`BVMGR_VERSION`) and confirm `vmsa_core_is_loaded()` and `vmsa_core_version_ok()` both pass.
2. Load with a supported legacy VMS version (`VMS_VERSION`) and confirm both checks pass.
3. Load with no supported core identity and confirm both checks fail closed.
4. Load with an older core version and confirm the version gate fails.

## Production workflow

1. Confirm the false “installed but inactive” notice is absent.
2. Open Backstage Venue Manager → Planning → Agreements and an Event Plan Agreement Packet metabox.
3. Confirm existing templates and all historical packets remain visible with unchanged status counts.
4. Generate a safe test packet with outbound email suppressed, open its tokenized recipient view, and verify the packet contents render.
5. Submit a safe acknowledgement and confirm the accepted state persists and appears in the operator and vendor-facing status surfaces.
6. Confirm the nonce/capability guards still reject invalid or unauthorized management requests.
7. Check PHP/WordPress logs after the workflow.

## Release

- Run PHP lint across every plugin PHP file.
- Run the focused BVM identity regression.
- Validate the release ZIP with `unzip -t`.
