# VMS Agreements 0.3.48 Test Plan

## Automated routing regression

Run `php tests/vendor-portal-routing-regression.php` with BVM 1.2.0 source available at the normal sibling path or through `BVM_PORTAL_SOURCE`.

The test must confirm:

- Dashboard, Profile, Tax Profile, Availability, Tech Docs, Guest List, Agreements, and the existing auxiliary portal slugs remain allowlisted.
- Direct `tab=agreements` and the normal Agreements link both resolve to Agreements.
- Agreements receives active styling while Dashboard is not selected.
- A pending packet produces the expected badge count.
- One-agreement, no-agreement, and acknowledged packet/action surfaces render.
- Packet queries stay limited to the authorized vendor IDs passed by BVM.
- Invalid tab values still fall back to Dashboard.
- The BVM source retains the Add a Business navigation path.

## Compatibility and release

1. Run all four `tests/bvm-public-runtime-compatibility.php` scenarios.
2. Run PHP lint across every plugin PHP file.
3. Build `vms-agreements-0.3.48-vendor-portal-routing-registration.zip` with a single `vms-agreements/` root.
4. Run `unzip -t` and compare the extracted package with the candidate source tree.

## Production acceptance

1. Back up the installed production `vms-agreements` directory outside the web root.
2. Confirm production BVM and Agreements versions before deployment.
3. Deploy only the Agreements package.
4. Open `/vendor-portal/?tab=agreements&vendor_id=5505` without submitting any form or action.
5. Confirm Agreements is active, Dashboard is inactive, the badge remains accurate, and the existing Reputation agreement plus its review/print or acknowledged actions render.
6. Confirm Dashboard and another ordinary portal tab still work.
7. Confirm a vendor without packets sees **No agreements yet** if a safe account/context is available.
8. Check narrow/mobile layout and production logs.
9. Do not acknowledge, sign, regenerate, reassign, delete, or otherwise mutate any real agreement during smoke testing.
