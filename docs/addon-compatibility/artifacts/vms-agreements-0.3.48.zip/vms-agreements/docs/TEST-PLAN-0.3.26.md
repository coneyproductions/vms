# VMS Agreements 0.3.26 Test Plan — Cache / Timezone / Stale / Mojibake Hardening

## Scope

This patch addresses three production-observed issues after 0.3.25: regenerated packets could still show stale on the vendor dashboard, generated times displayed in the wrong timezone, and truncated mojibake fragments such as `â€` could still appear in admin packet titles / Agreement Text Preview.

## Manual test steps

1. Install and activate `vms-agreements-0.3.26-cache-timezone-stale-and-mojibake-hardening.zip`.
2. Clear the site/page cache after installation.
3. Confirm plugin version/build reports `0.3.26`.
4. Open the problem Event Plan and regenerate the current agreement packet.
5. Confirm the admin packet header no longer shows `â€` or other mojibake fragments in the event/title line.
6. Confirm the admin **Agreement Text Preview** no longer shows `â€` fragments.
7. Confirm the packet admin header shows **Current** immediately after regeneration.
8. Open the vendor portal preview for the same vendor, preferably with a cache-busting query parameter such as `&vmsa_nocache=1` if available or after clearing cache.
9. Confirm the vendor agreement card no longer shows **Event Plan terms changed since packet generation** immediately after regeneration.
10. Confirm the vendor portal still shows the **Action Needed** banner and review-needed badge for an unsigned current agreement.
11. Confirm the generated/history timestamp now matches the WordPress site timezone / expected local time.
12. Send the vendor review email manually and confirm the **Not yet sent** message is replaced by sent details.
13. Acknowledge the packet and confirm the signer confirmation email and operator signed-notification email still work.

## Regression checks

- Confirm 0.3.24 manual-send behavior remains: generation does not auto-email the vendor.
- Confirm 0.3.24 vendor Action Needed banner and Agreements tab badge still show for unsigned agreements.
- Confirm 0.3.24 operator/admin signed-notification email still logs in the email audit trail after acknowledgement.
- Confirm 0.3.22 compact print/PDF summary + bonus table still renders correctly.

## Codex note

Codex may make small, directly related repairs if testing reveals a regression. If code changes are made, update the VMS Agreements version/build markers, changelog/build notes, and packaged filename consistently before returning the zip.
