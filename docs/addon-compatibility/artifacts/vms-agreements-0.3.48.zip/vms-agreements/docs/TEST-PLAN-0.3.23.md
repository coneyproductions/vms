# VMS Agreements 0.3.23 Test Plan — Mojibake Display Cleanup

## Scope

This patch cleans up residual mojibake / encoding artifacts in agreement packet display surfaces without changing stored packet snapshot hashes. The visible target is agreement text such as `My Kinda Party â€ A Jason Aldean tribute` rendering as normal punctuation instead of `â€` fragments.

## What changed

- Adds display-only cleanup for common mojibake punctuation artifacts.
- Applies cleanup to admin packet headers/cards, packet tables, operator queue rows, public/vendor review pages, standalone Print / Save PDF copy, agreement text preview, vendor portal agreement cards, acknowledgement labels/proof, and email template token rendering.
- Updates packet title comparison/normalization so an event title with mojibake punctuation can still match a correctly encoded vendor title and avoid a duplicate `Event - Vendor` title when they are really the same name.
- Keeps stored packet snapshots and existing packet hashes intact.

## Manual test steps

1. Install and activate `vms-agreements-0.3.23-mojibake-display-cleanup.zip`.
2. Confirm activation does not fatal-error.
3. Open an existing generated agreement packet that previously showed funky characters in the title or summary, such as `â€`, `â€“`, `â€”`, `â€™`, or stray `Â`.
4. Confirm the admin packet header no longer shows the funky characters.
5. Confirm the header does not duplicate the event/vendor name when the only difference is mojibake punctuation.
6. Confirm the Event, Vendor / Venue, Compensation Snapshot, Acknowledgements, and Agreement Text Preview cards do not show the funky characters.
7. Open **Open Vendor Review** and confirm the public review page is clean.
8. Open **Print / Save PDF** and confirm the standalone print copy is clean and the 0.3.22 compact one-page-oriented layout is preserved.
9. Send or preview a vendor review email if safe, and confirm the subject/body render normal punctuation for event/vendor/payment tokens.
10. If the packet was current before installing this patch, confirm it is still treated as current and not made stale solely by the display cleanup.

## Regression checks

- Confirm 0.3.18 activation safety remains intact.
- Confirm base-plus-bonus agreements still show the Bonus payout schedule table in admin, public review, and print/PDF views.
- Confirm no raw `â€`, `â€“`, `â€”`, `â€™`, `â€œ`, `â€�`, `â€¦`, or stray `Â` fragments remain on the tested agreement surfaces.

## Codex note

Codex may make small, directly related repairs if testing reveals a regression. If code changes are made, update the VMS Agreements version/build markers, changelog/build notes, and packaged filename consistently before returning the zip.
