# VMS Agreements 0.3.36 Test Plan

## Static / package

1. PHP lint all plugin PHP files.
2. Confirm runtime/build version markers are 0.3.36.
3. Confirm the 0.3.34 agreement-language defaults version remains unchanged because this release does not change contract clauses.

## Reputation print-layout acceptance fixture

Use the September 12, 2026 Reputation packet with the $1,500 base and 100/150/200/250/300/350 paid-ticket payout schedule.

1. Open the printable Agreement Copy.
2. Confirm Event Details and Vendor Details are two readable side-by-side cards.
3. Confirm Compensation Terms is a full-width card below those two cards.
4. Confirm Contracting party, Compensation terms, Deposit / Advance Terms, and Payment summary labels do not overlap their values.
5. Confirm the Bonus Payout Schedule places the payout table at left and qualifying paid-ticket explanation at right on print/wide layouts.
6. Confirm mobile/narrow layouts stack those regions into one column.
7. Print / Save as PDF and confirm Agreement Terms begin on page 1 when space permits instead of forcing the complete terms panel onto page 2.
8. Confirm no individual clause is split unnecessarily across a page break.
9. Confirm unacknowledged print copy says acknowledgement proof appears after the Vendor submits their acknowledgement.

## Regression

1. Confirm public review still shows the same packet facts and clauses.
2. Confirm bonus values and qualifying-ticket wording are unchanged.
3. Confirm packet hashes/current-state diagnostics do not change solely because of the CSS/markup layout update.
4. Confirm acknowledgement, resend, supersede, void, and readiness-diagnostic workflows remain unchanged.
