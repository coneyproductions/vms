# VMS Agreements 0.3.24 Test Plan — Agreement Action Flags + Signed Notifications

## Scope

This patch improves agreement follow-up visibility and notification flow. Generated packets should remain manual-send only, clearly show as **not yet sent** until the operator emails the vendor, surface unsigned agreements more prominently in the vendor portal, and notify the operator/admin when the vendor acknowledges the packet.

## What changed

- Adds a clear **Not yet sent** notice in the admin packet email/send area when a packet has been generated but the review-link email has not been sent yet.
- Adds a badge/count on the vendor portal **Agreements** tab when one or more current agreements still need review.
- Adds a more prominent vendor-portal **Action Needed** banner when agreements are waiting for review/acknowledgement.
- Adds an operator/admin signed-notification email when the vendor acknowledges the agreement packet.
- Adds a third email template block to the Email Template Editor for the operator signed-notification email.

## Manual test steps

1. Install and activate `vms-agreements-0.3.24-agreement-flags-and-signed-notifications.zip`.
2. Confirm activation does not fatal-error.
3. Generate a fresh agreement packet for a vendor/event and do **not** send the review email yet.
4. Open the packet admin screen and confirm the Email Review Link card shows a clear **Not yet sent** / generated-not-emailed state.
5. Confirm no auto-email was sent merely from generating the packet.
6. Open the vendor portal/dashboard for that vendor. Confirm the **Agreements** tab shows a badge/count when the agreement still needs attention.
7. Confirm the vendor portal shows a prominent agreement **Action Needed** banner and the agreement card still shows a review-needed state.
8. From the admin packet screen, send the vendor review-link email manually. Confirm the packet records the send, the status remains appropriate, and the **Not yet sent** message is replaced by sent details.
9. Open the vendor review link and acknowledge the agreement as the vendor.
10. Confirm the signer still receives the normal acknowledgement confirmation email.
11. Confirm the operator/admin recipient receives the new signed-notification email.
12. Confirm the packet email audit trail shows both email records:
    - vendor acknowledgement confirmation email
    - operator signed notification email
13. Open **Agreements → Email Templates** and confirm there are now three editable templates:
    - Review Link Email
    - Acknowledgement Confirmation Email
    - Operator Signed Notification Email
14. Confirm the new operator notification template supports the expected tokens and that its default body includes the packet admin link.

## Regression checks

- Confirm 0.3.23 mojibake cleanup remains intact on packet/admin/vendor-facing agreement surfaces.
- Confirm Print / Save PDF still works.
- Confirm the packet review link still opens and acknowledges normally.
- Confirm previously acknowledged packets remain acknowledged and do not regress back to a pending state.

## Codex note

Codex may make small, directly related repairs if testing reveals a regression. If code changes are made, update the VMS Agreements version/build markers, changelog/build notes, and packaged filename consistently before returning the zip.
