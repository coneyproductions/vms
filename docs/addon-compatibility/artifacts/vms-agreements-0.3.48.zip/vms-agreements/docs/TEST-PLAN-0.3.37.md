# VMS Agreements 0.3.37 Test Plan

## Static / package

1. PHP lint all plugin PHP files.
2. Confirm runtime/build version markers are 0.3.37.
3. Confirm stock agreement-language defaults migration advances to 0.3.37 while preserving customized editable clauses.

## Vendor identity

1. Use a Vendor with `_vms_payee_legal_name` and `_vms_contact_name`; open an Event Plan and confirm both fields prefill in the Agreement Packet metabox.
2. Remove payee legal name and confirm legal name falls back to Contact Person.
3. Manually replace legal name and representative, save the Event Plan, reload, and confirm the Event Plan values persist.
4. Generate a packet and confirm Vendor Details shows Vendor / act, Legal contracting name, Representative / contact, email, and phone.
5. Confirm Agreement Packet Scope names the legal Vendor party and representative/contact.
6. Confirm changing either saved identity value after generation makes the current packet stale.

## Production responsibilities

1. Leave one or more production answers blank and confirm packet generation is blocked with the Production Responsibilities diagnostic.
2. Answer Stage, House Sound / PA, Stage Lighting, and Sound Engineer Yes/No but leave confirmation unchecked; confirm generation remains blocked.
3. Confirm all four answers and the booking confirmation, save, and verify Generate Packet becomes available.
4. Generate a packet and confirm the four responsibilities appear in public review, print summary, and Agreement Text.
5. Change a production answer after generation and confirm the packet becomes stale.

## Signer

1. Open a current vendor review link and confirm Signer name prefills from Representative / contact and Signer email prefills from Vendor email.
2. Confirm both signer fields remain editable.
3. Submit with a different signer name and confirm the acknowledgement record stores the actual submitted signer separately from the packet Vendor representative.

## Reputation acceptance fixture

For September 12, 2026 Reputation, verify legal Vendor party/representative are the intended person/entity and set Stage, House Sound / PA, Stage Lighting, and Sound Engineer to the actual booking answers. Regenerate, print, and visually verify no summary overlap.
