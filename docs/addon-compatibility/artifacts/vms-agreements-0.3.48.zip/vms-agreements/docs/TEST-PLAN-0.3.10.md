# TEST PLAN - VMS Agreements 0.3.10 Vendor Portal Core Hook Integration

🚨 **Codex / live-site testing is required before treating 0.3.10 as validated.**

This pass completes the native Vendor Portal Pending Agreements integration. It does not change packet generation, packet snapshots, public review tokens, acknowledgement submission, email templates, print rendering, or regeneration guardrails.

## Required Pairing

1. Install VMS Core `0.2.24.569` or newer.
2. Install VMS Agreements `0.3.10` over the existing `vms-agreements` folder.
3. Confirm WordPress shows VMS Agreements version `0.3.10`.
4. Confirm `vms-agreements/vms-agreements-build.txt` reads:
   - `0.3.10`
   - `vendor-portal-core-hook-integration`

## Syntax / Smoke Checks

1. Run PHP lint on all VMS Agreements PHP files.
2. Activate VMS Agreements.
3. Confirm no fatal errors on:
   - VMS > Agreements
   - Admin packet viewer
   - Public vendor review link
   - Public print / save-as-PDF link
   - Public page containing `[vms_vendor_portal]`

## Native Vendor Portal Checks

Use a logged-in user linked to a VMS vendor profile with at least one agreement packet.

1. Open the native vendor portal dashboard.
2. Confirm a Pending Agreements / Agreements section appears automatically after the dashboard cards.
3. Confirm the native portal nav includes **Agreements**.
4. Click **Agreements**.
5. Confirm the tab renders agreement history without requiring the `[vmsa_vendor_agreements]` shortcode.
6. Confirm the tab URL uses `tab=agreements` and preserves the active vendor ID where applicable.

## Empty Vendor Checks

Use a linked vendor profile with no agreement packets.

1. Confirm the dashboard does not show a noisy empty Agreements card.
2. Confirm the Agreements nav tab is hidden when there are no packets.
3. Confirm manually visiting `tab=agreements` still shows a friendly empty-state message rather than an error.

## Admin Preview Checks

1. Use VMS vendor portal admin preview mode for a vendor with packets.
2. Confirm the Agreements nav tab appears.
3. Confirm the dashboard Agreements card appears.
4. Confirm the packet list uses the previewed vendor from Core portal context, not the logged-in admin's vendor associations.

## Status / Action Checks

Create or reuse agreement packets for the same vendor in these statuses:

1. `generated`
2. `sent`
3. `viewed`
4. `acknowledged`
5. `superseded`
6. `voided`

Expected:

- `generated` and `sent` display as **Needs Review**.
- `viewed` displays as **Viewed**.
- `acknowledged` displays as **Acknowledged**.
- `superseded` displays as **Superseded**.
- `voided` displays as **Voided**.
- Header counts show Needs Review, Viewed, and Acknowledged totals.
- Active packets expose **Review Agreement** and **Print / Save PDF** buttons.
- Superseded/voided packets remain historical-only.

## Token / Email Regression Checks

1. Send a review-link email from the admin packet viewer.
2. Confirm the emailed link still works.
3. Confirm the portal **Review Agreement** button opens the same tokenized public review flow.
4. Confirm opening the review page still records viewed metadata for eligible packets.
5. Submit an acknowledgement and confirm the acknowledgement confirmation email still sends.
6. Confirm public print view still avoids site header/footer/gallery leakage.

## Shortcode Fallback Check

1. Place `[vmsa_vendor_agreements]` on a private test page while logged in as a linked vendor.
2. Confirm the shortcode still renders packet history.
3. Confirm shortcode behavior is additive fallback only; the native portal should work without relying on this shortcode.
