# VMS Agreements 0.3.45 Codex Handoff

## Goal
Fix the final Vendor Details label/value collision in the HTML print-copy preview without shrinking typography or changing agreement content.

## Changes
- Gives the Vendor Details card a wider label column in `.vmsa-print-mode` so **Representative / contact** and other long labels cannot overlap their values.
- Adds safe label wrapping via `overflow-wrap: anywhere`.
- Uses a compact print-media width so the two-column summary remains readable in PDF/physical print.

## Compatibility
- Presentation-only change.
- Existing packets do not require regeneration.
- No packet snapshot, terms hash, compensation hash, acknowledgement, or contract-language changes.
