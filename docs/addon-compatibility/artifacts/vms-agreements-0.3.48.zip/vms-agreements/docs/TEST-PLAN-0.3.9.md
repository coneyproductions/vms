# TEST PLAN - VMS Agreements 0.3.9 Vendor Portal Pending Agreements

🚨 **Codex / live-site testing is required before treating 0.3.9 as validated.**

This pass adds vendor-facing portal agreement visibility. It does not change packet generation, review tokens, acknowledgement submission, email templates, packet snapshots, print rendering, or regeneration guardrails.

## Install / Version Checks

1. Install `vms-agreements-0.3.9-vendor-portal-pending-agreements.zip` over the existing `vms-agreements` folder.
2. Confirm WordPress shows VMS Agreements version `0.3.9`.
3. Confirm `vms-agreements/vms-agreements-build.txt` reads:
   - `0.3.9`
   - `vendor-portal-pending-agreements`
4. Confirm VMS Core remains `0.2.24.568` or newer.

## Syntax / Smoke Checks

1. Run PHP lint on all plugin PHP files.
2. Activate VMS Agreements.
3. Confirm no fatal errors on:
   - VMS > Agreements
   - Admin packet viewer
   - Public vendor review link
   - Public print / save-as-PDF link

## Vendor Portal Display Checks

Use a logged-in user linked to a VMS vendor profile.

1. Add the shortcode `[vmsa_vendor_agreements]` to a test vendor portal page, or trigger the portal hook `vms_vendor_portal_after_dashboard_cards` if VMS Core exposes that dashboard area.
2. Confirm the agreement card renders for the logged-in linked vendor.
3. Confirm a user with no linked vendor profile sees a friendly empty/linking message and does not see other vendors' packets.
4. Confirm a linked vendor sees only packets where `_vmsa_vendor_id` matches their vendor profile.

## Status Checks

Create or reuse agreement packets for the same vendor in these statuses:

1. `generated`
2. `sent`
3. `viewed`
4. `acknowledged`
5. `superseded`
6. `voided`

Expected:

- `generated` and `sent` display as **Needs Review**.
- `viewed` displays as **Viewed**.
- `acknowledged` displays as **Acknowledged**.
- `superseded` displays as **Superseded**.
- `voided` displays as **Voided**.
- Header counts show Needs Review, Viewed, and Acknowledged totals.

## Action Button Checks

For active packets (`generated`, `sent`, `viewed`, `acknowledged`):

1. Click **Review Agreement**.
2. Confirm it opens the same tokenized public review URL used by review emails.
3. Confirm opening the review page still records viewed status/view metadata for `generated` or `sent` packets.
4. Click **Print / Save PDF**.
5. Confirm it opens the same secure print view using the existing token plus `vmsa_print=1`.

For inactive packets (`superseded`, `voided`):

1. Confirm review/print buttons are not shown.
2. Confirm the card clearly states it is a historical copy only.

## Regression Checks

1. Send a review-link email from the admin packet viewer.
2. Confirm the emailed link still works.
3. Confirm acknowledgement submission still works.
4. Confirm acknowledgement confirmation email still sends.
5. Confirm regenerated/superseded packet guardrails still behave as before.
6. Confirm public print view still avoids site header/footer/gallery leakage.

## Notes

- Vendor matching is deliberately defensive. It first allows VMS Core/helper functions or filters to provide vendor IDs, then falls back to common vendor user-link post meta, user meta, and email matching.
- If the current VMS Core portal uses a different hook name, use the shortcode as the safe integration path until the exact core hook is available.
