# CODEX HANDOFF - VMS Agreements 0.3.5 Printable Agreement Copy

## Package

`vms-agreements-0.3.5-printable-agreement-copy.zip`

## Goal

Test the new print / save-as-PDF workflow for agreement packets without disturbing the existing packet generation, review-link email, acknowledgement, stale-packet, void, or regenerate/supersede behavior.

## Primary Test Plan

Run:

- `docs/TEST-PLAN-0.3.5.md`

Also spot-check:

- `docs/TEST-PLAN-0.3.4.md`

## Important Guardrails

- Do not replace the tokenized review-link flow.
- Do not add a server-side PDF library in this pass.
- Do not change packet snapshot schema unless a failure proves it is required.
- Do not loosen voided/superseded/stale packet restrictions.
- Do not make public print links available without a valid packet token.

## Versioning Rule

If any code is edited, update all version/build markers and docs before returning a zip:

- plugin header version
- `VMSA_VERSION`
- `vms-agreements-build.txt`
- changelog
- handoff
- relevant test plan docs
- package filename

Return a complete replacement zip only.
