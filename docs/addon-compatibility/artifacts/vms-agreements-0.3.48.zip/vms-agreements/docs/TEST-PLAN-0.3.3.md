# VMS Agreements 0.3.3 Test Plan - Email Mobile Readability Polish

## Purpose

Verify that vendor agreement emails are easier to read on mobile devices without changing packet storage, review tokens, acknowledgements, or send guardrails.

## Checks

1. Install/replace the plugin with `vms-agreements-0.3.3-email-mobile-readability-polish.zip`.
2. Open **VMS > Agreements > Default Template > Edit Email Templates**.
3. Confirm the stock Review Link Email has clearer sections:
   - Booking summary
   - Compensation
   - Deposit / advance
   - Payment summary
4. Confirm the stock email body uses `{payment_summary_email}`.
5. Send a review-link email to a packet with:
   - flat/base compensation
   - a deposit or advance
   - a calculable remaining balance
6. On a phone, confirm the payment summary appears as separate lines instead of one dense paragraph.
7. Confirm the acknowledgement/audit disclosure says packet verification records instead of exposing raw terms hash / compensation hash wording in the email copy.
8. Submit the vendor acknowledgement and confirm the acknowledgement confirmation email also uses the cleaner payment summary format.

## Regression checks

- Review email sending is still blocked if `{review_link}` is removed from the review email body.
- Existing customized email templates are not overwritten by the upgrade migration.
- Stock 0.3.2 default email templates are migrated to the improved 0.3.3 copy.
- Packet generation, review links, acknowledgement submission, audit records, and regeneration guardrails behave as before.
