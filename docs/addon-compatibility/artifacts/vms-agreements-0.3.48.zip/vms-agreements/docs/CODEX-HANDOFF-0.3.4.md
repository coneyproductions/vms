# CODEX HANDOFF - VMS Agreements 0.3.4 Final Payment Summary Cleanup

## Package to test
`vms-agreements-0.3.4-final-payment-summary-cleanup.zip`

## Prerequisite
Install VMS Core `0.2.24.568` or newer first. This Agreements build expects Core final payment timing/method fields to exist.

## Primary purpose
Verify Agreements consumes VMS Core final payment timing/method data and presents a simpler vendor-facing payment summary without exposing internal Event Plan publication/status.

## Required test plan
Run:

- `docs/TEST-PLAN-0.3.4.md`

Also smoke test the prior agreement flow:

1. Generate packet.
2. Confirm duplicate/regenerate guardrails still work.
3. Email review link.
4. Open public vendor review link on desktop and mobile.
5. Submit acknowledgement.
6. Confirm admin proof/audit trail and confirmation email still work.

## Failure protocol for Codex
If any test fails:

1. Stop and document the failing step, expected result, actual result, URL/screen, and any console/PHP/WP debug log errors.
2. Fix the smallest durable root cause. Do not bypass packet, token, acknowledgement, stale/superseded, or email guardrails.
3. Re-run the failed test and at least one adjacent regression test.
4. If any PHP/code files are edited, update all version/build markers in the same pass.
5. If only documentation is edited, do not bump the runtime plugin version unless a code behavior changed.
6. Package a complete replacement zip. Do not provide partial files.
7. Report exactly what changed, what was tested, what still could not be tested, and whether production install is recommended.

## Required version/build updates if Codex edits code
If Codex changes code, update at minimum:

- `vms-agreements.php` plugin header `Version`
- `vms-agreements.php` `VMSA_VERSION`
- `vms-agreements-build.txt`
- `docs/CHANGELOG.md`
- `docs/README.md` if behavior/user workflow changed
- `docs/HANDOFF.md`
- add or update the relevant build-specific test plan under `docs/`
- package filename

Use the next appropriate patch version, for example `0.3.5`, unless the maintainer gives a different target.

## Rollback rule
If the update causes a critical error or the site goes down, immediately roll back to the previous working VMS Agreements zip before further diagnosis.

## Success criteria
The build is acceptable only if:

- Vendor-facing Booking Summary does not show internal Event Plan publication/status.
- Payment summary shows total agreed payment, deposit/advance, remaining final payment, expected final payment timing, and payment method when available.
- `ACH / Direct Deposit` appears clearly when selected in VMS Core.
- Review-link email is readable on mobile.
- Acknowledgement confirmation email still sends.
- Voided, superseded, stale, acknowledged, and regenerated packet guardrails still behave as before.
