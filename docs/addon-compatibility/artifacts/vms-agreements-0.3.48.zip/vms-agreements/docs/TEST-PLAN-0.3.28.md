# VMS Agreements 0.3.28 Test Plan — Frontend Current-State Fallback + Stale Hardening

## Scope

This patch addresses the case where the admin packet screen shows a packet as **Current** but the public/vendor agreement review page marks the exact same packet stale. The likely cause is VMS Core compensation helpers being available in wp-admin but not loaded on public/vendor portal requests, which made the public-side comparison treat compensation terms as empty.

## What changed

- Adds a frontend-safe comparison fallback for compensation terms when `vms_get_event_plan_comp_terms()` is not available on the request.
- Preserves the packet snapshot's stored compensation terms for comparison in that specific helper-missing case instead of manufacturing a false compensation change.
- Adds diagnostics fields showing whether the VMS compensation helper was available and which fallback was used.
- Recursively cleans display strings at packet generation time so new snapshots do not preserve mojibake artifacts.

## Manual test steps

1. Install and activate `vms-agreements-0.3.28-frontend-current-state-fallback-and-stale-hardening.zip`.
2. Clear page/cache/object cache once.
3. Open the most recent packet that previously showed **Current** in admin but stale on the public review page.
4. Confirm the admin packet status still shows **Current**.
5. Open **Agreement Current-State Diagnostics** and confirm:
   - Packet matches current Event Plan: Yes
   - VMS compensation helper available: visible as Yes/No
   - if No, fallback indicates compensation terms were preserved from the packet snapshot
6. Click **Open Vendor Review** for the exact same packet ID.
7. Confirm the public review page no longer shows **Event Plan terms changed since packet generation** for that current packet.
8. Confirm the signer section is enabled when the packet is current and still not acknowledged.
9. Open the vendor portal preview and confirm the current card points to the same latest packet and does not show the stale warning.
10. Regenerate once only if needed, then repeat steps 4–9.
11. Confirm newly generated packet titles/snapshot text do not show `â€`, `â€“`, stray `Â`, or similar mojibake fragments.

## Regression checks

- Confirm genuinely superseded packets remain historical/inactive.
- Confirm old stale review links still do not become incorrectly acknowledgeable.
- Confirm manual vendor review email still sends only when the operator clicks the email button.
- Confirm unsigned agreement action flags and operator signed-notification behavior from 0.3.24 remain intact.
- Confirm print/PDF still works.

## Codex note

Codex should inspect the diagnostics panel before and after opening the public review link. If the public page still says stale while admin says current, capture the diagnostics rows and whether the compensation helper fallback was used.
