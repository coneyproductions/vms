# Codex Handoff - VMS Agreements 0.3.37

## Package

`vms-agreements-0.3.37-vendor-identity-production-terms.zip`

## Goal

Make the packet identify the actual Vendor legal party and responsible contact, then require booking-specific production responsibility answers before a new agreement can be generated. This closes the ambiguity exposed by the Reputation acceptance review where only the band/display name appeared and venue production promises were not explicitly listed.

## Changes

- Event Plan Agreement Packet metabox now captures Vendor legal / contracting name and Vendor representative / contact.
- Legal name prefills from VMS Core `_vms_payee_legal_name`, falling back to `_vms_contact_name`; representative prefills from `_vms_contact_name`. Both values may be manually replaced for the individual agreement.
- Adds required Yes/No answers for Venue-provided Stage, House Sound / PA, Stage Lighting, and Sound Engineer plus a per-booking confirmation checkbox.
- Generation is blocked with a specific readiness message until legal identity, representative, all four production answers, and production confirmation are available.
- New packet snapshots and terms hashes include legal identity, representative, and production responsibilities.
- Public review / print Vendor Details shows act/display name, legal contracting name, representative/contact, email, and phone.
- Public review / print summary adds Production Responsibilities.
- Formal Agreement Packet Scope now names the Vendor legal contracting party and representative/contact.
- Signer name/email fields prefill from the packet representative and vendor email but remain editable; acknowledgement continues to record the actual signer separately.

## Architecture note

These booking-specific production values are Agreements-owned Event Plan metadata as a narrow bridge so current agreements can be issued. If VMS Core later gains a canonical production-responsibility model, migrate these fields into Core and keep Agreements as a consumer/snapshot renderer.

## Non-goals / unchanged

- No change to compensation calculations, bonus tiers, weather/event-viability economics, payment calculations, acknowledgement audit schema, review tokens, email delivery, or packet supersede/void behavior.
- No operator production defaults yet; every booking must be explicitly answered and confirmed.
