# VMS Agreements 0.3.45 Test Plan

## Vendor Details overlap
1. Open an existing packet's **Print / Save as PDF** HTML view.
2. Confirm **Representative / contact** does not overlap the representative value.
3. Confirm **Legal contracting name**, Vendor email, and Vendor phone remain aligned and readable.
4. Confirm Event Details still fits cleanly beside Vendor Details.

## PDF / physical print
1. Print or Save as PDF.
2. Confirm the two-column Event/Vendor summary remains intact.
3. Confirm no Vendor Details labels overlap values or are clipped.

## Regression
- No agreement wording changes.
- Existing packet does not become stale and does not require regeneration.
- All PHP files pass `php -l`; release ZIP passes `unzip -t`.
