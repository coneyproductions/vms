# VMS Agreements 0.3.5 Test Plan - Printable Agreement Copy

## Purpose

Verify that agreement packets can be opened in a clean printable view and saved as PDF through the browser without changing packet storage, review links, acknowledgement behavior, email delivery, or regeneration guardrails.

## Install / Setup

1. Install VMS Core 0.2.24.568 or newer.
2. Install and activate VMS Agreements 0.3.5.
3. Use an Event Plan with:
   - upcoming event date
   - primary vendor with email
   - compensation terms
   - optional deposit / advance terms
   - final payment timing and method when available

## Test 1 - Admin packet print action

1. Go to VMS > Planning > Agreements.
2. Open an existing current agreement packet or generate a new packet.
3. In the Vendor Review Link card, click Print / Save PDF.
4. Confirm a new public print view opens.
5. Confirm the page uses a clean standalone layout without the normal site header/footer.
6. Confirm the page includes:
   - event date/time/venue
   - vendor name/email/phone when captured
   - simplified payment summary
   - agreement text
   - acknowledgement status/proof section

Expected: The print view opens successfully and does not require WordPress admin access.

## Test 2 - Public review page print action

1. Open the normal Vendor Review Link in a private/incognito window.
2. Click Print / Save as PDF.
3. Confirm the print view opens.
4. Click Back to review page.

Expected: The vendor can move between the normal review page and printable copy using the same secure token.

## Test 3 - Browser print / save PDF

1. On the print view, click Print / Save as PDF.
2. Confirm the browser print dialog opens.
3. Preview the print output.
4. Confirm action buttons are hidden from print output.
5. Confirm cards do not have heavy shadows/backgrounds in print output.

Expected: Print output is clean and suitable for saving as PDF.

## Test 4 - Before acknowledgement

1. Open a packet that has not yet been acknowledged.
2. Open the print view.
3. Confirm the copy says acknowledgement proof has not yet been recorded.

Expected: The copy does not imply that the agreement has already been acknowledged.

## Test 5 - After acknowledgement

1. Open the Vendor Review Link.
2. Complete required signer details and acknowledgements.
3. Submit acknowledgement.
4. Open the Print / Save as PDF view again.
5. Confirm acknowledgement proof appears in the printable copy.

Expected: The printable copy includes signer, acknowledgement date/time, IP address, agreement version, and acknowledgement lines.

## Test 6 - Guardrails unchanged

1. Void a packet.
2. Try opening its review/print link.
3. Supersede a packet.
4. Try opening the superseded packet review/print link.
5. Change Event Plan terms to make a packet stale.
6. Confirm stale packet acknowledgement remains blocked.

Expected: Existing voided/superseded/stale guardrails remain unchanged.

## Test 7 - Regression checks

1. Send a review-link email.
2. Confirm email delivery still works.
3. Regenerate/supersede a current packet.
4. Confirm old packet is preserved and new packet requires fresh acknowledgement.
5. Confirm template health check still blocks packet generation when required blocks are unhealthy.

Expected: No regressions in email, acknowledgement, template, or regeneration behavior.

## Failure Protocol for Codex

If any test fails:

1. Record the exact failure, URL/screen, packet ID, event plan ID, and visible message.
2. Identify the smallest durable root cause.
3. Fix the root cause without changing unrelated packet/acknowledgement/email behavior.
4. Rerun the failed test and nearby regression tests.
5. If code is edited, update:
   - plugin header version
   - `VMSA_VERSION`
   - `vms-agreements-build.txt`
   - `docs/CHANGELOG.md`
   - `docs/HANDOFF.md`
   - this test plan or a new test plan if version changes
   - package filename
6. Return one complete replacement zip only.
