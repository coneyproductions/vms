# VMS Agreements 0.3.8 Test Plan - Printable Copy Readable Width

## Goal

Verify that printable agreement copies favor readability over forcing a cramped one-page layout.

## Preconditions

1. VMS Core 0.2.24.568+ is installed and active.
2. VMS Agreements 0.3.8 is installed and active.
3. At least one current agreement packet exists with event, vendor, compensation, deposit, and final payment fields.

## Tests

1. Open the packet viewer in wp-admin.
2. Click Print / Save PDF.
3. Confirm the standalone print page opens without the normal site header, footer, or gallery content.
4. Confirm Booking & Payment Summary shows Event, Vendor, and Payment as full-width stacked sections, not cramped columns.
5. Confirm Agreement Terms render as full-width clause blocks with each heading paired with its text.
6. Print or save as PDF from the browser.
7. Confirm the PDF is readable even if it spills to a second page.
8. Open the vendor review link and click Print / Save as PDF.
9. Confirm the public print route uses the same readable full-width layout.
10. If the packet is acknowledged, confirm acknowledgement proof appears. If not acknowledged, confirm the not-yet-acknowledged message appears.

## Regression checks

1. Packet generation still works.
2. Vendor acknowledgement still works.
3. Review-link email sending still works.
4. Regenerate / supersede and void guardrails still work.

## Failure protocol for Codex

If any failure requires code changes:

1. Fix the smallest durable root cause.
2. Re-run the failed test and adjacent regression checks.
3. Update all version/build markers before packaging: plugin header version, VMSA_VERSION, vms-agreements-build.txt, CHANGELOG.md, docs/HANDOFF.md, relevant test plan docs, and package filename.
4. Return a complete replacement zip only. Do not provide partial files.
