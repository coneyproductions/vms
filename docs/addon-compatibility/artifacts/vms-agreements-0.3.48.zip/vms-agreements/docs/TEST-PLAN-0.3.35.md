# VMS Agreements 0.3.35 Test Plan

## Static / package

1. PHP lint all plugin PHP files.
2. Confirm runtime/build version markers are 0.3.35.
3. Confirm the 0.3.34 agreement-language defaults version remains unchanged because this release does not modify contract text.

## Event Plan sidebar readiness diagnostics

1. Use an upcoming Event Plan with a primary vendor.
2. Clear Legal contracting party in Agreement Defaults.
3. Confirm the Agreement Packet metabox does **not** claim the Event Plan is cancelled or past.
4. Confirm it says generation is waiting on Agreement Defaults and displays **Open Agreement Defaults**.
5. Click the button and confirm the Agreements admin page lands at the Agreement Defaults card.
6. Save a legal contracting party and return to the Event Plan.
7. Confirm Generate Packet becomes available.

## Distinct blockers

1. Mark a disposable test Event Plan Cancelled and confirm the sidebar identifies the Cancelled status.
2. Use a past Event Plan and confirm the sidebar identifies the past event date.
3. Use an upcoming Event Plan without a primary vendor and confirm the primary-vendor guidance remains specific.
4. Confirm existing packet history remains visible when generation itself is blocked.

## Packet detail

1. Open an existing packet whose Event Plan is blocked.
2. Confirm the bottom regeneration guardrail uses the same reason-specific explanation.
3. For missing Agreement Defaults, confirm the remediation button is present.

## Regression

1. Generate a packet for an eligible upcoming Event Plan.
2. Confirm 0.3.34 contract language, hashes, packet snapshots, public review, acknowledgement, and supersede behavior are unchanged.
