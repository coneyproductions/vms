# VMS Agreements 0.1.2 Test Plan — Button + Guided Tour Hotfix

🚨 **Codex / browser testing recommended before using with real vendor agreements.**

## Install / Activation

1. Upload and replace the existing `vms-agreements` plugin.
2. Confirm WordPress shows VMS Agreements version `0.1.2`.
3. Confirm VMS Core `0.2.24.567` or newer is active.

## Agreements Page Generate Button

1. Open `wp-admin/admin.php?page=vms-agreements`.
2. Confirm the `Generate Agreement Packet` button is clickable, not greyed out, when VMS Core dependency checks pass.
3. Select an Event Plan with a primary vendor.
4. Click `Generate Agreement Packet`.
5. Confirm it redirects to the generated packet view instead of staying disabled or routing to another WordPress admin list.

## Dependency Regression

1. On a disposable test site only, disable or downgrade VMS Core below `0.2.24.567`.
2. Confirm the dependency warning appears.
3. Confirm packet generation is disabled while the dependency is missing/old.

## Guided Tour

1. Open the Agreements admin page.
2. Confirm the screen no longer shows `No guided tour is registered for this screen yet.`
3. Start the Agreement Packets tour.
4. Confirm steps can target the intro, Generate Packet card, Default Template card, Recent Packets card, and packet viewer sections when a packet is open.

## Regression

1. Confirm the Event Plan sidebar Generate Packet link still works.
2. Confirm existing packets still appear in Recent Packets.
3. Confirm stale/current packet status still renders.
4. Confirm voiding a packet still works.
