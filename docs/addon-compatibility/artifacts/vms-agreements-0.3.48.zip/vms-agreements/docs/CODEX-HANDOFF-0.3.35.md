# Codex Handoff — VMS Agreements 0.3.35

## Package

`vms-agreements-0.3.35-generation-readiness-diagnostics.zip`

## Goal

Make agreement-generation guardrails explain the actual prerequisite that is blocking the operator. This follows a real Reputation Event Plan case where a missing Legal contracting party in Agreement Defaults was incorrectly presented as a cancelled/past Event Plan.

## Changes

- `vmsa_event_plan_generation_block_reason()` remains the single eligibility source of truth.
- Added `vmsa_event_plan_generation_block_message()` for reason-specific operator guidance.
- Added `vmsa_event_plan_generation_block_action()` for actionable remediation links.
- Event Plan Agreement Packet metabox now renders the specific blocker.
- Missing contracting identity includes an **Open Agreement Defaults** button anchored to the defaults card.
- Packet-detail regeneration guardrail uses the same shared diagnostic.
- Agreement Defaults card now has a stable anchor (`#vmsa-agreement-defaults`).

## Non-goals / unchanged

- No agreement clause changes from 0.3.34.
- No packet schema, hash, snapshot, acknowledgement, compensation, or eligibility behavior changes.
- Cancelled and past Event Plans remain blocked.

## Operator acceptance fixture

On the September 12, 2026 Reputation Event Plan:

1. Clear the Legal contracting party in Agreement Defaults.
2. Confirm the Event Plan sidebar says Agreement generation is waiting on Agreement Defaults and offers **Open Agreement Defaults**.
3. Set `Coney Productions LLC d/b/a Serenade Range`, save, and return to the Event Plan.
4. Confirm **Generate Packet** appears without changing Event Plan date/status.
