# VMS Agreements 0.3.7 Test Plan - Printable Copy Legibility Cleanup

## Purpose
Confirm the printable agreement copy remains compact while improving readability of the Agreement Terms section.

## Prerequisites
1. VMS Core 0.2.24.568 or newer is installed and active.
2. VMS Agreements 0.3.7 is installed and active.
3. At least one future Event Plan has a primary vendor and compensation terms.

## Tests

### 1. Generate or open a packet
1. Go to VMS > Planning > Agreements.
2. Open an existing current packet or generate a new packet for a future, non-cancelled Event Plan.
3. Confirm the packet viewer loads without PHP errors.

Expected: Packet viewer loads normally and the Print / Save PDF button is available.

### 2. Printable copy does not include theme/footer content
1. Click Print / Save PDF.
2. Save the browser print output as PDF.
3. Review the PDF.

Expected: The PDF includes only the agreement copy. Site footers, galleries, sliders, and unrelated theme content do not appear.

### 3. Printable copy remains compact
1. Review the saved PDF page count.

Expected: A normal short agreement fits on one page. Longer edited clause language may flow to two pages, but the layout should remain compact.

### 4. Agreement Terms are readable
1. Review the Agreement Terms section in the saved PDF.

Expected: Clause headings appear as headings with their matching text below/near them. Headings should not run together inline with the previous clause text.

### 5. Summary still includes key payment information
1. Review the Booking & Payment Summary.

Expected: Event title, date, time, venue, vendor, compensation/deposit summary, total payment, and remaining final payment are still present.

### 6. Acknowledgement proof state
1. Test both an unacknowledged and acknowledged packet if available.

Expected: Unacknowledged packets state acknowledgement proof is not recorded yet. Acknowledged packets include signer/audit proof.

## Failure / Version Protocol for Codex
If a test fails, document the failure, fix the smallest durable root cause, rerun the failed test plus adjacent regression checks, and package a complete replacement zip. If Codex edits code, update the plugin header version, `VMSA_VERSION`, `vms-agreements-build.txt`, changelog, README/handoff as applicable, relevant test plan docs, and package filename in the same pass. If only docs change, do not bump the runtime version unless behavior changed.
