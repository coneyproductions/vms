# VMS Agreements 0.3.47 Handoff

## Scope

Dependency-only compatibility repair for the public Backstage Venue Manager package.

## Change

- Added a shared core-version resolver that prefers `BVMGR_VERSION` and falls back to legacy `VMS_VERSION`.
- Routed the loaded/version gate and dependency notice through that resolver.
- Left all packet, template, snapshot, acknowledgement, email, permission, nonce, and vendor-portal behavior unchanged.

## Compatibility

Existing templates, packets, review tokens, acknowledgement records, hashes, and Event Plan associations do not require migration or regeneration.
