# CODEX HANDOFF - VMS Agreements 0.3.6 Printable Copy Cleanup

Package under test:

`vms-agreements-0.3.6-printable-copy-cleanup.zip`

## Goal

Verify that printable agreement copies are compact, isolated from theme/footer content, and suitable for browser print/save-as-PDF.

## Primary test plan

Run:

- `docs/TEST-PLAN-0.3.6.md`

Also spot-check the 0.3.4/0.3.5 flows if failures appear near packet rendering, acknowledgement proof, or tokenized review links.

## Important guardrails

Do not change packet snapshot schema, acknowledgement records, review token validation, email delivery, template editor behavior, or regeneration guardrails unless a test failure proves it is required.

## If code changes are made

Update all applicable version/build markers and docs in the same pass:

- plugin header version
- `VMSA_VERSION`
- `vms-agreements-build.txt`
- changelog
- README / handoff
- relevant test plan docs
- replacement package filename

Return a complete replacement zip.
