# VMS Agreements 0.3.1 Test Plan - Payment Summary Wording

## Purpose

Verify the agreement packet compensation language clearly distinguishes total agreed payment, deposit/advance, and remaining final payment balance.

## Checks

1. Generate a packet for a flat-fee Event Plan with a deposit/advance amount.
2. Confirm the public vendor review page shows:
   - Compensation terms
   - Deposit / advance terms
   - Payment summary
   - Final payment balance after deposit/advance
3. Confirm the wording no longer says "Creditable toward final pay".
4. Confirm the deposit/advance line explains the amount is part of the total payment, not extra pay.
5. Confirm the admin packet viewer shows the same Payment summary in the Compensation Snapshot.
6. Send the review email and confirm the email includes the Payment summary.
7. Generate or view a variable-compensation packet and confirm the summary states that variable compensation may change the final payment amount.
8. Confirm existing older packets still render safely using fallback calculations from stored compensation terms.

## Expected Result

Vendors should be able to understand:
- the total agreed payment or known base/guarantee;
- the deposit/advance amount and status;
- that the deposit/advance is part of the total payment, not additional pay;
- the remaining final balance after deposit/advance when the balance can be calculated.
