# CODEX HANDOFF - VMS Agreements 0.3.9 Vendor Portal Pending Agreements

## Build

- Plugin: `vms-agreements`
- Version: `0.3.9`
- Package target: `vms-agreements-0.3.9-vendor-portal-pending-agreements.zip`
- Requires: VMS Core `0.2.24.568+`

## What Changed

Added a vendor-facing agreement portal renderer:

- New file: `includes/vendor-portal.php`
- New shortcode: `[vmsa_vendor_agreements]`
- Auto-render hooks added for likely VMS portal areas:
  - `vms_vendor_portal_after_dashboard_cards`
  - `vms_vendor_portal_dashboard_after_cards`
  - `vms_vendor_portal_agreements`
- Public stylesheet extended with vendor agreement card/list styling.
- Front-end public stylesheet now loads for logged-in users so portal cards can be styled when rendered by shortcode or portal hook.

## Behavior

Logged-in vendors can see agreement packets tied to their vendor profile:

- Needs Review / Pending (`generated`, `sent`)
- Viewed
- Acknowledged
- Superseded
- Voided

Active packets show:

- **Review Agreement** button using the existing tokenized public review URL.
- **Print / Save PDF** button using the existing secure print URL.

Inactive packets show historical status only and do not expose review/print actions because the existing public token route intentionally rejects superseded/voided packets.

## Important Guardrails Preserved

- Email token flow remains unchanged.
- Public review-link behavior remains unchanged.
- Opening the public review URL still records viewed status/metadata.
- Packet generation, snapshot schema, acknowledgement records, email templates, print rendering, and regeneration/void guardrails were not changed.

## Vendor Matching

Vendor matching is defensive because VMS Core may expose different account-link helpers across versions:

1. Checks optional filters and helper functions first.
2. Checks user meta keys such as `vms_vendor_id` / `_vms_vendor_id`.
3. Searches vendor post meta keys such as `_vms_vendor_user_id`, `_vms_linked_user_id`, and primary/vendor email fields.
4. Only packets matching `_vmsa_vendor_id` are returned.

Useful filters:

- `vmsa_current_user_vendor_ids_pre`
- `vmsa_current_user_vendor_ids`
- `vmsa_vendor_portal_vendor_post_types`
- `vmsa_vendor_portal_user_link_meta_keys`
- `vmsa_vendor_portal_email_link_meta_keys`
- `vmsa_vendor_portal_user_vendor_meta_keys`
- `vmsa_vendor_portal_packet_statuses`

## Testing Required

🚨 Run `docs/TEST-PLAN-0.3.9.md` before considering this build validated.

Focus especially on whether the current VMS Core vendor portal fires one of the included hooks. If not, the shortcode `[vmsa_vendor_agreements]` is the safe integration path until the exact hook is added or confirmed.
