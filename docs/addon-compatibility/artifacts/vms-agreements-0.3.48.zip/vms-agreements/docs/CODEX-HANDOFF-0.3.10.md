# CODEX HANDOFF - VMS Agreements 0.3.10 Vendor Portal Core Hook Integration

## Build

- Plugin: `vms-agreements`
- Version: `0.3.10`
- Package target: `vms-agreements-0.3.10-vendor-portal-core-hook-integration.zip`
- Requires: VMS Core `0.2.24.569+`

## What Changed

Updated `includes/vendor-portal.php` so Pending Agreements uses real VMS portal extension points:

- Adds an Agreements nav item via `vms_vendor_portal_nav_links`.
- Renders the Agreements tab via `vms_vendor_portal_render_custom_tab` when `tab=agreements`.
- Renders the dashboard card through `vms_vendor_portal_dashboard_after_cards`.
- Reads `vendor_id` / `vendor_ids` from Core's `$portal_context` before falling back to logged-in-user vendor discovery.
- Hides dashboard/nav integration when the active vendor has no packets, while direct tab/shortcode rendering still shows a friendly empty state.

## Why

Version `0.3.9` had a working renderer and shortcode fallback, but the card did not appear automatically because VMS Core did not fire the guessed dashboard hook. Pair this version with VMS Core `0.2.24.569+`, which adds the stable hook.

## Guardrails Preserved

- Tokenized email review links remain unchanged.
- Public review URL behavior remains unchanged.
- Print / Save PDF URL behavior remains unchanged.
- Acknowledgement submission and confirmation emails remain unchanged.
- Packet schema, snapshots, terms/comp hashes, supersede/regenerate/void guardrails remain unchanged.
- Shortcode `[vmsa_vendor_agreements]` remains available as a fallback.

## Testing Required

🚨 Run `docs/TEST-PLAN-0.3.10.md` with VMS Core `0.2.24.569+` before considering this build validated.
