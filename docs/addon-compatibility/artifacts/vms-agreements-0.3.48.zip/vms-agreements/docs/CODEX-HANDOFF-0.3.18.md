# Codex Handoff - VMS Agreements 0.3.18

## Build

- Plugin: `vms-agreements`
- Version: `0.3.18`
- Build label: `activation-bonus-clarity`

## Purpose

This is a targeted hotfix after the 0.3.17 zip reportedly fataled on activation and the agreement preview made the bonus structure look like a bonus was earned at 100 attendees.

## What Changed

- Keeps activation lightweight: registers CPTs, stores version/build state, sets a default-template-check flag, and flushes rewrites.
- Defers default agreement template creation/checking to the existing admin-init manager path instead of doing heavier template writes inside the activation hook.
- Changes Base + attendance/ticket-sales bonus wording so agreements refer to paid ticket sales by default.
- Clarifies step bonuses as no bonus on the first threshold count, then bonus per additional step, with the first bonus count explicitly shown.

## Example Expected Bonus Copy

`Base fee: $1,500.00; Bonus structure: no bonus on the first 100 paid ticket sales; then $250.00 per 50 additional paid ticket sales (first bonus at 150 paid ticket sales).`

## Required Test Plan

Run `docs/TEST-PLAN-0.3.18.md`.
