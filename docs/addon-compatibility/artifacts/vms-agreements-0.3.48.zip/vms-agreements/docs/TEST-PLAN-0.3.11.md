# TEST PLAN - VMS Agreements 0.3.11 Vendor Portal History Cleanup

🚨 **Codex / live-site testing is required before treating 0.3.11 as validated.**

This pass cleans up the vendor-facing Agreements tab by collapsing superseded and voided packets into an Agreement History section. It also improves flat-fee compensation wording and reduces duplicate Event labeling in public/print summary cards.

## 🚨 Codex Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small:

1. Update the plugin header version.
2. Update all version constants.
3. Update `vms-agreements-build.txt`.
4. Update `docs/CHANGELOG.md` and any relevant build notes.
5. Update or add the relevant test plan notes.
6. Update the Codex handoff with the repair summary.
7. Rename the package zip to the new version/build slug.

Do not return a modified plugin zip with stale version numbers, stale build notes, or a stale package filename.

## Required Pairing

1. Install VMS Core `0.2.24.570` or newer.
2. Install VMS Agreements `0.3.11` over the existing `vms-agreements` folder.
3. Confirm WordPress shows VMS Agreements version `0.3.11`.
4. Confirm `vms-agreements/vms-agreements-build.txt` reads:
   - `0.3.11`
   - `vendor-portal-history-cleanup`

## Syntax / Smoke Checks

1. Run PHP lint on all VMS Agreements PHP files.
2. Activate VMS Agreements.
3. Confirm no fatal errors on:
   - VMS > Agreements
   - Admin packet viewer
   - Public vendor review link
   - Public print / save-as-PDF link
   - Public page containing the native VMS vendor portal shortcode/page

## Vendor Portal History Checks

Use a logged-in user linked to a VMS vendor profile with:

- at least one current active packet in `generated`, `sent`, `viewed`, or `acknowledged` status
- at least two historical packets in `superseded` or `voided` status

Expected:

1. The Agreements tab appears in the vendor portal nav.
2. The current/actionable packet card appears expanded above history.
3. Superseded and voided packets do not render as full expanded cards by default.
4. A collapsed **Agreement History** section appears.
5. The history summary shows the number of previous packets.
6. Opening Agreement History reveals compact historical packet cards.
7. Compact historical cards show event name, status, date, and history/audit lines.
8. Historical compact cards do not expose active Review Agreement or Print / Save PDF buttons.
9. The vendor can close the Agreement History section again.

## History-Only Vendor Check

Use or create a linked vendor that has only superseded/voided packets and no current packet.

Expected:

1. The Agreements tab still renders a friendly page.
2. Agreement History is open by default when there are no current packets.
3. Historical packets are still compact.
4. No active review/print action is exposed for inactive packets.

## Compensation Wording Checks

Use a packet with flat-fee compensation.

Expected on all relevant displays:

- Vendor portal card shows `Flat fee: $1,500.00` or total agreed payment when the payment breakdown is available.
- Public review Booking Summary does not show `Flat fee; Base/flat`.
- Public print Booking & Payment Summary does not show `Flat fee; Base/flat`.
- Agreement Text generated from template tokens does not show `Flat fee; Base/flat` for newly generated packets.
- Existing older packets with stored `Flat fee; Base/flat` text display cleaned wording without requiring packet regeneration.

## Public / Print Label Checks

1. Open a public vendor review link.
2. Open the matching Print / Save as PDF link.

Expected:

- Booking Summary no longer visually reads as `Event Event Test Band`.
- Event label is clearer as `Event name` inside the Event section.
- Existing acknowledgement and proof display still works.
- Public print shell still avoids normal site footer/gallery leakage.

## Regression Checks

1. Send a review-link email from the admin packet viewer.
2. Confirm the emailed link still works.
3. Confirm the portal Review Agreement button still opens the same tokenized public review flow for active packets.
4. Confirm opening the review page still records viewed metadata for eligible packets.
5. Submit an acknowledgement and confirm the acknowledgement confirmation email still sends.
6. Confirm superseded and voided tokenized public links still show the unavailable screen.
7. Confirm `[vmsa_vendor_agreements]` still works as a fallback display.

## Out of Scope

- Hard-delete cleanup for test packets.
- Admin-only bulk cleanup tools.
- Server-side PDF generation.
- Clause language rewrite.
