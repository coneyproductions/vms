# VMS Agreements 0.3.40 Test Plan

## Agreement Setup — payment method
1. Open Agreements → Agreement Setup for an upcoming Event Plan with a primary vendor.
2. Confirm a **Final Payment** section appears.
3. Confirm the resolved final-payment timing is displayed.
4. Confirm Payment method is required and offers:
   - Check
   - Cash
   - ACH / Direct Deposit
   - Zelle
   - Venmo
   - PayPal
   - Other
5. Select a standard method, save, reopen Agreement Setup, and confirm it persists.
6. Select **Other** and confirm the manual method field becomes required.
7. Confirm **Other** with a blank description cannot produce a new packet.
8. Enter a manual value for Other, save, reopen, and confirm it persists.

## Generation readiness
1. Clear the Event Plan final-payment method while identity and production setup are otherwise complete.
2. Confirm packet generation reports **Payment method** as the missing Agreement Setup prerequisite.
3. Confirm the Event Plan Agreement Packet metabox shows `Payment method: Needs setup`.
4. Set and save a payment method.
5. Confirm generation becomes available when the other required setup fields are complete.

## Packet rendering / stale behavior
1. Generate or regenerate a packet after choosing a method.
2. Confirm the Compensation Terms / Payment summary visibly includes `Payment method: <chosen method>`.
3. Confirm the formal Agreement Text payment summary contains the same method.
4. Change the payment method in Agreement Setup after packet generation.
5. Confirm the existing packet becomes stale and requires regeneration rather than silently changing stored packet evidence.

## Compatibility / regression
- The payment value is stored in VMS Core Event Plan payment meta, not a second Agreements-only payment field.
- An old 0.3.37 Event Plan editor form submission that lacks payment fields does not clear an already-saved payment method.
- Existing historical packets remain readable and retain their stored hashes/evidence.
- Vendor identity, production responsibilities, public acknowledgement, print footer, and bold Agreement Text headings remain unchanged.
- All plugin PHP files pass `php -l`.
