# VMS Agreements 0.3.41 Codex Handoff

## Goal
Finish the Reputation agreement review with clearer payment presentation and explicit standard technical / venue-access expectations without turning the agreement into a full stage rider.

## Changes
- Cleans the Agreement Setup Final Payment layout: the payment-method selector sits on its own aligned row, and the custom **Other** field is hidden until Other is selected.
- Renames vendor-facing **Payment summary** presentation to **Payment Terms** and renders its items as a readable list.
- In formal Agreement Text, moves Payment Terms ahead of the bonus payout schedule so payment timing/method remain visibly part of Compensation Terms instead of appearing appended to the bonus explanation.
- Tightens the stock Payment Timing clause to state that the final-payment timing and method shown in Compensation Terms control.
- Defines the standard House Sound / PA scope when Venue-provided: Venue-confirmed standard house PA, microphones, microphone stands, DI boxes, stage monitor wedges, and ordinary house audio cabling for the agreed input list.
- States that Vendor provides instruments, personal/instrument cabling, backline unless separately accepted, specialty/wireless gear, and any in-ear monitoring system unless expressly accepted by Venue.
- Allows compatible console monitor sends to a Vendor-provided IEM system when available.
- Requires Vendor to disclose stage plot/input list and nonstandard technical requirements reasonably in advance.
- Expands the stock Venue Rules clause so Vendor must follow reasonable written arrival/load-in, setup, soundcheck, performance, strike/load-out, and venue-vacate instructions. Exact logistics may be communicated/adjusted later without a new packet unless the packet makes a time a material term.
- Exact-match language migration updates untouched stock 0.3.40 clauses while preserving operator-customized clause text.

## Reputation acceptance target
Regenerate the Reputation packet after installing 0.3.41. Confirm Compensation Terms show a readable Payment Terms list before Bonus payout schedule; Production Responsibilities explain the standard house-audio scope; and Agreement Text states Vendor-provided IEM responsibility plus the production/access schedule obligation.
