# Codex Handoff — VMS Agreements 0.3.21

## Issue
0.3.20 added the bonus payout schedule table to the public/vendor review page, admin compensation snapshot, and text-preview output, but the dedicated print/PDF copy still showed the summary text `Bonus: see payout table below.` without rendering the actual payout table.

## Change
- `includes/public.php`
  - `vmsa_render_public_print_content()` now calls `vmsa_render_public_bonus_payout_table()` immediately after the print Booking & Payment Summary grid.
  - The table appears before Agreement Terms in the standalone print/PDF view.
  - Existing no-table guard remains centralized in `vmsa_render_public_bonus_payout_table()`, so flat-fee-only packets do not show an empty table.
- Version bumped to 0.3.21 in:
  - `vms-agreements.php`
  - `vms-agreements-build.txt`

## Expected example
For a $1,500 base fee with no bonus through 100 paid ticket sales and $250 every 50 paid ticket sales after that, print/PDF should include:

| Paid ticket sales | Payout |
|---:|---:|
| 100 | $1,500.00 |
| 150 | $1,750.00 |
| 200 | $2,000.00 |
| 250 | $2,250.00 |
| 300 | $2,500.00 |
| 350 | $2,750.00 |

## Testing notes
- Codex may make small, directly related code repairs during testing if feasible.
- If code changes are made during testing, update the plugin header version, `VMSA_VERSION`, and `vms-agreements-build.txt` consistently.
- Regression-check activation because 0.3.18 intentionally made activation lighter after the 0.3.17 fatal-on-activation report.
