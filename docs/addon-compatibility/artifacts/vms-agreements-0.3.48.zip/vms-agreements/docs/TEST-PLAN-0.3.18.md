# VMS Agreements 0.3.18 Test Plan - Activation + Bonus Clarity

## Build Under Test

- VMS Agreements: `0.3.18-activation-bonus-clarity`
- VMS Core: current staging/production build

## Checks

1. Upload and activate `vms-agreements` with WP debug logging enabled.
2. Confirm activation does not fatal.
3. Confirm plugin header reports `0.3.18`.
4. Confirm `VMSA_VERSION` reports `0.3.18`.
5. Confirm `vms-agreements-build.txt` contains:

```text
0.3.18
activation-bonus-clarity
```

6. Open **VMS > Agreements** as an admin and confirm the default template check completes without error.
7. Generate or regenerate an agreement packet for an Event Plan using Base + attendance/ticket-sales bonus terms with:
   - Base fee: `$1,500`
   - Bonus threshold/start count: `100`
   - Step size: `50`
   - Step bonus: `$250`
8. Confirm the agreement preview does **not** say the vendor receives a bonus at `100 attendees`.
9. Confirm the compensation summary reads clearly as paid ticket sales, for example:
   - `Base fee: $1,500.00`
   - `Bonus structure: no bonus on the first 100 paid ticket sales; then $250.00 per 50 additional paid ticket sales (first bonus at 150 paid ticket sales).`
10. Confirm existing packet schema, review links, acknowledgement flow, operator queue, vendor portal, and print view still render.

## Notes for Codex

- Codex may make small, directly related code repairs discovered during this test when feasible.
- If code changes are made, update the plugin header, `VMSA_VERSION`, `vms-agreements-build.txt`, and docs consistently before packaging.
