# VMS Agreements 0.3.30 Test Plan — Agreement Language Consistency Audit

## Scope

This patch standardizes vendor-facing agreement terminology without changing the 0.3.29 current/stale/hash behavior.

## What changed

- New packets now include a required **Agreement Packet Scope** block near the top of the generated agreement text.
- Stock acknowledgement labels, stock audit/proof blocks, public review copy, print/PDF copy, vendor-portal warnings, proof output, and default email copy now use consistent **Agreement Packet** terminology.
- Vendor-facing stale messaging no longer says **Event Plan**.
- Existing customized template/email text is preserved unless it exactly matched prior stock defaults.

## Manual test steps

1. Install and activate `vms-agreements-0.3.30-agreement-language-consistency-audit.zip`.
2. Confirm version markers:
   - plugin header `0.3.30`
   - `VMSA_VERSION` `0.3.30`
   - `vms-agreements-build.txt` slug `agreement-language-consistency-audit`
3. Open the default Agreement Template editor.
4. Confirm a required protected **Agreement Packet Scope** block appears before the Event Details block.
5. Confirm the stock **Acknowledgement & Audit Record** block and **Acknowledgement Proof** block use the updated Agreement Packet wording.
6. Generate one new packet only.
7. Open the public/vendor review page for that exact packet.
8. Confirm `booking details` does not appear in the acknowledgement section or formal packet language.
9. Confirm the acknowledgement checkboxes use these concepts:
   - Agreement Packet
   - Event Details
   - Vendor Details
   - Compensation Terms
   - Deposit / Advance Terms
   - Agreement Terms
   - Acknowledgement Record
   - Packet Verification Records
10. Confirm the **Agreement Text** section includes **Agreement Packet Scope** near the top.
11. Confirm the public review summary card uses **Agreement Packet Summary**, **Event Details**, **Vendor Details**, and **Compensation Terms** headings.
12. Open the print/PDF view for the same packet.
13. Confirm the print/PDF copy uses the same terminology and does not show **Booking Summary** or vendor-facing **packet version** wording.
14. Confirm the acknowledgement-proof section shows:
   - signer details
   - acknowledgement date/time
   - packet ID
   - agreement version
   - Packet Verification Records
15. Confirm default review/acknowledgement emails use **Agreement Packet** terminology and do not say **Booking summary** or **packet record**.
16. Force or locate one stale packet and confirm the public review page and vendor portal both say:
   - `This Agreement Packet is no longer current. Please use the latest Agreement Packet issued by the venue.`
17. Confirm admin packet diagnostics and internal operator screens may still reference **Event Plan** where appropriate.
18. Re-check a known current packet from 0.3.29 behavior and confirm it is still acknowledgeable when current.

## Regression checks

- Confirm stale packets remain blocked from acknowledgement.
- Confirm superseded and voided packets remain historical/inactive.
- Confirm vendor portal still promotes only the latest current packet per Event Plan into the primary list/counts/CTA.
- Confirm raw-title decoding and mojibake cleanup still prevent broken punctuation in newly generated packet titles and snapshots.
- Confirm manual vendor review emails still send only when the operator clicks the email action.
- Confirm existing historical packets and acknowledgement records remain unchanged.
