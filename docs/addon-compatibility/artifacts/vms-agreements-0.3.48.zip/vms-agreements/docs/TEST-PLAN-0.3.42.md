# VMS Agreements 0.3.42 Test Plan

## Agreement Setup / production schedule
1. Open an upcoming Event Plan in Agreements → Agreement Setup.
2. Confirm Production Schedule shows Arrival / load-in, Soundcheck starts, Soundcheck complete by, and optional Load-out / venue vacate by.
3. Confirm the first three fields are required by the form.
4. Save times and reload Agreement Setup; confirm the values persist.
5. Leave vacate blank and generate a packet; confirm the packet says the vacate time will be communicated by Venue.
6. Enter a vacate time, save/regenerate, and confirm the explicit time appears.

## Packet rendering / hashing
1. Generate a packet after completing the schedule.
2. Confirm public review and print/PDF show Production Schedule with formatted times.
3. Confirm formal Agreement Text Event Details include Arrival / load-in, Soundcheck, and Load-out / venue vacate.
4. Change one schedule time after generation and confirm the current packet becomes stale.
5. Confirm a historical snapshot without `production_schedule` still validates its original terms hash.

## Weather cancellation language
1. Confirm the stock Weather / Safety Cancellation clause states an approximately 72-hour forecast-review goal.
2. Confirm the payment cutoff is exactly 24 hours before the scheduled arrival/load-in time in the packet.
3. Confirm cancellation at least 24 hours before that time owes no base guarantee except separately agreed nonrefundable terms/approved expenses.
4. Confirm cancellation inside 24 hours owes 100% of the base guarantee regardless of travel/arrival status.
5. Confirm reschedule-credit treatment requires written acceptance by both parties.

## Safety concern / refusal to proceed
1. Confirm Vendor may raise a specific safety concern.
2. Confirm nobody is required to work during rain on the uncovered stage or another immediate unsafe condition.
3. Confirm that absent a Venue suspension or immediate hazard, Vendor is expected to proceed with the agreed Production Schedule.
4. Confirm unjustified refusal/material delay in load-in/setup/soundcheck/performance may be treated as nonperformance when it materially affects the show.

## Phone formatting
1. Verify `2142024526` renders as `(214) 202-4526` on public review, print/PDF, admin packet review, and agreement emails.
2. Verify `12142024526` renders as `(214) 202-4526`.
3. Verify already formatted `(214) 202-4526` remains `(214) 202-4526`.
4. Verify unusual/non-10-digit values are left unchanged rather than incorrectly reformatted.

## Regression
- Vendor legal identity, representative, four Production Responsibilities, payment-method requirement, compensation/bonus terms, IEM/house-audio scope, live-band commitment, acknowledgement flow, print identity footer, and generation diagnostics continue to work.
- Customized clause text is not overwritten by stock-language migration.
- All plugin PHP files pass `php -l` and the release ZIP passes `unzip -t`.
