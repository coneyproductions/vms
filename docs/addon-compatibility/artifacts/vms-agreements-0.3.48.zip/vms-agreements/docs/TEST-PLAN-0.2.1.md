# VMS Agreements 0.2.1 Test Plan — Inline Acknowledgement UX

## Purpose

Confirm the public vendor review page places required acknowledgement checkboxes next to the agreement content they confirm, instead of grouping all checkboxes at the bottom of the page.

## Prerequisites

- VMS Core `0.2.24.567` or newer is active.
- VMS Agreements `0.2.1` is active.
- A current, non-stale agreement packet exists with a Vendor Review Link.

## Tests

### 1. Public review layout

1. Open the Vendor Review Link in an incognito/private browser window.
2. Confirm the Booking Summary card contains the event, vendor, compensation, and deposit / advance details.
3. Confirm the acknowledgement for reviewing event/vendor/compensation terms appears directly below the Booking Summary card content.
4. Confirm the acknowledgement for deposit / advance terms appears directly below the Booking Summary card content.
5. Confirm the final audit-record acknowledgement remains near the signer details and submit button.

Expected result: the acknowledgement checkboxes are visually tied to the content they represent, and the signer details remain in the final submit section.

### 2. Required checkbox validation

1. Complete signer name and signer email.
2. Leave one of the inline checkboxes unchecked.
3. Click Acknowledge Agreement Packet.

Expected result: browser validation blocks submission and focuses the unchecked checkbox near the related content.

### 3. Successful acknowledgement

1. Check every required acknowledgement.
2. Submit the acknowledgement form.

Expected result: acknowledgement succeeds and the public page displays the recorded proof.

### 4. Admin proof regression

1. Return to the admin packet viewer.
2. Confirm the packet status is Acknowledged.
3. Confirm the admin viewer still shows acknowledgement proof for each acknowledgement line.
4. Confirm the audit trail still shows signer, timestamp, IP, template/version, terms hash, and compensation hash details.

Expected result: only the public acknowledgement layout changed; storage and admin proof behavior remain intact.

## Notes

This is a UX-only pass. It does not change packet storage, acknowledgement records, hash generation, token handling, or regeneration guardrails.
