# VMS Agreements Handoff

## Current Build

- Plugin: **VMS Agreements**
- Version: **0.3.48**
- Build label: **vendor-portal-routing-registration**
- Folder: `vms-agreements`
- Type: standalone premium add-on for VMS Core
- Required VMS Core: `0.2.24.570+`

## What This Build Adds

`0.3.48` includes all agreement/business-rule and presentation work through 0.3.47 and adds a focused Backstage Venue Manager vendor-portal routing repair:

- Registers `agreements` through BVM's public vendor-portal allowed-tab filter.
- Keeps the existing Agreements navigation, badge, content renderer, packet queries, empty state, and secure review/print actions.
- Preserves all BVM and companion portal slugs already present in the allowlist.
- Makes no agreement-language, compensation, hashing, acknowledgement, identity, production, signature, notification, authorization, or nonce changes.

## Current agreement business rules

- Venue contracting identity is operator-configured; Serenade Range uses `Coney Productions LLC d/b/a Serenade Range`.
- Vendor packets distinguish act/display name, legal contracting party, representative/contact, and actual acknowledgement signer.
- Payment method is required; payment timing/method are shown inside Compensation Terms.
- Production Responsibilities require explicit Yes/No for Stage, House Sound / PA, Stage Lighting, and Sound Engineer.
- Venue-provided House Sound / PA covers Venue-confirmed standard microphones/stands, DI boxes, monitor wedges, and ordinary house audio cabling for the agreed input list; Vendor supplies IEM hardware and specialty/wireless gear unless accepted in writing.
- Attendance bonuses use qualifying paid tickets only; discounted paid tickets count, free/comps/refunds/cancellations/known chargebacks/non-revenue admissions do not; highest threshold reached controls and tiers are not cumulative.

## Architecture note

Agreement-specific identity, production responsibilities, and Production Schedule remain Agreements-owned Event Plan metadata so they can be snapshotted and compared for staleness. Final payment method remains VMS Core compensation truth.

## Validation

Use `docs/TEST-PLAN-0.3.48.md` for focused release checks and `docs/CODEX-HANDOFF-0.3.48.md` for the version-specific summary.
