# VMS Agreements 0.3.19 Test Plan - Bonus Wording Polish

## Scope

This pass keeps the 0.3.18 activation hotfix and only changes generated compensation-summary wording for Base + attendance/ticket-sales bonus structures.

## Preconditions

- VMS Core is active.
- VMS Agreements 0.3.19 is installed as the only active VMS Agreements plugin directory.
- Test with an Event Plan using Base + Attendance Bonus / ticket-sales bonus:
  - Base fee: $1,500.00
  - Start/threshold: 100
  - Step size: 50
  - Step bonus: $250.00

## Activation Smoke Test

1. Deactivate VMS Agreements.
2. Activate VMS Agreements 0.3.19.
3. Confirm activation does not fatal.
4. Confirm `vms-agreements-build.txt` reports 0.3.19.
5. Confirm the Agreements admin page loads.

## Bonus Wording Test

1. Open an eligible Event Plan with the pay structure above.
2. Generate or regenerate the agreement packet.
3. Review **Agreement Text Preview**.
4. Confirm the compensation line uses concise paid-ticket-sales wording, for example:

   `Base fee: $1,500.00; Bonus: No bonus is earned through 100 paid ticket sales. Add $250.00 every 50 paid ticket sales after that.`

5. Confirm the wording does not imply a bonus is paid at 100.
6. Confirm the wording says **paid ticket sales**, not generic attendees, unless the source terms explicitly define a different count basis.

## Regression Checks

- Existing packet viewer still loads.
- Vendor review link still loads.
- Deposit summary is unchanged.
- Payment timing summary is unchanged.
- Acknowledgement checkbox and audit/proof records are unchanged.
- Operator Agreement Queue still loads.

## Notes for Codex

Codex may make small, directly-related repairs found during testing if they are necessary to complete this test pass. If code changes are made, update the plugin version, `VMSA_VERSION`, `vms-agreements-build.txt`, changelog, and package name consistently.
