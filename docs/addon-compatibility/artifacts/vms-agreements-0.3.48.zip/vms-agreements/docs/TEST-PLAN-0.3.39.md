# VMS Agreements 0.3.39 Test Plan

## Vendor review formatting
1. Open a current vendor review packet.
2. Confirm Agreement Text headings such as Agreement Packet Scope, Event Details, Vendor Details, Compensation Terms, Production Responsibilities, Performance / Live-Band Commitment, Weather / Safety Cancellation, Payment Timing, and Governing Law / Dispute Resolution are bold.
3. Confirm ordinary clause body text remains normal weight.
4. Confirm generated Bonus payout schedule and Payment summary subheads are bold.
5. Confirm the wording itself is unchanged.

## Print / PDF identity
1. Open Print / Save as PDF for a multi-page packet.
2. Confirm each printed page carries the same small footer identifying event name, event date, packet ID, and agreement version.
3. Confirm the footer stays in the page margin and does not obscure agreement content.

## Regression
- Existing packet current/stale status is unchanged.
- Terms and compensation hashes are unchanged.
- Acknowledgement submission and proof remain unchanged.
- Agreement Setup and production/identity persistence remain unchanged.
