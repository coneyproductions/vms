# VMS Agreements 0.3.21 Test Plan — Print Bonus Payout Table

## Purpose
Verify that the printable/vendor agreement copy includes the same bonus payout schedule table whenever the compensation summary says the bonus uses a payout table.

## Preconditions
- VMS Core active.
- VMS Agreements 0.3.21 active.
- An Event Plan exists with compensation structure **Base + Attendance Bonus** / step bonus.
- Example fixture:
  - Base fee: $1,500.00
  - No bonus through: 100 paid ticket sales
  - Step: $250.00 per 50 paid ticket sales after that

## Activation smoke
1. Upload and activate the plugin zip.
2. Confirm activation does not trigger a fatal error.
3. Confirm `vms-agreements-build.txt` reports `0.3.21` and `print-bonus-payout-table`.

## Packet generation / admin review
1. Generate or regenerate an agreement packet from the fixture Event Plan.
2. Open the packet admin screen.
3. Confirm the compensation area still shows the bonus payout schedule table.
4. Confirm the table header says **Paid ticket sales**, not generic attendees, unless the Event Plan explicitly stores a different count basis.

## Public/vendor review page
1. Open the vendor review link.
2. Confirm Booking Summary shows the compensation summary and the bonus payout schedule table.
3. Confirm the table makes 100 base-only and 150 the first bonus payout:

| Paid ticket sales | Payout |
|---:|---:|
| 100 | $1,500.00 |
| 150 | $1,750.00 |
| 200 | $2,000.00 |
| 250 | $2,250.00 |
| 300 | $2,500.00 |
| 350 | $2,750.00 |

## Print / Save as PDF view
1. Click **Print / Save as PDF** from the vendor review page, or open the review URL with `vmsa_print=1`.
2. In **Booking & Payment Summary**, confirm the Payment section no longer says “see payout table below” without an actual table.
3. Confirm the **Bonus payout schedule** table appears below the summary grid and before **Agreement Terms**.
4. Print/save to PDF and confirm the table is included in the saved output.

## Flat-fee regression
1. Generate a flat-fee-only packet.
2. Confirm no empty bonus payout table appears in admin, vendor review, or print/PDF view.
