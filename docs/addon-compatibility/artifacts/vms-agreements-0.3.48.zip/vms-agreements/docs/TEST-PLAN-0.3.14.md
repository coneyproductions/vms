# VMS Agreements 0.3.14 Test Plan - Agreement Language Polish

## Build Under Test

- VMS Core: `0.2.24.570+`
- VMS Agreements: `0.3.14-agreement-language-polish`
- Plugin folder must remain: `vms-agreements`

## 🚨 Codex Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small, Codex must update all relevant version markers and packaging docs in the same pass before returning a repaired zip.

At minimum, update:

1. Plugin header version.
2. Version constants.
3. Build file.
4. Changelog/build notes.
5. Test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale version numbers or stale build notes.

## 1. Install / Build Metadata

1. Install/replace VMS Core `0.2.24.570+`.
2. Install/replace VMS Agreements `0.3.14`.
3. Confirm the installed folder is exactly `vms-agreements`.
4. Confirm the plugin header reports `0.3.14`.
5. Confirm `VMSA_VERSION` reports `0.3.14`.
6. Confirm `vms-agreements-build.txt` contains:

```text
0.3.14
agreement-language-polish
```

## 2. PHP Lint

Run PHP lint against all plugin PHP files:

```bash
find wp-content/plugins/vms-agreements -name '*.php' -print0 | xargs -0 -n1 php -l
```

Expected: no syntax errors.

## 3. Default Template Language Migration

On a site with the stock/default 0.3.13 agreement template:

1. Open **VMS > Agreements** as an admin.
2. Confirm the default template clauses are updated to the 0.3.14 wording.
3. Confirm the template version increments when stock language is migrated.
4. Confirm the Template Health Check still passes or remains usable without new errors.
5. Confirm the updated clauses include clearer wording for:
   - Cancellation / Event Viability
   - Payment Timing
   - Technical / Hospitality Rider Handling
   - No-show / Nonperformance
   - Venue Rules / Expectations
   - Acknowledgement & Audit Record

Expected: unchanged stock language is upgraded, but the editor remains usable.

## 4. Customized Template Preservation

If practical, create a temporary custom edit before upgrade or use a fixture with customized clause text.

1. Confirm a customized clause does not get overwritten by the 0.3.14 migration.
2. Confirm missing required blocks still get normalized by the existing template sanitizer.
3. Confirm customized email templates do not get overwritten unless they exactly match known stock 0.3.2 or 0.3.13 defaults.

Expected: operator-customized wording is preserved.

## 5. New Packet Language

1. Generate a fresh agreement packet from a valid upcoming Event Plan with a primary vendor.
2. Open the admin packet viewer.
3. Confirm the Agreement Text uses the polished 0.3.14 clause language.
4. Confirm the Booking Summary still shows event/vendor/payment/deposit data correctly.
5. Confirm no raw placeholder text remains, including the old sentence about clauses being expanded later.
6. Confirm flat-fee cleanup still displays clean wording such as `Flat fee: $600.00`.

## 6. Public Review / Print Language

1. Open the secure vendor review link for the fresh packet.
2. Confirm the public review page renders the polished clauses without fatal errors.
3. Confirm acknowledgement checkbox labels use the polished wording.
4. Open **Print / Save PDF**.
5. Confirm the print shell still renders as the standalone print view and includes the polished language.

## 7. Email Default Language

Using a stock/default email template:

1. Send the review-link email from the admin packet viewer or operator queue.
2. Confirm Mailpit receives the email.
3. Confirm the email includes the clearer 0.3.14 wording and still includes the secure `{review_link}` output.
4. Submit the acknowledgement form.
5. Confirm the acknowledgement confirmation email arrives and includes the updated “keep this email for your records” wording plus acknowledgement proof.

## 8. Existing Workflow Regressions

Confirm unchanged behavior for:

1. Operator Agreement Queue rendering and bucket counts.
2. Queue Email Review / Resend behavior and 0.3.12 delivery guardrails.
3. Public review link open path `generated/sent -> viewed`.
4. Public acknowledgement submit path `viewed -> acknowledged`.
5. Acknowledgement proof display on public page and admin packet viewer.
6. Vendor portal Agreements tab and collapsed Agreement History.
7. Historical superseded/voided tokenized links returning unavailable/403.

## 9. Failure Guardrail Spot Check

Repeat the 0.3.12-style intercepted `pre_wp_mail` check from either the queue or packet viewer if practical.

Expected:

- Intercepted review-link email stays unsent/generated.
- No false successful sent state is recorded.
- Diagnostics/error details remain visible in the admin packet viewer.

## 10. Report Back

Report:

- Whether stock language migrated correctly.
- Whether customized language was preserved.
- Whether fresh packet text, public review, print, emails, and acknowledgement still work.
- Any code changes made, including required version/build/doc updates if repairs were needed.
