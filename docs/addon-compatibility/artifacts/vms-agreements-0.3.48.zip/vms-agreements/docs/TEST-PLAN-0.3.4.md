# VMS Agreements 0.3.4 Test Plan - Final Payment Method and Summary Cleanup

## Prerequisite
Install VMS Core 0.2.24.568 or newer.

## Manual test steps

1. Open a future Event Plan in VMS Core and set compensation, deposit/advance, Expected Final Payment, and Payment Method.
2. Select `ACH / Direct Deposit` as the Payment Method.
3. Save the Event Plan.
4. Generate a fresh agreement packet from VMS Agreements.
5. Confirm the vendor-facing Booking Summary does not show internal Event Plan publication/status.
6. Confirm the vendor-facing Compensation card shows payment summary lines, including expected final payment timing and payment method.
7. Confirm the agreement text preview shows payment summary as readable lines instead of one long paragraph.
8. Email the vendor review link and confirm the email payment summary is readable on mobile.
9. Acknowledge the packet and confirm the acknowledgement confirmation email still sends.
10. Regenerate/supersede guardrails should still behave as before.

## Expected result
Agreement packets consume VMS Core final payment timing/method data and present a simpler vendor-facing payment summary without changing token, acknowledgement, or regeneration behavior.

## Codex failure/version instructions
If a test fails, document the failure, fix the smallest durable root cause, re-run the failed test plus an adjacent regression test, and package a complete replacement zip. If Codex edits code, update the plugin header version, `VMSA_VERSION`, `vms-agreements-build.txt`, changelog, README/handoff as applicable, relevant test plan docs, and package filename in the same pass. If only docs change, do not bump the runtime version unless behavior changed.
