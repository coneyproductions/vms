# VMS Agreements 0.2.3 Test Plan - Generation Eligibility + Title Cleanup

## Purpose

Verify that cancelled/past Event Plans cannot generate new agreement packets, repeated titles are cleaned up, and odd punctuation characters no longer appear in the admin/vendor agreement UI.

## Preconditions

- VMS Core `0.2.24.567` or newer is active.
- VMS Agreements `0.2.3` is active.
- At least one upcoming, non-cancelled Event Plan exists with a primary vendor.
- At least one past Event Plan or cancelled Event Plan exists.

## Tests

### 1. Generate dropdown eligibility

1. Open **VMS -> Planning -> Agreements**.
2. Open the **Generate Packet** dropdown.
3. Confirm upcoming, non-cancelled Event Plans with a primary vendor are available.
4. Confirm past Event Plans are not listed.
5. Confirm cancelled Event Plans are not listed.
6. Confirm Event Plans without a primary vendor are not listed.

Expected: only upcoming, non-cancelled Event Plans with a primary vendor are selectable.

### 2. Direct generation guardrail

1. From a past or cancelled Event Plan, attempt to use any existing Generate Packet / Regenerate link if one is visible.
2. Or manually revisit an older admin-post generation URL for that Event Plan.

Expected: generation is blocked and the admin is redirected with a clear notice. No new packet is created.

### 3. Event Plan metabox messaging

1. Open a past Event Plan with a prior agreement packet.
2. Confirm existing packet history can still be viewed.
3. Confirm the metabox does not offer casual new generation/regeneration.
4. Confirm the metabox explains that new packet generation is closed for cancelled/past Event Plans.

Expected: history remains available, but new packet creation is blocked.

### 4. Packet viewer guardrail

1. Open an existing packet for a past or cancelled Event Plan.
2. Confirm the packet can still be viewed.
3. Confirm the viewer explains that new packet generation is closed for cancelled/past Event Plans.
4. Confirm Void Packet remains available where appropriate.

Expected: existing records are preserved; new packet generation is not offered.

### 5. Repeated title cleanup

1. Generate a packet for an Event Plan where the Event Plan title and primary vendor title are identical.
2. Open the packet viewer and Recent Packets table.

Expected: the title appears once, not as `Name - Name`.

### 6. Character rendering cleanup

1. Review the admin packet viewer, Recent Packets table, public vendor review page, email preview/received email, and acknowledgement proof.
2. Look for mojibake/crazy-character sequences such as `â`, `â€”`, or similar.

Expected: UI output uses plain ASCII hyphens/placeholders and does not show encoding garbage.

## Notes

This pass intentionally does not change packet snapshots, acknowledgement records, token behavior, email delivery behavior, or review-link guardrails except blocking new generation for cancelled/past Event Plans.
