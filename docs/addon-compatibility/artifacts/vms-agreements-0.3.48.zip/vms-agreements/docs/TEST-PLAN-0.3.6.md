# VMS Agreements 0.3.6 Test Plan - Printable Copy Cleanup

## Purpose

Validate that printable agreement copies are compact, complete, and isolated from theme/footer content.

## Preconditions

1. VMS Core 0.2.24.568+ is active.
2. VMS Agreements 0.3.6 is installed and active.
3. At least one current agreement packet exists with event, vendor, compensation, deposit/advance, final payment timing, and payment method data.

## Tests

### 1. Admin print link opens compact print route

1. Open VMS > Planning > Agreements.
2. Open a current packet.
3. Click Print / Save PDF.

Expected:
- The page opens in a standalone print shell.
- Normal site header/footer is not present.
- Internal status pills such as Generated / Current are not shown in the printable copy.
- The top action buttons are visible on screen but not printed.

### 2. Printable summary includes required data

Expected:
- Booking & Payment Summary includes event title, date, time, venue, vendor name, vendor email, vendor phone, pay terms, deposit/advance summary, and payment summary.
- Payment summary includes total agreed payment, deposit/advance, remaining final payment, final payment timing, and payment method when available in the packet snapshot.

### 3. Printable agreement text is deduplicated

Expected:
- The printable copy does not repeat the protected Event Details, Vendor Details, Compensation Terms, and Deposit / Advance Terms blocks again inside Agreement Terms.
- Agreement Terms still includes editable clauses such as cancellation/event viability, payment timing, rider handling, no-show/nonperformance, venue rules/expectations if enabled, custom terms if enabled, and audit disclosure.

### 4. PDF output is compact

1. Use browser print/save-as-PDF.
2. Save a PDF.
3. Review page count and content.

Expected:
- Normal short agreement packets should generally fit in one to two pages.
- Text size should feel like a document, not a mobile webpage.
- No photo galleries, site footer content, unrelated page content, or theme promotional blocks appear after the agreement copy.

### 5. Unacknowledged and acknowledged states

Expected before acknowledgement:
- Printable copy clearly says acknowledgement proof has not been recorded yet.

Expected after acknowledgement:
- Printable copy includes signer, signer email, acknowledged timestamp, IP address, agreement version, terms hash, compensation hash, and per-checkbox acknowledgement proof.

### 6. Regression checks

Confirm unchanged behavior:
- Public vendor review page still renders normally.
- Vendor acknowledgement submission still works.
- Review-link email delivery still works.
- Confirmation email still works.
- Stale/voided/superseded packet guardrails still work.
- Packet regeneration still preserves old packet history.

## Failure / version protocol

If a test fails, document the failure, fix the smallest durable root cause, rerun the failed test plus adjacent regression checks, and package a complete replacement zip. If Codex edits code, update the plugin header version, `VMSA_VERSION`, `vms-agreements-build.txt`, changelog, README/handoff as applicable, relevant test plan docs, and package filename in the same pass. If only docs change, do not bump the runtime version unless behavior changed.
