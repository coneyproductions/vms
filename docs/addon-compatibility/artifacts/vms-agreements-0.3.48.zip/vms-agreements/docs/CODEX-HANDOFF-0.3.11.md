# CODEX HANDOFF - VMS Agreements 0.3.11 Vendor Portal History Cleanup

## Package

- Plugin: `vms-agreements`
- Version: `0.3.11`
- Package target: `vms-agreements-0.3.11-vendor-portal-history-cleanup.zip`
- Required VMS Core: `0.2.24.570+`

## Purpose

0.3.11 cleans up the vendor-facing Agreements tab after the native portal integration in 0.3.10. The main goal is to keep current/actionable packets easy to find while preserving superseded and voided packet history.

## What Changed

- Superseded and voided vendor portal packets now move into a default-collapsed **Agreement History** section.
- Historical packets render as compact cards.
- Current/actionable packets remain expanded.
- Vendors can open Agreement History when they need to inspect older records.
- Flat-fee compensation wording is cleaner for new summaries.
- Older stored packet summaries are display-cleaned so `Flat fee; Base/flat: $1,500.00` becomes `Flat fee: $1,500.00` without requiring regeneration.
- Public review and print summary labels use `Event name` to avoid the duplicate `Event Event Test Band` visual/text issue.

## Guardrails Preserved

- No packet schema change.
- No hard-delete behavior added.
- No acknowledgement record change.
- No review token validation change.
- No email send/resend flow change.
- No packet regeneration/supersede/void workflow change.
- No public print shell routing change.

## Testing

🚨 Run `docs/TEST-PLAN-0.3.11.md` with VMS Core `0.2.24.570+` before considering this build validated.

## 🚨 Codex Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small:

1. Update the plugin header version.
2. Update all version constants.
3. Update `vms-agreements-build.txt`.
4. Update `docs/CHANGELOG.md` and any relevant build notes.
5. Update or add the relevant test plan notes.
6. Update this Codex handoff with the repair summary.
7. Rename the package zip to the new version/build slug.

Do not return a modified plugin zip with stale version numbers, stale build notes, or a stale package filename.
