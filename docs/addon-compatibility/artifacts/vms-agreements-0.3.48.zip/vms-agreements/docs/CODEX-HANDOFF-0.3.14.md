# Codex Handoff - VMS Agreements 0.3.14

## Build

- Plugin: `vms-agreements`
- Version: `0.3.14`
- Build label: `agreement-language-polish`
- Requires VMS Core: `0.2.24.570+`

## Purpose

This pass polishes default vendor-facing agreement language now that packet generation, email delivery, vendor portal visibility, history collapse, and the operator queue are validated.

## What Changed

- Updated stock default agreement clause wording for:
  - Cancellation / Event Viability
  - Payment Timing
  - Technical / Hospitality Rider Handling
  - No-show / Nonperformance
  - Venue Rules / Expectations
  - Acknowledgement & Audit Record
- Updated stock acknowledgement checkbox labels to be more plain-English and less raw-hash-focused.
- Updated stock Review Link Email and Acknowledgement Confirmation Email copy.
- Added a safe migration for unchanged stock 0.3.13 template clauses and acknowledgement labels.
- Added a safe migration for unchanged stock 0.3.2 and 0.3.13 email templates.
- Template version is bumped when stock agreement language is migrated, so stale-packet detection can still reflect changed default terms.

## What Did Not Change

- No packet schema changes.
- No review-token validation changes.
- No acknowledgement submission changes.
- No review-link email delivery mechanics or diagnostics changes.
- No operator queue behavior changes.
- No vendor portal behavior changes.
- No public print layout changes.
- No automated reminders.
- No hard-delete cleanup for test packets.

## Files Changed

- `vms-agreements.php`
- `includes/cpt.php`
- `includes/template-blocks.php`
- `includes/email-templates.php`
- `vms-agreements-build.txt`
- `docs/CHANGELOG.md`
- `docs/HANDOFF.md`
- `docs/README.md`
- `docs/TEST-PLAN-0.3.14.md`
- `docs/CODEX-HANDOFF-0.3.14.md`

## Required Test Plan

Run:

- `docs/TEST-PLAN-0.3.14.md`

## 🚨 Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small, Codex must update all relevant version markers and packaging docs in the same pass before returning a repaired zip.

At minimum, update:

1. Plugin header version.
2. `VMSA_VERSION`.
3. `vms-agreements-build.txt`.
4. `docs/CHANGELOG.md`.
5. Relevant test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale version numbers or stale build notes.
