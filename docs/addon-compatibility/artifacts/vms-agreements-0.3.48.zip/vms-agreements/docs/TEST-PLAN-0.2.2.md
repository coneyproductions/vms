# VMS Agreements 0.2.2 Test Plan — Email Review Link Foundation

## Purpose

Verify that agreement review links can be emailed to the vendor from the packet viewer, with safe guardrails and audit tracking.

## Preconditions

- VMS Core `0.2.24.567` or newer is active.
- VMS Agreements `0.2.2` is active.
- An Event Plan exists with a primary vendor.
- The primary vendor has an email address saved in the vendor profile before the packet is generated.
- A current agreement packet has been generated for that Event Plan/vendor.

## Tests

### 1. Email button appears

1. Open **VMS → Planning → Agreements**.
2. Open a current, non-stale agreement packet.
3. Confirm the **Vendor Review Link** card includes **Email Review Link**.
4. Confirm the destination vendor email is shown.

Expected: the admin can see where the email will be sent before sending.

### 2. Send review email

1. Click **Email Review Link to Vendor**.
2. Confirm the page redirects back to the packet viewer.
3. Confirm the success notice appears.
4. Confirm packet status changes from **Generated** to **Sent** if it had not been viewed yet.
5. Confirm **Last sent** and **Send count** appear in the Vendor Review Link card.
6. Confirm the Audit Trail shows a review email send record.

Expected: the email send is recorded and the packet remains active/current.

### 3. Resend review email

1. Click **Resend Review Link Email**.
2. Confirm the send count increments.
3. Confirm the Audit Trail includes another email send record.

Expected: resending does not regenerate the packet and does not invalidate the existing link.

### 4. Vendor opens emailed link

1. Open the emailed review link in a private/incognito browser.
2. Confirm the vendor-facing agreement page loads.
3. Confirm packet status changes to **Viewed**.
4. Submit the acknowledgement form as in the `0.2.1` test plan.

Expected: the prior acknowledgement flow still works after email delivery.

### 5. Stale packet guardrail

1. Make a material Event Plan change that makes the packet stale.
2. Return to the packet viewer.
3. Confirm the email action is disabled or blocked.
4. Attempt the email action if possible.

Expected: stale packets cannot be emailed; a fresh packet must be generated first.

### 6. Inactive packet guardrail

1. Void or supersede a packet.
2. Confirm no active email action is available.

Expected: voided/superseded packets cannot be emailed.

### 7. Missing vendor email

1. Generate a packet for a vendor without an email address.
2. Open the packet viewer.

Expected: the Email Review Link area clearly explains that no vendor email is available and does not send.

## Notes

This version intentionally does not add editable email templates, automated reminders, or vendor portal agreement lists. Those should be separate future passes after the basic send/resend audit flow is verified.
