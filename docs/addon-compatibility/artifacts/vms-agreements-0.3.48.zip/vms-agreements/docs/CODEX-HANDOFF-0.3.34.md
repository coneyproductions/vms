# Codex Handoff — VMS Agreements 0.3.34

## Package

`vms-agreements-0.3.34-contract-language-hardening.zip`

## Goal

Make the current Agreement Packet materially safer to send for the September 2026 Reputation booking without waiting on the broader VMS Core production-responsibility workflow.

## Decisions implemented

- Contracting identity is an operator setting and is snapshotted/hash-covered in new packets. Serenade Range should set it to `Coney Productions LLC d/b/a Serenade Range`.
- Standard final-payment fallback is operator-configurable and defaults to 5 calendar days after performance; explicit Event Plan final-payment timing still wins. The chosen fallback is snapshotted into each new packet.
- Attendance-bonus thresholds default to qualifying paid ticket sales. Discounted paid tickets count; free/comps, refunded/cancelled tickets, known chargebacks at settlement, staff/vendor/non-revenue admissions do not. Highest threshold wins; tiers are not cumulative.
- Live-band performance is a required clause. Tracks may supplement but may not replace the live band or reduce the booked presentation to solo/karaoke-style/predominantly pre-recorded performance without written approval.
- Weather/safety cancellation separates rain/electrical safety from event viability. Current stock wording provides 0% base guarantee before Vendor arrival, 50% after timely arrival/ready-to-perform but before performance, and 100% once performance begins.
- Event-viability cancellation is separate: no base guarantee at 7+ days' notice, 50% inside 7 days, 100% if the Vendor has already arrived on time and ready to perform.
- Refund/comp wording no longer reads as a direct deduction from the earned guarantee.
- Added independent-contractor/W-9, amendments, and Texas good-faith/mediation clauses.

## Deferred intentionally

Per-booking Yes/No production responsibilities (stage, sound/PA, lighting, sound engineer, etc.) should live in VMS Core and be required/confirmed before Agreements generation. 0.3.34 tightens the rider clause so only expressly documented or written-accepted production commitments bind the Venue, but it does not invent duplicate Agreements-only production fields.

## Upgrade behavior

- `vmsa_agreement_language_defaults_version` advances to `0.3.34`.
- Stock 0.3.33 clause bodies are recognized as legacy defaults and upgraded.
- Customized editable clause bodies are preserved.
- Missing newly-required blocks are merged into the default template and the template version/health metadata is refreshed.
- Existing packet snapshots are not rewritten. Generate a fresh packet to obtain the new terms.
