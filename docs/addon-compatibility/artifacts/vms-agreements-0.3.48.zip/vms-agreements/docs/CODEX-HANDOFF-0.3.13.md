# Codex Handoff - VMS Agreements 0.3.13

## Build

- Plugin: `vms-agreements`
- Version: `0.3.13`
- Build label: `operator-agreement-queue`
- Requires VMS Core: `0.2.24.570+`

## Purpose

This pass adds an operator-facing agreement queue to the existing VMS Agreements admin page. The queue is intended to answer: which agreement packets still need attention?

## What Changed

- Added **Operator Agreement Queue** above the existing **Recent Packets** table.
- Added queue buckets for:
  - Stale / Needs Regeneration
  - Generated - Not Sent
  - Sent - Not Viewed
  - Viewed - Not Acknowledged
  - Acknowledged
  - Superseded / Voided History
- Added summary count pills for each bucket.
- Active follow-up sections open by default.
- Acknowledged and history sections are collapsed by default.
- Queue rows show packet, event, vendor, status, terms state, last activity, and actions.
- Queue actions include Open Packet, Event Plan, Email/Resend Review, and Print/PDF where safe.
- Stale packets do not expose email actions from the queue; operators are directed to open the packet and regenerate safely.
- Superseded/voided packets remain historical-only from the queue.
- Added admin CSS for the queue and responsive table behavior.
- Added a guided tour step for the operator queue.

## What Did Not Change

- No packet schema changes.
- No review-token validation changes.
- No acknowledgement submission changes.
- No vendor portal behavior changes.
- No public print rendering changes.
- No review-link email send handler changes beyond reusing the existing 0.3.12 admin-post handler from queue buttons.
- No automated reminders.
- No hard-delete cleanup for test packets.

## Files Changed

- `vms-agreements.php`
- `includes/admin.php`
- `assets/admin.css`
- `vms-agreements-build.txt`
- `docs/CHANGELOG.md`
- `docs/HANDOFF.md`
- `docs/README.md`
- `docs/TEST-PLAN-0.3.13.md`
- `docs/CODEX-HANDOFF-0.3.13.md`

## Required Test Plan

Run:

- `docs/TEST-PLAN-0.3.13.md`

## 🚨 Repair / Versioning Protocol

If testing reveals a defect and Codex makes any code change, no matter how small, Codex must update all relevant version markers and packaging docs in the same pass before returning a repaired zip.

At minimum, update:

1. Plugin header version.
2. `VMSA_VERSION`.
3. `vms-agreements-build.txt`.
4. `docs/CHANGELOG.md`.
5. Relevant test plan and/or Codex handoff notes.
6. Package filename.

Do not return a modified plugin zip with stale version numbers or stale build notes.
