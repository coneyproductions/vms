# Codex Handoff — VMS Agreements 0.3.33

## Package

`vms-agreements-0.3.33-public-review-cache-safety.zip`

## Goal

Close the main Agreements go-live regression from production smoke: public review links must show fresh current vs stale packet state on the same plain URL without manual cache-busting.

## Key changes

- Version bumped to `0.3.33` in:
  - `vms-agreements.php` plugin header
  - `VMSA_VERSION`
  - `vms-agreements-build.txt`
- `includes/public.php`
  - bootstraps cache-safety for public review and acknowledgement requests before render
  - reapplies explicit no-cache headers on send-headers and acknowledgement responses
  - refreshes the linked Event Plan cache before computing public current/stale packet state
- `includes/helpers.php`
  - strengthens cache bypass flags and response headers for public requests
- `includes/vendor-portal.php`
  - adds a separate `Signed history` count so the portal no longer under-reports acknowledged history when no active packet exists

## Local smoke coverage

Fixture IDs used locally:

- Vendor `2175`
- Event Plan `2176`
- Packets exercised:
  - `2182` same-URL stale/current regression check
  - `2184` send/resend/acknowledgement/notification/print
  - `2185` generated cleanup candidate

Observed results:

- Plain public review URL for `2182` rendered `Current`.
- After changing Event Plan `2176`, the exact same `2182` review URL immediately rendered the stale warning with no extra query param.
- Preview did not send email.
- `2184` send/resend recorded `generated -> sent` then `sent -> sent`, and Mailpit captured both review-link emails to the controlled test address.
- Public acknowledgement for `2184` succeeded through `admin-post.php`, redirected with `vmsa_notice=acknowledged`, stored the iPhone Safari UA string, sent the signer confirmation email, and sent the operator signed-notification email to `dev-email@wpengine.local`.
- Vendor portal/admin surfaces were clear both with an active packet and in a history-only state after cleanup.
- History cleanup deleted stale unsigned packets `2182` and `2183`, unacknowledged cleanup deleted generated packet `2185`, and signed history `2177`, `2178`, and `2184` was preserved.
- Guardrails blocked new packet generation for past Event Plan `2186` and cancelled Event Plan `2187`.
- Public review, vendor portal HTML, admin surfaces, and print/PDF output showed no mojibake in this smoke pass.

## Notes

- The Chrome headless print smoke wrote `/tmp/vmsa-2184-print.pdf` successfully and produced a 3-page PDF.
- The local fixture was returned to a safe history-only state after smoke:
  - Event Plan `2176` title restored
  - Vendor `2175` email restored to `codex-vmsa-smoke+2306@example.com`
  - Remaining packets: `2184`, `2178`, `2177`
