# VMS Agreements 0.3.33 Test Plan — Public Review Cache Safety

## Scope

This patch is limited to public agreement review freshness and the low-risk vendor portal signed-history count fix.

## What changed

- Public agreement review and acknowledgement responses now set stronger no-cache headers and cache-bypass flags.
- Public review refreshes linked Event Plan state before computing current vs stale packet terms.
- Vendor portal counts now show `Current signed` and `Signed history` separately.

## Manual test steps

1. Install and activate `vms-agreements-0.3.33-public-review-cache-safety.zip`.
2. Confirm version markers:
   - plugin header `0.3.33`
   - `VMSA_VERSION` `0.3.33`
   - `vms-agreements-build.txt` label `public-review-cache-safety`
3. Use a safe upcoming Event Plan linked to a safe test vendor.
4. Generate a packet and copy the plain public review URL.
5. Open the plain public review URL and confirm:
   - packet renders successfully
   - header/status shows `Current`
   - no email is sent
   - response headers include no-cache / no-store directives
6. Change the linked Event Plan in a contract-significant way such as title, date, or time.
7. Re-open the exact same plain public review URL without adding a cache-busting query string.
8. Confirm the stale warning appears immediately.
9. Generate a fresh packet from the updated Event Plan.
10. Send the review link to a controlled internal/test email address only.
11. Confirm:
    - first send records `status_before=generated`
    - resend records `status_before=sent`
    - packet status remains `sent` after resend
    - send count increments
12. Open the fresh public review URL and submit acknowledgement.
13. Confirm:
    - acknowledgement succeeds
    - signer confirmation email is sent
    - operator signed-notification email is sent to the configured recipient(s)
    - packet status becomes `acknowledged`
14. Confirm print view renders cleanly and browser PDF output is acceptable.
15. Confirm public review, vendor portal, and admin surfaces show no mojibake or broken punctuation.

## Status-surface checks

1. With a current active packet, confirm:
   - Event Plan shows `View Current Packet`
   - vendor portal shows `Current signed` and `Signed history`
2. Remove the active packet safely so only historical signed packets remain.
3. Confirm:
   - Event Plan switches to `View Latest Packet`
   - Event Plan explains that no current packet is active
   - vendor portal still shows non-zero `Signed history`
   - vendor portal no longer under-reports acknowledged history in the history-only state

## Cleanup and guardrail checks

1. Create at least one stale/history unsigned packet and one generated/not-sent packet.
2. Run history cleanup and confirm unsigned stale/history packets are deleted.
3. Run unacknowledged cleanup and confirm generated/sent/viewed unsigned packets are deleted.
4. Confirm acknowledged packet history is preserved.
5. Confirm cancelled and past Event Plans remain blocked from new packet generation.
