# VMS Agreements 0.3.0 Test Plan - Template Block Editor + Health Check

## Scope

This build adds a structured template editor and health check foundation. It does not change packet acknowledgement storage, review-token validation, email delivery, or packet regeneration guardrails.

## Install / Replace

1. Upload `vms-agreements-0.3.0-template-block-editor-health-check.zip` through WordPress Plugins > Add New > Upload Plugin.
2. Choose replace current plugin when prompted.
3. Confirm the plugin remains installed in the `vms-agreements` folder.
4. Confirm the active plugin version is `0.3.0`.

## Admin Template Editor

1. Go to VMS > Planning > Agreements.
2. Confirm Default Template shows:
   - Template name
   - Version
   - Block count
   - Acknowledgement count
   - Health status
   - Edit Template Blocks button
3. Click Edit Template Blocks.
4. Confirm the editor shows protected required blocks for:
   - Event details
   - Vendor details
   - Compensation terms
   - Deposit / advance terms
   - Acknowledgement proof
5. Confirm protected blocks cannot be disabled and do not expose source data as editable freeform text.
6. Confirm editable clause blocks can be edited:
   - Cancellation / Event Viability
   - Payment Timing
   - Technical / Hospitality Rider Handling
   - No-show / Nonperformance
   - Venue Rules / Expectations
   - Additional Terms
7. Save the template.
8. Confirm the template version increments by one patch version.
9. Confirm the health check refreshes after save.

## Health Check

1. Clear the body of a required editable clause such as Cancellation / Event Viability.
2. Save the template.
3. Confirm the health check flags the empty required clause.
4. Try generating a packet and confirm generation is blocked while the template has health-check errors.
5. Restore the clause text and save again.
6. Confirm the health check returns to Passed or Usable with warnings.
7. Edit the audit disclosure and remove references to IP or hash.
8. Save and confirm the health check warns about missing audit concepts.
9. Restore the audit disclosure before generating real packets.

## Packet Generation

1. Generate a packet from an upcoming Event Plan with a primary vendor.
2. Confirm the packet snapshot includes the updated template version.
3. Confirm Agreement Text Preview renders structured blocks rather than the old placeholder paragraph only.
4. Confirm protected packet data appears from the Event Plan snapshot:
   - event title/date/time/venue
   - vendor name/email/phone
   - compensation summary
   - deposit / advance summary
5. Confirm editable clause wording appears in the preview.

## Public Review Page

1. Open the Vendor Review Link in an incognito/private window.
2. Confirm Booking Summary still appears as cards.
3. Confirm Agreement Text includes the structured template content and updated clause wording.
4. Confirm required acknowledgement checkboxes still render inline or near their related areas.
5. Confirm the new authorized-signer acknowledgement appears near signer/submit details.
6. Submit a completed acknowledgement.
7. Confirm proof displays after submission.
8. Confirm the admin packet viewer shows acknowledgement proof and audit trail details.

## Regression Checks

1. Existing current packet guardrail still redirects ordinary Generate attempts to the current packet.
2. Regenerate / Supersede still creates a new current packet only when deliberately selected.
3. Voided/superseded packets still cannot be reviewed publicly.
4. Stale packets still cannot be acknowledged.
5. Email Review Link still sends to vendor email and records send audit details.
6. Past/cancelled Event Plans still cannot generate new packets.

## Notes

- This build intentionally does not add PDF generation, automated reminders, vendor portal agreement cards, or clause bypass workflow.
- Existing packets keep their previously captured template snapshot and version.
