<?php
/**
 * Plugin Name: VMS Agreements
 * Plugin URI: https://booklivetalent.com/
 * Description: Premium agreement packet add-on for Venue Management System. Captures Event Plan booking terms, compensation snapshots, deposit terms, and acknowledgement audit records.
 * Version: 0.3.48
 * Author: Book Live Talent
 * Author URI: https://booklivetalent.com/
 * Text Domain: vms-agreements
 * Requires at least: 6.5
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('VMSA_VERSION')) {
    define('VMSA_VERSION', '0.3.48');
}

if (!defined('VMSA_MIN_VMS_VERSION')) {
    define('VMSA_MIN_VMS_VERSION', '0.2.24.570');
}

if (!defined('VMSA_PLUGIN_FILE')) {
    define('VMSA_PLUGIN_FILE', __FILE__);
}

if (!defined('VMSA_PLUGIN_DIR')) {
    define('VMSA_PLUGIN_DIR', plugin_dir_path(__FILE__));
}

if (!defined('VMSA_PLUGIN_URL')) {
    define('VMSA_PLUGIN_URL', plugin_dir_url(__FILE__));
}

require_once VMSA_PLUGIN_DIR . 'includes/helpers.php';
require_once VMSA_PLUGIN_DIR . 'includes/template-blocks.php';
require_once VMSA_PLUGIN_DIR . 'includes/email-templates.php';
require_once VMSA_PLUGIN_DIR . 'includes/cpt.php';
require_once VMSA_PLUGIN_DIR . 'includes/snapshots.php';
require_once VMSA_PLUGIN_DIR . 'includes/admin.php';
require_once VMSA_PLUGIN_DIR . 'includes/metaboxes.php';
require_once VMSA_PLUGIN_DIR . 'includes/public.php';
require_once VMSA_PLUGIN_DIR . 'includes/vendor-portal.php';

add_action('init', 'vmsa_load_textdomain', 1);
add_action('init', 'vmsa_register_post_types', 8);
add_action('admin_init', 'vmsa_maybe_ensure_default_template');
add_action('admin_init', 'vmsa_maybe_upgrade_email_template_defaults', 12);
add_action('admin_init', 'vmsa_maybe_upgrade_agreement_language_defaults', 13);
add_action('admin_notices', 'vmsa_render_dependency_notice');

register_activation_hook(__FILE__, 'vmsa_activate');

function vmsa_load_textdomain(): void
{
    load_plugin_textdomain('vms-agreements', false, dirname(plugin_basename(__FILE__)) . '/languages');
}

function vmsa_activate(): void
{
    // Keep activation intentionally light. Default-template creation already runs
    // from admin_init for managers, and doing it here can turn ordinary plugin
    // activation into a heavier write path than necessary.
    vmsa_register_post_types();
    update_option('vmsa_version', VMSA_VERSION, false);
    update_option('vmsa_needs_default_template_check', '1', false);
    flush_rewrite_rules(false);
}
