<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'vmsa_register_vendor_portal_integrations', 20);
add_action('vms_vendor_portal_after_dashboard_cards', 'vmsa_render_vendor_portal_agreements_action', 30);
add_action('vms_vendor_portal_dashboard_after_cards', 'vmsa_render_vendor_portal_agreements_action', 30);
add_action('vms_vendor_portal_agreements', 'vmsa_render_vendor_portal_agreements_action', 10);
add_action('vms_vendor_portal_nav_links', 'vmsa_render_vendor_portal_nav_link', 30, 2);
add_filter('vms_vendor_portal_allowed_tabs', 'vmsa_register_vendor_portal_tab', 20);
add_filter('vms_vendor_portal_render_custom_tab', 'vmsa_render_vendor_portal_custom_tab', 30, 3);

function vmsa_register_vendor_portal_tab($tabs)
{
    if (!is_array($tabs)) {
        return $tabs;
    }

    $tabs[] = 'agreements';
    return array_values(array_unique(array_filter(array_map('sanitize_key', $tabs))));
}

function vmsa_register_vendor_portal_integrations(): void
{
    add_shortcode('vmsa_vendor_agreements', 'vmsa_render_vendor_agreements_shortcode');
}

function vmsa_render_vendor_agreements_shortcode($atts = array()): string
{
    $atts = shortcode_atts(array(
        'vendor_id' => 0,
        'limit' => 50,
        'show_history' => 'yes',
    ), is_array($atts) ? $atts : array(), 'vmsa_vendor_agreements');

    $vendor_ids = array();
    $requested_vendor_id = absint($atts['vendor_id'] ?? 0);
    if ($requested_vendor_id > 0 && current_user_can('manage_options')) {
        $vendor_ids[] = $requested_vendor_id;
    }

    return vmsa_get_vendor_portal_agreements_html(array(
        'vendor_ids' => $vendor_ids,
        'limit' => absint($atts['limit'] ?? 50),
        'show_history' => !in_array(strtolower((string) ($atts['show_history'] ?? 'yes')), array('0', 'false', 'no'), true),
    ));
}

function vmsa_render_vendor_portal_agreements_action($context = null): void
{
    static $rendered = false;

    if ($rendered) {
        return;
    }

    $rendered = true;

    $vendor_ids = vmsa_vendor_portal_vendor_ids_from_context($context);
    $html = vmsa_get_vendor_portal_agreements_html(array(
        'context' => $context,
        'vendor_ids' => $vendor_ids,
        'hide_if_empty' => true,
    ));

    if ($html !== '') {
        echo $html;
    }
}

function vmsa_render_vendor_portal_nav_link($active_tab, $portal_context = array()): void
{
    $portal_context = is_array($portal_context) ? $portal_context : array();
    $vendor_ids = vmsa_vendor_portal_vendor_ids_from_context($portal_context);

    if (empty($vendor_ids) || !vmsa_vendor_portal_has_packets($vendor_ids)) {
        return;
    }

    $base_url = isset($portal_context['base_url']) ? (string) $portal_context['base_url'] : get_permalink();
    if ($base_url === '') {
        $base_url = home_url('/');
    }

    $vendor_id = absint($portal_context['vendor_id'] ?? 0);
    $args = array('tab' => 'agreements');
    if ($vendor_id > 0) {
        $args['vendor_id'] = $vendor_id;
    }

    $preview_query_function = vmsa_core_function_name('vms_vendor_portal_get_preview_query_args');
    if (!empty($portal_context['is_preview']) && $vendor_id > 0 && $preview_query_function !== '') {
        $args = array_merge((array) $preview_query_function($vendor_id), $args);
    }

    $nav_counts = vmsa_vendor_portal_packet_counts(vmsa_get_vendor_portal_packets($vendor_ids, array('limit' => 50)));
    $needs_review = absint($nav_counts['pending'] ?? 0) + absint($nav_counts['viewed'] ?? 0);
    $label = esc_html__('Agreements', 'vms-agreements');
    if ($needs_review > 0) {
        $label .= ' <span class="vmsa-tab-badge">' . esc_html((string) $needs_review) . '</span>';
    }

    echo '<a class="' . (sanitize_key((string) $active_tab) === 'agreements' ? 'is-active' : '') . '" href="' . esc_url(add_query_arg($args, $base_url)) . '">' . wp_kses($label, array('span' => array('class' => array()))) . '</a>';
}

function vmsa_render_vendor_portal_custom_tab($rendered, $tab, $portal_context = array()): bool
{
    if ($rendered || sanitize_key((string) $tab) !== 'agreements') {
        return (bool) $rendered;
    }

    $vendor_ids = vmsa_vendor_portal_vendor_ids_from_context($portal_context);
    echo vmsa_get_vendor_portal_agreements_html(array(
        'context' => $portal_context,
        'vendor_ids' => $vendor_ids,
        'hide_if_empty' => false,
    ));

    return true;
}

function vmsa_vendor_portal_vendor_ids_from_context($context = null): array
{
    if (!is_array($context)) {
        return array();
    }

    $active_vendor_id = isset($context['vendor_id']) ? absint($context['vendor_id']) : 0;
    if ($active_vendor_id > 0) {
        return array($active_vendor_id);
    }

    if (isset($context['vendor_ids']) && is_array($context['vendor_ids'])) {
        return vmsa_normalize_id_list($context['vendor_ids']);
    }

    return array();
}

function vmsa_vendor_portal_has_packets(array $vendor_ids): bool
{
    return !empty(vmsa_get_vendor_portal_packets($vendor_ids, array('limit' => 1)));
}

function vmsa_get_vendor_portal_agreements_html(array $args = array()): string
{
    vmsa_disable_public_cache();

    if (!is_user_logged_in()) {
        return vmsa_vendor_portal_notice_html(
            __('Sign in to view agreements tied to your vendor account.', 'vms-agreements')
        );
    }

    $vendor_ids = isset($args['vendor_ids']) && is_array($args['vendor_ids'])
        ? array_values(array_filter(array_map('absint', $args['vendor_ids'])))
        : array();

    if (empty($vendor_ids)) {
        $vendor_ids = vmsa_vendor_portal_vendor_ids_from_context($args['context'] ?? null);
    }

    if (empty($vendor_ids)) {
        $vendor_ids = vmsa_get_current_user_vendor_ids();
    }

    $hide_if_empty = !empty($args['hide_if_empty']);

    if (empty($vendor_ids)) {
        return $hide_if_empty ? '' : vmsa_vendor_portal_notice_html(
            __('No linked vendor profile was found for this login yet. If you expected to see agreements here, contact the venue so they can link your account to your vendor profile.', 'vms-agreements')
        );
    }

    $limit = isset($args['limit']) ? absint($args['limit']) : 50;
    if ($limit <= 0) {
        $limit = 50;
    }

    $packets = vmsa_get_vendor_portal_packets($vendor_ids, array(
        'limit' => $limit,
    ));

    if (empty($packets) && $hide_if_empty) {
        return '';
    }
    ob_start();
    echo '<section class="vmsa-vendor-agreements" data-vms-tour="vendor.agreements">';
    echo '<div class="vmsa-vendor-agreements__header">';
    echo '<div>';
    echo '<p class="vmsa-public-kicker">' . esc_html__('Vendor Portal', 'vms-agreements') . '</p>';
    echo '<h2>' . esc_html__('Agreements', 'vms-agreements') . '</h2>';
    echo '<p>' . esc_html__('Review pending agreement packets, reopen acknowledged copies, and save printable records for your bookings.', 'vms-agreements') . '</p>';
    echo '</div>';
    $packet_groups = vmsa_partition_vendor_portal_packets($packets);
    $current_packets = (array) ($packet_groups['current'] ?? array());
    $historical_packets = (array) ($packet_groups['history'] ?? array());
    vmsa_render_vendor_portal_counts($current_packets, $historical_packets);
    echo '</div>';

    $counts = vmsa_vendor_portal_packet_counts($current_packets);
    if (($counts['pending'] ?? 0) > 0 || ($counts['viewed'] ?? 0) > 0) {
        vmsa_render_vendor_portal_attention_banner($counts, $current_packets);
    }

    if (empty($packets)) {
        echo '<div class="vmsa-vendor-agreements__empty">';
        echo '<h3>' . esc_html__('No agreements yet', 'vms-agreements') . '</h3>';
        echo '<p>' . esc_html__('Agreement packets assigned to your vendor profile will appear here after the venue generates them.', 'vms-agreements') . '</p>';
        echo '</div>';
    } else {
        if (!empty($current_packets)) {
            echo '<div class="vmsa-vendor-agreements__list">';
            foreach ($current_packets as $packet_id) {
                vmsa_render_vendor_portal_packet_card(absint($packet_id));
            }
            echo '</div>';
        }

        if (!empty($historical_packets)) {
            vmsa_render_vendor_portal_history_group($historical_packets, empty($current_packets));
        }
    }

    echo '</section>';
    return trim((string) ob_get_clean());
}

function vmsa_vendor_portal_notice_html(string $message): string
{
    return '<section class="vmsa-vendor-agreements"><div class="vmsa-vendor-agreements__empty"><h2>' . esc_html__('Agreements', 'vms-agreements') . '</h2><p>' . esc_html($message) . '</p></div></section>';
}

function vmsa_get_current_user_vendor_ids(int $user_id = 0): array
{
    $user_id = $user_id > 0 ? $user_id : get_current_user_id();
    if ($user_id <= 0) {
        return array();
    }

    $pre = apply_filters('vmsa_current_user_vendor_ids_pre', null, $user_id);
    if ($pre !== null) {
        return vmsa_normalize_id_list($pre);
    }

    $ids = array();
    foreach (array(
        'vms_get_active_vendor_ids_for_user',
        'vms_get_vendor_ids_for_user',
        'vms_vendor_get_vendor_ids_for_user',
        'vms_vendor_portal_get_vendor_ids_for_user',
    ) as $function_name) {
        $resolved_function = vmsa_core_function_name($function_name);
        if ($resolved_function !== '') {
            $ids = array_merge($ids, vmsa_normalize_id_list($resolved_function($user_id)));
        }
    }

    foreach (array(
        'vms_get_vendor_id_for_user',
        'vms_vendor_get_vendor_id_for_user',
        'vms_vendor_portal_get_vendor_id_for_user',
    ) as $function_name) {
        $resolved_function = vmsa_core_function_name($function_name);
        if ($resolved_function !== '') {
            $ids = array_merge($ids, vmsa_normalize_id_list($resolved_function($user_id)));
        }
    }

    $user_vendor_meta_keys = apply_filters('vmsa_vendor_portal_user_vendor_meta_keys', array(
        'vms_vendor_id',
        '_vms_vendor_id',
        'vms_vendor_profile_id',
        '_vms_vendor_profile_id',
        'vms_linked_vendor_id',
        '_vms_linked_vendor_id',
    ));
    foreach ((array) $user_vendor_meta_keys as $key) {
        $key = sanitize_key((string) $key);
        if ($key === '') {
            continue;
        }
        $ids = array_merge($ids, vmsa_normalize_id_list(get_user_meta($user_id, $key, false)));
    }

    $ids = array_merge($ids, vmsa_find_vendor_ids_for_user($user_id));
    $ids = array_values(array_unique(array_filter(array_map('absint', $ids))));

    /**
     * Let VMS Core or site-specific glue add/remove linked vendor IDs without
     * changing the agreement packet schema.
     *
     * @param int[] $ids
     * @param int   $user_id
     */
    $filtered = apply_filters('vmsa_current_user_vendor_ids', $ids, $user_id);
    return vmsa_normalize_id_list($filtered);
}

function vmsa_normalize_id_list($value): array
{
    if ($value instanceof WP_Post) {
        $value = $value->ID;
    }

    if (!is_array($value)) {
        $value = array($value);
    }

    $ids = array();
    foreach ($value as $item) {
        if ($item instanceof WP_Post) {
            $item = $item->ID;
        }
        $id = absint($item);
        if ($id > 0) {
            $ids[] = $id;
        }
    }

    return array_values(array_unique($ids));
}

function vmsa_find_vendor_ids_for_user(int $user_id): array
{
    $user = get_userdata($user_id);
    if (!$user instanceof WP_User) {
        return array();
    }

    $post_types = apply_filters('vmsa_vendor_portal_vendor_post_types', array('vms_vendor'));
    $post_types = array_values(array_filter(array_map('sanitize_key', (array) $post_types)));
    if (empty($post_types)) {
        return array();
    }

    $meta_query = array('relation' => 'OR');
    $user_meta_keys = apply_filters('vmsa_vendor_portal_user_link_meta_keys', array(
        '_vms_vendor_user_id',
        '_vms_vendor_wp_user_id',
        '_vms_user_id',
        '_vms_linked_user_id',
        '_vms_associated_user_id',
        '_vms_vendor_portal_user_id',
        '_vms_vendor_account_user_id',
    ));

    foreach ((array) $user_meta_keys as $key) {
        $key = sanitize_key((string) $key);
        if ($key === '') {
            continue;
        }

        $meta_query[] = array(
            'key' => $key,
            'value' => $user_id,
            'compare' => '=',
            'type' => 'NUMERIC',
        );
    }

    $email = sanitize_email((string) $user->user_email);
    if ($email !== '') {
        $email_meta_keys = apply_filters('vmsa_vendor_portal_email_link_meta_keys', array(
            '_vms_vendor_primary_email',
            '_vms_vendor_email',
            '_vms_contact_email',
            '_vms_primary_email',
        ));

        foreach ((array) $email_meta_keys as $key) {
            $key = sanitize_key((string) $key);
            if ($key === '') {
                continue;
            }

            $meta_query[] = array(
                'key' => $key,
                'value' => $email,
                'compare' => '=',
            );
        }
    }

    if (count($meta_query) <= 1) {
        return array();
    }

    $ids = get_posts(array(
        'post_type' => $post_types,
        'post_status' => array('publish', 'private', 'draft'),
        'posts_per_page' => 20,
        'fields' => 'ids',
        'meta_query' => $meta_query,
    ));

    return array_values(array_unique(array_filter(array_map('absint', $ids))));
}

function vmsa_get_vendor_portal_packets(array $vendor_ids, array $args = array()): array
{
    $vendor_ids = array_values(array_unique(array_filter(array_map('absint', $vendor_ids))));
    if (empty($vendor_ids)) {
        return array();
    }

    $limit = isset($args['limit']) ? absint($args['limit']) : 50;
    if ($limit <= 0) {
        $limit = 50;
    }

    $statuses = apply_filters('vmsa_vendor_portal_packet_statuses', array(
        'generated',
        'sent',
        'viewed',
        'acknowledged',
        'superseded',
        'voided',
    ));
    $statuses = array_values(array_filter(array_map('sanitize_key', (array) $statuses)));

    $meta_query = array(
        'relation' => 'AND',
        array(
            'key' => '_vmsa_vendor_id',
            'value' => $vendor_ids,
            'compare' => 'IN',
            'type' => 'NUMERIC',
        ),
    );

    if (!empty($statuses)) {
        $meta_query[] = array(
            'key' => '_vmsa_status',
            'value' => $statuses,
            'compare' => 'IN',
        );
    }

    $ids = get_posts(array(
        'post_type' => VMSA_CPT_PACKET,
        'post_status' => 'private',
        'posts_per_page' => $limit,
        'fields' => 'ids',
        'orderby' => 'date',
        'order' => 'DESC',
        'meta_query' => $meta_query,
    ));

    $ids = array_values(array_filter(array_map('absint', $ids)));
    usort($ids, 'vmsa_sort_vendor_portal_packets');

    return $ids;
}

function vmsa_vendor_portal_packet_event_plan_id(int $packet_id): int
{
    $snapshot = vmsa_get_packet_snapshot($packet_id);
    return absint($snapshot['event_plan']['id'] ?? get_post_meta($packet_id, '_vmsa_event_plan_id', true));
}

function vmsa_partition_vendor_portal_packets(array $packet_ids): array
{
    $current = array();
    $history = array();
    $selected_by_event = array();

    foreach ($packet_ids as $packet_id) {
        $packet_id = absint($packet_id);
        if ($packet_id <= 0) {
            continue;
        }

        $status = sanitize_key((string) get_post_meta($packet_id, '_vmsa_status', true));
        if (in_array($status, array('superseded', 'voided'), true)) {
            $history[] = $packet_id;
            continue;
        }

        $terms_status = in_array($status, vmsa_get_active_packet_statuses(), true)
            ? vmsa_packet_current_terms_status($packet_id)
            : array('state' => 'historical');

        if (($terms_status['state'] ?? '') !== 'current') {
            $history[] = $packet_id;
            continue;
        }

        $event_plan_id = vmsa_vendor_portal_packet_event_plan_id($packet_id);
        $group_key = $event_plan_id > 0 ? 'event_' . $event_plan_id : 'packet_' . $packet_id;
        if (isset($selected_by_event[$group_key])) {
            $history[] = $packet_id;
            continue;
        }

        $selected_by_event[$group_key] = $packet_id;
    }

    $current = array_values(array_map('absint', array_values($selected_by_event)));
    $history = array_values(array_unique(array_filter(array_map('absint', $history))));

    return array(
        'current' => $current,
        'history' => $history,
    );
}

function vmsa_sort_vendor_portal_packets(int $a, int $b): int
{
    $a_date = vmsa_vendor_portal_packet_event_sort_date($a);
    $b_date = vmsa_vendor_portal_packet_event_sort_date($b);

    if ($a_date === $b_date) {
        return $b <=> $a;
    }

    if ($a_date === '') {
        return 1;
    }

    if ($b_date === '') {
        return -1;
    }

    return strcmp($a_date, $b_date);
}

function vmsa_vendor_portal_packet_event_sort_date(int $packet_id): string
{
    $snapshot = vmsa_get_packet_snapshot($packet_id);
    $event = (array) ($snapshot['event_plan'] ?? array());
    $date = (string) ($event['event_date'] ?? '');
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? $date : '';
}

function vmsa_vendor_portal_packet_counts(array $packet_ids): array
{
    $counts = array(
        'pending' => 0,
        'viewed' => 0,
        'acknowledged' => 0,
    );

    foreach ($packet_ids as $packet_id) {
        $status = sanitize_key((string) get_post_meta(absint($packet_id), '_vmsa_status', true));
        if (in_array($status, array('generated', 'sent'), true)) {
            $counts['pending']++;
        } elseif ($status === 'viewed') {
            $counts['viewed']++;
        } elseif ($status === 'acknowledged') {
            $counts['acknowledged']++;
        }
    }

    return $counts;
}

function vmsa_vendor_portal_signed_history_count(array $packet_ids): int
{
    $count = 0;

    foreach ($packet_ids as $packet_id) {
        $packet_id = absint($packet_id);
        if ($packet_id <= 0) {
            continue;
        }

        if (function_exists('vmsa_packet_has_acknowledgement_history') && vmsa_packet_has_acknowledgement_history($packet_id)) {
            $count++;
        }
    }

    return $count;
}

function vmsa_render_vendor_portal_counts(array $packet_ids, array $history_packet_ids = array()): void
{
    $counts = vmsa_vendor_portal_packet_counts($packet_ids);
    $signed_history = vmsa_vendor_portal_signed_history_count($history_packet_ids);

    echo '<div class="vmsa-vendor-agreements__counts" aria-label="' . esc_attr__('Agreement status counts', 'vms-agreements') . '">';
    echo '<span><strong>' . esc_html((string) $counts['pending']) . '</strong> ' . esc_html__('Needs review', 'vms-agreements') . '</span>';
    echo '<span><strong>' . esc_html((string) $counts['viewed']) . '</strong> ' . esc_html__('Viewed', 'vms-agreements') . '</span>';
    echo '<span><strong>' . esc_html((string) $counts['acknowledged']) . '</strong> ' . esc_html__('Current signed', 'vms-agreements') . '</span>';
    echo '<span><strong>' . esc_html((string) $signed_history) . '</strong> ' . esc_html__('Signed history', 'vms-agreements') . '</span>';
    echo '</div>';
}

function vmsa_render_vendor_portal_attention_banner(array $counts, array $packet_ids): void
{
    $pending = absint($counts['pending'] ?? 0);
    $viewed = absint($counts['viewed'] ?? 0);
    $needs_action = $pending + $viewed;
    if ($needs_action <= 0) {
        return;
    }

    $label = sprintf(_n('%s agreement needs your review', '%s agreements need your review', $needs_action, 'vms-agreements'), number_format_i18n($needs_action));
    $first_packet_id = 0;
    foreach ($packet_ids as $packet_id) {
        $status = sanitize_key((string) get_post_meta(absint($packet_id), '_vmsa_status', true));
        if (in_array($status, array('generated', 'sent', 'viewed'), true)) {
            $first_packet_id = absint($packet_id);
            break;
        }
    }

    $cta_url = '';
    if ($first_packet_id > 0) {
        $cta_url = vmsa_packet_review_url($first_packet_id, vmsa_get_or_create_review_token($first_packet_id));
    }

    echo '<div class="vmsa-vendor-agreements-alert">';
    echo '<div>';
    echo '<strong>' . esc_html__('Action Needed', 'vms-agreements') . '</strong>';
    echo '<p>' . esc_html($label) . '. ' . esc_html__('Open the Agreement Packet and acknowledge it when ready.', 'vms-agreements') . '</p>';
    echo '</div>';
    if ($cta_url !== '') {
        echo '<a class="vmsa-vendor-agreement-button vmsa-vendor-agreement-button--primary" href="' . esc_url($cta_url) . '">' . esc_html__('Review Agreement', 'vms-agreements') . '</a>';
    }
    echo '</div>';
}

function vmsa_vendor_portal_packet_is_history(int $packet_id): bool
{
    $status = sanitize_key((string) get_post_meta($packet_id, '_vmsa_status', true));
    return in_array($status, array('superseded', 'voided'), true);
}

function vmsa_render_vendor_portal_history_group(array $packet_ids, bool $open_by_default = false): void
{
    $packet_ids = array_values(array_filter(array_map('absint', $packet_ids)));
    if (empty($packet_ids)) {
        return;
    }

    $count = count($packet_ids);
    echo '<details class="vmsa-vendor-agreements__history-group"' . ($open_by_default ? ' open' : '') . '>';
    echo '<summary>';
    echo '<span>' . esc_html(sprintf(_n('Agreement History (%s previous packet)', 'Agreement History (%s previous packets)', $count, 'vms-agreements'), number_format_i18n($count))) . '</span>';
    echo '<small>' . esc_html__('Superseded, voided, and outdated packets are kept for recordkeeping, but collapsed so the current Agreement Packet stays easy to find.', 'vms-agreements') . '</small>';
    echo '</summary>';
    echo '<div class="vmsa-vendor-agreements__history-list">';
    foreach ($packet_ids as $packet_id) {
        vmsa_render_vendor_portal_packet_card($packet_id, true);
    }
    echo '</div>';
    echo '</details>';
}

function vmsa_render_vendor_portal_packet_card(int $packet_id, bool $compact = false): void
{
    $snapshot = vmsa_get_packet_snapshot($packet_id);
    $status = sanitize_key((string) get_post_meta($packet_id, '_vmsa_status', true));
    $status = $status !== '' ? $status : 'generated';
    $terms_status = in_array($status, vmsa_get_active_packet_statuses(), true)
        ? vmsa_packet_current_terms_status($packet_id)
        : array('state' => 'historical', 'label' => __('Historical packet', 'vms-agreements'));
    $event = (array) ($snapshot['event_plan'] ?? array());
    $venue = (array) ($snapshot['venue'] ?? array());
    $vendor = (array) ($snapshot['vendor'] ?? array());
    $comp = (array) ($snapshot['compensation'] ?? array());
    $event_title = trim(vmsa_display_text($event['title'] ?? vmsa_get_post_title_text($packet_id)));
    $event_date = (string) ($event['event_date'] ?? '');
    $time = vmsa_format_time_range((string) ($event['start_time'] ?? ''), (string) ($event['end_time'] ?? ''));
    $token = in_array($status, vmsa_get_active_packet_statuses(), true) ? vmsa_get_or_create_review_token($packet_id) : '';
    $review_url = $token !== '' ? vmsa_packet_review_url($packet_id, $token) : '';
    $print_url = $token !== '' ? vmsa_packet_print_url($packet_id, $token) : '';
    $latest_ack = vmsa_get_latest_ack_record($packet_id);
    $history = vmsa_vendor_portal_packet_history_lines($packet_id, $status, $latest_ack);
    $status_info = vmsa_vendor_portal_status_info($status);

    $card_classes = 'vmsa-vendor-agreement-card vmsa-vendor-agreement-card--' . $status_info['key'];
    if ($compact) {
        $card_classes .= ' vmsa-vendor-agreement-card--compact';
    }

    echo '<article class="' . esc_attr($card_classes) . '">';
    echo '<div class="vmsa-vendor-agreement-card__main">';
    echo '<div class="vmsa-vendor-agreement-card__title-row">';
    echo '<h3>' . esc_html(vmsa_display_text($event_title !== '' ? $event_title : __('Agreement Packet', 'vms-agreements'))) . '</h3>';
    echo '<span class="vmsa-vendor-agreement-status vmsa-vendor-agreement-status--' . esc_attr($status_info['key']) . '">' . esc_html($status_info['label']) . '</span>';
    echo '</div>';

    echo '<dl class="vmsa-vendor-agreement-card__details">';
    echo '<div><dt>' . esc_html__('Date', 'vms-agreements') . '</dt><dd>' . esc_html(vmsa_format_date($event_date)) . '</dd></div>';
    if (!$compact) {
        echo '<div><dt>' . esc_html__('Time', 'vms-agreements') . '</dt><dd>' . esc_html($time) . '</dd></div>';
        echo '<div><dt>' . esc_html__('Venue', 'vms-agreements') . '</dt><dd>' . esc_html((string) ($venue['name'] ?? '-')) . '</dd></div>';
        echo '<div><dt>' . esc_html__('Vendor', 'vms-agreements') . '</dt><dd>' . esc_html(vmsa_display_text($vendor['name'] ?? '-')) . '</dd></div>';
    }
    echo '</dl>';

    if (!$compact) {
        echo '<div class="vmsa-vendor-agreement-card__summary">';
        echo '<p><strong>' . esc_html__('Compensation Terms:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_display_text(vmsa_vendor_portal_pay_summary($comp))) . '</p>';
        if (!empty($comp['deposit_summary'])) {
            echo '<p><strong>' . esc_html__('Deposit / Advance Terms:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_display_text($comp['deposit_summary'])) . '</p>';
        }
        echo '</div>';
    }

    if (($terms_status['state'] ?? '') === 'stale') {
        echo '<p class="vmsa-vendor-agreement-card__warning">' . esc_html(vmsa_vendor_facing_terms_status_label($terms_status)) . '</p>';
    }

    if (!empty($history)) {
        echo '<ul class="vmsa-vendor-agreement-card__history">';
        foreach ($history as $line) {
            echo '<li>' . esc_html($line) . '</li>';
        }
        echo '</ul>';
    }

    echo '</div>';
    echo '<div class="vmsa-vendor-agreement-card__actions">';
    if (!$compact && $review_url !== '') {
        echo '<a class="vmsa-vendor-agreement-button vmsa-vendor-agreement-button--primary" href="' . esc_url($review_url) . '">' . esc_html__('Review Agreement', 'vms-agreements') . '</a>';
    }
    if (!$compact && $print_url !== '') {
        echo '<a class="vmsa-vendor-agreement-button" target="_blank" rel="noopener noreferrer" href="' . esc_url($print_url) . '">' . esc_html__('Print / Save PDF', 'vms-agreements') . '</a>';
    }
    if ($review_url === '' && $print_url === '') {
        echo '<span class="vmsa-vendor-agreement-card__inactive">' . esc_html($compact ? __('Historical record', 'vms-agreements') : __('Historical copy only. Contact the venue if you need the current review link.', 'vms-agreements')) . '</span>';
    }
    echo '</div>';
    echo '</article>';
}

function vmsa_vendor_portal_status_info(string $status): array
{
    $status = sanitize_key($status);
    if (in_array($status, array('generated', 'sent'), true)) {
        return array('key' => 'pending', 'label' => __('Needs Review', 'vms-agreements'));
    }

    $labels = array(
        'viewed' => __('Viewed', 'vms-agreements'),
        'acknowledged' => __('Acknowledged', 'vms-agreements'),
        'superseded' => __('Superseded', 'vms-agreements'),
        'voided' => __('Voided', 'vms-agreements'),
    );

    return array(
        'key' => isset($labels[$status]) ? $status : 'unknown',
        'label' => $labels[$status] ?? vmsa_get_status_label($status),
    );
}

function vmsa_vendor_portal_pay_summary(array $comp): string
{
    $breakdown = isset($comp['payment_breakdown']) && is_array($comp['payment_breakdown']) ? $comp['payment_breakdown'] : array();
    $total = trim((string) ($breakdown['total_agreed_payment'] ?? ''));
    $summary = trim((string) ($comp['summary'] ?? ''));

    if ($total !== '') {
        return sprintf(__('Total agreed payment: %s', 'vms-agreements'), $total);
    }

    if ($summary !== '') {
        return vmsa_clean_compensation_summary_text($summary);
    }

    return __('See Agreement Packet.', 'vms-agreements');
}

function vmsa_vendor_portal_packet_history_lines(int $packet_id, string $status, array $latest_ack): array
{
    $lines = array();
    $generated_at = (string) get_post_meta($packet_id, '_vmsa_generated_at', true);
    $sent_at = (string) get_post_meta($packet_id, '_vmsa_review_email_sent_at', true);
    $viewed_at = (string) get_post_meta($packet_id, '_vmsa_first_viewed_at', true);
    $ack_at = (string) ($latest_ack['acknowledged_at'] ?? get_post_meta($packet_id, '_vmsa_acknowledged_at', true));
    $superseded_at = (string) get_post_meta($packet_id, '_vmsa_superseded_at', true);
    $voided_at = (string) get_post_meta($packet_id, '_vmsa_voided_at', true);

    if ($generated_at !== '') {
        $lines[] = sprintf(__('Generated %s', 'vms-agreements'), vmsa_format_audit_datetime($generated_at));
    }

    if ($sent_at !== '') {
        $lines[] = sprintf(__('Review email sent %s', 'vms-agreements'), vmsa_format_audit_datetime($sent_at));
    }

    if ($viewed_at !== '') {
        $lines[] = sprintf(__('First viewed %s', 'vms-agreements'), vmsa_format_audit_datetime($viewed_at));
    }

    if ($ack_at !== '') {
        $lines[] = sprintf(__('Acknowledged %s', 'vms-agreements'), vmsa_format_audit_datetime($ack_at));
    }

    if ($status === 'superseded' && $superseded_at !== '') {
        $lines[] = sprintf(__('Superseded %s', 'vms-agreements'), vmsa_format_audit_datetime($superseded_at));
    }

    if ($status === 'voided' && $voided_at !== '') {
        $lines[] = sprintf(__('Voided %s', 'vms-agreements'), vmsa_format_audit_datetime($voided_at));
    }

    return $lines;
}
