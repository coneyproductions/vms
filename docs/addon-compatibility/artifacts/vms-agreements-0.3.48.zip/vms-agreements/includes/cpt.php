<?php
if (!defined('ABSPATH')) {
    exit;
}

function vmsa_register_post_types(): void
{
    register_post_type(VMSA_CPT_TEMPLATE, array(
        'labels' => array(
            'name' => __('Agreement Templates', 'vms-agreements'),
            'singular_name' => __('Agreement Template', 'vms-agreements'),
        ),
        'public' => false,
        'show_ui' => false,
        'show_in_menu' => false,
        'supports' => array('title'),
        'capability_type' => 'post',
        'has_archive' => false,
        'rewrite' => false,
    ));

    register_post_type(VMSA_CPT_PACKET, array(
        'labels' => array(
            'name' => __('Agreement Packets', 'vms-agreements'),
            'singular_name' => __('Agreement Packet', 'vms-agreements'),
        ),
        'public' => false,
        'show_ui' => false,
        'show_in_menu' => false,
        'supports' => array('title'),
        'capability_type' => 'post',
        'has_archive' => false,
        'rewrite' => false,
    ));
}

function vmsa_default_template_body(): string
{
    return trim(implode("\n\n", array(
        'Agreement Packet',
        'This Agreement Packet documents the booking terms between {contracting_entity}, as the contracting venue/operator, and {vendor_contracting_party} for this event.',
        'Event: {event_title}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Contracting party: {contracting_entity}',
        'Vendor / act: {vendor_name}',
        'Vendor legal / contracting name: {vendor_legal_name}',
        'Vendor representative / contact: {vendor_representative}',
        'Compensation: {compensation_summary}',
        'Deposit / advance: {deposit_summary}',
        'Production responsibilities:',
        'Stage: {production_stage}',
        'House Sound / PA: {production_house_sound}',
        'Stage Lighting: {production_stage_lighting}',
        'Sound Engineer: {production_sound_engineer}',
        'Production schedule:',
        'Arrival / load-in: {arrival_loadin_time}',
        'Soundcheck: {soundcheck_window}',
        'Load-out / venue vacate by: {vacate_by_time}',
        'Payment summary:',
        '{payment_summary}',
        'The Agreement Terms below address performance commitment, weather/safety cancellation, event viability, payment, production/riders, Vendor performance issues, independent-contractor status, changes to agreed terms, governing law, venue expectations, and acknowledgement recordkeeping.',
    )));
}

function vmsa_default_acknowledgements(): array
{
    return array(
        array(
            'key' => 'terms_reviewed',
            'label' => __('I have reviewed this Agreement Packet, including the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, Production Responsibilities, Production Schedule, performance commitment, cancellation terms, payment terms, production/rider terms, performance-issue terms, and other Agreement Terms shown above.', 'vms-agreements'),
        ),
        array(
            'key' => 'deposit_reviewed',
            'label' => __('I understand that this Agreement Packet controls the material booking terms unless the Venue issues a newer Agreement Packet or both parties accept another written amendment.', 'vms-agreements'),
        ),
        array(
            'key' => 'audit_understood',
            'label' => __('I understand that my acknowledgement will create an Acknowledgement Record that may include my signer name, signer email, acknowledgement date/time, IP address, browser/user agent, user account if available, agreement version, packet ID, terms hash, compensation hash, and related Packet Verification Records.', 'vms-agreements'),
        ),
        array(
            'key' => 'authorized_signer',
            'label' => __('I confirm that I am authorized to review and acknowledge this Agreement Packet on behalf of the Vendor listed above.', 'vms-agreements'),
        ),
    );
}

function vmsa_ensure_default_template(): int
{
    $existing_id = absint(get_option('vmsa_default_template_id', 0));
    if ($existing_id > 0 && get_post_type($existing_id) === VMSA_CPT_TEMPLATE) {
        return $existing_id;
    }

    $found = get_posts(array(
        'post_type' => VMSA_CPT_TEMPLATE,
        'post_status' => array('publish', 'draft', 'private'),
        'posts_per_page' => 1,
        'fields' => 'ids',
        'meta_key' => '_vmsa_template_key',
        'meta_value' => 'default_booking_agreement',
    ));

    if (!empty($found)) {
        $template_id = absint($found[0]);
        update_option('vmsa_default_template_id', $template_id, false);
        return $template_id;
    }

    $template_id = wp_insert_post(array(
        'post_type' => VMSA_CPT_TEMPLATE,
        'post_status' => 'publish',
        'post_title' => __('Default Booking Agreement', 'vms-agreements'),
    ), true);

    if (is_wp_error($template_id) || absint($template_id) <= 0) {
        return 0;
    }

    $template_id = absint($template_id);
    update_post_meta($template_id, '_vmsa_template_key', 'default_booking_agreement');
    update_post_meta($template_id, '_vmsa_template_version', '1.0.0');
    update_post_meta($template_id, '_vmsa_template_body', vmsa_default_template_body());
    update_post_meta($template_id, '_vmsa_template_blocks', vmsa_default_template_blocks());
    update_post_meta($template_id, '_vmsa_acknowledgements', vmsa_default_acknowledgements());
    update_post_meta($template_id, '_vmsa_email_templates', vmsa_default_email_templates());
    update_option('vmsa_default_template_id', $template_id, false);

    return $template_id;
}

function vmsa_maybe_ensure_default_template(): void
{
    if (!vmsa_can_manage()) {
        return;
    }

    vmsa_ensure_default_template();

    if ((string) get_option('vmsa_needs_default_template_check', '') !== '') {
        delete_option('vmsa_needs_default_template_check');
    }
}

function vmsa_get_template_payload(int $template_id = 0): array
{
    if ($template_id <= 0) {
        $template_id = vmsa_ensure_default_template();
    }

    $body = $template_id > 0 ? (string) get_post_meta($template_id, '_vmsa_template_body', true) : '';
    if ($body === '') {
        $body = vmsa_default_template_body();
    }

    $acknowledgements = $template_id > 0 ? get_post_meta($template_id, '_vmsa_acknowledgements', true) : array();
    if (!is_array($acknowledgements) || empty($acknowledgements)) {
        $acknowledgements = vmsa_default_acknowledgements();
    }
    $acknowledgements = vmsa_merge_required_template_acknowledgements($acknowledgements);

    $payload = array(
        'id' => $template_id,
        'title' => $template_id > 0 ? vmsa_get_post_title_text($template_id) : __('Default Booking Agreement', 'vms-agreements'),
        'version' => $template_id > 0 ? (string) get_post_meta($template_id, '_vmsa_template_version', true) : '1.0.0',
        'body' => $body,
        'blocks' => vmsa_get_template_blocks($template_id),
        'acknowledgements' => $acknowledgements,
    );
    $payload['health'] = vmsa_template_health_check($payload);

    return $payload;
}

function vmsa_sanitize_acknowledgement_row($row): ?array
{
    if (!is_array($row)) {
        return null;
    }

    $key = isset($row['key']) ? sanitize_key((string) $row['key']) : '';
    $label = isset($row['label']) ? sanitize_text_field((string) $row['label']) : '';

    if ($key === '' || $label === '') {
        return null;
    }

    return array(
        'key' => $key,
        'label' => $label,
    );
}
