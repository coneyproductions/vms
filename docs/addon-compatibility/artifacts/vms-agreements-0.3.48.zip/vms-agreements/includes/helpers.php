<?php
if (!defined('ABSPATH')) {
    exit;
}

const VMSA_CPT_TEMPLATE = 'vmsa_template';
const VMSA_CPT_PACKET = 'vmsa_packet';

function vmsa_core_is_loaded(): bool
{
    return vmsa_core_version() !== '';
}

function vmsa_core_version(): string
{
    if (defined('BVMGR_VERSION')) {
        return trim((string) BVMGR_VERSION);
    }

    if (defined('VMS_VERSION')) {
        return trim((string) VMS_VERSION);
    }

    return '';
}

function vmsa_core_version_ok(): bool
{
    $version = vmsa_core_version();
    return $version !== '' && version_compare($version, VMSA_MIN_VMS_VERSION, '>=');
}

function vmsa_core_function_name(string $legacy_name): string
{
    $legacy_name = trim($legacy_name);
    if ($legacy_name === '') {
        return '';
    }

    if (str_starts_with($legacy_name, 'vms_')) {
        $public_name = 'bvmgr_' . substr($legacy_name, 4);
        if (function_exists($public_name)) {
            return $public_name;
        }
    }

    return function_exists($legacy_name) ? $legacy_name : '';
}

function vmsa_can_manage(): bool
{
    return current_user_can('manage_options');
}


/**
 * Legal contracting identity shown in new Agreement Packets.
 *
 * Keep this operator-level rather than hard-coding a venue/company name so the
 * add-on remains reusable across VMS installations. Existing packet snapshots
 * retain the identity that was active when they were generated.
 */
function vmsa_get_contracting_entity_name(): string
{
    return trim(vmsa_display_text(get_option('vmsa_contracting_entity_name', '')));
}

/**
 * Venue/operator fallback for final payment timing when an Event Plan does not
 * already carry an explicit VMS Core final-payment timing value.
 */
function vmsa_get_standard_final_payment_days(): int
{
    $raw = get_option('vmsa_standard_final_payment_days', 5);
    $days = absint($raw);
    if ($days <= 0) {
        $days = 5;
    }

    return min(90, $days);
}


/**
 * Final-payment methods supported by the VMS Core compensation model.
 *
 * Agreements edits the existing Event Plan compensation fields rather than
 * maintaining a second payment-method value of its own.
 *
 * @return array<string,string>
 */
function vmsa_payment_method_choices(): array
{
    return array(
        'check' => __('Check', 'vms-agreements'),
        'cash' => __('Cash', 'vms-agreements'),
        'ach_direct_deposit' => __('ACH / Direct Deposit', 'vms-agreements'),
        'zelle' => __('Zelle', 'vms-agreements'),
        'venmo' => __('Venmo', 'vms-agreements'),
        'paypal' => __('PayPal', 'vms-agreements'),
        'other' => __('Other', 'vms-agreements'),
    );
}

function vmsa_event_plan_payment_meta_key(string $field, string $fallback): string
{
    $meta_key_function = vmsa_core_function_name('vms_meta_key');
    if ($meta_key_function !== '') {
        $key = (string) $meta_key_function('event_plan', $field);
        if ($key !== '') {
            return $key;
        }
    }

    return $fallback;
}

/**
 * Read the Event Plan's canonical VMS Core payment-method fields.
 *
 * @return array{method:string,other:string,label:string,complete:bool}
 */
function vmsa_get_event_plan_payment_method(int $event_plan_id): array
{
    $event_plan_id = absint($event_plan_id);
    $method_key = vmsa_event_plan_payment_meta_key('final_payment_method', '_vms_final_payment_method');
    $other_key = vmsa_event_plan_payment_meta_key('final_payment_method_other', '_vms_final_payment_method_other');

    $method = $event_plan_id > 0
        ? sanitize_key((string) get_post_meta($event_plan_id, $method_key, true))
        : '';
    $other = $event_plan_id > 0
        ? trim(sanitize_text_field((string) get_post_meta($event_plan_id, $other_key, true)))
        : '';

    $choices = vmsa_payment_method_choices();
    if (!array_key_exists($method, $choices)) {
        $method = '';
    }

    $complete = $method !== '' && ($method !== 'other' || $other !== '');
    $label = '';
    if ($complete) {
        $label = $method === 'other' ? $other : (string) ($choices[$method] ?? '');
    }

    return array(
        'method' => $method,
        'other' => $other,
        'label' => $label,
        'complete' => $complete,
    );
}

function vmsa_render_dependency_notice(): void
{
    if (!current_user_can('activate_plugins')) {
        return;
    }

    if (!vmsa_core_is_loaded()) {
        echo '<div class="notice notice-error"><p><strong>' . esc_html__('VMS Agreements is installed but inactive.', 'vms-agreements') . '</strong> ' . esc_html__('Activate Venue Management System first.', 'vms-agreements') . '</p></div>';
        return;
    }

    if (!vmsa_core_version_ok()) {
        echo '<div class="notice notice-error"><p><strong>' . esc_html__('VMS Agreements needs a newer VMS Core build.', 'vms-agreements') . '</strong> ' . sprintf(
            esc_html__('Installed VMS Core: %1$s. Required VMS Core: %2$s or newer.', 'vms-agreements'),
            esc_html(vmsa_core_version()),
            esc_html(VMSA_MIN_VMS_VERSION)
        ) . '</p></div>';
    }
}


function vmsa_repair_mojibake_text(string $text): string
{
    if ($text === '') {
        return '';
    }

    // Repair common UTF-8 punctuation that has already been stored/displayed as
    // Windows-1252/Latin-1 mojibake (for example: â€“ instead of –). Keep this as
    // display cleanup so historical packet hashes are not invalidated.
    $replacements = array(
        'Ã¢â‚¬â„¢' => '’',
        'Ã¢â‚¬Ëœ' => '‘',
        'Ã¢â‚¬Å“' => '“',
        'Ã¢â‚¬Â' => '”',
        'Ã¢â‚¬Â�' => '”',
        'Ã¢â‚¬â€œ' => '–',
        'Ã¢â‚¬â€' => '—',
        'Ã¢â‚¬Â¦' => '…',
        'â€™' => '’',
        'â€˜' => '‘',
        'â€œ' => '“',
        'â€�' => '”',
        'â€' => '”',
        'â€“' => '–',
        'â€”' => '—',
        'â€"' => '—',
        'â€¦' => '…',
        'â€¢' => '•',
        'â„¢' => '™',
        'â‚¬' => '€',
        'Â©' => '©',
        'Â®' => '®',
        'Â°' => '°',
        'Â±' => '±',
        'Â½' => '½',
        'Â¼' => '¼',
        'Â¾' => '¾',
        'Â ' => ' ',
        "\xc2\xa0" => ' ',
    );

    $text = strtr($text, $replacements);

    // Some packet titles contain truncated mojibake fragments such as
    // "Show â€    Band" after an em dash was corrupted. At this point the complete
    // quote/dash sequences above have already been repaired, so any remaining
    // standalone â€ / Ã¢â‚¬ fragment is almost certainly the broken dash remnant.
    $text = preg_replace('/\s*Ã¢â‚¬[^A-Za-z0-9]*\s*/u', ' — ', $text);
    $text = preg_replace('/\s*â€[^A-Za-z0-9]*\s*/u', ' — ', $text);
    $text = preg_replace('/\s+Â\s+/u', ' ', $text);
    $text = str_replace('Â', '', $text);
    $text = preg_replace('/[ \t]{2,}/u', ' ', $text);
    $text = preg_replace('/\s+([—–-])\s+/u', ' $1 ', $text);

    return is_string($text) ? trim($text) : '';
}

function vmsa_display_text($value): string
{
    return vmsa_repair_mojibake_text((string) $value);
}

function vmsa_clean_money($value): ?float
{
    if ($value === '' || $value === null || !is_numeric($value)) {
        return null;
    }

    $amount = round((float) $value, 2);
    return $amount >= 0 ? $amount : null;
}

function vmsa_money($value): string
{
    $amount = vmsa_clean_money($value);
    if ($amount === null) {
        return '-';
    }

    return '$' . number_format($amount, 2);
}

function vmsa_clean_compensation_summary_text(string $summary): string
{
    $summary = trim($summary);
    if ($summary === '') {
        return '';
    }

    $summary = preg_replace('/^Flat fee;\s*Base\/flat:\s*/i', __('Flat fee:', 'vms-agreements') . ' ', $summary);
    $summary = preg_replace('/^Flat fee \+ door split;\s*Base\/flat:\s*/i', __('Flat fee:', 'vms-agreements') . ' ', $summary);
    $summary = preg_replace('/^Base \+ attendance bonus;\s*Base\/flat:\s*/i', __('Base fee:', 'vms-agreements') . ' ', $summary);
    $summary = str_replace('Base/flat:', __('Base fee:', 'vms-agreements'), $summary);

    return is_string($summary) ? vmsa_display_text(trim($summary)) : '';
}


function vmsa_format_phone_number(string $phone): string
{
    $phone = trim(vmsa_display_text($phone));
    if ($phone === '') {
        return '';
    }

    $digits = preg_replace('/\D+/', '', $phone);
    if (!is_string($digits)) {
        return $phone;
    }

    if (strlen($digits) === 11 && str_starts_with($digits, '1')) {
        $digits = substr($digits, 1);
    }

    if (strlen($digits) === 10) {
        return sprintf(
            '(%s) %s-%s',
            substr($digits, 0, 3),
            substr($digits, 3, 3),
            substr($digits, 6, 4)
        );
    }

    return $phone;
}

function vmsa_format_date(string $date): string
{
    $date = trim($date);
    if ($date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return '-';
    }

    $timezone = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
    $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $date, $timezone);

    return $dt instanceof DateTimeImmutable ? $dt->format('F j, Y') : $date;
}

function vmsa_format_time(string $time): string
{
    $time = trim($time);
    if ($time === '') {
        return '-';
    }

    $format_time_function = vmsa_core_function_name('vms_event_plan_review_format_time');
    if ($format_time_function !== '') {
        $label = (string) $format_time_function($time);
        if ($label !== '' && strtolower($label) !== 'not set') {
            return strtoupper(str_replace(array('am', 'pm'), array('AM', 'PM'), $label));
        }
    }

    $timezone = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
    foreach (array('!H:i', '!H:i:s', '!g:i A', '!g:ia', '!g:i a') as $format) {
        $dt = DateTimeImmutable::createFromFormat($format, $time, $timezone);
        if ($dt instanceof DateTimeImmutable) {
            return $dt->format('g:i A');
        }
    }

    return $time;
}

function vmsa_format_time_range(string $start_time, string $end_time): string
{
    $start = vmsa_format_time($start_time);
    $end = vmsa_format_time($end_time);

    if ($start === '-' && $end === '-') {
        return '-';
    }

    if ($start === '-') {
        return $end;
    }

    if ($end === '-') {
        return $start;
    }

    return $start . ' - ' . $end;
}

function vmsa_get_event_plan_status(int $event_plan_id): string
{
    if ($event_plan_id <= 0) {
        return '';
    }

    $get_status_function = vmsa_core_function_name('vms_event_plan_get_status');
    if ($get_status_function !== '') {
        return (string) $get_status_function($event_plan_id, 'agreement');
    }

    $meta_key_function = vmsa_core_function_name('vms_meta_key');
    $status_key = $meta_key_function !== '' ? (string) $meta_key_function('event_plan', 'status') : '_vms_event_plan_status';
    if ($status_key === '') {
        $status_key = '_vms_event_plan_status';
    }

    $status = sanitize_key((string) get_post_meta($event_plan_id, $status_key, true));
    if ($status === '') {
        $status = sanitize_key((string) get_post_meta($event_plan_id, '_vms_event_status', true));
    }

    if ($status === '' && get_post_status($event_plan_id) === 'publish') {
        $status = 'published';
    }

    return $status !== '' ? $status : 'draft';
}

function vmsa_get_event_plan_status_label(string $status): string
{
    $status = sanitize_key($status);
    if ($status === '') {
        return '-';
    }

    $status_label_function = vmsa_core_function_name('vms_event_plan_status_label');
    if ($status_label_function !== '') {
        return (string) $status_label_function($status);
    }

    return ucwords(str_replace(array('_', '-'), ' ', $status));
}

function vmsa_current_datetime_mysql(): string
{
    return current_time('mysql');
}

function vmsa_disable_public_cache(): void
{
    if (!defined('DONOTCACHEPAGE')) {
        define('DONOTCACHEPAGE', true);
    }
    if (!defined('DONOTCACHEOBJECT')) {
        define('DONOTCACHEOBJECT', true);
    }
    if (!defined('DONOTCACHEDB')) {
        define('DONOTCACHEDB', true);
    }
    if (!defined('DONOTMINIFY')) {
        define('DONOTMINIFY', true);
    }
    if (!defined('DONOTCDN')) {
        define('DONOTCDN', true);
    }

    if (!headers_sent()) {
        if (function_exists('header_remove')) {
            header_remove('ETag');
            header_remove('Last-Modified');
        }
        nocache_headers();
        header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0, s-maxage=0');
        header('Pragma: no-cache');
        header('Expires: Wed, 11 Jan 1984 05:00:00 GMT');
        header('Surrogate-Control: no-store, no-cache, max-age=0');
        header('X-Accel-Expires: 0');
    }
}

function vmsa_admin_page_slug(): string
{
    return 'vms-agreements';
}

function vmsa_legacy_admin_page_slug(): string
{
    return 'vmsa-agreements';
}

function vmsa_admin_page_url(array $args = array()): string
{
    return add_query_arg(array_merge(array('page' => vmsa_admin_page_slug()), $args), admin_url('admin.php'));
}

function vmsa_agreement_setup_url(int $event_plan_id, array $args = array()): string
{
    $event_plan_id = absint($event_plan_id);
    return vmsa_admin_page_url(array_merge(array('vmsa_setup_event_plan' => $event_plan_id), $args));
}

function vmsa_generate_packet_url(int $event_plan_id, bool $confirm_regenerate = false): string
{
    $args = array(
        'action' => 'vmsa_generate_packet',
        'event_plan_id' => $event_plan_id,
    );

    if ($confirm_regenerate) {
        $args['vmsa_confirm_regenerate'] = '1';
    }

    return wp_nonce_url(
        add_query_arg($args, admin_url('admin-post.php')),
        'vmsa_generate_packet'
    );
}

function vmsa_event_plan_edit_url(int $event_plan_id): string
{
    return add_query_arg(
        array(
            'post' => $event_plan_id,
            'action' => 'edit',
        ),
        admin_url('post.php')
    );
}

function vmsa_get_post_title_text(int $post_id): string
{
    if ($post_id <= 0) {
        return '';
    }

    // Use raw post_title so agreement hashes and generated packet snapshots do
    // not depend on request-specific the_title filters or admin-only entity
    // decoding. Fall back progressively if raw access is unavailable.
    $title = (string) get_post_field('post_title', $post_id, 'raw');
    if ($title === '') {
        $title = (string) get_post_field('post_title', $post_id);
    }
    if ($title === '') {
        $title = (string) get_the_title($post_id);
    }

    if (strpos($title, '&') !== false) {
        $charset = function_exists('get_bloginfo') ? (string) get_bloginfo('charset') : 'UTF-8';
        $title = html_entity_decode($title, ENT_QUOTES, $charset);
        $title = html_entity_decode($title, ENT_QUOTES, $charset);
    }

    return vmsa_display_text(wp_strip_all_tags($title));
}

function vmsa_normalize_title_key(string $title): string
{
    $title = wp_strip_all_tags(vmsa_display_text($title));
    $title = strtolower(trim($title));
    $title = preg_replace('/[^a-z0-9]+/', '', $title);
    return is_string($title) ? $title : '';
}

function vmsa_packet_title(int $event_plan_id, int $vendor_id): string
{
    $event_title = $event_plan_id > 0 ? vmsa_get_post_title_text($event_plan_id) : '';
    $vendor_title = $vendor_id > 0 ? vmsa_get_post_title_text($vendor_id) : '';

    if ($event_title !== '' && $vendor_title !== '' && vmsa_normalize_title_key($event_title) === vmsa_normalize_title_key($vendor_title)) {
        return $event_title;
    }

    $parts = array_filter(array($event_title, $vendor_title));
    return !empty($parts) ? implode(' - ', $parts) : __('Agreement Packet', 'vms-agreements');
}

function vmsa_packet_display_title(int $packet_id): string
{
    $snapshot = vmsa_get_packet_snapshot($packet_id);
    $event = (array) ($snapshot['event_plan'] ?? array());
    $vendor = (array) ($snapshot['vendor'] ?? array());

    $event_title = vmsa_display_text($event['title'] ?? '');
    $vendor_title = vmsa_display_text($vendor['name'] ?? '');

    if ($event_title !== '' || $vendor_title !== '') {
        if ($event_title !== '' && $vendor_title !== '' && vmsa_normalize_title_key($event_title) === vmsa_normalize_title_key($vendor_title)) {
            return $event_title;
        }

        $parts = array_filter(array($event_title, $vendor_title));
        return implode(' - ', $parts);
    }

    $title = vmsa_get_post_title_text($packet_id);
    return $title !== '' ? $title : __('Agreement Packet', 'vms-agreements');
}

function vmsa_get_event_plan_date(int $event_plan_id): string
{
    if ($event_plan_id <= 0) {
        return '';
    }

    $date = trim((string) get_post_meta($event_plan_id, '_vms_event_date', true));
    $meta_key_function = vmsa_core_function_name('vms_meta_key');
    if ($date === '' && $meta_key_function !== '') {
        $date_key = (string) $meta_key_function('event_plan', 'event_date');
        if ($date_key !== '' && $date_key !== '_vms_event_date') {
            $date = trim((string) get_post_meta($event_plan_id, $date_key, true));
        }
    }

    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? $date : '';
}

function vmsa_event_plan_is_past(int $event_plan_id): bool
{
    $date = vmsa_get_event_plan_date($event_plan_id);
    if ($date === '') {
        return false;
    }

    $today = function_exists('wp_date') ? wp_date('Y-m-d', time(), wp_timezone()) : current_time('Y-m-d');
    return $date < $today;
}

function vmsa_event_plan_is_cancelled(int $event_plan_id): bool
{
    $status = sanitize_key(vmsa_get_event_plan_status($event_plan_id));
    return in_array($status, array('cancelled', 'canceled'), true);
}

function vmsa_event_plan_generation_block_reason(int $event_plan_id): string
{
    if ($event_plan_id <= 0 || get_post_type($event_plan_id) !== 'vms_event_plan') {
        return 'missing_event_plan';
    }

    if (vmsa_event_plan_is_cancelled($event_plan_id)) {
        return 'cancelled_event';
    }

    if (vmsa_event_plan_is_past($event_plan_id)) {
        return 'past_event';
    }

    if (vmsa_get_primary_vendor_id($event_plan_id) <= 0) {
        return 'missing_vendor';
    }

    if (vmsa_get_contracting_entity_name() === '') {
        return 'missing_contracting_entity';
    }

    $vendor_id = vmsa_get_primary_vendor_id($event_plan_id);
    $identity = vmsa_get_event_plan_vendor_identity($event_plan_id, $vendor_id);
    if (trim((string) ($identity['legal_name'] ?? '')) === '') {
        return 'missing_vendor_legal_name';
    }
    if (trim((string) ($identity['representative_name'] ?? '')) === '') {
        return 'missing_vendor_representative';
    }

    $payment_method = vmsa_get_event_plan_payment_method($event_plan_id);
    if (empty($payment_method['complete'])) {
        return 'payment_method_incomplete';
    }

    if (!vmsa_production_terms_complete(vmsa_get_event_plan_production_terms($event_plan_id))) {
        return 'production_terms_incomplete';
    }

    if (!vmsa_production_schedule_complete(vmsa_get_event_plan_production_schedule($event_plan_id))) {
        return 'production_schedule_incomplete';
    }

    return '';
}

function vmsa_event_plan_can_generate_packet(int $event_plan_id): bool
{
    return vmsa_event_plan_generation_block_reason($event_plan_id) === '';
}


/**
 * Human-readable explanation for why a new packet cannot be generated.
 *
 * Keep this diagnostic separate from the boolean guardrail so admin surfaces can
 * explain the actual missing prerequisite instead of presenting every failure as
 * a cancelled/past event.
 */
function vmsa_event_plan_generation_block_message(int $event_plan_id, string $reason = '', bool $history_available = false): string
{
    $event_plan_id = absint($event_plan_id);
    $reason = sanitize_key($reason !== '' ? $reason : vmsa_event_plan_generation_block_reason($event_plan_id));
    $history_suffix = $history_available
        ? ' ' . __('Existing packet history remains available.', 'vms-agreements')
        : '';

    if ($reason === 'missing_contracting_entity') {
        return __('Agreement generation is waiting on Agreement Defaults. Set the Legal contracting party, save the defaults, then return to this Event Plan.', 'vms-agreements');
    }

    if ($reason === 'cancelled_event') {
        return __('Agreement generation is unavailable because this Event Plan is marked Cancelled. Review the Cancellation and Event Plan Status & Workflow sections if that state is unexpected.', 'vms-agreements') . $history_suffix;
    }

    if ($reason === 'past_event') {
        $event_date = trim((string) get_post_meta($event_plan_id, '_vms_event_date', true));
        if ($event_date !== '') {
            $timestamp = strtotime($event_date . ' 12:00:00');
            if ($timestamp !== false) {
                $event_date = wp_date(get_option('date_format') ?: 'F j, Y', $timestamp, wp_timezone());
            }
        }

        $message = $event_date !== ''
            ? sprintf(__('Agreement generation is unavailable because the Event Plan date (%s) has passed.', 'vms-agreements'), $event_date)
            : __('Agreement generation is unavailable because the Event Plan date has passed.', 'vms-agreements');
        return $message . $history_suffix;
    }

    if ($reason === 'missing_vendor') {
        return __('Agreement generation is waiting on a primary vendor. Choose the primary vendor on this Event Plan, save it, then generate the packet.', 'vms-agreements');
    }

    if ($reason === 'missing_event_plan') {
        return __('Agreement generation is unavailable because this Event Plan could not be resolved.', 'vms-agreements');
    }

    if ($reason === 'missing_vendor_legal_name') {
        return __('Agreement generation is waiting on the Vendor legal / contracting name. Open Agreement Setup, enter or confirm the legal party, save the setup, then generate the packet.', 'vms-agreements');
    }

    if ($reason === 'missing_vendor_representative') {
        return __('Agreement generation is waiting on the Vendor representative / contact name. Open Agreement Setup, enter or confirm the responsible person, save the setup, then generate the packet.', 'vms-agreements');
    }

    if ($reason === 'payment_method_incomplete') {
        return __('Agreement generation is waiting on a final payment method. Open Agreement Setup, choose how the Vendor will be paid, specify the method when Other is selected, save the setup, then generate the packet.', 'vms-agreements');
    }

    if ($reason === 'production_terms_incomplete') {
        return __('Agreement generation is waiting on Production Responsibilities. Open Agreement Setup, answer Yes or No for Stage, House Sound / PA, Stage Lighting, and Sound Engineer, confirm the booking-specific answers, then save the setup.', 'vms-agreements');
    }

    if ($reason === 'production_schedule_incomplete') {
        return __('Agreement generation is waiting on the Production Schedule. Open Agreement Setup and enter the scheduled arrival/load-in time plus the soundcheck start and finish times, then save the setup.', 'vms-agreements');
    }

    if ($reason !== '') {
        return __('Agreement generation is unavailable because this Event Plan is missing a required prerequisite. Review the Event Plan and Agreement Defaults, then try again.', 'vms-agreements');
    }

    return '';
}

function vmsa_event_plan_generation_block_action(string $reason, int $event_plan_id = 0): array
{
    $reason = sanitize_key($reason);
    $event_plan_id = absint($event_plan_id);

    if ($reason === 'missing_contracting_entity') {
        return array(
            'label' => __('Open Agreement Defaults', 'vms-agreements'),
            'url' => vmsa_admin_page_url() . '#vmsa-agreement-defaults',
        );
    }

    if (
        $event_plan_id > 0
        && in_array($reason, array('missing_vendor_legal_name', 'missing_vendor_representative', 'payment_method_incomplete', 'production_terms_incomplete', 'production_schedule_incomplete'), true)
    ) {
        return array(
            'label' => __('Open Agreement Setup', 'vms-agreements'),
            'url' => vmsa_agreement_setup_url($event_plan_id),
        );
    }

    return array();
}

function vmsa_hash_payload($value): string
{
    $normalized = vmsa_normalize_for_hash($value);
    return hash('sha256', wp_json_encode($normalized));
}

function vmsa_normalize_for_hash($value)
{
    if (is_array($value)) {
        $is_list = array_keys($value) === range(0, count($value) - 1);
        if (!$is_list) {
            ksort($value);
        }

        foreach ($value as $key => $child) {
            $value[$key] = vmsa_normalize_for_hash($child);
        }
    }

    return $value;
}

function vmsa_get_meta_int(int $post_id, string $key): int
{
    return absint(get_post_meta($post_id, $key, true));
}

function vmsa_get_primary_vendor_id(int $event_plan_id): int
{
    return vmsa_get_meta_int($event_plan_id, '_vms_band_vendor_id');
}

function vmsa_get_venue_id(int $event_plan_id): int
{
    return vmsa_get_meta_int($event_plan_id, '_vms_venue_id');
}

function vmsa_get_vendor_contact_snapshot(int $vendor_id): array
{
    if ($vendor_id <= 0) {
        return array(
            'id' => 0,
            'name' => '',
            'legal_name' => '',
            'representative_name' => '',
            'email' => '',
            'phone' => '',
        );
    }

    $email = trim((string) get_post_meta($vendor_id, '_vms_vendor_primary_email', true));
    if ($email === '') {
        $email = trim((string) get_post_meta($vendor_id, '_vms_vendor_email', true));
    }

    $phone = trim((string) get_post_meta($vendor_id, '_vms_vendor_primary_phone', true));
    if ($phone === '') {
        $phone = trim((string) get_post_meta($vendor_id, '_vms_vendor_phone', true));
    }

    $contact_name = trim(vmsa_display_text(get_post_meta($vendor_id, '_vms_contact_name', true)));
    $payee_legal_name = trim(vmsa_display_text(get_post_meta($vendor_id, '_vms_payee_legal_name', true)));
    $display_name = vmsa_get_post_title_text($vendor_id);

    return array(
        'id' => $vendor_id,
        'name' => $display_name,
        'legal_name' => $payee_legal_name !== '' ? $payee_legal_name : $contact_name,
        'representative_name' => $contact_name,
        'email' => $email,
        'phone' => vmsa_format_phone_number($phone),
    );
}

/**
 * Agreement-specific Vendor identity. VMS Core remains the source for the
 * Vendor profile; Agreements permits an Event Plan override so a packet can
 * name the exact legal party and representative without rewriting the shared
 * Vendor record.
 */
function vmsa_get_event_plan_vendor_identity(int $event_plan_id, int $vendor_id = 0): array
{
    $event_plan_id = absint($event_plan_id);
    $vendor_id = $vendor_id > 0 ? absint($vendor_id) : vmsa_get_primary_vendor_id($event_plan_id);
    $base = vmsa_get_vendor_contact_snapshot($vendor_id);

    $identity_vendor_id = $event_plan_id > 0 ? absint(get_post_meta($event_plan_id, '_vmsa_agreement_identity_vendor_id', true)) : 0;
    $use_saved_identity = $identity_vendor_id <= 0 || $identity_vendor_id === $vendor_id;
    $legal_override = $event_plan_id > 0 && $use_saved_identity
        ? trim(vmsa_display_text(get_post_meta($event_plan_id, '_vmsa_vendor_legal_name', true)))
        : '';
    $representative_override = $event_plan_id > 0 && $use_saved_identity
        ? trim(vmsa_display_text(get_post_meta($event_plan_id, '_vmsa_vendor_representative_name', true)))
        : '';

    $legal_name = $legal_override !== '' ? $legal_override : trim(vmsa_display_text($base['legal_name'] ?? ''));
    $representative_name = $representative_override !== '' ? $representative_override : trim(vmsa_display_text($base['representative_name'] ?? ''));

    return array(
        'legal_name' => $legal_name,
        'representative_name' => $representative_name,
        'legal_name_is_override' => $legal_override !== '',
        'representative_is_override' => $representative_override !== '',
    );
}

function vmsa_get_event_plan_production_terms(int $event_plan_id): array
{
    $event_plan_id = absint($event_plan_id);
    $keys = array(
        'stage' => '_vmsa_production_stage',
        'house_sound' => '_vmsa_production_house_sound',
        'stage_lighting' => '_vmsa_production_stage_lighting',
        'sound_engineer' => '_vmsa_production_sound_engineer',
    );

    $terms = array();
    foreach ($keys as $key => $meta_key) {
        $value = $event_plan_id > 0 ? sanitize_key((string) get_post_meta($event_plan_id, $meta_key, true)) : '';
        $terms[$key] = in_array($value, array('yes', 'no'), true) ? $value : '';
    }

    $current_vendor_id = $event_plan_id > 0 ? vmsa_get_primary_vendor_id($event_plan_id) : 0;
    $confirmed_vendor_id = $event_plan_id > 0 ? absint(get_post_meta($event_plan_id, '_vmsa_production_vendor_id', true)) : 0;
    $vendor_matches = $confirmed_vendor_id <= 0 || $current_vendor_id <= 0 || $confirmed_vendor_id === $current_vendor_id;
    $terms['confirmed'] = $event_plan_id > 0
        && $vendor_matches
        && (string) get_post_meta($event_plan_id, '_vmsa_production_confirmed', true) === '1';
    return $terms;
}

function vmsa_production_terms_complete(array $terms): bool
{
    foreach (array('stage', 'house_sound', 'stage_lighting', 'sound_engineer') as $key) {
        if (!isset($terms[$key]) || !in_array((string) $terms[$key], array('yes', 'no'), true)) {
            return false;
        }
    }

    return !empty($terms['confirmed']);
}


function vmsa_normalize_time_input(string $time): string
{
    $time = trim($time);
    if ($time === '') {
        return '';
    }

    foreach (array('H:i', 'H:i:s', 'g:i A', 'g:ia', 'g:i a') as $format) {
        $dt = DateTimeImmutable::createFromFormat('!' . $format, $time);
        if ($dt instanceof DateTimeImmutable) {
            return $dt->format('H:i');
        }
    }

    return '';
}

/**
 * Booking-specific production schedule captured by Agreements.
 *
 * Arrival/load-in and the soundcheck window are material packet facts because
 * the weather-cancellation cutoff is measured from the scheduled arrival/load-in
 * time. Venue-vacate is optional and may still be communicated later when blank.
 *
 * @return array{arrival_loadin:string,soundcheck_start:string,soundcheck_end:string,vacate_by:string}
 */
function vmsa_get_event_plan_production_schedule(int $event_plan_id): array
{
    $event_plan_id = absint($event_plan_id);

    return array(
        'arrival_loadin' => $event_plan_id > 0 ? vmsa_normalize_time_input((string) get_post_meta($event_plan_id, '_vmsa_arrival_loadin_time', true)) : '',
        'soundcheck_start' => $event_plan_id > 0 ? vmsa_normalize_time_input((string) get_post_meta($event_plan_id, '_vmsa_soundcheck_start_time', true)) : '',
        'soundcheck_end' => $event_plan_id > 0 ? vmsa_normalize_time_input((string) get_post_meta($event_plan_id, '_vmsa_soundcheck_end_time', true)) : '',
        'vacate_by' => $event_plan_id > 0 ? vmsa_normalize_time_input((string) get_post_meta($event_plan_id, '_vmsa_vacate_by_time', true)) : '',
    );
}

function vmsa_production_schedule_complete(array $schedule): bool
{
    return trim((string) ($schedule['arrival_loadin'] ?? '')) !== ''
        && trim((string) ($schedule['soundcheck_start'] ?? '')) !== ''
        && trim((string) ($schedule['soundcheck_end'] ?? '')) !== '';
}

/**
 * Persist agreement-specific identity, final-payment method, and production
 * terms for an Event Plan.
 *
 * Identity/production values remain attached to the Event Plan for agreement
 * current/stale verification. Payment method is written to VMS Core's existing
 * Event Plan compensation meta so Agreements does not create a second source of
 * payment truth. Operators edit these values from the Agreements screen.
 *
 * @param array<string,mixed> $values
 * @return array<string,mixed>
 */
function vmsa_update_event_plan_agreement_setup(int $event_plan_id, array $values): array
{
    $event_plan_id = absint($event_plan_id);
    if ($event_plan_id <= 0 || get_post_type($event_plan_id) !== 'vms_event_plan') {
        return array('saved' => false, 'complete' => false);
    }

    $vendor_id = vmsa_get_primary_vendor_id($event_plan_id);
    $legal_name = sanitize_text_field((string) ($values['vendor_legal_name'] ?? ''));
    $representative_name = sanitize_text_field((string) ($values['vendor_representative_name'] ?? ''));

    update_post_meta($event_plan_id, '_vmsa_vendor_legal_name', $legal_name);
    update_post_meta($event_plan_id, '_vmsa_vendor_representative_name', $representative_name);
    update_post_meta($event_plan_id, '_vmsa_agreement_identity_vendor_id', $vendor_id);

    $payment_input_present = array_key_exists('payment_method', $values) || array_key_exists('payment_method_other', $values);
    if ($payment_input_present) {
        $payment_method = sanitize_key((string) ($values['payment_method'] ?? ''));
        $payment_method_other = sanitize_text_field((string) ($values['payment_method_other'] ?? ''));
        $payment_choices = vmsa_payment_method_choices();
        if (!array_key_exists($payment_method, $payment_choices)) {
            $payment_method = '';
        }
        if ($payment_method !== 'other') {
            $payment_method_other = '';
        }

        $payment_method_key = vmsa_event_plan_payment_meta_key('final_payment_method', '_vms_final_payment_method');
        $payment_method_other_key = vmsa_event_plan_payment_meta_key('final_payment_method_other', '_vms_final_payment_method_other');
        update_post_meta($event_plan_id, $payment_method_key, $payment_method);
        update_post_meta($event_plan_id, $payment_method_other_key, $payment_method_other);
        $payment_complete = $payment_method !== '' && ($payment_method !== 'other' || trim($payment_method_other) !== '');
    } else {
        $existing_payment_method = vmsa_get_event_plan_payment_method($event_plan_id);
        $payment_method = (string) ($existing_payment_method['method'] ?? '');
        $payment_method_other = (string) ($existing_payment_method['other'] ?? '');
        $payment_complete = !empty($existing_payment_method['complete']);
    }

    $production_fields = array(
        'stage' => '_vmsa_production_stage',
        'house_sound' => '_vmsa_production_house_sound',
        'stage_lighting' => '_vmsa_production_stage_lighting',
        'sound_engineer' => '_vmsa_production_sound_engineer',
    );

    $production_complete = true;
    foreach ($production_fields as $field => $meta_key) {
        $posted = sanitize_key((string) ($values['production_' . $field] ?? ''));
        if (!in_array($posted, array('yes', 'no'), true)) {
            $posted = '';
            $production_complete = false;
        }
        update_post_meta($event_plan_id, $meta_key, $posted);
    }

    $confirmed = $production_complete && !empty($values['production_confirmed']);
    update_post_meta($event_plan_id, '_vmsa_production_confirmed', $confirmed ? '1' : '0');
    update_post_meta($event_plan_id, '_vmsa_production_vendor_id', $vendor_id);

    $schedule_fields = array(
        'arrival_loadin' => '_vmsa_arrival_loadin_time',
        'soundcheck_start' => '_vmsa_soundcheck_start_time',
        'soundcheck_end' => '_vmsa_soundcheck_end_time',
        'vacate_by' => '_vmsa_vacate_by_time',
    );
    $schedule_input_present = false;
    foreach (array_keys($schedule_fields) as $schedule_field) {
        if (array_key_exists($schedule_field, $values)) {
            $schedule_input_present = true;
            break;
        }
    }

    if ($schedule_input_present) {
        $schedule = array();
        foreach ($schedule_fields as $field => $meta_key) {
            $value = vmsa_normalize_time_input((string) ($values[$field] ?? ''));
            $schedule[$field] = $value;
            update_post_meta($event_plan_id, $meta_key, $value);
        }
    } else {
        $schedule = vmsa_get_event_plan_production_schedule($event_plan_id);
    }
    $schedule_complete = vmsa_production_schedule_complete($schedule);

    clean_post_cache($event_plan_id);

    return array(
        'saved' => true,
        'complete' => ($legal_name !== '' && $representative_name !== '' && $payment_complete && $confirmed && $schedule_complete),
        'vendor_id' => $vendor_id,
        'legal_name' => $legal_name,
        'representative_name' => $representative_name,
        'payment_method' => $payment_method,
        'payment_method_other' => $payment_method_other,
        'payment_complete' => $payment_complete,
        'production_complete' => $confirmed,
        'production_schedule' => $schedule,
        'production_schedule_complete' => $schedule_complete,
    );
}

function vmsa_production_responsibility_label(string $value): string
{
    $value = sanitize_key($value);
    if ($value === 'yes') {
        return __('Yes - Venue provides', 'vms-agreements');
    }
    if ($value === 'no') {
        return __('No - Venue does not provide', 'vms-agreements');
    }

    return __('Not specified', 'vms-agreements');
}

function vmsa_vendor_contracting_party_display(array $vendor): string
{
    $legal_name = trim(vmsa_display_text($vendor['legal_name'] ?? ''));
    $display_name = trim(vmsa_display_text($vendor['name'] ?? ''));

    if ($legal_name === '') {
        return $display_name;
    }

    if ($display_name !== '' && vmsa_normalize_title_key($legal_name) !== vmsa_normalize_title_key($display_name)) {
        return sprintf(__('%1$s, performing as %2$s', 'vms-agreements'), $legal_name, $display_name);
    }

    return $legal_name;
}

function vmsa_get_active_packet_statuses(): array
{
    return array('generated', 'sent', 'viewed', 'acknowledged');
}

function vmsa_get_status_label(string $status): string
{
    $labels = array(
        'generated' => __('Generated', 'vms-agreements'),
        'sent' => __('Sent', 'vms-agreements'),
        'viewed' => __('Viewed', 'vms-agreements'),
        'acknowledged' => __('Acknowledged', 'vms-agreements'),
        'superseded' => __('Superseded', 'vms-agreements'),
        'voided' => __('Voided', 'vms-agreements'),
    );

    return $labels[$status] ?? ucwords(str_replace('_', ' ', $status));
}

function vmsa_notice_from_query(): void
{
    $message = isset($_GET['vmsa_notice']) ? sanitize_key((string) $_GET['vmsa_notice']) : '';
    if ($message === '') {
        return;
    }

    if (in_array($message, array('cleanup_packets_deleted', 'cleanup_packets_none'), true)) {
        $scope = isset($_GET['vmsa_cleanup_scope']) ? sanitize_key((string) $_GET['vmsa_cleanup_scope']) : 'unacknowledged';
        $deleted = isset($_GET['vmsa_deleted']) ? absint($_GET['vmsa_deleted']) : 0;
        $skipped = isset($_GET['vmsa_skipped']) ? absint($_GET['vmsa_skipped']) : 0;
        $scope_label = $scope === 'history' ? __('stale/history', 'vms-agreements') : __('unacknowledged', 'vms-agreements');
        $type = $message === 'cleanup_packets_deleted' ? 'success' : 'warning';

        if ($message === 'cleanup_packets_deleted') {
            $text = sprintf(
                _n('Deleted %1$s %2$s agreement packet.', 'Deleted %1$s %2$s agreement packets.', $deleted, 'vms-agreements'),
                number_format_i18n($deleted),
                $scope_label
            );
        } else {
            $text = __('No eligible test packets found.', 'vms-agreements');
        }

        if ($skipped > 0) {
            $text .= ' ' . sprintf(
                _n('Skipped %s acknowledged packet.', 'Skipped %s acknowledged packets.', $skipped, 'vms-agreements'),
                number_format_i18n($skipped)
            );
        }

        echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($text) . '</p></div>';
        return;
    }

    $map = array(
        'packet_generated' => array('success', __('Agreement packet generated.', 'vms-agreements')),
        'packet_regenerated' => array('success', __('New current agreement packet generated. The previous active packet was preserved as superseded history.', 'vms-agreements')),
        'packet_voided' => array('success', __('Agreement packet voided.', 'vms-agreements')),
        'review_token_regenerated' => array('success', __('Vendor review link regenerated. Any previously copied review link for this packet is no longer valid.', 'vms-agreements')),
        'review_email_sent' => array('success', __('Vendor review email sent.', 'vms-agreements')),
        'review_email_failed' => array('error', __('Vendor review email could not be sent. Review the audit trail for details.', 'vms-agreements')),
        'template_saved' => array('success', __('Agreement template blocks saved and health check refreshed. A new template version was created for future packets.', 'vms-agreements')),
        'template_saved_needs_attention' => array('warning', __('Agreement template saved, but blocking health-check issues remain. Repair required components before generating new packets.', 'vms-agreements')),
        'template_required_repaired' => array('success', __('Required agreement template components were repaired and the health check was refreshed. A new template version was created for future packets.', 'vms-agreements')),
        'template_save_failed' => array('error', __('Agreement template could not be saved.', 'vms-agreements')),
        'email_template_saved' => array('success', __('Agreement email templates saved and health check refreshed.', 'vms-agreements')),
        'email_template_save_failed' => array('error', __('Agreement email templates could not be saved.', 'vms-agreements')),
        'email_template_unhealthy' => array('error', __('Agreement email template health check has errors. Fix the email template before sending the vendor review link.', 'vms-agreements')),
        'template_unhealthy' => array('error', __('Agreement template health check has errors. Fix the template before generating a packet.', 'vms-agreements')),
        'missing_vendor_email' => array('error', __('This packet does not include a vendor email address.', 'vms-agreements')),
        'cannot_email_packet' => array('error', __('This packet is not available for vendor email delivery.', 'vms-agreements')),
        'stale_packet_email_blocked' => array('error', __('This packet is stale. Generate a fresh packet before emailing the vendor review link.', 'vms-agreements')),
        'regenerate_required' => array('warning', __('A current agreement packet already exists. Review it first, then use Regenerate / Supersede Current Packet if a new acknowledgement should be required.', 'vms-agreements')),
        'cleanup_confirmation_required' => array('error', __('Confirm the cleanup checkbox before deleting test packets.', 'vms-agreements')),
        'missing_event_plan' => array('error', __('Choose a valid Event Plan first.', 'vms-agreements')),
        'missing_vendor' => array('error', __('This Event Plan does not have a primary vendor yet.', 'vms-agreements')),
        'missing_contracting_entity' => array('error', __('Set the legal contracting party in Agreement Defaults before generating a new agreement packet.', 'vms-agreements')),
        'missing_vendor_legal_name' => array('error', __('Enter or confirm the Vendor legal / contracting name in Agreement Setup before generating the packet.', 'vms-agreements')),
        'missing_vendor_representative' => array('error', __('Enter or confirm the Vendor representative / contact name in Agreement Setup before generating the packet.', 'vms-agreements')),
        'payment_method_incomplete' => array('error', __('Choose the final payment method in Agreement Setup before generating the packet. If you choose Other, specify the method.', 'vms-agreements')),
        'production_terms_incomplete' => array('error', __('Complete and confirm the four Production Responsibilities in Agreement Setup before generating the packet.', 'vms-agreements')),
        'production_schedule_incomplete' => array('error', __('Enter arrival/load-in and soundcheck start/finish times in Agreement Setup before generating the packet.', 'vms-agreements')),
        'agreement_setup_saved' => array('success', __('Agreement Setup saved. These terms will be used by the next generated packet.', 'vms-agreements')),
        'agreement_setup_incomplete' => array('warning', __('Agreement Setup was saved, but one or more required agreement fields still need attention before a packet can be generated.', 'vms-agreements')),
        'agreement_defaults_saved' => array('success', __('Agreement defaults saved. New packets will snapshot the updated contracting identity and payment fallback.', 'vms-agreements')),
        'cancelled_event' => array('error', __('Cancelled Event Plans cannot generate new agreement packets. Existing packets remain available for history.', 'vms-agreements')),
        'past_event' => array('error', __('Past Event Plans cannot generate new agreement packets. Existing packets remain available for history.', 'vms-agreements')),
        'event_not_eligible' => array('error', __('This Event Plan is not eligible for a new agreement packet.', 'vms-agreements')),
        'dependency' => array('error', __('VMS Agreements needs VMS Core 0.2.24.570 or newer before packet generation can run.', 'vms-agreements')),
        'failed' => array('error', __('Agreement action failed. Please review the packet details and try again.', 'vms-agreements')),
    );

    if (!isset($map[$message])) {
        return;
    }

    [$type, $text] = $map[$message];
    echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($text) . '</p></div>';
}

function vmsa_get_email_records(int $packet_id): array
{
    $records = get_post_meta($packet_id, '_vmsa_email_records', true);
    return is_array($records) ? $records : array();
}

function vmsa_get_latest_email_record(int $packet_id): array
{
    $records = vmsa_get_email_records($packet_id);
    if (empty($records)) {
        return array();
    }

    $latest = end($records);
    return is_array($latest) ? $latest : array();
}


function vmsa_send_mail_with_diagnostics(string $context, string $to, string $subject, string $body, array $headers = array()): array
{
    $context = sanitize_key($context);
    $to = sanitize_email($to);
    $subject = (string) $subject;
    $body = (string) $body;
    $headers = array_values(array_filter(array_map('strval', $headers)));

    $failed_error = null;
    $succeeded = false;
    $pre_short_circuit = false;
    $pre_return_type = '';

    $pre_filter = static function ($pre_wp_mail, $atts) use (&$pre_short_circuit, &$pre_return_type) {
        if ($pre_wp_mail !== null) {
            $pre_short_circuit = true;
            $pre_return_type = gettype($pre_wp_mail);
        }

        return $pre_wp_mail;
    };

    $failed_action = static function ($wp_error) use (&$failed_error): void {
        if ($wp_error instanceof WP_Error) {
            $failed_error = $wp_error;
        }
    };

    $succeeded_action = static function ($mail_data) use (&$succeeded): void {
        $succeeded = true;
    };

    add_filter('pre_wp_mail', $pre_filter, PHP_INT_MAX, 2);
    add_action('wp_mail_failed', $failed_action, 10, 1);
    add_action('wp_mail_succeeded', $succeeded_action, 10, 1);

    $wp_mail_return = wp_mail($to, $subject, $body, $headers);

    remove_filter('pre_wp_mail', $pre_filter, PHP_INT_MAX);
    remove_action('wp_mail_failed', $failed_action, 10);
    remove_action('wp_mail_succeeded', $succeeded_action, 10);

    $error = '';
    if ($failed_error instanceof WP_Error) {
        $error = $failed_error->get_error_message();
        if ($error === '') {
            $error = __('WordPress reported a mail delivery failure.', 'vms-agreements');
        }
    } elseif ($pre_short_circuit) {
        $error = __('WordPress mail delivery was intercepted by a pre_wp_mail filter before PHPMailer handled the message. VMS Agreements did not mark the review email as sent.', 'vms-agreements');
    } elseif (!$wp_mail_return) {
        $error = __('wp_mail returned false.', 'vms-agreements');
    }

    $sent = (bool) $wp_mail_return && !$pre_short_circuit && !($failed_error instanceof WP_Error);

    return array(
        'sent' => $sent,
        'context' => $context,
        'wp_mail_return' => (bool) $wp_mail_return,
        'wp_mail_succeeded_action' => $succeeded,
        'pre_wp_mail_short_circuit' => $pre_short_circuit,
        'pre_wp_mail_return_type' => $pre_return_type,
        'wp_mail_failed' => $failed_error instanceof WP_Error,
        'wp_mail_failed_code' => $failed_error instanceof WP_Error ? (string) $failed_error->get_error_code() : '',
        'error' => $error,
    );
}
function vmsa_get_ack_records(int $packet_id): array
{
    $records = get_post_meta($packet_id, '_vmsa_ack_records', true);
    return is_array($records) ? $records : array();
}

function vmsa_get_latest_ack_record(int $packet_id): array
{
    $records = vmsa_get_ack_records($packet_id);
    if (empty($records)) {
        return array();
    }

    $latest = end($records);
    return is_array($latest) ? $latest : array();
}

function vmsa_get_request_ip(): string
{
    $candidates = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');

    foreach ($candidates as $key) {
        if (empty($_SERVER[$key])) {
            continue;
        }

        $raw = sanitize_text_field(wp_unslash((string) $_SERVER[$key]));
        $parts = array_map('trim', explode(',', $raw));
        foreach ($parts as $part) {
            if (filter_var($part, FILTER_VALIDATE_IP)) {
                return $part;
            }
        }
    }

    return '';
}

function vmsa_format_audit_datetime(string $mysql): string
{
    $mysql = trim($mysql);
    if ($mysql === '') {
        return '-';
    }

    $format = get_option('date_format') . ' ' . get_option('time_format');
    $timezone = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');

    // VMSA audit values are stored with current_time('mysql'), which is already
    // in the WordPress site timezone. Do not run them through strtotime() first,
    // because PHP may interpret that timezone-less value as the server timezone
    // and then shift it again for display.
    foreach (array('Y-m-d H:i:s', 'Y-m-d H:i') as $format_in) {
        $dt = DateTimeImmutable::createFromFormat('!' . $format_in, $mysql, $timezone);
        if ($dt instanceof DateTimeImmutable) {
            return $dt->format($format);
        }
    }

    $timestamp = strtotime($mysql);
    if (!$timestamp) {
        return vmsa_display_text($mysql);
    }

    return function_exists('wp_date') ? wp_date($format, $timestamp, $timezone) : date($format, $timestamp);
}

function vmsa_make_review_token(): string
{
    return wp_generate_password(48, false, false);
}

function vmsa_hash_review_token(string $token): string
{
    return hash('sha256', $token);
}

function vmsa_get_or_create_review_token(int $packet_id, bool $force_new = false): string
{
    if ($packet_id <= 0 || get_post_type($packet_id) !== VMSA_CPT_PACKET) {
        return '';
    }

    $token = (string) get_post_meta($packet_id, '_vmsa_review_token', true);
    if (!$force_new && $token !== '') {
        return $token;
    }

    $token = vmsa_make_review_token();
    update_post_meta($packet_id, '_vmsa_review_token', $token);
    update_post_meta($packet_id, '_vmsa_review_token_hash', vmsa_hash_review_token($token));
    update_post_meta($packet_id, '_vmsa_review_token_created_at', vmsa_current_datetime_mysql());
    update_post_meta($packet_id, '_vmsa_review_token_created_by', get_current_user_id());

    return $token;
}

function vmsa_validate_review_token(int $packet_id, string $token): bool
{
    if ($packet_id <= 0 || $token === '') {
        return false;
    }

    $stored_hash = (string) get_post_meta($packet_id, '_vmsa_review_token_hash', true);
    $stored_token = (string) get_post_meta($packet_id, '_vmsa_review_token', true);

    if ($stored_hash !== '') {
        return hash_equals($stored_hash, vmsa_hash_review_token($token));
    }

    if ($stored_token !== '') {
        return hash_equals($stored_token, $token);
    }

    return false;
}

function vmsa_packet_review_url(int $packet_id, string $token = '', array $extra_args = array()): string
{
    if ($token === '') {
        $token = vmsa_get_or_create_review_token($packet_id);
    }

    $generated_at = (string) get_post_meta($packet_id, '_vmsa_generated_at', true);
    $cache_bust = $packet_id . '-' . substr(hash('sha256', $generated_at . '|' . (string) get_post_modified_time('U', true, $packet_id)), 0, 10);

    return add_query_arg(array_merge(array(
        'vmsa_packet' => $packet_id,
        'vmsa_token' => $token,
        'vmsa_rev' => $cache_bust,
    ), $extra_args), home_url('/'));
}

function vmsa_regenerate_review_token_url(int $packet_id): string
{
    return wp_nonce_url(add_query_arg(array(
        'action' => 'vmsa_regenerate_review_token',
        'packet_id' => $packet_id,
    ), admin_url('admin-post.php')), 'vmsa_regenerate_review_token');
}
