<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('add_meta_boxes', 'vmsa_register_event_plan_metabox');
add_action('add_meta_boxes', 'vmsa_register_vendor_metabox');
add_action('save_post_vms_event_plan', 'vmsa_save_event_plan_agreement_terms', 30, 3);

function vmsa_register_event_plan_metabox(): void
{
    add_meta_box(
        'vmsa_event_plan_agreement_packet',
        __('Agreement Packet', 'vms-agreements'),
        'vmsa_render_event_plan_metabox',
        'vms_event_plan',
        'side',
        'default'
    );
}

function vmsa_register_vendor_metabox(): void
{
    add_meta_box(
        'vmsa_vendor_agreement_packets',
        __('Agreements', 'vms-agreements'),
        'vmsa_render_vendor_metabox',
        'vms_vendor',
        'side',
        'default'
    );
}

function vmsa_save_event_plan_agreement_terms(int $post_id, WP_Post $post, bool $update): void
{
    // Backward-compatibility safety for an already-open 0.3.37 Event Plan
    // editor tab. New UI edits these values from the Agreements screen.
    if ($post->post_type !== 'vms_event_plan' || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id)) {
        return;
    }

    if (!isset($_POST['vmsa_agreement_terms_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash((string) $_POST['vmsa_agreement_terms_nonce'])), 'vmsa_save_event_plan_agreement_terms')) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    vmsa_update_event_plan_agreement_setup($post_id, array(
        'vendor_legal_name' => isset($_POST['vmsa_vendor_legal_name']) ? wp_unslash((string) $_POST['vmsa_vendor_legal_name']) : '',
        'vendor_representative_name' => isset($_POST['vmsa_vendor_representative_name']) ? wp_unslash((string) $_POST['vmsa_vendor_representative_name']) : '',
        'production_stage' => isset($_POST['vmsa_production_stage']) ? wp_unslash((string) $_POST['vmsa_production_stage']) : '',
        'production_house_sound' => isset($_POST['vmsa_production_house_sound']) ? wp_unslash((string) $_POST['vmsa_production_house_sound']) : '',
        'production_stage_lighting' => isset($_POST['vmsa_production_stage_lighting']) ? wp_unslash((string) $_POST['vmsa_production_stage_lighting']) : '',
        'production_sound_engineer' => isset($_POST['vmsa_production_sound_engineer']) ? wp_unslash((string) $_POST['vmsa_production_sound_engineer']) : '',
        'production_confirmed' => !empty($_POST['vmsa_production_confirmed']),
    ));
}

function vmsa_render_event_plan_metabox(WP_Post $post): void
{
    if (!vmsa_can_manage()) {
        echo '<p>' . esc_html__('You do not have permission to manage agreement packets.', 'vms-agreements') . '</p>';
        return;
    }

    if (!vmsa_core_version_ok()) {
        echo '<p>' . esc_html__('VMS Agreements needs VMS Core 0.2.24.570 or newer.', 'vms-agreements') . '</p>';
        return;
    }

    $event_plan_id = absint($post->ID);
    $vendor_id = vmsa_get_primary_vendor_id($event_plan_id);

    if ($vendor_id <= 0) {
        echo '<p>' . esc_html__('Choose a primary vendor before preparing an agreement packet.', 'vms-agreements') . '</p>';
        return;
    }

    $identity = vmsa_get_event_plan_vendor_identity($event_plan_id, $vendor_id);
    $payment_method = vmsa_get_event_plan_payment_method($event_plan_id);
    $production = vmsa_get_event_plan_production_terms($event_plan_id);
    $production_ready = vmsa_production_terms_complete($production);
    $production_schedule = vmsa_get_event_plan_production_schedule($event_plan_id);
    $schedule_ready = vmsa_production_schedule_complete($production_schedule);
    $payment_ready = !empty($payment_method['complete']);
    $identity_ready = trim((string) ($identity['legal_name'] ?? '')) !== '' && trim((string) ($identity['representative_name'] ?? '')) !== '';
    $agreement_setup_ready = $identity_ready && $payment_ready && $production_ready && $schedule_ready;

    echo '<p class="description">' . esc_html__('Agreement-specific identity, payment method, production responsibilities, and production schedule are managed in VMS Agreements, so viewing a packet cannot accidentally discard unsaved Event Plan sidebar fields.', 'vms-agreements') . '</p>';
    echo '<p><strong>' . esc_html__('Agreement Setup', 'vms-agreements') . '</strong><br>';
    echo esc_html__('Legal party:', 'vms-agreements') . ' ' . esc_html((string) ($identity['legal_name'] ?? '—')) . '<br>';
    echo esc_html__('Representative:', 'vms-agreements') . ' ' . esc_html((string) ($identity['representative_name'] ?? '—')) . '<br>';
    echo esc_html__('Payment method:', 'vms-agreements') . ' ' . esc_html($payment_ready ? (string) ($payment_method['label'] ?? '') : __('Needs setup', 'vms-agreements')) . '<br>';
    echo esc_html__('Production:', 'vms-agreements') . ' ' . esc_html($production_ready ? __('Confirmed', 'vms-agreements') : __('Needs setup', 'vms-agreements')) . '<br>';
    echo esc_html__('Arrival / load-in:', 'vms-agreements') . ' ' . esc_html($schedule_ready ? vmsa_format_time((string) ($production_schedule['arrival_loadin'] ?? '')) : __('Needs setup', 'vms-agreements')) . '<br>';
    echo esc_html__('Soundcheck:', 'vms-agreements') . ' ' . esc_html($schedule_ready ? vmsa_format_time_range((string) ($production_schedule['soundcheck_start'] ?? ''), (string) ($production_schedule['soundcheck_end'] ?? '')) : __('Needs setup', 'vms-agreements')) . '</p>';
    echo '<p><a class="button button-secondary" href="' . esc_url(vmsa_agreement_setup_url($event_plan_id)) . '">' . esc_html($agreement_setup_ready ? __('Review Agreement Setup', 'vms-agreements') : __('Complete Agreement Setup', 'vms-agreements')) . '</a></p>';
    echo '<hr>';

    $generation_block_reason = vmsa_event_plan_generation_block_reason($event_plan_id);
    $active_packet_id = vmsa_find_active_packet($event_plan_id, $vendor_id);
    $latest_packet_id = $active_packet_id;
    if ($latest_packet_id <= 0) {
        $latest = absint(get_post_meta($event_plan_id, '_vmsa_latest_packet_id', true));
        if ($latest > 0 && get_post_type($latest) === VMSA_CPT_PACKET) {
            $latest_packet_id = $latest;
        }
    }

    if ($latest_packet_id > 0) {
        $status = (string) get_post_meta($latest_packet_id, '_vmsa_status', true);
        $terms_status = vmsa_packet_current_terms_status($latest_packet_id);
        $show_current_wording = $active_packet_id > 0;
        echo '<p><strong>' . esc_html__('Latest packet:', 'vms-agreements') . '</strong><br>';
        echo '<a href="' . esc_url(vmsa_admin_page_url(array('packet_id' => $latest_packet_id))) . '">' . esc_html(vmsa_packet_display_title($latest_packet_id)) . '</a></p>';
        echo '<p><span class="vmsa-pill vmsa-pill-' . esc_attr($status) . '">' . esc_html(vmsa_get_status_label($status)) . '</span></p>';
        if ($show_current_wording) {
            echo '<p><span class="vmsa-pill vmsa-pill-' . esc_attr((string) $terms_status['state']) . '">' . esc_html((string) $terms_status['label']) . '</span></p>';
        } else {
            echo '<p class="description">' . esc_html__('No current packet is active right now. The latest historical packet is shown for reference.', 'vms-agreements') . '</p>';
        }

        if ($show_current_wording && ($terms_status['state'] ?? '') === 'stale') {
            echo '<p class="vmsa-warning-text">' . esc_html__('This packet no longer matches the current agreement setup or Event Plan terms. Review Agreement Setup before regenerating.', 'vms-agreements') . '</p>';
        }

        echo '<p><a class="button button-primary" href="' . esc_url(vmsa_admin_page_url(array('packet_id' => $latest_packet_id))) . '">' . esc_html($show_current_wording ? __('View Current Packet', 'vms-agreements') : __('View Latest Packet', 'vms-agreements')) . '</a></p>';

        if ($generation_block_reason !== '') {
            $block_message = vmsa_event_plan_generation_block_message($event_plan_id, $generation_block_reason, true);
            echo '<p class="vmsa-warning-text">' . esc_html($block_message) . '</p>';
            $block_action = vmsa_event_plan_generation_block_action($generation_block_reason, $event_plan_id);
            if (!empty($block_action['url']) && !empty($block_action['label'])) {
                echo '<p><a class="button button-secondary" href="' . esc_url((string) $block_action['url']) . '">' . esc_html((string) $block_action['label']) . '</a></p>';
            }
        }
    } else {
        echo '<p>' . esc_html__('No agreement packet has been generated for this Event Plan yet.', 'vms-agreements') . '</p>';
        echo '<p><a class="button button-primary" href="' . esc_url(vmsa_agreement_setup_url($event_plan_id)) . '">' . esc_html__('Prepare Agreement Packet', 'vms-agreements') . '</a></p>';
        if ($generation_block_reason !== '') {
            echo '<p class="description">' . esc_html(vmsa_event_plan_generation_block_message($event_plan_id, $generation_block_reason, false)) . '</p>';
        }
    }
}

function vmsa_render_vendor_metabox(WP_Post $post): void
{
    if (!vmsa_can_manage()) {
        echo '<p>' . esc_html__('You do not have permission to manage agreement packets.', 'vms-agreements') . '</p>';
        return;
    }

    if (!vmsa_core_version_ok()) {
        echo '<p>' . esc_html__('VMS Agreements needs VMS Core 0.2.24.570 or newer.', 'vms-agreements') . '</p>';
        return;
    }

    $vendor_id = absint($post->ID);
    $packet_ids = function_exists('vmsa_get_vendor_portal_packets')
        ? vmsa_get_vendor_portal_packets(array($vendor_id), array('limit' => 20))
        : array();

    if (empty($packet_ids)) {
        echo '<p>' . esc_html__('No agreement packets have been generated for this vendor yet.', 'vms-agreements') . '</p>';
        return;
    }

    $groups = function_exists('vmsa_partition_vendor_portal_packets')
        ? vmsa_partition_vendor_portal_packets($packet_ids)
        : array('current' => $packet_ids, 'history' => array());

    $current_packets = array_values(array_filter(array_map('absint', (array) ($groups['current'] ?? array()))));
    $history_packets = array_values(array_filter(array_map('absint', (array) ($groups['history'] ?? array()))));
    $current_counts = function_exists('vmsa_vendor_portal_packet_counts')
        ? vmsa_vendor_portal_packet_counts($current_packets)
        : array('pending' => 0, 'viewed' => 0, 'acknowledged' => 0);

    $signed_history = 0;
    foreach ($history_packets as $history_packet_id) {
        if (function_exists('vmsa_packet_has_acknowledgement_history') && vmsa_packet_has_acknowledgement_history($history_packet_id)) {
            $signed_history++;
        }
    }

    echo '<p class="description">' . esc_html__('Shows the current agreement status for this vendor and preserves signed packet history for reference.', 'vms-agreements') . '</p>';
    echo '<p>';
    echo '<span class="vmsa-pill vmsa-pill-generated">' . esc_html(sprintf(__('Needs review: %d', 'vms-agreements'), absint($current_counts['pending'] ?? 0))) . '</span> ';
    echo '<span class="vmsa-pill vmsa-pill-viewed">' . esc_html(sprintf(__('Viewed: %d', 'vms-agreements'), absint($current_counts['viewed'] ?? 0))) . '</span> ';
    echo '<span class="vmsa-pill vmsa-pill-acknowledged">' . esc_html(sprintf(__('Current signed: %d', 'vms-agreements'), absint($current_counts['acknowledged'] ?? 0))) . '</span> ';
    echo '<span class="vmsa-pill vmsa-pill-superseded">' . esc_html(sprintf(__('Signed history: %d', 'vms-agreements'), $signed_history)) . '</span>';
    echo '</p>';

    $primary_packet_id = !empty($current_packets) ? absint($current_packets[0]) : absint($packet_ids[0]);
    if ($primary_packet_id <= 0) {
        return;
    }

    $primary_status = (string) get_post_meta($primary_packet_id, '_vmsa_status', true);
    $primary_snapshot = vmsa_get_packet_snapshot($primary_packet_id);
    $event = (array) ($primary_snapshot['event_plan'] ?? array());
    $event_title = trim(vmsa_display_text($event['title'] ?? vmsa_get_post_title_text($primary_packet_id)));
    $event_date = vmsa_format_date((string) ($event['event_date'] ?? ''));
    $link_label = !empty($current_packets) ? __('Current packet:', 'vms-agreements') : __('Latest packet:', 'vms-agreements');

    echo '<p><strong>' . esc_html($link_label) . '</strong><br>';
    echo '<a href="' . esc_url(vmsa_admin_page_url(array('packet_id' => $primary_packet_id))) . '">' . esc_html(vmsa_packet_display_title($primary_packet_id)) . '</a></p>';
    echo '<p><span class="vmsa-pill vmsa-pill-' . esc_attr($primary_status) . '">' . esc_html(vmsa_get_status_label($primary_status)) . '</span></p>';

    if ($event_title !== '' || $event_date !== '-') {
        echo '<p class="description">';
        if ($event_title !== '') {
            echo esc_html($event_title);
        }
        if ($event_date !== '-') {
            echo ($event_title !== '' ? '<br>' : '') . esc_html($event_date);
        }
        echo '</p>';
    }

    if (empty($current_packets)) {
        echo '<p class="description">' . esc_html__('No current packet is active for this vendor right now. Open the latest packet for history details or generate a fresh packet from the Event Plan when needed.', 'vms-agreements') . '</p>';
    } else {
        echo '<p><a class="button button-primary" href="' . esc_url(vmsa_admin_page_url(array('packet_id' => $primary_packet_id))) . '">' . esc_html__('View Current Packet', 'vms-agreements') . '</a></p>';
    }
}
