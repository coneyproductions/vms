<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_enqueue_scripts', 'vmsa_public_enqueue_assets');
add_action('init', 'vmsa_bootstrap_public_cache_safety', 0);
add_action('send_headers', 'vmsa_send_public_cache_headers', 0);
add_action('template_redirect', 'vmsa_maybe_render_public_review_page', 1);
add_action('admin_post_vmsa_acknowledge_packet', 'vmsa_handle_public_acknowledgement');
add_action('admin_post_nopriv_vmsa_acknowledge_packet', 'vmsa_handle_public_acknowledgement');

vmsa_bootstrap_public_cache_safety();

function vmsa_is_public_review_request(): bool
{
    return isset($_GET['vmsa_packet'], $_GET['vmsa_token']);
}

function vmsa_is_public_acknowledgement_request(): bool
{
    return isset($_REQUEST['action']) && sanitize_key((string) wp_unslash($_REQUEST['action'])) === 'vmsa_acknowledge_packet';
}

function vmsa_is_public_cache_sensitive_request(): bool
{
    return vmsa_is_public_review_request() || vmsa_is_public_acknowledgement_request();
}

function vmsa_bootstrap_public_cache_safety(): void
{
    static $bootstrapped = false;

    if ($bootstrapped || !vmsa_is_public_cache_sensitive_request()) {
        return;
    }

    $bootstrapped = true;
    vmsa_disable_public_cache();
    add_filter('nocache_headers', 'vmsa_filter_public_nocache_headers', 20);
}

function vmsa_send_public_cache_headers(): void
{
    if (!vmsa_is_public_cache_sensitive_request()) {
        return;
    }

    vmsa_disable_public_cache();
}

function vmsa_filter_public_nocache_headers(array $headers): array
{
    if (!vmsa_is_public_cache_sensitive_request()) {
        return $headers;
    }

    $headers['Cache-Control'] = 'private, no-store, no-cache, must-revalidate, max-age=0, s-maxage=0';
    $headers['Pragma'] = 'no-cache';
    $headers['Expires'] = 'Wed, 11 Jan 1984 05:00:00 GMT';
    $headers['Surrogate-Control'] = 'no-store, no-cache, max-age=0';
    $headers['X-Accel-Expires'] = '0';

    return $headers;
}

function vmsa_is_public_print_request(): bool
{
    return vmsa_is_public_review_request() && isset($_GET['vmsa_print']) && (string) $_GET['vmsa_print'] === '1';
}

function vmsa_packet_print_url(int $packet_id, string $token = ''): string
{
    return vmsa_packet_review_url($packet_id, $token, array('vmsa_print' => '1'));
}

function vmsa_public_enqueue_assets(): void
{
    if (!vmsa_is_public_review_request() && !is_user_logged_in()) {
        return;
    }

    wp_enqueue_style(
        'vmsa-public',
        VMSA_PLUGIN_URL . 'assets/public.css',
        array(),
        VMSA_VERSION
    );
}

function vmsa_get_public_review_context(): array|WP_Error
{
    $packet_id = isset($_REQUEST['vmsa_packet']) ? absint($_REQUEST['vmsa_packet']) : 0;
    $token = isset($_REQUEST['vmsa_token']) ? sanitize_text_field(wp_unslash((string) $_REQUEST['vmsa_token'])) : '';

    if ($packet_id <= 0 || $token === '' || get_post_type($packet_id) !== VMSA_CPT_PACKET) {
        return new WP_Error('vmsa_invalid_link', __('This agreement review link is invalid.', 'vms-agreements'));
    }

    if (!vmsa_validate_review_token($packet_id, $token)) {
        return new WP_Error('vmsa_invalid_token', __('This agreement review link is invalid or has been replaced.', 'vms-agreements'));
    }

    $status = (string) get_post_meta($packet_id, '_vmsa_status', true);
    if (in_array($status, array('voided', 'superseded'), true)) {
        return new WP_Error('vmsa_inactive_packet', __('This Agreement Packet is no longer active. Please contact the venue for the current Agreement Packet.', 'vms-agreements'));
    }

    $snapshot = vmsa_get_packet_snapshot($packet_id);
    if (empty($snapshot)) {
        return new WP_Error('vmsa_missing_snapshot', __('This agreement packet is missing its stored terms snapshot.', 'vms-agreements'));
    }

    $event_plan_id = absint($snapshot['event_plan']['id'] ?? get_post_meta($packet_id, '_vmsa_event_plan_id', true));
    if ($event_plan_id > 0) {
        clean_post_cache($event_plan_id);
    }

    return array(
        'packet_id' => $packet_id,
        'token' => $token,
        'status' => $status,
        'snapshot' => $snapshot,
        'terms_status' => vmsa_packet_current_terms_status($packet_id),
        'ack_records' => vmsa_get_ack_records($packet_id),
    );
}

function vmsa_maybe_render_public_review_page(): void
{
    if (!vmsa_is_public_review_request()) {
        return;
    }

    vmsa_disable_public_cache();

    $context = vmsa_get_public_review_context();

    if (!is_wp_error($context) && !vmsa_is_public_print_request()) {
        $packet_id = absint($context['packet_id']);
        $status = (string) ($context['status'] ?? '');
        if (in_array($status, array('generated', 'sent'), true)) {
            update_post_meta($packet_id, '_vmsa_status', 'viewed');
            update_post_meta($packet_id, '_vmsa_first_viewed_at', vmsa_current_datetime_mysql());
            update_post_meta($packet_id, '_vmsa_first_viewed_ip', vmsa_get_request_ip());
            $context['status'] = 'viewed';
        }

        update_post_meta($packet_id, '_vmsa_last_viewed_at', vmsa_current_datetime_mysql());
        update_post_meta($packet_id, '_vmsa_last_viewed_ip', vmsa_get_request_ip());
        update_post_meta($packet_id, '_vmsa_view_count', absint(get_post_meta($packet_id, '_vmsa_view_count', true)) + 1);
    }

    status_header(is_wp_error($context) ? 403 : 200);
    nocache_headers();

    if (is_wp_error($context)) {
        if (vmsa_is_public_print_request()) {
            vmsa_render_public_print_shell($context);
            exit;
        }

        get_header();
        echo '<main class="vmsa-public-wrap" id="vmsa-agreement-review">';
        echo '<section class="vmsa-public-card">';
        echo '<h1>' . esc_html__('Agreement Review Unavailable', 'vms-agreements') . '</h1>';
        echo '<p>' . esc_html($context->get_error_message()) . '</p>';
        echo '</section>';
        echo '</main>';
        get_footer();
        exit;
    }

    if (vmsa_is_public_print_request()) {
        $context['print_mode'] = true;
        vmsa_render_public_print_shell($context);
        exit;
    }

    get_header();
    echo '<main class="vmsa-public-wrap" id="vmsa-agreement-review">';

    vmsa_render_public_review_content($context);

    echo '</main>';
    get_footer();
    exit;
}

function vmsa_render_public_print_shell(array|WP_Error $context): void
{
    $title = __('Agreement Copy', 'vms-agreements');
    if (!is_wp_error($context)) {
        $snapshot = (array) ($context['snapshot'] ?? array());
        $event = (array) ($snapshot['event_plan'] ?? array());
        $event_title = trim(vmsa_display_text($event['title'] ?? ''));
        if ($event_title !== '') {
            $title = sprintf(__('Agreement Copy - %s', 'vms-agreements'), $event_title);
        }
    }

    echo '<!doctype html>';
    echo '<html ' . get_language_attributes() . '>';
    echo '<head>';
    echo '<meta charset="' . esc_attr(get_bloginfo('charset')) . '">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . esc_html(vmsa_display_text($title)) . '</title>';
    wp_head();
    echo '</head>';
    echo '<body class="vmsa-print-mode">';
    echo '<main class="vmsa-public-wrap vmsa-print-wrap" id="vmsa-agreement-print">';

    if (is_wp_error($context)) {
        echo '<section class="vmsa-public-card">';
        echo '<h1>' . esc_html__('Agreement Copy Unavailable', 'vms-agreements') . '</h1>';
        echo '<p>' . esc_html($context->get_error_message()) . '</p>';
        echo '</section>';
    } else {
        vmsa_render_public_print_content($context);
    }

    echo '</main>';
    // Do not call wp_footer() in the standalone print shell. Some themes/plugins inject
    // footer galleries or promotional blocks there, which can leak into saved PDFs.
    echo '</body></html>';
}


function vmsa_render_public_print_content(array $context): void
{
    $packet_id = absint($context['packet_id']);
    $token = (string) ($context['token'] ?? '');
    $snapshot = (array) ($context['snapshot'] ?? array());
    $latest_ack = vmsa_get_latest_ack_record($packet_id);

    $event = (array) ($snapshot['event_plan'] ?? array());
    $operator = (array) ($snapshot['operator'] ?? array());
    $venue = (array) ($snapshot['venue'] ?? array());
    $vendor = (array) ($snapshot['vendor'] ?? array());
    $comp = (array) ($snapshot['compensation'] ?? array());
    $production = (array) ($snapshot['production'] ?? array());
    $production_schedule = (array) ($snapshot['production_schedule'] ?? array());
    $template = (array) ($snapshot['template'] ?? array());
    $acknowledgements = (array) ($template['acknowledgements'] ?? array());

    $event_title = trim(vmsa_display_text($event['title'] ?? vmsa_get_post_title_text($packet_id)));
    $payment_breakdown = (array) ($comp['payment_breakdown'] ?? array());
    $payment_lines = isset($payment_breakdown['lines']) && is_array($payment_breakdown['lines'])
        ? $payment_breakdown['lines']
        : array((string) ($comp['payment_summary'] ?? vmsa_format_payment_summary((array) ($comp['terms'] ?? array()))));

    $print_identity_parts = array_filter(array(
        $event_title,
        vmsa_format_date((string) ($event['event_date'] ?? '')),
        sprintf(__('Packet #%d', 'vms-agreements'), $packet_id),
        trim((string) ($template['version'] ?? '')) !== '' ? sprintf(__('Agreement version %s', 'vms-agreements'), (string) $template['version']) : '',
    ));
    echo '<div class="vmsa-print-page-identity" aria-hidden="true">' . esc_html(implode(' • ', $print_identity_parts)) . '</div>';

    echo '<section class="vmsa-print-title">';
    echo '<div>';
    echo '<p class="vmsa-public-kicker">' . esc_html__('Vendor Agreement Copy', 'vms-agreements') . '</p>';
    echo '<h1>' . esc_html(vmsa_display_text($event_title !== '' ? $event_title : __('Agreement Copy', 'vms-agreements'))) . '</h1>';
    echo '</div>';
    echo '<div class="vmsa-public-print-actions">';
    echo '<button type="button" class="vmsa-public-print-button" onclick="window.print();">' . esc_html__('Print / Save as PDF', 'vms-agreements') . '</button>';
    echo '<a class="vmsa-public-print-link" href="' . esc_url(vmsa_packet_review_url($packet_id, $token)) . '">' . esc_html__('Back to review page', 'vms-agreements') . '</a>';
    echo '</div>';
    echo '</section>';

    echo '<section class="vmsa-print-panel">';
    echo '<h2>' . esc_html__('Agreement Packet Summary', 'vms-agreements') . '</h2>';
    echo '<div class="vmsa-summary-identity-grid">';
    vmsa_render_public_detail_group(__('Event Details', 'vms-agreements'), array(
        __('Event name', 'vms-agreements') => $event_title,
        __('Date', 'vms-agreements') => vmsa_format_date((string) ($event['event_date'] ?? '')),
        __('Time', 'vms-agreements') => vmsa_format_time_range((string) ($event['start_time'] ?? ''), (string) ($event['end_time'] ?? '')),
        __('Venue', 'vms-agreements') => (string) ($venue['name'] ?? ''),
        __('Contracting party', 'vms-agreements') => (string) ($operator['contracting_entity'] ?? ''),
    ));
    $vendor_detail_rows = array(
        __('Vendor / act', 'vms-agreements') => (string) ($vendor['name'] ?? ''),
    );
    if (array_key_exists('legal_name', $vendor)) {
        $vendor_detail_rows[__('Legal contracting name', 'vms-agreements')] = (string) ($vendor['legal_name'] ?? '');
    }
    if (array_key_exists('representative_name', $vendor)) {
        $vendor_detail_rows[__('Representative / contact', 'vms-agreements')] = (string) ($vendor['representative_name'] ?? '');
    }
    $vendor_detail_rows[__('Vendor email', 'vms-agreements')] = (string) ($vendor['email'] ?? '');
    $vendor_detail_rows[__('Vendor phone', 'vms-agreements')] = vmsa_format_phone_number((string) ($vendor['phone'] ?? ''));
    vmsa_render_public_detail_group(__('Vendor Details', 'vms-agreements'), $vendor_detail_rows);
    echo '</div>';
    echo '<div class="vmsa-summary-comp-row">';
    vmsa_render_public_detail_group(__('Compensation Terms', 'vms-agreements'), array(
        __('Compensation terms', 'vms-agreements') => vmsa_clean_compensation_summary_text((string) ($comp['summary'] ?? '')),
        __('Deposit / Advance Terms', 'vms-agreements') => (string) ($comp['deposit_summary'] ?? ''),
        __('Payment Terms', 'vms-agreements') => $payment_lines,
    ));
    echo '</div>';
    vmsa_render_public_bonus_payout_table((array) ($comp['terms'] ?? array()));
    if (!empty($production)) {
        vmsa_render_public_production_summary($production);
    }
    if (!empty($production_schedule)) {
        vmsa_render_public_production_schedule($production_schedule);
    }
    echo '</section>';

    $clauses = vmsa_render_print_clause_blocks($snapshot);
    if (!empty($clauses)) {
        echo '<section class="vmsa-print-panel vmsa-print-terms-panel">';
        echo '<h2>' . esc_html__('Agreement Terms', 'vms-agreements') . '</h2>';
        echo '<div class="vmsa-print-clauses">';
        foreach ($clauses as $clause) {
            $title = trim(vmsa_display_text($clause['title'] ?? ''));
            $body = trim(vmsa_display_text($clause['body'] ?? ''));
            if ($title === '' && $body === '') {
                continue;
            }

            echo '<article class="vmsa-print-clause">';
            if ($title !== '') {
                echo '<h3>' . esc_html(vmsa_display_text($title)) . '</h3>';
            }
            if ($body !== '') {
                echo vmsa_render_public_clause_body_html($body);
            }
            echo '</article>';
        }
        echo '</div>';
        echo '</section>';
    }

    if (!empty($latest_ack)) {
        vmsa_render_public_ack_proof($latest_ack, $acknowledgements);
    } else {
        vmsa_render_public_print_signature_panel($vendor, $operator);
        echo '<section class="vmsa-print-panel vmsa-print-ack-status">';
        echo '<h2>' . esc_html__('Acknowledgement Status', 'vms-agreements') . '</h2>';
        echo '<p>' . esc_html__('This Agreement Packet has not been acknowledged yet. Acknowledgement proof will appear after the Vendor submits their acknowledgement.', 'vms-agreements') . '</p>';
        echo '</section>';
    }
}

function vmsa_render_public_print_signature_panel(array $vendor, array $operator): void
{
    $vendor_legal = trim(vmsa_display_text($vendor['legal_name'] ?? ''));
    if ($vendor_legal === '') {
        $vendor_legal = trim(vmsa_display_text($vendor['name'] ?? ''));
    }

    $venue_legal = trim(vmsa_display_text($operator['contracting_entity'] ?? ''));

    echo '<section class="vmsa-print-panel vmsa-print-signatures">';
    echo '<h2>' . esc_html__('Physical Signatures', 'vms-agreements') . '</h2>';
    echo '<p class="vmsa-print-signature-note">' . esc_html__('Use this section when executing a printed copy instead of the VMS electronic acknowledgement. Duplicate physical signatures are not required after electronic acknowledgement.', 'vms-agreements') . '</p>';
    echo '<div class="vmsa-print-signature-grid">';

    echo '<div class="vmsa-print-signature-party">';
    echo '<h3>' . esc_html__('Vendor', 'vms-agreements') . '</h3>';
    if ($vendor_legal !== '') {
        echo '<div class="vmsa-print-signature-identity"><strong>' . esc_html__('Legal contracting name:', 'vms-agreements') . '</strong> ' . esc_html($vendor_legal) . '</div>';
    }
    foreach (array(
        __('Signature', 'vms-agreements'),
        __('Printed name', 'vms-agreements'),
        __('Title / capacity, if applicable', 'vms-agreements'),
        __('Date', 'vms-agreements'),
    ) as $caption) {
        echo '<div class="vmsa-print-signature-line"></div><span class="vmsa-print-signature-caption">' . esc_html($caption) . '</span>';
    }
    echo '</div>';

    echo '<div class="vmsa-print-signature-party">';
    echo '<h3>' . esc_html__('Venue', 'vms-agreements') . '</h3>';
    if ($venue_legal !== '') {
        echo '<div class="vmsa-print-signature-identity"><strong>' . esc_html__('Contracting party:', 'vms-agreements') . '</strong> ' . esc_html($venue_legal) . '</div>';
    }
    foreach (array(
        __('Signature', 'vms-agreements'),
        __('Printed name', 'vms-agreements'),
        __('Title / capacity', 'vms-agreements'),
        __('Date', 'vms-agreements'),
    ) as $caption) {
        echo '<div class="vmsa-print-signature-line"></div><span class="vmsa-print-signature-caption">' . esc_html($caption) . '</span>';
    }
    echo '</div>';

    echo '</div>';
    echo '</section>';
}

function vmsa_vendor_facing_stale_packet_message(): string
{
    return __('This Agreement Packet is no longer current. Please use the latest Agreement Packet issued by the venue.', 'vms-agreements');
}

function vmsa_vendor_facing_terms_status_label(array $terms_status): string
{
    $state = sanitize_key((string) ($terms_status['state'] ?? ''));
    if ($state !== '' && !in_array($state, array('current', 'historical'), true)) {
        return vmsa_vendor_facing_stale_packet_message();
    }

    return (string) ($terms_status['label'] ?? '');
}

function vmsa_render_print_clause_blocks(array $snapshot): array
{
    $template = (array) ($snapshot['template'] ?? array());
    $blocks = vmsa_sanitize_template_blocks((array) ($template['blocks'] ?? vmsa_get_template_blocks(absint($template['id'] ?? 0))));
    $tokens = vmsa_template_tokens($snapshot);
    $skip_keys = array('event_summary', 'vendor_summary', 'compensation_summary', 'deposit_summary', 'production_summary', 'acknowledgement_proof');
    $clauses = array();

    foreach ($blocks as $block) {
        if (empty($block['enabled'])) {
            continue;
        }

        $key = (string) ($block['key'] ?? '');
        if (in_array($key, $skip_keys, true)) {
            continue;
        }

        $title = trim(vmsa_display_text($block['title'] ?? ''));
        $body = trim(vmsa_display_text(strtr((string) ($block['body'] ?? ''), $tokens)));
        if ($title === '' && $body === '') {
            continue;
        }

        $clauses[] = array(
            'key' => $key,
            'title' => $title,
            'body' => $body,
        );
    }

    return $clauses;
}


function vmsa_render_public_clause_body_html(string $body): string
{
    $lines = preg_split('/\R/u', $body);
    if (!is_array($lines)) {
        $lines = array($body);
    }

    $html = '';
    $paragraph = array();
    $in_list = false;

    $flush_paragraph = static function () use (&$html, &$paragraph): void {
        if (empty($paragraph)) {
            return;
        }
        $text = trim(implode(' ', $paragraph));
        if ($text !== '') {
            $html .= '<p>' . esc_html($text) . '</p>';
        }
        $paragraph = array();
    };

    $close_list = static function () use (&$html, &$in_list): void {
        if ($in_list) {
            $html .= '</ul>';
            $in_list = false;
        }
    };

    foreach ($lines as $line) {
        $trimmed = trim((string) $line);
        if ($trimmed === '') {
            $flush_paragraph();
            $close_list();
            continue;
        }

        if (str_starts_with($trimmed, '- ')) {
            $flush_paragraph();
            if (!$in_list) {
                $html .= '<ul class="vmsa-public-agreement-list">';
                $in_list = true;
            }
            $html .= '<li>' . esc_html(trim(substr($trimmed, 2))) . '</li>';
            continue;
        }

        $close_list();
        $paragraph[] = $trimmed;
    }

    $flush_paragraph();
    $close_list();
    return $html;
}

function vmsa_render_public_agreement_text_html(array $snapshot): string
{
    $clauses = vmsa_render_print_clause_blocks($snapshot);
    if (empty($clauses)) {
        return '';
    }

    $html = '';
    foreach ($clauses as $clause) {
        $title = trim(vmsa_display_text($clause['title'] ?? ''));
        $body = trim(vmsa_display_text($clause['body'] ?? ''));
        if ($title === '' && $body === '') {
            continue;
        }

        $html .= '<article class="vmsa-public-agreement-clause">';
        if ($title !== '') {
            $html .= '<strong class="vmsa-public-agreement-heading">' . esc_html($title) . '</strong>';
        }
        if ($body !== '') {
            $html .= vmsa_render_public_clause_body_html($body);
        }
        $html .= '</article>';
    }

    return $html;
}

function vmsa_render_public_review_content(array $context): void
{
    $packet_id = absint($context['packet_id']);
    $token = (string) ($context['token'] ?? '');
    $status = (string) ($context['status'] ?? '');
    $snapshot = (array) ($context['snapshot'] ?? array());
    $terms_status = (array) ($context['terms_status'] ?? array());
    $ack_records = (array) ($context['ack_records'] ?? array());

    $event = (array) ($snapshot['event_plan'] ?? array());
    $operator = (array) ($snapshot['operator'] ?? array());
    $venue = (array) ($snapshot['venue'] ?? array());
    $vendor = (array) ($snapshot['vendor'] ?? array());
    $comp = (array) ($snapshot['compensation'] ?? array());
    $production = (array) ($snapshot['production'] ?? array());
    $production_schedule = (array) ($snapshot['production_schedule'] ?? array());
    $template = (array) ($snapshot['template'] ?? array());
    $acknowledgements = (array) ($template['acknowledgements'] ?? array());
    $latest_ack = vmsa_get_latest_ack_record($packet_id);
    $print_mode = !empty($context['print_mode']);
    $can_acknowledge = !$print_mode && (($terms_status['state'] ?? '') === 'current') && $status !== 'acknowledged' && empty($latest_ack);
    $rendered_ack_keys = array();

    $notice = isset($_GET['vmsa_notice']) ? sanitize_key((string) $_GET['vmsa_notice']) : '';

    echo '<section class="vmsa-public-card vmsa-public-hero">';
    echo '<p class="vmsa-public-kicker">' . esc_html__('Vendor Agreement Review', 'vms-agreements') . '</p>';
    echo '<h1>' . esc_html(vmsa_display_text($event['title'] ?? vmsa_get_post_title_text($packet_id))) . '</h1>';
    if ($print_mode) {
        echo '<p>' . esc_html__('Printable Agreement Packet copy. Use your browser print dialog to print or save this page as a PDF.', 'vms-agreements') . '</p>';
        echo '<div class="vmsa-public-print-actions">';
        echo '<button type="button" class="vmsa-public-print-button" onclick="window.print();">' . esc_html__('Print / Save as PDF', 'vms-agreements') . '</button>';
        echo '<a class="vmsa-public-print-link" href="' . esc_url(vmsa_packet_review_url($packet_id, $token)) . '">' . esc_html__('Back to review page', 'vms-agreements') . '</a>';
        echo '</div>';
    } else {
        echo '<p>' . esc_html__('Please review this Agreement Packet, including the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, and Agreement Terms below. Your acknowledgement will create an Acknowledgement Record and related Packet Verification Records.', 'vms-agreements') . '</p>';
        echo '<div class="vmsa-public-print-actions">';
        echo '<a class="vmsa-public-print-button" target="_blank" rel="noopener noreferrer" href="' . esc_url(vmsa_packet_print_url($packet_id, $token)) . '">' . esc_html__('Print / Save as PDF', 'vms-agreements') . '</a>';
        echo '</div>';
    }
    if (!$print_mode) {
        echo '<div class="vmsa-public-pills">';
        echo '<span>' . esc_html(vmsa_get_status_label($status)) . '</span>';
        echo '<span>' . esc_html(vmsa_vendor_facing_terms_status_label($terms_status)) . '</span>';
        echo '</div>';
    }
    echo '</section>';

    if ($notice === 'acknowledged') {
        echo '<div class="vmsa-public-notice vmsa-public-notice-success">' . esc_html__('Agreement Packet acknowledgement received. Your Acknowledgement Record is shown below.', 'vms-agreements') . '</div>';
    } elseif ($notice === 'missing_required') {
        echo '<div class="vmsa-public-notice vmsa-public-notice-error">' . esc_html__('Please complete every required acknowledgement before submitting.', 'vms-agreements') . '</div>';
    } elseif ($notice === 'stale') {
        echo '<div class="vmsa-public-notice vmsa-public-notice-error">' . esc_html(vmsa_vendor_facing_stale_packet_message()) . '</div>';
    }

    if (($terms_status['state'] ?? '') !== 'current' && $notice !== 'stale') {
        echo '<div class="vmsa-public-notice vmsa-public-notice-error">' . esc_html(vmsa_vendor_facing_terms_status_label($terms_status)) . '</div>';
    }

    if ($can_acknowledge) {
        echo '<form class="vmsa-public-form vmsa-public-inline-form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="vmsa_acknowledge_packet">';
        echo '<input type="hidden" name="vmsa_packet" value="' . esc_attr((string) $packet_id) . '">';
        echo '<input type="hidden" name="vmsa_token" value="' . esc_attr($token) . '">';
    }

    echo '<section class="vmsa-public-card">';
    echo '<h2>' . esc_html__('Agreement Packet Summary', 'vms-agreements') . '</h2>';
    echo '<div class="vmsa-summary-identity-grid">';
    vmsa_render_public_detail_group(__('Event Details', 'vms-agreements'), array(
        __('Event name', 'vms-agreements') => (string) ($event['title'] ?? ''),
        __('Date', 'vms-agreements') => vmsa_format_date((string) ($event['event_date'] ?? '')),
        __('Time', 'vms-agreements') => vmsa_format_time_range((string) ($event['start_time'] ?? ''), (string) ($event['end_time'] ?? '')),
        __('Venue', 'vms-agreements') => (string) ($venue['name'] ?? ''),
        __('Contracting party', 'vms-agreements') => (string) ($operator['contracting_entity'] ?? ''),
    ));
    $vendor_detail_rows = array(
        __('Vendor / act', 'vms-agreements') => (string) ($vendor['name'] ?? ''),
    );
    if (array_key_exists('legal_name', $vendor)) {
        $vendor_detail_rows[__('Legal contracting name', 'vms-agreements')] = (string) ($vendor['legal_name'] ?? '');
    }
    if (array_key_exists('representative_name', $vendor)) {
        $vendor_detail_rows[__('Representative / contact', 'vms-agreements')] = (string) ($vendor['representative_name'] ?? '');
    }
    $vendor_detail_rows[__('Vendor email', 'vms-agreements')] = (string) ($vendor['email'] ?? '');
    $vendor_detail_rows[__('Vendor phone', 'vms-agreements')] = vmsa_format_phone_number((string) ($vendor['phone'] ?? ''));
    vmsa_render_public_detail_group(__('Vendor Details', 'vms-agreements'), $vendor_detail_rows);
    echo '</div>';
    $payment_breakdown = (array) ($comp['payment_breakdown'] ?? array());
    $payment_lines = isset($payment_breakdown['lines']) && is_array($payment_breakdown['lines'])
        ? $payment_breakdown['lines']
        : array((string) ($comp['payment_summary'] ?? vmsa_format_payment_summary((array) ($comp['terms'] ?? array()))));
    echo '<div class="vmsa-summary-comp-row">';
    vmsa_render_public_detail_group(__('Compensation Terms', 'vms-agreements'), array(
        __('Compensation terms', 'vms-agreements') => vmsa_clean_compensation_summary_text((string) ($comp['summary'] ?? '')),
        __('Deposit / Advance Terms', 'vms-agreements') => (string) ($comp['deposit_summary'] ?? ''),
        __('Payment Terms', 'vms-agreements') => $payment_lines,
    ));
    echo '</div>';
    vmsa_render_public_bonus_payout_table((array) ($comp['terms'] ?? array()));
    if (!empty($production)) {
        vmsa_render_public_production_summary($production);
    }
    if (!empty($production_schedule)) {
        vmsa_render_public_production_schedule($production_schedule);
    }
    if ($can_acknowledge) {
        vmsa_render_public_inline_ack_checkbox($acknowledgements, 'terms_reviewed', $rendered_ack_keys);
        vmsa_render_public_inline_ack_checkbox($acknowledgements, 'deposit_reviewed', $rendered_ack_keys);
    }
    echo '</section>';

    echo '<section class="vmsa-public-card">';
    echo '<h2>' . esc_html__('Agreement Terms', 'vms-agreements') . '</h2>';
    echo '<div class="vmsa-public-agreement-text">' . vmsa_render_public_agreement_text_html($snapshot) . '</div>';
    echo '</section>';

    if ($status === 'acknowledged' || !empty($latest_ack)) {
        vmsa_render_public_ack_proof($latest_ack, $acknowledgements);
        return;
    }

    if ($print_mode) {
        echo '<section class="vmsa-public-card">';
        echo '<h2>' . esc_html__('Acknowledgement Status', 'vms-agreements') . '</h2>';
        echo '<p>' . esc_html__('This Agreement Packet has not been acknowledged yet. Acknowledgement proof will appear here after the vendor submits their acknowledgement.', 'vms-agreements') . '</p>';
        echo '</section>';
        return;
    }

    echo '<section class="vmsa-public-card vmsa-public-submit-card">';
    echo '<h2>' . esc_html__('Signer Details & Acknowledge', 'vms-agreements') . '</h2>';

    if ($can_acknowledge) {
        echo '<p>' . esc_html__('Complete the signer details below, confirm the remaining acknowledgement, and submit this Agreement Packet. The signer details, acknowledgement date/time, IP address, agreement version, packet ID, terms hash, compensation hash, and related Packet Verification Records will be recorded.', 'vms-agreements') . '</p>';
        echo '<div class="vmsa-public-two-col">';
        echo '<label>' . esc_html__('Signer name', 'vms-agreements') . '<input type="text" name="signer_name" value="' . esc_attr((string) ($vendor['representative_name'] ?? '')) . '" required autocomplete="name"></label>';
        echo '<label>' . esc_html__('Signer email', 'vms-agreements') . '<input type="email" name="signer_email" value="' . esc_attr((string) ($vendor['email'] ?? '')) . '" required autocomplete="email"></label>';
        echo '</div>';
        echo '<div class="vmsa-public-checks">';
        vmsa_render_public_inline_ack_checkbox($acknowledgements, 'audit_understood', $rendered_ack_keys);
        vmsa_render_public_remaining_ack_checkboxes($acknowledgements, $rendered_ack_keys);
        echo '</div>';
        echo '<button type="submit" class="vmsa-public-submit">' . esc_html__('Acknowledge Agreement Packet', 'vms-agreements') . '</button>';
    } else {
        echo '<p>' . esc_html__('Acknowledgement is disabled until the venue issues the latest current Agreement Packet.', 'vms-agreements') . '</p>';
    }
    echo '</section>';

    if ($can_acknowledge) {
        echo '</form>';
    }
}
function vmsa_render_public_inline_ack_checkbox(array $acknowledgements, string $target_key, array &$rendered_ack_keys): void
{
    foreach ($acknowledgements as $ack) {
        if (!is_array($ack)) {
            continue;
        }

        $key = sanitize_key((string) ($ack['key'] ?? ''));
        $label = vmsa_display_text($ack['label'] ?? '');
        if ($key !== $target_key || $label === '') {
            continue;
        }

        echo '<div class="vmsa-public-inline-ack">';
        echo '<label><input type="checkbox" name="vmsa_ack[]" value="' . esc_attr($key) . '" required> <span>' . esc_html($label) . '</span></label>';
        echo '</div>';
        $rendered_ack_keys[$key] = true;
        return;
    }
}

function vmsa_render_public_remaining_ack_checkboxes(array $acknowledgements, array &$rendered_ack_keys): void
{
    foreach ($acknowledgements as $ack) {
        if (!is_array($ack)) {
            continue;
        }

        $key = sanitize_key((string) ($ack['key'] ?? ''));
        $label = vmsa_display_text($ack['label'] ?? '');
        if ($key === '' || $label === '' || isset($rendered_ack_keys[$key])) {
            continue;
        }

        echo '<div class="vmsa-public-inline-ack">';
        echo '<label><input type="checkbox" name="vmsa_ack[]" value="' . esc_attr($key) . '" required> <span>' . esc_html($label) . '</span></label>';
        echo '</div>';
        $rendered_ack_keys[$key] = true;
    }
}

function vmsa_render_public_detail_group(string $title, array $rows): void
{
    echo '<div class="vmsa-public-detail-group"><h3>' . esc_html(vmsa_display_text($title)) . '</h3><dl>';
    foreach ($rows as $label => $value) {
        echo '<dt>' . esc_html(vmsa_display_text($label)) . '</dt>';
        if (is_array($value)) {
            $items = array_values(array_filter(array_map('trim', array_map('vmsa_display_text', $value))));
            if (empty($items)) {
                echo '<dd>-</dd>';
            } else {
                echo '<dd><ul class="vmsa-public-detail-list">';
                foreach ($items as $item) {
                    echo '<li>' . esc_html($item) . '</li>';
                }
                echo '</ul></dd>';
            }
            continue;
        }
        $value = vmsa_display_text($value);
        echo '<dd>' . esc_html($value !== '' ? $value : '-') . '</dd>';
    }
    echo '</dl></div>';
}



function vmsa_render_public_production_schedule(array $schedule): void
{
    if (empty($schedule)) {
        return;
    }

    $arrival = trim((string) ($schedule['arrival_loadin'] ?? ''));
    $sound_start = trim((string) ($schedule['soundcheck_start'] ?? ''));
    $sound_end = trim((string) ($schedule['soundcheck_end'] ?? ''));
    $vacate = trim((string) ($schedule['vacate_by'] ?? ''));

    if ($arrival === '' && $sound_start === '' && $sound_end === '' && $vacate === '') {
        return;
    }

    $items = array(
        __('Arrival / Load-in', 'vms-agreements') => $arrival !== '' ? vmsa_format_time($arrival) : __('Not specified', 'vms-agreements'),
        __('Soundcheck Starts', 'vms-agreements') => $sound_start !== '' ? vmsa_format_time($sound_start) : __('Not specified', 'vms-agreements'),
        __('Soundcheck Complete', 'vms-agreements') => $sound_end !== '' ? vmsa_format_time($sound_end) : __('Not specified', 'vms-agreements'),
        __('Load-out / Vacate By', 'vms-agreements') => $vacate !== '' ? vmsa_format_time($vacate) : __('To be communicated by Venue', 'vms-agreements'),
    );

    echo '<div class="vmsa-summary-production-row vmsa-summary-schedule-row">';
    echo '<div class="vmsa-public-detail-group vmsa-public-production-group">';
    echo '<h3>' . esc_html__('Production Schedule', 'vms-agreements') . '</h3>';
    echo '<div class="vmsa-public-production-grid vmsa-public-schedule-grid">';
    foreach ($items as $label => $value) {
        echo '<div class="vmsa-public-production-item">';
        echo '<span class="vmsa-public-production-label">' . esc_html(vmsa_display_text($label)) . '</span>';
        echo '<strong class="vmsa-public-production-value">' . esc_html(vmsa_display_text($value)) . '</strong>';
        echo '</div>';
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
}

function vmsa_render_public_production_summary(array $production): void
{
    $items = array(
        __('Stage', 'vms-agreements') => vmsa_production_responsibility_label((string) ($production['stage'] ?? '')),
        __('House Sound / PA', 'vms-agreements') => vmsa_production_responsibility_label((string) ($production['house_sound'] ?? '')),
        __('Stage Lighting', 'vms-agreements') => vmsa_production_responsibility_label((string) ($production['stage_lighting'] ?? '')),
        __('Sound Engineer', 'vms-agreements') => vmsa_production_responsibility_label((string) ($production['sound_engineer'] ?? '')),
    );

    echo '<div class="vmsa-summary-production-row">';
    echo '<div class="vmsa-public-detail-group vmsa-public-production-group">';
    echo '<h3>' . esc_html__('Production Responsibilities', 'vms-agreements') . '</h3>';
    echo '<div class="vmsa-public-production-grid">';
    foreach ($items as $label => $value) {
        echo '<div class="vmsa-public-production-item">';
        echo '<span class="vmsa-public-production-label">' . esc_html(vmsa_display_text($label)) . '</span>';
        echo '<strong class="vmsa-public-production-value">' . esc_html(vmsa_display_text($value)) . '</strong>';
        echo '</div>';
    }
    echo '</div>';
    if (sanitize_key((string) ($production['house_sound'] ?? '')) === 'yes') {
        echo '<p class="vmsa-public-production-note">' . esc_html__('House Sound / PA includes the Venue-confirmed standard house audio package for the agreed input list. Vendor supplies any in-ear monitor system and specialty or wireless equipment unless the Venue accepts it in writing.', 'vms-agreements') . '</p>';
    }
    echo '</div>';
    echo '</div>';
}

function vmsa_render_public_bonus_payout_table(array $terms): void
{
    $rows = function_exists('vmsa_build_bonus_payout_rows') ? vmsa_build_bonus_payout_rows($terms) : array();
    if (empty($rows)) {
        return;
    }

    echo '<div class="vmsa-public-bonus-payout">';
    echo '<h3>' . esc_html__('Bonus payout schedule', 'vms-agreements') . '</h3>';
    echo '<div class="vmsa-public-bonus-layout">';
    echo '<div class="vmsa-public-bonus-table-wrap">';
    echo '<table class="vmsa-public-bonus-payout-table"><thead><tr>';
    echo '<th scope="col">' . esc_html(vmsa_bonus_count_source_table_heading($terms)) . '</th>';
    echo '<th scope="col">' . esc_html__('Payout', 'vms-agreements') . '</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr>';
        echo '<td>' . esc_html((string) absint($row['count'] ?? 0)) . '</td>';
        echo '<td>' . esc_html(vmsa_money($row['payout'] ?? null)) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
    echo '</div>';
    $note = function_exists('vmsa_bonus_qualification_note') ? vmsa_bonus_qualification_note($terms) : '';
    if ($note !== '') {
        echo '<div class="vmsa-public-bonus-note-wrap"><p class="vmsa-public-bonus-note">' . esc_html($note) . '</p></div>';
    }
    echo '</div>';
    echo '</div>';
}

function vmsa_render_public_ack_proof(array $record, array $acknowledgements): void
{
    echo '<section class="vmsa-public-card">';
    echo '<h2>' . esc_html__('Acknowledgement Proof', 'vms-agreements') . '</h2>';

    if (empty($record)) {
        echo '<p>' . esc_html__('This Agreement Packet is marked acknowledged, but no detailed Acknowledgement Record was found.', 'vms-agreements') . '</p>';
        echo '</section>';
        return;
    }

    echo '<div class="vmsa-public-proof-box">';
    echo '<p>' . esc_html__('This Acknowledgement Record is stored with the Agreement Packet and its Packet Verification Records.', 'vms-agreements') . '</p>';
    echo '<p><strong>' . esc_html__('Signer:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_display_text($record['signer_name'] ?? '-')) . ' &lt;' . esc_html((string) ($record['signer_email'] ?? '-')) . '&gt;</p>';
    echo '<p><strong>' . esc_html__('Acknowledged:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_format_audit_datetime((string) ($record['acknowledged_at'] ?? ''))) . '</p>';
    echo '<p><strong>' . esc_html__('Packet ID:', 'vms-agreements') . '</strong> ' . esc_html((string) absint($record['packet_id'] ?? 0)) . '</p>';
    echo '<p><strong>' . esc_html__('Agreement version:', 'vms-agreements') . '</strong> ' . esc_html((string) ($record['template_version'] ?? '-')) . '</p>';
    echo '<p><strong>' . esc_html__('IP address:', 'vms-agreements') . '</strong> ' . esc_html((string) ($record['ip_address'] ?? '-')) . '</p>';
    echo '<p><strong>' . esc_html__('Packet Verification Records:', 'vms-agreements') . '</strong></p>';
    echo '<p><strong>' . esc_html__('Terms hash:', 'vms-agreements') . '</strong> <code>' . esc_html((string) ($record['terms_hash'] ?? '-')) . '</code></p>';
    echo '<p><strong>' . esc_html__('Compensation hash:', 'vms-agreements') . '</strong> <code>' . esc_html((string) ($record['comp_hash'] ?? '-')) . '</code></p>';
    echo '</div>';

    echo '<ul class="vmsa-public-proof-list">';
    $ack_rows = isset($record['acknowledgements']) && is_array($record['acknowledgements']) ? $record['acknowledgements'] : array();
    foreach ($ack_rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        echo '<li><strong>' . esc_html(vmsa_display_text($row['label'] ?? '')) . '</strong><span>' . sprintf(
            esc_html__('Acknowledged %1$s - IP: %2$s', 'vms-agreements'),
            esc_html(vmsa_format_audit_datetime((string) ($row['acknowledged_at'] ?? ($record['acknowledged_at'] ?? '')))),
            esc_html((string) ($record['ip_address'] ?? '-'))
        ) . '</span></li>';
    }
    echo '</ul>';
    echo '</section>';
}

function vmsa_handle_public_acknowledgement(): void
{
    vmsa_disable_public_cache();

    $context = vmsa_get_public_review_context();
    if (is_wp_error($context)) {
        wp_die(esc_html($context->get_error_message()));
    }

    $packet_id = absint($context['packet_id']);
    $token = (string) ($context['token'] ?? '');
    $status = (string) get_post_meta($packet_id, '_vmsa_status', true);

    if ($status === 'acknowledged') {
        wp_safe_redirect(vmsa_packet_review_url($packet_id, $token, array('vmsa_notice' => 'acknowledged')));
        exit;
    }

    if (!in_array($status, array('generated', 'sent', 'viewed'), true)) {
        wp_die(esc_html__('This Agreement Packet is not available for acknowledgement.', 'vms-agreements'));
    }

    $terms_status = vmsa_packet_current_terms_status($packet_id);
    if (($terms_status['state'] ?? '') !== 'current') {
        wp_safe_redirect(vmsa_packet_review_url($packet_id, $token, array('vmsa_notice' => 'stale')));
        exit;
    }

    $snapshot = vmsa_get_packet_snapshot($packet_id);
    $template = (array) ($snapshot['template'] ?? array());
    $acknowledgements = array_values(array_filter(array_map('vmsa_sanitize_acknowledgement_row', (array) ($template['acknowledgements'] ?? array()))));
    $required_keys = array_map(static fn($ack): string => (string) ($ack['key'] ?? ''), $acknowledgements);
    $submitted = isset($_POST['vmsa_ack']) && is_array($_POST['vmsa_ack']) ? array_map('sanitize_key', wp_unslash($_POST['vmsa_ack'])) : array();

    foreach ($required_keys as $key) {
        if ($key === '' || !in_array($key, $submitted, true)) {
            wp_safe_redirect(vmsa_packet_review_url($packet_id, $token, array('vmsa_notice' => 'missing_required')));
            exit;
        }
    }

    $signer_name = isset($_POST['signer_name']) ? sanitize_text_field(wp_unslash((string) $_POST['signer_name'])) : '';
    $signer_email = isset($_POST['signer_email']) ? sanitize_email(wp_unslash((string) $_POST['signer_email'])) : '';

    if ($signer_name === '' || $signer_email === '') {
        wp_safe_redirect(vmsa_packet_review_url($packet_id, $token, array('vmsa_notice' => 'missing_required')));
        exit;
    }

    $now = vmsa_current_datetime_mysql();
    $ip = vmsa_get_request_ip();
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash((string) $_SERVER['HTTP_USER_AGENT'])) : '';

    $ack_rows = array();
    foreach ($acknowledgements as $ack) {
        $ack_rows[] = array(
            'key' => (string) ($ack['key'] ?? ''),
            'label' => vmsa_display_text($ack['label'] ?? ''),
            'acknowledged' => true,
            'acknowledged_at' => $now,
        );
    }

    $record = array(
        'id' => wp_generate_uuid4(),
        'packet_id' => $packet_id,
        'event_plan_id' => absint($snapshot['event_plan']['id'] ?? 0),
        'vendor_id' => absint($snapshot['vendor']['id'] ?? 0),
        'signer_name' => $signer_name,
        'signer_email' => $signer_email,
        'acknowledged_at' => $now,
        'acknowledged_at_gmt' => current_time('mysql', true),
        'ip_address' => $ip,
        'user_agent' => $user_agent,
        'user_id' => get_current_user_id(),
        'template_id' => absint($template['id'] ?? 0),
        'template_version' => (string) ($template['version'] ?? ''),
        'terms_hash' => (string) ($snapshot['terms_hash'] ?? ''),
        'comp_hash' => (string) ($snapshot['compensation']['comp_hash'] ?? ''),
        'acknowledgements' => $ack_rows,
    );

    $records = vmsa_get_ack_records($packet_id);
    $records[] = $record;
    update_post_meta($packet_id, '_vmsa_ack_records', $records);
    update_post_meta($packet_id, '_vmsa_status', 'acknowledged');
    update_post_meta($packet_id, '_vmsa_acknowledged_at', $now);
    update_post_meta($packet_id, '_vmsa_acknowledged_by_name', $signer_name);
    update_post_meta($packet_id, '_vmsa_acknowledged_by_email', $signer_email);
    update_post_meta($packet_id, '_vmsa_acknowledged_ip', $ip);

    $confirmation_email = vmsa_build_acknowledgement_confirmation_email($packet_id, $snapshot, $record, vmsa_packet_review_url($packet_id, $token));
    $confirmation_sent = wp_mail(
        $signer_email,
        (string) $confirmation_email['subject'],
        (string) $confirmation_email['body'],
        array('Content-Type: text/plain; charset=UTF-8')
    );

    $email_records = vmsa_get_email_records($packet_id);
    $email_records[] = array(
        'id' => wp_generate_uuid4(),
        'type' => 'acknowledgement_confirmation_email',
        'sent' => (bool) $confirmation_sent,
        'sent_at' => $now,
        'sent_at_gmt' => current_time('mysql', true),
        'sent_by' => 0,
        'to' => $signer_email,
        'subject' => (string) $confirmation_email['subject'],
        'ack_record_id' => (string) ($record['id'] ?? ''),
        'status_before' => $status,
        'error' => $confirmation_sent ? '' : __('wp_mail returned false.', 'vms-agreements'),
    );
    update_post_meta($packet_id, '_vmsa_email_records', $email_records);
    update_post_meta($packet_id, '_vmsa_ack_confirmation_email_sent_at', $now);
    update_post_meta($packet_id, '_vmsa_ack_confirmation_email_sent_to', $signer_email);
    update_post_meta($packet_id, '_vmsa_ack_confirmation_email_last_result', $confirmation_sent ? 'sent' : 'failed');

    $operator_recipients = vmsa_get_operator_acknowledgement_notification_recipients($packet_id, $snapshot, $record);
    if (!empty($operator_recipients)) {
        $operator_email = vmsa_build_operator_acknowledgement_notification_email($packet_id, $snapshot, $record, vmsa_packet_review_url($packet_id, $token));
        $operator_sent = wp_mail(
            $operator_recipients,
            (string) $operator_email['subject'],
            (string) $operator_email['body'],
            array('Content-Type: text/plain; charset=UTF-8')
        );

        $email_records = vmsa_get_email_records($packet_id);
        $email_records[] = array(
            'id' => wp_generate_uuid4(),
            'type' => 'acknowledgement_operator_notification',
            'sent' => (bool) $operator_sent,
            'sent_at' => $now,
            'sent_at_gmt' => current_time('mysql', true),
            'sent_by' => 0,
            'to' => implode(', ', $operator_recipients),
            'subject' => (string) $operator_email['subject'],
            'ack_record_id' => (string) ($record['id'] ?? ''),
            'status_before' => 'acknowledged',
            'error' => $operator_sent ? '' : __('wp_mail returned false.', 'vms-agreements'),
        );
        update_post_meta($packet_id, '_vmsa_email_records', $email_records);
        update_post_meta($packet_id, '_vmsa_ack_operator_email_sent_at', $now);
        update_post_meta($packet_id, '_vmsa_ack_operator_email_sent_to', implode(', ', $operator_recipients));
        update_post_meta($packet_id, '_vmsa_ack_operator_email_last_result', $operator_sent ? 'sent' : 'failed');
    }

    wp_safe_redirect(vmsa_packet_review_url($packet_id, $token, array('vmsa_notice' => 'acknowledged')));
    exit;
}
