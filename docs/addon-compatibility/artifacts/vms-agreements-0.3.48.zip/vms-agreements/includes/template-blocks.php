<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Structured agreement template blocks.
 *
 * The editor intentionally keeps required booking/audit blocks protected while
 * allowing operators to edit clause wording in safer, versioned sections.
 */
function vmsa_default_template_blocks(): array
{
    return array(
        array(
            'key' => 'agreement_packet_scope',
            'label' => __('Agreement Packet scope', 'vms-agreements'),
            'type' => 'protected',
            'required' => true,
            'locked' => true,
            'enabled' => true,
            'title' => __('Agreement Packet Scope', 'vms-agreements'),
            'body' => __('The Agreement Packet Summary above is incorporated into and forms part of this agreement. The contracting parties are the Venue and Vendor identified in that Summary. The booking-specific event, compensation, payment, production, and schedule terms shown there control together with the Agreement Terms below. By acknowledging this Agreement Packet, the signer confirms review of the packet and authority to acknowledge it on behalf of the Vendor.', 'vms-agreements'),
        ),
        array(
            'key' => 'event_summary',
            'label' => __('Event details', 'vms-agreements'),
            'type' => 'protected',
            'required' => true,
            'locked' => true,
            'enabled' => true,
            'title' => __('Event Details', 'vms-agreements'),
            'body' => __('Generated from the Event Plan snapshot: event title, date, performance time, production schedule, venue, and contracting party.', 'vms-agreements'),
        ),
        array(
            'key' => 'vendor_summary',
            'label' => __('Vendor details', 'vms-agreements'),
            'type' => 'protected',
            'required' => true,
            'locked' => true,
            'enabled' => true,
            'title' => __('Vendor Details', 'vms-agreements'),
            'body' => __('Generated from the packet snapshot: act/vendor display name, legal contracting name, representative/contact, email, and phone.', 'vms-agreements'),
        ),
        array(
            'key' => 'compensation_summary',
            'label' => __('Compensation terms', 'vms-agreements'),
            'type' => 'protected',
            'required' => true,
            'locked' => true,
            'enabled' => true,
            'title' => __('Compensation Terms', 'vms-agreements'),
            'body' => __('Generated from the Event Plan compensation terms captured by VMS Core, including any qualifying paid-ticket bonus schedule and final-payment details.', 'vms-agreements'),
        ),
        array(
            'key' => 'deposit_summary',
            'label' => __('Deposit / advance terms', 'vms-agreements'),
            'type' => 'protected',
            'required' => true,
            'locked' => true,
            'enabled' => true,
            'title' => __('Deposit / Advance Terms', 'vms-agreements'),
            'body' => __('Generated from the Event Plan deposit or advance terms captured by VMS Core.', 'vms-agreements'),
        ),
        array(
            'key' => 'production_summary',
            'label' => __('Production responsibilities', 'vms-agreements'),
            'type' => 'protected',
            'required' => true,
            'locked' => true,
            'enabled' => true,
            'title' => __('Production Responsibilities', 'vms-agreements'),
            'body' => __('Generated from booking-specific Venue-provided Yes/No answers for Stage, House Sound / PA, Stage Lighting, and Sound Engineer.', 'vms-agreements'),
        ),
        array(
            'key' => 'performance_commitment',
            'label' => __('Performance / live-band commitment', 'vms-agreements'),
            'type' => 'clause',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Performance / Live-Band Commitment', 'vms-agreements'),
            'body' => __('Vendor agrees to provide the live-band performance represented and booked for this event. Unless the Venue approves a change in writing, the booked act will appear and perform as a live band using live musicians reasonably consistent with the act as represented at booking. Pre-recorded tracks may be used only as supplemental production elements and may not replace the live band or reduce the performance to a solo, karaoke-style, or predominantly pre-recorded presentation. Any material reduction, substitution, or change in the advertised or represented live lineup or presentation must be disclosed promptly and approved by the Venue in writing.', 'vms-agreements'),
        ),
        array(
            'key' => 'cancellation_viability',
            'label' => __('Weather / safety cancellation terms', 'vms-agreements'),
            'type' => 'clause',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Weather / Safety Cancellation', 'vms-agreements'),
            'body' => __("Safety comes first. The Venue may cancel, postpone, pause, or stop the event when weather or another safety condition makes load-in, setup, soundcheck, performance, or venue operation unsafe. Examples include rain, lightning, severe thunderstorms, high winds, flooding, extreme heat, or another comparable event outside either party's reasonable control that makes the event unsafe or impracticable.

Because the Venue's performance stage is uncovered, live production will not be required or permitted during rain or other precipitation that creates an electrical or stage hazard. The Venue may cancel in advance when those conditions are reasonably expected during the production or performance window.

When forecasts allow, the Venue will try to make and communicate a weather decision about 72 hours before the scheduled arrival/load-in time. This is a planning goal; the payment cutoff is 24 hours before scheduled arrival/load-in.

Weather/safety cancellation payment:
- Notice at least 24 hours before scheduled arrival/load-in: no base guarantee is owed, except any separately agreed nonrefundable amount or approved expense.
- Notice less than 24 hours before scheduled arrival/load-in: 100% of the base guarantee is owed.
- If the performance has already begun and is stopped for weather or safety: 100% of the base guarantee is owed.

Any credit of an owed cancellation payment toward a rescheduled engagement must be agreed to in writing by both parties. Variable compensation remains governed by the qualifying paid-ticket terms in this packet.", 'vms-agreements'),
        ),
        array(
            'key' => 'event_viability_cancellation',
            'label' => __('Event viability cancellation terms', 'vms-agreements'),
            'type' => 'clause',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Low Ticket Sales / Event Viability Cancellation', 'vms-agreements'),
            'body' => __("The Venue may cancel because of low ticket sales or overall event viability. The base-guarantee payment depends on when the Venue gives notice:
- Seven or more calendar days before the scheduled performance: no base guarantee is owed.
- Less than seven calendar days before the scheduled performance: 50% of the base guarantee is owed.
- If the Vendor has already arrived on time and is ready and able to perform when the Venue cancels for event viability: 100% of the base guarantee is owed.

These rules do not change the separate weather/safety rules or the Vendor cancellation/performance-issue rules. A different cancellation or reschedule arrangement accepted by both parties in writing controls when applicable.", 'vms-agreements'),
        ),
        array(
            'key' => 'payment_timing',
            'label' => __('Payment timing', 'vms-agreements'),
            'type' => 'clause',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Payment Timing', 'vms-agreements'),
            'body' => __('The payment timing and payment method stated in the Compensation Terms control. Refunds, complimentary or free admissions, and ticket exclusions affect qualifying ticket counts as stated in the Compensation Terms; they are not direct deductions from an otherwise earned base guarantee. Unless this packet states a different final-payment timing, final payment will be issued no later than {standard_final_payment_days} calendar days following the completed performance. If a cancellation payment is owed, it will be issued no later than {standard_final_payment_days} calendar days after the cancellation amount is determined.', 'vms-agreements'),
        ),
        array(
            'key' => 'rider_handling',
            'label' => __('Production / rider handling', 'vms-agreements'),
            'type' => 'clause',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Production / Technical / Hospitality Terms', 'vms-agreements'),
            'body' => __('The Venue is responsible only for production, sound, lighting, staging, staffing, backline, hospitality, and related items expressly listed in this Agreement Packet or otherwise accepted by the Venue in writing for this booking. When House Sound / PA is marked as Venue-provided, the Venue will provide its standard house PA plus the microphones, microphone stands, DI boxes, stage monitor wedges, and ordinary house audio cabling that the Venue confirms for the agreed input list. Vendor is responsible for instruments, instrument/pedalboard cables, amplifiers or other backline unless separately accepted by the Venue, specialty microphones, wireless systems, adapters, personal accessories, and any in-ear monitoring system, including earpieces, bodypacks, transmitters/receivers, and related hardware, unless the Venue expressly agrees otherwise in writing. When technically compatible and available, the Venue may provide console monitor sends to a Vendor-provided in-ear monitoring system. Vendor must disclose its stage plot/input list and any nonstandard technical requirements reasonably in advance. Any technical or hospitality rider is a request unless accepted by the Venue in writing. Unapproved, late, or conflicting rider terms are not binding, and an unapproved rider request is not a valid reason for Vendor to refuse or materially alter the agreed performance.', 'vms-agreements'),
        ),
        array(
            'key' => 'no_show_nonperformance',
            'label' => __('Vendor cancellation / nonperformance handling', 'vms-agreements'),
            'type' => 'clause',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Vendor Cancellation / Performance Issues', 'vms-agreements'),
            'body' => __("Vendor should promptly tell the Venue about any issue that may prevent or materially delay the agreed load-in, setup, soundcheck, or performance. Vendor may raise a specific safety concern, and the Venue will evaluate current conditions and may pause or stop production when necessary for safety. No Vendor personnel are required to work during rain on the uncovered stage or during another immediate unsafe condition.

Unless the Venue has paused production or an immediate hazardous condition prevents safe work, Vendor is expected to follow the agreed Production Schedule. An unapproved refusal or material delay in load-in, setup, soundcheck, or performance may be treated as a performance issue if it materially delays, shortens, or prevents the show.

If a material performance issue occurs, such as an unapproved cancellation, failure to appear, material lateness, refusal to perform, early departure, making performance conditional on an unapproved demand, or another material failure to provide the agreed service, the Venue may document what happened, withhold unpaid amounts where appropriate, and document direct costs or reasonable cover costs caused by the issue. This agreement does not impose an automatic flat penalty.", 'vms-agreements'),
        ),
        array(
            'key' => 'independent_contractor_tax',
            'label' => __('Independent contractor / tax documentation', 'vms-agreements'),
            'type' => 'clause',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Independent Contractor / Tax Documentation', 'vms-agreements'),
            'body' => __('Vendor is engaged as an independent contractor and is responsible for its own personnel, payroll, taxes, instruments, equipment, and obligations except for items the Venue expressly agrees to provide. Vendor will provide a completed Form W-9 or other reasonably required payment/tax documentation before final payment is processed.', 'vms-agreements'),
        ),
        array(
            'key' => 'venue_rules',
            'label' => __('Venue rules / expectations', 'vms-agreements'),
            'type' => 'clause',
            'required' => false,
            'locked' => false,
            'enabled' => true,
            'title' => __('Venue Rules / Performance Expectations', 'vms-agreements'),
            'body' => __('Vendor agrees to appear and perform in a professional, punctual, prepared, and respectful manner; follow reasonable venue policies, safety requirements, staff directions, and lawful conduct expectations; and maintain the family-friendly performance environment communicated for the booking. The Production Schedule shown in this Agreement Packet is the agreed baseline for arrival/load-in and soundcheck. Reasonable later logistical adjustments, including strike/load-out and venue-vacate instructions, may be made by written communication and do not require a new Agreement Packet when they do not materially change the booking. For purposes of the 24-hour weather/safety cancellation cutoff, the scheduled arrival/load-in time shown in the acknowledged Agreement Packet controls unless both parties agree in writing to a different arrival/load-in time before that cutoff. Vendor should promptly tell the Venue about any issue that could affect arrival, performance, staffing, equipment, or guest safety.', 'vms-agreements'),
        ),
        array(
            'key' => 'amendments',
            'label' => __('Amendments / changes', 'vms-agreements'),
            'type' => 'clause',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Changes to Agreed Terms', 'vms-agreements'),
            'body' => __('A material change to the event date, compensation, deposit, performance scope, cancellation terms, or other material booking obligation must be documented in a newer Agreement Packet or another written amendment accepted by both parties. Routine logistical communications that do not change a material booking obligation do not by themselves amend this agreement.', 'vms-agreements'),
        ),
        array(
            'key' => 'governing_law_disputes',
            'label' => __('Governing law / disputes', 'vms-agreements'),
            'type' => 'clause',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Governing Law / Dispute Resolution', 'vms-agreements'),
            'body' => __('This Agreement Packet is governed by the laws of the State of Texas. Before filing litigation concerning this agreement, the parties will first make a good-faith effort to resolve the dispute directly and, if unresolved, participate in mediation in the county where the Venue is located unless both parties agree otherwise in writing.', 'vms-agreements'),
        ),
        array(
            'key' => 'custom_operator_terms',
            'label' => __('Custom operator terms', 'vms-agreements'),
            'type' => 'clause',
            'required' => false,
            'locked' => false,
            'enabled' => false,
            'title' => __('Additional Terms', 'vms-agreements'),
            'body' => '',
        ),
        array(
            'key' => 'audit_disclosure',
            'label' => __('Audit disclosure', 'vms-agreements'),
            'type' => 'audit',
            'required' => true,
            'locked' => false,
            'enabled' => true,
            'title' => __('Acknowledgement & Audit Record', 'vms-agreements'),
            'body' => __('By acknowledging this Agreement Packet, the signer understands that an Acknowledgement Record may be created and retained by the Venue. The Acknowledgement Record may include signer name, signer email, acknowledgement date/time, IP address, browser/user agent, user account when available, agreement version, packet ID, terms hash, compensation hash, and related Packet Verification Records. These records may be displayed back as acknowledgement proof and retained with the Agreement Packet.', 'vms-agreements'),
        ),
        array(
            'key' => 'acknowledgement_proof',
            'label' => __('Acknowledgement proof', 'vms-agreements'),
            'type' => 'protected',
            'required' => true,
            'locked' => true,
            'enabled' => true,
            'title' => __('Acknowledgement Proof', 'vms-agreements'),
            'body' => __('After acknowledgement, the Venue may display, store, print, or email acknowledgement proof showing the signer details, acknowledgement date/time, agreement version, packet ID, and Packet Verification Records associated with this Agreement Packet.', 'vms-agreements'),
        ),
    );
}

function vmsa_legacy_default_template_body_0_3_13(): string
{
    return trim(implode("\n\n", array(
        'Booking Agreement Summary',
        'This packet records the event, vendor, compensation, deposit, and acknowledgement terms for this booking.',
        'Event: {event_title}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Vendor: {vendor_name}',
        'Compensation: {compensation_summary}',
        'Deposit / advance: {deposit_summary}',
        'Payment summary:',
        '{payment_summary}',
        'Cancellation / viability language, rider handling, no-show handling, and other agreement clauses will be expanded in the Agreement Add-On template editor. This first version establishes the packet, version, snapshot, and audit foundation.',
    )));
}

function vmsa_legacy_template_block_bodies_0_3_13(): array
{
    return array(
        'event_summary' => 'Generated from the Event Plan snapshot: event title, date, time, status, and venue.',
        'vendor_summary' => 'Generated from the packet snapshot: vendor name, email, and phone.',
        'compensation_summary' => 'Generated from VMS Core compensation terms captured on the Event Plan.',
        'deposit_summary' => 'Generated from VMS Core deposit or advance terms captured on the Event Plan.',
        'cancellation_viability' => 'The venue may review event viability, safety, weather, ticket demand, operational readiness, or other material circumstances before the event. If the event is cancelled or rescheduled, the venue will document the reason and communicate next steps as promptly as practical.',
        'payment_timing' => 'Unless otherwise stated in writing, the final payment balance is the total agreed payment minus any deposit/advance already paid, plus or minus any variable compensation or documented adjustments captured in this packet.',
        'rider_handling' => 'Any technical or hospitality rider is treated as a request unless it is accepted by the venue in writing. Venue-provided sound, lighting, staging, staffing, and hospitality details control over unapproved or late rider assumptions.',
        'no_show_nonperformance' => 'If the vendor does not appear, arrives materially late, refuses to perform, or otherwise fails to provide the agreed service, the venue may document direct costs, reasonable cover costs, payment withholding, and future booking consequences. A flat penalty is not assumed by default.',
        'venue_rules' => 'Vendor agrees to follow reasonable venue policies, arrival instructions, performance schedule, safety requirements, and staff directions related to the event.',
        'audit_disclosure' => 'By acknowledging this packet, the signer understands that signer name, signer email, acknowledgement date and time, IP address, browser/user agent, agreement version, packet ID, terms hash, and compensation hash may be recorded and displayed back as acknowledgement proof.',
        'acknowledgement_proof' => 'Generated after vendor acknowledgement: signer identity, acknowledgement timestamp, IP address, agreement version, terms hash, and compensation hash.',
    );
}

function vmsa_legacy_acknowledgement_labels_0_3_13(): array
{
    return array(
        'terms_reviewed' => 'I have reviewed the event date, venue, vendor name, and compensation terms shown in this packet.',
        'deposit_reviewed' => 'I understand the deposit or advance terms shown in this packet, if any.',
        'audit_understood' => 'I understand that my acknowledgement time, date, account, IP address, agreement version, terms hash, and compensation hash may be recorded.',
        'authorized_signer' => 'I confirm that I am authorized to acknowledge this agreement on behalf of the vendor listed above.',
    );
}

function vmsa_legacy_default_template_body_0_3_29(): string
{
    return trim(implode("\n\n", array(
        'Vendor Booking Agreement',
        'This packet records the event details, vendor details, payment terms, deposit or advance terms, core agreement clauses, and acknowledgement proof for this booking.',
        'Event: {event_title}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Vendor: {vendor_name}',
        'Compensation: {compensation_summary}',
        'Deposit / advance: {deposit_summary}',
        'Payment summary:',
        '{payment_summary}',
        'The structured agreement clauses below explain cancellation/event viability, payment timing, rider handling, nonperformance, venue expectations, and acknowledgement recordkeeping.',
    )));
}

function vmsa_legacy_template_block_bodies_0_3_29(): array
{
    return array(
        'event_summary' => 'Generated from the Event Plan snapshot: event title, date, time, and venue.',
        'vendor_summary' => 'Generated from the packet snapshot: vendor name, email, and phone.',
        'compensation_summary' => 'Generated from the Event Plan compensation terms captured by VMS Core.',
        'deposit_summary' => 'Generated from the Event Plan deposit or advance terms captured by VMS Core.',
        'cancellation_viability' => 'The venue may cancel or reschedule the event if reasonably necessary because of unsafe conditions, severe weather, insufficient event viability or ticket demand, operational readiness, vendor availability, force majeure, or other material circumstances. If cancellation or rescheduling occurs, the venue will document the reason, notify the vendor as promptly as practical, and explain the next step for rescheduling, release, deposit handling, or final payment. Unless this packet states otherwise, payment for a cancelled event is limited to amounts already earned, written nonrefundable terms, approved expenses, or documented adjustments accepted by the venue.',
        'payment_timing' => 'Unless this packet or a later written update says otherwise, the final payment balance is the total agreed payment minus any deposit or advance already paid, plus or minus any variable compensation, refunds, comps/exclusions, or documented adjustments captured by VMS. Final payment timing and method are controlled by the payment details shown in this packet.',
        'rider_handling' => 'The venue provides the production, sound, lighting, staging, staffing, and hospitality details shown or communicated for this booking. Any technical or hospitality rider is a request unless accepted by the venue in writing. Unapproved, late, or conflicting rider terms are not binding unless the venue expressly accepts them in writing.',
        'no_show_nonperformance' => 'If the vendor does not appear, arrives materially late, refuses to perform, or otherwise fails to provide the agreed service, the venue may document what happened, withhold unpaid amounts where appropriate, document direct costs or reasonable cover costs, and consider future booking consequences. This agreement does not assume a flat penalty by default.',
        'venue_rules' => 'Vendor agrees to follow reasonable venue policies, arrival/load-in instructions, performance schedule, safety requirements, staff directions, and lawful conduct expectations related to the event. Vendor should promptly tell the venue about any issue that could affect arrival, performance, staffing, equipment, or guest safety.',
        'audit_disclosure' => 'By acknowledging this packet, the signer understands that signer name, signer email, acknowledgement date/time, IP address, browser/user agent, user account when available, agreement version, packet ID, and packet verification records may be recorded and displayed back as acknowledgement proof.',
        'acknowledgement_proof' => 'Generated after vendor acknowledgement: signer identity, acknowledgement timestamp, IP address, agreement version, packet ID, and packet verification records.',
    );
}

function vmsa_legacy_acknowledgement_labels_0_3_29(): array
{
    return array(
        'terms_reviewed' => 'I have reviewed the booking details, vendor details, compensation terms, and deposit/advance terms shown in this packet.',
        'deposit_reviewed' => 'I understand that this agreement packet controls the booking details unless the venue issues a newer packet or written update.',
        'audit_understood' => 'I understand that my acknowledgement details may be recorded and displayed back as proof, including signer information, date/time, account, IP address, agreement version, and packet verification records.',
        'authorized_signer' => 'I confirm that I am authorized to review and acknowledge this agreement on behalf of the vendor listed above.',
    );
}

function vmsa_legacy_default_template_body_0_3_30(): string
{
    return trim(implode("\n\n", array(
        'Agreement Packet',
        'This Agreement Packet documents the terms for the event listed below. It includes the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, Agreement Terms, and Acknowledgement & Audit Record shown in this packet. By acknowledging this Agreement Packet, the signer confirms review of the packet and authority to acknowledge it on behalf of the vendor listed below.',
        'Event: {event_title}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Vendor: {vendor_name}',
        'Compensation: {compensation_summary}',
        'Deposit / advance: {deposit_summary}',
        'Payment summary:',
        '{payment_summary}',
        'The Agreement Terms below explain cancellation/event viability, payment timing, rider handling, no-show/nonperformance, venue expectations, and acknowledgement recordkeeping for this Agreement Packet.',
    )));
}

function vmsa_legacy_template_block_bodies_0_3_30(): array
{
    return array(
        'agreement_packet_scope' => 'This Agreement Packet documents the terms for the event listed below. It includes the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, Agreement Terms, and Acknowledgement & Audit Record shown in this packet. By acknowledging this Agreement Packet, the signer confirms review of the packet and authority to acknowledge it on behalf of the vendor listed below.',
        'event_summary' => 'Generated from the Event Plan snapshot: event title, date, time, and venue.',
        'vendor_summary' => 'Generated from the packet snapshot: vendor name, email, and phone.',
        'compensation_summary' => 'Generated from the Event Plan compensation terms captured by VMS Core.',
        'deposit_summary' => 'Generated from the Event Plan deposit or advance terms captured by VMS Core.',
        'cancellation_viability' => 'The venue may cancel or reschedule the event if reasonably necessary because of unsafe conditions, severe weather, insufficient event viability or ticket demand, operational readiness, vendor availability, force majeure, or other material circumstances. If cancellation or rescheduling occurs, the venue will document the reason, notify the vendor as promptly as practical, and explain the next step for rescheduling, release, deposit handling, or final payment. Unless this packet states otherwise, payment for a cancelled event is limited to amounts already earned, written nonrefundable terms, approved expenses, or documented adjustments accepted by the venue.',
        'payment_timing' => 'Unless this packet or a later written update says otherwise, the final payment balance is the total agreed payment minus any deposit or advance already paid, plus or minus any variable compensation, refunds, comps/exclusions, or documented adjustments captured by VMS. Final payment timing and method are controlled by the payment details shown in this packet.',
        'rider_handling' => 'The venue provides the production, sound, lighting, staging, staffing, and hospitality details shown or communicated for this booking. Any technical or hospitality rider is a request unless accepted by the venue in writing. Unapproved, late, or conflicting rider terms are not binding unless the venue expressly accepts them in writing.',
        'no_show_nonperformance' => 'If the vendor does not appear, arrives materially late, refuses to perform, or otherwise fails to provide the agreed service, the venue may document what happened, withhold unpaid amounts where appropriate, document direct costs or reasonable cover costs, and consider future booking consequences. This agreement does not assume a flat penalty by default.',
        'venue_rules' => 'Vendor agrees to follow reasonable venue policies, arrival/load-in instructions, performance schedule, safety requirements, staff directions, and lawful conduct expectations related to the event. Vendor should promptly tell the venue about any issue that could affect arrival, performance, staffing, equipment, or guest safety.',
        'audit_disclosure' => 'By acknowledging this Agreement Packet, the signer understands that an Acknowledgement Record may be created and retained by the venue. The Acknowledgement Record may include signer name, signer email, acknowledgement date/time, IP address, browser/user agent, user account when available, agreement version, packet ID, terms hash, compensation hash, and related Packet Verification Records. These records may be displayed back as acknowledgement proof and retained with the Agreement Packet.',
        'acknowledgement_proof' => 'After acknowledgement, the venue may display, store, print, or email acknowledgement proof showing the signer details, acknowledgement date/time, agreement version, packet ID, and Packet Verification Records associated with this Agreement Packet.',
    );
}

function vmsa_legacy_acknowledgement_labels_0_3_30(): array
{
    return array(
        'terms_reviewed' => 'I have reviewed this Agreement Packet, including the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, Agreement Terms, and Acknowledgement & Audit Record shown above.',
        'deposit_reviewed' => 'I understand that this Agreement Packet controls the Event Details, Compensation Terms, Deposit / Advance Terms, and Agreement Terms for this booking unless the venue issues a newer Agreement Packet or a later written update.',
        'audit_understood' => 'I understand that my acknowledgement will create an Acknowledgement Record that may include my signer name, signer email, acknowledgement date/time, IP address, browser/user agent, user account if available, agreement version, packet ID, terms hash, compensation hash, and related Packet Verification Records.',
        'authorized_signer' => 'I confirm that I am authorized to review and acknowledge this Agreement Packet on behalf of the vendor listed above.',
    );
}

function vmsa_legacy_template_block_bodies_0_3_34(): array
{
    return array(
        'agreement_packet_scope' => 'This Agreement Packet documents the booking terms between {contracting_entity}, as the contracting venue/operator (the "Venue"), and the vendor identified below (the "Vendor") for the event listed below. It includes the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, Agreement Terms, and Acknowledgement & Audit Record shown in this packet. By acknowledging this Agreement Packet, the signer confirms review of the packet and authority to acknowledge it on behalf of the Vendor.',
        'vendor_summary' => 'Generated from the packet snapshot: vendor name, email, and phone.',
    );
}


function vmsa_legacy_template_block_bodies_0_3_40(): array
{
    return array(
        'payment_timing' => 'The final payment balance is the total amount earned under this Agreement Packet minus any deposit or advance already paid, plus any earned variable compensation and any documented adjustment accepted by both parties. Refunds, complimentary or free admissions, and ticket exclusions affect qualifying ticket counts only as stated in the Compensation Terms and are not direct deductions from an otherwise earned base guarantee. Unless this packet states a different final-payment timing, final payment will be issued no later than {standard_final_payment_days} calendar days following the completed performance. If a cancellation payment is owed, it will be issued no later than {standard_final_payment_days} calendar days after the cancellation amount is determined. The payment method shown in this packet controls when one is specified.',
        'rider_handling' => 'The Venue is responsible only for production, sound, lighting, staging, staffing, backline, hospitality, and related items expressly listed in this Agreement Packet or otherwise accepted by the Venue in writing for this booking. Any technical or hospitality rider is a request unless accepted by the Venue in writing. Unapproved, late, or conflicting rider terms are not binding, and an unapproved rider request is not a valid reason for Vendor to refuse or materially alter the agreed performance.',
        'venue_rules' => 'Vendor agrees to appear and perform in a professional, punctual, prepared, and respectful manner; follow reasonable venue policies, arrival/load-in instructions, performance schedule, safety requirements, staff directions, and lawful conduct expectations; and maintain the family-friendly performance environment communicated for the booking. Vendor should promptly tell the Venue about any issue that could affect arrival, performance, staffing, equipment, or guest safety.',
    );
}

function vmsa_legacy_template_block_bodies_0_3_41(): array
{
    return array(
        'agreement_packet_scope' => 'This Agreement Packet documents the booking terms between {contracting_entity}, as the contracting venue/operator (the "Venue"), and {vendor_contracting_party} (the "Vendor") for the event listed below. The Vendor representative/contact identified for this booking is {vendor_representative}. It includes the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, Production Responsibilities, Agreement Terms, and Acknowledgement & Audit Record shown in this packet. By acknowledging this Agreement Packet, the signer confirms review of the packet and authority to acknowledge it on behalf of the Vendor.',
        'cancellation_viability' => 'The Venue may cancel, postpone, suspend, or stop the event when reasonably necessary because of unsafe conditions, severe weather, force majeure, or other conditions that make safe load-in, setup, soundcheck, performance, or venue operation impracticable. When the Venue performance stage is uncovered, live production will not be required or permitted during rain or other precipitation that creates unsafe electrical or stage conditions, and the Venue may make the safety cancellation decision in advance when such precipitation is reasonably expected during the production or performance window. For a weather or safety cancellation made before Vendor arrives at the venue, no base guarantee is owed except a separate written nonrefundable amount or approved expense. If Vendor has arrived on time and is ready and able to perform but the Venue cancels before the performance begins for weather or safety reasons, 50% of the base guarantee is owed. If the performance has begun and is stopped for weather or safety reasons, 100% of the base guarantee is owed. Variable compensation remains governed by the qualifying paid-ticket terms in this packet.',
        'no_show_nonperformance' => 'Vendor must promptly notify the Venue of any issue that may prevent or materially delay the agreed performance. If Vendor cancels without a Venue-accepted reason or mutual written agreement, does not appear, arrives materially late, refuses to perform, leaves before the agreed performance is complete, makes performance conditional on an unapproved demand, or otherwise fails to provide the agreed service, the Venue may document what happened, withhold unpaid amounts where appropriate, and document direct costs or reasonable cover costs caused by the nonperformance. This agreement does not impose a flat penalty by default.',
        'venue_rules' => 'Vendor agrees to appear and perform in a professional, punctual, prepared, and respectful manner; follow reasonable venue policies, safety requirements, staff directions, and lawful conduct expectations; and maintain the family-friendly performance environment communicated for the booking. Vendor will follow the Venue’s reasonable written production schedule and access instructions, including arrival/load-in, setup, soundcheck, performance, strike/load-out, and venue-vacate timing. Unless this Agreement Packet states a fixed time as a material booking term, reasonable logistical schedule updates communicated by the Venue do not require a new Agreement Packet. Vendor should promptly tell the Venue about any issue that could affect arrival, performance, staffing, equipment, or guest safety.',
    );
}

function vmsa_legacy_template_block_bodies_0_3_42(): array
{
    return array(
        'agreement_packet_scope' => 'This Agreement Packet documents the booking terms between {contracting_entity}, as the contracting venue/operator (the "Venue"), and {vendor_contracting_party} (the "Vendor") for the event listed below. The Vendor representative/contact identified for this booking is {vendor_representative}. It includes the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, Production Responsibilities, Production Schedule, Agreement Terms, and Acknowledgement & Audit Record shown in this packet. By acknowledging this Agreement Packet, the signer confirms review of the packet and authority to acknowledge it on behalf of the Vendor.',
        'cancellation_viability' => 'The Venue may cancel, postpone, suspend, or stop the event when reasonably necessary because of unsafe conditions, severe weather, force majeure, or other conditions that make safe load-in, setup, soundcheck, performance, or venue operation impracticable. Because the Venue performance stage is uncovered, live production will not be required or permitted during rain or other precipitation that creates unsafe electrical or stage conditions, and the Venue may make a safety cancellation decision in advance when such conditions are reasonably expected during the production or performance window. When reasonably practical based on available forecasts, the Venue will attempt to make and communicate a weather-related decision approximately 72 hours before the scheduled arrival/load-in time; this is a planning goal and does not change the payment cutoff below. If the Venue communicates a weather or safety cancellation at least 24 hours before the scheduled arrival/load-in time stated in this Agreement Packet, no base guarantee is owed except a separately agreed nonrefundable amount or approved expense. If the Venue communicates the cancellation less than 24 hours before that scheduled arrival/load-in time, 100% of the base guarantee is owed, whether or not Vendor has begun travel, arrived, loaded in, or soundchecked. If the performance has begun and is stopped for weather or safety reasons, 100% of the base guarantee is owed. Any credit or treatment of an otherwise owed cancellation payment toward a rescheduled engagement must be accepted by both parties in writing. Variable compensation remains governed by the qualifying paid-ticket terms in this packet.',
        'event_viability_cancellation' => 'The Venue may cancel the event because of insufficient ticket demand or event viability without owing the base guarantee if the Venue gives notice at least seven calendar days before the scheduled performance. If the Venue cancels for event viability less than seven calendar days before the scheduled performance, 50% of the base guarantee is owed. If Vendor has already arrived on time and is ready and able to perform when the Venue makes an event-viability cancellation, 100% of the base guarantee is owed. This paragraph does not replace the separate weather/safety rules, Vendor nonperformance rules, or a different cancellation or reschedule arrangement accepted by both parties in writing.',
        'payment_timing' => 'The final payment balance is the total amount earned under this Agreement Packet minus any deposit or advance already paid, plus any earned variable compensation and any documented adjustment accepted by both parties. Refunds, complimentary or free admissions, and ticket exclusions affect qualifying ticket counts only as stated in the Compensation Terms and are not direct deductions from an otherwise earned base guarantee. The final-payment timing and payment method stated in the Compensation Terms control. Unless this packet states a different final-payment timing, final payment will be issued no later than {standard_final_payment_days} calendar days following the completed performance. If a cancellation payment is owed, it will be issued no later than {standard_final_payment_days} calendar days after the cancellation amount is determined.',
        'no_show_nonperformance' => 'Vendor must promptly notify the Venue of any issue that may prevent or materially delay the agreed load-in, setup, soundcheck, or performance. Vendor may promptly raise a specific safety concern, and the Venue will evaluate current conditions and may suspend or stop production when necessary for safety. No Vendor personnel are required to work during rain on the uncovered stage or during another immediate unsafe condition. Unless the Venue has suspended production or an immediate hazardous condition prevents safe work, Vendor is expected to proceed with the agreed Production Schedule. A refusal or material delay in loading in, setting up, soundchecking, or performing without an immediate safety condition or other reason accepted by the Venue may be treated as Vendor nonperformance if it materially delays, shortens, or prevents the performance. If Vendor cancels without a Venue-accepted reason or mutual written agreement, does not appear, arrives materially late, refuses to perform, leaves before the agreed performance is complete, makes performance conditional on an unapproved demand, or otherwise fails to provide the agreed service, the Venue may document what happened, withhold unpaid amounts where appropriate, and document direct costs or reasonable cover costs caused by the nonperformance. This agreement does not impose a flat penalty by default.',
    );
}

function vmsa_legacy_template_block_titles_0_3_43(): array
{
    return array(
        'cancellation_viability' => array('Cancellation / Event Viability', 'Weather / Safety Cancellation'),
        'event_viability_cancellation' => array('Event Viability / Ticket-Demand Cancellation'),
        'rider_handling' => array('Technical / Hospitality Rider Handling', 'Production / Technical / Hospitality Terms'),
        'no_show_nonperformance' => array('No-show / Nonperformance', 'Vendor Cancellation / No-Show / Nonperformance'),
    );
}

function vmsa_legacy_default_template_body_0_3_43(): string
{
    return trim(implode("\n\n", array(
        'Agreement Packet',
        'This Agreement Packet documents the booking terms between {contracting_entity}, as the contracting venue/operator, and {vendor_contracting_party} for this event.',
        'Event: {event_title}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Contracting party: {contracting_entity}',
        'Vendor / act: {vendor_name}',
        'Vendor legal / contracting name: {vendor_legal_name}',
        'Vendor representative / contact: {vendor_representative}',
        'Compensation: {compensation_summary}',
        'Deposit / advance: {deposit_summary}',
        'Production responsibilities:',
        'Stage: {production_stage}',
        'House Sound / PA: {production_house_sound}',
        'Stage Lighting: {production_stage_lighting}',
        'Sound Engineer: {production_sound_engineer}',
        'Production schedule:',
        'Arrival / load-in: {arrival_loadin_time}',
        'Soundcheck: {soundcheck_window}',
        'Load-out / venue vacate by: {vacate_by_time}',
        'Payment summary:',
        '{payment_summary}',
        'The Agreement Terms below address performance commitment, weather/safety cancellation, event viability, payment, production/riders, Vendor nonperformance, independent-contractor status, changes to agreed terms, governing law, venue expectations, and acknowledgement recordkeeping.',
    )));
}

function vmsa_legacy_acknowledgement_labels_0_3_43(): array
{
    return array(
        'terms_reviewed' => 'I have reviewed this Agreement Packet, including the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, Production Responsibilities, Production Schedule, performance commitment, cancellation terms, payment terms, production/rider terms, nonperformance terms, and other Agreement Terms shown above.',
    );
}

function vmsa_legacy_default_template_body_0_3_36(): string
{
    return trim(implode("\n\n", array(
        'Agreement Packet',
        'This Agreement Packet documents the booking terms between {contracting_entity}, as the contracting venue/operator, and the vendor listed below for this event.',
        'Event: {event_title}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Contracting party: {contracting_entity}',
        'Vendor: {vendor_name}',
        'Compensation: {compensation_summary}',
        'Deposit / advance: {deposit_summary}',
        'Payment summary:',
        '{payment_summary}',
        'The Agreement Terms below address performance commitment, weather/safety cancellation, event viability, payment, production/riders, Vendor nonperformance, independent-contractor status, changes to agreed terms, governing law, venue expectations, and acknowledgement recordkeeping.',
    )));
}

function vmsa_legacy_acknowledgement_labels_0_3_36(): array
{
    return array(
        'terms_reviewed' => 'I have reviewed this Agreement Packet, including the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, performance commitment, cancellation terms, payment terms, production/rider terms, nonperformance terms, and other Agreement Terms shown above.',
    );
}

function vmsa_legacy_default_template_body_0_3_41(): string
{
    return trim(implode("\n\n", array(
        'Agreement Packet',
        'This Agreement Packet documents the booking terms between {contracting_entity}, as the contracting venue/operator, and {vendor_contracting_party} for this event.',
        'Event: {event_title}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Contracting party: {contracting_entity}',
        'Vendor / act: {vendor_name}',
        'Vendor legal / contracting name: {vendor_legal_name}',
        'Vendor representative / contact: {vendor_representative}',
        'Compensation: {compensation_summary}',
        'Deposit / advance: {deposit_summary}',
        'Production responsibilities:',
        'Stage: {production_stage}',
        'House Sound / PA: {production_house_sound}',
        'Stage Lighting: {production_stage_lighting}',
        'Sound Engineer: {production_sound_engineer}',
        'Payment summary:',
        '{payment_summary}',
        'The Agreement Terms below address performance commitment, weather/safety cancellation, event viability, payment, production/riders, Vendor nonperformance, independent-contractor status, changes to agreed terms, governing law, venue expectations, and acknowledgement recordkeeping.',
    )));
}

function vmsa_legacy_acknowledgement_labels_0_3_41(): array
{
    return array(
        'terms_reviewed' => 'I have reviewed this Agreement Packet, including the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, Production Responsibilities, performance commitment, cancellation terms, payment terms, production/rider terms, nonperformance terms, and other Agreement Terms shown above.',
    );
}

function vmsa_maybe_upgrade_agreement_language_defaults(): void
{
    if (!vmsa_can_manage()) {
        return;
    }

    $installed = (string) get_option('vmsa_agreement_language_defaults_version', '');
    if ($installed !== '' && version_compare($installed, '0.3.44', '>=')) {
        return;
    }

    $template_id = vmsa_ensure_default_template();
    if ($template_id <= 0) {
        update_option('vmsa_agreement_language_defaults_version', '0.3.44', false);
        return;
    }

    $changed = false;
    $defaults = vmsa_template_block_defaults_by_key();
    $legacy_body_sets = array(
        vmsa_legacy_template_block_bodies_0_3_13(),
        vmsa_legacy_template_block_bodies_0_3_29(),
        vmsa_legacy_template_block_bodies_0_3_30(),
        vmsa_legacy_template_block_bodies_0_3_34(),
        vmsa_legacy_template_block_bodies_0_3_40(),
        vmsa_legacy_template_block_bodies_0_3_41(),
        vmsa_legacy_template_block_bodies_0_3_42(),
    );
    $stored_blocks = get_post_meta($template_id, '_vmsa_template_blocks', true);
    $blocks = vmsa_sanitize_template_blocks(is_array($stored_blocks) ? $stored_blocks : array());
    $stored_keys = array();
    if (is_array($stored_blocks)) {
        foreach ($stored_blocks as $stored_key => $stored_block) {
            if (!is_array($stored_block)) {
                continue;
            }
            $resolved_key = isset($stored_block['key']) ? sanitize_key((string) $stored_block['key']) : sanitize_key((string) $stored_key);
            if ($resolved_key !== '') {
                $stored_keys[$resolved_key] = true;
            }
        }
    }
    foreach (array_keys($defaults) as $default_key) {
        if (!isset($stored_keys[$default_key])) {
            $changed = true;
            break;
        }
    }

    foreach ($blocks as &$block) {
        $key = (string) ($block['key'] ?? '');
        if ($key === '' || !isset($defaults[$key])) {
            continue;
        }

        $body = (string) ($block['body'] ?? '');
        $new_body = (string) ($defaults[$key]['body'] ?? '');
        if ($new_body === '') {
            continue;
        }

        foreach ($legacy_body_sets as $legacy_bodies) {
            $legacy_body = (string) ($legacy_bodies[$key] ?? '');
            if ($legacy_body !== '' && trim($body) === trim($legacy_body) && trim($new_body) !== trim($legacy_body)) {
                $block['body'] = $new_body;
                $changed = true;
                break;
            }
        }
    }
    unset($block);

    $legacy_title_sets = array(vmsa_legacy_template_block_titles_0_3_43());
    foreach ($blocks as &$block) {
        $key = (string) ($block['key'] ?? '');
        if ($key === '' || !isset($defaults[$key])) {
            continue;
        }

        $stored_title = trim((string) ($block['title'] ?? ''));
        $new_title = trim((string) ($defaults[$key]['title'] ?? ''));
        if ($new_title === '' || $stored_title === $new_title) {
            continue;
        }

        foreach ($legacy_title_sets as $legacy_titles) {
            $candidates = (array) ($legacy_titles[$key] ?? array());
            foreach ($candidates as $legacy_title) {
                if ($stored_title === trim((string) $legacy_title)) {
                    $block['title'] = $new_title;
                    $changed = true;
                    break 2;
                }
            }
        }
    }
    unset($block);

    if ($changed) {
        update_post_meta($template_id, '_vmsa_template_blocks', $blocks);
        if (function_exists('vmsa_template_body_from_blocks_for_legacy')) {
            update_post_meta($template_id, '_vmsa_template_body', vmsa_template_body_from_blocks_for_legacy($blocks));
        }
    }

    $stored_body = (string) get_post_meta($template_id, '_vmsa_template_body', true);
    foreach (array(
        vmsa_legacy_default_template_body_0_3_13(),
        vmsa_legacy_default_template_body_0_3_29(),
        vmsa_legacy_default_template_body_0_3_30(),
        vmsa_legacy_default_template_body_0_3_36(),
        vmsa_legacy_default_template_body_0_3_41(),
        vmsa_legacy_default_template_body_0_3_43(),
    ) as $legacy_body) {
        if (trim($stored_body) === trim($legacy_body)) {
            update_post_meta($template_id, '_vmsa_template_body', vmsa_default_template_body());
            $changed = true;
            break;
        }
    }

    $legacy_label_sets = array(
        vmsa_legacy_acknowledgement_labels_0_3_13(),
        vmsa_legacy_acknowledgement_labels_0_3_29(),
        vmsa_legacy_acknowledgement_labels_0_3_30(),
        vmsa_legacy_acknowledgement_labels_0_3_36(),
        vmsa_legacy_acknowledgement_labels_0_3_41(),
        vmsa_legacy_acknowledgement_labels_0_3_43(),
    );
    $default_acks = array();
    foreach (vmsa_default_acknowledgements() as $ack) {
        if (is_array($ack) && !empty($ack['key'])) {
            $default_acks[(string) $ack['key']] = $ack;
        }
    }

    $stored_acks = get_post_meta($template_id, '_vmsa_acknowledgements', true);
    $acks = array_values(array_filter(array_map('vmsa_sanitize_acknowledgement_row', is_array($stored_acks) ? $stored_acks : array())));
    foreach ($acks as &$ack) {
        $key = (string) ($ack['key'] ?? '');
        if ($key === '' || !isset($default_acks[$key]['label'])) {
            continue;
        }

        foreach ($legacy_label_sets as $legacy_labels) {
            if (isset($legacy_labels[$key]) && (string) ($ack['label'] ?? '') === (string) $legacy_labels[$key]) {
                $ack['label'] = (string) $default_acks[$key]['label'];
                $changed = true;
                break;
            }
        }
    }
    unset($ack);

    if ($changed) {
        update_post_meta($template_id, '_vmsa_acknowledgements', vmsa_merge_required_template_acknowledgements($acks));
        $current_version = (string) get_post_meta($template_id, '_vmsa_template_version', true);
        update_post_meta($template_id, '_vmsa_template_version', vmsa_bump_template_version($current_version));
        update_post_meta($template_id, '_vmsa_template_updated_at', vmsa_current_datetime_mysql());
        update_post_meta($template_id, '_vmsa_template_updated_by', get_current_user_id());
        $payload = vmsa_get_template_payload($template_id);
        update_post_meta($template_id, '_vmsa_template_health', (array) ($payload['health'] ?? array()));
    }

    update_option('vmsa_agreement_language_defaults_version', '0.3.44', false);
}

function vmsa_template_block_defaults_by_key(): array
{
    $map = array();
    foreach (vmsa_default_template_blocks() as $block) {
        $map[(string) $block['key']] = $block;
    }

    return $map;
}

function vmsa_sanitize_template_blocks($blocks): array
{
    $defaults = vmsa_template_block_defaults_by_key();
    $raw_incoming = is_array($blocks) ? $blocks : array();
    $incoming = array();
    foreach ($raw_incoming as $maybe_key => $maybe_block) {
        if (!is_array($maybe_block)) {
            continue;
        }

        $block_key = isset($maybe_block['key']) ? sanitize_key((string) $maybe_block['key']) : sanitize_key((string) $maybe_key);
        if ($block_key !== '') {
            $incoming[$block_key] = $maybe_block;
        }
    }
    $normalized = array();

    foreach ($defaults as $key => $default) {
        $raw = isset($incoming[$key]) && is_array($incoming[$key]) ? $incoming[$key] : array();
        $locked = !empty($default['locked']);
        $required = !empty($default['required']);

        $title = isset($raw['title']) ? sanitize_text_field((string) $raw['title']) : (string) ($default['title'] ?? '');
        $body = isset($raw['body']) ? sanitize_textarea_field((string) $raw['body']) : (string) ($default['body'] ?? '');

        if ($title === '') {
            $title = (string) ($default['title'] ?? $default['label'] ?? $key);
        }

        if ($locked) {
            // Locked blocks can have their display title adjusted, but their source/body stays protected.
            $body = (string) ($default['body'] ?? '');
        }

        $enabled = $required || $locked ? true : !empty($raw['enabled']);

        $normalized[] = array(
            'key' => $key,
            'label' => (string) ($default['label'] ?? $key),
            'type' => (string) ($default['type'] ?? 'clause'),
            'required' => $required,
            'locked' => $locked,
            'enabled' => $enabled,
            'title' => $title,
            'body' => $body,
        );
    }

    return $normalized;
}

function vmsa_get_template_blocks(int $template_id = 0): array
{
    $stored = $template_id > 0 ? get_post_meta($template_id, '_vmsa_template_blocks', true) : array();
    if (!is_array($stored) || empty($stored)) {
        return vmsa_default_template_blocks();
    }

    // Accept both list-shaped stored data and key-indexed posted data.
    $by_key = array();
    foreach ($stored as $key => $block) {
        if (!is_array($block)) {
            continue;
        }

        $block_key = isset($block['key']) ? sanitize_key((string) $block['key']) : sanitize_key((string) $key);
        if ($block_key !== '') {
            $by_key[$block_key] = $block;
        }
    }

    return vmsa_sanitize_template_blocks($by_key);
}

function vmsa_template_block_by_key(array $blocks, string $key): array
{
    foreach ($blocks as $block) {
        if (is_array($block) && (string) ($block['key'] ?? '') === $key) {
            return $block;
        }
    }

    return array();
}

function vmsa_template_health_check(array $template): array
{
    $blocks = vmsa_sanitize_template_blocks((array) ($template['blocks'] ?? array()));
    $acknowledgements = array_values(array_filter(array_map('vmsa_sanitize_acknowledgement_row', (array) ($template['acknowledgements'] ?? array()))));
    $issues = array();

    $required_blocks = array('agreement_packet_scope', 'event_summary', 'vendor_summary', 'compensation_summary', 'deposit_summary', 'production_summary', 'performance_commitment', 'cancellation_viability', 'event_viability_cancellation', 'payment_timing', 'rider_handling', 'no_show_nonperformance', 'independent_contractor_tax', 'amendments', 'governing_law_disputes', 'audit_disclosure', 'acknowledgement_proof');
    foreach ($required_blocks as $key) {
        $block = vmsa_template_block_by_key($blocks, $key);
        if (empty($block)) {
            $issues[] = vmsa_template_health_issue('error', $key, sprintf(__('Required block missing: %s', 'vms-agreements'), $key));
            continue;
        }

        if (empty($block['enabled'])) {
            $issues[] = vmsa_template_health_issue('error', $key, sprintf(__('Required block is disabled: %s', 'vms-agreements'), (string) ($block['label'] ?? $key)));
        }

        if (trim((string) ($block['title'] ?? '')) === '') {
            $issues[] = vmsa_template_health_issue('warning', $key, sprintf(__('Block title is empty: %s', 'vms-agreements'), (string) ($block['label'] ?? $key)));
        }

        if (empty($block['locked']) && trim((string) ($block['body'] ?? '')) === '') {
            $issues[] = vmsa_template_health_issue('error', $key, sprintf(__('Required clause text is empty: %s', 'vms-agreements'), (string) ($block['label'] ?? $key)));
        }
    }

    $audit = vmsa_template_block_by_key($blocks, 'audit_disclosure');
    $audit_body = strtolower((string) ($audit['body'] ?? ''));
    $audit_concepts = array(
        'IP address' => array('ip address', 'ip'),
        'acknowledgement time' => array('date/time', 'date and time', 'timestamp', 'time'),
        'agreement version' => array('agreement version', 'template version', 'packet version', 'version'),
        'packet verification record' => array('packet verification', 'verification record', 'verification records', 'packet id', 'terms hash', 'compensation hash', 'hash', 'recorded packet'),
    );

    foreach ($audit_concepts as $concept_label => $accepted_phrases) {
        if ($audit_body !== '' && !vmsa_template_health_text_contains_any($audit_body, $accepted_phrases)) {
            $issues[] = vmsa_template_health_issue('warning', 'audit_disclosure', sprintf(__('Audit disclosure may be missing this concept: %s', 'vms-agreements'), $concept_label));
        }
    }

    $ack_keys = array();
    foreach ($acknowledgements as $ack) {
        $ack_keys[] = (string) ($ack['key'] ?? '');
    }

    foreach (array('terms_reviewed', 'deposit_reviewed', 'audit_understood', 'authorized_signer') as $key) {
        if (!in_array($key, $ack_keys, true)) {
            $issues[] = vmsa_template_health_issue('error', 'acknowledgements', sprintf(__('Required acknowledgement missing: %s', 'vms-agreements'), $key));
        }
    }

    if (empty($issues)) {
        $issues[] = vmsa_template_health_issue('success', 'template', __('Template health check passed. Required protected blocks, core clauses, and acknowledgement disclosures are present.', 'vms-agreements'));
    }

    return $issues;
}

function vmsa_template_health_text_contains_any(string $haystack, array $needles): bool
{
    foreach ($needles as $needle) {
        $needle = strtolower(trim((string) $needle));
        if ($needle !== '' && strpos($haystack, $needle) !== false) {
            return true;
        }
    }

    return false;
}

function vmsa_template_health_issue(string $severity, string $key, string $message): array
{
    return array(
        'severity' => sanitize_key($severity),
        'key' => sanitize_key($key),
        'message' => sanitize_text_field($message),
    );
}

function vmsa_template_health_has_errors(array $issues): bool
{
    foreach ($issues as $issue) {
        if (is_array($issue) && (string) ($issue['severity'] ?? '') === 'error') {
            return true;
        }
    }

    return false;
}

function vmsa_template_health_has_warnings(array $issues): bool
{
    foreach ($issues as $issue) {
        if (is_array($issue) && (string) ($issue['severity'] ?? '') === 'warning') {
            return true;
        }
    }

    return false;
}

function vmsa_template_health_severity_counts(array $issues): array
{
    $counts = array(
        'error' => 0,
        'warning' => 0,
        'success' => 0,
    );

    foreach ($issues as $issue) {
        if (!is_array($issue)) {
            continue;
        }

        $severity = sanitize_key((string) ($issue['severity'] ?? 'warning'));
        if (!isset($counts[$severity])) {
            $counts[$severity] = 0;
        }
        $counts[$severity]++;
    }

    return $counts;
}

function vmsa_template_health_status_label(array $issues): string
{
    if (vmsa_template_health_has_errors($issues)) {
        return __('Needs attention', 'vms-agreements');
    }

    foreach ($issues as $issue) {
        if (is_array($issue) && (string) ($issue['severity'] ?? '') === 'warning') {
            return __('Usable with warnings', 'vms-agreements');
        }
    }

    return __('Passed', 'vms-agreements');
}

function vmsa_bump_template_version(string $version): string
{
    $version = trim($version);
    if ($version === '') {
        return '1.0.1';
    }

    $parts = array_map('absint', explode('.', $version));
    while (count($parts) < 3) {
        $parts[] = 0;
    }
    $parts[2]++;

    return implode('.', array_slice($parts, 0, 3));
}

function vmsa_render_template_blocks_text(array $snapshot): string
{
    $template = (array) ($snapshot['template'] ?? array());
    $blocks = vmsa_sanitize_template_blocks((array) ($template['blocks'] ?? vmsa_get_template_blocks(absint($template['id'] ?? 0))));
    $tokens = vmsa_template_tokens($snapshot);
    $lines = array();

    foreach ($blocks as $block) {
        if (empty($block['enabled'])) {
            continue;
        }

        $key = (string) ($block['key'] ?? '');
        $title = trim(vmsa_display_text($block['title'] ?? ''));
        $body = trim(vmsa_display_text($block['body'] ?? ''));

        if ($title !== '') {
            $lines[] = $title;
        }

        if ($key === 'event_summary') {
            $lines[] = 'Event: ' . ($tokens['{event_title}'] ?? '');
            $lines[] = 'Date: ' . ($tokens['{event_date}'] ?? '');
            $lines[] = 'Performance time: ' . ($tokens['{event_time}'] ?? '');
            if (($tokens['{arrival_loadin_time}'] ?? '-') !== '-') {
                $lines[] = 'Arrival / load-in: ' . ($tokens['{arrival_loadin_time}'] ?? '');
            }
            if (($tokens['{soundcheck_window}'] ?? '-') !== '-') {
                $lines[] = 'Soundcheck: ' . ($tokens['{soundcheck_window}'] ?? '');
            }
            if (isset($snapshot['production_schedule']) && is_array($snapshot['production_schedule'])) {
                $lines[] = 'Load-out / venue vacate by: ' . ($tokens['{vacate_by_time}'] ?? '');
            }
            $lines[] = 'Venue: ' . ($tokens['{venue_name}'] ?? '');
            $lines[] = 'Contracting party: ' . ($tokens['{contracting_entity}'] ?? '');
        } elseif ($key === 'vendor_summary') {
            $lines[] = 'Vendor / act: ' . ($tokens['{vendor_name}'] ?? '');
            $lines[] = 'Vendor legal / contracting name: ' . ($tokens['{vendor_legal_name}'] ?? '');
            $lines[] = 'Vendor representative / contact: ' . ($tokens['{vendor_representative}'] ?? '');
            $lines[] = 'Vendor email: ' . ($tokens['{vendor_email}'] ?? '');
            $lines[] = 'Vendor phone: ' . ($tokens['{vendor_phone}'] ?? '');
        } elseif ($key === 'production_summary') {
            $lines[] = 'Stage: ' . ($tokens['{production_stage}'] ?? '');
            $lines[] = 'House Sound / PA: ' . ($tokens['{production_house_sound}'] ?? '');
            $lines[] = 'Stage Lighting: ' . ($tokens['{production_stage_lighting}'] ?? '');
            $lines[] = 'Sound Engineer: ' . ($tokens['{production_sound_engineer}'] ?? '');
        } elseif ($key === 'compensation_summary') {
            $lines[] = 'Compensation terms: ' . ($tokens['{compensation_summary}'] ?? '');
            $payment_breakdown = (array) ($snapshot['compensation']['payment_breakdown'] ?? array());
            $payment_lines = isset($payment_breakdown['lines']) && is_array($payment_breakdown['lines'])
                ? $payment_breakdown['lines']
                : array((string) ($tokens['{payment_summary}'] ?? ''));
            $lines[] = '';
            $lines[] = 'Payment terms:';
            foreach ($payment_lines as $payment_line) {
                $payment_line = trim(vmsa_display_text($payment_line));
                if ($payment_line !== '') {
                    $lines[] = '- ' . $payment_line;
                }
            }
            $bonus_table = function_exists('vmsa_format_bonus_payout_table_text')
                ? vmsa_format_bonus_payout_table_text((array) ($snapshot['compensation']['terms'] ?? array()))
                : '';
            if ($bonus_table !== '') {
                $lines[] = '';
                $lines[] = 'Bonus payout schedule:';
                foreach (explode("\n", $bonus_table) as $bonus_table_line) {
                    $lines[] = $bonus_table_line;
                }
            }
            $bonus_note = function_exists('vmsa_bonus_qualification_note')
                ? vmsa_bonus_qualification_note((array) ($snapshot['compensation']['terms'] ?? array()))
                : '';
            if ($bonus_note !== '') {
                $lines[] = $bonus_note;
            }
        } elseif ($key === 'deposit_summary') {
            $lines[] = 'Deposit / advance terms: ' . ($tokens['{deposit_summary}'] ?? '');
        } elseif ($key === 'acknowledgement_proof') {
            $lines[] = __('Acknowledgement proof is generated and printed after vendor acknowledgement.', 'vms-agreements');
        } else {
            $lines[] = strtr($body, $tokens);
        }

        $lines[] = '';
    }

    return trim(vmsa_display_text(implode("\n", $lines)));
}

function vmsa_merge_required_template_acknowledgements(array $acknowledgements): array
{
    $clean = array_values(array_filter(array_map('vmsa_sanitize_acknowledgement_row', $acknowledgements)));
    $by_key = array();
    foreach ($clean as $ack) {
        $by_key[(string) ($ack['key'] ?? '')] = $ack;
    }

    foreach (vmsa_default_acknowledgements() as $required) {
        $required = vmsa_sanitize_acknowledgement_row($required);
        if (!$required) {
            continue;
        }

        $key = (string) ($required['key'] ?? '');
        if ($key !== '' && !isset($by_key[$key])) {
            $by_key[$key] = $required;
        }
    }

    return array_values($by_key);
}
