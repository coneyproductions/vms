<?php
if (!defined('ABSPATH')) {
    exit;
}

function vmsa_default_review_email_body(): string
{
    return trim(implode("\n", array(
        'Hi {vendor_name},',
        '',
        '{site_name} has prepared the current Agreement Packet for your upcoming booking. Please review the Event Details, Vendor Details, Compensation Terms, Deposit / Advance Terms, and Agreement Terms before acknowledging.',
        '',
        'Agreement Packet Summary',
        'Event Details',
        'Event name: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        '',
        'Vendor Details',
        'Vendor: {vendor_name}',
        'Email: {vendor_email}',
        'Phone: {vendor_phone}',
        '',
        'Compensation Terms',
        '{compensation_summary}',
        '',
        'Deposit / Advance Terms',
        '{deposit_summary}',
        '',
        'Payment Summary',
        '{payment_summary_email}',
        '',
        '{operator_note}',
        '',
        'Review and acknowledge the Agreement Packet here:',
        '{review_link}',
        '',
        'After you submit, acknowledgement proof for this Agreement Packet may be displayed back to you and retained with the Acknowledgement Record. This may include signer name, signer email, acknowledgement date/time, IP address, agreement version, packet ID, and related Packet Verification Records.',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_default_acknowledgement_email_body(): string
{
    return trim(implode("\n", array(
        'Hi {signer_name},',
        '',
        'Your acknowledgement of the Agreement Packet has been recorded for {event_name}. Keep this email with your records.',
        '',
        'Agreement Packet Summary',
        'Event Details',
        'Event name: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        '',
        'Vendor Details',
        'Vendor: {vendor_name}',
        'Email: {vendor_email}',
        'Phone: {vendor_phone}',
        '',
        'Payment Summary',
        '{payment_summary_email}',
        '',
        'Acknowledgement Proof',
        '{acknowledgement_proof}',
        '',
        'You can reopen the review page here:',
        '{review_link}',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_default_operator_acknowledgement_email_body(): string
{
    return trim(implode("\n", array(
        'Hi,',
        '',
        'An Agreement Packet has been acknowledged for {event_name}.',
        '',
        'Agreement Packet Summary',
        'Event Details',
        'Event name: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        '',
        'Vendor Details',
        'Vendor: {vendor_name}',
        'Email: {vendor_email}',
        'Phone: {vendor_phone}',
        '',
        'Signer Details',
        'Signer: {signer_name} <{signer_email}>',
        'Acknowledged: {acknowledged_at}',
        '',
        'Payment Summary',
        '{payment_summary_email}',
        '',
        'Agreement Packet Admin Link',
        '{packet_admin_link}',
        '',
        'Printable Agreement Packet',
        '{print_link}',
        '',
        'Acknowledgement Proof',
        '{acknowledgement_proof}',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_legacy_review_email_body_0_3_13(): string
{
    return trim(implode("\n", array(
        'Hi {vendor_name},',
        '',
        '{site_name} has prepared an agreement packet for your review.',
        '',
        'Booking summary',
        'Event: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        '',
        'Compensation',
        '{compensation_summary}',
        '',
        'Deposit / advance',
        '{deposit_summary}',
        '',
        'Payment summary',
        '{payment_summary_email}',
        '',
        '{operator_note}',
        '',
        'Review and acknowledge the agreement packet here:',
        '{review_link}',
        '',
        'Acknowledgement details will be recorded and shown back to you after submission. This includes signer name/email, date/time, IP address, agreement version, and packet verification records.',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_legacy_acknowledgement_email_body_0_3_13(): string
{
    return trim(implode("\n", array(
        'Hi {signer_name},',
        '',
        'Your agreement acknowledgement has been recorded for {event_name}.',
        '',
        'Booking summary',
        'Event: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Vendor: {vendor_name}',
        '',
        'Payment summary',
        '{payment_summary_email}',
        '',
        'Acknowledgement proof',
        '{acknowledgement_proof}',
        '',
        'You can reopen the review page here:',
        '{review_link}',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_legacy_review_email_body_0_3_2(): string
{
    return trim(implode("\n", array(
        'Hi {vendor_name},',
        '',
        '{site_name} has prepared an agreement packet for your review.',
        '',
        'Booking summary:',
        'Event: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Compensation: {compensation_summary}',
        'Deposit / advance: {deposit_summary}',
        'Payment summary: {payment_summary}',
        '',
        '{operator_note}',
        '',
        'Please review and acknowledge the agreement packet here:',
        '{review_link}',
        '',
        'Your acknowledgement details, including signer name/email, date/time, IP address, agreement version, terms hash, and compensation hash, will be recorded and shown back to you after submission.',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_legacy_acknowledgement_email_body_0_3_2(): string
{
    return trim(implode("\n", array(
        'Hi {signer_name},',
        '',
        'Your agreement acknowledgement has been recorded for {event_name}.',
        '',
        'Booking summary:',
        'Event: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Vendor: {vendor_name}',
        'Payment summary: {payment_summary}',
        '',
        'Acknowledgement proof:',
        '{acknowledgement_proof}',
        '',
        'You can reopen the review page here:',
        '{review_link}',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_legacy_review_email_body_0_3_29(): string
{
    return trim(implode("\n", array(
        'Hi {vendor_name},',
        '',
        '{site_name} has prepared the agreement packet for your upcoming booking. Please review the event details, payment terms, and agreement clauses before acknowledging.',
        '',
        'Booking summary',
        'Event: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        '',
        'Compensation',
        '{compensation_summary}',
        '',
        'Deposit / advance',
        '{deposit_summary}',
        '',
        'Payment summary',
        '{payment_summary_email}',
        '',
        '{operator_note}',
        '',
        'Review and acknowledge the agreement packet here:',
        '{review_link}',
        '',
        'After you submit, the acknowledgement proof will be shown back to you and kept with the packet record. This may include signer name/email, date/time, IP address, agreement version, and packet verification records.',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_legacy_acknowledgement_email_body_0_3_29(): string
{
    return trim(implode("\n", array(
        'Hi {signer_name},',
        '',
        'Your agreement acknowledgement has been recorded for {event_name}. Keep this email for your records.',
        '',
        'Booking summary',
        'Event: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Vendor: {vendor_name}',
        '',
        'Payment summary',
        '{payment_summary_email}',
        '',
        'Acknowledgement proof',
        '{acknowledgement_proof}',
        '',
        'You can reopen the review page here:',
        '{review_link}',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_legacy_operator_acknowledgement_email_body_0_3_29(): string
{
    return trim(implode("\n", array(
        'Hi,',
        '',
        'An agreement packet has been acknowledged for {event_name}.',
        '',
        'Booking summary',
        'Event: {event_name}',
        'Date: {event_date}',
        'Time: {event_time}',
        'Venue: {venue_name}',
        'Vendor: {vendor_name}',
        '',
        'Signer details',
        'Signer: {signer_name} <{signer_email}>',
        'Acknowledged: {acknowledged_at}',
        '',
        'Payment summary',
        '{payment_summary_email}',
        '',
        'Packet admin link',
        '{packet_admin_link}',
        '',
        'Printable copy',
        '{print_link}',
        '',
        'Acknowledgement proof',
        '{acknowledgement_proof}',
        '',
        'Thank you,',
        '{site_name}',
    )));
}

function vmsa_default_email_templates(): array
{
    return array(
        'review' => array(
            'label' => __('Review Link Email', 'vms-agreements'),
            'description' => __('Sent from the packet viewer when the operator emails the vendor review link.', 'vms-agreements'),
            'subject' => __('Agreement review requested: {event_name}', 'vms-agreements'),
            'body' => vmsa_default_review_email_body(),
        ),
        'acknowledgement' => array(
            'label' => __('Acknowledgement Confirmation Email', 'vms-agreements'),
            'description' => __('Sent to the signer after the agreement packet is acknowledged.', 'vms-agreements'),
            'subject' => __('Agreement acknowledged: {event_name}', 'vms-agreements'),
            'body' => vmsa_default_acknowledgement_email_body(),
        ),
        'operator_acknowledgement' => array(
            'label' => __('Operator Signed Notification Email', 'vms-agreements'),
            'description' => __('Sent to the operator/admin recipients after the vendor acknowledges the agreement packet.', 'vms-agreements'),
            'subject' => __('Vendor signed agreement: {event_name}', 'vms-agreements'),
            'body' => vmsa_default_operator_acknowledgement_email_body(),
        ),
    );
}

function vmsa_allowed_email_tokens(): array
{
    return array(
        '{site_name}' => __('Site name', 'vms-agreements'),
        '{vendor_name}' => __('Vendor name', 'vms-agreements'),
        '{vendor_email}' => __('Vendor email', 'vms-agreements'),
        '{vendor_phone}' => __('Vendor phone', 'vms-agreements'),
        '{event_name}' => __('Event name', 'vms-agreements'),
        '{event_date}' => __('Event date', 'vms-agreements'),
        '{event_time}' => __('Event time', 'vms-agreements'),
        '{venue_name}' => __('Venue name', 'vms-agreements'),
        '{compensation_summary}' => __('Compensation summary', 'vms-agreements'),
        '{deposit_summary}' => __('Deposit / advance summary', 'vms-agreements'),
        '{payment_summary}' => __('Payment summary', 'vms-agreements'),
        '{payment_summary_email}' => __('Payment summary formatted for email', 'vms-agreements'),
        '{total_payment}' => __('Known total/base payment', 'vms-agreements'),
        '{final_balance}' => __('Final balance after deposit when calculable', 'vms-agreements'),
        '{expected_final_payment}' => __('Expected final payment timing', 'vms-agreements'),
        '{payment_method}' => __('Payment method', 'vms-agreements'),
        '{review_link}' => __('Secure vendor review link', 'vms-agreements'),
        '{operator_note}' => __('One-time admin note entered before sending', 'vms-agreements'),
        '{signer_name}' => __('Signer name', 'vms-agreements'),
        '{signer_email}' => __('Signer email', 'vms-agreements'),
        '{acknowledged_at}' => __('Acknowledgement date/time', 'vms-agreements'),
        '{ip_address}' => __('Signer IP address', 'vms-agreements'),
        '{agreement_version}' => __('Agreement template version', 'vms-agreements'),
        '{terms_hash}' => __('Terms hash', 'vms-agreements'),
        '{comp_hash}' => __('Compensation hash', 'vms-agreements'),
        '{packet_id}' => __('Packet ID', 'vms-agreements'),
        '{packet_admin_link}' => __('Admin link to the agreement packet', 'vms-agreements'),
        '{print_link}' => __('Printable packet link', 'vms-agreements'),
        '{acknowledgement_proof}' => __('Multi-line acknowledgement proof summary', 'vms-agreements'),
    );
}

function vmsa_maybe_upgrade_email_template_defaults(): void
{
    if (!vmsa_can_manage()) {
        return;
    }

    $installed = (string) get_option('vmsa_email_template_defaults_version', '');
    if ($installed !== '' && version_compare($installed, '0.3.30', '>=')) {
        return;
    }

    $template_id = vmsa_ensure_default_template();
    if ($template_id <= 0) {
        return;
    }

    $stored = get_post_meta($template_id, '_vmsa_email_templates', true);
    $payload = vmsa_sanitize_email_template_payload(is_array($stored) ? $stored : array());
    $changed = false;

    $review_body = (string) ($payload['review']['body'] ?? '');
    if (
        $review_body === vmsa_legacy_review_email_body_0_3_2()
        || $review_body === vmsa_legacy_review_email_body_0_3_13()
        || $review_body === vmsa_legacy_review_email_body_0_3_29()
    ) {
        $payload['review']['body'] = vmsa_default_review_email_body();
        $changed = true;
    }

    $acknowledgement_body = (string) ($payload['acknowledgement']['body'] ?? '');
    if (
        $acknowledgement_body === vmsa_legacy_acknowledgement_email_body_0_3_2()
        || $acknowledgement_body === vmsa_legacy_acknowledgement_email_body_0_3_13()
        || $acknowledgement_body === vmsa_legacy_acknowledgement_email_body_0_3_29()
    ) {
        $payload['acknowledgement']['body'] = vmsa_default_acknowledgement_email_body();
        $changed = true;
    }

    if (empty($payload['operator_acknowledgement']['subject'] ?? '')) {
        $payload['operator_acknowledgement']['subject'] = (string) (vmsa_default_email_templates()['operator_acknowledgement']['subject'] ?? '');
        $changed = true;
    }

    $operator_ack_body = (string) ($payload['operator_acknowledgement']['body'] ?? '');
    if ($operator_ack_body === '' || $operator_ack_body === vmsa_legacy_operator_acknowledgement_email_body_0_3_29()) {
        $payload['operator_acknowledgement']['body'] = vmsa_default_operator_acknowledgement_email_body();
        $changed = true;
    }

    if ($changed) {
        update_post_meta($template_id, '_vmsa_email_templates', $payload);
        update_post_meta($template_id, '_vmsa_email_templates_updated_at', vmsa_current_datetime_mysql());
        update_post_meta($template_id, '_vmsa_email_templates_updated_by', get_current_user_id());
        update_post_meta($template_id, '_vmsa_email_templates_health', vmsa_email_template_health_check($payload));
    }

    update_option('vmsa_email_template_defaults_version', '0.3.30', false);
}

function vmsa_get_email_template_payload(int $template_id = 0): array
{
    if ($template_id <= 0) {
        $template_id = vmsa_ensure_default_template();
    }

    $stored = $template_id > 0 ? get_post_meta($template_id, '_vmsa_email_templates', true) : array();
    $payload = vmsa_sanitize_email_template_payload(is_array($stored) ? $stored : array());
    $payload['health'] = vmsa_email_template_health_check($payload);
    $payload['template_id'] = $template_id;
    $payload['updated_at'] = $template_id > 0 ? (string) get_post_meta($template_id, '_vmsa_email_templates_updated_at', true) : '';
    $payload['updated_by'] = $template_id > 0 ? absint(get_post_meta($template_id, '_vmsa_email_templates_updated_by', true)) : 0;

    return $payload;
}

function vmsa_sanitize_email_template_payload($payload): array
{
    $defaults = vmsa_default_email_templates();
    $raw = is_array($payload) ? $payload : array();
    $normalized = array();

    foreach ($defaults as $key => $default) {
        $incoming = isset($raw[$key]) && is_array($raw[$key]) ? $raw[$key] : array();
        $subject = isset($incoming['subject']) ? sanitize_text_field((string) $incoming['subject']) : (string) ($default['subject'] ?? '');
        $body = isset($incoming['body']) ? sanitize_textarea_field((string) $incoming['body']) : (string) ($default['body'] ?? '');

        if ($subject === '') {
            $subject = (string) ($default['subject'] ?? '');
        }
        if ($body === '') {
            $body = (string) ($default['body'] ?? '');
        }

        $normalized[$key] = array(
            'label' => (string) ($default['label'] ?? $key),
            'description' => (string) ($default['description'] ?? ''),
            'subject' => $subject,
            'body' => $body,
        );
    }

    return $normalized;
}

function vmsa_email_template_health_check(array $payload): array
{
    $issues = array();
    $review_body = (string) ($payload['review']['body'] ?? '');
    $review_subject = (string) ($payload['review']['subject'] ?? '');
    $ack_body = (string) ($payload['acknowledgement']['body'] ?? '');
    $operator_ack_body = (string) ($payload['operator_acknowledgement']['body'] ?? '');

    if (trim($review_subject) === '') {
        $issues[] = vmsa_template_health_issue('error', 'review_subject', __('Review email subject is empty.', 'vms-agreements'));
    }

    if (trim($review_body) === '') {
        $issues[] = vmsa_template_health_issue('error', 'review_body', __('Review email body is empty.', 'vms-agreements'));
    }

    if (strpos($review_body, '{review_link}') === false) {
        $issues[] = vmsa_template_health_issue('error', 'review_link', __('Review email body must include {review_link}.', 'vms-agreements'));
    }

    foreach (array('{vendor_name}', '{event_name}') as $recommended) {
        if ($review_body !== '' && strpos($review_body . $review_subject, $recommended) === false) {
            $issues[] = vmsa_template_health_issue('warning', 'review_recommended', sprintf(__('Review email should usually include %s.', 'vms-agreements'), $recommended));
        }
    }

    if (trim($ack_body) === '') {
        $issues[] = vmsa_template_health_issue('warning', 'ack_body', __('Acknowledgement confirmation email body is empty, so the fallback confirmation copy will be used.', 'vms-agreements'));
    } elseif (strpos($ack_body, '{acknowledgement_proof}') === false) {
        $issues[] = vmsa_template_health_issue('warning', 'ack_proof', __('Acknowledgement confirmation email should include {acknowledgement_proof}.', 'vms-agreements'));
    }

    if (trim($operator_ack_body) === '') {
        $issues[] = vmsa_template_health_issue('warning', 'operator_ack_body', __('Operator signed-notification email body is empty, so the fallback signed-notification copy will be used.', 'vms-agreements'));
    } elseif (strpos($operator_ack_body, '{packet_admin_link}') === false) {
        $issues[] = vmsa_template_health_issue('warning', 'operator_ack_link', __('Operator signed-notification email should include {packet_admin_link}.', 'vms-agreements'));
    }

    if (empty($issues)) {
        $issues[] = vmsa_template_health_issue('success', 'email_templates', __('Email template health check passed. Required review link and core recommended tokens are present.', 'vms-agreements'));
    }

    return $issues;
}

function vmsa_email_template_health_has_errors(array $issues): bool
{
    return vmsa_template_health_has_errors($issues);
}

function vmsa_email_template_health_status_label(array $issues): string
{
    return vmsa_template_health_status_label($issues);
}

function vmsa_email_payment_summary_lines(array $snapshot): string
{
    $comp = (array) ($snapshot['compensation'] ?? array());
    $breakdown = (array) ($comp['payment_breakdown'] ?? array());
    $lines = isset($breakdown['lines']) && is_array($breakdown['lines']) ? $breakdown['lines'] : array();

    if (empty($lines)) {
        return (string) ($comp['payment_summary'] ?? vmsa_format_payment_summary((array) ($comp['terms'] ?? array())));
    }

    $clean = array();
    foreach ($lines as $line) {
        $line = trim(vmsa_display_text($line));
        if ($line !== '') {
            $clean[] = '- ' . $line;
        }
    }

    return implode("\n", $clean);
}

function vmsa_email_template_tokens(array $snapshot, string $review_url = '', array $ack_record = array(), string $operator_note = '', int $packet_id = 0): array
{
    $event = (array) ($snapshot['event_plan'] ?? array());
    $venue = (array) ($snapshot['venue'] ?? array());
    $vendor = (array) ($snapshot['vendor'] ?? array());
    $comp = (array) ($snapshot['compensation'] ?? array());
    $breakdown = (array) ($comp['payment_breakdown'] ?? array());

    $known_amount = array_key_exists('known_amount', $breakdown) ? $breakdown['known_amount'] : null;
    $final_balance = array_key_exists('remaining_after_deposit', $breakdown) ? $breakdown['remaining_after_deposit'] : null;
    $acknowledged_at = (string) ($ack_record['acknowledged_at'] ?? '');
    $template = (array) ($snapshot['template'] ?? array());
    $packet_id = $packet_id > 0 ? $packet_id : absint($ack_record['packet_id'] ?? 0);

    $proof_lines = array();
    if (!empty($ack_record)) {
        $proof_lines[] = 'Signer: ' . vmsa_display_text($ack_record['signer_name'] ?? '-') . ' <' . (string) ($ack_record['signer_email'] ?? '-') . '>';
        $proof_lines[] = 'Acknowledged: ' . vmsa_format_audit_datetime($acknowledged_at);
        $proof_lines[] = 'Packet ID: ' . (string) absint($ack_record['packet_id'] ?? $packet_id);
        $proof_lines[] = 'Agreement version: ' . (string) ($ack_record['template_version'] ?? ($template['version'] ?? '-'));
        $proof_lines[] = 'IP address: ' . (string) ($ack_record['ip_address'] ?? '-');
        $proof_lines[] = 'Packet Verification Records:';
        $proof_lines[] = '- Terms hash: ' . (string) ($ack_record['terms_hash'] ?? ($snapshot['terms_hash'] ?? '-'));
        $proof_lines[] = '- Compensation hash: ' . (string) ($ack_record['comp_hash'] ?? ($comp['comp_hash'] ?? '-'));
    }

    $operator_note = trim($operator_note);
    if ($operator_note !== '') {
        $operator_note = "Note from the venue:\n" . $operator_note;
    }

    $packet_admin_link = $packet_id > 0 ? vmsa_admin_page_url(array('packet_id' => $packet_id)) : '';
    $print_link = ($packet_id > 0 && $review_url !== '') ? vmsa_packet_print_url($packet_id, vmsa_get_or_create_review_token($packet_id)) : '';

    return array(
        '{site_name}' => vmsa_display_text(wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES)),
        '{vendor_name}' => vmsa_display_text($vendor['name'] ?? ''),
        '{vendor_email}' => vmsa_display_text($vendor['email'] ?? ''),
        '{vendor_phone}' => vmsa_format_phone_number((string) ($vendor['phone'] ?? '')),
        '{event_name}' => vmsa_display_text($event['title'] ?? ''),
        '{event_date}' => vmsa_format_date((string) ($event['event_date'] ?? '')),
        '{event_time}' => vmsa_format_time_range((string) ($event['start_time'] ?? ''), (string) ($event['end_time'] ?? '')),
        '{venue_name}' => vmsa_display_text($venue['name'] ?? ''),
        '{compensation_summary}' => vmsa_clean_compensation_summary_text((string) ($comp['summary'] ?? '')),
        '{deposit_summary}' => vmsa_display_text($comp['deposit_summary'] ?? ''),
        '{payment_summary}' => vmsa_display_text($comp['payment_summary'] ?? vmsa_format_payment_summary((array) ($comp['terms'] ?? array()))),
        '{payment_summary_email}' => vmsa_email_payment_summary_lines($snapshot),
        '{total_payment}' => is_numeric($known_amount) ? vmsa_money($known_amount) : __('Calculated from agreement terms', 'vms-agreements'),
        '{final_balance}' => is_numeric($final_balance) ? vmsa_money($final_balance) : __('Calculated from agreement terms', 'vms-agreements'),
        '{expected_final_payment}' => vmsa_display_text($breakdown['final_payment_timing_label'] ?? ''),
        '{payment_method}' => vmsa_display_text($breakdown['final_payment_method_label'] ?? ''),
        '{review_link}' => $review_url,
        '{operator_note}' => vmsa_display_text($operator_note),
        '{signer_name}' => vmsa_display_text($ack_record['signer_name'] ?? ''),
        '{signer_email}' => (string) ($ack_record['signer_email'] ?? ''),
        '{acknowledged_at}' => $acknowledged_at !== '' ? vmsa_format_audit_datetime($acknowledged_at) : '',
        '{ip_address}' => (string) ($ack_record['ip_address'] ?? ''),
        '{agreement_version}' => (string) ($ack_record['template_version'] ?? ($template['version'] ?? '')),
        '{terms_hash}' => (string) ($ack_record['terms_hash'] ?? ($snapshot['terms_hash'] ?? '')),
        '{comp_hash}' => (string) ($ack_record['comp_hash'] ?? ($comp['comp_hash'] ?? '')),
        '{packet_id}' => (string) ($packet_id > 0 ? $packet_id : ($ack_record['packet_id'] ?? '')),
        '{packet_admin_link}' => $packet_admin_link,
        '{print_link}' => $print_link,
        '{acknowledgement_proof}' => implode("\n", array_filter($proof_lines)),
    );
}

function vmsa_apply_email_template_tokens(string $text, array $tokens): string
{
    $rendered = strtr($text, $tokens);
    $rendered = preg_replace("/\n{3,}/", "\n\n", $rendered);
    return trim(vmsa_display_text((string) $rendered));
}

function vmsa_build_templated_email(int $packet_id, int $template_id, string $template_key, array $snapshot, string $review_url = '', array $ack_record = array(), string $operator_note = ''): array
{
    $payload = vmsa_get_email_template_payload($template_id);
    $templates = vmsa_sanitize_email_template_payload($payload);
    $selected = isset($templates[$template_key]) && is_array($templates[$template_key]) ? $templates[$template_key] : (vmsa_default_email_templates()[$template_key] ?? array());
    $tokens = vmsa_email_template_tokens($snapshot, $review_url, $ack_record, $operator_note, $packet_id);

    return array(
        'subject' => vmsa_apply_email_template_tokens((string) ($selected['subject'] ?? ''), $tokens),
        'body' => vmsa_apply_email_template_tokens((string) ($selected['body'] ?? ''), $tokens),
        'tokens' => $tokens,
        'health' => (array) ($payload['health'] ?? array()),
    );
}

function vmsa_build_review_email(int $packet_id, array $snapshot, string $review_url, string $operator_note = ''): array
{
    $template_id = absint($snapshot['template']['id'] ?? get_post_meta($packet_id, '_vmsa_template_id', true));
    return vmsa_build_templated_email($packet_id, $template_id, 'review', $snapshot, $review_url, array(), $operator_note);
}

function vmsa_build_acknowledgement_confirmation_email(int $packet_id, array $snapshot, array $ack_record, string $review_url): array
{
    $template_id = absint($snapshot['template']['id'] ?? get_post_meta($packet_id, '_vmsa_template_id', true));
    return vmsa_build_templated_email($packet_id, $template_id, 'acknowledgement', $snapshot, $review_url, $ack_record, '');
}

function vmsa_build_operator_acknowledgement_notification_email(int $packet_id, array $snapshot, array $ack_record, string $review_url): array
{
    $template_id = absint($snapshot['template']['id'] ?? get_post_meta($packet_id, '_vmsa_template_id', true));
    return vmsa_build_templated_email($packet_id, $template_id, 'operator_acknowledgement', $snapshot, $review_url, $ack_record, '');
}

function vmsa_get_operator_acknowledgement_notification_recipients(int $packet_id, array $snapshot = array(), array $ack_record = array()): array
{
    $default = array();
    $admin_email = sanitize_email((string) get_option('admin_email'));
    if ($admin_email !== '') {
        $default[] = $admin_email;
    }

    $filtered = apply_filters('vmsa_operator_acknowledgement_notification_recipients', $default, $packet_id, $snapshot, $ack_record);
    if (!is_array($filtered)) {
        $filtered = array($filtered);
    }

    $emails = array();
    foreach ($filtered as $value) {
        $email = sanitize_email((string) $value);
        if ($email !== '') {
            $emails[] = $email;
        }
    }

    return array_values(array_unique($emails));
}
