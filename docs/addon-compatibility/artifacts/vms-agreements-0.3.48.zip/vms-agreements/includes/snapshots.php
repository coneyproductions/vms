<?php
if (!defined('ABSPATH')) {
    exit;
}

function vmsa_comp_structure_label(string $structure): string
{
    $labels = array(
        'flat_fee' => __('Flat fee', 'vms-agreements'),
        'door_split' => __('Door split', 'vms-agreements'),
        'flat_fee_door_split' => __('Flat fee + door split', 'vms-agreements'),
        'attendance_bonus' => __('Base + attendance bonus', 'vms-agreements'),
    );

    return $labels[$structure] ?? ucwords(str_replace('_', ' ', $structure));
}

function vmsa_bonus_count_source_label(array $terms): string
{
    $candidate_keys = array(
        'attendance_bonus_count_source',
        'attendance_bonus_count_basis',
        'attendance_bonus_basis',
        'attendance_bonus_metric',
        'bonus_count_source',
        'bonus_basis',
        'count_source',
    );

    $source = '';
    foreach ($candidate_keys as $key) {
        if (isset($terms[$key]) && trim((string) $terms[$key]) !== '') {
            $source = sanitize_key((string) $terms[$key]);
            break;
        }
    }

    if ($source !== '') {
        if (strpos($source, 'paid') !== false && (strpos($source, 'ticket') !== false || strpos($source, 'sale') !== false)) {
            return __('paid ticket sales', 'vms-agreements');
        }
        if (strpos($source, 'ticket') !== false || strpos($source, 'sale') !== false) {
            return __('ticket sales', 'vms-agreements');
        }
        if (strpos($source, 'attend') !== false || strpos($source, 'headcount') !== false) {
            return __('attendees', 'vms-agreements');
        }
    }

    // VMS Core currently treats the bonus threshold as paid ticket sales for
    // agreements. Default to the legally clearer basis instead of implying raw
    // attendance/headcount.
    return __('paid ticket sales', 'vms-agreements');
}


function vmsa_bonus_count_source_unit_label(array $terms): string
{
    $candidate_keys = array(
        'attendance_bonus_count_source',
        'attendance_bonus_count_basis',
        'attendance_bonus_basis',
        'attendance_bonus_metric',
        'bonus_count_source',
        'bonus_basis',
        'count_source',
    );

    $source = '';
    foreach ($candidate_keys as $key) {
        if (isset($terms[$key]) && trim((string) $terms[$key]) !== '') {
            $source = sanitize_key((string) $terms[$key]);
            break;
        }
    }

    if ($source !== '') {
        if (strpos($source, 'paid') !== false && (strpos($source, 'ticket') !== false || strpos($source, 'sale') !== false)) {
            return __('paid ticket sale', 'vms-agreements');
        }
        if (strpos($source, 'ticket') !== false || strpos($source, 'sale') !== false) {
            return __('ticket sale', 'vms-agreements');
        }
        if (strpos($source, 'attend') !== false || strpos($source, 'headcount') !== false) {
            return __('attendee', 'vms-agreements');
        }
    }

    return __('paid ticket sale', 'vms-agreements');
}


function vmsa_bonus_count_source_table_heading(array $terms): string
{
    $label = vmsa_bonus_count_source_label($terms);
    $normalized = strtolower($label);

    if ($normalized === 'paid ticket sales') {
        return __('Paid ticket sales', 'vms-agreements');
    }

    if ($normalized === 'ticket sales') {
        return __('Ticket sales', 'vms-agreements');
    }

    if ($normalized === 'attendees') {
        return __('Attendance', 'vms-agreements');
    }

    return ucwords($label);
}

function vmsa_build_bonus_payout_rows(array $terms, int $row_limit = 6): array
{
    $structure = sanitize_key((string) ($terms['structure'] ?? ''));
    $mode = sanitize_key((string) ($terms['attendance_bonus_mode'] ?? ''));

    if ($structure !== 'attendance_bonus' || $mode !== 'step') {
        return array();
    }

    $base = vmsa_clean_money($terms['flat_fee_amount'] ?? null);
    $start = isset($terms['attendance_bonus_start_count']) && is_numeric($terms['attendance_bonus_start_count'])
        ? absint($terms['attendance_bonus_start_count'])
        : 0;
    $step_size = isset($terms['attendance_bonus_step_size']) && is_numeric($terms['attendance_bonus_step_size'])
        ? absint($terms['attendance_bonus_step_size'])
        : 0;
    $step_bonus = vmsa_clean_money($terms['attendance_bonus_step_bonus'] ?? null);
    $max_bonus = vmsa_clean_money($terms['attendance_bonus_max_bonus'] ?? null);

    if ($base === null || $start <= 0 || $step_size <= 0 || $step_bonus === null) {
        return array();
    }

    $row_limit = max(2, min(12, $row_limit));
    $rows = array();

    for ($i = 0; $i < $row_limit; $i++) {
        $bonus = round($step_bonus * $i, 2);
        if ($max_bonus !== null) {
            $bonus = min($bonus, $max_bonus);
        }

        $rows[] = array(
            'count' => $start + ($step_size * $i),
            'bonus' => $bonus,
            'payout' => round($base + $bonus, 2),
        );

        if ($max_bonus !== null && $bonus >= $max_bonus) {
            break;
        }
    }

    return $rows;
}

function vmsa_format_bonus_payout_table_text(array $terms): string
{
    $rows = vmsa_build_bonus_payout_rows($terms);
    if (empty($rows)) {
        return '';
    }

    $count_heading = vmsa_bonus_count_source_table_heading($terms);
    $payout_heading = __('Payout', 'vms-agreements');

    $count_width = max(strlen($count_heading), 5);
    foreach ($rows as $row) {
        $count_width = max($count_width, strlen((string) ($row['count'] ?? '')));
    }

    $lines = array();
    $lines[] = str_pad($count_heading, $count_width) . ' | ' . $payout_heading;
    $lines[] = str_repeat('-', $count_width) . '-|-' . str_repeat('-', strlen($payout_heading));

    foreach ($rows as $row) {
        $lines[] = str_pad((string) absint($row['count'] ?? 0), $count_width) . ' | ' . vmsa_money($row['payout'] ?? null);
    }

    return implode("\n", $lines);
}

function vmsa_format_compensation_summary(array $terms): string
{
    $structure = sanitize_key((string) ($terms['structure'] ?? 'flat_fee'));
    $parts = array();

    $flat = vmsa_clean_money($terms['flat_fee_amount'] ?? null);
    $split = isset($terms['door_split_percent']) && is_numeric($terms['door_split_percent']) ? (float) $terms['door_split_percent'] : null;

    if ($flat !== null && in_array($structure, array('flat_fee', 'flat_fee_door_split', 'attendance_bonus'), true)) {
        if ($structure === 'attendance_bonus') {
            $parts[] = __('Base fee:', 'vms-agreements') . ' ' . vmsa_money($flat);
        } else {
            $parts[] = __('Flat fee:', 'vms-agreements') . ' ' . vmsa_money($flat);
        }
    } elseif ($structure !== '') {
        $parts[] = vmsa_comp_structure_label($structure);
    }

    if ($split !== null && in_array($structure, array('door_split', 'flat_fee_door_split'), true)) {
        $parts[] = __('Door split:', 'vms-agreements') . ' ' . rtrim(rtrim(number_format($split, 2, '.', ''), '0'), '.') . '%';
    }
    if ($structure === 'attendance_bonus') {
        $mode = sanitize_key((string) ($terms['attendance_bonus_mode'] ?? ''));
        $start = isset($terms['attendance_bonus_start_count']) && is_numeric($terms['attendance_bonus_start_count']) ? absint($terms['attendance_bonus_start_count']) : null;
        $max = vmsa_clean_money($terms['attendance_bonus_max_bonus'] ?? null);
        $count_label = vmsa_bonus_count_source_label($terms);
        $count_unit_label = vmsa_bonus_count_source_unit_label($terms);

        if ($mode === 'step') {
            $step_size = isset($terms['attendance_bonus_step_size']) && is_numeric($terms['attendance_bonus_step_size']) ? absint($terms['attendance_bonus_step_size']) : null;
            $step_bonus = vmsa_clean_money($terms['attendance_bonus_step_bonus'] ?? null);

            if (!empty(vmsa_build_bonus_payout_rows($terms))) {
                $parts[] = __('Bonus: see payout table below.', 'vms-agreements');
            } elseif ($start !== null && $step_size !== null) {
                $parts[] = sprintf(
                    /* translators: 1 count source, 2 threshold count, 3 bonus amount, 4 step size */
                    __('Bonus: No bonus is earned through %2$s %1$s. Add %3$s every %4$s %1$s after that.', 'vms-agreements'),
                    $count_label,
                    (string) $start,
                    $step_bonus === null ? '-' : vmsa_money($step_bonus),
                    (string) $step_size
                );
            } else {
                $parts[] = sprintf(
                    /* translators: 1 bonus amount, 2 step size, 3 count source */
                    __('Bonus: Add %1$s every %2$s additional %3$s above the bonus threshold.', 'vms-agreements'),
                    $step_bonus === null ? '-' : vmsa_money($step_bonus),
                    $step_size === null ? '-' : (string) $step_size,
                    $count_label
                );
            }
        } elseif ($mode === 'continuous') {
            $rate = vmsa_clean_money($terms['attendance_bonus_per_ticket_rate'] ?? null);
            if ($start !== null) {
                $parts[] = sprintf(
                    /* translators: 1 count source, 2 threshold count, 3 per-ticket amount, 4 singular count unit */
                    __('Bonus: No bonus is earned through %2$s %1$s. Add %3$s for each additional %4$s after that.', 'vms-agreements'),
                    $count_label,
                    (string) $start,
                    $rate === null ? '-' : vmsa_money($rate),
                    $count_unit_label
                );
            } else {
                $parts[] = sprintf(
                    /* translators: 1 per-ticket amount, 2 singular count unit */
                    __('Bonus: Add %1$s for each additional %2$s above the bonus threshold.', 'vms-agreements'),
                    $rate === null ? '-' : vmsa_money($rate),
                    $count_unit_label
                );
            }
        }

        if ($max !== null) {
            $parts[] = __('Bonus cap:', 'vms-agreements') . ' ' . vmsa_money($max);
        }
    }

    $commission = isset($terms['commission_percent']) && is_numeric($terms['commission_percent']) ? (float) $terms['commission_percent'] : null;
    if ($commission !== null && $commission > 0) {
        $mode = sanitize_key((string) ($terms['commission_mode'] ?? 'artist_fee'));
        $parts[] = sprintf(
            /* translators: 1 percent, 2 mode */
            __('Agent fee: %1$s%% (%2$s)', 'vms-agreements'),
            rtrim(rtrim(number_format($commission, 2, '.', ''), '0'), '.'),
            str_replace('_', ' ', $mode)
        );
    }

    return vmsa_clean_compensation_summary_text(implode('; ', array_filter($parts)));
}

function vmsa_compensation_known_amount(array $terms): ?float
{
    $structure = sanitize_key((string) ($terms['structure'] ?? 'flat_fee'));
    $flat = vmsa_clean_money($terms['flat_fee_amount'] ?? null);

    if ($flat !== null && in_array($structure, array('flat_fee', 'flat_fee_door_split', 'attendance_bonus'), true)) {
        return $flat;
    }

    return null;
}

function vmsa_compensation_has_variable_component(array $terms): bool
{
    $structure = sanitize_key((string) ($terms['structure'] ?? 'flat_fee'));
    return in_array($structure, array('door_split', 'flat_fee_door_split', 'attendance_bonus'), true);
}

function vmsa_deposit_status_label(string $status): string
{
    $status = sanitize_key($status);
    $labels = array(
        'not_required' => __('Not required', 'vms-agreements'),
        'unpaid' => __('Unpaid', 'vms-agreements'),
        'paid' => __('Paid', 'vms-agreements'),
        'waived' => __('Waived', 'vms-agreements'),
        'refunded' => __('Refunded', 'vms-agreements'),
    );

    return (string) ($labels[$status] ?? ucwords(str_replace('_', ' ', $status)));
}

function vmsa_deposit_treatment_label(string $treatment): string
{
    $treatment = sanitize_key($treatment);
    $labels = array(
        'creditable' => __('Applies toward the total payment', 'vms-agreements'),
        'refundable' => __('Refundable under the agreement terms', 'vms-agreements'),
        'non_refundable' => __('Non-refundable under the agreement terms', 'vms-agreements'),
        'nonrefundable' => __('Non-refundable under the agreement terms', 'vms-agreements'),
    );

    return (string) ($labels[$treatment] ?? ucwords(str_replace('_', ' ', $treatment)));
}

function vmsa_format_deposit_summary(array $terms): string
{
    $amount = vmsa_clean_money($terms['deposit_amount'] ?? null);
    $normalize_status_function = vmsa_core_function_name('vms_normalize_comp_deposit_status');
    $normalize_treatment_function = vmsa_core_function_name('vms_normalize_comp_deposit_treatment');
    $normalize_date_function = vmsa_core_function_name('vms_normalize_comp_deposit_date');
    $status = $normalize_status_function !== ''
        ? (string) $normalize_status_function($terms['deposit_status'] ?? '')
        : sanitize_key((string) ($terms['deposit_status'] ?? 'not_required'));
    $treatment = $normalize_treatment_function !== ''
        ? (string) $normalize_treatment_function($terms['deposit_treatment'] ?? '')
        : sanitize_key((string) ($terms['deposit_treatment'] ?? 'creditable'));
    $due = $normalize_date_function !== ''
        ? (string) $normalize_date_function($terms['deposit_due_date'] ?? '')
        : (string) ($terms['deposit_due_date'] ?? '');
    $paid = $normalize_date_function !== ''
        ? (string) $normalize_date_function($terms['deposit_paid_date'] ?? '')
        : (string) ($terms['deposit_paid_date'] ?? '');
    $notes = trim((string) ($terms['deposit_notes'] ?? ''));

    if ($amount !== null && $amount > 0 && $status === 'not_required') {
        $status = 'unpaid';
    }

    if (($amount === null || $amount <= 0) && $status === 'not_required' && $due === '' && $paid === '' && $notes === '') {
        return __('No deposit required.', 'vms-agreements');
    }

    $parts = array();
    $parts[] = ($amount !== null && $amount > 0) ? vmsa_money($amount) : __('No amount set', 'vms-agreements');
    $parts[] = vmsa_deposit_status_label($status);

    if ($treatment !== '' && $status !== 'not_required') {
        $parts[] = vmsa_deposit_treatment_label($treatment);
    }

    if ($due !== '') {
        $parts[] = __('Due', 'vms-agreements') . ' ' . vmsa_format_date($due);
    }
    if ($paid !== '') {
        $parts[] = __('Paid', 'vms-agreements') . ' ' . vmsa_format_date($paid);
    }
    // Deposit notes remain captured in the packet snapshot, but are not printed
    // in the vendor-facing default summary. Operators can add custom clause text
    // in the structured template when a special explanation is needed.

    return implode('; ', array_filter($parts));
}


function vmsa_final_payment_timing_label(array $terms): string
{
    $timing_label_function = vmsa_core_function_name('vms_comp_final_payment_timing_label');
    if ($timing_label_function !== '') {
        return (string) $timing_label_function($terms);
    }

    $timing = sanitize_key((string) ($terms['final_payment_timing'] ?? ''));
    $days = preg_replace('/[^0-9]/', '', (string) ($terms['final_payment_days_after'] ?? ''));
    $date = (string) ($terms['final_payment_date'] ?? '');
    $custom = trim((string) ($terms['final_payment_custom_text'] ?? ''));

    if ($timing === 'in_advance') {
        return __('In advance', 'vms-agreements');
    }
    if ($timing === 'day_of_event') {
        return __('Day of event', 'vms-agreements');
    }
    if ($timing === 'days_after') {
        return $days !== '' ? sprintf(_n('%s day after event', '%s days after event', (int) $days, 'vms-agreements'), $days) : __('After event - number of days not set', 'vms-agreements');
    }
    if ($timing === 'fixed_date') {
        return $date !== '' ? sprintf(__('Specific date: %s', 'vms-agreements'), vmsa_format_date($date)) : __('Specific date not set', 'vms-agreements');
    }
    if ($timing === 'custom') {
        return $custom !== '' ? $custom : __('Custom timing not set', 'vms-agreements');
    }

    return '';
}

function vmsa_final_payment_method_label(array $terms): string
{
    $method_label_function = vmsa_core_function_name('vms_comp_final_payment_method_label');
    if ($method_label_function !== '') {
        return (string) $method_label_function($terms);
    }

    $method = sanitize_key((string) ($terms['final_payment_method'] ?? ''));
    $other = trim((string) ($terms['final_payment_method_other'] ?? ''));
    $labels = vmsa_payment_method_choices();

    if ($method === 'other') {
        return $other !== '' ? $other : __('Other method not specified', 'vms-agreements');
    }

    return (string) ($labels[$method] ?? '');
}

function vmsa_apply_agreement_payment_defaults(array $terms): array
{
    $timing = sanitize_key((string) ($terms['final_payment_timing'] ?? ''));
    $days = absint($terms['final_payment_days_after'] ?? 0);

    if ($timing === '' || ($timing === 'days_after' && $days <= 0)) {
        $terms['final_payment_timing'] = 'days_after';
        $terms['final_payment_days_after'] = vmsa_get_standard_final_payment_days();
    }

    return $terms;
}

/**
 * Plain-English meaning of an attendance-bonus table. This is rendered next to
 * the protected payout schedule so the count basis cannot be mistaken for raw
 * attendance and the threshold payouts cannot be read as cumulative bonuses.
 */
function vmsa_bonus_qualification_note(array $terms): string
{
    if (sanitize_key((string) ($terms['structure'] ?? '')) !== 'attendance_bonus') {
        return '';
    }

    $basis = strtolower(vmsa_bonus_count_source_label($terms));
    if ($basis === 'paid ticket sales') {
        return __('Bonus thresholds use qualifying paid ticket sales only. Discounted paid tickets count. Free or complimentary admissions, refunded or cancelled tickets, chargebacks known at settlement, staff/vendor admissions, and other non-revenue admissions do not count toward bonus thresholds. The base guarantee still applies below the first listed threshold. The highest qualifying threshold reached determines the payout; tiers are not cumulative.', 'vms-agreements');
    }

    return sprintf(
        /* translators: %s is the configured bonus count basis. */
        __('Bonus thresholds are measured using %s. The base guarantee still applies below the first listed threshold. The highest qualifying threshold reached determines the payout; tiers are not cumulative.', 'vms-agreements'),
        $basis
    );
}

function vmsa_build_payment_breakdown(array $terms): array
{
    $known_amount = vmsa_compensation_known_amount($terms);
    $has_variable = vmsa_compensation_has_variable_component($terms);
    $deposit_amount = vmsa_clean_money($terms['deposit_amount'] ?? null);
    $deposit_applies = $deposit_amount !== null && $deposit_amount > 0;
    $remaining = ($known_amount !== null && $deposit_applies) ? max(0, round($known_amount - $deposit_amount, 2)) : null;
    $timing_label = vmsa_final_payment_timing_label($terms);
    $method_label = vmsa_final_payment_method_label($terms);

    $lines = array();
    if ($known_amount !== null) {
        $lines[] = sprintf(
            $has_variable
                ? __('Base guarantee: %s', 'vms-agreements')
                : __('Total agreed payment: %s', 'vms-agreements'),
            vmsa_money($known_amount)
        );
    } else {
        $lines[] = __('Total payment: calculated from the compensation terms after the event.', 'vms-agreements');
    }

    if ($deposit_applies) {
        $normalize_status_function = vmsa_core_function_name('vms_normalize_comp_deposit_status');
        $status = $normalize_status_function !== ''
            ? (string) $normalize_status_function($terms['deposit_status'] ?? '')
            : sanitize_key((string) ($terms['deposit_status'] ?? 'unpaid'));
        if ($status === 'not_required') {
            $status = 'unpaid';
        }

        $lines[] = sprintf(
            __('Deposit/advance: %1$s (%2$s).', 'vms-agreements'),
            vmsa_money($deposit_amount),
            vmsa_deposit_status_label($status)
        );

        if ($remaining !== null) {
            $lines[] = sprintf(
                $has_variable
                    ? __('Known remaining final payment after deposit/advance: %s, before variable compensation or adjustments.', 'vms-agreements')
                    : __('Remaining final payment after deposit/advance: %s', 'vms-agreements'),
                vmsa_money($remaining)
            );
        }
    } else {
        $lines[] = __('Deposit/advance: none required.', 'vms-agreements');
        if ($known_amount !== null && !$has_variable) {
            $lines[] = sprintf(__('Remaining final payment: %s', 'vms-agreements'), vmsa_money($known_amount));
        }
    }

    if ($timing_label !== '') {
        $lines[] = sprintf(__('Final payment due: %s', 'vms-agreements'), $timing_label);
    }

    if ($method_label !== '') {
        $lines[] = sprintf(__('Payment method: %s', 'vms-agreements'), $method_label);
    }

    if ($has_variable) {
        $lines[] = __('Variable compensation: determined by the applicable compensation and bonus terms in this packet.', 'vms-agreements');
    }

    return array(
        'known_amount' => $known_amount,
        'deposit_amount' => $deposit_amount,
        'remaining_after_deposit' => $remaining,
        'has_variable_component' => $has_variable,
        'final_payment_timing_label' => $timing_label,
        'final_payment_method_label' => $method_label,
        'summary' => implode(' ', array_filter($lines)),
        'lines' => $lines,
    );
}

function vmsa_format_payment_summary(array $terms): string
{
    $breakdown = vmsa_build_payment_breakdown($terms);
    return (string) ($breakdown['summary'] ?? '');
}


function vmsa_canonicalize_terms_hash_value($value)
{
    if (is_array($value)) {
        $skip_keys = array(
            'admin_url',
            'created_at',
            'created_at_gmt',
            'created_by',
            'edit_url',
            'generated_at',
            'generated_at_gmt',
            'generated_by',
            'health',
            'last_error',
            'modified',
            'modified_gmt',
            'snapshot_version',
            'updated_at',
            'updated_at_gmt',
            'updated_by',
            'url',
        );

        foreach ($skip_keys as $skip_key) {
            if (array_key_exists($skip_key, $value)) {
                unset($value[$skip_key]);
            }
        }

        $is_list = array_keys($value) === range(0, count($value) - 1);
        if (!$is_list) {
            ksort($value);
        }

        foreach ($value as $key => $child) {
            $value[$key] = vmsa_canonicalize_terms_hash_value($child);
        }

        return $value;
    }

    if (is_string($value)) {
        $value = vmsa_display_text($value);
        $value = preg_replace('/[ \t]+/u', ' ', $value);
        $value = preg_replace('/\R/u', "\n", $value);
        return trim(is_string($value) ? $value : '');
    }

    return $value;
}

function vmsa_snapshot_terms_hash_payload(array $snapshot): array
{
    $event = (array) ($snapshot['event_plan'] ?? array());
    $operator = (array) ($snapshot['operator'] ?? array());
    $venue = (array) ($snapshot['venue'] ?? array());
    $vendor = (array) ($snapshot['vendor'] ?? array());
    $comp = (array) ($snapshot['compensation'] ?? array());
    $template = (array) ($snapshot['template'] ?? array());

    // Keep the packet currency check focused on contract-significant values.
    // Avoid derived/display-only strings and WordPress/editor volatility, because
    // those can change between admin and vendor-portal contexts and make a
    // brand-new packet appear stale immediately after generation.
    //
    // New contract-significant keys are appended conditionally so historical
    // packet snapshots continue to reproduce the hash schema they were issued
    // with rather than appearing tampered merely because the plugin upgraded.
    $vendor_payload = array(
        'id' => absint($vendor['id'] ?? 0),
        'name' => vmsa_display_text($vendor['name'] ?? ''),
        'email' => sanitize_email((string) ($vendor['email'] ?? '')),
        'phone' => preg_replace('/\D+/', '', (string) ($vendor['phone'] ?? '')),
    );
    if (array_key_exists('legal_name', $vendor)) {
        $vendor_payload['legal_name'] = vmsa_display_text($vendor['legal_name'] ?? '');
    }
    if (array_key_exists('representative_name', $vendor)) {
        $vendor_payload['representative_name'] = vmsa_display_text($vendor['representative_name'] ?? '');
    }

    $payload = array(
        'event_plan' => array(
            'id' => absint($event['id'] ?? 0),
            'title' => vmsa_display_text($event['title'] ?? ''),
            'event_date' => (string) ($event['event_date'] ?? ''),
            'start_time' => (string) ($event['start_time'] ?? ''),
            'end_time' => (string) ($event['end_time'] ?? ''),
        ),
        'operator' => array(
            'contracting_entity' => vmsa_display_text($operator['contracting_entity'] ?? ''),
            'standard_final_payment_days' => absint($operator['standard_final_payment_days'] ?? 0),
        ),
        'venue' => array(
            'id' => absint($venue['id'] ?? 0),
            'name' => vmsa_display_text($venue['name'] ?? ''),
        ),
        'vendor' => $vendor_payload,
        'compensation' => array(
            'terms' => (array) ($comp['terms'] ?? array()),
        ),
        'template' => array(
            'id' => absint($template['id'] ?? 0),
            'version' => (string) ($template['version'] ?? ''),
            'body_hash' => (string) ($template['body_hash'] ?? ''),
            'acknowledgements' => array_map(static function ($ack): array {
                $ack = is_array($ack) ? $ack : array();
                return array(
                    'key' => sanitize_key((string) ($ack['key'] ?? '')),
                    'label' => vmsa_display_text($ack['label'] ?? ''),
                    'required' => !empty($ack['required']),
                );
            }, (array) ($template['acknowledgements'] ?? array())),
        ),
    );

    if (isset($snapshot['production']) && is_array($snapshot['production'])) {
        $production = (array) $snapshot['production'];
        $payload['production'] = array(
            'stage' => sanitize_key((string) ($production['stage'] ?? '')),
            'house_sound' => sanitize_key((string) ($production['house_sound'] ?? '')),
            'stage_lighting' => sanitize_key((string) ($production['stage_lighting'] ?? '')),
            'sound_engineer' => sanitize_key((string) ($production['sound_engineer'] ?? '')),
        );
    }

    if (isset($snapshot['production_schedule']) && is_array($snapshot['production_schedule'])) {
        $schedule = (array) $snapshot['production_schedule'];
        $payload['production_schedule'] = array(
            'arrival_loadin' => (string) ($schedule['arrival_loadin'] ?? ''),
            'soundcheck_start' => (string) ($schedule['soundcheck_start'] ?? ''),
            'soundcheck_end' => (string) ($schedule['soundcheck_end'] ?? ''),
            'vacate_by' => (string) ($schedule['vacate_by'] ?? ''),
        );
    }

    return $payload;
}

function vmsa_build_snapshot_terms_hash(array $snapshot): string
{
    return vmsa_hash_payload(vmsa_canonicalize_terms_hash_value(vmsa_snapshot_terms_hash_payload($snapshot)));
}

function vmsa_snapshot_terms_canonical_payload(array $snapshot): array
{
    return vmsa_canonicalize_terms_hash_value(vmsa_snapshot_terms_hash_payload($snapshot));
}

function vmsa_format_terms_diagnostic_value($value): string
{
    if (is_bool($value)) {
        return $value ? 'true' : 'false';
    }

    if ($value === null) {
        return 'null';
    }

    if (is_array($value)) {
        $encoded = wp_json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return is_string($encoded) ? $encoded : '[array]';
    }

    return vmsa_display_text((string) $value);
}

function vmsa_diff_terms_payloads($left, $right, string $path = '', int $limit = 40): array
{
    if ($limit <= 0) {
        return array();
    }

    $diffs = array();
    if (is_array($left) || is_array($right)) {
        $left = is_array($left) ? $left : array();
        $right = is_array($right) ? $right : array();
        $keys = array_values(array_unique(array_merge(array_keys($left), array_keys($right))));
        sort($keys);

        foreach ($keys as $key) {
            if (count($diffs) >= $limit) {
                break;
            }

            $child_path = $path === '' ? (string) $key : $path . '.' . (string) $key;
            if (!array_key_exists($key, $left)) {
                $diffs[] = array(
                    'path' => $child_path,
                    'packet' => '[missing]',
                    'current' => vmsa_format_terms_diagnostic_value($right[$key]),
                );
                continue;
            }

            if (!array_key_exists($key, $right)) {
                $diffs[] = array(
                    'path' => $child_path,
                    'packet' => vmsa_format_terms_diagnostic_value($left[$key]),
                    'current' => '[missing]',
                );
                continue;
            }

            $child_diffs = vmsa_diff_terms_payloads($left[$key], $right[$key], $child_path, $limit - count($diffs));
            $diffs = array_merge($diffs, $child_diffs);
        }

        return array_slice($diffs, 0, $limit);
    }

    if ($left !== $right) {
        $diffs[] = array(
            'path' => $path,
            'packet' => vmsa_format_terms_diagnostic_value($left),
            'current' => vmsa_format_terms_diagnostic_value($right),
        );
    }

    return $diffs;
}

function vmsa_packet_terms_diagnostics(int $packet_id): array
{
    $snapshot = vmsa_get_packet_snapshot($packet_id);
    $event_plan_id = absint($snapshot['event_plan']['id'] ?? get_post_meta($packet_id, '_vmsa_event_plan_id', true));
    $template_id = absint($snapshot['template']['id'] ?? get_post_meta($packet_id, '_vmsa_template_id', true));

    $packet_payload = vmsa_snapshot_terms_canonical_payload($snapshot);
    $packet_hash = vmsa_hash_payload($packet_payload);
    $stored_hash = (string) ($snapshot['terms_hash'] ?? get_post_meta($packet_id, '_vmsa_terms_hash', true));
    $current_snapshot = array();
    $current_payload = array();
    $current_hash = '';
    $diffs = array();
    $error = '';
    $fallbacks = array();
    $comp_helper_available = vmsa_core_function_name('vms_get_event_plan_comp_terms') !== '';

    if ($event_plan_id > 0) {
        $current = vmsa_build_event_plan_snapshot($event_plan_id, $template_id);
        if (is_wp_error($current)) {
            $error = $current->get_error_message();
        } else {
            $current_snapshot = $current;

            // On public/vendor-portal requests VMS Core may not have loaded the
            // admin compensation helper. In 0.3.27 that meant the current
            // comparison rebuilt compensation as an empty array, so the exact
            // same packet could show Current in wp-admin but stale on the public
            // review page. If the helper is unavailable, compare the current
            // Event/Vendor/Template fields while preserving the packet's stored
            // compensation terms for the current-side fingerprint instead of
            // manufacturing an empty compensation change.
            if (!$comp_helper_available && !empty($snapshot['compensation']['terms'])) {
                $current_snapshot['compensation'] = (array) ($snapshot['compensation'] ?? array());
                $fallbacks[] = 'compensation_terms_from_packet_snapshot';
            }

            $current_payload = vmsa_snapshot_terms_canonical_payload($current_snapshot);
            $current_hash = vmsa_hash_payload($current_payload);
            $diffs = vmsa_diff_terms_payloads($packet_payload, $current_payload);
        }
    } else {
        $error = __('Packet is missing an Event Plan reference.', 'vms-agreements');
    }

    return array(
        'packet_id' => $packet_id,
        'event_plan_id' => $event_plan_id,
        'template_id' => $template_id,
        'stored_hash' => $stored_hash,
        'packet_hash' => $packet_hash,
        'current_hash' => $current_hash,
        'matches_stored_packet' => $stored_hash !== '' && hash_equals($stored_hash, $packet_hash),
        'matches_current' => $packet_hash !== '' && $current_hash !== '' && hash_equals($packet_hash, $current_hash),
        'differences' => $diffs,
        'error' => $error,
        'fallbacks' => $fallbacks,
        'comp_helper_available' => $comp_helper_available,
    );
}

function vmsa_clean_snapshot_display_strings($value)
{
    if (is_array($value)) {
        foreach ($value as $key => $child) {
            $value[$key] = vmsa_clean_snapshot_display_strings($child);
        }
        return $value;
    }

    if (is_string($value)) {
        return vmsa_display_text($value);
    }

    return $value;
}

function vmsa_build_event_plan_snapshot(int $event_plan_id, int $template_id = 0): array|WP_Error
{
    if (!vmsa_core_version_ok()) {
        return new WP_Error('vmsa_dependency', __('VMS Core is missing or too old for agreement packet generation.', 'vms-agreements'));
    }

    $event_post = get_post($event_plan_id);
    if (!$event_post || $event_post->post_type !== 'vms_event_plan') {
        return new WP_Error('vmsa_missing_plan', __('Event Plan not found.', 'vms-agreements'));
    }

    $block_reason = vmsa_event_plan_generation_block_reason($event_plan_id);
    if (in_array($block_reason, array('cancelled_event', 'past_event'), true)) {
        return new WP_Error('vmsa_event_not_eligible', vmsa_event_plan_generation_block_message($event_plan_id, $block_reason));
    }
    if ($block_reason === 'missing_contracting_entity') {
        return new WP_Error('vmsa_missing_contracting_entity', vmsa_event_plan_generation_block_message($event_plan_id, $block_reason));
    }
    if ($block_reason === 'missing_vendor_legal_name') {
        return new WP_Error('vmsa_missing_vendor_legal_name', vmsa_event_plan_generation_block_message($event_plan_id, $block_reason));
    }
    if ($block_reason === 'missing_vendor_representative') {
        return new WP_Error('vmsa_missing_vendor_representative', vmsa_event_plan_generation_block_message($event_plan_id, $block_reason));
    }
    if ($block_reason === 'payment_method_incomplete') {
        return new WP_Error('vmsa_payment_method_incomplete', vmsa_event_plan_generation_block_message($event_plan_id, $block_reason));
    }
    if ($block_reason === 'production_terms_incomplete') {
        return new WP_Error('vmsa_production_terms_incomplete', vmsa_event_plan_generation_block_message($event_plan_id, $block_reason));
    }
    if ($block_reason === 'production_schedule_incomplete') {
        return new WP_Error('vmsa_production_schedule_incomplete', vmsa_event_plan_generation_block_message($event_plan_id, $block_reason));
    }

    $vendor_id = vmsa_get_primary_vendor_id($event_plan_id);
    if ($vendor_id <= 0) {
        return new WP_Error('vmsa_missing_vendor', __('This Event Plan does not have a primary vendor yet.', 'vms-agreements'));
    }

    $venue_id = vmsa_get_venue_id($event_plan_id);
    $event_date = (string) get_post_meta($event_plan_id, '_vms_event_date', true);
    $start_time = (string) get_post_meta($event_plan_id, '_vms_start_time', true);
    $end_time = (string) get_post_meta($event_plan_id, '_vms_end_time', true);
    $status = vmsa_get_event_plan_status($event_plan_id);

    $comp_terms_function = vmsa_core_function_name('vms_get_event_plan_comp_terms');
    $comp_terms = $comp_terms_function !== ''
        ? (array) $comp_terms_function($event_plan_id)
        : array();
    $comp_terms = vmsa_apply_agreement_payment_defaults($comp_terms);

    // Use an Agreements-owned compensation hash based only on the structured
    // compensation terms. Some VMS Core hashes can include adjacent/volatile
    // event-plan meta, which can make a freshly generated packet look stale
    // immediately after generation.
    $comp_hash = vmsa_hash_payload(vmsa_canonicalize_terms_hash_value($comp_terms));

    $template = vmsa_get_template_payload($template_id);
    if (vmsa_template_health_has_errors((array) ($template['health'] ?? array()))) {
        return new WP_Error('vmsa_template_unhealthy', __('Agreement template health check has errors. Fix the template before generating a packet.', 'vms-agreements'));
    }
    $vendor = vmsa_get_vendor_contact_snapshot($vendor_id);
    $identity = vmsa_get_event_plan_vendor_identity($event_plan_id, $vendor_id);
    $vendor['legal_name'] = (string) ($identity['legal_name'] ?? '');
    $vendor['representative_name'] = (string) ($identity['representative_name'] ?? '');
    foreach (array('name', 'legal_name', 'representative_name', 'email', 'phone') as $vendor_field) {
        if (isset($vendor[$vendor_field])) {
            $vendor[$vendor_field] = vmsa_display_text($vendor[$vendor_field]);
        }
    }
    $production = vmsa_get_event_plan_production_terms($event_plan_id);
    $production_schedule = vmsa_get_event_plan_production_schedule($event_plan_id);

    $snapshot = array(
        'snapshot_version' => '1.2.0',
        'created_at' => vmsa_current_datetime_mysql(),
        'created_by' => get_current_user_id(),
        'event_plan' => array(
            'id' => $event_plan_id,
            'title' => vmsa_get_post_title_text($event_plan_id),
            'post_status' => (string) get_post_status($event_plan_id),
            'event_status' => $status,
            'event_status_label' => vmsa_get_event_plan_status_label($status),
            'event_date' => $event_date,
            'start_time' => $start_time,
            'end_time' => $end_time,
            'edit_url' => vmsa_event_plan_edit_url($event_plan_id),
            'modified_gmt' => (string) get_post_field('post_modified_gmt', $event_plan_id),
        ),
        'operator' => array(
            'contracting_entity' => vmsa_get_contracting_entity_name(),
            'standard_final_payment_days' => vmsa_get_standard_final_payment_days(),
        ),
        'venue' => array(
            'id' => $venue_id,
            'name' => $venue_id > 0 ? vmsa_get_post_title_text($venue_id) : '',
        ),
        'vendor' => $vendor,
        'production' => array(
            'stage' => (string) ($production['stage'] ?? ''),
            'house_sound' => (string) ($production['house_sound'] ?? ''),
            'stage_lighting' => (string) ($production['stage_lighting'] ?? ''),
            'sound_engineer' => (string) ($production['sound_engineer'] ?? ''),
        ),
        'production_schedule' => array(
            'arrival_loadin' => (string) ($production_schedule['arrival_loadin'] ?? ''),
            'soundcheck_start' => (string) ($production_schedule['soundcheck_start'] ?? ''),
            'soundcheck_end' => (string) ($production_schedule['soundcheck_end'] ?? ''),
            'vacate_by' => (string) ($production_schedule['vacate_by'] ?? ''),
        ),
        'compensation' => array(
            'terms' => $comp_terms,
            'summary' => vmsa_format_compensation_summary($comp_terms),
            'deposit_summary' => vmsa_format_deposit_summary($comp_terms),
            'payment_summary' => vmsa_format_payment_summary($comp_terms),
            'payment_breakdown' => vmsa_build_payment_breakdown($comp_terms),
            'comp_hash' => $comp_hash,
        ),
        'template' => array(
            'id' => absint($template['id'] ?? 0),
            'title' => vmsa_display_text($template['title'] ?? ''),
            'version' => (string) ($template['version'] ?? ''),
            'body_hash' => vmsa_hash_payload(array(
                'body' => (string) ($template['body'] ?? ''),
                'blocks' => (array) ($template['blocks'] ?? array()),
            )),
            'blocks' => (array) ($template['blocks'] ?? array()),
            'health' => (array) ($template['health'] ?? array()),
            'acknowledgements' => (array) ($template['acknowledgements'] ?? array()),
        ),
    );

    $snapshot = vmsa_clean_snapshot_display_strings($snapshot);
    $snapshot['terms_hash'] = vmsa_build_snapshot_terms_hash($snapshot);

    return $snapshot;
}

function vmsa_find_active_packet(int $event_plan_id, int $vendor_id = 0): int
{
    $meta_query = array(
        array(
            'key' => '_vmsa_event_plan_id',
            'value' => $event_plan_id,
            'compare' => '=',
            'type' => 'NUMERIC',
        ),
        array(
            'key' => '_vmsa_status',
            'value' => vmsa_get_active_packet_statuses(),
            'compare' => 'IN',
        ),
    );

    if ($vendor_id > 0) {
        $meta_query[] = array(
            'key' => '_vmsa_vendor_id',
            'value' => $vendor_id,
            'compare' => '=',
            'type' => 'NUMERIC',
        );
    }

    $ids = get_posts(array(
        'post_type' => VMSA_CPT_PACKET,
        'post_status' => 'private',
        'posts_per_page' => 1,
        'orderby' => 'date',
        'order' => 'DESC',
        'fields' => 'ids',
        'meta_query' => $meta_query,
    ));

    return !empty($ids) ? absint($ids[0]) : 0;
}

function vmsa_generate_packet(int $event_plan_id, int $template_id = 0, bool $supersede_existing = true): int|WP_Error
{
    $snapshot = vmsa_build_event_plan_snapshot($event_plan_id, $template_id);
    if (is_wp_error($snapshot)) {
        return $snapshot;
    }

    $vendor_id = absint($snapshot['vendor']['id'] ?? 0);
    $existing_packet_id = vmsa_find_active_packet($event_plan_id, $vendor_id);

    if ($existing_packet_id > 0 && $supersede_existing) {
        update_post_meta($existing_packet_id, '_vmsa_status', 'superseded');
        update_post_meta($existing_packet_id, '_vmsa_superseded_at', vmsa_current_datetime_mysql());
        update_post_meta($existing_packet_id, '_vmsa_superseded_by_user', get_current_user_id());
    }

    $packet_id = wp_insert_post(array(
        'post_type' => VMSA_CPT_PACKET,
        'post_status' => 'private',
        'post_title' => vmsa_packet_title($event_plan_id, $vendor_id),
    ), true);

    if (is_wp_error($packet_id) || absint($packet_id) <= 0) {
        return is_wp_error($packet_id) ? $packet_id : new WP_Error('vmsa_insert_failed', __('Could not create agreement packet.', 'vms-agreements'));
    }

    $packet_id = absint($packet_id);
    $template = vmsa_get_template_payload($template_id);

    update_post_meta($packet_id, '_vmsa_event_plan_id', $event_plan_id);
    update_post_meta($packet_id, '_vmsa_vendor_id', $vendor_id);
    update_post_meta($packet_id, '_vmsa_template_id', absint($template['id'] ?? 0));
    update_post_meta($packet_id, '_vmsa_template_version', (string) ($template['version'] ?? ''));
    update_post_meta($packet_id, '_vmsa_status', 'generated');
    update_post_meta($packet_id, '_vmsa_snapshot', $snapshot);
    update_post_meta($packet_id, '_vmsa_terms_hash', (string) ($snapshot['terms_hash'] ?? ''));
    update_post_meta($packet_id, '_vmsa_comp_hash', (string) ($snapshot['compensation']['comp_hash'] ?? ''));
    update_post_meta($packet_id, '_vmsa_generated_at', vmsa_current_datetime_mysql());
    update_post_meta($packet_id, '_vmsa_generated_by', get_current_user_id());
    update_post_meta($packet_id, '_vmsa_ack_records', array());
    vmsa_get_or_create_review_token($packet_id);

    update_post_meta($event_plan_id, '_vmsa_latest_packet_id', $packet_id);

    return $packet_id;
}

function vmsa_get_packet_snapshot(int $packet_id): array
{
    $snapshot = get_post_meta($packet_id, '_vmsa_snapshot', true);
    return is_array($snapshot) ? $snapshot : array();
}

function vmsa_packet_current_terms_status(int $packet_id): array
{
    $snapshot = vmsa_get_packet_snapshot($packet_id);
    $event_plan_id = absint($snapshot['event_plan']['id'] ?? get_post_meta($packet_id, '_vmsa_event_plan_id', true));
    if ($event_plan_id <= 0 || get_post_type($event_plan_id) !== 'vms_event_plan') {
        return array('state' => 'missing', 'label' => __('Event Plan missing', 'vms-agreements'));
    }

    $diagnostics = vmsa_packet_terms_diagnostics($packet_id);
    if (!empty($diagnostics['error'])) {
        return array(
            'state' => 'unknown',
            'label' => (string) $diagnostics['error'],
            'diagnostics' => $diagnostics,
        );
    }

    if (!empty($diagnostics['matches_current']) || empty($diagnostics['differences'])) {
        return array(
            'state' => 'current',
            'label' => __('Current', 'vms-agreements'),
            'diagnostics' => $diagnostics,
        );
    }

    return array(
        'state' => 'stale',
        'label' => __('Event Plan terms changed since packet generation', 'vms-agreements'),
        'diagnostics' => $diagnostics,
    );
}

function vmsa_template_tokens(array $snapshot): array
{
    $event = (array) ($snapshot['event_plan'] ?? array());
    $operator = (array) ($snapshot['operator'] ?? array());
    $venue = (array) ($snapshot['venue'] ?? array());
    $vendor = (array) ($snapshot['vendor'] ?? array());
    $comp = (array) ($snapshot['compensation'] ?? array());
    $production_schedule = (array) ($snapshot['production_schedule'] ?? array());

    $time = vmsa_format_time_range((string) ($event['start_time'] ?? ''), (string) ($event['end_time'] ?? ''));

    return array(
        '{event_title}' => vmsa_display_text($event['title'] ?? ''),
        '{event_date}' => vmsa_format_date((string) ($event['event_date'] ?? '')),
        '{event_time}' => $time,
        '{venue_name}' => vmsa_display_text($venue['name'] ?? ''),
        '{contracting_entity}' => vmsa_display_text($operator['contracting_entity'] ?? ''),
        '{standard_final_payment_days}' => (string) absint($operator['standard_final_payment_days'] ?? vmsa_get_standard_final_payment_days()),
        '{vendor_name}' => vmsa_display_text($vendor['name'] ?? ''),
        '{vendor_legal_name}' => vmsa_display_text($vendor['legal_name'] ?? ''),
        '{vendor_representative}' => vmsa_display_text($vendor['representative_name'] ?? ''),
        '{vendor_contracting_party}' => vmsa_vendor_contracting_party_display($vendor),
        '{vendor_email}' => vmsa_display_text($vendor['email'] ?? ''),
        '{vendor_phone}' => vmsa_format_phone_number((string) ($vendor['phone'] ?? '')),
        '{arrival_loadin_time}' => vmsa_format_time((string) ($production_schedule['arrival_loadin'] ?? '')),
        '{soundcheck_start_time}' => vmsa_format_time((string) ($production_schedule['soundcheck_start'] ?? '')),
        '{soundcheck_end_time}' => vmsa_format_time((string) ($production_schedule['soundcheck_end'] ?? '')),
        '{soundcheck_window}' => vmsa_format_time_range((string) ($production_schedule['soundcheck_start'] ?? ''), (string) ($production_schedule['soundcheck_end'] ?? '')),
        '{vacate_by_time}' => trim((string) ($production_schedule['vacate_by'] ?? '')) !== '' ? vmsa_format_time((string) ($production_schedule['vacate_by'] ?? '')) : __('To be communicated by Venue', 'vms-agreements'),
        '{production_stage}' => vmsa_production_responsibility_label((string) ($snapshot['production']['stage'] ?? '')),
        '{production_house_sound}' => vmsa_production_responsibility_label((string) ($snapshot['production']['house_sound'] ?? '')),
        '{production_stage_lighting}' => vmsa_production_responsibility_label((string) ($snapshot['production']['stage_lighting'] ?? '')),
        '{production_sound_engineer}' => vmsa_production_responsibility_label((string) ($snapshot['production']['sound_engineer'] ?? '')),
        '{compensation_summary}' => vmsa_clean_compensation_summary_text((string) ($comp['summary'] ?? '')),
        '{deposit_summary}' => vmsa_display_text($comp['deposit_summary'] ?? ''),
        '{payment_summary}' => vmsa_display_text($comp['payment_summary'] ?? vmsa_format_payment_summary((array) ($comp['terms'] ?? array()))),
        '{comp_hash}' => (string) ($comp['comp_hash'] ?? ''),
        '{terms_hash}' => (string) ($snapshot['terms_hash'] ?? ''),
    );
}

function vmsa_render_template_text(array $snapshot): string
{
    $template = (array) ($snapshot['template'] ?? array());
    if (!empty($template['blocks']) && is_array($template['blocks'])) {
        return vmsa_render_template_blocks_text($snapshot);
    }

    $payload = vmsa_get_template_payload(absint($template['id'] ?? 0));
    if (!empty($payload['blocks']) && is_array($payload['blocks'])) {
        $snapshot['template']['blocks'] = $payload['blocks'];
        return vmsa_render_template_blocks_text($snapshot);
    }

    $body = (string) ($payload['body'] ?? '');
    return vmsa_display_text(strtr($body, vmsa_template_tokens($snapshot)));
}
