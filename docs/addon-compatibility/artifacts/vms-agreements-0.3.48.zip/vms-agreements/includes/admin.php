<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('vmsa_i18n_runtime')) {
    function vmsa_i18n_runtime(string $text): string
    {
        if ($text === '') {
            return '';
        }

        if (doing_action('after_setup_theme') || did_action('after_setup_theme')) {
            return __($text, 'vms-agreements');
        }

        return $text;
    }
}

add_action('admin_menu', 'vmsa_register_admin_menu', 60);
add_action('admin_enqueue_scripts', 'vmsa_admin_enqueue_assets', 60);
add_filter('vms_admin_ui_shell_pages', 'vmsa_register_vms_shell_page');
add_filter('vms_admin_ui_active_cluster', 'vmsa_register_vms_active_cluster', 10, 3);
add_filter('vms_admin_ui_nav_clusters', 'vmsa_register_vms_top_nav');
add_filter('vms_tours_register', 'vmsa_register_guided_tours');
add_filter('vms_register_tours', 'vmsa_register_guided_tours');
add_action('admin_init', 'vmsa_redirect_legacy_admin_page_slug');
add_action('admin_post_vmsa_generate_packet', 'vmsa_handle_generate_packet');
add_action('admin_post_vmsa_void_packet', 'vmsa_handle_void_packet');
add_action('admin_post_vmsa_cleanup_event_plan_packets', 'vmsa_handle_cleanup_event_plan_packets');
add_action('admin_post_vmsa_regenerate_review_token', 'vmsa_handle_regenerate_review_token');
add_action('admin_post_vmsa_email_review_link', 'vmsa_handle_email_review_link');
add_action('admin_post_vmsa_save_template_blocks', 'vmsa_handle_save_template_blocks');
add_action('admin_post_vmsa_repair_template_required_components', 'vmsa_handle_repair_template_required_components');
add_action('admin_post_vmsa_save_email_templates', 'vmsa_handle_save_email_templates');
add_action('admin_post_vmsa_save_agreement_defaults', 'vmsa_handle_save_agreement_defaults');
add_action('admin_post_vmsa_save_event_plan_agreement_setup', 'vmsa_handle_save_event_plan_agreement_setup');

function vmsa_register_admin_menu(): void
{
    add_submenu_page(
        'vms-dashboard',
        __('Agreement Packets', 'vms-agreements'),
        __('Agreements', 'vms-agreements'),
        'manage_options',
        vmsa_admin_page_slug(),
        'vmsa_render_admin_page'
    );
}

/**
 * Make the add-on visible inside VMS's compact admin shell without requiring
 * a core-code menu patch. Older VMS builds simply ignore these filters.
 *
 * @param string[] $shell_pages
 * @return string[]
 */
function vmsa_register_vms_shell_page(array $shell_pages): array
{
    $shell_pages[] = vmsa_admin_page_slug();
    return array_values(array_unique(array_filter($shell_pages)));
}

function vmsa_register_vms_active_cluster(string $cluster, string $page, string $post_type): string
{
    if ($page === vmsa_admin_page_slug() || $page === vmsa_legacy_admin_page_slug()) {
        return 'planning';
    }

    return $cluster;
}

/**
 * Add Agreements to the Planning dropdown in the VMS top navigation.
 *
 * @param array<string,array<string,mixed>> $clusters
 * @return array<string,array<string,mixed>>
 */
function vmsa_register_vms_top_nav(array $clusters): array
{
    if (!isset($clusters['planning']) || !is_array($clusters['planning'])) {
        return $clusters;
    }

    $items = isset($clusters['planning']['items']) && is_array($clusters['planning']['items'])
        ? $clusters['planning']['items']
        : array();

    $agreement_item = array(
        'label' => vmsa_i18n_runtime('Agreements'),
        'url' => vmsa_admin_page_url(),
    );

    $already_present = false;
    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }

        $url = isset($item['url']) ? (string) $item['url'] : '';
        if (
            strpos($url, 'page=' . vmsa_admin_page_slug()) !== false
            || strpos($url, 'page=' . vmsa_legacy_admin_page_slug()) !== false
        ) {
            $already_present = true;
            break;
        }
    }

    if (!$already_present) {
        $inserted = false;
        $new_items = array();

        foreach ($items as $item) {
            $new_items[] = $item;

            if (
                is_array($item)
                && isset($item['url'])
                && strpos((string) $item['url'], 'post_type=vms_event_plan') !== false
            ) {
                $new_items[] = $agreement_item;
                $inserted = true;
            }
        }

        $items = $inserted ? $new_items : array_merge($items, array($agreement_item));
    }

    $clusters['planning']['items'] = array_values($items);
    return $clusters;
}

/**
 * Register a first-pass guided tour for the Agreements admin screen.
 *
 * @param array<int,array<string,mixed>> $tours
 * @return array<int,array<string,mixed>>
 */
function vmsa_register_guided_tours(array $tours): array
{
    foreach ($tours as $tour) {
        if (is_array($tour) && isset($tour['id']) && (string) $tour['id'] === 'vms.agreements.packets') {
            return $tours;
        }
    }

    $tours[] = array(
        'id' => 'vms.agreements.packets',
        'title' => vmsa_i18n_runtime('Agreement Packets'),
        'screen' => 'admin:' . vmsa_admin_page_slug(),
        'version' => '1.0.0',
        'level' => 'beginner',
        'description' => vmsa_i18n_runtime('Understand how agreement packets preserve event, vendor, compensation, deposit, template, and acknowledgement terms before the vendor-facing review flow is enabled.'),
        'audience' => array(
            'capabilities_any' => array('manage_options'),
            'capabilities_all' => array(),
            'roles_any' => array(),
            'roles_all' => array(),
        ),
        'auto_run' => true,
        'priority' => 8,
        'steps' => array(
            array(
                'id' => 'intro',
                'selector' => '[data-vms-tour="agreements.intro"]',
                'title' => vmsa_i18n_runtime('What packets protect'),
                'body' => vmsa_i18n_runtime('A packet is a point-in-time copy of the Event Plan terms. That matters because the agreement must later prove exactly which event, vendor, compensation, deposit, and template terms were shown.'),
                'placement' => 'bottom',
                'guard' => array('type' => 'element_exists'),
            ),
            array(
                'id' => 'generate',
                'selector' => '[data-vms-tour="agreements.generate"]',
                'title' => vmsa_i18n_runtime('Generate from the Event Plan'),
                'body' => vmsa_i18n_runtime('Choose an Event Plan only after its primary vendor and compensation terms are reasonably complete. If a current packet already exists, ordinary generation opens that packet first. Use Regenerate / Supersede only when a fresh vendor acknowledgement should be required.'),
                'placement' => 'bottom',
                'guard' => array('type' => 'element_exists'),
            ),
            array(
                'id' => 'template',
                'selector' => '[data-vms-tour="agreements.template"]',
                'title' => vmsa_i18n_runtime('Template version matters'),
                'body' => vmsa_i18n_runtime('The template is versioned so a future wording change does not rewrite history. Old packets continue pointing to the template version they were created with.'),
                'placement' => 'bottom',
                'guard' => array('type' => 'element_exists'),
            ),
            array(
                'id' => 'queue',
                'selector' => '[data-vms-tour="agreements.queue"]',
                'title' => vmsa_i18n_runtime('Operator agreement queue'),
                'body' => vmsa_i18n_runtime('Use the queue to spot generated, sent, viewed, stale, acknowledged, and historical packets without opening each packet one by one.'),
                'placement' => 'top',
                'guard' => array('type' => 'element_exists'),
            ),
            array(
                'id' => 'recent',
                'selector' => '[data-vms-tour="agreements.recent"]',
                'title' => vmsa_i18n_runtime('Recent packets'),
                'body' => vmsa_i18n_runtime('Use this list to confirm whether a packet is current, stale, superseded, or voided before anyone relies on it. Stale means the Event Plan changed after the snapshot was made.'),
                'placement' => 'top',
                'guard' => array('type' => 'element_exists'),
            ),
            array(
                'id' => 'packet-view',
                'selector' => '[data-vms-tour="agreements.packet-view"]',
                'title' => vmsa_i18n_runtime('Packet viewer'),
                'body' => vmsa_i18n_runtime('This view is the operator proof screen. It should clearly show the captured terms, hashes, and later the acknowledgement records, instead of hiding that evidence in raw metadata.'),
                'placement' => 'top',
                'guard' => array('type' => 'element_exists'),
            ),
            array(
                'id' => 'comp-snapshot',
                'selector' => '[data-vms-tour="agreements.comp-snapshot"]',
                'title' => vmsa_i18n_runtime('Compensation and deposit snapshot'),
                'body' => vmsa_i18n_runtime('This is where base pay, bonus/agent details, and deposit terms are frozen for the packet. The agreement add-on reads these from VMS Core instead of inventing separate contract-only pay fields.'),
                'placement' => 'top',
                'guard' => array('type' => 'element_exists'),
            ),
            array(
                'id' => 'audit',
                'selector' => '[data-vms-tour="agreements.audit"]',
                'title' => vmsa_i18n_runtime('Audit trail'),
                'body' => vmsa_i18n_runtime('The vendor-facing phase will print acknowledgement evidence here: timestamp, signer identity, IP address, browser, template version, terms hash, and compensation hash.'),
                'placement' => 'top',
                'guard' => array('type' => 'element_exists'),
            ),
        ),
    );

    return $tours;
}

function vmsa_redirect_legacy_admin_page_slug(): void
{
    if (!is_admin()) {
        return;
    }

    $page = isset($_GET['page']) ? sanitize_key((string) $_GET['page']) : '';
    if ($page !== vmsa_legacy_admin_page_slug()) {
        return;
    }

    if (!vmsa_can_manage()) {
        return;
    }

    $args = array();
    if (isset($_GET['packet_id'])) {
        $args['packet_id'] = absint($_GET['packet_id']);
    }
    if (isset($_GET['vmsa_notice'])) {
        $args['vmsa_notice'] = sanitize_key((string) $_GET['vmsa_notice']);
    }

    wp_safe_redirect(vmsa_admin_page_url($args));
    exit;
}

function vmsa_admin_enqueue_assets(string $hook): void
{
    $page = isset($_GET['page']) ? sanitize_key((string) $_GET['page']) : '';
    $is_packet_page = in_array($page, array(vmsa_admin_page_slug(), vmsa_legacy_admin_page_slug()), true);
    $is_event_plan_editor = in_array($hook, array('post.php', 'post-new.php'), true)
        && isset($_GET['post'])
        && get_post_type(absint($_GET['post'])) === 'vms_event_plan';

    if (!$is_packet_page && !$is_event_plan_editor) {
        return;
    }

    wp_enqueue_style(
        'vmsa-admin',
        VMSA_PLUGIN_URL . 'assets/admin.css',
        array(),
        VMSA_VERSION
    );
}

function vmsa_handle_generate_packet(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to generate agreement packets.', 'vms-agreements'));
    }

    check_admin_referer('vmsa_generate_packet');

    if (!vmsa_core_version_ok()) {
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => 'dependency')));
        exit;
    }

    $event_plan_id = isset($_REQUEST['event_plan_id']) ? absint($_REQUEST['event_plan_id']) : 0;
    if ($event_plan_id <= 0 || get_post_type($event_plan_id) !== 'vms_event_plan') {
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => 'missing_event_plan')));
        exit;
    }

    $block_reason = vmsa_event_plan_generation_block_reason($event_plan_id);
    if ($block_reason !== '') {
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => $block_reason)));
        exit;
    }

    $vendor_id = vmsa_get_primary_vendor_id($event_plan_id);
    $existing_packet_id = $vendor_id > 0 ? vmsa_find_active_packet($event_plan_id, $vendor_id) : 0;
    $confirmed_regenerate = !empty($_REQUEST['vmsa_confirm_regenerate']);

    if ($existing_packet_id > 0 && !$confirmed_regenerate) {
        wp_safe_redirect(vmsa_admin_page_url(array(
            'packet_id' => $existing_packet_id,
            'vmsa_notice' => 'regenerate_required',
        )));
        exit;
    }

    $result = vmsa_generate_packet($event_plan_id);
    if (is_wp_error($result)) {
        $code = $result->get_error_code();
        $notice_map = array(
            'vmsa_missing_vendor' => 'missing_vendor',
            'vmsa_missing_contracting_entity' => 'missing_contracting_entity',
            'vmsa_missing_vendor_legal_name' => 'missing_vendor_legal_name',
            'vmsa_missing_vendor_representative' => 'missing_vendor_representative',
            'vmsa_payment_method_incomplete' => 'payment_method_incomplete',
            'vmsa_production_terms_incomplete' => 'production_terms_incomplete',
            'vmsa_production_schedule_incomplete' => 'production_schedule_incomplete',
            'vmsa_event_not_eligible' => 'event_not_eligible',
            'vmsa_template_unhealthy' => 'template_unhealthy',
        );
        $notice = (string) ($notice_map[$code] ?? 'failed');
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => $notice)));
        exit;
    }

    wp_safe_redirect(vmsa_admin_page_url(array(
        'packet_id' => absint($result),
        'vmsa_notice' => $existing_packet_id > 0 ? 'packet_regenerated' : 'packet_generated',
    )));
    exit;
}


function vmsa_handle_void_packet(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to void agreement packets.', 'vms-agreements'));
    }

    check_admin_referer('vmsa_void_packet');

    $packet_id = isset($_POST['packet_id']) ? absint($_POST['packet_id']) : 0;
    if ($packet_id <= 0 || get_post_type($packet_id) !== VMSA_CPT_PACKET) {
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => 'failed')));
        exit;
    }

    update_post_meta($packet_id, '_vmsa_status', 'voided');
    update_post_meta($packet_id, '_vmsa_voided_at', vmsa_current_datetime_mysql());
    update_post_meta($packet_id, '_vmsa_voided_by', get_current_user_id());

    wp_safe_redirect(vmsa_admin_page_url(array(
        'packet_id' => $packet_id,
        'vmsa_notice' => 'packet_voided',
    )));
    exit;
}

function vmsa_get_event_plan_packet_ids(int $event_plan_id): array
{
    if ($event_plan_id <= 0) {
        return array();
    }

    $ids = get_posts(array(
        'post_type' => VMSA_CPT_PACKET,
        'post_status' => 'any',
        'posts_per_page' => -1,
        'fields' => 'ids',
        'orderby' => 'date',
        'order' => 'DESC',
        'meta_query' => array(
            array(
                'key' => '_vmsa_event_plan_id',
                'value' => $event_plan_id,
                'compare' => '=',
                'type' => 'NUMERIC',
            ),
        ),
    ));

    return array_values(array_filter(array_map('absint', $ids)));
}

function vmsa_packet_has_acknowledgement_history(int $packet_id, string $status = ''): bool
{
    $status = $status !== '' ? sanitize_key($status) : sanitize_key((string) get_post_meta($packet_id, '_vmsa_status', true));
    if ($status === 'acknowledged') {
        return true;
    }

    $acknowledged_at = (string) get_post_meta($packet_id, '_vmsa_acknowledged_at', true);
    if ($acknowledged_at !== '') {
        return true;
    }

    $records = vmsa_get_ack_records($packet_id);
    return !empty($records);
}

function vmsa_cleanup_scope_matches_packet(string $scope, int $packet_id, string $status): bool
{
    $status = sanitize_key($status);
    if ($scope === 'unacknowledged') {
        return in_array($status, array('generated', 'sent', 'viewed', 'superseded', 'voided'), true);
    }

    if (in_array($status, array('superseded', 'voided'), true)) {
        return true;
    }

    if (in_array($status, vmsa_get_active_packet_statuses(), true)) {
        $terms_status = vmsa_packet_current_terms_status($packet_id);
        return (string) ($terms_status['state'] ?? '') === 'stale';
    }

    return false;
}

function vmsa_get_latest_packet_id_for_event_plan(int $event_plan_id): int
{
    if ($event_plan_id <= 0) {
        return 0;
    }

    $ids = get_posts(array(
        'post_type' => VMSA_CPT_PACKET,
        'post_status' => 'any',
        'posts_per_page' => 1,
        'fields' => 'ids',
        'orderby' => 'date',
        'order' => 'DESC',
        'meta_query' => array(
            array(
                'key' => '_vmsa_event_plan_id',
                'value' => $event_plan_id,
                'compare' => '=',
                'type' => 'NUMERIC',
            ),
        ),
    ));

    return !empty($ids) ? absint($ids[0]) : 0;
}

function vmsa_refresh_event_plan_latest_packet_id(int $event_plan_id): int
{
    if ($event_plan_id <= 0) {
        return 0;
    }

    $active_packet_id = vmsa_find_active_packet($event_plan_id);
    $latest_packet_id = $active_packet_id > 0 ? $active_packet_id : vmsa_get_latest_packet_id_for_event_plan($event_plan_id);

    if ($latest_packet_id > 0) {
        update_post_meta($event_plan_id, '_vmsa_latest_packet_id', $latest_packet_id);
    } else {
        delete_post_meta($event_plan_id, '_vmsa_latest_packet_id');
    }

    return $latest_packet_id;
}

function vmsa_invalidate_packet_cleanup_caches(int $event_plan_id, array $deleted_packet_ids, array $vendor_ids): void
{
    foreach ($deleted_packet_ids as $packet_id) {
        clean_post_cache(absint($packet_id));
    }

    foreach ($vendor_ids as $vendor_id) {
        clean_post_cache(absint($vendor_id));
    }

    if ($event_plan_id > 0) {
        clean_post_cache($event_plan_id);
    }

    /**
     * Allow site-specific code to invalidate any additional packet or vendor
     * portal cache layers after admin cleanup deletes test packets.
     *
     * @param int   $event_plan_id
     * @param int[] $deleted_packet_ids
     * @param int[] $vendor_ids
     */
    do_action('vmsa_after_packet_cleanup', $event_plan_id, $deleted_packet_ids, $vendor_ids);
}

function vmsa_handle_cleanup_event_plan_packets(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to delete agreement packets.', 'vms-agreements'));
    }

    check_admin_referer('vmsa_cleanup_event_plan_packets');

    $event_plan_id = isset($_POST['event_plan_id']) ? absint($_POST['event_plan_id']) : 0;
    $origin_packet_id = isset($_POST['packet_id']) ? absint($_POST['packet_id']) : 0;
    $scope = isset($_POST['cleanup_scope']) ? sanitize_key((string) wp_unslash($_POST['cleanup_scope'])) : '';
    $confirmed = isset($_POST['vmsa_confirm_cleanup']) ? sanitize_key((string) wp_unslash($_POST['vmsa_confirm_cleanup'])) : '';

    $redirect_args = array();
    if ($origin_packet_id > 0 && get_post_type($origin_packet_id) === VMSA_CPT_PACKET) {
        $redirect_args['packet_id'] = $origin_packet_id;
    }

    if ($event_plan_id <= 0 || get_post_type($event_plan_id) !== 'vms_event_plan' || !in_array($scope, array('unacknowledged', 'history'), true)) {
        wp_safe_redirect(vmsa_admin_page_url(array_merge($redirect_args, array('vmsa_notice' => 'failed'))));
        exit;
    }

    if ($confirmed !== '1') {
        wp_safe_redirect(vmsa_admin_page_url(array_merge($redirect_args, array('vmsa_notice' => 'cleanup_confirmation_required'))));
        exit;
    }

    $deleted = 0;
    $skipped = 0;
    $deleted_packet_ids = array();
    $vendor_ids = array();

    foreach (vmsa_get_event_plan_packet_ids($event_plan_id) as $packet_id) {
        if ($packet_id <= 0 || get_post_type($packet_id) !== VMSA_CPT_PACKET) {
            continue;
        }

        $status = sanitize_key((string) get_post_meta($packet_id, '_vmsa_status', true));
        if (vmsa_packet_has_acknowledgement_history($packet_id, $status)) {
            $skipped++;
            continue;
        }

        if (!vmsa_cleanup_scope_matches_packet($scope, $packet_id, $status)) {
            continue;
        }

        $vendor_ids[] = absint(get_post_meta($packet_id, '_vmsa_vendor_id', true));
        $result = wp_delete_post($packet_id, true);
        if ($result instanceof WP_Post) {
            $deleted++;
            $deleted_packet_ids[] = $packet_id;
        }
    }

    $vendor_ids = array_values(array_unique(array_filter(array_map('absint', $vendor_ids))));
    $latest_packet_id = vmsa_refresh_event_plan_latest_packet_id($event_plan_id);
    vmsa_invalidate_packet_cleanup_caches($event_plan_id, $deleted_packet_ids, $vendor_ids);

    $redirect_packet_id = 0;
    if ($origin_packet_id > 0 && get_post_type($origin_packet_id) === VMSA_CPT_PACKET) {
        $redirect_packet_id = $origin_packet_id;
    } elseif ($latest_packet_id > 0 && get_post_type($latest_packet_id) === VMSA_CPT_PACKET) {
        $redirect_packet_id = $latest_packet_id;
    }

    $notice = $deleted > 0 ? 'cleanup_packets_deleted' : 'cleanup_packets_none';
    $args = array(
        'vmsa_notice' => $notice,
        'vmsa_cleanup_scope' => $scope,
        'vmsa_deleted' => $deleted,
        'vmsa_skipped' => $skipped,
    );
    if ($redirect_packet_id > 0) {
        $args['packet_id'] = $redirect_packet_id;
    }

    wp_safe_redirect(vmsa_admin_page_url($args));
    exit;
}

function vmsa_handle_regenerate_review_token(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__("You do not have permission to manage agreement packets.", "vms-agreements"));
    }

    check_admin_referer("vmsa_regenerate_review_token");

    $packet_id = isset($_GET["packet_id"]) ? absint($_GET["packet_id"]) : 0;
    if ($packet_id <= 0 || get_post_type($packet_id) !== VMSA_CPT_PACKET) {
        wp_safe_redirect(vmsa_admin_page_url(array("vmsa_notice" => "failed")));
        exit;
    }

    vmsa_get_or_create_review_token($packet_id, true);

    wp_safe_redirect(vmsa_admin_page_url(array(
        "packet_id" => $packet_id,
        "vmsa_notice" => "review_token_regenerated",
    )));
    exit;
}

function vmsa_handle_email_review_link(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to email agreement packets.', 'vms-agreements'));
    }

    check_admin_referer('vmsa_email_review_link');

    $packet_id = isset($_POST['packet_id']) ? absint($_POST['packet_id']) : 0;
    if ($packet_id <= 0 || get_post_type($packet_id) !== VMSA_CPT_PACKET) {
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => 'failed')));
        exit;
    }

    $status = (string) get_post_meta($packet_id, '_vmsa_status', true);
    if (in_array($status, array('voided', 'superseded', 'acknowledged'), true)) {
        wp_safe_redirect(vmsa_admin_page_url(array(
            'packet_id' => $packet_id,
            'vmsa_notice' => 'cannot_email_packet',
        )));
        exit;
    }

    $terms_status = vmsa_packet_current_terms_status($packet_id);
    if (($terms_status['state'] ?? '') !== 'current') {
        wp_safe_redirect(vmsa_admin_page_url(array(
            'packet_id' => $packet_id,
            'vmsa_notice' => 'stale_packet_email_blocked',
        )));
        exit;
    }

    $snapshot = vmsa_get_packet_snapshot($packet_id);
    $template_id = absint($snapshot['template']['id'] ?? get_post_meta($packet_id, '_vmsa_template_id', true));
    $email_templates = vmsa_get_email_template_payload($template_id);
    if (vmsa_email_template_health_has_errors((array) ($email_templates['health'] ?? array()))) {
        wp_safe_redirect(vmsa_admin_page_url(array(
            'packet_id' => $packet_id,
            'vmsa_notice' => 'email_template_unhealthy',
        )));
        exit;
    }

    $vendor = (array) ($snapshot['vendor'] ?? array());
    $to = sanitize_email((string) ($vendor['email'] ?? ''));
    if ($to === '') {
        wp_safe_redirect(vmsa_admin_page_url(array(
            'packet_id' => $packet_id,
            'vmsa_notice' => 'missing_vendor_email',
        )));
        exit;
    }

    $token = vmsa_get_or_create_review_token($packet_id);
    $review_url = vmsa_packet_review_url($packet_id, $token);
    $operator_note = isset($_POST['operator_note']) ? sanitize_textarea_field(wp_unslash((string) $_POST['operator_note'])) : '';
    $email = vmsa_build_review_email($packet_id, $snapshot, $review_url, $operator_note);

    $mail_result = vmsa_send_mail_with_diagnostics(
        'review_link_email',
        $to,
        (string) $email['subject'],
        (string) $email['body'],
        array(
            'Content-Type: text/plain; charset=UTF-8',
            'X-VMSA-Email-Type: review_link_email',
            'X-VMSA-Packet-ID: ' . $packet_id,
        )
    );
    $sent = !empty($mail_result['sent']);

    $now = vmsa_current_datetime_mysql();
    $records = vmsa_get_email_records($packet_id);
    $records[] = array(
        'id' => wp_generate_uuid4(),
        'type' => 'review_link_email',
        'sent' => (bool) $sent,
        'sent_at' => $now,
        'sent_at_gmt' => current_time('mysql', true),
        'sent_by' => get_current_user_id(),
        'to' => $to,
        'subject' => (string) $email['subject'],
        'review_token_hash' => (string) get_post_meta($packet_id, '_vmsa_review_token_hash', true),
        'status_before' => $status,
        'operator_note' => $operator_note,
        'wp_mail_return' => !empty($mail_result['wp_mail_return']),
        'wp_mail_succeeded_action' => !empty($mail_result['wp_mail_succeeded_action']),
        'pre_wp_mail_short_circuit' => !empty($mail_result['pre_wp_mail_short_circuit']),
        'pre_wp_mail_return_type' => (string) ($mail_result['pre_wp_mail_return_type'] ?? ''),
        'wp_mail_failed' => !empty($mail_result['wp_mail_failed']),
        'wp_mail_failed_code' => (string) ($mail_result['wp_mail_failed_code'] ?? ''),
        'error' => $sent ? '' : (string) ($mail_result['error'] ?? __('wp_mail returned false.', 'vms-agreements')),
    );
    update_post_meta($packet_id, '_vmsa_email_records', $records);

    if ($sent) {
        update_post_meta($packet_id, '_vmsa_review_email_sent_at', $now);
        update_post_meta($packet_id, '_vmsa_review_email_sent_to', $to);
        update_post_meta($packet_id, '_vmsa_review_email_sent_by', get_current_user_id());
        update_post_meta($packet_id, '_vmsa_review_email_send_count', absint(get_post_meta($packet_id, '_vmsa_review_email_send_count', true)) + 1);
        delete_post_meta($packet_id, '_vmsa_review_email_last_error');

        if ($status === 'generated') {
            update_post_meta($packet_id, '_vmsa_status', 'sent');
        }

        wp_safe_redirect(vmsa_admin_page_url(array(
            'packet_id' => $packet_id,
            'vmsa_notice' => 'review_email_sent',
        )));
        exit;
    }

    update_post_meta($packet_id, '_vmsa_review_email_last_error', (string) ($mail_result['error'] ?? __('wp_mail returned false.', 'vms-agreements')));

    wp_safe_redirect(vmsa_admin_page_url(array(
        'packet_id' => $packet_id,
        'vmsa_notice' => 'review_email_failed',
    )));
    exit;
}

function vmsa_handle_save_event_plan_agreement_setup(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to edit agreement setup.', 'vms-agreements'));
    }

    check_admin_referer('vmsa_save_event_plan_agreement_setup');

    $event_plan_id = isset($_POST['event_plan_id']) ? absint($_POST['event_plan_id']) : 0;
    if ($event_plan_id <= 0 || get_post_type($event_plan_id) !== 'vms_event_plan' || !current_user_can('edit_post', $event_plan_id)) {
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => 'missing_event_plan')));
        exit;
    }

    $result = vmsa_update_event_plan_agreement_setup($event_plan_id, array(
        'vendor_legal_name' => isset($_POST['vmsa_vendor_legal_name']) ? wp_unslash((string) $_POST['vmsa_vendor_legal_name']) : '',
        'vendor_representative_name' => isset($_POST['vmsa_vendor_representative_name']) ? wp_unslash((string) $_POST['vmsa_vendor_representative_name']) : '',
        'payment_method' => isset($_POST['vmsa_payment_method']) ? wp_unslash((string) $_POST['vmsa_payment_method']) : '',
        'payment_method_other' => isset($_POST['vmsa_payment_method_other']) ? wp_unslash((string) $_POST['vmsa_payment_method_other']) : '',
        'production_stage' => isset($_POST['vmsa_production_stage']) ? wp_unslash((string) $_POST['vmsa_production_stage']) : '',
        'production_house_sound' => isset($_POST['vmsa_production_house_sound']) ? wp_unslash((string) $_POST['vmsa_production_house_sound']) : '',
        'production_stage_lighting' => isset($_POST['vmsa_production_stage_lighting']) ? wp_unslash((string) $_POST['vmsa_production_stage_lighting']) : '',
        'production_sound_engineer' => isset($_POST['vmsa_production_sound_engineer']) ? wp_unslash((string) $_POST['vmsa_production_sound_engineer']) : '',
        'production_confirmed' => !empty($_POST['vmsa_production_confirmed']),
        'arrival_loadin' => isset($_POST['vmsa_arrival_loadin']) ? wp_unslash((string) $_POST['vmsa_arrival_loadin']) : '',
        'soundcheck_start' => isset($_POST['vmsa_soundcheck_start']) ? wp_unslash((string) $_POST['vmsa_soundcheck_start']) : '',
        'soundcheck_end' => isset($_POST['vmsa_soundcheck_end']) ? wp_unslash((string) $_POST['vmsa_soundcheck_end']) : '',
        'vacate_by' => isset($_POST['vmsa_vacate_by']) ? wp_unslash((string) $_POST['vmsa_vacate_by']) : '',
    ));

    $notice = !empty($result['complete']) ? 'agreement_setup_saved' : 'agreement_setup_incomplete';
    $after_save = isset($_POST['vmsa_after_save']) ? sanitize_key((string) wp_unslash($_POST['vmsa_after_save'])) : 'stay';

    if ($after_save === 'view_packet') {
        $vendor_id = vmsa_get_primary_vendor_id($event_plan_id);
        $packet_id = $vendor_id > 0 ? vmsa_find_active_packet($event_plan_id, $vendor_id) : 0;
        if ($packet_id <= 0) {
            $packet_id = absint(get_post_meta($event_plan_id, '_vmsa_latest_packet_id', true));
        }
        if ($packet_id > 0 && get_post_type($packet_id) === VMSA_CPT_PACKET) {
            wp_safe_redirect(vmsa_admin_page_url(array('packet_id' => $packet_id, 'vmsa_notice' => $notice)));
            exit;
        }
    }

    if ($after_save === 'generate') {
        $block_reason = vmsa_event_plan_generation_block_reason($event_plan_id);
        if ($block_reason !== '') {
            wp_safe_redirect(vmsa_agreement_setup_url($event_plan_id, array('vmsa_notice' => $block_reason)));
            exit;
        }

        $vendor_id = vmsa_get_primary_vendor_id($event_plan_id);
        $existing_packet_id = $vendor_id > 0 ? vmsa_find_active_packet($event_plan_id, $vendor_id) : 0;
        $packet_result = vmsa_generate_packet($event_plan_id);
        if (is_wp_error($packet_result)) {
            $code = $packet_result->get_error_code();
            $notice_map = array(
                'vmsa_missing_vendor' => 'missing_vendor',
                'vmsa_missing_contracting_entity' => 'missing_contracting_entity',
                'vmsa_missing_vendor_legal_name' => 'missing_vendor_legal_name',
                'vmsa_missing_vendor_representative' => 'missing_vendor_representative',
                'vmsa_payment_method_incomplete' => 'payment_method_incomplete',
                'vmsa_production_terms_incomplete' => 'production_terms_incomplete',
                'vmsa_production_schedule_incomplete' => 'production_schedule_incomplete',
                'vmsa_event_not_eligible' => 'event_not_eligible',
                'vmsa_template_unhealthy' => 'template_unhealthy',
            );
            $generation_notice = (string) ($notice_map[$code] ?? 'failed');
            wp_safe_redirect(vmsa_agreement_setup_url($event_plan_id, array('vmsa_notice' => $generation_notice)));
            exit;
        }

        wp_safe_redirect(vmsa_admin_page_url(array(
            'packet_id' => absint($packet_result),
            'vmsa_notice' => $existing_packet_id > 0 ? 'packet_regenerated' : 'packet_generated',
        )));
        exit;
    }

    wp_safe_redirect(vmsa_agreement_setup_url($event_plan_id, array('vmsa_notice' => $notice)));
    exit;
}

function vmsa_handle_save_agreement_defaults(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to edit agreement defaults.', 'vms-agreements'));
    }

    check_admin_referer('vmsa_save_agreement_defaults');

    $entity = isset($_POST['vmsa_contracting_entity_name'])
        ? sanitize_text_field(wp_unslash((string) $_POST['vmsa_contracting_entity_name']))
        : '';
    $days = isset($_POST['vmsa_standard_final_payment_days'])
        ? absint($_POST['vmsa_standard_final_payment_days'])
        : 5;
    $days = max(1, min(90, $days));

    update_option('vmsa_contracting_entity_name', $entity, false);
    update_option('vmsa_standard_final_payment_days', $days, false);

    wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => 'agreement_defaults_saved')));
    exit;
}

function vmsa_render_agreement_defaults_form(): void
{
    $entity = vmsa_get_contracting_entity_name();
    $days = vmsa_get_standard_final_payment_days();

    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('vmsa_save_agreement_defaults');
    echo '<input type="hidden" name="action" value="vmsa_save_agreement_defaults">';
    echo '<label for="vmsa-contracting-entity"><strong>' . esc_html__('Legal contracting party', 'vms-agreements') . '</strong></label>';
    echo '<input id="vmsa-contracting-entity" class="vmsa-full" type="text" name="vmsa_contracting_entity_name" value="' . esc_attr($entity) . '" placeholder="' . esc_attr__('Example: Company LLC d/b/a Venue Name', 'vms-agreements') . '" required>';
    echo '<p class="description">' . esc_html__('Snapshotted into each new packet so the legal contracting party is distinct from the venue display name.', 'vms-agreements') . '</p>';

    echo '<label for="vmsa-final-payment-days"><strong>' . esc_html__('Standard final-payment fallback', 'vms-agreements') . '</strong></label>';
    echo '<div><input id="vmsa-final-payment-days" type="number" min="1" max="90" name="vmsa_standard_final_payment_days" value="' . esc_attr((string) $days) . '" required> ' . esc_html__('calendar days after the performance', 'vms-agreements') . '</div>';
    echo '<p class="description">' . esc_html__('Used only when the Event Plan does not already contain explicit VMS Core final-payment timing. Event-specific terms still win.', 'vms-agreements') . '</p>';

    submit_button(__('Save Agreement Defaults', 'vms-agreements'), 'secondary', 'submit', false);
    echo '</form>';
}

function vmsa_render_admin_page(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to view agreement packets.', 'vms-agreements'));
    }

    $render_content = static function (): void {
        echo '<p class="vmsa-intro" data-vms-tour="agreements.intro">' . esc_html__('Agreement packets are generated from Event Plans and preserve the exact event, vendor, compensation, deposit, template, and acknowledgement terms that will later be presented to the vendor.', 'vms-agreements') . '</p>';

        vmsa_notice_from_query();

        if (isset($_GET['vmsa_email_template'])) {
            vmsa_render_email_template_editor(absint($_GET['vmsa_email_template']));
            return;
        }

        if (isset($_GET['vmsa_template'])) {
            vmsa_render_template_editor(absint($_GET['vmsa_template']));
            return;
        }

        $setup_event_plan_id = isset($_GET['vmsa_setup_event_plan']) ? absint($_GET['vmsa_setup_event_plan']) : 0;
        if ($setup_event_plan_id > 0) {
            vmsa_render_agreement_setup_view($setup_event_plan_id);
            return;
        }

        if (!vmsa_core_version_ok()) {
            echo '<div class="notice notice-error inline"><p>' . esc_html__('Packet generation is disabled until VMS Core 0.2.24.570 or newer is active.', 'vms-agreements') . '</p></div>';
        }

        $packet_id = isset($_GET['packet_id']) ? absint($_GET['packet_id']) : 0;
        if ($packet_id > 0 && get_post_type($packet_id) === VMSA_CPT_PACKET) {
            vmsa_render_packet_view($packet_id);
        }

        echo '<div class="vmsa-grid">';
        echo '<section class="vmsa-card" data-vms-tour="agreements.generate">';
        echo '<h2>' . esc_html__('Generate Packet', 'vms-agreements') . '</h2>';
        vmsa_render_generate_form();
        echo '</section>';

        echo '<section class="vmsa-card" data-vms-tour="agreements.template">';
        echo '<h2>' . esc_html__('Default Template', 'vms-agreements') . '</h2>';
        vmsa_render_template_summary();
        echo '</section>';

        echo '<section class="vmsa-card" id="vmsa-agreement-defaults">';
        echo '<h2>' . esc_html__('Agreement Defaults', 'vms-agreements') . '</h2>';
        vmsa_render_agreement_defaults_form();
        echo '</section>';
        echo '</div>';

        echo '<section class="vmsa-card vmsa-card-wide" data-vms-tour="agreements.queue">';
        echo '<h2>' . esc_html__('Operator Agreement Queue', 'vms-agreements') . '</h2>';
        vmsa_render_operator_queue();
        echo '</section>';

        echo '<section class="vmsa-card vmsa-card-wide" data-vms-tour="agreements.recent">';
        echo '<h2>' . esc_html__('Recent Packets', 'vms-agreements') . '</h2>';
        vmsa_render_packets_table();
        echo '</section>';
    };

    $shell_renderer = vmsa_core_function_name('vms_admin_ui_render_shell');
    if ($shell_renderer !== '') {
        $shell_renderer(
            array(
                'title' => __('VMS Agreement Packets', 'vms-agreements'),
                'subtitle' => __('Generate and review versioned agreement packets from Event Plans.', 'vms-agreements'),
                'shell_id' => 'vmsa-agreements-shell',
                'content_class' => 'vmsa-wrap',
            ),
            $render_content
        );
        return;
    }

    echo '<div class="wrap vmsa-wrap">';
    echo '<h1>' . esc_html__('VMS Agreement Packets', 'vms-agreements') . '</h1>';
    $render_content();
    echo '</div>';
}
function vmsa_render_generate_form(): void
{
    $plans = get_posts(array(
        'post_type' => 'vms_event_plan',
        'post_status' => array('publish', 'draft', 'pending', 'future', 'private'),
        'posts_per_page' => 75,
        'orderby' => 'modified',
        'order' => 'DESC',
        'fields' => 'ids',
    ));

    $candidate_plans = array();
    foreach ($plans as $plan_id) {
        $plan_id = absint($plan_id);
        if ($plan_id <= 0 || vmsa_event_plan_is_cancelled($plan_id) || vmsa_event_plan_is_past($plan_id)) {
            continue;
        }
        if (vmsa_get_primary_vendor_id($plan_id) <= 0) {
            continue;
        }
        $candidate_plans[] = $plan_id;
    }

    if (vmsa_get_contracting_entity_name() === '') {
        echo '<div class="notice notice-warning inline"><p>' . esc_html__('Agreement Defaults still need the legal contracting party before a packet can be generated. You can prepare event-specific Agreement Setup now.', 'vms-agreements') . '</p></div>';
    }

    echo '<form method="get" action="' . esc_url(admin_url('admin.php')) . '">';
    echo '<input type="hidden" name="page" value="' . esc_attr(vmsa_admin_page_slug()) . '">';
    echo '<label for="vmsa-event-plan-id"><strong>' . esc_html__('Event Plan', 'vms-agreements') . '</strong></label>';

    $select_attrs = empty($candidate_plans) ? ' disabled' : '';
    echo '<select id="vmsa-event-plan-id" name="vmsa_setup_event_plan" class="vmsa-full" required' . $select_attrs . '>';
    echo '<option value="">' . esc_html__('Choose an upcoming Event Plan with a primary vendor', 'vms-agreements') . '</option>';

    foreach ($candidate_plans as $plan_id) {
        $date = vmsa_get_event_plan_date($plan_id);
        $vendor_id = vmsa_get_primary_vendor_id($plan_id);
        $vendor = $vendor_id > 0 ? vmsa_display_text(get_the_title($vendor_id)) : '';
        $title = vmsa_display_text(get_the_title($plan_id));
        $setup_ready = in_array(vmsa_event_plan_generation_block_reason($plan_id), array('', 'missing_contracting_entity'), true);
        $label_parts = array($title, vmsa_format_date($date));
        if ($vendor !== '' && vmsa_normalize_title_key($vendor) !== vmsa_normalize_title_key($title)) {
            $label_parts[] = $vendor;
        }
        $label_parts[] = $setup_ready ? __('Agreement setup ready', 'vms-agreements') : __('Agreement setup required', 'vms-agreements');
        echo '<option value="' . esc_attr((string) $plan_id) . '">' . esc_html(implode(' - ', array_filter($label_parts))) . '</option>';
    }

    echo '</select>';

    if (empty($candidate_plans)) {
        echo '<p class="description">' . esc_html__('No upcoming, non-cancelled Event Plans with a primary vendor are available.', 'vms-agreements') . '</p>';
    } else {
        echo '<p class="description">' . esc_html__('Open Agreement Setup to confirm the legal Vendor party, final payment method, and booking-specific production responsibilities before generating or superseding a packet.', 'vms-agreements') . '</p>';
    }

    $button_attrs = (vmsa_core_version_ok() && !empty($candidate_plans)) ? array() : array('disabled' => 'disabled');
    submit_button(__('Open Agreement Setup', 'vms-agreements'), 'primary', 'submit', false, $button_attrs);
    echo '</form>';
}

function vmsa_render_agreement_setup_view(int $event_plan_id): void
{
    $event_plan_id = absint($event_plan_id);
    if ($event_plan_id <= 0 || get_post_type($event_plan_id) !== 'vms_event_plan') {
        echo '<div class="notice notice-error inline"><p>' . esc_html__('This Event Plan could not be opened for Agreement Setup.', 'vms-agreements') . '</p></div>';
        return;
    }

    $vendor_id = vmsa_get_primary_vendor_id($event_plan_id);
    $event_title = vmsa_get_post_title_text($event_plan_id);
    $event_date = vmsa_get_event_plan_date($event_plan_id);
    $vendor_name = $vendor_id > 0 ? vmsa_get_post_title_text($vendor_id) : '';

    echo '<section class="vmsa-card vmsa-card-wide vmsa-agreement-setup">';
    echo '<div class="vmsa-card-header">';
    echo '<div><h2>' . esc_html__('Agreement Setup', 'vms-agreements') . '</h2>';
    echo '<p class="description">' . esc_html__('Confirm agreement-specific identity, final payment method, production responsibilities, and production schedule here. Saving this form does not alter an existing packet; regenerate/supersede only when you are ready to create a new agreement snapshot.', 'vms-agreements') . '</p></div>';
    echo '<a class="button button-secondary" href="' . esc_url(vmsa_event_plan_edit_url($event_plan_id)) . '">' . esc_html__('Back to Event Plan', 'vms-agreements') . '</a>';
    echo '</div>';

    echo '<dl class="vmsa-definition-list vmsa-setup-event-summary">';
    echo '<dt>' . esc_html__('Event', 'vms-agreements') . '</dt><dd>' . esc_html($event_title) . '</dd>';
    echo '<dt>' . esc_html__('Date', 'vms-agreements') . '</dt><dd>' . esc_html(vmsa_format_date($event_date)) . '</dd>';
    echo '<dt>' . esc_html__('Primary vendor / act', 'vms-agreements') . '</dt><dd>' . esc_html($vendor_name !== '' ? $vendor_name : __('Not assigned', 'vms-agreements')) . '</dd>';
    echo '<dt>' . esc_html__('Venue contracting party', 'vms-agreements') . '</dt><dd>' . esc_html(vmsa_get_contracting_entity_name() !== '' ? vmsa_get_contracting_entity_name() : __('Not set in Agreement Defaults', 'vms-agreements')) . '</dd>';
    echo '</dl>';

    if ($vendor_id <= 0) {
        echo '<div class="vmsa-guardrail"><p class="vmsa-warning-text">' . esc_html__('Assign a primary vendor on the Event Plan before completing Agreement Setup.', 'vms-agreements') . '</p></div>';
        echo '</section>';
        return;
    }

    $identity = vmsa_get_event_plan_vendor_identity($event_plan_id, $vendor_id);
    $payment_method = vmsa_get_event_plan_payment_method($event_plan_id);
    $production = vmsa_get_event_plan_production_terms($event_plan_id);
    $production_schedule = vmsa_get_event_plan_production_schedule($event_plan_id);

    $comp_terms_function = vmsa_core_function_name('vms_get_event_plan_comp_terms');
    $payment_terms = $comp_terms_function !== ''
        ? (array) $comp_terms_function($event_plan_id)
        : array();
    $payment_terms = vmsa_apply_agreement_payment_defaults($payment_terms);
    $payment_timing_label = vmsa_final_payment_timing_label($payment_terms);

    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="vmsa-agreement-setup-form">';
    wp_nonce_field('vmsa_save_event_plan_agreement_setup');
    echo '<input type="hidden" name="action" value="vmsa_save_event_plan_agreement_setup">';
    echo '<input type="hidden" name="event_plan_id" value="' . esc_attr((string) $event_plan_id) . '">';

    echo '<div class="vmsa-grid">';
    echo '<div class="vmsa-subcard"><h3>' . esc_html__('Vendor Contract Identity', 'vms-agreements') . '</h3>';
    echo '<label for="vmsa-vendor-legal-name"><strong>' . esc_html__('Vendor legal / contracting name', 'vms-agreements') . '</strong></label>';
    echo '<input id="vmsa-vendor-legal-name" class="vmsa-full" type="text" name="vmsa_vendor_legal_name" value="' . esc_attr((string) ($identity['legal_name'] ?? '')) . '" required>';
    echo '<p class="description">' . esc_html__('Prefilled from the Vendor payee/legal name, then Contact Person when available. Override it here when this agreement should name a different legal party.', 'vms-agreements') . '</p>';
    echo '<label for="vmsa-vendor-representative"><strong>' . esc_html__('Vendor representative / contact', 'vms-agreements') . '</strong></label>';
    echo '<input id="vmsa-vendor-representative" class="vmsa-full" type="text" name="vmsa_vendor_representative_name" value="' . esc_attr((string) ($identity['representative_name'] ?? '')) . '" required>';
    echo '<p class="description">' . esc_html__('The responsible person associated with this booking. The actual acknowledgement signer is recorded separately when the packet is accepted.', 'vms-agreements') . '</p>';
    echo '</div>';

    echo '<div class="vmsa-subcard"><h3>' . esc_html__('Production Responsibilities', 'vms-agreements') . '</h3>';
    echo '<p class="description">' . esc_html__('For this booking, does the Venue provide each item? Every item requires an explicit Yes or No.', 'vms-agreements') . '</p>';
    $production_labels = array(
        'stage' => __('Stage', 'vms-agreements'),
        'house_sound' => __('House Sound / PA', 'vms-agreements'),
        'stage_lighting' => __('Stage Lighting', 'vms-agreements'),
        'sound_engineer' => __('Sound Engineer', 'vms-agreements'),
    );
    echo '<div class="vmsa-production-grid">';
    foreach ($production_labels as $key => $label) {
        $current = (string) ($production[$key] ?? '');
        echo '<fieldset class="vmsa-production-choice"><legend><strong>' . esc_html($label) . '</strong></legend>';
        echo '<label><input type="radio" name="vmsa_production_' . esc_attr($key) . '" value="yes" ' . checked($current, 'yes', false) . ' required> ' . esc_html__('Yes', 'vms-agreements') . '</label> ';
        echo '<label><input type="radio" name="vmsa_production_' . esc_attr($key) . '" value="no" ' . checked($current, 'no', false) . '> ' . esc_html__('No', 'vms-agreements') . '</label>';
        echo '</fieldset>';
    }
    echo '</div>';
    echo '<p><label class="vmsa-production-confirm"><input type="checkbox" name="vmsa_production_confirmed" value="1" ' . checked(!empty($production['confirmed']), true, false) . ' required> <strong>' . esc_html__('I reviewed these production responsibilities for this booking.', 'vms-agreements') . '</strong></label></p>';
    echo '</div>';
    echo '</div>';

    echo '<div class="vmsa-subcard vmsa-production-schedule-card"><h3>' . esc_html__('Production Schedule', 'vms-agreements') . '</h3>';
    echo '<p class="description">' . esc_html__('These times are included in the Agreement Packet. Arrival/load-in anchors the 24-hour weather-cancellation cutoff. Venue-vacate may be left blank when it will be communicated later.', 'vms-agreements') . '</p>';
    echo '<div class="vmsa-production-schedule-grid">';
    echo '<div><label for="vmsa-arrival-loadin"><strong>' . esc_html__('Arrival / load-in', 'vms-agreements') . '</strong></label><input id="vmsa-arrival-loadin" type="time" name="vmsa_arrival_loadin" value="' . esc_attr((string) ($production_schedule['arrival_loadin'] ?? '')) . '" required></div>';
    echo '<div><label for="vmsa-soundcheck-start"><strong>' . esc_html__('Soundcheck starts', 'vms-agreements') . '</strong></label><input id="vmsa-soundcheck-start" type="time" name="vmsa_soundcheck_start" value="' . esc_attr((string) ($production_schedule['soundcheck_start'] ?? '')) . '" required></div>';
    echo '<div><label for="vmsa-soundcheck-end"><strong>' . esc_html__('Soundcheck complete by', 'vms-agreements') . '</strong></label><input id="vmsa-soundcheck-end" type="time" name="vmsa_soundcheck_end" value="' . esc_attr((string) ($production_schedule['soundcheck_end'] ?? '')) . '" required></div>';
    echo '<div><label for="vmsa-vacate-by"><strong>' . esc_html__('Load-out / venue vacate by', 'vms-agreements') . '</strong></label><input id="vmsa-vacate-by" type="time" name="vmsa_vacate_by" value="' . esc_attr((string) ($production_schedule['vacate_by'] ?? '')) . '"><span class="description">' . esc_html__('Optional', 'vms-agreements') . '</span></div>';
    echo '</div>';
    echo '</div>';

    echo '<div class="vmsa-subcard vmsa-payment-setup-card"><h3>' . esc_html__('Final Payment', 'vms-agreements') . '</h3>';
    if ($payment_timing_label !== '') {
        echo '<p><strong>' . esc_html__('Expected timing:', 'vms-agreements') . '</strong> ' . esc_html($payment_timing_label) . '</p>';
    }
    echo '<div class="vmsa-payment-method-field">';
    echo '<label for="vmsa-payment-method"><strong>' . esc_html__('Payment method', 'vms-agreements') . '</strong></label>';
    echo '<select id="vmsa-payment-method" name="vmsa_payment_method" required>';
    echo '<option value="">' . esc_html__('Select payment method', 'vms-agreements') . '</option>';
    foreach (vmsa_payment_method_choices() as $method_key => $method_label) {
        echo '<option value="' . esc_attr((string) $method_key) . '" ' . selected((string) ($payment_method['method'] ?? ''), (string) $method_key, false) . '>' . esc_html((string) $method_label) . '</option>';
    }
    echo '</select>';
    echo '</div>';
    $show_other_payment = (string) ($payment_method['method'] ?? '') === 'other';
    echo '<div id="vmsa-payment-method-other-field" class="vmsa-payment-method-other-field"' . ($show_other_payment ? '' : ' hidden') . '>';
    echo '<label for="vmsa-payment-method-other"><strong>' . esc_html__('Other payment method', 'vms-agreements') . '</strong></label>';
    echo '<input id="vmsa-payment-method-other" class="vmsa-full" type="text" name="vmsa_payment_method_other" value="' . esc_attr((string) ($payment_method['other'] ?? '')) . '" placeholder="' . esc_attr__('Describe the payment method', 'vms-agreements') . '">';
    echo '</div>';
    echo '<p class="description">' . esc_html__('This writes to the Event Plan\'s existing VMS Core final-payment method and is snapshotted into the agreement. A packet cannot be generated without a specific payment method.', 'vms-agreements') . '</p>';
    echo '<script>(function(){var s=document.getElementById("vmsa-payment-method"),o=document.getElementById("vmsa-payment-method-other"),w=document.getElementById("vmsa-payment-method-other-field");if(!s||!o||!w)return;function sync(){var other=(s.value==="other");o.required=other;o.setAttribute("aria-required",other?"true":"false");w.hidden=!other;}s.addEventListener("change",sync);sync();})();</script>';
    echo '</div>';

    $block_reason = vmsa_event_plan_generation_block_reason($event_plan_id);
    $active_packet_id = vmsa_find_active_packet($event_plan_id, $vendor_id);
    $latest_packet_id = $active_packet_id > 0 ? $active_packet_id : absint(get_post_meta($event_plan_id, '_vmsa_latest_packet_id', true));

    if ($active_packet_id > 0) {
        $active_status = sanitize_key((string) get_post_meta($active_packet_id, '_vmsa_status', true));
        $ack_records = get_post_meta($active_packet_id, '_vmsa_ack_records', true);
        if ($active_status === 'acknowledged' || (is_array($ack_records) && !empty($ack_records))) {
            echo '<p class="vmsa-warning-text">' . esc_html__('This packet has acknowledgement history. Regenerating / superseding will require the Vendor to acknowledge the new packet again.', 'vms-agreements') . '</p>';
        }
    }

    echo '<div class="vmsa-actions-bottom">';
    echo '<button type="submit" class="button button-secondary" name="vmsa_after_save" value="stay">' . esc_html__('Save Agreement Setup', 'vms-agreements') . '</button>';
    if ($latest_packet_id > 0 && get_post_type($latest_packet_id) === VMSA_CPT_PACKET) {
        echo '<button type="submit" class="button button-secondary" name="vmsa_after_save" value="view_packet">' . esc_html($active_packet_id > 0 ? __('Save & View Current Packet', 'vms-agreements') : __('Save & View Latest Packet', 'vms-agreements')) . '</button>';
    }
    if (!in_array($block_reason, array('cancelled_event', 'past_event', 'missing_event_plan', 'missing_vendor'), true)) {
        echo '<button type="submit" class="button button-primary" name="vmsa_after_save" value="generate">' . esc_html($active_packet_id > 0 ? __('Save & Regenerate / Supersede', 'vms-agreements') : __('Save & Generate Packet', 'vms-agreements')) . '</button>';
    }
    echo '</div>';
    echo '</form>';

    if ($block_reason !== '' && !in_array($block_reason, array('missing_vendor_legal_name', 'missing_vendor_representative', 'payment_method_incomplete', 'production_terms_incomplete', 'production_schedule_incomplete'), true)) {
        echo '<p class="vmsa-warning-text">' . esc_html(vmsa_event_plan_generation_block_message($event_plan_id, $block_reason, $latest_packet_id > 0)) . '</p>';
        $block_action = vmsa_event_plan_generation_block_action($block_reason, $event_plan_id);
        if (!empty($block_action['url']) && !empty($block_action['label'])) {
            echo '<p><a class="button button-secondary" href="' . esc_url((string) $block_action['url']) . '">' . esc_html((string) $block_action['label']) . '</a></p>';
        }
    }

    if ($active_packet_id > 0) {
        $terms_status = vmsa_packet_current_terms_status($active_packet_id);
        if (($terms_status['state'] ?? '') === 'stale') {
            echo '<p class="vmsa-warning-text">' . esc_html__('The current packet is stale because agreement or Event Plan terms changed. Regenerate / Supersede after confirming this setup.', 'vms-agreements') . '</p>';
        } else {
            echo '<p class="description">' . esc_html__('The current packet still matches the saved agreement setup.', 'vms-agreements') . '</p>';
        }
    }

    echo '</section>';
}

function vmsa_render_template_summary(): void
{
    $template = vmsa_get_template_payload();
    $health = (array) ($template['health'] ?? array());
    $template_id = absint($template['id'] ?? 0);
    $email_payload = vmsa_get_email_template_payload($template_id);
    $email_health = (array) ($email_payload['health'] ?? array());

    echo '<dl class="vmsa-definition-list">';
    echo '<dt>' . esc_html__('Template', 'vms-agreements') . '</dt><dd>' . esc_html((string) ($template['title'] ?? '')) . '</dd>';
    echo '<dt>' . esc_html__('Version', 'vms-agreements') . '</dt><dd>' . esc_html((string) ($template['version'] ?? '')) . '</dd>';
    echo '<dt>' . esc_html__('Blocks', 'vms-agreements') . '</dt><dd>' . esc_html((string) count((array) ($template['blocks'] ?? array()))) . '</dd>';
    echo '<dt>' . esc_html__('Acknowledgements', 'vms-agreements') . '</dt><dd>' . esc_html((string) count((array) ($template['acknowledgements'] ?? array()))) . '</dd>';
    echo '<dt>' . esc_html__('Agreement Health', 'vms-agreements') . '</dt><dd>' . esc_html(vmsa_template_health_status_label($health)) . '</dd>';
    echo '<dt>' . esc_html__('Email Health', 'vms-agreements') . '</dt><dd>' . esc_html(vmsa_email_template_health_status_label($email_health)) . '</dd>';
    echo '</dl>';
    echo '<p class="description">' . esc_html__('Templates are structured into protected data blocks, editable clause blocks, and editable email templates. Operators can revise wording without removing the event, vendor, compensation, deposit, acknowledgement, and audit record foundation.', 'vms-agreements') . '</p>';
    if ($template_id > 0) {
        echo '<p class="vmsa-button-row">';
        echo '<a class="button button-secondary" href="' . esc_url(vmsa_admin_page_url(array('vmsa_template' => $template_id))) . '">' . esc_html__('Edit Template Blocks', 'vms-agreements') . '</a> ';
        echo '<a class="button button-secondary" href="' . esc_url(vmsa_admin_page_url(array('vmsa_email_template' => $template_id))) . '">' . esc_html__('Edit Email Templates', 'vms-agreements') . '</a>';
        echo '</p>';
    }
}


function vmsa_render_packets_table(): void
{
    $packets = get_posts(array(
        'post_type' => VMSA_CPT_PACKET,
        'post_status' => 'private',
        'posts_per_page' => 25,
        'orderby' => 'date',
        'order' => 'DESC',
        'fields' => 'ids',
    ));

    if (empty($packets)) {
        echo '<p>' . esc_html__('No agreement packets have been generated yet.', 'vms-agreements') . '</p>';
        return;
    }

    echo '<table class="widefat striped vmsa-table">';
    echo '<thead><tr>';
    echo '<th>' . esc_html__('Packet', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Event', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Vendor', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Status', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Terms', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Generated', 'vms-agreements') . '</th>';
    echo '</tr></thead><tbody>';

    foreach ($packets as $packet_id) {
        $packet_id = absint($packet_id);
        $snapshot = vmsa_get_packet_snapshot($packet_id);
        $status = (string) get_post_meta($packet_id, '_vmsa_status', true);
        $terms_status = vmsa_packet_current_terms_status($packet_id);
        $event_id = absint($snapshot['event_plan']['id'] ?? 0);
        $vendor_id = absint($snapshot['vendor']['id'] ?? 0);
        $generated = (string) get_post_meta($packet_id, '_vmsa_generated_at', true);

        echo '<tr>';
        echo '<td><a href="' . esc_url(vmsa_admin_page_url(array('packet_id' => $packet_id))) . '"><strong>' . esc_html(vmsa_packet_display_title($packet_id)) . '</strong></a></td>';
        echo '<td>' . ($event_id > 0 ? '<a href="' . esc_url(vmsa_event_plan_edit_url($event_id)) . '">' . esc_html(vmsa_display_text($snapshot['event_plan']['title'] ?? get_the_title($event_id))) . '</a>' : '-') . '</td>';
        echo '<td>' . esc_html(vmsa_display_text($vendor_id > 0 ? ($snapshot['vendor']['name'] ?? get_the_title($vendor_id)) : '-')) . '</td>';
        echo '<td><span class="vmsa-pill vmsa-pill-' . esc_attr($status) . '">' . esc_html(vmsa_get_status_label($status)) . '</span></td>';
        echo '<td><span class="vmsa-pill vmsa-pill-' . esc_attr((string) $terms_status['state']) . '">' . esc_html((string) $terms_status['label']) . '</span></td>';
        echo '<td>' . esc_html($generated !== '' ? vmsa_format_audit_datetime($generated) : get_the_date('', $packet_id)) . '</td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
}

function vmsa_render_operator_queue(): void
{
    $packets = vmsa_get_operator_queue_packet_ids();
    if (empty($packets)) {
        echo '<p>' . esc_html__('No agreement packets have been generated yet.', 'vms-agreements') . '</p>';
        return;
    }

    $bucket_config = vmsa_operator_queue_bucket_config();
    $rows_by_bucket = array();
    foreach ($bucket_config as $bucket_key => $config) {
        $rows_by_bucket[$bucket_key] = array();
    }

    foreach ($packets as $packet_id) {
        $row = vmsa_build_operator_queue_row(absint($packet_id));
        if (empty($row)) {
            continue;
        }

        $bucket = (string) ($row['bucket'] ?? 'history');
        if (!isset($rows_by_bucket[$bucket])) {
            $bucket = 'history';
        }

        $rows_by_bucket[$bucket][] = $row;
    }

    echo '<p class="description">' . esc_html__('Use this queue to see which vendor agreement packets still need operator attention without opening each packet one by one.', 'vms-agreements') . '</p>';

    echo '<div class="vmsa-queue-summary">';
    foreach ($bucket_config as $bucket_key => $config) {
        $count = count($rows_by_bucket[$bucket_key]);
        echo '<span class="vmsa-queue-stat vmsa-queue-stat-' . esc_attr($bucket_key) . '">';
        echo '<strong>' . esc_html((string) $count) . '</strong> ' . esc_html((string) ($config['short_label'] ?? $config['label']));
        echo '</span>';
    }
    echo '</div>';

    $active_attention_count = count($rows_by_bucket['stale']) + count($rows_by_bucket['generated']) + count($rows_by_bucket['sent']) + count($rows_by_bucket['viewed']);
    if ($active_attention_count === 0) {
        echo '<div class="vmsa-queue-empty-state">' . esc_html__('No active agreement follow-ups need attention right now.', 'vms-agreements') . '</div>';
    }

    foreach ($bucket_config as $bucket_key => $config) {
        $rows = $rows_by_bucket[$bucket_key];
        if (empty($rows)) {
            continue;
        }

        $default_open = !empty($config['default_open']);
        echo '<details class="vmsa-queue-section vmsa-queue-section-' . esc_attr($bucket_key) . '"' . ($default_open ? ' open' : '') . '>';
        echo '<summary><span>' . esc_html((string) $config['label']) . '</span><span class="vmsa-pill">' . esc_html((string) count($rows)) . '</span></summary>';
        if (!empty($config['description'])) {
            echo '<p class="description">' . esc_html((string) $config['description']) . '</p>';
        }
        vmsa_render_operator_queue_table($rows);
        echo '</details>';
    }
}

/**
 * @return array<int,int>
 */
function vmsa_get_operator_queue_packet_ids(): array
{
    $packets = get_posts(array(
        'post_type' => VMSA_CPT_PACKET,
        'post_status' => 'private',
        'posts_per_page' => 150,
        'orderby' => 'date',
        'order' => 'DESC',
        'fields' => 'ids',
    ));

    return array_map('absint', is_array($packets) ? $packets : array());
}

/**
 * @return array<string,array<string,mixed>>
 */
function vmsa_operator_queue_bucket_config(): array
{
    return array(
        'stale' => array(
            'label' => __('Stale / Needs Regeneration', 'vms-agreements'),
            'short_label' => __('Stale', 'vms-agreements'),
            'description' => __('The Event Plan changed after these packets were generated. Open the packet to review and regenerate before asking for acknowledgement.', 'vms-agreements'),
            'default_open' => true,
        ),
        'generated' => array(
            'label' => __('Generated - Not Sent', 'vms-agreements'),
            'short_label' => __('Generated', 'vms-agreements'),
            'description' => __('These current packets exist but have not yet had a review-link email successfully sent.', 'vms-agreements'),
            'default_open' => true,
        ),
        'sent' => array(
            'label' => __('Sent - Not Viewed', 'vms-agreements'),
            'short_label' => __('Sent', 'vms-agreements'),
            'description' => __('These packets were emailed but the vendor has not opened the review link yet.', 'vms-agreements'),
            'default_open' => true,
        ),
        'viewed' => array(
            'label' => __('Viewed - Not Acknowledged', 'vms-agreements'),
            'short_label' => __('Viewed', 'vms-agreements'),
            'description' => __('These vendors opened the packet but have not submitted acknowledgement yet.', 'vms-agreements'),
            'default_open' => true,
        ),
        'acknowledged' => array(
            'label' => __('Acknowledged', 'vms-agreements'),
            'short_label' => __('Acknowledged', 'vms-agreements'),
            'description' => __('Completed current packets remain available here for quick access and printable proof.', 'vms-agreements'),
            'default_open' => false,
        ),
        'history' => array(
            'label' => __('Superseded / Voided History', 'vms-agreements'),
            'short_label' => __('History', 'vms-agreements'),
            'description' => __('Inactive packets are retained for audit history. They do not expose active email/review actions from the queue.', 'vms-agreements'),
            'default_open' => false,
        ),
    );
}

/**
 * @return array<string,mixed>
 */
function vmsa_build_operator_queue_row(int $packet_id): array
{
    if ($packet_id <= 0 || get_post_type($packet_id) !== VMSA_CPT_PACKET) {
        return array();
    }

    $snapshot = vmsa_get_packet_snapshot($packet_id);
    if (empty($snapshot)) {
        return array();
    }

    $status = (string) get_post_meta($packet_id, '_vmsa_status', true);
    if ($status === '') {
        $status = 'generated';
    }

    $terms_status = vmsa_packet_current_terms_status($packet_id);
    $bucket = vmsa_operator_queue_bucket_for_packet($status, $terms_status);
    $event = (array) ($snapshot['event_plan'] ?? array());
    $vendor = (array) ($snapshot['vendor'] ?? array());
    $comp = (array) ($snapshot['compensation'] ?? array());
    $event_id = absint($event['id'] ?? get_post_meta($packet_id, '_vmsa_event_plan_id', true));
    $vendor_id = absint($vendor['id'] ?? get_post_meta($packet_id, '_vmsa_vendor_id', true));
    $event_title = vmsa_display_text($event['title'] ?? ($event_id > 0 ? get_the_title($event_id) : ''));
    $vendor_name = vmsa_display_text($vendor['name'] ?? ($vendor_id > 0 ? get_the_title($vendor_id) : ''));
    $vendor_email = sanitize_email((string) ($vendor['email'] ?? ''));

    return array(
        'packet_id' => $packet_id,
        'title' => vmsa_packet_display_title($packet_id),
        'status' => $status,
        'status_label' => vmsa_get_status_label($status),
        'terms_state' => (string) ($terms_status['state'] ?? 'unknown'),
        'terms_label' => (string) ($terms_status['label'] ?? ''),
        'bucket' => $bucket,
        'event_id' => $event_id,
        'event_title' => $event_title,
        'event_date' => vmsa_format_date((string) ($event['event_date'] ?? '')),
        'vendor_id' => $vendor_id,
        'vendor_name' => $vendor_name,
        'vendor_email' => $vendor_email,
        'pay_summary' => vmsa_clean_compensation_summary_text((string) ($comp['summary'] ?? '')),
        'last_activity' => vmsa_operator_queue_last_activity($packet_id, $status),
        'can_email' => vmsa_operator_queue_can_email($status, $terms_status, $vendor_email),
        'can_print' => !in_array($status, array('voided', 'superseded'), true),
    );
}

function vmsa_operator_queue_bucket_for_packet(string $status, array $terms_status): string
{
    $terms_state = (string) ($terms_status['state'] ?? 'unknown');
    if ($terms_state === 'stale' && in_array($status, vmsa_get_active_packet_statuses(), true)) {
        return 'stale';
    }

    if (in_array($status, array('generated', 'sent', 'viewed', 'acknowledged'), true)) {
        return $status;
    }

    return 'history';
}

function vmsa_operator_queue_last_activity(int $packet_id, string $status): string
{
    if ($status === 'acknowledged') {
        $latest_ack = vmsa_get_latest_ack_record($packet_id);
        $ack_at = (string) ($latest_ack['acknowledged_at'] ?? '');
        if ($ack_at !== '') {
            return sprintf(__('Acknowledged %s', 'vms-agreements'), vmsa_format_audit_datetime($ack_at));
        }
    }

    if ($status === 'viewed') {
        $viewed_at = (string) get_post_meta($packet_id, '_vmsa_last_viewed_at', true);
        if ($viewed_at !== '') {
            return sprintf(__('Viewed %s', 'vms-agreements'), vmsa_format_audit_datetime($viewed_at));
        }
    }

    if ($status === 'sent') {
        $sent_at = (string) get_post_meta($packet_id, '_vmsa_review_email_sent_at', true);
        if ($sent_at !== '') {
            return sprintf(__('Sent %s', 'vms-agreements'), vmsa_format_audit_datetime($sent_at));
        }
    }

    if ($status === 'superseded') {
        $superseded_at = (string) get_post_meta($packet_id, '_vmsa_superseded_at', true);
        if ($superseded_at !== '') {
            return sprintf(__('Superseded %s', 'vms-agreements'), vmsa_format_audit_datetime($superseded_at));
        }
    }

    if ($status === 'voided') {
        $voided_at = (string) get_post_meta($packet_id, '_vmsa_voided_at', true);
        if ($voided_at !== '') {
            return sprintf(__('Voided %s', 'vms-agreements'), vmsa_format_audit_datetime($voided_at));
        }
    }

    $generated_at = (string) get_post_meta($packet_id, '_vmsa_generated_at', true);
    if ($generated_at !== '') {
        return sprintf(__('Generated %s', 'vms-agreements'), vmsa_format_audit_datetime($generated_at));
    }

    return get_the_date('', $packet_id);
}

function vmsa_operator_queue_can_email(string $status, array $terms_status, string $vendor_email): bool
{
    if ($vendor_email === '') {
        return false;
    }

    if (!in_array($status, array('generated', 'sent', 'viewed'), true)) {
        return false;
    }

    return (string) ($terms_status['state'] ?? '') === 'current';
}

/**
 * @param array<int,array<string,mixed>> $rows
 */
function vmsa_render_operator_queue_table(array $rows): void
{
    echo '<table class="widefat striped vmsa-table vmsa-queue-table">';
    echo '<thead><tr>';
    echo '<th>' . esc_html__('Packet', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Event', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Vendor', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Status', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Last Activity', 'vms-agreements') . '</th>';
    echo '<th>' . esc_html__('Actions', 'vms-agreements') . '</th>';
    echo '</tr></thead><tbody>';

    foreach ($rows as $row) {
        $packet_id = absint($row['packet_id'] ?? 0);
        $event_id = absint($row['event_id'] ?? 0);
        $event_title = (string) ($row['event_title'] ?? '');
        $event_date = (string) ($row['event_date'] ?? '');
        $vendor_name = (string) ($row['vendor_name'] ?? '');
        $vendor_email = (string) ($row['vendor_email'] ?? '');
        $status = (string) ($row['status'] ?? '');
        $terms_state = (string) ($row['terms_state'] ?? '');
        $terms_label = (string) ($row['terms_label'] ?? '');
        $pay_summary = (string) ($row['pay_summary'] ?? '');

        echo '<tr>';
        echo '<td><a href="' . esc_url(vmsa_admin_page_url(array('packet_id' => $packet_id))) . '"><strong>' . esc_html(vmsa_display_text($row['title'] ?? vmsa_packet_display_title($packet_id))) . '</strong></a>';
        if ($pay_summary !== '') {
            echo '<br><span class="description">' . esc_html(vmsa_display_text($pay_summary)) . '</span>';
        }
        echo '</td>';

        echo '<td>';
        if ($event_id > 0) {
            echo '<a href="' . esc_url(vmsa_event_plan_edit_url($event_id)) . '">' . esc_html(vmsa_display_text($event_title !== '' ? $event_title : get_the_title($event_id))) . '</a>';
        } else {
            echo esc_html(vmsa_display_text($event_title !== '' ? $event_title : '-'));
        }
        if ($event_date !== '') {
            echo '<br><span class="description">' . esc_html($event_date) . '</span>';
        }
        echo '</td>';

        echo '<td>' . esc_html(vmsa_display_text($vendor_name !== '' ? $vendor_name : '-'));
        if ($vendor_email !== '') {
            echo '<br><span class="description">' . esc_html($vendor_email) . '</span>';
        }
        echo '</td>';

        echo '<td><span class="vmsa-pill vmsa-pill-' . esc_attr($status) . '">' . esc_html((string) ($row['status_label'] ?? vmsa_get_status_label($status))) . '</span><br>';
        echo '<span class="vmsa-pill vmsa-pill-' . esc_attr($terms_state) . '">' . esc_html($terms_label !== '' ? $terms_label : ucwords($terms_state)) . '</span></td>';

        echo '<td>' . esc_html((string) ($row['last_activity'] ?? '-')) . '</td>';
        echo '<td>';
        vmsa_render_operator_queue_actions($row);
        echo '</td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
}

/**
 * @param array<string,mixed> $row
 */
function vmsa_render_operator_queue_actions(array $row): void
{
    $packet_id = absint($row['packet_id'] ?? 0);
    $event_id = absint($row['event_id'] ?? 0);
    $status = (string) ($row['status'] ?? '');
    $can_email = !empty($row['can_email']);
    $can_print = !empty($row['can_print']);

    echo '<div class="vmsa-queue-actions">';
    echo '<a class="button button-small" href="' . esc_url(vmsa_admin_page_url(array('packet_id' => $packet_id))) . '">' . esc_html__('Open Packet', 'vms-agreements') . '</a>';

    if ($event_id > 0) {
        echo '<a class="button button-small" href="' . esc_url(vmsa_event_plan_edit_url($event_id)) . '">' . esc_html__('Event Plan', 'vms-agreements') . '</a>';
    }

    if ($can_email) {
        $send_count = absint(get_post_meta($packet_id, '_vmsa_review_email_send_count', true));
        echo '<form class="vmsa-inline-action-form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('vmsa_email_review_link');
        echo '<input type="hidden" name="action" value="vmsa_email_review_link">';
        echo '<input type="hidden" name="packet_id" value="' . esc_attr((string) $packet_id) . '">';
        echo '<button type="submit" class="button button-small button-secondary">' . esc_html($send_count > 0 ? __('Resend Email', 'vms-agreements') : __('Email Review', 'vms-agreements')) . '</button>';
        echo '</form>';
    }

    if ($can_print) {
        $token = vmsa_get_or_create_review_token($packet_id);
        echo '<a class="button button-small" target="_blank" rel="noopener noreferrer" href="' . esc_url(vmsa_packet_print_url($packet_id, $token)) . '">' . esc_html__('Print / PDF', 'vms-agreements') . '</a>';
    }

    if ((string) ($row['bucket'] ?? '') === 'stale') {
        echo '<span class="description vmsa-queue-action-note">' . esc_html__('Open packet to regenerate safely.', 'vms-agreements') . '</span>';
    } elseif (in_array($status, array('superseded', 'voided'), true)) {
        echo '<span class="description vmsa-queue-action-note">' . esc_html__('Historical only.', 'vms-agreements') . '</span>';
    }

    echo '</div>';
}

function vmsa_render_packet_view(int $packet_id): void
{
    $snapshot = vmsa_get_packet_snapshot($packet_id);
    if (empty($snapshot)) {
        echo '<section class="vmsa-card vmsa-card-wide"><p>' . esc_html__('This packet has no stored snapshot.', 'vms-agreements') . '</p></section>';
        return;
    }

    $status = (string) get_post_meta($packet_id, '_vmsa_status', true);
    $terms_status = vmsa_packet_current_terms_status($packet_id);
    $event = (array) ($snapshot['event_plan'] ?? array());
    $operator = (array) ($snapshot['operator'] ?? array());
    $venue = (array) ($snapshot['venue'] ?? array());
    $vendor = (array) ($snapshot['vendor'] ?? array());
    $comp = (array) ($snapshot['compensation'] ?? array());
    $production_schedule = (array) ($snapshot['production_schedule'] ?? array());
    $template = (array) ($snapshot['template'] ?? array());
    $acknowledgements = (array) ($template['acknowledgements'] ?? array());
    $audit_records = get_post_meta($packet_id, '_vmsa_ack_records', true);
    if (!is_array($audit_records)) {
        $audit_records = array();
    }

    echo '<section class="vmsa-card vmsa-card-wide vmsa-packet-view" data-vms-tour="agreements.packet-view">';
    echo '<div class="vmsa-card-header" data-vms-tour="agreements.packet-header">';
    echo '<div><h2>' . esc_html(vmsa_packet_display_title($packet_id)) . '</h2><p class="description">' . esc_html__('Stored agreement packet snapshot', 'vms-agreements') . '</p></div>';
    echo '<div class="vmsa-actions">';
    echo '<span class="vmsa-pill vmsa-pill-' . esc_attr($status) . '">' . esc_html(vmsa_get_status_label($status)) . '</span>';
    echo '<span class="vmsa-pill vmsa-pill-' . esc_attr((string) $terms_status['state']) . '">' . esc_html((string) $terms_status['label']) . '</span>';
    echo '</div>';
    echo '</div>';

    if (($terms_status['state'] ?? '') === 'stale') {
        echo '<div class="notice notice-warning inline"><p>' . esc_html__('The Event Plan changed after this packet was generated. Generate a new packet before sending or requesting acknowledgement.', 'vms-agreements') . '</p></div>';
    }
    vmsa_render_admin_review_link_card($packet_id, $status, $terms_status);

    echo '<div class="vmsa-grid vmsa-grid-three">';
    $event_card_rows = array(
        __('Title', 'vms-agreements') => (string) ($event['title'] ?? ''),
        __('Date', 'vms-agreements') => vmsa_format_date((string) ($event['event_date'] ?? '')),
        __('Performance Time', 'vms-agreements') => vmsa_format_time_range((string) ($event['start_time'] ?? ''), (string) ($event['end_time'] ?? '')),
    );
    if (!empty($production_schedule)) {
        $event_card_rows[__('Arrival / Load-in', 'vms-agreements')] = vmsa_format_time((string) ($production_schedule['arrival_loadin'] ?? ''));
        $event_card_rows[__('Soundcheck', 'vms-agreements')] = vmsa_format_time_range((string) ($production_schedule['soundcheck_start'] ?? ''), (string) ($production_schedule['soundcheck_end'] ?? ''));
        $event_card_rows[__('Vacate By', 'vms-agreements')] = trim((string) ($production_schedule['vacate_by'] ?? '')) !== '' ? vmsa_format_time((string) ($production_schedule['vacate_by'] ?? '')) : __('To be communicated', 'vms-agreements');
    }
    $event_card_rows[__('Status', 'vms-agreements')] = (string) ($event['event_status_label'] ?? vmsa_get_event_plan_status_label((string) ($event['event_status'] ?? '')));
    vmsa_render_snapshot_card(__('Event', 'vms-agreements'), $event_card_rows);
    vmsa_render_snapshot_card(__('Vendor / Venue', 'vms-agreements'), array(
        __('Vendor', 'vms-agreements') => (string) ($vendor['name'] ?? ''),
        __('Vendor Email', 'vms-agreements') => (string) ($vendor['email'] ?? ''),
        __('Vendor Phone', 'vms-agreements') => vmsa_format_phone_number((string) ($vendor['phone'] ?? '')),
        __('Venue', 'vms-agreements') => (string) ($venue['name'] ?? ''),
        __('Contracting Party', 'vms-agreements') => (string) ($operator['contracting_entity'] ?? ''),
    ));
    vmsa_render_snapshot_card(__('Template', 'vms-agreements'), array(
        __('Template', 'vms-agreements') => (string) ($template['title'] ?? ''),
        __('Version', 'vms-agreements') => (string) ($template['version'] ?? ''),
        __('Terms Hash', 'vms-agreements') => (string) ($snapshot['terms_hash'] ?? ''),
        __('Comp Hash', 'vms-agreements') => (string) ($comp['comp_hash'] ?? ''),
    ));
    echo '</div>';

    vmsa_render_admin_terms_diagnostic_panel($packet_id, $terms_status);

    echo '<div class="vmsa-grid">';
    echo '<div class="vmsa-subcard" data-vms-tour="agreements.comp-snapshot"><h3>' . esc_html__('Compensation Snapshot', 'vms-agreements') . '</h3>';
    echo '<p>' . esc_html(vmsa_clean_compensation_summary_text((string) ($comp['summary'] ?? ''))) . '</p>';
    vmsa_render_admin_bonus_payout_table((array) ($comp['terms'] ?? array()));
    echo '<p><strong>' . esc_html__('Deposit / advance:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_display_text($comp['deposit_summary'] ?? '')) . '</p>';
    echo '<p><strong>' . esc_html__('Payment summary:', 'vms-agreements') . '</strong></p>';
    $payment_breakdown = (array) ($comp['payment_breakdown'] ?? array());
    $payment_lines = isset($payment_breakdown['lines']) && is_array($payment_breakdown['lines'])
        ? $payment_breakdown['lines']
        : array((string) ($comp['payment_summary'] ?? vmsa_format_payment_summary((array) ($comp['terms'] ?? array()))));
    echo '<ul class="vmsa-compact-list">';
    foreach ($payment_lines as $payment_line) {
        $payment_line = trim(vmsa_display_text($payment_line));
        if ($payment_line !== '') {
            echo '<li>' . esc_html($payment_line) . '</li>';
        }
    }
    echo '</ul>';
    echo '</div>';

    vmsa_render_admin_acknowledgement_summary($packet_id, $acknowledgements, $audit_records);
    echo '</div>';

    echo '<div class="vmsa-subcard"><h3>' . esc_html__('Agreement Text Preview', 'vms-agreements') . '</h3>';
    $agreement_preview_text = vmsa_display_text(vmsa_render_template_text($snapshot));
    echo '<div class="vmsa-agreement-preview">' . wp_kses_post(nl2br(esc_html($agreement_preview_text))) . '</div>';
    echo '</div>';

    vmsa_render_admin_audit_trail($packet_id, $audit_records);

    echo '<div class="vmsa-actions vmsa-actions-bottom">';
    $event_id = absint($event['id'] ?? 0);
    if ($event_id > 0) {
        $is_active_packet = in_array($status, vmsa_get_active_packet_statuses(), true);
        $has_ack_records = !empty($audit_records);
        $generation_block_reason = vmsa_event_plan_generation_block_reason($event_id);

        if ($generation_block_reason !== '') {
            echo '<div class="vmsa-guardrail">';
            echo '<h3>' . esc_html__('New Packet Generation Unavailable', 'vms-agreements') . '</h3>';
            echo '<p class="vmsa-warning-text">' . esc_html(vmsa_event_plan_generation_block_message($event_id, $generation_block_reason, true)) . '</p>';
            $block_action = vmsa_event_plan_generation_block_action($generation_block_reason, $event_id);
            if (!empty($block_action['url']) && !empty($block_action['label'])) {
                echo '<p><a class="button button-secondary" href="' . esc_url((string) $block_action['url']) . '">' . esc_html((string) $block_action['label']) . '</a></p>';
            }
            echo '</div>';
        } elseif ($is_active_packet) {
            echo '<div class="vmsa-guardrail">';
            echo '<h3>' . esc_html__('Regenerate / Supersede Current Packet', 'vms-agreements') . '</h3>';
            if ($status === 'acknowledged' || $has_ack_records) {
                echo '<p class="vmsa-warning-text">' . esc_html__('This packet already has vendor acknowledgement history. Regenerating will preserve this packet as superseded history and create a new current packet that must be acknowledged again.', 'vms-agreements') . '</p>';
            } else {
                echo '<p>' . esc_html__('Regenerating preserves this packet as superseded history and creates a new current packet. Use this only when the event, compensation, deposit, or agreement terms need a fresh snapshot.', 'vms-agreements') . '</p>';
            }
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field('vmsa_generate_packet');
            echo '<input type="hidden" name="action" value="vmsa_generate_packet">';
            echo '<input type="hidden" name="event_plan_id" value="' . esc_attr((string) $event_id) . '">';
            echo '<input type="hidden" name="vmsa_confirm_regenerate" value="1">';
            submit_button(__('Regenerate / Supersede Current Packet', 'vms-agreements'), 'secondary', 'submit', false);
            echo '</form>';
            echo '</div>';
        } else {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field('vmsa_generate_packet');
            echo '<input type="hidden" name="action" value="vmsa_generate_packet">';
            echo '<input type="hidden" name="event_plan_id" value="' . esc_attr((string) $event_id) . '">';
            submit_button(__('Generate Packet from Current Event Plan', 'vms-agreements'), 'secondary', 'submit', false);
            echo '</form>';
        }
    }

    if (!in_array($status, array('voided', 'superseded'), true)) {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('vmsa_void_packet');
        echo '<input type="hidden" name="action" value="vmsa_void_packet">';
        echo '<input type="hidden" name="packet_id" value="' . esc_attr((string) $packet_id) . '">';
        submit_button(__('Void Packet', 'vms-agreements'), 'delete', 'submit', false);
        echo '</form>';
    }
    echo '</div>';

    vmsa_render_admin_cleanup_section($packet_id, $event_id);

    echo '</section>';
}

function vmsa_render_admin_cleanup_section(int $packet_id, int $event_plan_id): void
{
    if (!vmsa_can_manage() || $event_plan_id <= 0 || get_post_type($event_plan_id) !== 'vms_event_plan') {
        return;
    }

    echo '<div class="vmsa-subcard vmsa-testing-cleanup">';
    echo '<h3>' . esc_html__('Testing / Cleanup', 'vms-agreements') . '</h3>';
    echo '<p>' . esc_html__('These tools are for test packet cleanup only. They hard-delete eligible Agreement Packet posts for this Event Plan and cannot be undone. Acknowledged packets are always skipped.', 'vms-agreements') . '</p>';

    echo '<div class="vmsa-guardrail">';
    echo '<h4>' . esc_html__('Delete unacknowledged packets for this Event Plan', 'vms-agreements') . '</h4>';
    echo '<p>' . esc_html__('Deletes generated, sent, viewed, superseded, and voided packets for this Event Plan when they do not contain acknowledgement history.', 'vms-agreements') . '</p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('vmsa_cleanup_event_plan_packets');
    echo '<input type="hidden" name="action" value="vmsa_cleanup_event_plan_packets">';
    echo '<input type="hidden" name="packet_id" value="' . esc_attr((string) $packet_id) . '">';
    echo '<input type="hidden" name="event_plan_id" value="' . esc_attr((string) $event_plan_id) . '">';
    echo '<input type="hidden" name="cleanup_scope" value="unacknowledged">';
    echo '<p><label><input type="checkbox" name="vmsa_confirm_cleanup" value="1" required> ' . esc_html__('I understand this will permanently delete eligible unacknowledged test packets for this Event Plan.', 'vms-agreements') . '</label></p>';
    submit_button(__('Delete unacknowledged packets for this Event Plan', 'vms-agreements'), 'delete', 'submit', false);
    echo '</form>';
    echo '</div>';

    echo '<div class="vmsa-guardrail">';
    echo '<h4>' . esc_html__('Delete stale/history packets for this Event Plan', 'vms-agreements') . '</h4>';
    echo '<p>' . esc_html__('Deletes superseded, voided, or stale packets for this Event Plan while keeping the current generated/sent/viewed packet and any packet with acknowledgement history.', 'vms-agreements') . '</p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('vmsa_cleanup_event_plan_packets');
    echo '<input type="hidden" name="action" value="vmsa_cleanup_event_plan_packets">';
    echo '<input type="hidden" name="packet_id" value="' . esc_attr((string) $packet_id) . '">';
    echo '<input type="hidden" name="event_plan_id" value="' . esc_attr((string) $event_plan_id) . '">';
    echo '<input type="hidden" name="cleanup_scope" value="history">';
    echo '<p><label><input type="checkbox" name="vmsa_confirm_cleanup" value="1" required> ' . esc_html__('I understand this will permanently delete eligible stale/history test packets for this Event Plan.', 'vms-agreements') . '</label></p>';
    submit_button(__('Delete stale/history packets for this Event Plan', 'vms-agreements'), 'delete', 'submit', false);
    echo '</form>';
    echo '</div>';

    echo '</div>';
}


function vmsa_render_admin_bonus_payout_table(array $terms): void
{
    $rows = function_exists('vmsa_build_bonus_payout_rows') ? vmsa_build_bonus_payout_rows($terms) : array();
    if (empty($rows)) {
        return;
    }

    echo '<div class="vmsa-bonus-payout">';
    echo '<h4>' . esc_html__('Bonus payout schedule', 'vms-agreements') . '</h4>';
    echo '<table class="widefat striped vmsa-bonus-payout-table"><thead><tr>';
    echo '<th scope="col">' . esc_html(vmsa_bonus_count_source_table_heading($terms)) . '</th>';
    echo '<th scope="col">' . esc_html__('Payout', 'vms-agreements') . '</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr>';
        echo '<td>' . esc_html((string) absint($row['count'] ?? 0)) . '</td>';
        echo '<td>' . esc_html(vmsa_money($row['payout'] ?? null)) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
    $note = function_exists('vmsa_bonus_qualification_note') ? vmsa_bonus_qualification_note($terms) : '';
    if ($note !== '') {
        echo '<p class="description">' . esc_html($note) . '</p>';
    }
    echo '</div>';
}

function vmsa_render_admin_terms_diagnostic_panel(int $packet_id, array $terms_status): void
{
    if (!vmsa_can_manage()) {
        return;
    }

    $diagnostics = isset($terms_status['diagnostics']) && is_array($terms_status['diagnostics'])
        ? (array) $terms_status['diagnostics']
        : vmsa_packet_terms_diagnostics($packet_id);

    $state = (string) ($terms_status['state'] ?? 'unknown');
    $differences = isset($diagnostics['differences']) && is_array($diagnostics['differences']) ? $diagnostics['differences'] : array();
    $summary_class = $state === 'current' ? 'vmsa-diagnostic-current' : 'vmsa-diagnostic-stale';

    echo '<details class="vmsa-subcard vmsa-terms-diagnostics ' . esc_attr($summary_class) . '">';
    echo '<summary><strong>' . esc_html__('Agreement Current-State Diagnostics', 'vms-agreements') . '</strong> ';
    echo '<span class="description">' . esc_html($state === 'current' ? __('No contract-significant differences detected.', 'vms-agreements') : __('Contract-significant differences detected; see fields below.', 'vms-agreements')) . '</span></summary>';

    echo '<dl class="vmsa-definition-list">';
    echo '<dt>' . esc_html__('Packet ID', 'vms-agreements') . '</dt><dd>' . esc_html((string) $packet_id) . '</dd>';
    echo '<dt>' . esc_html__('Event Plan ID', 'vms-agreements') . '</dt><dd>' . esc_html((string) absint($diagnostics['event_plan_id'] ?? 0)) . '</dd>';
    echo '<dt>' . esc_html__('Stored hash', 'vms-agreements') . '</dt><dd><code>' . esc_html((string) ($diagnostics['stored_hash'] ?? '')) . '</code></dd>';
    echo '<dt>' . esc_html__('Packet canonical hash', 'vms-agreements') . '</dt><dd><code>' . esc_html((string) ($diagnostics['packet_hash'] ?? '')) . '</code></dd>';
    echo '<dt>' . esc_html__('Current Event Plan hash', 'vms-agreements') . '</dt><dd><code>' . esc_html((string) ($diagnostics['current_hash'] ?? '')) . '</code></dd>';
    echo '<dt>' . esc_html__('Stored hash matches packet', 'vms-agreements') . '</dt><dd>' . esc_html(!empty($diagnostics['matches_stored_packet']) ? __('Yes', 'vms-agreements') : __('No', 'vms-agreements')) . '</dd>';
    echo '<dt>' . esc_html__('Packet matches current Event Plan', 'vms-agreements') . '</dt><dd>' . esc_html(!empty($diagnostics['matches_current']) || empty($differences) ? __('Yes', 'vms-agreements') : __('No', 'vms-agreements')) . '</dd>';
    echo '<dt>' . esc_html__('VMS compensation helper available', 'vms-agreements') . '</dt><dd>' . esc_html(!empty($diagnostics['comp_helper_available']) ? __('Yes', 'vms-agreements') : __('No', 'vms-agreements')) . '</dd>';
    if (!empty($diagnostics['fallbacks']) && is_array($diagnostics['fallbacks'])) {
        echo '<dt>' . esc_html__('Comparison fallbacks used', 'vms-agreements') . '</dt><dd>' . esc_html(implode(', ', array_map('vmsa_display_text', (array) $diagnostics['fallbacks']))) . '</dd>';
    }
    echo '</dl>';

    if (!empty($diagnostics['error'])) {
        echo '<p class="vmsa-warning-text">' . esc_html(vmsa_display_text($diagnostics['error'])) . '</p>';
    }

    if (empty($differences)) {
        echo '<p>' . esc_html__('No field-level differences were found in the agreement fingerprint. If another page shows this packet as stale, clear page/object cache and retest this exact packet URL.', 'vms-agreements') . '</p>';
    } else {
        echo '<table class="widefat striped vmsa-table vmsa-diagnostic-table"><thead><tr>';
        echo '<th>' . esc_html__('Field', 'vms-agreements') . '</th>';
        echo '<th>' . esc_html__('Packet snapshot', 'vms-agreements') . '</th>';
        echo '<th>' . esc_html__('Current Event Plan', 'vms-agreements') . '</th>';
        echo '</tr></thead><tbody>';
        foreach (array_slice($differences, 0, 40) as $diff) {
            if (!is_array($diff)) {
                continue;
            }
            echo '<tr>';
            echo '<td><code>' . esc_html((string) ($diff['path'] ?? '')) . '</code></td>';
            echo '<td>' . esc_html(vmsa_display_text($diff['packet'] ?? '')) . '</td>';
            echo '<td>' . esc_html(vmsa_display_text($diff['current'] ?? '')) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    echo '</details>';
}

function vmsa_render_snapshot_card(string $title, array $rows): void
{
    echo '<div class="vmsa-subcard"><h3>' . esc_html(vmsa_display_text($title)) . '</h3><dl class="vmsa-definition-list">';
    foreach ($rows as $label => $value) {
        $value = vmsa_display_text($value);
        echo '<dt>' . esc_html(vmsa_display_text($label)) . '</dt><dd>' . esc_html($value !== '' ? $value : '-') . '</dd>';
    }
    echo '</dl></div>';
}

function vmsa_render_admin_review_link_card(int $packet_id, string $status, array $terms_status): void
{
    if (in_array($status, array('voided', 'superseded'), true)) {
        return;
    }

    $snapshot = vmsa_get_packet_snapshot($packet_id);
    $vendor = (array) ($snapshot['vendor'] ?? array());
    $vendor_email = sanitize_email((string) ($vendor['email'] ?? ''));
    $token = vmsa_get_or_create_review_token($packet_id);
    $review_url = vmsa_packet_review_url($packet_id, $token);
    $is_current = (($terms_status['state'] ?? '') === 'current');
    $send_count = absint(get_post_meta($packet_id, '_vmsa_review_email_send_count', true));
    $last_sent = (string) get_post_meta($packet_id, '_vmsa_review_email_sent_at', true);
    $last_sent_to = (string) get_post_meta($packet_id, '_vmsa_review_email_sent_to', true);
    $last_error = (string) get_post_meta($packet_id, '_vmsa_review_email_last_error', true);

    echo '<div class="vmsa-subcard" data-vms-tour="agreements.vendor-review-link">';
    echo '<h3>' . esc_html__('Vendor Review Link', 'vms-agreements') . '</h3>';
    if (!$is_current) {
        echo '<p class="vmsa-warning-text">' . esc_html__('This packet is stale. Generate a fresh packet before sending the vendor review link.', 'vms-agreements') . '</p>';
    }
    echo '<p class="description">' . esc_html__('Copy this secure link for the vendor to review and acknowledge the current packet. Regenerating the link invalidates the previously copied link for this packet.', 'vms-agreements') . '</p>';
    echo '<div class="vmsa-review-link-row">';
    echo '<input type="text" readonly value="' . esc_attr($review_url) . '" onclick="this.select();">';
    echo '<a class="button button-secondary" target="_blank" rel="noopener noreferrer" href="' . esc_url($review_url) . '">' . esc_html__('Open Vendor Review', 'vms-agreements') . '</a>';
    echo '<a class="button button-secondary" target="_blank" rel="noopener noreferrer" href="' . esc_url(vmsa_packet_print_url($packet_id, $token)) . '">' . esc_html__('Print / Save PDF', 'vms-agreements') . '</a>';
    echo '<a class="button button-secondary" href="' . esc_url(vmsa_regenerate_review_token_url($packet_id)) . '">' . esc_html__('Regenerate Link', 'vms-agreements') . '</a>';
    echo '</div>';

    echo '<div class="vmsa-email-delivery-box">';
    echo '<h4>' . esc_html__('Email Review Link', 'vms-agreements') . '</h4>';
    if ($vendor_email === '') {
        echo '<p class="vmsa-warning-text">' . esc_html__('This packet snapshot does not include a vendor email address, so VMS Agreements cannot email the link yet.', 'vms-agreements') . '</p>';
    } else {
        echo '<p class="description">' . sprintf(
            esc_html__('Send the secure review link to %s. Each send/resend is recorded in the audit trail.', 'vms-agreements'),
            esc_html($vendor_email)
        ) . '</p>';
        if ($last_error !== '') {
            echo '<p class="vmsa-warning-text"><strong>' . esc_html__('Last email error:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_display_text($last_error)) . '</p>';
        }

        if ($send_count > 0) {
            echo '<p><strong>' . esc_html__('Last sent:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_format_audit_datetime($last_sent)) . ' &mdash; ' . esc_html($last_sent_to !== '' ? $last_sent_to : $vendor_email) . '</p>';
            echo '<p><strong>' . esc_html__('Send count:', 'vms-agreements') . '</strong> ' . esc_html((string) $send_count) . '</p>';
        } else {
            echo '<p class="vmsa-warning-text"><strong>' . esc_html__('Not yet sent:', 'vms-agreements') . '</strong> ' . esc_html__('This packet has been generated, but the vendor review email has not been sent yet.', 'vms-agreements') . '</p>';
        }

        if ($status === 'acknowledged') {
            echo '<p class="description">' . esc_html__('This packet has already been acknowledged, so the review email action is disabled.', 'vms-agreements') . '</p>';
        } elseif (!$is_current) {
            echo '<p class="description">' . esc_html__('Email delivery is disabled until a fresh current packet is generated.', 'vms-agreements') . '</p>';
        } else {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field('vmsa_email_review_link');
            echo '<input type="hidden" name="action" value="vmsa_email_review_link">';
            echo '<input type="hidden" name="packet_id" value="' . esc_attr((string) $packet_id) . '">';
            echo '<label class="vmsa-email-note-field"><span>' . esc_html__('Optional note for this send', 'vms-agreements') . '</span><textarea name="operator_note" rows="3" placeholder="' . esc_attr__('Example: Please review this when you get a chance and let us know if anything looks off.', 'vms-agreements') . '"></textarea></label>';
            submit_button($send_count > 0 ? __('Resend Review Link Email', 'vms-agreements') : __('Email Review Link to Vendor', 'vms-agreements'), 'primary', 'submit', false);
            echo '</form>';
        }
    }
    echo '</div>';
    echo '</div>';
}
function vmsa_render_admin_acknowledgement_summary(int $packet_id, array $acknowledgements, array $audit_records): void
{
    $latest = vmsa_get_latest_ack_record($packet_id);

    echo '<div class="vmsa-subcard" data-vms-tour="agreements.acknowledgements"><h3>' . esc_html__('Acknowledgements', 'vms-agreements') . '</h3>';
    if (empty($acknowledgements)) {
        echo '<p>' . esc_html__('No acknowledgements are configured on this template.', 'vms-agreements') . '</p>';
        echo '</div>';
        return;
    }

    $proof_by_key = array();
    if (!empty($latest['acknowledgements']) && is_array($latest['acknowledgements'])) {
        foreach ($latest['acknowledgements'] as $row) {
            if (is_array($row) && !empty($row['key'])) {
                $proof_by_key[(string) $row['key']] = $row;
            }
        }
    }

    echo '<ul class="vmsa-checklist">';
    foreach ($acknowledgements as $ack) {
        if (!is_array($ack)) {
            continue;
        }
        $key = (string) ($ack['key'] ?? '');
        $label = vmsa_display_text($ack['label'] ?? '');
        $proof = $key !== '' && isset($proof_by_key[$key]) ? (array) $proof_by_key[$key] : array();
        echo '<li>' . esc_html($label);
        if (!empty($proof)) {
            echo '<span>' . sprintf(
                esc_html__('Acknowledged %1$s by %2$s - IP: %3$s', 'vms-agreements'),
                esc_html(vmsa_format_audit_datetime((string) ($proof['acknowledged_at'] ?? ($latest['acknowledged_at'] ?? '')))),
                esc_html(vmsa_display_text($latest['signer_name'] ?? '-')),
                esc_html((string) ($latest['ip_address'] ?? '-'))
            ) . '</span>';
        } else {
            echo '<span>' . esc_html__('Not yet acknowledged', 'vms-agreements') . '</span>';
        }
        echo '</li>';
    }
    echo '</ul>';
    echo '</div>';
}

function vmsa_render_admin_audit_trail(int $packet_id, array $audit_records): void
{
    echo '<div class="vmsa-subcard" data-vms-tour="agreements.audit"><h3>' . esc_html__('Audit Trail', 'vms-agreements') . '</h3>';
    echo '<p><strong>' . esc_html__('Generated:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_format_audit_datetime((string) get_post_meta($packet_id, '_vmsa_generated_at', true))) . '</p>';

    $first_viewed = (string) get_post_meta($packet_id, '_vmsa_first_viewed_at', true);
    $last_viewed = (string) get_post_meta($packet_id, '_vmsa_last_viewed_at', true);
    $view_count = absint(get_post_meta($packet_id, '_vmsa_view_count', true));
    if ($first_viewed !== '') {
        echo '<p><strong>' . esc_html__('First viewed:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_format_audit_datetime($first_viewed)) . '</p>';
    }
    if ($last_viewed !== '') {
        echo '<p><strong>' . esc_html__('Last viewed:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_format_audit_datetime($last_viewed)) . '</p>';
    }
    if ($view_count > 0) {
        echo '<p><strong>' . esc_html__('Review link views:', 'vms-agreements') . '</strong> ' . esc_html((string) $view_count) . '</p>';
    }


    $email_records = vmsa_get_email_records($packet_id);
    if (!empty($email_records)) {
        echo '<div class="vmsa-email-record">';
        echo '<p><strong>' . esc_html__('Agreement emails:', 'vms-agreements') . '</strong> ' . esc_html((string) count($email_records)) . '</p>';
        foreach ($email_records as $email_record) {
            if (!is_array($email_record)) {
                continue;
            }
            $sent_ok = !empty($email_record['sent']);
            $type = sanitize_key((string) ($email_record['type'] ?? ''));
            $label_map = array(
                'acknowledgement_confirmation_email' => __('Acknowledgement confirmation email', 'vms-agreements'),
                'acknowledgement_operator_notification' => __('Operator signed notification email', 'vms-agreements'),
                'review_email' => __('Vendor review link email', 'vms-agreements'),
            );
            $label = $label_map[$type] ?? __('Vendor review link email', 'vms-agreements');
            $sent_by = absint($email_record['sent_by'] ?? 0);
            $sent_by_label = $sent_by > 0 ? sprintf(__('user #%s', 'vms-agreements'), (string) $sent_by) : __('system', 'vms-agreements');
            echo '<p>' . sprintf(
                esc_html__('%1$s: %2$s %3$s to %4$s - sent by %5$s', 'vms-agreements'),
                esc_html($label),
                $sent_ok ? esc_html__('Sent', 'vms-agreements') : esc_html__('Failed', 'vms-agreements'),
                esc_html(vmsa_format_audit_datetime((string) ($email_record['sent_at'] ?? ''))),
                esc_html((string) ($email_record['to'] ?? '-')),
                esc_html($sent_by_label)
            ) . '</p>';
            if (!$sent_ok && !empty($email_record['error'])) {
                echo '<p class="vmsa-warning-text">' . esc_html(vmsa_display_text($email_record['error'])) . '</p>';
            }
        }
        echo '</div>';
    }
    if (empty($audit_records)) {
        echo '<p>' . esc_html__('No vendor acknowledgement records have been captured yet.', 'vms-agreements') . '</p>';
        echo '</div>';
        return;
    }

    foreach ($audit_records as $record) {
        if (!is_array($record)) {
            continue;
        }
        echo '<div class="vmsa-audit-record">';
        echo '<p><strong>' . esc_html__('Acknowledged:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_format_audit_datetime((string) ($record['acknowledged_at'] ?? ''))) . '</p>';
        echo '<p><strong>' . esc_html__('Signer:', 'vms-agreements') . '</strong> ' . esc_html((string) ($record['signer_name'] ?? '-')) . ' &lt;' . esc_html((string) ($record['signer_email'] ?? '-')) . '&gt;</p>';
        echo '<p><strong>' . esc_html__('IP address:', 'vms-agreements') . '</strong> ' . esc_html((string) ($record['ip_address'] ?? '-')) . '</p>';
        echo '<p><strong>' . esc_html__('User account:', 'vms-agreements') . '</strong> ' . esc_html(absint($record['user_id'] ?? 0) > 0 ? (string) absint($record['user_id']) : __('Not logged in', 'vms-agreements')) . '</p>';
        echo '<p><strong>' . esc_html__('Agreement version:', 'vms-agreements') . '</strong> ' . esc_html((string) ($record['template_version'] ?? '-')) . '</p>';
        echo '<p><strong>' . esc_html__('Terms hash:', 'vms-agreements') . '</strong> <code>' . esc_html((string) ($record['terms_hash'] ?? '-')) . '</code></p>';
        echo '<p><strong>' . esc_html__('Compensation hash:', 'vms-agreements') . '</strong> <code>' . esc_html((string) ($record['comp_hash'] ?? '-')) . '</code></p>';
        echo '<p><strong>' . esc_html__('Browser:', 'vms-agreements') . '</strong> ' . esc_html((string) ($record['user_agent'] ?? '-')) . '</p>';
        echo '</div>';
    }
    echo '</div>';
}

function vmsa_repair_template_required_components(int $template_id): array
{
    $stored_blocks = get_post_meta($template_id, '_vmsa_template_blocks', true);
    $raw_blocks = is_array($stored_blocks) ? $stored_blocks : array();
    $raw_by_key = array();
    foreach ($raw_blocks as $raw_key => $raw_block) {
        if (!is_array($raw_block)) {
            continue;
        }
        $raw_block_key = isset($raw_block['key']) ? sanitize_key((string) $raw_block['key']) : sanitize_key((string) $raw_key);
        if ($raw_block_key !== '') {
            $raw_by_key[$raw_block_key] = $raw_block;
        }
    }

    $blocks = vmsa_sanitize_template_blocks(is_array($stored_blocks) ? $stored_blocks : array());
    $defaults = vmsa_template_block_defaults_by_key();
    $changed = false;

    foreach ($blocks as &$block) {
        if (!is_array($block)) {
            continue;
        }

        $key = (string) ($block['key'] ?? '');
        if ($key === '' || empty($defaults[$key]) || empty($defaults[$key]['required'])) {
            continue;
        }

        $raw = isset($raw_by_key[$key]) && is_array($raw_by_key[$key]) ? $raw_by_key[$key] : array();
        if (empty($raw)) {
            $changed = true;
        }
        if (isset($raw['enabled']) && empty($raw['enabled'])) {
            $changed = true;
        }
        if (isset($raw['title']) && trim((string) $raw['title']) === '') {
            $changed = true;
        }

        $default = (array) $defaults[$key];
        $default_title = (string) ($default['title'] ?? $default['label'] ?? $key);
        $default_body = (string) ($default['body'] ?? '');

        if (!empty($default['locked']) && isset($raw['body']) && (string) $raw['body'] !== $default_body) {
            $changed = true;
        }

        if (empty($block['enabled'])) {
            $block['enabled'] = true;
            $changed = true;
        }

        if (trim((string) ($block['title'] ?? '')) === '') {
            $block['title'] = $default_title;
            $changed = true;
        }

        if (!empty($default['locked'])) {
            if ((string) ($block['body'] ?? '') !== $default_body) {
                $block['body'] = $default_body;
                $changed = true;
            }
        } elseif (trim((string) ($block['body'] ?? '')) === '') {
            $block['body'] = $default_body;
            $changed = true;
        }
    }
    unset($block);

    $stored_acks = get_post_meta($template_id, '_vmsa_acknowledgements', true);
    $acks = vmsa_merge_required_template_acknowledgements(is_array($stored_acks) ? $stored_acks : array());
    $stored_acks_clean = array_values(array_filter(array_map('vmsa_sanitize_acknowledgement_row', is_array($stored_acks) ? $stored_acks : array())));
    if ($acks !== $stored_acks_clean) {
        $changed = true;
    }

    update_post_meta($template_id, '_vmsa_template_blocks', $blocks);
    update_post_meta($template_id, '_vmsa_template_body', vmsa_template_body_from_blocks_for_legacy($blocks));
    update_post_meta($template_id, '_vmsa_acknowledgements', $acks);

    if ($changed) {
        $current_version = (string) get_post_meta($template_id, '_vmsa_template_version', true);
        update_post_meta($template_id, '_vmsa_template_version', vmsa_bump_template_version($current_version));
    }

    update_post_meta($template_id, '_vmsa_template_updated_at', vmsa_current_datetime_mysql());
    update_post_meta($template_id, '_vmsa_template_updated_by', get_current_user_id());

    $payload = vmsa_get_template_payload($template_id);
    update_post_meta($template_id, '_vmsa_template_health', (array) ($payload['health'] ?? array()));

    return array(
        'changed' => $changed,
        'health' => (array) ($payload['health'] ?? array()),
    );
}

function vmsa_handle_repair_template_required_components(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to repair agreement templates.', 'vms-agreements'));
    }

    check_admin_referer('vmsa_repair_template_required_components');

    $template_id = isset($_POST['template_id']) ? absint($_POST['template_id']) : 0;
    if ($template_id <= 0 || get_post_type($template_id) !== VMSA_CPT_TEMPLATE) {
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => 'template_save_failed')));
        exit;
    }

    vmsa_repair_template_required_components($template_id);

    wp_safe_redirect(vmsa_admin_page_url(array(
        'vmsa_template' => $template_id,
        'vmsa_notice' => 'template_required_repaired',
    )));
    exit;
}


function vmsa_handle_save_template_blocks(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to edit agreement templates.', 'vms-agreements'));
    }

    check_admin_referer('vmsa_save_template_blocks');

    $template_id = isset($_POST['template_id']) ? absint($_POST['template_id']) : 0;
    if ($template_id <= 0 || get_post_type($template_id) !== VMSA_CPT_TEMPLATE) {
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => 'template_save_failed')));
        exit;
    }

    $posted_blocks = isset($_POST['vmsa_blocks']) && is_array($_POST['vmsa_blocks']) ? wp_unslash($_POST['vmsa_blocks']) : array();
    $blocks = vmsa_sanitize_template_blocks($posted_blocks);

    update_post_meta($template_id, '_vmsa_template_blocks', $blocks);
    update_post_meta($template_id, '_vmsa_template_body', vmsa_template_body_from_blocks_for_legacy($blocks));

    $current_version = (string) get_post_meta($template_id, '_vmsa_template_version', true);
    $new_version = vmsa_bump_template_version($current_version);
    update_post_meta($template_id, '_vmsa_template_version', $new_version);
    update_post_meta($template_id, '_vmsa_template_updated_at', vmsa_current_datetime_mysql());
    update_post_meta($template_id, '_vmsa_template_updated_by', get_current_user_id());

    $payload = vmsa_get_template_payload($template_id);
    $health = (array) ($payload['health'] ?? array());
    update_post_meta($template_id, '_vmsa_template_health', $health);
    $notice = vmsa_template_health_has_errors($health) ? 'template_saved_needs_attention' : 'template_saved';

    wp_safe_redirect(vmsa_admin_page_url(array(
        'vmsa_template' => $template_id,
        'vmsa_notice' => $notice,
    )));
    exit;
}

function vmsa_template_body_from_blocks_for_legacy(array $blocks): string
{
    $parts = array();
    foreach ($blocks as $block) {
        if (!is_array($block) || empty($block['enabled'])) {
            continue;
        }

        $title = trim((string) ($block['title'] ?? ''));
        $body = trim((string) ($block['body'] ?? ''));
        if ($title !== '') {
            $parts[] = $title;
        }
        if ($body !== '') {
            $parts[] = $body;
        }
    }

    return trim(implode("\n\n", $parts));
}

function vmsa_render_template_editor(int $template_id): void
{
    if ($template_id <= 0 || get_post_type($template_id) !== VMSA_CPT_TEMPLATE) {
        echo '<section class="vmsa-card vmsa-card-wide"><p>' . esc_html__('Template not found.', 'vms-agreements') . '</p></section>';
        return;
    }

    $template = vmsa_get_template_payload($template_id);
    $blocks = (array) ($template['blocks'] ?? array());
    $health = (array) ($template['health'] ?? array());

    echo '<section class="vmsa-card vmsa-card-wide vmsa-template-editor" data-vms-tour="agreements.template-editor">';
    echo '<div class="vmsa-template-editor-heading">';
    echo '<div>';
    echo '<h2>' . esc_html__('Template Block Editor', 'vms-agreements') . '</h2>';
    echo '<p class="description">' . esc_html__('Edit agreement wording in structured blocks. Required booking, compensation, deposit, acknowledgement, and audit components stay protected so generated packets remain trustworthy.', 'vms-agreements') . '</p>';
    echo '</div>';
    echo '<p><a class="button button-secondary" href="' . esc_url(vmsa_admin_page_url()) . '">' . esc_html__('Back to Agreement Packets', 'vms-agreements') . '</a></p>';
    echo '</div>';

    $health_counts = vmsa_template_health_severity_counts($health);
    $has_errors = vmsa_template_health_has_errors($health);
    $has_warnings = vmsa_template_health_has_warnings($health);

    echo '<div class="vmsa-template-health-panel vmsa-template-health-panel-' . esc_attr($has_errors ? 'error' : ($has_warnings ? 'warning' : 'success')) . '">';
    echo '<div class="vmsa-template-health-head">';
    echo '<div>';
    echo '<h3>' . esc_html__('Template Health Check', 'vms-agreements') . '</h3>';
    echo '<p><strong>' . esc_html__('Status:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_template_health_status_label($health)) . '</p>';
    if ($has_errors) {
        echo '<p class="vmsa-warning-text">' . esc_html__('Blocking errors prevent new agreement packets from being generated from this template until required components are repaired.', 'vms-agreements') . '</p>';
    } elseif ($has_warnings) {
        echo '<p class="description">' . esc_html__('Warnings do not block generation, but they should be reviewed before relying on the template for real vendor agreements.', 'vms-agreements') . '</p>';
    } else {
        echo '<p class="description">' . esc_html__('No blocking template errors were found. Required data blocks, required clauses, acknowledgement records, and audit disclosure concepts are present.', 'vms-agreements') . '</p>';
    }
    echo '</div>';
    echo '<div class="vmsa-template-health-actions">';
    echo '<span class="vmsa-badge vmsa-badge-' . esc_attr($has_errors ? 'danger' : 'success') . '">' . esc_html(sprintf(__('Errors: %d', 'vms-agreements'), (int) ($health_counts['error'] ?? 0))) . '</span>';
    echo '<span class="vmsa-badge vmsa-badge-' . esc_attr($has_warnings ? 'warning' : 'success') . '">' . esc_html(sprintf(__('Warnings: %d', 'vms-agreements'), (int) ($health_counts['warning'] ?? 0))) . '</span>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('vmsa_repair_template_required_components');
    echo '<input type="hidden" name="action" value="vmsa_repair_template_required_components">';
    echo '<input type="hidden" name="template_id" value="' . esc_attr((string) $template_id) . '">';
    submit_button(__('Repair Required Components', 'vms-agreements'), 'secondary', 'submit', false);
    echo '</form>';
    echo '</div>';
    echo '</div>';
    echo '<ul class="vmsa-template-health-list">';
    foreach ($health as $issue) {
        if (!is_array($issue)) {
            continue;
        }
        $severity = sanitize_key((string) ($issue['severity'] ?? 'warning'));
        echo '<li class="vmsa-health-' . esc_attr($severity) . '"><strong>' . esc_html(ucfirst($severity)) . ':</strong> ' . esc_html((string) ($issue['message'] ?? '')) . '</li>';
    }
    echo '</ul>';
    echo '</div>';

    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('vmsa_save_template_blocks');
    echo '<input type="hidden" name="action" value="vmsa_save_template_blocks">';
    echo '<input type="hidden" name="template_id" value="' . esc_attr((string) $template_id) . '">';

    echo '<div class="vmsa-template-meta">';
    echo '<p><strong>' . esc_html__('Template:', 'vms-agreements') . '</strong> ' . esc_html((string) ($template['title'] ?? '')) . '</p>';
    echo '<p><strong>' . esc_html__('Current version:', 'vms-agreements') . '</strong> ' . esc_html((string) ($template['version'] ?? '')) . '</p>';
    echo '<p class="description">' . esc_html__('Saving creates a new template patch version. Existing packets keep the exact version they were generated with.', 'vms-agreements') . '</p>';
    echo '</div>';

    foreach ($blocks as $block) {
        if (!is_array($block)) {
            continue;
        }

        vmsa_render_template_block_editor_row($block);
    }

    echo '<div class="vmsa-actions vmsa-template-save-actions">';
    submit_button(__('Save Template Blocks & Run Health Check', 'vms-agreements'), 'primary', 'submit', false);
    echo '<a class="button button-secondary" href="' . esc_url(vmsa_admin_page_url()) . '">' . esc_html__('Cancel', 'vms-agreements') . '</a>';
    echo '</div>';
    echo '</form>';
    echo '</section>';
}

function vmsa_render_template_block_editor_row(array $block): void
{
    $key = sanitize_key((string) ($block['key'] ?? ''));
    if ($key === '') {
        return;
    }

    $locked = !empty($block['locked']);
    $required = !empty($block['required']);
    $type = sanitize_key((string) ($block['type'] ?? 'clause'));
    $enabled = !empty($block['enabled']);
    $defaults = vmsa_template_block_defaults_by_key();
    $default = isset($defaults[$key]) && is_array($defaults[$key]) ? $defaults[$key] : array();
    $body = trim((string) ($block['body'] ?? ''));
    $default_body = trim((string) ($default['body'] ?? ''));
    $is_customized = !$locked && $body !== '' && $default_body !== '' && $body !== $default_body;
    $is_broken_required = $required && !$locked && $body === '';

    echo '<div class="vmsa-template-block vmsa-template-block-' . esc_attr($type) . '">';
    echo '<div class="vmsa-template-block-head">';
    echo '<div>';
    echo '<h3>' . esc_html((string) ($block['label'] ?? $key)) . '</h3>';
    echo '<p class="description">';
    echo $locked ? esc_html__('Protected block: source data is generated from the packet snapshot. You can rename the card title, but not remove the underlying data.', 'vms-agreements') : esc_html__('Editable clause block: customize this wording for your venue/operator needs.', 'vms-agreements');
    echo '</p>';
    echo '</div>';
    echo '<div class="vmsa-template-block-badges">';
    echo $required ? '<span class="vmsa-badge vmsa-badge-required">' . esc_html__('Required', 'vms-agreements') . '</span>' : '<span class="vmsa-badge">' . esc_html__('Optional', 'vms-agreements') . '</span>';
    echo $locked ? '<span class="vmsa-badge vmsa-badge-locked">' . esc_html__('Protected', 'vms-agreements') . '</span>' : '<span class="vmsa-badge">' . esc_html__('Editable', 'vms-agreements') . '</span>';
    if ($is_broken_required) {
        echo '<span class="vmsa-badge vmsa-badge-danger">' . esc_html__('Needs wording', 'vms-agreements') . '</span>';
    } elseif ($is_customized) {
        echo '<span class="vmsa-badge vmsa-badge-warning">' . esc_html__('Customized wording', 'vms-agreements') . '</span>';
    } elseif (!$locked && $enabled) {
        echo '<span class="vmsa-badge vmsa-badge-success">' . esc_html__('Stock wording', 'vms-agreements') . '</span>';
    } elseif (!$enabled) {
        echo '<span class="vmsa-badge">' . esc_html__('Disabled', 'vms-agreements') . '</span>';
    }
    echo '</div>';
    echo '</div>';

    echo '<input type="hidden" name="vmsa_blocks[' . esc_attr($key) . '][key]" value="' . esc_attr($key) . '">';

    if (!$required && !$locked) {
        echo '<label class="vmsa-template-enabled"><input type="checkbox" name="vmsa_blocks[' . esc_attr($key) . '][enabled]" value="1" ' . checked($enabled, true, false) . '> ' . esc_html__('Include this block in generated agreements', 'vms-agreements') . '</label>';
    } else {
        echo '<input type="hidden" name="vmsa_blocks[' . esc_attr($key) . '][enabled]" value="1">';
    }

    echo '<label>' . esc_html__('Card title', 'vms-agreements');
    echo '<input type="text" name="vmsa_blocks[' . esc_attr($key) . '][title]" value="' . esc_attr((string) ($block['title'] ?? '')) . '">';
    echo '</label>';

    if ($locked) {
        echo '<div class="vmsa-protected-block-note">' . esc_html((string) ($block['body'] ?? '')) . '</div>';
    } else {
        if ($is_broken_required) {
            echo '<p class="vmsa-template-inline-warning">' . esc_html__('This required clause is empty. New packet generation will be blocked until wording is restored.', 'vms-agreements') . '</p>';
        }
        echo '<label>' . esc_html__('Block wording', 'vms-agreements');
        echo '<textarea name="vmsa_blocks[' . esc_attr($key) . '][body]" rows="7">' . esc_textarea((string) ($block['body'] ?? '')) . '</textarea>';
        echo '</label>';
    }

    echo '</div>';
}

function vmsa_handle_save_email_templates(): void
{
    if (!vmsa_can_manage()) {
        wp_die(esc_html__('You do not have permission to edit agreement email templates.', 'vms-agreements'));
    }

    check_admin_referer('vmsa_save_email_templates');

    $template_id = isset($_POST['template_id']) ? absint($_POST['template_id']) : 0;
    if ($template_id <= 0 || get_post_type($template_id) !== VMSA_CPT_TEMPLATE) {
        wp_safe_redirect(vmsa_admin_page_url(array('vmsa_notice' => 'email_template_save_failed')));
        exit;
    }

    $posted = isset($_POST['vmsa_email_templates']) && is_array($_POST['vmsa_email_templates']) ? wp_unslash($_POST['vmsa_email_templates']) : array();
    $payload = vmsa_sanitize_email_template_payload($posted);
    update_post_meta($template_id, '_vmsa_email_templates', $payload);
    update_post_meta($template_id, '_vmsa_email_templates_updated_at', vmsa_current_datetime_mysql());
    update_post_meta($template_id, '_vmsa_email_templates_updated_by', get_current_user_id());
    update_post_meta($template_id, '_vmsa_email_templates_health', vmsa_email_template_health_check($payload));

    wp_safe_redirect(vmsa_admin_page_url(array(
        'vmsa_email_template' => $template_id,
        'vmsa_notice' => 'email_template_saved',
    )));
    exit;
}

function vmsa_render_email_template_editor(int $template_id): void
{
    if ($template_id <= 0 || get_post_type($template_id) !== VMSA_CPT_TEMPLATE) {
        echo '<section class="vmsa-card vmsa-card-wide"><p>' . esc_html__('Template not found.', 'vms-agreements') . '</p></section>';
        return;
    }

    $payload = vmsa_get_email_template_payload($template_id);
    $health = (array) ($payload['health'] ?? array());
    $tokens = vmsa_allowed_email_tokens();

    echo '<section class="vmsa-card vmsa-card-wide vmsa-email-template-editor" data-vms-tour="agreements.email-template-editor">';
    echo '<div class="vmsa-template-editor-heading">';
    echo '<div>';
    echo '<h2>' . esc_html__('Email Template Editor', 'vms-agreements') . '</h2>';
    echo '<p class="description">' . esc_html__('Customize the email copy for sending vendor review links, signer confirmations, and operator signed notifications. The review email must include the secure review link token.', 'vms-agreements') . '</p>';
    echo '</div>';
    echo '<p><a class="button button-secondary" href="' . esc_url(vmsa_admin_page_url()) . '">' . esc_html__('Back to Agreement Packets', 'vms-agreements') . '</a></p>';
    echo '</div>';

    echo '<div class="vmsa-template-health-panel">';
    echo '<h3>' . esc_html__('Email Template Health Check', 'vms-agreements') . '</h3>';
    echo '<p><strong>' . esc_html__('Status:', 'vms-agreements') . '</strong> ' . esc_html(vmsa_email_template_health_status_label($health)) . '</p>';
    echo '<ul class="vmsa-template-health-list">';
    foreach ($health as $issue) {
        if (!is_array($issue)) {
            continue;
        }
        $severity = sanitize_key((string) ($issue['severity'] ?? 'warning'));
        echo '<li class="vmsa-health-' . esc_attr($severity) . '"><strong>' . esc_html(ucfirst($severity)) . ':</strong> ' . esc_html((string) ($issue['message'] ?? '')) . '</li>';
    }
    echo '</ul>';
    echo '</div>';

    echo '<div class="vmsa-email-token-panel">';
    echo '<h3>' . esc_html__('Available Tokens', 'vms-agreements') . '</h3>';
    echo '<p class="description">' . esc_html__('Use these tokens in subject lines or message bodies. They will be replaced with packet-specific values when the email is sent.', 'vms-agreements') . '</p>';
    echo '<div class="vmsa-token-grid">';
    foreach ($tokens as $token => $description) {
        echo '<div><code>' . esc_html((string) $token) . '</code><span>' . esc_html((string) $description) . '</span></div>';
    }
    echo '</div>';
    echo '</div>';

    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('vmsa_save_email_templates');
    echo '<input type="hidden" name="action" value="vmsa_save_email_templates">';
    echo '<input type="hidden" name="template_id" value="' . esc_attr((string) $template_id) . '">';

    foreach (array('review', 'acknowledgement', 'operator_acknowledgement') as $key) {
        $email = isset($payload[$key]) && is_array($payload[$key]) ? $payload[$key] : array();
        echo '<div class="vmsa-template-block vmsa-email-template-block">';
        echo '<div class="vmsa-template-block-head">';
        echo '<div><h3>' . esc_html((string) ($email['label'] ?? $key)) . '</h3>';
        echo '<p class="description">' . esc_html((string) ($email['description'] ?? '')) . '</p></div>';
        if ($key === 'review') {
            echo '<div class="vmsa-template-block-badges"><span class="vmsa-badge vmsa-badge-required">' . esc_html__('Requires {review_link}', 'vms-agreements') . '</span></div>';
        }
        echo '</div>';
        echo '<label>' . esc_html__('Subject', 'vms-agreements');
        echo '<input type="text" name="vmsa_email_templates[' . esc_attr($key) . '][subject]" value="' . esc_attr((string) ($email['subject'] ?? '')) . '">';
        echo '</label>';
        echo '<label>' . esc_html__('Body', 'vms-agreements');
        echo '<textarea name="vmsa_email_templates[' . esc_attr($key) . '][body]" rows="12">' . esc_textarea((string) ($email['body'] ?? '')) . '</textarea>';
        echo '</label>';
        echo '</div>';
    }

    echo '<div class="vmsa-actions vmsa-template-save-actions">';
    submit_button(__('Save Email Templates & Run Health Check', 'vms-agreements'), 'primary', 'submit', false);
    echo '<a class="button button-secondary" href="' . esc_url(vmsa_admin_page_url()) . '">' . esc_html__('Cancel', 'vms-agreements') . '</a>';
    echo '</div>';
    echo '</form>';
    echo '</section>';
}
