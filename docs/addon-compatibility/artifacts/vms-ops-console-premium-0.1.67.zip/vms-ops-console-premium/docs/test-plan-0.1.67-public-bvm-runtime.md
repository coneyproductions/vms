# VMS Ops Console Premium 0.1.67 Test Plan

- Load with public Backstage Venue Manager 1.2.0 and no active historical VMS plugin.
- Confirm Ops menus/PWA and REST routes register.
- Confirm venue, event-plan, check-in-close, admissions, pass, and BVM admin helpers resolve through public APIs.
- Re-run the 0.1.66 season-pass scanner success-message checks and confirm PWA behavior remains unchanged by the compatibility bridge.
