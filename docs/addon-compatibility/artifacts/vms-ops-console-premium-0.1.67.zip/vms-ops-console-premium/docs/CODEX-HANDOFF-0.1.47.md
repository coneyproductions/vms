# VMS Ops Console Premium 0.1.47 — OPS scanner/readiness cleanup

## Scope

This pass updates the PWA/operator console only. It is intended to address show-night friction reported on iPhone/iPad devices:

- ID scanner opened too zoomed in, requiring IDs to be held several feet away.
- Camera permission appeared to re-prompt too often during a session.
- Log In could be tapped before venue/bootstrap readiness, causing a confusing “select venue” failure while no venues were visible yet.
- Top/bottom duplicate user name display was cluttered.
- ID Console layout had unnecessary Details/debug UI and extra visual clutter.
- Collapsed sections on iPad stayed too tall.

## Files changed

- `vms-ops-console-premium.php`
- `pwa/assets/js/app.js`
- `pwa/assets/css/app.css`
- `vms-build.txt`
- `docs/CODEX-HANDOFF-0.1.47.md`
- `docs/test-plan-0.1.47-ops-scanner-readiness.md`

## Implementation notes

### Camera / ID scanner

- ID scanner zoom no longer defaults to a high zoom value.
- When `MediaStreamTrack` zoom capability exists, ID scan startup applies normal `1x` when it is within range; otherwise it falls back to the minimum supported zoom value.
- Existing Zoom +/- controls remain available.
- Added a `Zoom 1x` reset button for supported ID scanner cameras.
- The active camera stream is kept warm after closing the scanner while the operator remains logged in, reducing same-session camera permission prompts on browsers/devices that re-prompt when a track is stopped.
- Warm camera stream is cleared on logout/auth loss/page unload.

### Login / venue readiness

- Header Log In button now starts disabled as `Connecting…`.
- Button remains disabled until bootstrap/venue/device readiness is complete.
- If no venue is selected after bootstrap, button shows `Select Venue` and remains disabled instead of allowing an early confusing login attempt.

### ID Console cleanup

- Removed top header display-name line; bottom WP chip remains.
- 21+ cutoff note moved above ID scan controls.
- Scan ID button now has a stronger blue primary treatment.
- Details/debug textarea is hidden by default and only appears when `?vms_ops_debug=1` is present.
- Empty feedback elements are hidden to reduce phantom dark/blank UI blocks.
- Manual Member Creation is restricted to manager/admin capability (`manageAdmin`) rather than the broader lite member-management capability.

### iPad collapsed panels

- Collapsed panels override the tablet min-height so sections are slimmer when closed.

## Deployment note

Install as the canonical plugin folder:

`vms-ops-console-premium/`

Do not install as a parallel versioned folder.
