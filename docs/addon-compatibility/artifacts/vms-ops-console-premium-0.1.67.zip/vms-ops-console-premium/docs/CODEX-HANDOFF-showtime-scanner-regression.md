# Showtime Scanner Regression

## Root Cause

The shutdown branch was server-side check-in window enforcement:

- `includes/ticket-console/checkin.php`
- `vms_ops_ticket_checkin_assert_window()`

Before this fix, that path parsed `event['end_at']` and, when `checkin_close_at` was absent, derived scanner close time directly from `end_at`:

```php
$event_end = vms_ops_parse_wp_datetime((string) ($event['end_at'] ?? ''));
$closes = vms_ops_ticket_apply_post_show_buffer($event_end);
```

If `end_at` collapsed onto showtime, `closes` also became showtime. That made the scanner return `checkin_closed` at `T` even though the valid check-in period should have continued after showtime.

Why all scanners failed together:

- every scanner shared the same event timing
- the shared server-side gate flipped at the same boundary
- the failure was deterministic at `now >= derived close time`

Why prior fixes were incomplete:

- prior logic still anchored scanner close to the same `end_at` field
- there was no canonical operational end/check-in close resolver
- some event shapes, especially collapsed `end_at == start_at`, still treated showtime as the terminal boundary

## Code Changes

Canonical timing/eligibility:

- `includes/ticket-console/eligibility.php`
- added `vms_ops_ticket_resolve_operational_event_end()`
- added `vms_ops_ticket_get_scanner_eligibility()`
- default fallback duration is now explicit and separate from showtime

Event payloads:

- `includes/ticket-console/events.php`
- event schedule resolution now prefers real event-plan start/end metadata
- collapsed or invalid ends are corrected to an operational end
- scanner payloads now include explicit `checkin_open_at` and `checkin_close_at`
- event filtering now uses explicit close timestamps, not raw `end_at` alone

Server check-in gate:

- `includes/ticket-console/checkin.php`
- `vms_ops_ticket_checkin_assert_window()` now resolves operational event end before deriving close time
- pass-claim end resolution now uses the same canonical resolver
- scanner-close diagnostics now log explicit reasons and timing context

Client diagnostics:

- `pwa/assets/js/app.js`
- all scanner teardown paths now emit explicit lifecycle reasons
- lifecycle records include timing/status/session context for future incidents

## Test Coverage

PHP:

- `tests/php/test-scanner-eligibility.php`
- proves eligibility at `T-60`, `T-15`, `T-1s`, `T`, `T+1s`, `T+15m`, `T+60m`
- proves showtime does not close scanning while check-in is open
- proves live/started/in_progress statuses remain scannable
- proves scanner session expiry is independent from showtime

- `tests/php/test-scanner-checkin-window.php`
- hits the exact server shutdown branch in `vms_ops_ticket_checkin_assert_window()`
- uses a collapsed `end_at == showtime` fixture
- proves the scanner remains allowed at `T-1s`, `T`, `T+1s`, `T+15m`, `T+60m`
- proves closure happens only after the derived check-in close time

Browser:

- `../vms-dev/tests/e2e/ops10-showtime-scanner.spec.ts`
- proves scanner stays mounted through a showtime event refresh/status transition
- proves attendee refresh at showtime does not close the scanner
- proves three staggered scanner clients remain usable before, at, and after showtime

## Failure Mode Matrix

- Showtime closes check-in: FOUND
  - exact branch: `vms_ops_ticket_checkin_assert_window()` deriving close from collapsed `end_at`
- Upcoming-only scanner status: NOT FOUND
  - no `status !== "upcoming" => scanner unavailable` shutdown branch was found
- One-hour scanner TTL: NOT FOUND
  - no scanner token/session expiry tied to showtime was found
- Polling/refresh teardown: NOT FOUND as root cause
  - refreshes were a likely trigger surface, but the deterministic shutdown came from server window logic
- API/server rejection: FOUND
  - server returned closed-window behavior when `end_at` collapsed to showtime
- Database/RLS rejection: NOT FOUND
  - this plugin does not use Supabase/RLS policies for scanner authorization
- Timezone bug: NOT FOUND
  - the reproduced failure did not depend on timezone misparsing

## Manual Verification Checklist

Use a test event with:

- timezone: `America/Chicago`
- check-in opens: `T - 60m`
- showtime: `T`
- check-in closes: `T + 120m`

Checklist:

1. Open scanner at `T - 15m`.
2. Confirm a valid scan works.
3. Verify scanner still works at `T - 1m`.
4. Verify scanner remains open and camera stays active at `T`.
5. Trigger event refresh and attendee refresh at `T`.
6. Verify no redirect or scanner teardown occurs.
7. Scan a valid ticket at `T`.
8. Scan again at `T + 1m` and `T + 15m`.
9. Verify multiple concurrent scanners remain active across `T`.
10. Verify closure happens only after the configured check-in close time.
