# Test Plan — VMS Ops Console Premium 0.1.47

## Version/package checks

1. Confirm plugin header shows `Version: 0.1.47`.
2. Confirm `VMS_OPS_CONSOLE_VERSION` is `0.1.47`.
3. Confirm `vms-build.txt` says `Version: 0.1.47`.
4. Confirm PWA JS/CSS asset URLs use `?ver=0.1.47` after activation.
5. Confirm package installs into `vms-ops-console-premium/`, not a parallel folder.

## Login/bootstrap readiness

1. Clear site/PWA cache or open a private browser session.
2. Open `/vms-ops/` on staging.
3. Before bootstrap completes, confirm the header button is disabled and says `Connecting…`.
4. Confirm tapping the button early cannot produce a “please select venue”/venue-required error.
5. After bootstrap finishes with one configured venue, confirm the venue is auto-selected and the button enables as `Log In`.
6. If testing multiple/no venues, confirm the button stays disabled as `Select Venue` until a venue is selected.
7. Log in and confirm panels appear normally.
8. Log out and confirm scanner/camera state is cleared.

## ID scanner zoom behavior

Test on the actual iPhone/iPad used at the gate if possible.

1. Log in to OPS.
2. Open ID Console.
3. Tap `Scan ID`.
4. Confirm camera opens at normal/1x or the minimum supported zoom, not the previous over-zoomed setting.
5. Confirm an ID can be scanned at a normal handheld distance.
6. If zoom controls appear, tap `Zoom +` and confirm zoom increases.
7. Tap `Zoom -` and confirm zoom decreases.
8. Tap `Zoom 1x` and confirm it resets to normal/minimum supported zoom.
9. Close and reopen scanner during the same OPS login session.
10. Confirm camera does not re-open at the prior zoomed-in value.

## Camera permission/session reuse

1. During one logged-in OPS session, open and close the scanner several times.
2. Confirm the browser does not repeatedly prompt for camera permission when the same session remains active.
3. Confirm scanner still opens after several close/reopen cycles.
4. Log out or close the browser/PWA.
5. Confirm a new session still handles browser permission prompts normally according to the device/browser.

Note: iOS/Safari ultimately controls persistent camera permissions. This patch keeps the active stream warm during the OPS session to reduce repeated prompts, but cannot force indefinite OS/browser permission persistence.

## ID Console cleanup

1. Confirm the top header shows `VMS Ops Console` only, without the extra display-name line.
2. Confirm the bottom WP chip still shows the logged-in WP user and logout link.
3. In ID Console, confirm `21+ cutoff today` appears directly under the `ID Console` heading.
4. Confirm `Scan ID` has stronger primary styling.
5. Confirm the `Details` panel is not visible by default.
6. Open `/vms-ops/?vms_ops_debug=1` as an authorized user and confirm `Details / Testing` appears.
7. Confirm the dark/blank block previously seen in the ID Console is no longer visible when no scan/result feedback exists.
8. Confirm `Manual Member Creation` is visible only for users with manager/admin member-management capability.

## iPad/tablet layout

1. On iPad-width viewport, log in.
2. Collapse Ticket Console, ID Console, and Member Lookup.
3. Confirm collapsed cards are slim and do not retain the large open-panel height.
4. Expand each section and confirm normal full contents return.

## Regression checks

1. Ticket scanner still opens and scans tickets.
2. ID scanner still processes PDF417 payloads.
3. Member lookup still searches and opens member details.
4. Alert Staff button/panel still works for users with alert capability.
5. Offline/weak network behavior has no new fatal JS errors in the browser console.
