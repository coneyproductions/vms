# Codex Handoff — VMS Ops Console Premium 0.1.56

## Build under test

- Plugin header: `0.1.56`
- `VMS_OPS_CONSOLE_VERSION`: `0.1.56`
- `vms-build.txt`: `0.1.56`

## Change summary

- Fixes the Showtime scanner shutdown path by separating showtime from check-in close.
- Scanner payloads now prefer explicit `checkin_close_at` values from TEC or linked Event Plans.
- Check-in API gates honor explicit `checkin_close_at` and log explicit close reasons.

## Files changed

- `vms-ops-console-premium.php`
- `includes/ticket-console/eligibility.php`
- `includes/ticket-console/checkin.php`
- `includes/ticket-console/events.php`
- `pwa/assets/js/app.js`
- `vms-build.txt`

## Verification

- `php tests/php/test-scanner-eligibility.php`
- `php tests/php/test-scanner-checkin-window.php`
- `php tests/php/test-checkin-close-persistence.php`
- `node node_modules/@playwright/test/cli.js test --config playwright.config.ts tests/e2e/ops10-showtime-scanner.spec.ts --project=chromium`
