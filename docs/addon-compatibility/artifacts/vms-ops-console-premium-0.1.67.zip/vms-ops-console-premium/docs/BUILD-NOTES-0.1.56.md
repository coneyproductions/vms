# VMS Ops Console Premium 0.1.56 — Showtime scanner and explicit check-in close

## Purpose

This build closes the Showtime scanner failure path and aligns scanner runtime decisions with explicit check-in close windows.

## Changes

- Scanner eligibility and API gates no longer treat showtime as scanner close.
- Scanner runtime prefers explicit `checkin_close_at` values when present and only falls back to canonical operational event-end logic when explicit close is absent.
- Added structured scanner close diagnostics so future shutdowns carry an explicit reason and timing context.

## Files changed

- `vms-ops-console-premium.php`
- `includes/ticket-console/eligibility.php`
- `includes/ticket-console/checkin.php`
- `includes/ticket-console/events.php`
- `pwa/assets/js/app.js`
- `vms-build.txt`
