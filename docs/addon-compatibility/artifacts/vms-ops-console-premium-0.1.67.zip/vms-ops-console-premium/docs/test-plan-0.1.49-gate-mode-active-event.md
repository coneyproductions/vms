# Test Plan — VMS Ops Console Premium 0.1.49

## A. Version/package checks

1. Install/activate the package in the canonical `vms-ops-console-premium` plugin folder.
2. Confirm the plugin header shows `Version: 0.1.49`.
3. Confirm `VMS_OPS_CONSOLE_VERSION` is `0.1.49`.
4. Confirm `vms-build.txt` says `Version: 0.1.49`.
5. Open `/vms-ops/` and confirm app JS/CSS asset URLs use `?ver=0.1.49`.
6. Clear/reload the PWA/service worker cache if the browser keeps serving the prior shell.

## B. Active event confirmation gate

1. Log in with a ticket-scanning user.
2. Confirm the Event picker still auto-selects a likely event after venue/login load.
3. Confirm the new **Active event** card appears and shows the selected event title/date/details.
4. Before confirmation, verify these are disabled:
   - ticket scan text input;
   - Scan Ticket camera button;
   - Check In button.
5. Click **Confirm & Start Scanning**.
6. Confirm the card changes to a ready/confirmed state and scan controls become available.
7. Click **Change Event**.
8. Confirm scan controls become disabled again until the newly selected event is confirmed.

## C. Confirmation persistence / reload recovery

1. Confirm an active event.
2. Reload the Ops Console.
3. Confirm the same event is still selected and treated as confirmed for the same user/venue/site day.
4. Change the selected event and confirm the app requires confirmation again.
5. If possible, test with two same-day events and confirm a confirmed later same-day event survives reload.

## D. Attendee cache and offline readiness

1. Confirm an active event with no existing local attendee cache.
2. Confirm the card initially shows Limited Offline or equivalent no-cache guidance.
3. Confirming the event should trigger attendee caching.
4. After caching, confirm the card shows **Offline Ready** and includes cached attendee count / timestamp detail.
5. Use browser offline/network throttling after caching and confirm the card reflects the cached/offline-ready state.
6. Clear local storage for attendees and repeat offline mode; confirm the card indicates online required/no usable offline cache.

## E. Recent-purchase / ticket-not-found retry

1. Confirm active event and cache attendees.
2. Add or simulate a ticket/guest-list reference that was not in the local cache at first load.
3. Scan/submit that ticket.
4. Confirm the first not-found condition triggers a silent attendee refresh and one retry before showing an error.
5. Confirm a genuinely invalid ticket still fails after the retry and does not loop indefinitely.

## F. Wrong-event guard

1. Confirm Event A.
2. Scan a valid ticket for Event B if the QR includes event metadata.
3. Confirm the app switches only through the existing wrong-event handling and does not silently scan against the wrong event without visible active-event context.
4. Confirm the Active Event card reflects any switched event and confirmation state correctly.

## G. ID scanned-member add

1. Log in as an ID-scanning user who does not have full member-admin rights.
2. Scan an ID that is not yet in the member table.
3. Confirm the not-found prompt shows the scanned name/DOB/member number.
4. Confirm the user can add the scanned member from the prompt.
5. Confirm the full manual member creation form is still hidden unless the user has member manager/lite capability.
6. Attempt a direct `/id/manual-member` request without `scan_payload` as that same user and confirm it is rejected.
7. Confirm the added member can be re-scanned and found.

## H. Smoke checks

1. Confirm Ticket Console, ID Console, Member Lookup, Alert Staff, and Presence/login still render normally for allowed users.
2. Confirm PHP lint passes on changed PHP files.
3. Confirm `node --check pwa/assets/js/app.js` passes.
4. Confirm zip integrity passes with `zip -T`.
