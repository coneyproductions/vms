# VMS Ops Console Premium 0.1.49 — Gate Mode follow-up fixes

## Purpose

This follow-up build keeps the 0.1.48 gate-mode hardening and repairs two issues found during validation:

- same-day reload recovery could drop a confirmed non-default event when multiple same-day events existed;
- scanned-ID member add loosened the `/id/manual-member` endpoint too broadly for `scan_ids` users.

## Changes

### Same-day confirmed-event recovery

- Login/default event selection now preserves the operator's already-confirmed same-day event when that event is still valid for the current site day.
- The app still prefers the current/imminent event over stale persisted selections when the confirmed event is not for today.
- This keeps reload recovery safe without forcing staff to re-confirm the same later same-day event after a refresh.

### Scanned-ID member add permission tightening

- ID-scanning staff can still add a not-found member directly from the scanned-ID prompt.
- Scan-only users must now provide the raw scanned ID payload when creating that member.
- The server derives the created member fields from the scanned payload for scan-only users instead of trusting arbitrary manual request fields.
- Full manual member creation remains restricted to member manager/lite roles and `manage_options`.

## Files changed

- `vms-ops-console-premium.php`
- `pwa/assets/js/app.js`
- `includes/rest/routes.php`
- `vms-build.txt`

## Notes / follow-up backlog

- A true manager PIN override is still not implemented.
- Offline ticket validation still only works for attendees already cached on the device.
- Real show-night validation is still required for PWA cache behavior, mobile Safari sleep/resume, and live WordPress session/nonce timing.
