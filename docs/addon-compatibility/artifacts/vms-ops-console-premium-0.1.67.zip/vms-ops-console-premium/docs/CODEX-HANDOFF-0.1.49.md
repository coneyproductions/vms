# Codex Handoff — VMS Ops Console Premium 0.1.49

## Build under test

Package: `vms-ops-console-premium-0.1.49.zip`

Confirm version markers:

- plugin header: `0.1.49`
- `VMS_OPS_CONSOLE_VERSION`: `0.1.49`
- `vms-build.txt`: `0.1.49`
- PWA JS/CSS URLs include `?ver=0.1.49`

## Main regression targets

1. Active event selection must remain explicit and scan-gated.
2. Same-day confirmed-event reload recovery must survive multiple same-day-event scenarios when the confirmed event is still today's intended event.
3. Recent-purchase cache miss should still trigger one attendee refresh + retry.
4. Offline readiness should still reflect whether local attendees are cached.
5. ID scan staff should still be able to add a scanned not-found member from the scan prompt.
6. Full manual member creation must remain role-limited even though scan-only users can complete the scanned-ID add flow.

## Suggested testing notes

Run the focused test plan on staging/mobile if available. The key follow-up checks for this build are:

- confirm Event B on a day with multiple same-day events, reload, and verify Event B stays selected/confirmed;
- confirm an ID-scan-only user can add a member from the scan prompt but cannot use arbitrary manual-member requests outside that flow.
