<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_admin_can_view_scan_history')) {
    function vms_ops_admin_can_view_scan_history(): bool
    {
        if (function_exists('vms_ops_admin_current_user_can_manage')) {
            return vms_ops_admin_current_user_can_manage();
        }

        return current_user_can('manage_options');
    }
}

if (!function_exists('vms_ops_admin_scan_history_manage_capability')) {
    function vms_ops_admin_scan_history_manage_capability(): string
    {
        if (function_exists('vms_ops_admin_manage_capability')) {
            return vms_ops_admin_manage_capability();
        }

        return 'manage_options';
    }
}

	if (!function_exists('vms_ops_admin_register_scan_history_submenu')) {
	    function vms_ops_admin_register_scan_history_submenu(): void
	    {
	        add_submenu_page(
	            null,
	            __('ID Scan History', 'vms-ops-console-premium'),
	            __('ID Scans', 'vms-ops-console-premium'),
	            vms_ops_admin_scan_history_manage_capability(),
	            'vms-ops-console-id-scans',
            'vms_ops_admin_render_id_scans_page'
        );
    }
}
add_action('admin_menu', 'vms_ops_admin_register_scan_history_submenu', 30);

if (!function_exists('vms_ops_admin_scan_history_result_label')) {
    function vms_ops_admin_scan_history_result_label(string $code): string
    {
        $code = sanitize_key($code);
        $labels = array(
            'processed' => __('Processed', 'vms-ops-console-premium'),
            'member_not_found' => __('Member Not Found', 'vms-ops-console-premium'),
            'suspended' => __('Suspended', 'vms-ops-console-premium'),
            'banned' => __('Banned', 'vms-ops-console-premium'),
        );

        return $labels[$code] ?? ($code !== '' ? ucwords(str_replace('_', ' ', $code)) : __('Unknown', 'vms-ops-console-premium'));
    }
}

if (!function_exists('vms_ops_admin_scan_history_badge_class')) {
    function vms_ops_admin_scan_history_badge_class(string $code): string
    {
        $code = sanitize_key($code);
        if ($code === '') {
            return 'is-neutral';
        }

        return 'is-' . $code;
    }
}

if (!function_exists('vms_ops_admin_scan_history_page_url')) {
    function vms_ops_admin_scan_history_page_url(array $filters = array(), array $extra = array()): string
    {
        $query = array_merge(array(
            'page' => 'vms-ops-console-id-scans',
        ), $filters, $extra);

        return add_query_arg($query, admin_url('admin.php'));
    }
}

if (!function_exists('vms_ops_admin_scan_history_render_hidden_filter_fields')) {
    function vms_ops_admin_scan_history_render_hidden_filter_fields(array $filters, array $skip = array()): void
    {
        foreach ($filters as $key => $value) {
            if ($key === 'paged' || $key === 'page_num' || in_array($key, $skip, true)) {
                continue;
            }
            printf(
                '<input type="hidden" name="%1$s" value="%2$s">',
                esc_attr((string) $key),
                esc_attr(is_scalar($value) ? (string) $value : '')
            );
        }
    }
}

if (!function_exists('vms_ops_admin_render_scan_history_payload_items')) {
    function vms_ops_admin_render_scan_history_payload_items(array $items): void
    {
        if (empty($items)) {
            echo '<p>' . esc_html__('No enriched payload details were stored for this scan.', 'vms-ops-console-premium') . '</p>';
            return;
        }

        echo '<dl class="vms-ops-scan-history-meta-list">';
        foreach ($items as $item) {
            $label = (string) ($item['label'] ?? '');
            $value = (string) ($item['value'] ?? '');
            if ($label === '' || $value === '') {
                continue;
            }

            echo '<div class="vms-ops-scan-history-meta-row">';
            echo '<dt>' . esc_html($label) . '</dt>';
            echo '<dd>' . esc_html($value) . '</dd>';
            echo '</div>';
        }
        echo '</dl>';
    }
}

if (!function_exists('vms_ops_admin_render_id_scans_page')) {
    function vms_ops_admin_render_id_scans_page(): void
    {
        if (!vms_ops_admin_can_view_scan_history()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        $filters = vms_ops_pc_scan_log_normalize_filters((array) $_GET);
        $rows = vms_ops_pc_scan_log_get_rows($filters, (int) $filters['per_page'], (int) $filters['page_num']);
        $total = vms_ops_pc_scan_log_get_total($filters);
        $scanner_options = vms_ops_pc_scan_log_get_scanner_options();
        $venues = function_exists('vms_ops_get_venues_list') ? vms_ops_get_venues_list() : array();
        $total_pages = max(1, (int) ceil($total / max(1, (int) $filters['per_page'])));

        $detail_row = null;
        $scan_log_id = isset($_GET['scan_log_id']) ? absint((string) $_GET['scan_log_id']) : 0;
        if ($scan_log_id > 0) {
            $detail_row = vms_ops_pc_scan_log_get_row($scan_log_id);
        }

        $pagination_filters = $filters;
        unset($pagination_filters['page_num']);
        $pagination = paginate_links(array(
            'base' => add_query_arg(array_merge($pagination_filters, array('paged' => '%#%')), admin_url('admin.php?page=vms-ops-console-id-scans')),
            'format' => '',
            'current' => max(1, (int) $filters['page_num']),
            'total' => $total_pages,
            'prev_text' => __('&laquo; Previous', 'vms-ops-console-premium'),
            'next_text' => __('Next &raquo;', 'vms-ops-console-premium'),
            'type' => 'list',
        ));

        $result_options = array(
            '' => __('All Results', 'vms-ops-console-premium'),
            'processed' => __('Processed', 'vms-ops-console-premium'),
            'member_not_found' => __('Member Not Found', 'vms-ops-console-premium'),
            'suspended' => __('Suspended', 'vms-ops-console-premium'),
            'banned' => __('Banned', 'vms-ops-console-premium'),
        );
        ?>
        <div class="wrap vms-ops-scan-history-page">
            <div class="vms-ops-scan-history-head" data-tour-anchor="purpose">
                <div>
                    <h1><?php esc_html_e('ID Scan History', 'vms-ops-console-premium'); ?></h1>
                    <p class="description">
                        <?php esc_html_e('Review recent ID scans, blocked scans, and member-not-found attempts without digging through the database.', 'vms-ops-console-premium'); ?>
                    </p>
                </div>
                <div class="vms-ops-scan-history-head-actions" data-tour-anchor="export">
                    <button type="button" class="button button-secondary" data-vms-ops-scan-tour-start>
                        <?php esc_html_e('Start Guided Tour', 'vms-ops-console-premium'); ?>
                    </button>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <?php wp_nonce_field('vms_ops_export_scan_log_csv'); ?>
                        <input type="hidden" name="action" value="vms_ops_export_scan_log_csv">
                        <?php vms_ops_admin_scan_history_render_hidden_filter_fields($filters); ?>
                        <button type="submit" class="button button-primary"><?php esc_html_e('Export CSV', 'vms-ops-console-premium'); ?></button>
                    </form>
                </div>
            </div>

            <?php if ($scan_log_id > 0 && !$detail_row) : ?>
                <div class="notice notice-warning inline"><p><?php esc_html_e('That scan record could not be found.', 'vms-ops-console-premium'); ?></p></div>
            <?php endif; ?>

            <form method="get" class="vms-ops-scan-history-filters" data-tour-anchor="filters">
                <input type="hidden" name="page" value="vms-ops-console-id-scans">
                <label>
                    <span><?php esc_html_e('Date From', 'vms-ops-console-premium'); ?></span>
                    <input type="date" name="date_from" value="<?php echo esc_attr((string) $filters['date_from']); ?>">
                </label>
                <label>
                    <span><?php esc_html_e('Date To', 'vms-ops-console-premium'); ?></span>
                    <input type="date" name="date_to" value="<?php echo esc_attr((string) $filters['date_to']); ?>">
                </label>
                <label>
                    <span><?php esc_html_e('Venue', 'vms-ops-console-premium'); ?></span>
                    <select name="venue_id">
                        <option value="0"><?php esc_html_e('All Venues', 'vms-ops-console-premium'); ?></option>
                        <?php foreach ($venues as $venue) :
                            $venue_id = (int) ($venue['id'] ?? 0);
                            if ($venue_id <= 0) {
                                continue;
                            }
                            ?>
                            <option value="<?php echo esc_attr((string) $venue_id); ?>"<?php selected((int) $filters['venue_id'], $venue_id); ?>>
                                <?php echo esc_html((string) ($venue['name'] ?? ('Venue #' . $venue_id))); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>
                    <span><?php esc_html_e('Result', 'vms-ops-console-premium'); ?></span>
                    <select name="result_code">
                        <?php foreach ($result_options as $value => $label) : ?>
                            <option value="<?php echo esc_attr($value); ?>"<?php selected((string) $filters['result_code'], $value); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>
                    <span><?php esc_html_e('Scanner', 'vms-ops-console-premium'); ?></span>
                    <select name="scanner_user_id">
                        <option value="0"><?php esc_html_e('All Scanners', 'vms-ops-console-premium'); ?></option>
                        <?php foreach ($scanner_options as $scanner) : ?>
                            <option value="<?php echo esc_attr((string) ($scanner['id'] ?? 0)); ?>"<?php selected((int) $filters['scanner_user_id'], (int) ($scanner['id'] ?? 0)); ?>>
                                <?php echo esc_html((string) ($scanner['label'] ?? '')); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label data-tour-anchor="member-lookup">
                    <span><?php esc_html_e('Member Lookup', 'vms-ops-console-premium'); ?></span>
                    <input type="text" name="member_lookup" value="<?php echo esc_attr((string) $filters['member_lookup']); ?>" placeholder="<?php esc_attr_e('Member number, name, or scan reference', 'vms-ops-console-premium'); ?>">
                </label>
                <label>
                    <span><?php esc_html_e('Console Type', 'vms-ops-console-premium'); ?></span>
                    <select name="console_type">
                        <option value="id"<?php selected((string) $filters['console_type'], 'id'); ?>><?php esc_html_e('ID', 'vms-ops-console-premium'); ?></option>
                        <option value="all"<?php selected((string) $filters['console_type'], 'all'); ?>><?php esc_html_e('All', 'vms-ops-console-premium'); ?></option>
                    </select>
                </label>
                <label>
                    <span><?php esc_html_e('Per Page', 'vms-ops-console-premium'); ?></span>
                    <select name="per_page">
                        <option value="25"<?php selected((int) $filters['per_page'], 25); ?>>25</option>
                        <option value="50"<?php selected((int) $filters['per_page'], 50); ?>>50</option>
                        <option value="100"<?php selected((int) $filters['per_page'], 100); ?>>100</option>
                    </select>
                </label>
                <div class="vms-ops-scan-history-filter-actions">
                    <button type="submit" class="button button-primary"><?php esc_html_e('Apply Filters', 'vms-ops-console-premium'); ?></button>
                    <a class="button" href="<?php echo esc_url(vms_ops_admin_scan_history_page_url(vms_ops_pc_scan_log_default_filters())); ?>">
                        <?php esc_html_e('Reset', 'vms-ops-console-premium'); ?>
                    </a>
                </div>
            </form>

            <?php if (is_array($detail_row)) : ?>
                <section class="vms-ops-scan-history-detail" data-tour-anchor="detail">
                    <div class="vms-ops-scan-history-detail-head">
                        <h2><?php esc_html_e('Scan Detail', 'vms-ops-console-premium'); ?></h2>
                        <a class="button" href="<?php echo esc_url(vms_ops_admin_scan_history_page_url($filters)); ?>"><?php esc_html_e('Close Detail', 'vms-ops-console-premium'); ?></a>
                    </div>
                    <div class="vms-ops-scan-history-detail-grid">
                        <div>
                            <h3><?php esc_html_e('Scan Summary', 'vms-ops-console-premium'); ?></h3>
                            <dl class="vms-ops-scan-history-meta-list">
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Scanned', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) $detail_row['created_at_display']); ?></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Result', 'vms-ops-console-premium'); ?></dt><dd><span class="vms-ops-scan-history-badge <?php echo esc_attr(vms_ops_admin_scan_history_badge_class((string) $detail_row['result_code'])); ?>"><?php echo esc_html(vms_ops_admin_scan_history_result_label((string) $detail_row['result_code'])); ?></span></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Venue', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) $detail_row['venue_label']); ?></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Scanner', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) $detail_row['scanner_display_name']); ?></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Member', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) $detail_row['member_name']); ?></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Member Number', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) ($detail_row['member_number'] ?: '—')); ?></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Member Status', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) ($detail_row['member_status'] ?: '—')); ?></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('DOB / Age', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) ($detail_row['date_of_birth'] ?: '—')); ?><?php echo $detail_row['age_years'] !== null ? esc_html(' • Age ' . (string) $detail_row['age_years']) : ''; ?></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Event', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) ($detail_row['event_title'] ?: '—')); ?></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Scan Reference', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) ($detail_row['scan_reference'] ?: '—')); ?></dd></div>
                                <div class="vms-ops-scan-history-meta-row"><dt><?php esc_html_e('Result Message', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html((string) ($detail_row['result_message'] ?: '—')); ?></dd></div>
                            </dl>
                        </div>
                        <div>
                            <h3><?php esc_html_e('Payload Details', 'vms-ops-console-premium'); ?></h3>
                            <?php vms_ops_admin_render_scan_history_payload_items((array) ($detail_row['payload_meta_items'] ?? array())); ?>
                        </div>
                    </div>
                </section>
            <?php endif; ?>

            <section class="vms-ops-scan-history-results" data-tour-anchor="results">
                <div class="vms-ops-scan-history-results-head">
                    <h2><?php esc_html_e('Results', 'vms-ops-console-premium'); ?></h2>
                    <p class="description">
                        <?php
                        printf(
                            /* translators: %s: row count */
                            esc_html__('%s matching scans.', 'vms-ops-console-premium'),
                            esc_html(number_format_i18n($total))
                        );
                        ?>
                    </p>
                </div>

                <?php if (empty($rows)) : ?>
                    <div class="notice notice-info inline">
                        <p><?php esc_html_e('No ID scan rows matched these filters. Adjust the date range, venue, or member lookup and try again.', 'vms-ops-console-premium'); ?></p>
                    </div>
                <?php else : ?>
                    <table class="widefat striped vms-ops-scan-history-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('Scanned', 'vms-ops-console-premium'); ?></th>
                                <th><?php esc_html_e('Result', 'vms-ops-console-premium'); ?></th>
                                <th><?php esc_html_e('Member', 'vms-ops-console-premium'); ?></th>
                                <th><?php esc_html_e('Age', 'vms-ops-console-premium'); ?></th>
                                <th><?php esc_html_e('Scanner', 'vms-ops-console-premium'); ?></th>
                                <th><?php esc_html_e('Venue', 'vms-ops-console-premium'); ?></th>
                                <th><?php esc_html_e('Notes', 'vms-ops-console-premium'); ?></th>
                                <th><?php esc_html_e('Actions', 'vms-ops-console-premium'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $row) : ?>
                                <tr>
                                    <td><?php echo esc_html((string) ($row['created_at_display'] ?? '—')); ?></td>
                                    <td>
                                        <span class="vms-ops-scan-history-badge <?php echo esc_attr(vms_ops_admin_scan_history_badge_class((string) ($row['result_code'] ?? ''))); ?>">
                                            <?php echo esc_html(vms_ops_admin_scan_history_result_label((string) ($row['result_code'] ?? ''))); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong><?php echo esc_html((string) ($row['member_name'] ?? '—')); ?></strong>
                                        <div class="vms-ops-scan-history-sub"><?php echo esc_html((string) (($row['member_number'] ?? '') !== '' ? $row['member_number'] : '—')); ?></div>
                                        <?php if (!empty($row['member_status'])) : ?>
                                            <div class="vms-ops-scan-history-sub"><?php echo esc_html((string) $row['member_status']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html((string) ($row['age_display'] ?? '—')); ?></td>
                                    <td><?php echo esc_html((string) ($row['scanner_display_name'] ?? '—')); ?></td>
                                    <td><?php echo esc_html((string) ($row['venue_label'] ?? '—')); ?></td>
                                    <td><?php echo esc_html((string) (($row['notes'] ?? '') !== '' ? $row['notes'] : '—')); ?></td>
                                    <td>
                                        <a class="button button-small" href="<?php echo esc_url(vms_ops_admin_scan_history_page_url($filters, array('scan_log_id' => (int) ($row['id'] ?? 0)))); ?>">
                                            <?php esc_html_e('View', 'vms-ops-console-premium'); ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <?php if (!empty($pagination)) : ?>
                    <div class="tablenav bottom">
                        <?php echo wp_kses_post($pagination); ?>
                    </div>
                <?php endif; ?>
            </section>
        </div>
        <?php
    }
}

if (!function_exists('vms_ops_admin_handle_export_scan_log_csv')) {
    function vms_ops_admin_handle_export_scan_log_csv(): void
    {
        if (!vms_ops_admin_can_view_scan_history()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        check_admin_referer('vms_ops_export_scan_log_csv');

        $filters = vms_ops_pc_scan_log_normalize_filters((array) $_POST);
        $rows = vms_ops_pc_scan_log_export_rows($filters);

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="vms-id-scan-history-' . gmdate('Y-m-d-His') . '.csv"');

        $output = fopen('php://output', 'w');
        if ($output === false) {
            exit;
        }

        fputcsv($output, array(
            'scan_log_id',
            'scanned_at',
            'venue',
            'console_type',
            'scan_type',
            'result_code',
            'result_message',
            'member_id',
            'member_number',
            'member_name',
            'member_status',
            'date_of_birth',
            'age',
            'scanner_user_id',
            'scanner_name',
            'event_id',
            'event_title',
            'scan_reference',
        ));

        foreach ($rows as $row) {
            fputcsv($output, array(
                (int) ($row['id'] ?? 0),
                (string) ($row['created_at_display'] ?? ''),
                (string) ($row['venue_label'] ?? ''),
                (string) ($row['console_type'] ?? ''),
                (string) ($row['scan_type'] ?? ''),
                (string) ($row['result_code'] ?? ''),
                (string) ($row['result_message'] ?? ''),
                (int) ($row['member_id'] ?? 0),
                (string) ($row['member_number'] ?? ''),
                (string) ($row['member_name'] ?? ''),
                (string) ($row['member_status'] ?? ''),
                (string) ($row['date_of_birth'] ?? ''),
                $row['age_years'] !== null ? (string) $row['age_years'] : '',
                (int) ($row['scanner_user_id'] ?? 0),
                (string) ($row['scanner_display_name'] ?? ''),
                (int) ($row['event_id'] ?? 0),
                (string) ($row['event_title'] ?? ''),
                (string) ($row['scan_reference'] ?? ''),
            ));
        }

        fclose($output);
        exit;
    }
}
add_action('admin_post_vms_ops_export_scan_log_csv', 'vms_ops_admin_handle_export_scan_log_csv');
