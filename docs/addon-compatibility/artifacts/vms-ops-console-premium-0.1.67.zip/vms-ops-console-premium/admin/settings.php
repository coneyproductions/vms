<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_sanitize_settings')) {
    function vms_ops_sanitize_settings($input): array
    {
        $defaults = function_exists('vms_ops_default_settings') ? vms_ops_default_settings() : array();
        $input = is_array($input) ? $input : array();
        $member_lookup_dob_policy = sanitize_key((string) ($input['member_lookup_dob_policy'] ?? ''));
        if (!in_array($member_lookup_dob_policy, array('always', 'no_photo', 'never_for_active_verified'), true)) {
            $member_lookup_dob_policy = !empty($input['member_lookup_require_dob_entry'])
                ? 'always'
                : sanitize_key((string) ($defaults['member_lookup_dob_policy'] ?? 'no_photo'));
        }
        if (!in_array($member_lookup_dob_policy, array('always', 'no_photo', 'never_for_active_verified'), true)) {
            $member_lookup_dob_policy = 'no_photo';
        }

        return array(
            'presence_timeout_seconds' => max(60, min(3600, (int) ($input['presence_timeout_seconds'] ?? ($defaults['presence_timeout_seconds'] ?? 180)))),
            'post_show_scan_buffer_hours' => max(0, min(12, (int) ($input['post_show_scan_buffer_hours'] ?? ($defaults['post_show_scan_buffer_hours'] ?? 4)))),
            'ticket_reopen_past_events_enabled' => !empty($input['ticket_reopen_past_events_enabled']) ? 1 : 0,
            'ticket_reopen_past_events_days' => max(0, min(30, (int) ($input['ticket_reopen_past_events_days'] ?? ($defaults['ticket_reopen_past_events_days'] ?? 3)))),
            'default_birthday_window_days' => max(0, min(45, (int) ($input['default_birthday_window_days'] ?? ($defaults['default_birthday_window_days'] ?? 7)))),
            'anniversary_lock_days' => max(0, min(365, (int) ($input['anniversary_lock_days'] ?? ($defaults['anniversary_lock_days'] ?? 30)))),
            'banned_clear_hold_seconds' => max(1, min(10, (int) ($input['banned_clear_hold_seconds'] ?? ($defaults['banned_clear_hold_seconds'] ?? 3)))),
            'default_venue_id' => max(0, (int) ($input['default_venue_id'] ?? ($defaults['default_venue_id'] ?? 0))),
            'member_lookup_enabled' => !empty($input['member_lookup_enabled']) ? 1 : 0,
            'member_lookup_dob_policy' => $member_lookup_dob_policy,
            'member_lookup_require_dob_entry' => $member_lookup_dob_policy === 'always' ? 1 : 0,
            'member_lookup_require_confidence' => !empty($input['member_lookup_require_confidence']) ? 1 : 0,
            'member_lookup_freshness_days' => in_array((int) ($input['member_lookup_freshness_days'] ?? ($defaults['member_lookup_freshness_days'] ?? 365)), array(0, 30, 90, 180, 365), true)
                ? (int) ($input['member_lookup_freshness_days'] ?? ($defaults['member_lookup_freshness_days'] ?? 365))
                : (int) ($defaults['member_lookup_freshness_days'] ?? 365),
            'member_lookup_allow_profile_photo' => !empty($input['member_lookup_allow_profile_photo']) ? 1 : 0,
            'member_lookup_profile_photo_upload_mode' => in_array(
                sanitize_key((string) ($input['member_lookup_profile_photo_upload_mode'] ?? ($defaults['member_lookup_profile_photo_upload_mode'] ?? 'enabled'))),
                array('enabled', 'managers_only', 'disabled'),
                true
            )
                ? sanitize_key((string) ($input['member_lookup_profile_photo_upload_mode'] ?? ($defaults['member_lookup_profile_photo_upload_mode'] ?? 'enabled')))
                : 'enabled',
            'member_lookup_dob_display' => (($input['member_lookup_dob_display'] ?? ($defaults['member_lookup_dob_display'] ?? 'full')) === 'masked') ? 'masked' : 'full',
            'member_lookup_require_photo_recheck' => !empty($input['member_lookup_require_photo_recheck']) ? 1 : 0,
            'member_lookup_audit_logging' => 1,
        );
    }
}

if (!function_exists('vms_ops_parse_venue_settings_lines')) {
    function vms_ops_parse_venue_settings_lines(string $text): array
    {
        $rows = preg_split('/\r\n|\r|\n/', trim($text));
        if (!is_array($rows)) {
            return array();
        }

        $out = array();
        foreach ($rows as $row) {
            $row = trim($row);
            if ($row === '') {
                continue;
            }

            $parts = array_map('trim', explode('|', $row));
            if (count($parts) < 1) {
                continue;
            }

            $venue_id = absint((string) ($parts[0] ?? '0'));
            if ($venue_id <= 0) {
                continue;
            }

            $birthday_window_days = isset($parts[1]) ? max(0, min(45, (int) $parts[1])) : null;
            $anniversary_lock_days = isset($parts[2]) ? max(0, min(365, (int) $parts[2])) : null;

            $out[$venue_id] = array_filter(array(
                'birthday_window_days' => $birthday_window_days,
                'anniversary_lock_days' => $anniversary_lock_days,
            ), static function ($value): bool {
                return $value !== null;
            });
        }

        return $out;
    }
}

if (!function_exists('vms_ops_sanitize_venue_settings')) {
    function vms_ops_sanitize_venue_settings($input): array
    {
        if (is_array($input)) {
            $output = array();

            // Accept either:
            // 1) Map keyed by venue_id => settings, OR
            // 2) List rows like [ ['venue_id'=>123,'birthday_window_days'=>...,'anniversary_lock_days'=>...], ... ]
            $is_list = array_keys($input) === range(0, count($input) - 1);

            foreach ($input as $venue_key => $settings) {
                if (!is_array($settings)) {
                    continue;
                }

                $venue_id = $is_list
                    ? absint((string) ($settings['venue_id'] ?? '0'))
                    : absint((string) $venue_key);

                if ($venue_id <= 0) {
                    continue;
                }

                $output[$venue_id] = array_filter(array(
                    'birthday_window_days' => isset($settings['birthday_window_days']) ? max(0, min(45, (int) $settings['birthday_window_days'])) : null,
                    'anniversary_lock_days' => isset($settings['anniversary_lock_days']) ? max(0, min(365, (int) $settings['anniversary_lock_days'])) : null,
                ), static function ($value): bool {
                    return $value !== null;
                });
            }
            return $output;
        }

        if (is_string($input)) {
            return vms_ops_parse_venue_settings_lines($input);
        }

        return array();
    }
}

if (!function_exists('vms_ops_get_settings')) {
    function vms_ops_get_settings(): array
    {
        $defaults = function_exists('vms_ops_default_settings') ? vms_ops_default_settings() : array();
        $stored = get_option('vms_ops_settings', array());
        $stored = is_array($stored) ? $stored : array();

        return vms_ops_sanitize_settings(array_merge($defaults, $stored));
    }
}

if (!function_exists('vms_ops_get_venue_settings')) {
    function vms_ops_get_venue_settings(): array
    {
        $stored = get_option('vms_ops_venue_settings', array());
        return vms_ops_sanitize_venue_settings($stored);
    }
}

if (!function_exists('vms_ops_get_venue_setting')) {
    function vms_ops_get_venue_setting(int $venue_id, string $key, $fallback = null)
    {
        $per_venue = vms_ops_get_venue_settings();
        if ($venue_id > 0 && isset($per_venue[$venue_id]) && is_array($per_venue[$venue_id]) && array_key_exists($key, $per_venue[$venue_id])) {
            return $per_venue[$venue_id][$key];
        }

        $settings = vms_ops_get_settings();
        $global_key_map = array(
            'birthday_window_days' => 'default_birthday_window_days',
            'anniversary_lock_days' => 'anniversary_lock_days',
        );

        if (isset($global_key_map[$key]) && array_key_exists($global_key_map[$key], $settings)) {
            return $settings[$global_key_map[$key]];
        }

        return $fallback;
    }
}

if (!function_exists('vms_ops_render_venue_settings_lines')) {
    function vms_ops_render_venue_settings_lines(array $settings): string
    {
        $lines = array();
        foreach ($settings as $venue_id => $row) {
            if (!is_array($row)) {
                continue;
            }
            $lines[] = implode('|', array(
                (int) $venue_id,
                isset($row['birthday_window_days']) ? (int) $row['birthday_window_days'] : '',
                isset($row['anniversary_lock_days']) ? (int) $row['anniversary_lock_days'] : '',
            ));
        }

        return implode("\n", $lines);
    }
}

if (!function_exists('vms_ops_admin_register_menu')) {
    function vms_ops_admin_register_menu(): void
    {
        $parent = apply_filters('vms_admin_parent_slug', 'vms-dashboard');
        $parent = sanitize_text_field((string) $parent);
        if ($parent === '') {
            $parent = 'vms-dashboard';
        }

        add_submenu_page(
            $parent,
            __('VMS Ops Console', 'vms-ops-console-premium'),
            __('VMS Ops Console', 'vms-ops-console-premium'),
            'manage_options',
            'vms-ops-console',
            'vms_ops_admin_render_settings_page'
        );
    }
}
// Admin menu entries are owned by VMS core hubs (vms-ops-console-hub, vms-teams, vms-alert-presets).
// This plugin provides the renderers and assets.
if (!function_exists('vms_ops_admin_remove_legacy_top_level_menu')) {
    function vms_ops_admin_remove_legacy_top_level_menu(): void
    {
        remove_menu_page('vms-ops-console');
    }
}
if (!function_exists('vms_ops_admin_register_settings')) {
    function vms_ops_admin_register_settings(): void
    {
        register_setting('vms_ops_settings_group', 'vms_ops_settings', array(
            'type' => 'array',
            'sanitize_callback' => 'vms_ops_sanitize_settings',
            'default' => vms_ops_default_settings(),
        ));

        register_setting('vms_ops_settings_group', 'vms_ops_venue_settings', array(
            'type' => 'array',
            'sanitize_callback' => 'vms_ops_sanitize_venue_settings',
            'default' => array(),
        ));
    }
}
add_action('admin_init', 'vms_ops_admin_register_settings');

if (!function_exists('vms_ops_admin_render_settings_page')) {
    function vms_ops_admin_render_settings_page(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        $settings = vms_ops_get_settings();
        $venue_settings = vms_ops_get_venue_settings();

        $venues = function_exists('vms_ops_get_venues_list') ? vms_ops_get_venues_list() : array();
        $default_venue_selected = (int) ($settings['default_venue_id'] ?? 0);
        if ($default_venue_selected <= 0 && count($venues) === 1) {
            $default_venue_selected = (int) ($venues[0]['id'] ?? 0);
        }
	        ?>
	        <div class="wrap vms-ops-settings-page">
	            <div class="vms-ops-page-head" data-tour-anchor="settings-intro">
	                <div>
	                    <h1><?php esc_html_e('VMS Ops Console Settings', 'vms-ops-console-premium'); ?></h1>
	                    <p class="description"><?php esc_html_e('Ops event visibility and scanner cutoffs now follow WordPress site time. Use the post-show buffer to keep late-night events available for closeout scanning without changing the actual event dates.', 'vms-ops-console-premium'); ?></p>
	                </div>
	                <button type="button" class="button button-secondary" data-vms-ops-settings-tour-start><?php esc_html_e('Start Settings Tour', 'vms-ops-console-premium'); ?></button>
	            </div>
	            <?php if (function_exists('vms_ops_admin_can_view_scan_history') && vms_ops_admin_can_view_scan_history()) : ?>
	                <div class="vms-ops-admin-shortcuts">
	                    <div>
	                        <h2><?php esc_html_e('Ops Console Admin Tools', 'vms-ops-console-premium'); ?></h2>
	                        <p class="description">
	                            <?php esc_html_e('Open manager-only tools that sit under the VMS Ops Console workflow without adding extra left-menu links.', 'vms-ops-console-premium'); ?>
	                        </p>
	                    </div>
	                    <div class="vms-ops-admin-shortcuts-actions">
                            <?php if (function_exists('vms_ops_admin_current_user_can_manage_members') && vms_ops_admin_current_user_can_manage_members()) : ?>
                                <a class="button button-secondary" href="<?php echo esc_url(admin_url('admin.php?page=vms-ops-console-members')); ?>">
                                    <?php esc_html_e('Open Members', 'vms-ops-console-premium'); ?>
                                </a>
                            <?php endif; ?>
	                        <a class="button button-secondary" href="<?php echo esc_url(admin_url('admin.php?page=vms-ops-console-id-scans')); ?>">
	                            <?php esc_html_e('Open ID Scan History', 'vms-ops-console-premium'); ?>
	                        </a>
	                    </div>
	                </div>
	            <?php endif; ?>
	            <form method="post" action="options.php">
	                <?php settings_fields('vms_ops_settings_group'); ?>
	                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="vms_ops_presence_timeout_seconds"><?php esc_html_e('Presence Timeout (seconds)', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input id="vms_ops_presence_timeout_seconds" name="vms_ops_settings[presence_timeout_seconds]" type="number" min="60" max="3600" value="<?php echo esc_attr((string) (int) $settings['presence_timeout_seconds']); ?>">
                        </td>
                    </tr>
                    <tr data-tour-anchor="scan-buffer">
                        <th scope="row"><label for="vms_ops_post_show_scan_buffer_hours"><?php esc_html_e('Post-Show Scan Buffer (Hours)', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input id="vms_ops_post_show_scan_buffer_hours" name="vms_ops_settings[post_show_scan_buffer_hours]" type="number" min="0" max="12" value="<?php echo esc_attr((string) (int) $settings['post_show_scan_buffer_hours']); ?>">
                            <p class="description"><?php esc_html_e('Ended events remain available for ticket and guest-list scanning until this many site-time hours after the saved event end time. Set to 0 to keep the immediate cutoff while still following WordPress site time.', 'vms-ops-console-premium'); ?></p>
                        </td>
                    </tr>
                    <tr data-tour-anchor="reopen-past-events">
                        <th scope="row"><label for="vms_ops_ticket_reopen_past_events_enabled"><?php esc_html_e('Reopen Past Events For Testing', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <label>
                                <input id="vms_ops_ticket_reopen_past_events_enabled" name="vms_ops_settings[ticket_reopen_past_events_enabled]" type="checkbox" value="1" <?php checked(!empty($settings['ticket_reopen_past_events_enabled'])); ?>>
                                <?php esc_html_e('Allow recently ended events to reappear in the Ticket Console after the normal post-show buffer so staff can run a real check-in test on older tickets.', 'vms-ops-console-premium'); ?>
                            </label>
                            <p class="description"><?php esc_html_e('Use this only when you need to prove a ticket checker can complete a real scan/check-in flow. Disable it again after testing.', 'vms-ops-console-premium'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_ticket_reopen_past_events_days"><?php esc_html_e('Past Event Reopen Window (Days)', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input id="vms_ops_ticket_reopen_past_events_days" name="vms_ops_settings[ticket_reopen_past_events_days]" type="number" min="0" max="30" value="<?php echo esc_attr((string) (int) $settings['ticket_reopen_past_events_days']); ?>">
                            <p class="description"><?php esc_html_e('Keep eligible past events selectable for this many days after the normal post-show scan buffer closes. Set to 0 to disable the reopen window even if the checkbox above is on.', 'vms-ops-console-premium'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_default_birthday_window_days"><?php esc_html_e('Default Birthday Window (days)', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input id="vms_ops_default_birthday_window_days" name="vms_ops_settings[default_birthday_window_days]" type="number" min="0" max="45" value="<?php echo esc_attr((string) (int) $settings['default_birthday_window_days']); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_anniversary_lock_days"><?php esc_html_e('Anniversary Lock (days)', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input id="vms_ops_anniversary_lock_days" name="vms_ops_settings[anniversary_lock_days]" type="number" min="0" max="365" value="<?php echo esc_attr((string) (int) $settings['anniversary_lock_days']); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_banned_clear_hold_seconds"><?php esc_html_e('Banned Screen Hold-to-Clear (seconds)', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input id="vms_ops_banned_clear_hold_seconds" name="vms_ops_settings[banned_clear_hold_seconds]" type="number" min="1" max="10" value="<?php echo esc_attr((string) (int) $settings['banned_clear_hold_seconds']); ?>">
                        </td>
                    </tr>
                    <tr data-tour-anchor="default-venue">
                        <th scope="row"><label for="vms_ops_default_venue_id"><?php esc_html_e('Default Venue', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <select id="vms_ops_default_venue_id" name="vms_ops_settings[default_venue_id]">
                                <option value="0"><?php esc_html_e('— None —', 'vms-ops-console-premium'); ?></option>
                                <?php foreach ($venues as $venue) :
                                    $vid = (int) ($venue['id'] ?? 0);
                                    if ($vid <= 0) {
                                        continue;
                                    }
                                    ?>
                                    <option value="<?php echo esc_attr((string) $vid); ?>"<?php selected($default_venue_selected, $vid); ?>><?php echo esc_html((string) ($venue['name'] ?? ('Venue #' . $vid))); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php esc_html_e('Used when the console is opened without an explicit venue selection.', 'vms-ops-console-premium'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_venue_settings"><?php esc_html_e('Per-Venue Overrides', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <table class="widefat striped vms-ops-admin-table vms-ops-admin-venue-overrides">
                                <thead>
                                    <tr>
                                        <th><?php esc_html_e('Venue', 'vms-ops-console-premium'); ?></th>
                                        <th><?php esc_html_e('Birthday Window (days)', 'vms-ops-console-premium'); ?></th>
                                        <th><?php esc_html_e('Anniversary Lock (days)', 'vms-ops-console-premium'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $rows = array();
                                foreach ((array) $venue_settings as $venue_id => $row) {
                                    if (!is_array($row)) {
                                        continue;
                                    }
                                    $rows[] = array(
                                        'venue_id' => (int) $venue_id,
                                        'birthday_window_days' => isset($row['birthday_window_days']) ? (int) $row['birthday_window_days'] : '',
                                        'anniversary_lock_days' => isset($row['anniversary_lock_days']) ? (int) $row['anniversary_lock_days'] : '',
                                    );
                                }

                                $blank_rows = 3;
                                $total = max(count($rows), 0) + $blank_rows;
                                for ($i = 0; $i < $total; $i++) :
                                    $row = $rows[$i] ?? array('venue_id' => '', 'birthday_window_days' => '', 'anniversary_lock_days' => '');
                                    ?>
                                    <tr>
                                        <td>
                                            <select name="vms_ops_venue_settings[<?php echo (int) $i; ?>][venue_id]">
                                                <option value=""><?php esc_html_e('— Select venue —', 'vms-ops-console-premium'); ?></option>
                                                <?php foreach ($venues as $venue) :
                                                    $vid = (int) ($venue['id'] ?? 0);
                                                    if ($vid <= 0) {
                                                        continue;
                                                    }
                                                    ?>
                                                    <option value="<?php echo esc_attr((string) $vid); ?>"<?php selected((int) ($row['venue_id'] ?? 0), $vid); ?>><?php echo esc_html((string) ($venue['name'] ?? ('Venue #' . $vid))); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td><input type="number" min="0" max="45" step="1" name="vms_ops_venue_settings[<?php echo (int) $i; ?>][birthday_window_days]" value="<?php echo esc_attr((string) ($row['birthday_window_days'] ?? '')); ?>" placeholder="7"></td>
                                        <td><input type="number" min="0" max="365" step="1" name="vms_ops_venue_settings[<?php echo (int) $i; ?>][anniversary_lock_days]" value="<?php echo esc_attr((string) ($row['anniversary_lock_days'] ?? '')); ?>" placeholder="30"></td>
                                    </tr>
                                <?php endfor; ?>
                                </tbody>
                            </table>

                            <details class="vms-ops-admin-advanced">
                                <summary><?php esc_html_e('Advanced: raw editor', 'vms-ops-console-premium'); ?></summary>
                                <textarea id="vms_ops_venue_settings" rows="8" cols="60" readonly><?php echo esc_textarea(vms_ops_render_venue_settings_lines($venue_settings)); ?></textarea>
                                <p class="description"><?php esc_html_e('Read-only snapshot in legacy pipe format (kept for debugging).', 'vms-ops-console-premium'); ?></p>
                            </details>
                        </td>
                    </tr>
                    <tr data-tour-anchor="member-lookup-settings">
                        <th scope="row"><?php esc_html_e('Verified Member Lookup', 'vms-ops-console-premium'); ?></th>
                        <td>
                            <p class="description"><?php esc_html_e('This tool is designed as a convenience path for recognized returning members. It does not replace your responsibility to verify age and membership when there is uncertainty.', 'vms-ops-console-premium'); ?></p>
                            <p class="description"><?php echo esc_html(function_exists('vms_ops_member_lookup_policy_text') ? vms_ops_member_lookup_policy_text() : __('Verified Member Lookup is for known, active, previously verified members. Staff should confirm DOB and use lookup only when they are confident they have the right person. Recheck ID whenever there is uncertainty.', 'vms-ops-console-premium')); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_member_lookup_enabled"><?php esc_html_e('Enable Verified Member Lookup', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input type="hidden" name="vms_ops_settings[member_lookup_enabled]" value="0">
                            <label><input id="vms_ops_member_lookup_enabled" name="vms_ops_settings[member_lookup_enabled]" type="checkbox" value="1" <?php checked(!empty($settings['member_lookup_enabled'])); ?>> <?php esc_html_e('Show the standalone Member Lookup workflow in Ops for users with the dedicated capability.', 'vms-ops-console-premium'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_member_lookup_dob_policy"><?php esc_html_e('Verified Lookup DOB Policy', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <select id="vms_ops_member_lookup_dob_policy" name="vms_ops_settings[member_lookup_dob_policy]">
                                <option value="always"<?php selected((string) ($settings['member_lookup_dob_policy'] ?? ''), 'always'); ?>><?php esc_html_e('Always require DOB', 'vms-ops-console-premium'); ?></option>
                                <option value="no_photo"<?php selected((string) ($settings['member_lookup_dob_policy'] ?? 'no_photo'), 'no_photo'); ?>><?php esc_html_e('Require DOB only when no profile photo exists', 'vms-ops-console-premium'); ?></option>
                                <option value="never_for_active_verified"<?php selected((string) ($settings['member_lookup_dob_policy'] ?? ''), 'never_for_active_verified'); ?>><?php esc_html_e('Never require DOB for active verified members', 'vms-ops-console-premium'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('Recommended: require DOB only when no profile photo exists. A stored profile photo can confirm the same already age-verified member, but blocked or stale members should still go to Check ID Now.', 'vms-ops-console-premium'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_member_lookup_require_confidence"><?php esc_html_e('Require Confidence Confirmation', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input type="hidden" name="vms_ops_settings[member_lookup_require_confidence]" value="0">
                            <label><input id="vms_ops_member_lookup_require_confidence" name="vms_ops_settings[member_lookup_require_confidence]" type="checkbox" value="1" <?php checked(!empty($settings['member_lookup_require_confidence'])); ?>> <?php esc_html_e('Require the bartender to explicitly confirm they confidently recognize the member before the service action is enabled.', 'vms-ops-console-premium'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_member_lookup_freshness_days"><?php esc_html_e('Verification Freshness Window', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <select id="vms_ops_member_lookup_freshness_days" name="vms_ops_settings[member_lookup_freshness_days]">
                                <option value="30"<?php selected((int) ($settings['member_lookup_freshness_days'] ?? 365), 30); ?>><?php esc_html_e('30 days', 'vms-ops-console-premium'); ?></option>
                                <option value="90"<?php selected((int) ($settings['member_lookup_freshness_days'] ?? 365), 90); ?>><?php esc_html_e('90 days', 'vms-ops-console-premium'); ?></option>
                                <option value="180"<?php selected((int) ($settings['member_lookup_freshness_days'] ?? 365), 180); ?>><?php esc_html_e('180 days', 'vms-ops-console-premium'); ?></option>
                                <option value="365"<?php selected((int) ($settings['member_lookup_freshness_days'] ?? 365), 365); ?>><?php esc_html_e('365 days', 'vms-ops-console-premium'); ?></option>
                                <option value="0"<?php selected((int) ($settings['member_lookup_freshness_days'] ?? 365), 0); ?>><?php esc_html_e('Never auto-stale', 'vms-ops-console-premium'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('When prior verification is older than this threshold, Ops will push staff to recheck ID instead of serving via lookup.', 'vms-ops-console-premium'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_member_lookup_allow_profile_photo"><?php esc_html_e('Allow Optional Member Profile Photo', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input type="hidden" name="vms_ops_settings[member_lookup_allow_profile_photo]" value="0">
                            <label><input id="vms_ops_member_lookup_allow_profile_photo" name="vms_ops_settings[member_lookup_allow_profile_photo]" type="checkbox" value="1" <?php checked(!empty($settings['member_lookup_allow_profile_photo'])); ?>> <?php esc_html_e('Allow a consent-aware profile photo to help staff recognize known members faster. This is not an ID image archive.', 'vms-ops-console-premium'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_member_lookup_profile_photo_upload_mode"><?php esc_html_e('Profile Photo Upload Mode', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <select id="vms_ops_member_lookup_profile_photo_upload_mode" name="vms_ops_settings[member_lookup_profile_photo_upload_mode]">
                                <option value="enabled"<?php selected((string) ($settings['member_lookup_profile_photo_upload_mode'] ?? 'enabled'), 'enabled'); ?>><?php esc_html_e('Enabled for member-photo staff', 'vms-ops-console-premium'); ?></option>
                                <option value="managers_only"<?php selected((string) ($settings['member_lookup_profile_photo_upload_mode'] ?? ''), 'managers_only'); ?>><?php esc_html_e('Managers only during peak mode', 'vms-ops-console-premium'); ?></option>
                                <option value="disabled"<?php selected((string) ($settings['member_lookup_profile_photo_upload_mode'] ?? ''), 'disabled'); ?>><?php esc_html_e('Disable uploads during peak mode', 'vms-ops-console-premium'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('Use this when the line is moving fast and you want to reduce live image-processing load. Existing photos still display even when uploads are limited.', 'vms-ops-console-premium'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_member_lookup_dob_display"><?php esc_html_e('DOB Display For Lookup Staff', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <select id="vms_ops_member_lookup_dob_display" name="vms_ops_settings[member_lookup_dob_display]">
                                <option value="full"<?php selected((string) ($settings['member_lookup_dob_display'] ?? 'full'), 'full'); ?>><?php esc_html_e('Full DOB', 'vms-ops-console-premium'); ?></option>
                                <option value="masked"<?php selected((string) ($settings['member_lookup_dob_display'] ?? 'full'), 'masked'); ?>><?php esc_html_e('Masked DOB (••/••/YYYY)', 'vms-ops-console-premium'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_member_lookup_require_photo_recheck"><?php esc_html_e('Require ID Recheck When No Photo Exists', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input type="hidden" name="vms_ops_settings[member_lookup_require_photo_recheck]" value="0">
                            <label><input id="vms_ops_member_lookup_require_photo_recheck" name="vms_ops_settings[member_lookup_require_photo_recheck]" type="checkbox" value="1" <?php checked(!empty($settings['member_lookup_require_photo_recheck'])); ?>> <?php esc_html_e('If no profile photo is on file, block the lookup-service path and direct staff to check ID now.', 'vms-ops-console-premium'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Audit Logging', 'vms-ops-console-premium'); ?></th>
                        <td>
                            <input type="hidden" name="vms_ops_settings[member_lookup_audit_logging]" value="1">
                            <label><input type="checkbox" checked disabled> <?php esc_html_e('Enabled. Lookup searches, opens, DOB confirmations, and service decisions are always logged in WordPress time.', 'vms-ops-console-premium'); ?></label>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Save Settings', 'vms-ops-console-premium')); ?>
            </form>
        </div>
        <?php
    }
}
