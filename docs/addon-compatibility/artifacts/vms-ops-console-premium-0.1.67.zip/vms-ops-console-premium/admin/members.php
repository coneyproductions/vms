<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_admin_members_page_slug')) {
    function vms_ops_admin_members_page_slug(): string
    {
        return 'vms-ops-console-members';
    }
}

if (!function_exists('vms_ops_admin_members_manage_capability')) {
    function vms_ops_admin_members_manage_capability(): string
    {
        if (function_exists('vms_ops_capability_manage_members_admin')) {
            return vms_ops_capability_manage_members_admin();
        }

        return 'manage_options';
    }
}

if (!function_exists('vms_ops_admin_current_user_can_manage_members')) {
    function vms_ops_admin_current_user_can_manage_members(): bool
    {
        return current_user_can('manage_options') || current_user_can(vms_ops_admin_members_manage_capability());
    }
}

if (!function_exists('vms_ops_admin_register_members_submenu')) {
    function vms_ops_admin_register_members_submenu(): void
    {
        $parent = apply_filters('vms_admin_parent_slug', 'vms-dashboard');
        $parent = sanitize_text_field((string) $parent);
        if ($parent === '') {
            $parent = 'vms-dashboard';
        }

        add_submenu_page(
            $parent,
            __('Members', 'vms-ops-console-premium'),
            __('Members', 'vms-ops-console-premium'),
            vms_ops_admin_members_manage_capability(),
            vms_ops_admin_members_page_slug(),
            'vms_ops_admin_render_members_page'
        );
    }
}
add_action('admin_menu', 'vms_ops_admin_register_members_submenu', 25);

if (!function_exists('vms_ops_admin_members_page_url')) {
    function vms_ops_admin_members_page_url(array $args = array()): string
    {
        return add_query_arg(array_merge(array(
            'page' => vms_ops_admin_members_page_slug(),
        ), $args), admin_url('admin.php'));
    }
}

if (!function_exists('vms_ops_admin_members_default_venue_id')) {
    function vms_ops_admin_members_default_venue_id(array $venues): int
    {
        $settings = function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array();
        $default_venue_id = (int) ($settings['default_venue_id'] ?? 0);

        foreach ($venues as $venue) {
            if ((int) ($venue['id'] ?? 0) === $default_venue_id) {
                return $default_venue_id;
            }
        }

        if (count($venues) === 1) {
            return (int) ($venues[0]['id'] ?? 0);
        }

        return 0;
    }
}

if (!function_exists('vms_ops_admin_members_format_date')) {
    function vms_ops_admin_members_format_date(string $value, string $fallback = ''): string
    {
        $value = trim($value);
        if ($value === '') {
            return $fallback;
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return $value;
        }

        return wp_date(get_option('date_format'), $timestamp, wp_timezone());
    }
}

if (!function_exists('vms_ops_admin_members_format_datetime')) {
    function vms_ops_admin_members_format_datetime(string $value, string $fallback = ''): string
    {
        $value = trim($value);
        if ($value === '') {
            return $fallback;
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return $value;
        }

        return wp_date(get_option('date_format') . ' ' . get_option('time_format'), $timestamp, wp_timezone());
    }
}

if (!function_exists('vms_ops_admin_members_status_label')) {
    function vms_ops_admin_members_status_label(string $status): string
    {
        $status = sanitize_key($status);
        $labels = array(
            'active' => __('Active', 'vms-ops-console-premium'),
            'expired' => __('Expired', 'vms-ops-console-premium'),
            'suspended' => __('Suspended', 'vms-ops-console-premium'),
            'banned' => __('Banned', 'vms-ops-console-premium'),
        );

        return $labels[$status] ?? ucfirst($status);
    }
}

if (!function_exists('vms_ops_admin_members_notice_text')) {
    function vms_ops_admin_members_notice_text(string $notice, string $member_name = '', string $fallback = ''): string
    {
        switch ($notice) {
            case 'member_saved':
                return __('Member changes saved.', 'vms-ops-console-premium');
            case 'member_no_changes':
                return __('No member changes were detected.', 'vms-ops-console-premium');
            case 'member_deleted':
                if ($member_name !== '') {
                    return sprintf(__('Deleted member: %s.', 'vms-ops-console-premium'), $member_name);
                }
                return __('Member deleted.', 'vms-ops-console-premium');
            case 'member_missing':
                return __('That member record could not be found.', 'vms-ops-console-premium');
            case 'search_requires_venue':
                return __('Select a venue before searching members.', 'vms-ops-console-premium');
            case 'action_failed':
                return $fallback !== '' ? $fallback : __('The member action could not be completed.', 'vms-ops-console-premium');
        }

        return '';
    }
}

if (!function_exists('vms_ops_admin_members_detail_payload')) {
    function vms_ops_admin_members_detail_payload(array $member, array $venue_map): array
    {
        $prepared = function_exists('vms_ops_pc_prepare_member_for_response')
            ? vms_ops_pc_prepare_member_for_response($member, true)
            : $member;
        $venue_id = (int) ($prepared['venue_id'] ?? ($member['venue_id'] ?? 0));
        $address = isset($prepared['address']) && is_array($prepared['address']) ? $prepared['address'] : array();
        $photo_url = function_exists('vms_ops_pc_lookup_member_photo_url')
            ? (string) vms_ops_pc_lookup_member_photo_url($member, function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array())
            : '';
        $photo_initials = function_exists('vms_ops_pc_lookup_member_initials')
            ? (string) vms_ops_pc_lookup_member_initials($member)
            : strtoupper(substr(trim((string) ($member['first_name'] ?? '')), 0, 1) . substr(trim((string) ($member['last_name'] ?? '')), 0, 1));
        $stored_status = sanitize_key((string) ($prepared['status'] ?? ($member['status'] ?? 'active')));
        $effective_status = function_exists('vms_ops_pc_member_effective_status')
            ? vms_ops_pc_member_effective_status($member)
            : $stored_status;
        $current_reason = '';
        if ($stored_status === 'suspended') {
            $current_reason = trim((string) ($member['suspended_reason'] ?? ''));
        } elseif ($stored_status === 'banned') {
            $current_reason = trim((string) ($member['banned_reason'] ?? ''));
        }

        return array(
            'id' => (int) ($prepared['id'] ?? ($member['id'] ?? 0)),
            'venue_id' => $venue_id,
            'venue_name' => $venue_map[$venue_id] ?? ($venue_id > 0 ? sprintf(__('Venue #%d', 'vms-ops-console-premium'), $venue_id) : __('Unknown venue', 'vms-ops-console-premium')),
            'member_number' => (string) ($prepared['member_number'] ?? ($member['member_number'] ?? '')),
            'full_name' => trim((string) ($prepared['first_name'] ?? ($member['first_name'] ?? '')) . ' ' . (string) ($prepared['last_name'] ?? ($member['last_name'] ?? ''))),
            'date_of_birth' => (string) ($prepared['date_of_birth'] ?? ($member['date_of_birth'] ?? '')),
            'status' => $stored_status,
            'status_label' => vms_ops_admin_members_status_label($stored_status),
            'effective_status' => $effective_status,
            'effective_status_label' => vms_ops_admin_members_status_label($effective_status),
            'vip' => !empty($prepared['vip']) ? 1 : 0,
            'membership_started_on' => (string) ($prepared['membership_started_on'] ?? ($member['membership_started_on'] ?? '')),
            'membership_expires_on' => (string) ($prepared['membership_expires_on'] ?? ($member['membership_expires_on'] ?? '')),
            'last_visit_on' => (string) ($prepared['last_visit_on'] ?? ($member['last_visit_on'] ?? '')),
            'phone_number' => (string) ($member['phone_number'] ?? ''),
            'email_address' => (string) ($member['email_address'] ?? ''),
            'notes' => (string) ($prepared['notes'] ?? ($member['notes'] ?? '')),
            'lookup_caution_flag' => !empty($member['lookup_caution_flag']) ? 1 : 0,
            'lookup_caution_note' => (string) ($member['lookup_caution_note'] ?? ''),
            'last_lookup_at' => (string) ($member['last_lookup_at'] ?? ''),
            'age_verified_at' => (string) ($member['age_verified_at'] ?? ''),
            'address' => $address,
            'photo_url' => $photo_url,
            'photo_initials' => $photo_initials !== '' ? $photo_initials : __('M', 'vms-ops-console-premium'),
            'current_reason' => $current_reason,
        );
    }
}

if (!function_exists('vms_ops_admin_render_members_page')) {
    function vms_ops_admin_render_members_page(): void
    {
        if (!vms_ops_admin_current_user_can_manage_members()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        $venues = function_exists('vms_ops_get_venues_list') ? vms_ops_get_venues_list() : array();
        $venue_map = array();
        foreach ($venues as $venue) {
            $venue_id = (int) ($venue['id'] ?? 0);
            if ($venue_id <= 0) {
                continue;
            }
            $venue_map[$venue_id] = (string) ($venue['name'] ?? ('Venue #' . $venue_id));
        }

        $default_venue_id = vms_ops_admin_members_default_venue_id($venues);
        $venue_id = isset($_GET['venue_id']) ? absint((string) $_GET['venue_id']) : $default_venue_id;
        if ($venue_id <= 0) {
            $venue_id = $default_venue_id;
        }

        $search = isset($_GET['search']) ? sanitize_text_field((string) wp_unslash($_GET['search'])) : '';
        $member_id = isset($_GET['member_id']) ? absint((string) $_GET['member_id']) : 0;
        $notice = isset($_GET['notice']) ? sanitize_key((string) $_GET['notice']) : '';
        $notice_type = isset($_GET['notice_type']) ? sanitize_key((string) $_GET['notice_type']) : 'success';
        if (!in_array($notice_type, array('success', 'warning', 'error'), true)) {
            $notice_type = 'success';
        }
        $notice_member = isset($_GET['member_name']) ? sanitize_text_field((string) wp_unslash($_GET['member_name'])) : '';
        $notice_message = isset($_GET['notice_message']) ? sanitize_text_field((string) wp_unslash($_GET['notice_message'])) : '';

        $selected_member = null;
        if ($member_id > 0 && function_exists('vms_ops_pc_get_member_by_id')) {
            $selected_member = vms_ops_pc_get_member_by_id($member_id);
        }

        $member_detail = is_array($selected_member)
            ? vms_ops_admin_members_detail_payload($selected_member, $venue_map)
            : null;

        $results = array(
            'items' => array(),
            'total_matches' => 0,
            'truncated' => 0,
        );
        if ($search !== '' && $venue_id > 0 && function_exists('vms_ops_pc_lookup_search_members')) {
            $results = vms_ops_pc_lookup_search_members($venue_id, $search, 30);
        }

        $active_notice = vms_ops_admin_members_notice_text($notice, $notice_member, $notice_message);
        ?>
        <div class="wrap vms-ops-members-page">
            <div class="vms-ops-page-head">
                <div>
                    <h1><?php esc_html_e('Members', 'vms-ops-console-premium'); ?></h1>
                    <p class="description"><?php esc_html_e('Search members by venue, then edit status, VIP state, address, or delete a test member record from wp-admin.', 'vms-ops-console-premium'); ?></p>
                </div>
            </div>

            <?php if ($active_notice !== '') : ?>
                <div class="notice notice-<?php echo esc_attr($notice_type); ?> inline"><p><?php echo esc_html($active_notice); ?></p></div>
            <?php endif; ?>

            <?php if ($member_id > 0 && !$selected_member) : ?>
                <div class="notice notice-warning inline"><p><?php esc_html_e('The selected member could not be loaded.', 'vms-ops-console-premium'); ?></p></div>
            <?php endif; ?>

            <?php if ($search !== '' && $venue_id <= 0) : ?>
                <div class="notice notice-warning inline"><p><?php echo esc_html(vms_ops_admin_members_notice_text('search_requires_venue')); ?></p></div>
            <?php endif; ?>

            <form method="get" class="vms-ops-members-filters">
                <input type="hidden" name="page" value="<?php echo esc_attr(vms_ops_admin_members_page_slug()); ?>">
                <label>
                    <span><?php esc_html_e('Venue', 'vms-ops-console-premium'); ?></span>
                    <select name="venue_id">
                        <option value="0"><?php esc_html_e('Select a venue', 'vms-ops-console-premium'); ?></option>
                        <?php foreach ($venues as $venue) :
                            $option_venue_id = (int) ($venue['id'] ?? 0);
                            if ($option_venue_id <= 0) {
                                continue;
                            }
                            ?>
                            <option value="<?php echo esc_attr((string) $option_venue_id); ?>"<?php selected($venue_id, $option_venue_id); ?>>
                                <?php echo esc_html((string) ($venue['name'] ?? ('Venue #' . $option_venue_id))); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label class="is-search">
                    <span><?php esc_html_e('Search', 'vms-ops-console-premium'); ?></span>
                    <input type="text" name="search" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Name, member #, email, phone, or DOB', 'vms-ops-console-premium'); ?>">
                </label>
                <div class="vms-ops-members-filter-actions">
                    <button type="submit" class="button button-primary"><?php esc_html_e('Search Members', 'vms-ops-console-premium'); ?></button>
                    <a class="button" href="<?php echo esc_url(vms_ops_admin_members_page_url(array('venue_id' => $default_venue_id > 0 ? $default_venue_id : 0))); ?>">
                        <?php esc_html_e('Reset', 'vms-ops-console-premium'); ?>
                    </a>
                </div>
            </form>

            <div class="vms-ops-members-layout">
                <section class="vms-ops-members-results">
                    <div class="vms-ops-members-section-head">
                        <div>
                            <h2><?php esc_html_e('Results', 'vms-ops-console-premium'); ?></h2>
                            <p class="description"><?php esc_html_e('Open a member to review the full record and apply admin-only changes.', 'vms-ops-console-premium'); ?></p>
                        </div>
                        <?php if ($search !== '' && $venue_id > 0) : ?>
                            <div class="vms-ops-members-results-summary">
                                <strong><?php echo esc_html((string) (int) ($results['total_matches'] ?? 0)); ?></strong>
                                <span><?php esc_html_e('matches', 'vms-ops-console-premium'); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($search === '') : ?>
                        <div class="vms-ops-members-empty">
                            <p><?php esc_html_e('Choose a venue and search to load member records here.', 'vms-ops-console-premium'); ?></p>
                        </div>
                    <?php elseif ($venue_id <= 0) : ?>
                        <div class="vms-ops-members-empty">
                            <p><?php esc_html_e('Search is waiting for a venue selection.', 'vms-ops-console-premium'); ?></p>
                        </div>
                    <?php elseif (empty($results['items'])) : ?>
                        <div class="vms-ops-members-empty">
                            <p><?php esc_html_e('No members matched that search.', 'vms-ops-console-premium'); ?></p>
                        </div>
                    <?php else : ?>
                        <table class="widefat striped vms-ops-members-table">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Member', 'vms-ops-console-premium'); ?></th>
                                    <th><?php esc_html_e('Status', 'vms-ops-console-premium'); ?></th>
                                    <th><?php esc_html_e('Contact', 'vms-ops-console-premium'); ?></th>
                                    <th><?php esc_html_e('Last Visit', 'vms-ops-console-premium'); ?></th>
                                    <th><?php esc_html_e('Action', 'vms-ops-console-premium'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ((array) ($results['items'] ?? array()) as $item) :
                                    $result_member_id = (int) ($item['id'] ?? 0);
                                    $row_url = vms_ops_admin_members_page_url(array(
                                        'venue_id' => $venue_id,
                                        'search' => $search,
                                        'member_id' => $result_member_id,
                                    ));
                                    $status = sanitize_key((string) ($item['status'] ?? 'active'));
                                    $contact_bits = array();
                                    $email_address = trim((string) ($item['email_address'] ?? ''));
                                    $phone_suffix = trim((string) ($item['phone_suffix'] ?? ''));
                                    if ($email_address !== '') {
                                        $contact_bits[] = $email_address;
                                    }
                                    if ($phone_suffix !== '') {
                                        $contact_bits[] = sprintf(__('Phone ending %s', 'vms-ops-console-premium'), $phone_suffix);
                                    }
                                    ?>
                                    <tr<?php echo $result_member_id === $member_id ? ' class="is-selected"' : ''; ?>>
                                        <td>
                                            <strong><?php echo esc_html((string) ($item['full_name'] ?? '')); ?></strong>
                                            <div class="vms-ops-members-sub"><?php echo esc_html((string) ($item['member_number'] ?? '')); ?></div>
                                        </td>
                                        <td>
                                            <span class="vms-ops-members-status-badge is-<?php echo esc_attr($status); ?>">
                                                <?php echo esc_html(vms_ops_admin_members_status_label($status)); ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc_html(!empty($contact_bits) ? implode(' • ', $contact_bits) : __('No phone or email saved', 'vms-ops-console-premium')); ?></td>
                                        <td><?php echo esc_html((string) ($item['last_visit_display'] ?? __('No visit logged', 'vms-ops-console-premium'))); ?></td>
                                        <td>
                                            <a class="button button-secondary" href="<?php echo esc_url($row_url); ?>">
                                                <?php esc_html_e('Open', 'vms-ops-console-premium'); ?>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                        <?php if (!empty($results['truncated'])) : ?>
                            <p class="description"><?php esc_html_e('Showing the top matches first. Narrow the search if you need a longer result set.', 'vms-ops-console-premium'); ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                </section>

                <section class="vms-ops-members-detail" id="vms-ops-member-detail">
                    <div class="vms-ops-members-section-head">
                        <div>
                            <h2><?php esc_html_e('Member Details', 'vms-ops-console-premium'); ?></h2>
                            <p class="description"><?php esc_html_e('This admin screen currently edits status, VIP, and address. Name and DOB remain read-only in this pass.', 'vms-ops-console-premium'); ?></p>
                        </div>
                    </div>

                    <?php if (!is_array($member_detail)) : ?>
                        <div class="vms-ops-members-empty">
                            <p><?php esc_html_e('Open a member from the search results to manage the record here.', 'vms-ops-console-premium'); ?></p>
                        </div>
                    <?php else : ?>
                        <div class="vms-ops-member-card">
                            <div class="vms-ops-member-card-head">
                                <div class="vms-ops-member-avatar" aria-hidden="true">
                                    <?php if ($member_detail['photo_url'] !== '') : ?>
                                        <img src="<?php echo esc_url($member_detail['photo_url']); ?>" alt="">
                                    <?php else : ?>
                                        <span><?php echo esc_html($member_detail['photo_initials']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="vms-ops-member-card-title">
                                    <h3><?php echo esc_html($member_detail['full_name'] !== '' ? $member_detail['full_name'] : __('Unnamed member', 'vms-ops-console-premium')); ?></h3>
                                    <p><?php echo esc_html($member_detail['member_number']); ?></p>
                                </div>
                                <div class="vms-ops-member-card-badges">
                                    <span class="vms-ops-members-status-badge is-<?php echo esc_attr($member_detail['effective_status']); ?>">
                                        <?php echo esc_html($member_detail['effective_status_label']); ?>
                                    </span>
                                    <?php if (!empty($member_detail['vip'])) : ?>
                                        <span class="vms-ops-members-status-badge is-vip"><?php esc_html_e('VIP', 'vms-ops-console-premium'); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <dl class="vms-ops-members-meta">
                                <div><dt><?php esc_html_e('Venue', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html($member_detail['venue_name']); ?></dd></div>
                                <div><dt><?php esc_html_e('DOB', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html(vms_ops_admin_members_format_date($member_detail['date_of_birth'], __('Unknown', 'vms-ops-console-premium'))); ?></dd></div>
                                <div><dt><?php esc_html_e('Phone', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html($member_detail['phone_number'] !== '' ? $member_detail['phone_number'] : __('Not saved', 'vms-ops-console-premium')); ?></dd></div>
                                <div><dt><?php esc_html_e('Email', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html($member_detail['email_address'] !== '' ? $member_detail['email_address'] : __('Not saved', 'vms-ops-console-premium')); ?></dd></div>
                                <div><dt><?php esc_html_e('Started', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html(vms_ops_admin_members_format_date($member_detail['membership_started_on'], __('Unknown', 'vms-ops-console-premium'))); ?></dd></div>
                                <div><dt><?php esc_html_e('Expires', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html(vms_ops_admin_members_format_date($member_detail['membership_expires_on'], __('Unknown', 'vms-ops-console-premium'))); ?></dd></div>
                                <div><dt><?php esc_html_e('Last Visit', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html(vms_ops_admin_members_format_date($member_detail['last_visit_on'], __('No visit logged', 'vms-ops-console-premium'))); ?></dd></div>
                                <div><dt><?php esc_html_e('Last Lookup', 'vms-ops-console-premium'); ?></dt><dd><?php echo esc_html(vms_ops_admin_members_format_datetime($member_detail['last_lookup_at'], __('No lookup logged', 'vms-ops-console-premium'))); ?></dd></div>
                            </dl>

                            <?php if (!empty($member_detail['lookup_caution_flag']) || $member_detail['notes'] !== '' || $member_detail['current_reason'] !== '') : ?>
                                <div class="vms-ops-member-notes">
                                    <?php if ($member_detail['current_reason'] !== '') : ?>
                                        <p><strong><?php esc_html_e('Current block reason:', 'vms-ops-console-premium'); ?></strong> <?php echo esc_html($member_detail['current_reason']); ?></p>
                                    <?php endif; ?>
                                    <?php if (!empty($member_detail['lookup_caution_flag'])) : ?>
                                        <p><strong><?php esc_html_e('Lookup caution:', 'vms-ops-console-premium'); ?></strong> <?php echo esc_html($member_detail['lookup_caution_note'] !== '' ? $member_detail['lookup_caution_note'] : __('Flagged for manual caution review.', 'vms-ops-console-premium')); ?></p>
                                    <?php endif; ?>
                                    <?php if ($member_detail['notes'] !== '') : ?>
                                        <p><strong><?php esc_html_e('Notes:', 'vms-ops-console-premium'); ?></strong> <?php echo esc_html($member_detail['notes']); ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="vms-ops-member-edit-form">
                                <?php wp_nonce_field('vms_ops_admin_save_member_' . $member_detail['id']); ?>
                                <input type="hidden" name="action" value="vms_ops_admin_save_member">
                                <input type="hidden" name="member_id" value="<?php echo esc_attr((string) $member_detail['id']); ?>">
                                <input type="hidden" name="venue_id" value="<?php echo esc_attr((string) $venue_id); ?>">
                                <input type="hidden" name="search" value="<?php echo esc_attr($search); ?>">

                                <div class="vms-ops-member-form-grid">
                                    <label>
                                        <span><?php esc_html_e('Status', 'vms-ops-console-premium'); ?></span>
                                        <select name="status">
                                            <option value="active"<?php selected($member_detail['status'], 'active'); ?>><?php esc_html_e('Active', 'vms-ops-console-premium'); ?></option>
                                            <option value="suspended"<?php selected($member_detail['status'], 'suspended'); ?>><?php esc_html_e('Suspended', 'vms-ops-console-premium'); ?></option>
                                            <option value="banned"<?php selected($member_detail['status'], 'banned'); ?>><?php esc_html_e('Banned', 'vms-ops-console-premium'); ?></option>
                                        </select>
                                    </label>
                                    <label class="is-checkbox">
                                        <span><?php esc_html_e('VIP', 'vms-ops-console-premium'); ?></span>
                                        <span class="vms-ops-member-checkbox">
                                            <input type="checkbox" name="vip" value="1" <?php checked(!empty($member_detail['vip'])); ?>>
                                            <?php esc_html_e('Flag this member as VIP', 'vms-ops-console-premium'); ?>
                                        </span>
                                    </label>
                                    <label class="is-full">
                                        <span><?php esc_html_e('Reason', 'vms-ops-console-premium'); ?></span>
                                        <textarea name="status_reason" rows="3" placeholder="<?php esc_attr_e('Used when changing status to suspended or banned.', 'vms-ops-console-premium'); ?>"><?php echo esc_textarea($member_detail['current_reason']); ?></textarea>
                                    </label>
                                    <label>
                                        <span><?php esc_html_e('Address Line 1', 'vms-ops-console-premium'); ?></span>
                                        <input type="text" name="address_line_1" value="<?php echo esc_attr((string) ($member_detail['address']['address_line_1'] ?? '')); ?>">
                                    </label>
                                    <label>
                                        <span><?php esc_html_e('Address Line 2', 'vms-ops-console-premium'); ?></span>
                                        <input type="text" name="address_line_2" value="<?php echo esc_attr((string) ($member_detail['address']['address_line_2'] ?? '')); ?>">
                                    </label>
                                    <label>
                                        <span><?php esc_html_e('City', 'vms-ops-console-premium'); ?></span>
                                        <input type="text" name="city" value="<?php echo esc_attr((string) ($member_detail['address']['city'] ?? '')); ?>">
                                    </label>
                                    <label>
                                        <span><?php esc_html_e('State', 'vms-ops-console-premium'); ?></span>
                                        <input type="text" name="state" maxlength="20" value="<?php echo esc_attr((string) ($member_detail['address']['state'] ?? '')); ?>">
                                    </label>
                                    <label>
                                        <span><?php esc_html_e('Postal Code', 'vms-ops-console-premium'); ?></span>
                                        <input type="text" name="postal_code" value="<?php echo esc_attr((string) ($member_detail['address']['postal_code'] ?? '')); ?>">
                                    </label>
                                </div>

                                <div class="vms-ops-member-actions">
                                    <button type="submit" class="button button-primary"><?php esc_html_e('Save Member Changes', 'vms-ops-console-premium'); ?></button>
                                </div>
                            </form>

                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="vms-ops-member-delete-form">
                                <?php wp_nonce_field('vms_ops_admin_delete_member_' . $member_detail['id']); ?>
                                <input type="hidden" name="action" value="vms_ops_admin_delete_member">
                                <input type="hidden" name="member_id" value="<?php echo esc_attr((string) $member_detail['id']); ?>">
                                <input type="hidden" name="venue_id" value="<?php echo esc_attr((string) $venue_id); ?>">
                                <input type="hidden" name="search" value="<?php echo esc_attr($search); ?>">
                                <button
                                    type="submit"
                                    class="button button-link-delete"
                                    onclick="return confirm('<?php echo esc_js(__('Delete this member record? This keeps scan/audit history but removes the member profile itself.', 'vms-ops-console-premium')); ?>');"
                                >
                                    <?php esc_html_e('Delete Member', 'vms-ops-console-premium'); ?>
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </section>
            </div>
        </div>
        <?php
    }
}

if (!function_exists('vms_ops_admin_handle_save_member')) {
    function vms_ops_admin_handle_save_member(): void
    {
        if (!vms_ops_admin_current_user_can_manage_members()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        $member_id = isset($_POST['member_id']) ? absint((string) $_POST['member_id']) : 0;
        check_admin_referer('vms_ops_admin_save_member_' . $member_id);

        $search = isset($_POST['search']) ? sanitize_text_field((string) wp_unslash($_POST['search'])) : '';
        $member = function_exists('vms_ops_pc_get_member_by_id') ? vms_ops_pc_get_member_by_id($member_id) : null;
        if (!is_array($member)) {
            wp_safe_redirect(vms_ops_admin_members_page_url(array(
                'search' => $search,
                'notice' => 'member_missing',
                'notice_type' => 'error',
            )));
            exit;
        }

        $venue_id = (int) ($member['venue_id'] ?? 0);
        $status = isset($_POST['status']) ? sanitize_key((string) wp_unslash($_POST['status'])) : sanitize_key((string) ($member['status'] ?? 'active'));
        if (!in_array($status, array('active', 'suspended', 'banned'), true)) {
            $status = sanitize_key((string) ($member['status'] ?? 'active'));
        }

        $status_reason = isset($_POST['status_reason']) ? sanitize_textarea_field((string) wp_unslash($_POST['status_reason'])) : '';
        $vip = !empty($_POST['vip']);
        $address = function_exists('vms_ops_pc_sanitize_address')
            ? vms_ops_pc_sanitize_address(array(
                'address_line_1' => isset($_POST['address_line_1']) ? (string) wp_unslash($_POST['address_line_1']) : '',
                'address_line_2' => isset($_POST['address_line_2']) ? (string) wp_unslash($_POST['address_line_2']) : '',
                'city' => isset($_POST['city']) ? (string) wp_unslash($_POST['city']) : '',
                'state' => isset($_POST['state']) ? (string) wp_unslash($_POST['state']) : '',
                'postal_code' => isset($_POST['postal_code']) ? (string) wp_unslash($_POST['postal_code']) : '',
            ))
            : array();

        $changes = 0;
        $current_status = sanitize_key((string) ($member['status'] ?? 'active'));
        if ($status !== $current_status) {
            $updated_status = vms_ops_pc_update_status($member_id, $status, $status_reason);
            if (is_wp_error($updated_status)) {
                wp_safe_redirect(vms_ops_admin_members_page_url(array(
                    'venue_id' => $venue_id,
                    'search' => $search,
                    'member_id' => $member_id,
                    'notice' => 'action_failed',
                    'notice_type' => 'error',
                    'notice_message' => $updated_status->get_error_message(),
                )));
                exit;
            }

            $member = $updated_status;
            $changes++;
        }

        $current_vip = !empty($member['vip']);
        if ($vip !== $current_vip) {
            $updated_vip = vms_ops_pc_update_vip($member_id, $vip);
            if (is_wp_error($updated_vip)) {
                wp_safe_redirect(vms_ops_admin_members_page_url(array(
                    'venue_id' => $venue_id,
                    'search' => $search,
                    'member_id' => $member_id,
                    'notice' => 'action_failed',
                    'notice_type' => 'error',
                    'notice_message' => $updated_vip->get_error_message(),
                )));
                exit;
            }

            $member = $updated_vip;
            $changes++;
        }

        $current_address = function_exists('vms_ops_pc_unpack_address')
            ? vms_ops_pc_unpack_address((string) ($member['address_ciphertext'] ?? ''))
            : array();
        if (is_wp_error($current_address)) {
            $current_address = array();
        }
        if (function_exists('vms_ops_pc_sanitize_address')) {
            $current_address = vms_ops_pc_sanitize_address(is_array($current_address) ? $current_address : array());
        }

        if ($current_address !== $address) {
            $updated_address = vms_ops_pc_update_member_address($member_id, $address);
            if (is_wp_error($updated_address)) {
                wp_safe_redirect(vms_ops_admin_members_page_url(array(
                    'venue_id' => $venue_id,
                    'search' => $search,
                    'member_id' => $member_id,
                    'notice' => 'action_failed',
                    'notice_type' => 'error',
                    'notice_message' => $updated_address->get_error_message(),
                )));
                exit;
            }

            $changes++;
        }

        wp_safe_redirect(vms_ops_admin_members_page_url(array(
            'venue_id' => $venue_id,
            'search' => $search,
            'member_id' => $member_id,
            'notice' => $changes > 0 ? 'member_saved' : 'member_no_changes',
            'notice_type' => $changes > 0 ? 'success' : 'warning',
        )));
        exit;
    }
}
add_action('admin_post_vms_ops_admin_save_member', 'vms_ops_admin_handle_save_member');

if (!function_exists('vms_ops_admin_handle_delete_member')) {
    function vms_ops_admin_handle_delete_member(): void
    {
        if (!vms_ops_admin_current_user_can_manage_members()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        $member_id = isset($_POST['member_id']) ? absint((string) $_POST['member_id']) : 0;
        check_admin_referer('vms_ops_admin_delete_member_' . $member_id);

        $search = isset($_POST['search']) ? sanitize_text_field((string) wp_unslash($_POST['search'])) : '';
        $member = function_exists('vms_ops_pc_get_member_by_id') ? vms_ops_pc_get_member_by_id($member_id) : null;
        if (!is_array($member)) {
            wp_safe_redirect(vms_ops_admin_members_page_url(array(
                'search' => $search,
                'notice' => 'member_missing',
                'notice_type' => 'error',
            )));
            exit;
        }

        $venue_id = (int) ($member['venue_id'] ?? 0);
        $deleted = vms_ops_pc_delete_member($member_id);
        if (is_wp_error($deleted)) {
            wp_safe_redirect(vms_ops_admin_members_page_url(array(
                'venue_id' => $venue_id,
                'search' => $search,
                'member_id' => $member_id,
                'notice' => 'action_failed',
                'notice_type' => 'error',
                'notice_message' => $deleted->get_error_message(),
            )));
            exit;
        }

        wp_safe_redirect(vms_ops_admin_members_page_url(array(
            'venue_id' => $venue_id,
            'search' => $search,
            'notice' => 'member_deleted',
            'notice_type' => 'success',
            'member_name' => sanitize_text_field((string) ($deleted['member_name'] ?? '')),
        )));
        exit;
    }
}
add_action('admin_post_vms_ops_admin_delete_member', 'vms_ops_admin_handle_delete_member');
