(function () {
  "use strict";

  function slugifyKey(label) {
    return String(label || "")
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s_-]/g, "")
      .replace(/[\s-]+/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "");
  }

  function initPresetKeyAutofill() {
    var table = document.querySelector(".vms-ops-admin-presets-table");
    if (!table) return;

    table.addEventListener(
      "input",
      function (e) {
        var target = e && e.target;
        if (!target || !target.classList) return;
        if (!target.classList.contains("vms-ops-preset-label")) return;

        var row = target.closest("tr");
        if (!row) return;

        var keyInput = row.querySelector(".vms-ops-preset-key");
        if (!keyInput) return;

        // Only auto-fill when the key is empty.
        if (String(keyInput.value || "").trim() !== "") return;

        keyInput.value = slugifyKey(target.value);
      },
      true
    );
  }

  function initTeamCapsSerializer() {
    var forms = document.querySelectorAll(".vms-ops-admin-user-caps-form");
    if (!forms.length) return;

    Array.prototype.forEach.call(forms, function (form) {
      var payloadInput = form.querySelector('input[name="caps_payload"]');
      if (!payloadInput) return;

      var legacyInputs = form.querySelectorAll(
        'input[name="user_ids[]"], input[name^="caps["]'
      );

      function syncPayload() {
        var payload = {};
        var rows = form.querySelectorAll("tbody tr[data-user-id]");

        Array.prototype.forEach.call(rows, function (row) {
          var userId = row.getAttribute("data-user-id");
          if (!userId) return;

          payload[userId] = [];

          var toggles = row.querySelectorAll("input.vms-ops-team-cap-toggle");
          Array.prototype.forEach.call(toggles, function (toggle) {
            var cap = toggle.getAttribute("data-cap");
            if (!cap) return;
            if (toggle.checked) {
              payload[userId].push(cap);
            }
          });
        });

        payloadInput.value = JSON.stringify(payload);
      }

      form.addEventListener("change", function (e) {
        var target = e && e.target;
        if (!target || !target.classList) return;
        if (!target.classList.contains("vms-ops-team-cap-toggle")) return;
        syncPayload();
      });

      form.addEventListener("submit", function () {
        syncPayload();
        Array.prototype.forEach.call(legacyInputs, function (input) {
          input.removeAttribute("name");
        });
      });

      syncPayload();
    });
  }

  function initScanHistoryTour() {
    initTour({
      pageSelector: ".vms-ops-scan-history-page",
      startSelector: "[data-vms-ops-scan-tour-start]",
      steps: [
        {
          selector: '[data-tour-anchor="purpose"]',
          title: "What this page is for",
          body: "Use ID Scan History to review scanned IDs, blocked entries, and member-not-found attempts without opening the database."
        },
        {
          selector: '[data-tour-anchor="filters"]',
          title: "Date and venue filters",
          body: "Start with the date window and venue. That keeps the results focused on the shift, room, or incident you are reviewing."
        },
        {
          selector: '[data-tour-anchor="member-lookup"]',
          title: "Member lookup",
          body: "Search with the member number, scanned name, or scan reference. Older rows may have lighter metadata, so broad searches are often more reliable."
        },
        {
          selector: '[data-tour-anchor="results"]',
          title: "Results table",
          body: "The table defaults to ID scans only. Result badges, member details, age status, scanner, and notes help you spot failed or risky scans quickly."
        },
        {
          selector: '[data-tour-anchor="detail"]',
          title: "Detail view",
          body: "Open a row when you need the stored scan context. Newer rows include richer payload details, while older rows may show less."
        },
        {
          selector: '[data-tour-anchor="export"]',
          title: "CSV export",
          body: "Export respects the filters on screen. Apply the date, venue, scanner, or member search first, then export the matching rows."
        }
      ]
    });
  }

  function clearTourHighlights() {
    document.querySelectorAll(".vms-tour-highlight").forEach(function (el) {
      el.classList.remove("vms-tour-highlight");
    });
  }

  function initTour(options) {
    var page = document.querySelector(options.pageSelector);
    var startButton = document.querySelector(options.startSelector);
    var steps = Array.isArray(options.steps) ? options.steps : [];
    if (!page || !startButton || !steps.length) return;

    var overlay = null;
    var currentStep = 0;

    function getAvailableSteps() {
      return steps.filter(function (step) {
        return step && step.selector && document.querySelector(step.selector);
      });
    }

    function closeTour() {
      clearTourHighlights();
      if (overlay && overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
      overlay = null;
    }

    function renderStep() {
      if (!overlay) return;

      var availableSteps = getAvailableSteps();
      if (!availableSteps.length) {
        closeTour();
        return;
      }

      if (currentStep < 0) currentStep = 0;
      if (currentStep >= availableSteps.length) currentStep = availableSteps.length - 1;

      var step = availableSteps[currentStep];
      var target = document.querySelector(step.selector);
      clearTourHighlights();
      if (target) {
        target.classList.add("vms-tour-highlight");
        target.scrollIntoView({ behavior: "smooth", block: "center" });
      }

      overlay.querySelector(".vms-ops-tour-progress").textContent =
        "Step " + (currentStep + 1) + " of " + availableSteps.length;
      overlay.querySelector(".vms-ops-tour-title").textContent = step.title;
      overlay.querySelector(".vms-ops-tour-body").textContent = step.body;

      var prevBtn = overlay.querySelector('[data-tour-action="prev"]');
      var nextBtn = overlay.querySelector('[data-tour-action="next"]');
      if (prevBtn) prevBtn.disabled = currentStep === 0;
      if (nextBtn) {
        nextBtn.textContent = currentStep === availableSteps.length - 1 ? "Finish" : "Next";
      }
    }

    function openTour() {
      if (overlay) {
        renderStep();
        return;
      }

      overlay = document.createElement("div");
      overlay.className = "vms-tour-overlay vms-ops-tour-overlay";
      overlay.innerHTML =
        '<div class="vms-ops-tour-card">' +
        '  <div class="vms-ops-tour-progress"></div>' +
        '  <h3 class="vms-ops-tour-title"></h3>' +
        '  <div class="vms-ops-tour-body"></div>' +
        '  <div class="vms-tour-actions">' +
        '    <button type="button" class="button" data-tour-action="prev">Back</button>' +
        '    <button type="button" class="button button-primary" data-tour-action="next">Next</button>' +
        '    <button type="button" class="button" data-tour-action="close">Close</button>' +
        '  </div>' +
        '</div>';

      overlay.addEventListener("click", function (event) {
        if (event.target === overlay) {
          closeTour();
        }
      });

      overlay.querySelector('[data-tour-action="prev"]').addEventListener("click", function () {
        currentStep -= 1;
        renderStep();
      });
      overlay.querySelector('[data-tour-action="next"]').addEventListener("click", function () {
        var availableSteps = getAvailableSteps();
        if (currentStep >= availableSteps.length - 1) {
          closeTour();
          return;
        }
        currentStep += 1;
        renderStep();
      });
      overlay.querySelector('[data-tour-action="close"]').addEventListener("click", closeTour);

      document.body.appendChild(overlay);
      currentStep = 0;
      renderStep();
    }

    startButton.addEventListener("click", openTour);
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && overlay) {
        closeTour();
      }
    });
  }

  function initSettingsTour() {
    initTour({
      pageSelector: ".vms-ops-settings-page",
      startSelector: "[data-vms-ops-settings-tour-start]",
      steps: [
        {
          selector: '[data-tour-anchor="settings-intro"]',
          title: "Why these settings matter",
          body: "Ops now follows WordPress site time for the runtime clock and scanner cutoffs. This page controls the operational defaults behind that behavior."
        },
        {
          selector: '[data-tour-anchor="scan-buffer"]',
          title: "Post-show scan buffer",
          body: "Use the buffer when late-night closeout work continues after the official event end time. It keeps scanning available for a limited grace window without moving the real event schedule."
        },
        {
          selector: '[data-tour-anchor="reopen-past-events"]',
          title: "Reopen recent past events",
          body: "Enable this only when you need staff to prove they can run a real ticket check-in on older tickets. It re-exposes recently ended events after the normal buffer, so turn it back off when testing is complete."
        },
        {
          selector: '[data-tour-anchor="default-venue"]',
          title: "Default venue behavior",
          body: "This controls which venue Ops selects first when a user does not already have one locked in. It prevents scanners from starting in the wrong room by default."
        },
        {
          selector: '[data-tour-anchor="member-lookup-settings"]',
          title: "Verified Member Lookup guardrails",
          body: "These settings control whether bar staff can use Verified Lookup, whether DOB entry and confidence acknowledgement are required, how stale prior verification becomes, and whether missing photos should force an ID recheck."
        }
      ]
    });
  }

  function initTeamsTour() {
    initTour({
      pageSelector: ".vms-ops-teams-page",
      startSelector: "[data-vms-ops-teams-tour-start]",
      steps: [
        {
          selector: '[data-tour-anchor="teams-intro"]',
          title: "WP role is not enough",
          body: "A WordPress role only covers login context. Ops readiness also depends on the Staff link, Staff Role, role-profile sync, and the actual scanner capabilities on the user account."
        },
        {
          selector: '[data-tour-anchor="status-summary"]',
          title: "Summary red flags",
          body: "Start here before a shift. The summary counts show which users are incomplete, stale, or running manual overrides so problems are visible before someone reaches the door or bar."
        },
        {
          selector: '[data-tour-anchor="role-profiles"]',
          title: "Role profiles",
          body: "Staff Role capability profiles are the source of truth for standard access. Update them when a job should normally gain or lose a scanner-related capability."
        },
        {
          selector: '[data-tour-anchor="sync-actions"]',
          title: "Sync and recalculate",
          body: "Use Role Sync when a user shows Needs Role Sync. It applies the saved Staff Role profiles to linked users. Recalculate only refreshes the warning state; it does not change capabilities."
        },
        {
          selector: '[data-tour-anchor="user-grid"]',
          title: "Per-user checklist and overrides",
          body: "Use the Setup Status column to see exactly why a user is blocked or stale. Per-user capability toggles remain available for exceptions, but they now stay visibly marked as manual overrides."
        }
      ]
    });
  }

  function initAdminUi() {
    initPresetKeyAutofill();
    initTeamCapsSerializer();
    initScanHistoryTour();
    initSettingsTour();
    initTeamsTour();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAdminUi);
  } else {
    initAdminUi();
  }
})();
