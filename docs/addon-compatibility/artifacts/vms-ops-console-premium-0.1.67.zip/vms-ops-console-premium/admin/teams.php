<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_admin_manage_capability')) {
    function vms_ops_admin_manage_capability(): string
    {
        $cap = 'manage_options';

        if (vms_ops_has_core_function('vms_admin_ui_ops_capability')) {
            $candidate = sanitize_text_field((string) vms_ops_call_core_function('vms_admin_ui_ops_capability'));
            if ($candidate !== '') {
                $cap = $candidate;
            }
        } elseif (vms_ops_has_core_function('vms_admin_ui_data_tools_capability')) {
            $candidate = sanitize_text_field((string) vms_ops_call_core_function('vms_admin_ui_data_tools_capability'));
            if ($candidate !== '') {
                $cap = $candidate;
            }
        }

        return $cap;
    }
}

if (!function_exists('vms_ops_admin_current_user_can_manage')) {
    function vms_ops_admin_current_user_can_manage(): bool
    {
        return current_user_can(vms_ops_admin_manage_capability()) || current_user_can('manage_options');
    }
}

if (!function_exists('vms_ops_admin_register_teams_submenu')) {
    function vms_ops_admin_register_teams_submenu(): void
    {
        $parent = apply_filters('vms_admin_parent_slug', 'vms-dashboard');
        $parent = sanitize_text_field((string) $parent);
        if ($parent === '') {
            $parent = 'vms-dashboard';
        }

        add_submenu_page(
            $parent,
            __('Teams', 'vms-ops-console-premium'),
            __('Teams', 'vms-ops-console-premium'),
            vms_ops_admin_manage_capability(),
            'vms-ops-console-teams',
            'vms_ops_admin_render_teams_page'
        );
    }
}
if (!function_exists('vms_ops_admin_team_caps')) {
    function vms_ops_admin_team_caps(): array
    {
        return array(
            vms_ops_capability_use_pwa(),
            vms_ops_capability_scan_tickets(),
            vms_ops_capability_scan_ids(),
            vms_ops_capability_member_lookup(),
            vms_ops_capability_manage_members_lite(),
            vms_ops_capability_manage_members_admin(),
            vms_ops_capability_send_alerts(),
            vms_ops_capability_receive_alerts(),
            vms_ops_capability_presence_checkin(),
        );
    }
}

if (!function_exists('vms_ops_admin_team_cap_label')) {
    function vms_ops_admin_team_cap_label(string $cap): string
    {
        $labels = array(
            vms_ops_capability_use_pwa() => __('Ops PWA', 'vms-ops-console-premium'),
            vms_ops_capability_scan_tickets() => __('Ticket Scan', 'vms-ops-console-premium'),
            vms_ops_capability_scan_ids() => __('ID Scan', 'vms-ops-console-premium'),
            vms_ops_capability_member_lookup() => __('Member Lookup', 'vms-ops-console-premium'),
            vms_ops_capability_manage_members_lite() => __('Member Admin Lite', 'vms-ops-console-premium'),
            vms_ops_capability_manage_members_admin() => __('Member Admin', 'vms-ops-console-premium'),
            vms_ops_capability_send_alerts() => __('Send Alerts', 'vms-ops-console-premium'),
            vms_ops_capability_receive_alerts() => __('Receive Alerts', 'vms-ops-console-premium'),
            vms_ops_capability_presence_checkin() => __('Presence Login', 'vms-ops-console-premium'),
        );

        return $labels[$cap] ?? $cap;
    }
}

if (!function_exists('vms_ops_admin_role_profile_option_key')) {
    function vms_ops_admin_role_profile_option_key(): string
    {
        return 'vms_ops_staff_role_cap_profiles';
    }
}

if (!function_exists('vms_ops_admin_normalize_staff_role_match_text')) {
    function vms_ops_admin_normalize_staff_role_match_text(string $value): string
    {
        $value = remove_accents($value);
        $value = strtolower($value);
        $value = preg_replace('/[^a-z0-9]+/', ' ', $value);
        return trim((string) $value);
    }
}

if (!function_exists('vms_ops_admin_role_profile_default_caps_for_identity')) {
    function vms_ops_admin_role_profile_default_caps_for_identity(string $name = '', string $slug = ''): array
    {
        $match_text = vms_ops_admin_normalize_staff_role_match_text(trim($name . ' ' . str_replace(array('-', '_'), ' ', $slug)));
        if ($match_text === '') {
            return array();
        }

        $match_text = ' ' . $match_text . ' ';
        $caps = array();
        $append_caps = static function (array $items) use (&$caps): void {
            foreach ($items as $cap) {
                $cap = sanitize_text_field((string) $cap);
                if ($cap !== '') {
                    $caps[] = $cap;
                }
            }
        };

        $is_ticket_role = preg_match('/\b(ticket|door|gate)\b/', $match_text) === 1;
        $is_bar_role = preg_match('/\b(bar|bartender)\b/', $match_text) === 1;

        if ($is_ticket_role) {
            $append_caps(array(
                vms_ops_capability_use_pwa(),
                vms_ops_capability_scan_tickets(),
            ));
        }

        if ($is_bar_role) {
            $append_caps(array(
                vms_ops_capability_use_pwa(),
                vms_ops_capability_scan_ids(),
                vms_ops_capability_manage_members_lite(),
            ));
        }

        $caps = array_values(array_unique($caps));
        if (empty($caps)) {
            return array();
        }

        $use_pwa_cap = vms_ops_capability_use_pwa();
        $has_non_pwa = false;
        foreach ($caps as $cap) {
            if ($cap !== $use_pwa_cap) {
                $has_non_pwa = true;
                break;
            }
        }

        if ($has_non_pwa && !in_array($use_pwa_cap, $caps, true)) {
            $caps[] = $use_pwa_cap;
        }

        return array_values(array_unique($caps));
    }
}

if (!function_exists('vms_ops_admin_role_profile_default_caps_for_term')) {
    function vms_ops_admin_role_profile_default_caps_for_term($role): array
    {
        if ($role instanceof WP_Term) {
            return vms_ops_admin_role_profile_default_caps_for_identity((string) $role->name, (string) $role->slug);
        }

        if (is_array($role)) {
            return vms_ops_admin_role_profile_default_caps_for_identity(
                (string) ($role['name'] ?? ''),
                (string) ($role['slug'] ?? '')
            );
        }

        return vms_ops_admin_role_profile_default_caps_for_identity((string) $role, sanitize_title((string) $role));
    }
}

if (!function_exists('vms_ops_admin_get_staff_roles')) {
    function vms_ops_admin_get_staff_roles(): array
    {
        if (!taxonomy_exists('vms_staff_role')) {
            return array();
        }

        $terms = get_terms(array(
            'taxonomy' => 'vms_staff_role',
            'hide_empty' => false,
        ));
        if (!is_array($terms)) {
            return array();
        }

        return array_values(array_filter($terms, static function ($term): bool {
            return ($term instanceof WP_Term) && ((int) $term->term_id > 0);
        }));
    }
}

if (!function_exists('vms_ops_admin_sanitize_role_profile_caps')) {
    function vms_ops_admin_sanitize_role_profile_caps(array $raw_profiles): array
    {
        $allowed_caps = vms_ops_admin_team_caps();
        $use_pwa_cap = vms_ops_capability_use_pwa();
        $clean = array();

        foreach ($raw_profiles as $raw_term_id => $raw_caps) {
            $term_id = absint((string) $raw_term_id);
            if ($term_id <= 0) {
                continue;
            }
            if (!is_array($raw_caps)) {
                continue;
            }

            $caps = array();
            foreach ($raw_caps as $cap) {
                $cap = sanitize_text_field((string) $cap);
                if ($cap === '' || !in_array($cap, $allowed_caps, true)) {
                    continue;
                }
                $caps[] = $cap;
            }
            $caps = array_values(array_unique($caps));

            $has_any = false;
            foreach ($caps as $cap) {
                if ($cap !== $use_pwa_cap) {
                    $has_any = true;
                    break;
                }
            }
            if ($has_any && !in_array($use_pwa_cap, $caps, true)) {
                $caps[] = $use_pwa_cap;
            }

            $clean[(string) $term_id] = array_values(array_unique($caps));
        }

        return $clean;
    }
}

if (!function_exists('vms_ops_admin_role_profiles_get_stored')) {
    function vms_ops_admin_role_profiles_get_stored(): array
    {
        $stored = get_option(vms_ops_admin_role_profile_option_key(), array());
        if (!is_array($stored)) {
            return array();
        }
        return vms_ops_admin_sanitize_role_profile_caps($stored);
    }
}

if (!function_exists('vms_ops_admin_role_profiles_get')) {
    function vms_ops_admin_role_profiles_get(): array
    {
        $stored = vms_ops_admin_role_profiles_get_stored();
        $effective = $stored;

        foreach (vms_ops_admin_get_staff_roles() as $role) {
            if (!($role instanceof WP_Term)) {
                continue;
            }

            $role_id = absint((string) $role->term_id);
            if ($role_id <= 0) {
                continue;
            }

            $role_key = (string) $role_id;
            $effective[$role_key] = array_values(array_unique(array_merge(
                vms_ops_admin_role_profile_default_caps_for_term($role),
                isset($stored[$role_key]) && is_array($stored[$role_key]) ? $stored[$role_key] : array()
            )));
        }

        return vms_ops_admin_sanitize_role_profile_caps($effective);
    }
}

if (!function_exists('vms_ops_admin_resolve_caps_for_linked_staff_entry')) {
    function vms_ops_admin_resolve_caps_for_linked_staff_entry(array $linked_staff_entry, ?array $role_profiles = null): array
    {
        $role_profiles = is_array($role_profiles) && !empty($role_profiles)
            ? vms_ops_admin_sanitize_role_profile_caps($role_profiles)
            : vms_ops_admin_role_profiles_get();

        $desired_caps = array();
        $missing_profiles = array();
        $role_ids = array_values(array_unique(array_map('absint', (array) ($linked_staff_entry['role_ids'] ?? array()))));
        $role_names = array_values(array_unique(array_filter(array_map('strval', (array) ($linked_staff_entry['role_names'] ?? array())))));

        foreach ($role_ids as $role_id) {
            if ($role_id <= 0) {
                continue;
            }

            $role_key = (string) $role_id;
            if (!array_key_exists($role_key, $role_profiles) || !is_array($role_profiles[$role_key])) {
                $missing_profiles[] = $role_id;
                continue;
            }

            foreach ($role_profiles[$role_key] as $cap) {
                $cap = sanitize_text_field((string) $cap);
                if ($cap !== '') {
                    $desired_caps[] = $cap;
                }
            }
        }

        foreach ($role_names as $role_name) {
            foreach (vms_ops_admin_role_profile_default_caps_for_term($role_name) as $cap) {
                $cap = sanitize_text_field((string) $cap);
                if ($cap !== '') {
                    $desired_caps[] = $cap;
                }
            }
        }

        $desired_caps = array_values(array_unique($desired_caps));
        sort($desired_caps);
        $missing_profiles = array_values(array_unique(array_map('absint', $missing_profiles)));

        return array(
            'desired_caps' => $desired_caps,
            'missing_profiles' => $missing_profiles,
        );
    }
}

if (!function_exists('vms_ops_admin_resolve_staff_linked_user_id')) {
    function vms_ops_admin_resolve_staff_linked_user_id(int $staff_id): int
    {
        $staff_id = absint($staff_id);
        if ($staff_id <= 0) {
            return 0;
        }

        $linked_user_id = (int) get_post_meta($staff_id, '_vms_linked_user_id', true);
        if ($linked_user_id <= 0) {
            $linked_user_id = (int) get_post_meta($staff_id, '_vms_user_id', true);
        }
        if ($linked_user_id > 0) {
            return $linked_user_id;
        }

        $linked_users = get_users(array(
            'fields' => array('ID'),
            'number' => 1,
            'meta_key' => '_vms_staff_id',
            'meta_value' => $staff_id,
            'orderby' => 'ID',
            'order' => 'ASC',
        ));

        if (is_array($linked_users) && !empty($linked_users)) {
            return (int) ($linked_users[0]->ID ?? 0);
        }

        return 0;
    }
}

if (!function_exists('vms_ops_admin_collect_linked_staff_index')) {
    function vms_ops_admin_collect_linked_staff_index(): array
    {
        if (!post_type_exists('vms_staff')) {
            return array();
        }

        $staff_ids = get_posts(array(
            'post_type' => 'vms_staff',
            'post_status' => array('publish', 'draft', 'pending', 'private'),
            'fields' => 'ids',
            'posts_per_page' => -1,
            'no_found_rows' => true,
        ));
        if (!is_array($staff_ids)) {
            return array();
        }

        $index = array();
        foreach ($staff_ids as $staff_id) {
            $staff_id = absint((string) $staff_id);
            if ($staff_id <= 0) {
                continue;
            }

            $linked_user_id = vms_ops_admin_resolve_staff_linked_user_id($staff_id);
            if ($linked_user_id <= 0) {
                continue;
            }

            if (!isset($index[$linked_user_id]) || !is_array($index[$linked_user_id])) {
                $index[$linked_user_id] = array(
                    'staff_ids' => array(),
                    'staff_labels' => array(),
                    'role_ids' => array(),
                    'role_names' => array(),
                );
            }

            $staff_label = trim((string) get_the_title($staff_id));
            if ($staff_label === '') {
                $staff_label = 'Staff #' . (string) $staff_id;
            }

            $index[$linked_user_id]['staff_ids'][] = $staff_id;
            $index[$linked_user_id]['staff_labels'][] = $staff_label;

            if (!taxonomy_exists('vms_staff_role')) {
                $legacy_role = trim((string) get_post_meta($staff_id, '_vms_staff_role', true));
                if ($legacy_role !== '') {
                    $index[$linked_user_id]['role_names'][] = $legacy_role;
                }
                continue;
            }

            $role_terms = get_the_terms($staff_id, 'vms_staff_role');
            if (is_array($role_terms)) {
                foreach ($role_terms as $role_term) {
                    if (!($role_term instanceof WP_Term)) {
                        continue;
                    }

                    $role_id = absint((string) $role_term->term_id);
                    if ($role_id > 0) {
                        $index[$linked_user_id]['role_ids'][] = $role_id;
                    }

                    $role_name = trim((string) $role_term->name);
                    if ($role_name !== '') {
                        $index[$linked_user_id]['role_names'][] = $role_name;
                    }
                }
            }

            if (!empty($index[$linked_user_id]['role_ids'])) {
                continue;
            }

            $legacy_role = trim((string) get_post_meta($staff_id, '_vms_staff_role', true));
            if ($legacy_role === '') {
                continue;
            }

            $legacy_labels = preg_split('/\s*,\s*/', $legacy_role);
            if (!is_array($legacy_labels)) {
                continue;
            }

            foreach ($legacy_labels as $legacy_label) {
                $legacy_label = trim((string) $legacy_label);
                if ($legacy_label === '') {
                    continue;
                }

                $index[$linked_user_id]['role_names'][] = $legacy_label;

                $legacy_term = get_term_by('name', $legacy_label, 'vms_staff_role');
                if (!($legacy_term instanceof WP_Term)) {
                    $legacy_term = get_term_by('slug', sanitize_title($legacy_label), 'vms_staff_role');
                }
                if ($legacy_term instanceof WP_Term) {
                    $index[$linked_user_id]['role_ids'][] = absint((string) $legacy_term->term_id);
                }
            }
        }

        foreach ($index as $user_id => $entry) {
            $entry['staff_ids'] = array_values(array_unique(array_map('absint', (array) $entry['staff_ids'])));
            $entry['staff_labels'] = array_values(array_unique(array_filter(array_map('strval', (array) $entry['staff_labels']))));
            $entry['role_ids'] = array_values(array_unique(array_map('absint', (array) $entry['role_ids'])));
            $entry['role_names'] = array_values(array_unique(array_filter(array_map('strval', (array) $entry['role_names']))));
            if (!empty($entry['role_names'])) {
                natcasesort($entry['role_names']);
                $entry['role_names'] = array_values($entry['role_names']);
            }
            $index[$user_id] = $entry;
        }

        return $index;
    }
}

if (!function_exists('vms_ops_admin_collect_linked_staff_user_roles')) {
    function vms_ops_admin_collect_linked_staff_user_roles(): array
    {
        $user_roles = array();
        foreach (vms_ops_admin_collect_linked_staff_index() as $linked_user_id => $entry) {
            if (empty($entry['role_ids']) || !is_array($entry['role_ids'])) {
                continue;
            }

            $user_roles[$linked_user_id] = array_values(array_unique(array_map('absint', $entry['role_ids'])));
        }

        return $user_roles;
    }
}

if (!function_exists('vms_ops_admin_user_effective_team_caps')) {
    function vms_ops_admin_user_effective_team_caps(WP_User $user, ?array $allowed_caps = null): array
    {
        $allowed_caps = is_array($allowed_caps) && !empty($allowed_caps)
            ? array_values(array_unique(array_map('sanitize_text_field', $allowed_caps)))
            : vms_ops_admin_team_caps();

        $effective = array();
        foreach ($allowed_caps as $cap) {
            if ($cap !== '' && user_can($user, $cap)) {
                $effective[] = $cap;
            }
        }

        return array_values(array_unique($effective));
    }
}

if (!function_exists('vms_ops_admin_apply_role_profiles_to_linked_users')) {
    function vms_ops_admin_apply_role_profiles_to_linked_users(array $role_profiles, string $mode = 'merge', ?array $restrict_user_ids = null): array
    {
        $mode = sanitize_key($mode);
        if (!in_array($mode, array('merge', 'replace'), true)) {
            $mode = 'merge';
        }

        $allowed_caps = vms_ops_admin_team_caps();
        $linked_staff_index = vms_ops_admin_collect_linked_staff_index();
        $restrict_lookup = null;
        if (is_array($restrict_user_ids) && !empty($restrict_user_ids)) {
            $restrict_lookup = array_fill_keys(array_filter(array_map('absint', $restrict_user_ids)), true);
        }
        $stats = array(
            'mode' => $mode,
            'users' => 0,
            'updated' => 0,
            'added' => 0,
            'removed' => 0,
            'skipped_no_profile' => 0,
        );

        foreach ($linked_staff_index as $user_id => $linked_staff_entry) {
            $user_id = absint((string) $user_id);
            if ($user_id <= 0) {
                continue;
            }
            if (is_array($restrict_lookup) && !isset($restrict_lookup[$user_id])) {
                continue;
            }
            $stats['users']++;

            $user = new WP_User($user_id);
            if (!($user instanceof WP_User) || $user->ID <= 0) {
                $stats['skipped_no_profile']++;
                continue;
            }

            $resolved = function_exists('vms_ops_admin_resolve_caps_for_linked_staff_entry')
                ? vms_ops_admin_resolve_caps_for_linked_staff_entry((array) $linked_staff_entry, $role_profiles)
                : array('desired_caps' => array());
            $desired_caps = array_values(array_intersect(
                $allowed_caps,
                array_values(array_unique(array_map('sanitize_text_field', (array) ($resolved['desired_caps'] ?? array()))))
            ));

            if (empty($desired_caps)) {
                $stats['skipped_no_profile']++;
                continue;
            }

            $before_effective_caps = vms_ops_admin_user_effective_team_caps($user, $allowed_caps);

            $target_caps = $mode === 'replace'
                ? $desired_caps
                : array_values(array_unique(array_merge($before_effective_caps, $desired_caps)));

            foreach ($allowed_caps as $cap) {
                $has_now = in_array($cap, $before_effective_caps, true);
                $should_have = in_array($cap, $target_caps, true);
                if ($has_now === $should_have) {
                    continue;
                }

                if ($should_have) {
                    $user->add_cap($cap);
                } else {
                    $user->remove_cap($cap);
                }
            }

            if ($mode === 'replace' && function_exists('vms_ops_set_user_cap_override_selection')) {
                vms_ops_set_user_cap_override_selection($user_id, $desired_caps, $allowed_caps);
            }

            $after_effective_caps = vms_ops_admin_user_effective_team_caps($user, $allowed_caps);
            $added_caps = array_values(array_diff($after_effective_caps, $before_effective_caps));
            $removed_caps = array_values(array_diff($before_effective_caps, $after_effective_caps));

            $stats['added'] += count($added_caps);
            $stats['removed'] += count($removed_caps);

            if (function_exists('vms_ops_setup_status_mark_user_synced')) {
                vms_ops_setup_status_mark_user_synced($user_id, $mode);
            }

            if (!empty($added_caps) || !empty($removed_caps)) {
                $stats['updated']++;
            }
        }

        return $stats;
    }
}

if (!function_exists('vms_ops_admin_render_teams_page')) {
    function vms_ops_admin_render_teams_page(): void
    {
        if (!vms_ops_admin_current_user_can_manage()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        $users = get_users(array(
            'number' => 200,
            'orderby' => 'display_name',
            'order' => 'ASC',
        ));

        $caps = vms_ops_admin_team_caps();
        $roles = vms_ops_admin_get_staff_roles();
        $role_profiles = vms_ops_admin_role_profiles_get();
        $linked_staff_index = vms_ops_admin_collect_linked_staff_index();
        $status_context = function_exists('vms_ops_setup_status_context') ? vms_ops_setup_status_context() : array();
        $status_rows = array();
        $summary_counts = array(
            'tracked_users' => 0,
            'users_need_setup' => 0,
            'missing_staff_links' => 0,
            'missing_staff_roles' => 0,
            'needs_role_sync' => 0,
            'permission_mismatch' => 0,
            'custom_overrides' => 0,
            'no_ops_access' => 0,
        );
        foreach ($users as $user) {
            if (!($user instanceof WP_User)) {
                continue;
            }

            $status = function_exists('vms_ops_setup_status_for_user')
                ? vms_ops_setup_status_for_user($user, $status_context)
                : array();
            $status_rows[(int) $user->ID] = $status;
            if (!empty($status['tracked'])) {
                $summary_counts['tracked_users']++;
            }

            foreach (array_keys($summary_counts) as $count_key) {
                if ($count_key === 'tracked_users') {
                    continue;
                }
                $summary_counts[$count_key] += isset($status['counts'][$count_key]) ? (int) $status['counts'][$count_key] : 0;
            }
        }
        $linked_staff_users = count($linked_staff_index);
        $linked_staff_users_with_roles = 0;
        foreach ($linked_staff_index as $linked_staff_entry) {
            if (!empty($linked_staff_entry['role_ids'])) {
                $linked_staff_users_with_roles++;
            }
        }
        $sync_mode = isset($_GET['sync_mode']) ? sanitize_key((string) $_GET['sync_mode']) : '';
        $sync_users = isset($_GET['sync_users']) ? absint((string) $_GET['sync_users']) : 0;
        $sync_updated = isset($_GET['sync_updated']) ? absint((string) $_GET['sync_updated']) : 0;
        $sync_added = isset($_GET['sync_added']) ? absint((string) $_GET['sync_added']) : 0;
        $sync_removed = isset($_GET['sync_removed']) ? absint((string) $_GET['sync_removed']) : 0;
        $sync_skipped = isset($_GET['sync_skipped']) ? absint((string) $_GET['sync_skipped']) : 0;
        $focus_user_id = isset($_GET['focus_user']) ? absint((string) $_GET['focus_user']) : 0;
        $teams_page_url = add_query_arg(array(
            'page' => vms_ops_admin_teams_page_slug(),
        ), admin_url('admin.php'));
        ?>
        <div class="wrap vms-ops-teams-page">
            <div class="vms-ops-page-head" data-tour-anchor="teams-intro">
                <div>
                    <h1><?php esc_html_e('Ops Team Capability Assignment', 'vms-ops-console-premium'); ?></h1>
                    <p class="description"><?php esc_html_e('A WordPress role only helps someone log in. Ops shows a user as truly Ready only when their Staff link, Staff Role, role-profile sync, and required scanner permissions all line up.', 'vms-ops-console-premium'); ?></p>
                </div>
                <button type="button" class="button button-secondary" data-vms-ops-teams-tour-start><?php esc_html_e('Start Teams Tour', 'vms-ops-console-premium'); ?></button>
            </div>
            <?php if (!empty($_GET['updated'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Team capabilities saved.', 'vms-ops-console-premium'); ?></p></div>
            <?php endif; ?>
            <?php if (!empty($_GET['profiles_updated'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Staff role capability profiles saved.', 'vms-ops-console-premium'); ?></p></div>
            <?php endif; ?>
            <?php if (!empty($_GET['synced'])) : ?>
                <div class="notice notice-success is-dismissible">
                    <p>
                        <?php
                        printf(
                            /* translators: 1: mode, 2: users evaluated, 3: users changed, 4: caps added, 5: caps removed, 6: users skipped */
                            esc_html__('Role sync complete (%1$s). Users evaluated: %2$d. Users changed: %3$d. Caps added: %4$d. Caps removed: %5$d. Skipped (no linked role profile): %6$d.', 'vms-ops-console-premium'),
                            esc_html($sync_mode === 'replace' ? __('replace', 'vms-ops-console-premium') : __('merge', 'vms-ops-console-premium')),
                            (int) $sync_users,
                            (int) $sync_updated,
                            (int) $sync_added,
                            (int) $sync_removed,
                            (int) $sync_skipped
                        );
                        ?>
                    </p>
                </div>
            <?php endif; ?>
            <?php if (!empty($_GET['row_synced'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('User setup resynced from Staff Role profiles.', 'vms-ops-console-premium'); ?></p></div>
            <?php endif; ?>
            <?php if (!empty($_GET['flagged_synced'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Flagged users were resynced from Staff Role profiles.', 'vms-ops-console-premium'); ?></p></div>
            <?php endif; ?>
            <?php if (!empty($_GET['recalculated'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Setup status recalculated from current Staff links, roles, and capability state.', 'vms-ops-console-premium'); ?></p></div>
            <?php endif; ?>
            <?php if (!empty($_GET['resync_failed'])) : ?>
                <div class="notice notice-error is-dismissible"><p><?php esc_html_e('That user could not be resynced.', 'vms-ops-console-premium'); ?></p></div>
            <?php endif; ?>

            <section id="vms-ops-team-status-summary" class="vms-ops-teams-summary" data-tour-anchor="status-summary">
                <div class="vms-ops-teams-summary-head">
                    <div>
                        <h2><?php esc_html_e('Setup Status Overview', 'vms-ops-console-premium'); ?></h2>
                        <p class="description"><?php esc_html_e('Use this summary to spot blocking setup gaps before someone arrives at the door or bar and discovers their scanner access is half-configured.', 'vms-ops-console-premium'); ?></p>
                    </div>
                    <div class="vms-ops-teams-summary-actions">
                        <a class="button button-secondary" href="<?php echo esc_url(vms_ops_setup_status_resync_flagged_url()); ?>"><?php esc_html_e('Resync Flagged Users', 'vms-ops-console-premium'); ?></a>
                        <a class="button" href="<?php echo esc_url($teams_page_url . '&recalculated=1'); ?>#vms-ops-teams-user-grid"><?php esc_html_e('Recalculate Setup Status', 'vms-ops-console-premium'); ?></a>
                    </div>
                </div>
                <div class="vms-ops-teams-summary-stats">
                    <a class="vms-ops-teams-summary-card is-alert" href="#vms-ops-teams-user-grid">
                        <strong><?php echo esc_html((string) (int) $summary_counts['users_need_setup']); ?></strong>
                        <span><?php esc_html_e('Users Need Setup', 'vms-ops-console-premium'); ?></span>
                    </a>
                    <a class="vms-ops-teams-summary-card" href="#vms-ops-teams-user-grid">
                        <strong><?php echo esc_html((string) (int) $summary_counts['missing_staff_links']); ?></strong>
                        <span><?php esc_html_e('Missing Staff Links', 'vms-ops-console-premium'); ?></span>
                    </a>
                    <a class="vms-ops-teams-summary-card" href="#vms-ops-teams-user-grid">
                        <strong><?php echo esc_html((string) (int) $summary_counts['missing_staff_roles']); ?></strong>
                        <span><?php esc_html_e('Missing Staff Roles', 'vms-ops-console-premium'); ?></span>
                    </a>
                    <a class="vms-ops-teams-summary-card" href="#vms-ops-teams-user-grid">
                        <strong><?php echo esc_html((string) (int) $summary_counts['needs_role_sync']); ?></strong>
                        <span><?php esc_html_e('Need Role Sync', 'vms-ops-console-premium'); ?></span>
                    </a>
                    <a class="vms-ops-teams-summary-card" href="#vms-ops-teams-user-grid">
                        <strong><?php echo esc_html((string) (int) $summary_counts['permission_mismatch']); ?></strong>
                        <span><?php esc_html_e('Permission Mismatch', 'vms-ops-console-premium'); ?></span>
                    </a>
                    <a class="vms-ops-teams-summary-card" href="#vms-ops-teams-user-grid">
                        <strong><?php echo esc_html((string) (int) $summary_counts['custom_overrides']); ?></strong>
                        <span><?php esc_html_e('Custom Overrides', 'vms-ops-console-premium'); ?></span>
                    </a>
                    <a class="vms-ops-teams-summary-card" href="#vms-ops-teams-user-grid">
                        <strong><?php echo esc_html((string) (int) $summary_counts['no_ops_access']); ?></strong>
                        <span><?php esc_html_e('No Ops Access', 'vms-ops-console-premium'); ?></span>
                    </a>
                </div>
            </section>

            <section id="vms-ops-team-role-profiles" data-tour-anchor="role-profiles">
                <h2><?php esc_html_e('Staff Role Capability Profiles', 'vms-ops-console-premium'); ?></h2>
                <p class="description"><?php esc_html_e('Set the standard Ops capability package for each Staff Role here. These profiles are the source of truth for one-click sync, not the WordPress role name alone.', 'vms-ops-console-premium'); ?></p>
                <p class="description"><?php esc_html_e('Known Ticket/Door and Bar/Bartender roles keep their baseline Ops scanner caps automatically so core shift duties do not disappear when a saved profile is blank or stale. Add any extra caps here as needed.', 'vms-ops-console-premium'); ?></p>

                <?php if (empty($roles)) : ?>
                    <div class="notice notice-warning inline"><p><?php esc_html_e('No Staff Roles found. Create roles first, then return here to configure role profiles.', 'vms-ops-console-premium'); ?></p></div>
                <?php else : ?>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <?php wp_nonce_field('vms_ops_save_role_profiles'); ?>
                        <input type="hidden" name="action" value="vms_ops_save_role_profiles">
                        <table class="widefat striped vms-ops-admin-table vms-ops-admin-role-profiles">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Staff Role', 'vms-ops-console-premium'); ?></th>
                                    <?php foreach ($caps as $cap) : ?>
                                        <th><span title="<?php echo esc_attr($cap); ?>"><?php echo esc_html(vms_ops_admin_team_cap_label($cap)); ?></span></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($roles as $role) : ?>
                                    <?php
                                    $role_id = (int) ($role->term_id ?? 0);
                                    if ($role_id <= 0) {
                                        continue;
                                    }
                                    $role_caps = isset($role_profiles[(string) $role_id]) && is_array($role_profiles[(string) $role_id])
                                        ? $role_profiles[(string) $role_id]
                                        : array();
                                    ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo esc_html((string) $role->name); ?></strong><br>
                                            <code>#<?php echo esc_html((string) $role_id); ?></code>
                                        </td>
                                        <?php foreach ($caps as $cap) : ?>
                                            <td>
                                                <label>
                                                    <input type="checkbox" name="role_caps[<?php echo esc_attr((string) $role_id); ?>][]" value="<?php echo esc_attr($cap); ?>" <?php checked(in_array($cap, $role_caps, true)); ?>>
                                                </label>
                                            </td>
                                        <?php endforeach; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php submit_button(__('Save Role Profiles', 'vms-ops-console-premium')); ?>
                    </form>
                <?php endif; ?>
            </section>

            <section class="vms-ops-admin-team-sync-block" data-tour-anchor="sync-actions">
                <h2><?php esc_html_e('Role Sync Actions', 'vms-ops-console-premium'); ?></h2>
                <p class="description"><?php esc_html_e('When a user shows Needs Role Sync, use this section to apply the saved Staff Role profiles to linked users. Use merge to preserve manual overrides, or replace to make linked users match the role profile exactly.', 'vms-ops-console-premium'); ?></p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="vms-ops-admin-team-sync-form">
                    <?php wp_nonce_field('vms_ops_sync_role_profiles'); ?>
                    <input type="hidden" name="action" value="vms_ops_sync_role_profiles">
                    <label for="vms_ops_role_sync_mode"><?php esc_html_e('Role sync mode', 'vms-ops-console-premium'); ?></label>
                    <select id="vms_ops_role_sync_mode" name="sync_mode">
                        <option value="merge"><?php esc_html_e('Merge (add role caps, keep manual overrides)', 'vms-ops-console-premium'); ?></option>
                        <option value="replace"><?php esc_html_e('Replace (set linked users to role profile exactly)', 'vms-ops-console-premium'); ?></option>
                    </select>
                    <?php submit_button(__('Run Role Sync for Linked Users', 'vms-ops-console-premium'), 'secondary', 'submit', false); ?>
                </form>
                <p class="description">
                    <?php
                    printf(
                        /* translators: 1: linked staff users, 2: linked staff users with at least one role, 3: tracked Ops users */
                        esc_html__('Role Sync uses Staff -> Portal User links. Linked staff users found: %1$d. Linked staff users with roles: %2$d. Ops-tracked users currently in this grid: %3$d.', 'vms-ops-console-premium'),
                        (int) $linked_staff_users,
                        (int) $linked_staff_users_with_roles,
                        (int) $summary_counts['tracked_users']
                    );
                    ?>
                </p>
            </section>

            <hr>
            <section id="vms-ops-teams-user-grid" data-tour-anchor="user-grid">
                <h2><?php esc_html_e('Per-User Overrides + Setup Checklist', 'vms-ops-console-premium'); ?></h2>
                <p class="description"><?php esc_html_e('Use this grid for one-off exceptions after role sync. The Setup Status column explains why a user is blocked, stale, or operating with a custom override.', 'vms-ops-console-premium'); ?></p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="vms-ops-admin-user-caps-form">
                    <?php wp_nonce_field('vms_ops_save_team_caps'); ?>
                    <input type="hidden" name="action" value="vms_ops_save_team_caps">
                    <input type="hidden" name="caps_payload" value="">
                    <table class="widefat striped vms-ops-admin-table vms-ops-admin-user-caps">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('User', 'vms-ops-console-premium'); ?></th>
                                <th><?php esc_html_e('Setup Status', 'vms-ops-console-premium'); ?></th>
                                <th><?php esc_html_e('Linked Staff / Roles', 'vms-ops-console-premium'); ?></th>
                                <?php foreach ($caps as $cap) : ?>
                                    <th><span title="<?php echo esc_attr($cap); ?>"><?php echo esc_html(vms_ops_admin_team_cap_label($cap)); ?></span></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user) : ?>
                                <?php
                                if (!($user instanceof WP_User)) {
                                    continue;
                                }
                                $user_id = (int) $user->ID;
                                $status = isset($status_rows[$user_id]) && is_array($status_rows[$user_id]) ? $status_rows[$user_id] : array();
                                $linked_staff_entry = isset($linked_staff_index[$user_id]) && is_array($linked_staff_index[$user_id])
                                    ? $linked_staff_index[$user_id]
                                    : array(
                                        'staff_labels' => array(),
                                        'role_names' => array(),
                                    );
                                $staff_labels = isset($linked_staff_entry['staff_labels']) && is_array($linked_staff_entry['staff_labels'])
                                    ? $linked_staff_entry['staff_labels']
                                    : array();
                                $role_names = isset($linked_staff_entry['role_names']) && is_array($linked_staff_entry['role_names'])
                                    ? $linked_staff_entry['role_names']
                                    : array();
                                $role_labels = function_exists('vms_ops_setup_status_get_user_role_labels')
                                    ? array_values(vms_ops_setup_status_get_user_role_labels($user))
                                    : array_map('strval', (array) $user->roles);
                                $status_level = sanitize_html_class((string) ($status['status_level'] ?? 'neutral'));
                                $status_label = (string) ($status['status_label'] ?? __('No Ops Access', 'vms-ops-console-premium'));
                                $status_summary = trim((string) ($status['summary'] ?? ''));
                                ?>
                                <tr
                                    id="vms-ops-team-user-<?php echo esc_attr((string) $user_id); ?>"
                                    data-user-id="<?php echo esc_attr((string) $user_id); ?>"
                                    data-status-key="<?php echo esc_attr((string) ($status['status_key'] ?? '')); ?>"
                                    class="<?php echo $focus_user_id === $user_id ? 'is-focus-row' : ''; ?>"
                                >
                                    <td>
                                        <strong><?php echo esc_html($user->display_name); ?></strong><br>
                                        <code><?php echo esc_html($user->user_email); ?></code><br>
                                        <span class="description"><?php echo esc_html__('WP Roles:', 'vms-ops-console-premium') . ' ' . esc_html(!empty($role_labels) ? implode(', ', $role_labels) : __('None', 'vms-ops-console-premium')); ?></span>
                                        <input type="hidden" name="user_ids[]" value="<?php echo esc_attr((string) $user_id); ?>">
                                    </td>
                                    <td class="vms-ops-team-status-cell">
                                        <span class="vms-ops-team-status-badge <?php echo esc_attr('is-' . $status_level); ?>"><?php echo esc_html($status_label); ?></span>
                                        <?php if ($status_summary !== '') : ?>
                                            <p class="vms-ops-team-status-summary"><?php echo esc_html($status_summary); ?></p>
                                        <?php endif; ?>
                                        <ul class="vms-ops-team-checklist">
                                            <?php foreach ((array) ($status['checklist'] ?? array()) as $item) : ?>
                                                <li class="<?php echo !empty($item['ok']) ? 'is-ok' : 'is-no'; ?>">
                                                    <span class="vms-ops-team-checklist-state"><?php echo !empty($item['ok']) ? esc_html__('Yes', 'vms-ops-console-premium') : esc_html__('No', 'vms-ops-console-premium'); ?></span>
                                                    <span><?php echo esc_html((string) ($item['label'] ?? '')); ?></span>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                        <div class="vms-ops-team-actions">
                                            <?php foreach ((array) ($status['actions'] ?? array()) as $action) : ?>
                                                <a
                                                    class="<?php echo esc_attr(!empty($action['kind']) && $action['kind'] === 'primary' ? 'button button-primary button-small' : 'button button-secondary button-small'); ?>"
                                                    href="<?php echo esc_url((string) ($action['url'] ?? '#')); ?>"
                                                >
                                                    <?php echo esc_html((string) ($action['label'] ?? '')); ?>
                                                </a>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (!empty($staff_labels)) : ?>
                                            <strong><?php echo esc_html(implode(', ', $staff_labels)); ?></strong><br>
                                            <span class="description">
                                                <?php
                                                echo !empty($role_names)
                                                    ? esc_html(implode(', ', $role_names))
                                                    : esc_html__('No staff role assigned', 'vms-ops-console-premium');
                                                ?>
                                            </span>
                                        <?php else : ?>
                                            <span class="description"><?php esc_html_e('Not linked to a Staff record', 'vms-ops-console-premium'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <?php foreach ($caps as $cap) : ?>
                                        <td>
                                            <label>
                                                <input
                                                    type="checkbox"
                                                    class="vms-ops-team-cap-toggle"
                                                    data-user-id="<?php echo esc_attr((string) $user_id); ?>"
                                                    data-cap="<?php echo esc_attr($cap); ?>"
                                                    name="caps[<?php echo esc_attr((string) $user_id); ?>][]"
                                                    value="<?php echo esc_attr($cap); ?>"
                                                    <?php checked(user_can($user, $cap)); ?>
                                                >
                                            </label>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php submit_button(__('Save Team Capabilities', 'vms-ops-console-premium')); ?>
                </form>
            </section>
        </div>
        <?php
    }
}

if (!function_exists('vms_ops_admin_teams_page_slug')) {
    function vms_ops_admin_teams_page_slug(): string
    {
        if (vms_ops_has_core_function('vms_admin_ui_registered_page_url')) {
            $legacy = vms_ops_call_core_function('vms_admin_ui_registered_page_url', 'vms-ops-console-teams');
            if (is_string($legacy) && $legacy !== '') {
                return 'vms-ops-console-teams';
            }
        }

        if (vms_ops_has_core_function('vms_admin_ui_page_url')) {
            return 'vms-teams';
        }

        return 'vms-ops-console-teams';
    }
}

if (!function_exists('vms_ops_admin_handle_save_team_caps')) {
    function vms_ops_admin_handle_save_team_caps(): void
    {
        if (!vms_ops_admin_current_user_can_manage()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        check_admin_referer('vms_ops_save_team_caps');

        $allowed_caps = vms_ops_admin_team_caps();
        $posted_caps = array();

        $payload_raw = isset($_POST['caps_payload'])
            ? (string) wp_unslash($_POST['caps_payload'])
            : '';
        if ($payload_raw !== '') {
            $decoded = json_decode($payload_raw, true);
            if (is_array($decoded)) {
                foreach ($decoded as $raw_user_id => $raw_caps) {
                    $user_id = absint((string) $raw_user_id);
                    if ($user_id <= 0 || !is_array($raw_caps)) {
                        continue;
                    }
                    $posted_caps[$user_id] = $raw_caps;
                }
            }
        }

        if (empty($posted_caps) && isset($_POST['caps']) && is_array($_POST['caps'])) {
            $posted_caps = (array) wp_unslash($_POST['caps']);
        }

        $user_ids = array_keys($posted_caps);
        if (empty($user_ids) && isset($_POST['user_ids']) && is_array($_POST['user_ids'])) {
            $user_ids = array_map('absint', (array) wp_unslash($_POST['user_ids']));
        }

        foreach ($user_ids as $raw_user_id) {
            $user_id = absint((string) $raw_user_id);
            if ($user_id <= 0) {
                continue;
            }

            $user = new WP_User($user_id);
            if (!($user instanceof WP_User) || $user->ID <= 0) {
                continue;
            }

            $selected_for_user = isset($posted_caps[$user_id]) && is_array($posted_caps[$user_id]) ? $posted_caps[$user_id] : array();
            $selected_for_user = array_values(array_unique(array_map('sanitize_text_field', $selected_for_user)));
            $selected_for_user = array_values(array_filter($selected_for_user, static function (string $cap) use ($allowed_caps): bool {
                return $cap !== '' && in_array($cap, $allowed_caps, true);
            }));

            // If any Ops Console capability is granted, always include the base access capability to avoid lockouts.
            $use_pwa_cap = vms_ops_capability_use_pwa();
            $has_any = false;
            foreach ($selected_for_user as $cap) {
                if ($cap && $cap !== $use_pwa_cap) {
                    $has_any = true;
                    break;
                }
            }
            if ($has_any && !in_array($use_pwa_cap, $selected_for_user, true)) {
                $selected_for_user[] = $use_pwa_cap;
            }

            if (function_exists('vms_ops_set_user_cap_override_selection')) {
                vms_ops_set_user_cap_override_selection($user_id, $selected_for_user, $allowed_caps);
                if (function_exists('vms_ops_setup_status_mark_user_synced')) {
                    vms_ops_setup_status_mark_user_synced($user_id, 'manual_override');
                }
                continue;
            }

            foreach ($allowed_caps as $cap) {
                if (in_array($cap, $selected_for_user, true)) {
                    $user->add_cap($cap);
                } else {
                    $user->remove_cap($cap);
                }
            }

            if (function_exists('vms_ops_setup_status_mark_user_synced')) {
                vms_ops_setup_status_mark_user_synced($user_id, 'manual_override');
            }
        }

        $target = add_query_arg(array(
            'page' => vms_ops_admin_teams_page_slug(),
            'updated' => 1,
        ), admin_url('admin.php'));

        wp_safe_redirect($target);
        exit;
    }
}
add_action('admin_post_vms_ops_save_team_caps', 'vms_ops_admin_handle_save_team_caps');

if (!function_exists('vms_ops_admin_handle_save_role_profiles')) {
    function vms_ops_admin_handle_save_role_profiles(): void
    {
        if (!vms_ops_admin_current_user_can_manage()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        check_admin_referer('vms_ops_save_role_profiles');

        $raw_profiles = isset($_POST['role_caps']) && is_array($_POST['role_caps'])
            ? (array) wp_unslash($_POST['role_caps'])
            : array();
        $old_profiles = vms_ops_admin_role_profiles_get_stored();
        $clean_profiles = vms_ops_admin_sanitize_role_profile_caps($raw_profiles);

        update_option(vms_ops_admin_role_profile_option_key(), $clean_profiles, false);
        if (function_exists('vms_ops_setup_status_touch_role_profile_meta')) {
            vms_ops_setup_status_touch_role_profile_meta($old_profiles, $clean_profiles);
        }

        $target = add_query_arg(array(
            'page' => vms_ops_admin_teams_page_slug(),
            'profiles_updated' => 1,
        ), admin_url('admin.php'));

        wp_safe_redirect($target);
        exit;
    }
}
add_action('admin_post_vms_ops_save_role_profiles', 'vms_ops_admin_handle_save_role_profiles');

if (!function_exists('vms_ops_admin_handle_sync_role_profiles')) {
    function vms_ops_admin_handle_sync_role_profiles(): void
    {
        if (!vms_ops_admin_current_user_can_manage()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        check_admin_referer('vms_ops_sync_role_profiles');

        $sync_mode = isset($_POST['sync_mode'])
            ? sanitize_key((string) wp_unslash($_POST['sync_mode']))
            : 'merge';
        if (!in_array($sync_mode, array('merge', 'replace'), true)) {
            $sync_mode = 'merge';
        }

        $profiles = vms_ops_admin_role_profiles_get();
        $stats = vms_ops_admin_apply_role_profiles_to_linked_users($profiles, $sync_mode);

        $target = add_query_arg(array(
            'page' => vms_ops_admin_teams_page_slug(),
            'synced' => 1,
            'sync_mode' => (string) ($stats['mode'] ?? $sync_mode),
            'sync_users' => (int) ($stats['users'] ?? 0),
            'sync_updated' => (int) ($stats['updated'] ?? 0),
            'sync_added' => (int) ($stats['added'] ?? 0),
            'sync_removed' => (int) ($stats['removed'] ?? 0),
            'sync_skipped' => (int) ($stats['skipped_no_profile'] ?? 0),
        ), admin_url('admin.php'));

        wp_safe_redirect($target);
        exit;
    }
}
add_action('admin_post_vms_ops_sync_role_profiles', 'vms_ops_admin_handle_sync_role_profiles');

if (!function_exists('vms_ops_admin_handle_resync_setup_user')) {
    function vms_ops_admin_handle_resync_setup_user(): void
    {
        if (!vms_ops_admin_current_user_can_manage()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        $user_id = isset($_GET['user_id']) ? absint((string) $_GET['user_id']) : 0;
        if ($user_id <= 0) {
            wp_safe_redirect(add_query_arg(array(
                'page' => vms_ops_admin_teams_page_slug(),
                'resync_failed' => 1,
            ), admin_url('admin.php')));
            exit;
        }

        check_admin_referer('vms_ops_resync_setup_user_' . $user_id);

        $profiles = vms_ops_admin_role_profiles_get();
        $stats = vms_ops_admin_apply_role_profiles_to_linked_users($profiles, 'replace', array($user_id));

        $target = add_query_arg(array(
            'page' => vms_ops_admin_teams_page_slug(),
            'row_synced' => 1,
            'sync_users' => (int) ($stats['users'] ?? 0),
            'sync_updated' => (int) ($stats['updated'] ?? 0),
            'focus_user' => $user_id,
        ), admin_url('admin.php'));

        wp_safe_redirect($target . '#vms-ops-team-user-' . $user_id);
        exit;
    }
}
add_action('admin_post_vms_ops_resync_setup_user', 'vms_ops_admin_handle_resync_setup_user');

if (!function_exists('vms_ops_admin_handle_resync_flagged_users')) {
    function vms_ops_admin_handle_resync_flagged_users(): void
    {
        if (!vms_ops_admin_current_user_can_manage()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        check_admin_referer('vms_ops_resync_flagged_users');

        $profiles = vms_ops_admin_role_profiles_get();
        $context = function_exists('vms_ops_setup_status_context') ? vms_ops_setup_status_context() : array();
        $users = get_users(array(
            'number' => 200,
            'orderby' => 'display_name',
            'order' => 'ASC',
        ));

        $target_user_ids = array();
        foreach ($users as $user) {
            if (!($user instanceof WP_User)) {
                continue;
            }

            $status = function_exists('vms_ops_setup_status_for_user')
                ? vms_ops_setup_status_for_user($user, $context)
                : array();
            if (empty($status['tracked'])) {
                continue;
            }
            if (!empty($status['needs_sync']) || !empty($status['permission_mismatch'])) {
                $target_user_ids[] = (int) $user->ID;
            }
        }

        $stats = vms_ops_admin_apply_role_profiles_to_linked_users($profiles, 'replace', $target_user_ids);
        $target = add_query_arg(array(
            'page' => vms_ops_admin_teams_page_slug(),
            'flagged_synced' => 1,
            'sync_users' => (int) ($stats['users'] ?? 0),
            'sync_updated' => (int) ($stats['updated'] ?? 0),
        ), admin_url('admin.php'));

        wp_safe_redirect($target . '#vms-ops-teams-user-grid');
        exit;
    }
}
add_action('admin_post_vms_ops_resync_flagged_users', 'vms_ops_admin_handle_resync_flagged_users');
