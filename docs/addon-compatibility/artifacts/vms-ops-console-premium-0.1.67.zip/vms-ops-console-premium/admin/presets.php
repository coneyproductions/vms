<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_admin_manage_capability')) {
    function vms_ops_admin_manage_capability(): string
    {
        $cap = 'manage_options';

        if (vms_ops_has_core_function('vms_admin_ui_ops_capability')) {
            $candidate = sanitize_text_field((string) vms_ops_call_core_function('vms_admin_ui_ops_capability'));
            if ($candidate !== '') {
                $cap = $candidate;
            }
        } elseif (vms_ops_has_core_function('vms_admin_ui_data_tools_capability')) {
            $candidate = sanitize_text_field((string) vms_ops_call_core_function('vms_admin_ui_data_tools_capability'));
            if ($candidate !== '') {
                $cap = $candidate;
            }
        }

        return $cap;
    }
}

if (!function_exists('vms_ops_admin_current_user_can_manage')) {
    function vms_ops_admin_current_user_can_manage(): bool
    {
        return current_user_can(vms_ops_admin_manage_capability()) || current_user_can('manage_options');
    }
}

if (!function_exists('vms_ops_admin_register_presets_submenu')) {
    function vms_ops_admin_register_presets_submenu(): void
    {
        $parent = apply_filters('vms_admin_parent_slug', 'vms-dashboard');
        $parent = sanitize_text_field((string) $parent);
        if ($parent === '') {
            $parent = 'vms-dashboard';
        }

        add_submenu_page(
            $parent,
            __('Alert Presets', 'vms-ops-console-premium'),
            __('Alert Presets', 'vms-ops-console-premium'),
            vms_ops_admin_manage_capability(),
            'vms-ops-console-presets',
            'vms_ops_admin_render_presets_page'
        );
    }
}
if (!function_exists('vms_ops_admin_presets_to_text')) {
    function vms_ops_admin_presets_to_text(array $presets): string
    {
        $lines = array();
        foreach ($presets as $preset) {
            if (!is_array($preset)) {
                continue;
            }
            $lines[] = implode('|', array(
                (string) ($preset['key'] ?? ''),
                (string) ($preset['label'] ?? ''),
                (string) ($preset['audience'] ?? 'all'),
                (string) ($preset['urgency'] ?? 'normal'),
                (string) ($preset['message'] ?? ''),
            ));
        }
        return implode("\n", $lines);
    }
}

if (!function_exists('vms_ops_admin_parse_preset_lines')) {
    function vms_ops_admin_parse_preset_lines(string $text): array
    {
        $rows = preg_split('/\r\n|\r|\n/', trim($text));
        if (!is_array($rows)) {
            return array();
        }

        $presets = array();
        foreach ($rows as $row) {
            $row = trim($row);
            if ($row === '') {
                continue;
            }

            $parts = array_map('trim', explode('|', $row));

            // Back-compat: allow both 4-part and 5-part formats.
            // - legacy: key|label|urgency|message
            // - current: key|label|audience|urgency|message
            $has_audience = count($parts) >= 5;
            $presets[] = array(
                'key' => sanitize_key((string) ($parts[0] ?? '')),
                'label' => sanitize_text_field((string) ($parts[1] ?? '')),
                'audience' => sanitize_key((string) ($has_audience ? ($parts[2] ?? 'all') : 'all')),
                'urgency' => vms_ops_alert_sanitize_urgency((string) ($has_audience ? ($parts[3] ?? 'normal') : ($parts[2] ?? 'normal'))),
                'message' => sanitize_text_field((string) ($has_audience ? ($parts[4] ?? '') : ($parts[3] ?? ''))),
            );
        }

        return $presets;
    }
}

if (!function_exists('vms_ops_admin_render_presets_page')) {
    function vms_ops_admin_render_presets_page(): void
    {
        if (!vms_ops_admin_current_user_can_manage()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        $venue_id_param_provided = isset($_GET['venue_id']);
        $venue_id = $venue_id_param_provided ? absint((string) $_GET['venue_id']) : 0;
        $console_type = isset($_GET['console_type']) ? sanitize_key((string) $_GET['console_type']) : 'ops';
        if ($console_type === '') {
            $console_type = 'ops';
        }

        $venues = function_exists('vms_ops_get_venues_list') ? vms_ops_get_venues_list() : array();
        if (!$venue_id_param_provided && $venue_id <= 0 && count($venues) === 1) {
            $venue_id = (int) ($venues[0]['id'] ?? 0);
        }

        $presets = vms_ops_alert_presets_get($venue_id, $console_type);

        $audience_choices = array(
            'all' => __('All on-duty staff', 'vms-ops-console-premium'),
            'ticket' => __('Ticket staff only', 'vms-ops-console-premium'),
            'id' => __('ID staff only', 'vms-ops-console-premium'),
            'managers' => __('Managers only', 'vms-ops-console-premium'),
        );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Alert Presets', 'vms-ops-console-premium'); ?></h1>
            <?php if (!empty($_GET['updated'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Alert presets saved.', 'vms-ops-console-premium'); ?></p></div>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('vms_ops_save_alert_presets'); ?>
                <input type="hidden" name="action" value="vms_ops_save_alert_presets">
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="vms_ops_preset_venue_id"><?php esc_html_e('Venue', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <select id="vms_ops_preset_venue_id" name="venue_id">
                                <option value="0"><?php esc_html_e('Global (all venues)', 'vms-ops-console-premium'); ?></option>
                                <?php foreach ($venues as $venue) :
                                    $vid = (int) ($venue['id'] ?? 0);
                                    if ($vid <= 0) {
                                        continue;
                                    }
                                    ?>
                                    <option value="<?php echo esc_attr((string) $vid); ?>"<?php selected($venue_id, $vid); ?>><?php echo esc_html((string) ($venue['name'] ?? ('Venue #' . $vid))); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_preset_console_type"><?php esc_html_e('Console Type', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <input id="vms_ops_preset_console_type" name="console_type" type="text" value="<?php echo esc_attr($console_type); ?>">
                            <p class="description"><?php esc_html_e('Examples: ops, ticket, id, all', 'vms-ops-console-premium'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vms_ops_preset_lines"><?php esc_html_e('Presets', 'vms-ops-console-premium'); ?></label></th>
                        <td>
                            <p class="description">
                                <?php
                                echo esc_html__('Recipients are on-duty users with “Receive Alerts”, filtered by the “Notify” column below.', 'vms-ops-console-premium');
                                ?>
                            </p>

                            <table class="widefat striped vms-ops-admin-table vms-ops-admin-presets-table">
                                <thead>
                                    <tr>
                                        <th><?php esc_html_e('Key (auto)', 'vms-ops-console-premium'); ?></th>
                                        <th><?php esc_html_e('Label', 'vms-ops-console-premium'); ?></th>
                                        <th><?php esc_html_e('Notify', 'vms-ops-console-premium'); ?></th>
                                        <th><?php esc_html_e('Urgency', 'vms-ops-console-premium'); ?></th>
                                        <th><?php esc_html_e('Message', 'vms-ops-console-premium'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $rows = array_values((array) $presets);
                                $blank_rows = 4;
                                $total = max(count($rows), 0) + $blank_rows;
                                for ($i = 0; $i < $total; $i++) :
                                    $preset = $rows[$i] ?? array();
                                    $key = (string) ($preset['key'] ?? '');
                                    $label = (string) ($preset['label'] ?? '');
                                    $audience = (string) ($preset['audience'] ?? 'all');
                                    if (!isset($audience_choices[$audience])) {
                                        $audience = 'all';
                                    }
                                    $urgency = (string) ($preset['urgency'] ?? 'normal');
                                    $message = (string) ($preset['message'] ?? '');
                                    ?>
                                    <tr>
                                        <td><input class="vms-ops-preset-key" type="text" name="presets[<?php echo (int) $i; ?>][key]" value="<?php echo esc_attr($key); ?>" placeholder="auto" readonly></td>
                                        <td><input class="vms-ops-preset-label" type="text" name="presets[<?php echo (int) $i; ?>][label]" value="<?php echo esc_attr($label); ?>" placeholder="Alert Staff"></td>
                                        <td>
                                            <select name="presets[<?php echo (int) $i; ?>][audience]">
                                                <?php foreach ($audience_choices as $aud_key => $aud_label) : ?>
                                                    <option value="<?php echo esc_attr($aud_key); ?>"<?php selected($audience, $aud_key); ?>><?php echo esc_html($aud_label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <select name="presets[<?php echo (int) $i; ?>][urgency]">
                                                <option value="normal"<?php selected($urgency, 'normal'); ?>><?php esc_html_e('Normal', 'vms-ops-console-premium'); ?></option>
                                                <option value="high"<?php selected($urgency, 'high'); ?>><?php esc_html_e('High', 'vms-ops-console-premium'); ?></option>
                                                <option value="critical"<?php selected($urgency, 'critical'); ?>><?php esc_html_e('Critical', 'vms-ops-console-premium'); ?></option>
                                            </select>
                                        </td>
                                        <td><input type="text" name="presets[<?php echo (int) $i; ?>][message]" value="<?php echo esc_attr($message); ?>" placeholder="Staff assist needed at console."></td>
                                    </tr>
                                <?php endfor; ?>
                                </tbody>
                            </table>

                            <details class="vms-ops-admin-advanced">
                                <summary><?php esc_html_e('Advanced: raw editor', 'vms-ops-console-premium'); ?></summary>
                                <textarea id="vms_ops_preset_lines" rows="10" cols="80" readonly><?php echo esc_textarea(vms_ops_admin_presets_to_text($presets)); ?></textarea>
                                <p class="description"><?php esc_html_e('Read-only snapshot in pipe format (kept for debugging).', 'vms-ops-console-premium'); ?></p>
                            </details>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Save Presets', 'vms-ops-console-premium')); ?>
            </form>
        </div>
        <?php
    }
}

if (!function_exists('vms_ops_admin_handle_save_alert_presets')) {
    function vms_ops_admin_handle_save_alert_presets(): void
    {
        if (!vms_ops_admin_current_user_can_manage()) {
            wp_die(esc_html__('Access denied.', 'vms-ops-console-premium'));
        }

        check_admin_referer('vms_ops_save_alert_presets');

        $venue_id = isset($_POST['venue_id']) ? absint((string) $_POST['venue_id']) : 0;
        $console_type = isset($_POST['console_type']) ? sanitize_key((string) $_POST['console_type']) : 'ops';
        if ($console_type === '') {
            $console_type = 'ops';
        }

        $presets = array();
        if (isset($_POST['presets']) && is_array($_POST['presets'])) {
            $raw = (array) wp_unslash($_POST['presets']);
            // Reuse the core sanitizer so the saved shape is canonical.
            $presets = vms_ops_alert_sanitize_presets($raw);
        } else {
            $preset_lines = isset($_POST['preset_lines']) ? (string) wp_unslash((string) $_POST['preset_lines']) : '';
            $presets = vms_ops_admin_parse_preset_lines($preset_lines);
            $presets = vms_ops_alert_sanitize_presets($presets);
        }

        $saved = vms_ops_alert_presets_save($venue_id, $console_type, $presets);
        if (is_wp_error($saved)) {
            wp_die(esc_html($saved->get_error_message()));
        }

        $target = add_query_arg(array(
            'page' => 'vms-ops-console-presets',
            'venue_id' => $venue_id,
            'console_type' => $console_type,
            'updated' => 1,
        ), admin_url('admin.php'));

        wp_safe_redirect($target);
        exit;
    }
}
add_action('admin_post_vms_ops_save_alert_presets', 'vms_ops_admin_handle_save_alert_presets');
