<?php
/**
 * Plugin Name: VMS Ops Console Premium
 * Description: Installable PWA ops console and Texas Private Club membership toolkit for VMS operators.
 * Version: 0.1.67
 * Author: VMS
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: vms-ops-console-premium
 */
 
defined('ABSPATH') || exit;

if (!defined('VMS_OPS_CONSOLE_VERSION')) {
    define('VMS_OPS_CONSOLE_VERSION', '0.1.67');
}
if (!defined('VMS_OPS_CONSOLE_FILE')) {
    define('VMS_OPS_CONSOLE_FILE', __FILE__);
}
if (!defined('VMS_OPS_CONSOLE_PATH')) {
    define('VMS_OPS_CONSOLE_PATH', plugin_dir_path(__FILE__));
}
if (!defined('VMS_OPS_CONSOLE_URL')) {
    define('VMS_OPS_CONSOLE_URL', plugin_dir_url(__FILE__));
}

require_once VMS_OPS_CONSOLE_PATH . 'includes/core-compat.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/db-schema.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/capabilities.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/encryption.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/venues.php';

require_once VMS_OPS_CONSOLE_PATH . 'includes/private-club/audit.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/private-club/members.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/private-club/renewals.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/private-club/status.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/private-club/visits.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/private-club/member-lookup.php';

require_once VMS_OPS_CONSOLE_PATH . 'includes/alerts/presets.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/alerts/routing.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/alerts/alerts-core.php';

require_once VMS_OPS_CONSOLE_PATH . 'includes/presence/heartbeat.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/presence/presence-core.php';

require_once VMS_OPS_CONSOLE_PATH . 'includes/ticket-console/eligibility.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/ticket-console/events.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/ticket-console/checkin.php';

require_once VMS_OPS_CONSOLE_PATH . 'admin/settings.php';
require_once VMS_OPS_CONSOLE_PATH . 'admin/teams.php';
require_once VMS_OPS_CONSOLE_PATH . 'admin/members.php';
require_once VMS_OPS_CONSOLE_PATH . 'includes/setup-status.php';
require_once VMS_OPS_CONSOLE_PATH . 'admin/presets.php';
require_once VMS_OPS_CONSOLE_PATH . 'admin/id-scans.php';

require_once VMS_OPS_CONSOLE_PATH . 'includes/rest/routes.php';

if (!function_exists('vms_ops_admin_enqueue_assets')) {
    function vms_ops_admin_enqueue_assets(string $hook_suffix): void
    {
        if (!is_admin()) {
            return;
        }

        $page = isset($_GET['page']) ? sanitize_key((string) $_GET['page']) : '';
        $allowed = array(
            'vms-teams',
            'vms-alert-presets',
        );
        $allowed_hooks = array(
            'users.php',
            'user-edit.php',
        );
        $is_ops_family = ($page !== '') && (strpos($page, 'vms-ops-console') === 0);
        $is_allowed_page = $page !== '' && in_array($page, $allowed, true);
        $is_allowed_hook = in_array($hook_suffix, $allowed_hooks, true);
        if (!$is_ops_family && !$is_allowed_page && !$is_allowed_hook) {
            return;
        }


        wp_enqueue_style(
            'vms-ops-console-admin',
            VMS_OPS_CONSOLE_URL . 'admin/assets/admin.css',
            array(),
            VMS_OPS_CONSOLE_VERSION
        );

        wp_enqueue_script(
            'vms-ops-console-admin',
            VMS_OPS_CONSOLE_URL . 'admin/assets/admin.js',
            array(),
            VMS_OPS_CONSOLE_VERSION,
            true
        );
    }
}
add_action('admin_enqueue_scripts', 'vms_ops_admin_enqueue_assets');

if (!function_exists('vms_ops_default_settings')) {
    function vms_ops_default_settings(): array
    {
        return array(
            'presence_timeout_seconds' => 180,
            'post_show_scan_buffer_hours' => 4,
            'ticket_reopen_past_events_enabled' => 0,
            'ticket_reopen_past_events_days' => 3,
            'default_birthday_window_days' => 7,
            'anniversary_lock_days' => 30,
            'banned_clear_hold_seconds' => 3,
            'default_venue_id' => 0,
            'member_lookup_enabled' => 1,
            'member_lookup_dob_policy' => 'no_photo',
            'member_lookup_require_dob_entry' => 0,
            'member_lookup_require_confidence' => 1,
            'member_lookup_freshness_days' => 365,
            'member_lookup_allow_profile_photo' => 1,
            'member_lookup_profile_photo_upload_mode' => 'enabled',
            'member_lookup_dob_display' => 'full',
            'member_lookup_require_photo_recheck' => 1,
            'member_lookup_audit_logging' => 1,
        );
    }
}

if (!function_exists('vms_ops_alert_staff_feature_enabled')) {
    function vms_ops_alert_staff_feature_enabled(): bool
    {
        $enabled = defined('VMS_OPS_ALERT_STAFF_ENABLED') ? (bool) VMS_OPS_ALERT_STAFF_ENABLED : false;
        return (bool) apply_filters('vms_ops_alert_staff_enabled', $enabled);
    }
}
  
if (!function_exists('vms_ops_seed_default_options')) {
    function vms_ops_seed_default_options(): void
    {
        $settings = get_option('vms_ops_settings', null);
        if (!is_array($settings)) {
            add_option('vms_ops_settings', vms_ops_default_settings(), '', false);
        }

        $venue_settings = get_option('vms_ops_venue_settings', null);
        if (!is_array($venue_settings)) {
            add_option('vms_ops_venue_settings', array(), '', false);
        }

        $presets = get_option('vms_ops_alert_presets', null);
        if (!is_array($presets)) {
            add_option('vms_ops_alert_presets', array(), '', false);
        }
    }
}

if (!function_exists('vms_ops_rewrite_environment_ready')) {
    function vms_ops_rewrite_environment_ready(): bool
    {
        global $wp_rewrite;
        return function_exists('add_rewrite_rule') && is_object($wp_rewrite) && method_exists($wp_rewrite, 'add_rule');
    }
}

if (!function_exists('vms_ops_register_rewrite_rules')) {
    function vms_ops_register_rewrite_rules(): bool
    {
        if (!vms_ops_rewrite_environment_ready()) {
            return false;
        }

        add_rewrite_rule('^vms-console/?$', 'index.php?vms_ops_legacy_console=1', 'top');
        add_rewrite_rule('^vms-ops/?$', 'index.php?vms_ops_pwa=1', 'top');
        add_rewrite_rule('^vms-ops/sw\\.js$', 'index.php?vms_ops_sw=1', 'top');
        add_rewrite_rule('^vms-ops/manifest\\.json$', 'index.php?vms_ops_manifest=1', 'top');
        add_rewrite_rule('^vms-ops/icon-(192|512)\\.png$', 'index.php?vms_ops_icon=$matches[1]', 'top');
        return true;
    }
}

if (!function_exists('vms_ops_schedule_rewrite_flush')) {
    function vms_ops_schedule_rewrite_flush(): void
    {
        update_option('vms_ops_rewrite_flush_pending', 1, false);
    }
}

if (!function_exists('vms_ops_maybe_flush_rewrite_rules')) {
    function vms_ops_maybe_flush_rewrite_rules(): void
    {
        if ((int) get_option('vms_ops_rewrite_flush_pending', 0) !== 1) {
            return;
        }

        if (!vms_ops_register_rewrite_rules()) {
            return;
        }

        flush_rewrite_rules(false);
        delete_option('vms_ops_rewrite_flush_pending');
    }
}
add_action('init', 'vms_ops_maybe_flush_rewrite_rules', 20);

if (!function_exists('vms_ops_plugin_activate')) {
    function vms_ops_plugin_activate(): void
    {
        vms_ops_register_capabilities();

        $schema_result = vms_ops_install_schema();
        if (is_wp_error($schema_result)) {
            deactivate_plugins(plugin_basename(VMS_OPS_CONSOLE_FILE));
            wp_die(esc_html($schema_result->get_error_message()));
        }

        vms_ops_seed_default_options();
        vms_ops_schedule_rewrite_flush();
        vms_ops_register_rewrite_rules();
        vms_ops_presence_schedule_event();
        vms_ops_maybe_flush_rewrite_rules();
    }
}
register_activation_hook(VMS_OPS_CONSOLE_FILE, 'vms_ops_plugin_activate');

if (!function_exists('vms_ops_plugin_deactivate')) {
    function vms_ops_plugin_deactivate(): void
    {
        delete_option('vms_ops_rewrite_flush_pending');
        vms_ops_presence_clear_scheduled_event();
        if (vms_ops_rewrite_environment_ready()) {
            flush_rewrite_rules(false);
        }
    }
}
register_deactivation_hook(VMS_OPS_CONSOLE_FILE, 'vms_ops_plugin_deactivate');

if (!function_exists('vms_ops_load_textdomain')) {
    function vms_ops_load_textdomain(): void
    {
        load_plugin_textdomain('vms-ops-console-premium', false, dirname(plugin_basename(VMS_OPS_CONSOLE_FILE)) . '/languages');
    }
}
add_action('init', 'vms_ops_load_textdomain', 1);

if (!function_exists('vms_ops_query_vars')) {
    function vms_ops_query_vars(array $vars): array
    {
        $vars[] = 'vms_ops_legacy_console';
        $vars[] = 'vms_ops_pwa';
        $vars[] = 'vms_ops_sw';
        $vars[] = 'vms_ops_manifest';
        $vars[] = 'vms_ops_icon';
        return $vars;
    }
}
add_filter('query_vars', 'vms_ops_query_vars');

if (!function_exists('vms_ops_normalize_route_path')) {
    function vms_ops_normalize_route_path(string $path): string
    {
        $normalized = '/' . ltrim($path, '/');
        $normalized = preg_replace('#/+#', '/', $normalized);
        if ($normalized === null || $normalized === '') {
            return '/';
        }

        return $normalized === '/' ? '/' : rtrim($normalized, '/');
    }
}

if (!function_exists('vms_ops_is_legacy_console_request')) {
    function vms_ops_is_legacy_console_request(): bool
    {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';
        $request_path = (string) wp_parse_url($request_uri, PHP_URL_PATH);
        if ($request_path === '') {
            return false;
        }

        $legacy_path = (string) wp_parse_url(home_url('/vms-console/'), PHP_URL_PATH);
        return vms_ops_normalize_route_path($request_path) === vms_ops_normalize_route_path($legacy_path);
    }
}

if (!function_exists('vms_ops_legacy_console_redirect_url')) {
    function vms_ops_legacy_console_redirect_url(): string
    {
        $target = (string) home_url('/vms-ops/');
        $query_string = isset($_SERVER['QUERY_STRING']) ? trim((string) wp_unslash($_SERVER['QUERY_STRING'])) : '';
        if ($query_string === '') {
            return $target;
        }

        return $target . (strpos($target, '?') === false ? '?' : '&') . $query_string;
    }
}

if (!function_exists('vms_ops_redirect_legacy_console')) {
    function vms_ops_redirect_legacy_console(): void
    {
        wp_safe_redirect(vms_ops_legacy_console_redirect_url(), 302, 'VMS Ops Console');
        exit;
    }
}

if (!function_exists('vms_ops_manifest_icon_url')) {
    function vms_ops_manifest_icon_url(int $size): string
    {
        $safe = $size >= 512 ? 512 : 192;
        return (string) home_url('/vms-ops/icon-' . $safe . '.png');
    }
}

if (!function_exists('vms_ops_wp_timezone_offset_minutes')) {
    function vms_ops_wp_timezone_offset_minutes(): int
    {
        $tz = wp_timezone();
        $utc_now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        return (int) round($tz->getOffset($utc_now) / 60);
    }
}

if (!function_exists('vms_ops_wp_timezone_label')) {
    function vms_ops_wp_timezone_label(): string
    {
        $timezone_string = trim((string) wp_timezone_string());
        if ($timezone_string !== '') {
            return $timezone_string;
        }

        $tz = wp_timezone();
        if ($tz instanceof DateTimeZone) {
            $name = trim((string) $tz->getName());
            if ($name !== '') {
                return $name;
            }
        }

        $offset_minutes = vms_ops_wp_timezone_offset_minutes();
        $sign = $offset_minutes >= 0 ? '+' : '-';
        $abs = abs($offset_minutes);

        return sprintf('UTC%s%02d:%02d', $sign, (int) floor($abs / 60), $abs % 60);
    }
}

if (!function_exists('vms_ops_time_sync_payload')) {
    function vms_ops_time_sync_payload(): array
    {
        $timezone_string = trim((string) wp_timezone_string());

        return array(
            'server_epoch_ms' => (int) vms_ops_now_timestamp() * 1000,
            'server_time_mysql' => vms_ops_now_mysql(),
            'timezone_string' => $timezone_string,
            'timezone_label' => vms_ops_wp_timezone_label(),
            'timezone_offset_minutes' => vms_ops_wp_timezone_offset_minutes(),
            'date_format' => (string) get_option('date_format'),
            'time_format' => (string) get_option('time_format'),
        );
    }
}

if (!function_exists('vms_ops_render_manifest')) {
    function vms_ops_render_manifest(): void
    {
        nocache_headers();
        header('Content-Type: application/manifest+json; charset=utf-8');

        $manifest_path = VMS_OPS_CONSOLE_PATH . 'pwa/manifest.json';
        $manifest = file_exists($manifest_path) ? (string) file_get_contents($manifest_path) : '{}';

        $replacements = array(
            '__START_URL__' => esc_url_raw(home_url('/vms-ops/')),
            '__SCOPE__' => esc_url_raw(home_url('/vms-ops/')),
            '__VERSION__' => VMS_OPS_CONSOLE_VERSION,
            '__ICON_192__' => esc_url_raw(vms_ops_manifest_icon_url(192)),
            '__ICON_512__' => esc_url_raw(vms_ops_manifest_icon_url(512)),
        );

        echo strtr($manifest, $replacements);
        exit;
    }
}

if (!function_exists('vms_ops_render_icon')) {
    function vms_ops_render_icon(int $size): void
    {
        $target_size = $size >= 512 ? 512 : 192;

        nocache_headers();
        header('Content-Type: image/png');
        header('Cache-Control: public, max-age=3600');

        $site_icon_id = (int) get_option('site_icon');
        $source_path = $site_icon_id > 0 ? (string) get_attached_file($site_icon_id) : '';

        if ($source_path !== '' && file_exists($source_path) && function_exists('wp_get_image_editor')) {
            $editor = wp_get_image_editor($source_path);
            if (!is_wp_error($editor)) {
                $resized = $editor->resize($target_size, $target_size, true);
                if (!is_wp_error($resized)) {
                    $streamed = $editor->stream('image/png');
                    if (!is_wp_error($streamed)) {
                        exit;
                    }
                }
            }
        }

        if (
            function_exists('imagecreatetruecolor')
            && function_exists('imagecreatefromstring')
            && function_exists('imagecopyresampled')
            && function_exists('imagepng')
        ) {
            $canvas = imagecreatetruecolor($target_size, $target_size);
            if ($canvas !== false) {
                imagealphablending($canvas, false);
                imagesavealpha($canvas, true);
                $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
                imagefilledrectangle($canvas, 0, 0, $target_size, $target_size, $transparent);

                $source_image = false;
                if ($source_path !== '' && file_exists($source_path)) {
                    $binary = @file_get_contents($source_path);
                    if (is_string($binary) && $binary !== '') {
                        $source_image = @imagecreatefromstring($binary);
                    }
                }

                if ($source_image !== false) {
                    $source_w = imagesx($source_image);
                    $source_h = imagesy($source_image);

                    if ($source_w > 0 && $source_h > 0) {
                        imagecopyresampled(
                            $canvas,
                            $source_image,
                            0,
                            0,
                            0,
                            0,
                            $target_size,
                            $target_size,
                            $source_w,
                            $source_h
                        );
                    }

                    imagedestroy($source_image);
                } else {
                    $bg = imagecolorallocate($canvas, 16, 24, 32);
                    $fg = imagecolorallocate($canvas, 247, 251, 255);
                    imagefilledrectangle($canvas, 0, 0, $target_size, $target_size, $bg);

                    $label = 'VMS';
                    $font = 5;
                    $text_w = imagefontwidth($font) * strlen($label);
                    $text_h = imagefontheight($font);
                    $text_x = (int) floor(($target_size - $text_w) / 2);
                    $text_y = (int) floor(($target_size - $text_h) / 2);
                    imagestring($canvas, $font, max(0, $text_x), max(0, $text_y), $label, $fg);
                }

                imagepng($canvas);
                imagedestroy($canvas);
                exit;
            }
        }

        $fallback_url = get_site_icon_url($target_size);
        if (is_string($fallback_url) && $fallback_url !== '') {
            wp_safe_redirect($fallback_url, 302);
            exit;
        }

        status_header(404);
        exit;
    }
}

if (!function_exists('vms_ops_render_sw')) {
    function vms_ops_render_sw(): void
    {
        nocache_headers();
        header('Content-Type: application/javascript; charset=utf-8');

        $sw_path = VMS_OPS_CONSOLE_PATH . 'pwa/sw.js';
        $source = file_exists($sw_path) ? (string) file_get_contents($sw_path) : '';

        $replacements = array(
            '__VERSION__' => VMS_OPS_CONSOLE_VERSION,
            '__SHELL_URL__' => esc_url_raw(home_url('/vms-ops/')),
            '__MEMBER_LOOKUP_ACCESS_JS__' => esc_url_raw(VMS_OPS_CONSOLE_URL . 'pwa/assets/js/member-lookup-access.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)),
            '__MEMBER_LOOKUP_DOB_JS__' => esc_url_raw(VMS_OPS_CONSOLE_URL . 'pwa/assets/js/member-lookup-dob.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)),
            '__MEMBER_PHOTO_CAPTURE_JS__' => esc_url_raw(VMS_OPS_CONSOLE_URL . 'pwa/assets/js/member-photo-capture.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)),
            '__APP_JS__' => esc_url_raw(VMS_OPS_CONSOLE_URL . 'pwa/assets/js/app.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)),
            '__APP_CSS__' => esc_url_raw(VMS_OPS_CONSOLE_URL . 'pwa/assets/css/app.css?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)),
            '__ZXING_LIBRARY_JS__' => esc_url_raw(VMS_OPS_CONSOLE_URL . 'pwa/assets/vendor/zxing-library.min.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)),
            '__ZXING_BROWSER_JS__' => esc_url_raw(VMS_OPS_CONSOLE_URL . 'pwa/assets/vendor/zxing-browser.min.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)),
        );

        echo strtr($source, $replacements);
        exit;
    }
}

if (!function_exists('vms_ops_render_pwa_shell')) {
    function vms_ops_render_pwa_shell(): void
    {
        if (!is_user_logged_in()) {
            auth_redirect();
        }

        $entry_caps = function_exists('vms_ops_all_capabilities') ? vms_ops_all_capabilities() : array(vms_ops_capability_use_pwa());
        $has_any_ops_cap = function_exists('vms_ops_user_has_any_capability') ? vms_ops_user_has_any_capability($entry_caps) : current_user_can(vms_ops_capability_use_pwa());
        $has_manage_options = current_user_can('manage_options');
        $can_access_shell = $has_manage_options || $has_any_ops_cap;

        if (!$can_access_shell) {
            status_header(403);
            nocache_headers();
            echo '<!doctype html><html><body><h1>' . esc_html__('Access denied.', 'vms-ops-console-premium') . '</h1></body></html>';
            exit;
        }

        $settings = function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : vms_ops_default_settings();
        $user = wp_get_current_user();
        $rest_root = rest_url('vms-ops/v1');
        $device_seed = get_current_user_id() . '|' . wp_get_session_token() . '|' . home_url();
        $time_sync = vms_ops_time_sync_payload();
        $return_url = home_url('/vms-ops/');
        $wp_logged_in = is_user_logged_in();
        $wp_auth_label = $wp_logged_in
            ? sprintf(
                /* translators: %s: display name */
                __('WP: %s', 'vms-ops-console-premium'),
                $user instanceof WP_User ? $user->display_name : __('User', 'vms-ops-console-premium')
            )
            : __('WP: Not logged in', 'vms-ops-console-premium');
        $wp_auth_action = $wp_logged_in ? __('Logout', 'vms-ops-console-premium') : __('Login', 'vms-ops-console-premium');
        $wp_auth_url = $wp_logged_in ? wp_logout_url($return_url) : wp_login_url($return_url);
        $user_role_label = '';
        if ($user instanceof WP_User && !empty($user->roles) && function_exists('wp_roles')) {
            $roles = wp_roles();
            if ($roles instanceof WP_Roles) {
                $role_labels = array();
                foreach ((array) $user->roles as $role_key) {
                    $role_key = sanitize_key((string) $role_key);
                    if ($role_key === '') {
                        continue;
                    }

                    $role_name = isset($roles->roles[$role_key]['name']) ? (string) $roles->roles[$role_key]['name'] : $role_key;
                    $role_labels[] = translate_user_role($role_name);
                }

                $role_labels = array_values(array_filter(array_unique(array_map('strval', $role_labels))));
                if (!empty($role_labels)) {
                    $user_role_label = implode(', ', $role_labels);
                }
            }
        }

        $fallback_venue = function_exists('vms_ops_get_fallback_venue') ? vms_ops_get_fallback_venue() : null;
        $preferred_venue = function_exists('vms_ops_get_preferred_venue') ? vms_ops_get_preferred_venue() : null;
        $resolved_default_venue_id = isset($settings['default_venue_id']) ? (int) $settings['default_venue_id'] : 0;
        if ($resolved_default_venue_id <= 0 && is_array($preferred_venue)) {
            $resolved_default_venue_id = (int) ($preferred_venue['id'] ?? 0);
        }
        if ($resolved_default_venue_id <= 0 && is_array($fallback_venue)) {
            $resolved_default_venue_id = (int) ($fallback_venue['id'] ?? 0);
        }

        $raw_caps = array(
            'manageOptions' => $has_manage_options ? 1 : 0,
            'usePwa' => current_user_can(vms_ops_capability_use_pwa()) ? 1 : 0,
            'scanTickets' => current_user_can(vms_ops_capability_scan_tickets()) ? 1 : 0,
            'scanIds' => current_user_can(vms_ops_capability_scan_ids()) ? 1 : 0,
            'memberLookup' => current_user_can(vms_ops_capability_member_lookup()) ? 1 : 0,
            'manageLite' => current_user_can(vms_ops_capability_manage_members_lite()) ? 1 : 0,
            'manageAdmin' => current_user_can(vms_ops_capability_manage_members_admin()) ? 1 : 0,
            'sendAlerts' => current_user_can(vms_ops_capability_send_alerts()) ? 1 : 0,
            'receiveAlerts' => current_user_can(vms_ops_capability_receive_alerts()) ? 1 : 0,
            'presenceCheckin' => current_user_can(vms_ops_capability_presence_checkin()) ? 1 : 0,
        );

        $effective_caps = $raw_caps;
        $effective_caps['usePwa'] = $can_access_shell ? 1 : 0;
        foreach (array('scanTickets', 'scanIds', 'memberLookup', 'manageLite', 'manageAdmin', 'sendAlerts', 'receiveAlerts') as $cap_key) {
            $effective_caps[$cap_key] = ($has_manage_options || !empty($raw_caps[$cap_key])) ? 1 : 0;
        }

        $config = array(
            'appVersion' => VMS_OPS_CONSOLE_VERSION,
            'restRoot' => esc_url_raw($rest_root),
            'nonce' => wp_create_nonce('wp_rest'),
            'permissionPayloadVersion' => 2,
            'wpAuthLabel' => $wp_auth_label,
            'user' => array(
                'id' => get_current_user_id(),
                'name' => $user instanceof WP_User ? $user->display_name : '',
                'roleLabel' => $user_role_label,
            ),
            'caps' => $effective_caps,
            'permissionPayload' => $raw_caps,
            'features' => array(
                'alertStaffEnabled' => vms_ops_alert_staff_feature_enabled() ? 1 : 0,
            ),
            'settings' => $settings,
            'debugMode' => (!empty($_GET['vms_ops_debug']) && $can_access_shell) ? 1 : 0,
            'defaultVenueId' => $resolved_default_venue_id,
            'defaultVenueName' => is_array($preferred_venue)
                ? (string) ($preferred_venue['name'] ?? '')
                : (is_array($fallback_venue) ? (string) ($fallback_venue['name'] ?? '') : ''),
            'serverEpochMs' => (int) ($time_sync['server_epoch_ms'] ?? 0),
            'serverTimezone' => (string) ($time_sync['timezone_string'] ?? ''),
            'serverTimezoneLabel' => (string) ($time_sync['timezone_label'] ?? ''),
            'serverTimezoneOffsetMinutes' => (int) ($time_sync['timezone_offset_minutes'] ?? 0),
            'serverDateFormat' => (string) ($time_sync['date_format'] ?? ''),
            'serverTimeFormat' => (string) ($time_sync['time_format'] ?? ''),
            'serverNowMysql' => (string) ($time_sync['server_time_mysql'] ?? ''),
            'deviceId' => substr(hash('sha256', $device_seed), 0, 32),
            'manifestUrl' => home_url('/vms-ops/manifest.json'),
            'swUrl' => home_url('/vms-ops/sw.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)),
            'shellUrl' => home_url('/vms-ops/'),
            'assets' => array(
                'memberLookupAccess' => VMS_OPS_CONSOLE_URL . 'pwa/assets/js/member-lookup-access.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION),
                'memberLookupDob' => VMS_OPS_CONSOLE_URL . 'pwa/assets/js/member-lookup-dob.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION),
                'memberPhotoCapture' => VMS_OPS_CONSOLE_URL . 'pwa/assets/js/member-photo-capture.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION),
                'css' => VMS_OPS_CONSOLE_URL . 'pwa/assets/css/app.css?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION),
                'js' => VMS_OPS_CONSOLE_URL . 'pwa/assets/js/app.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION),
                'zxingLibrary' => VMS_OPS_CONSOLE_URL . 'pwa/assets/vendor/zxing-library.min.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION),
                'zxingBrowser' => VMS_OPS_CONSOLE_URL . 'pwa/assets/vendor/zxing-browser.min.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION),
            ),
        );

        $header_time_format = trim((string) ($time_sync['time_format'] ?? ''));
        if ($header_time_format === '') {
            $header_time_format = 'g:i A';
        }
        $header_now = vms_ops_now_timestamp();
        $header_date_line = wp_date('D, M j', $header_now, wp_timezone()) . ' • ' . (string) ($time_sync['timezone_label'] ?? __('Site Time', 'vms-ops-console-premium'));
        $header_time_line = wp_date($header_time_format, $header_now, wp_timezone());
        $alert_staff_enabled = vms_ops_alert_staff_feature_enabled();

        nocache_headers();
        ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#101820">
    <title><?php echo esc_html__('VMS Ops Console', 'vms-ops-console-premium'); ?></title>
    <link rel="manifest" href="<?php echo esc_url(home_url('/vms-ops/manifest.json')); ?>">
    <link rel="apple-touch-icon" href="<?php echo esc_url(vms_ops_manifest_icon_url(192)); ?>">
    <link rel="stylesheet" href="<?php echo esc_url(VMS_OPS_CONSOLE_URL . 'pwa/assets/css/app.css?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)); ?>">
</head>
<body class="vms-ops-body<?php echo !empty($config['caps']['presenceCheckin']) ? ' vms-ops-login-required' : ''; ?>">
    <div id="vms-ops-app" class="vms-ops-app is-venues-loading" data-mode="mobile">
        <header class="vms-ops-header">
            <div>
                <h1><?php echo esc_html__('VMS Ops Console', 'vms-ops-console-premium'); ?></h1>
            </div>
            <div class="vms-ops-header-meta">
                <div id="vms-ops-site-time" class="vms-ops-site-time" aria-live="polite">
                    <span id="vms-ops-site-time-value" class="vms-ops-site-time-value"><?php echo esc_html($header_time_line); ?></span>
                    <span id="vms-ops-site-time-meta" class="vms-ops-site-time-meta"><?php echo esc_html($header_date_line); ?></span>
                </div>
                <label for="vms-ops-venue-select"><?php echo esc_html__('Venue', 'vms-ops-console-premium'); ?></label>
                <select id="vms-ops-venue-select">
                    <option value=""><?php echo esc_html__('Select venue', 'vms-ops-console-premium'); ?></option>
                </select>
                <button id="vms-ops-open-presence" class="vms-ops-header-toggle vms-ops-presence-toggle" type="button" disabled<?php echo !empty($config['caps']['presenceCheckin']) ? '' : ' hidden'; ?>><?php echo esc_html__('Connecting…', 'vms-ops-console-premium'); ?></button>
                <div class="vms-ops-wp-auth-chip">
                    <span><?php echo esc_html($wp_auth_label); ?></span>
                    <a href="<?php echo esc_url($wp_auth_url); ?>"><?php echo esc_html($wp_auth_action); ?></a>
                </div>
            </div>
        </header>

        <section class="vms-ops-panel vms-ops-panel-collapsible" id="vms-ops-ticket-panel"<?php echo !empty($config['caps']['scanTickets']) ? '' : ' hidden'; ?>>
            <h2 id="vms-ops-ticket-heading" class="vms-ops-collapsible-heading" role="button" tabindex="0" aria-expanded="true"><?php echo esc_html__('Ticket Console', 'vms-ops-console-premium'); ?></h2>
            <div id="vms-ops-ticket-body" class="vms-ops-panel-body">
            <div class="vms-ops-row vms-ops-ticket-controls">
                <label for="vms-ops-ticket-event"><?php echo esc_html__('Event', 'vms-ops-console-premium'); ?></label>
                <select id="vms-ops-ticket-event">
                    <option value=""><?php echo esc_html__('Select an event', 'vms-ops-console-premium'); ?></option>
                </select>
                <button id="vms-ops-refresh-events" type="button"><?php echo esc_html__('Refresh Events', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-load-attendees" type="button"><?php echo esc_html__('Cache Attendees', 'vms-ops-console-premium'); ?></button>
            </div>
            <div id="vms-ops-active-event-card" class="vms-ops-active-event-card" hidden>
                <div class="vms-ops-active-event-main">
                    <span class="vms-ops-active-event-label"><?php echo esc_html__('Active event', 'vms-ops-console-premium'); ?></span>
                    <strong id="vms-ops-active-event-name"><?php echo esc_html__('No event selected', 'vms-ops-console-premium'); ?></strong>
                    <span id="vms-ops-active-event-meta" class="vms-ops-active-event-meta"></span>
                </div>
                <div class="vms-ops-active-event-side">
                    <span id="vms-ops-active-event-status" class="vms-ops-active-event-status" aria-live="polite"><?php echo esc_html__('Needs confirmation', 'vms-ops-console-premium'); ?></span>
                    <button id="vms-ops-confirm-event" type="button"><?php echo esc_html__('Confirm & Start Scanning', 'vms-ops-console-premium'); ?></button>
                    <button id="vms-ops-change-event" type="button" class="vms-ops-secondary"><?php echo esc_html__('Change Event', 'vms-ops-console-premium'); ?></button>
                </div>
            </div>
            <div class="vms-ops-row">
                <input id="vms-ops-ticket-scan" type="text" autocomplete="off" placeholder="<?php echo esc_attr__('Scan or enter ticket code', 'vms-ops-console-premium'); ?>">
                <button id="vms-ops-ticket-scan-camera" type="button" class="vms-ops-secondary"><?php echo esc_html__('Scan Ticket', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-ticket-submit" type="button"><?php echo esc_html__('Check In', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-ticket-submit-all" type="button" class="vms-ops-secondary" hidden><?php echo esc_html__('Check In All Remaining', 'vms-ops-console-premium'); ?></button>
            </div>
            <p id="vms-ops-ticket-notice" class="vms-ops-feedback vms-ops-ticket-notice" aria-live="polite"></p>
            <p id="vms-ops-ticket-scan-hint" class="vms-ops-mini vms-ops-ticket-scan-hint"></p>
            <div class="vms-ops-attendee-lookup">
                <h3 class="vms-ops-attendee-heading"><?php echo esc_html__("Attendee Lookup", "vms-ops-console-premium"); ?></h3>
                <div class="vms-ops-row">
                    <input id="vms-ops-attendee-search" type="text" autocomplete="off" placeholder="<?php echo esc_attr__("Search attendees by name, email, or phone", "vms-ops-console-premium"); ?>">
                    <button id="vms-ops-attendee-clear" type="button" class="vms-ops-secondary"><?php echo esc_html__("Clear", "vms-ops-console-premium"); ?></button>
                </div>
                <div id="vms-ops-attendee-results" class="vms-ops-result"></div>
            </div>

            <p id="vms-ops-ticket-feedback" class="vms-ops-feedback" aria-live="polite"></p>
            <div class="vms-ops-ticket-meta-footer">
                <div id="vms-ops-ticket-cache-meta" class="vms-ops-mini"></div>
                <div id="vms-ops-ticket-cache-debug" class="vms-ops-ticket-cache-debug vms-ops-mini" hidden></div>
                <p id="vms-ops-attendee-meta" class="vms-ops-mini"></p>
            </div>
            </div>
        </section>

        <section class="vms-ops-panel vms-ops-panel-collapsible" id="vms-ops-id-panel"<?php echo (!empty($config['caps']['scanIds']) || !empty($config['caps']['manageLite']) || !empty($config['caps']['manageAdmin'])) ? '' : ' hidden'; ?>>
            <h2 id="vms-ops-id-heading" class="vms-ops-collapsible-heading" role="button" tabindex="0" aria-expanded="true"><?php echo esc_html__('ID Console', 'vms-ops-console-premium'); ?></h2>
            <div id="vms-ops-id-body" class="vms-ops-panel-body">
            <p id="vms-ops-id-age-cutoff-note" class="vms-ops-age-cutoff-note" aria-live="polite" hidden></p>
            <div class="vms-ops-row vms-ops-id-actions">
                <button id="vms-ops-id-scan-camera" type="button" class="vms-ops-secondary"><?php echo esc_html__('Scan ID', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-id-process" type="button" hidden><?php echo esc_html__('Process ID', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-id-retry-log" type="button" class="vms-ops-secondary" hidden><?php echo esc_html__('Retry Log', 'vms-ops-console-premium'); ?></button>
            </div>
            <div id="vms-ops-id-recheck-context" class="vms-ops-id-recheck-context" hidden></div>
            <details id="vms-ops-id-advanced" class="vms-ops-id-advanced"<?php echo !empty($config['debugMode']) ? '' : ' hidden'; ?>>
                <summary><?php echo esc_html__('Details / Testing', 'vms-ops-console-premium'); ?></summary>
                <textarea id="vms-ops-id-payload" rows="4" placeholder="<?php echo esc_attr__('Paste PDF417 payload for scan simulation', 'vms-ops-console-premium'); ?>"></textarea>
                <pre id="vms-ops-id-debug-timing" class="vms-ops-id-debug-timing" hidden></pre>
            </details>
            <div id="vms-ops-id-age-warning" class="vms-ops-age-card" aria-live="polite" hidden></div>
            <div id="vms-ops-id-not-found" class="vms-ops-id-not-found" hidden>
                <h3><?php echo esc_html__('Member not found', 'vms-ops-console-premium'); ?></h3>
                <p id="vms-ops-id-not-found-summary" class="vms-ops-mini"></p>
                <p id="vms-ops-id-not-found-action" class="vms-ops-id-not-found-action" aria-live="polite"></p>
                <div class="vms-ops-row">
                    <button id="vms-ops-id-add-member" type="button"><?php echo esc_html__('Add Member', 'vms-ops-console-premium'); ?></button>
                    <button id="vms-ops-id-not-found-cancel" type="button" class="vms-ops-secondary"><?php echo esc_html__('Cancel', 'vms-ops-console-premium'); ?></button>
                </div>
            </div>
            <p id="vms-ops-id-feedback" class="vms-ops-feedback" aria-live="polite"></p>
            <div id="vms-ops-id-result" class="vms-ops-result"></div>
            <h3 id="vms-ops-manual-member-heading" class="vms-ops-collapsible-heading vms-ops-manual-heading" role="button" tabindex="0" aria-expanded="false"><?php echo esc_html__('Manual Member Creation', 'vms-ops-console-premium'); ?></h3>
            <form id="vms-ops-manual-member-form" class="vms-ops-manual-member" hidden>
                <div class="vms-ops-manual-member-number">
                    <input id="vms-ops-member-number" name="member_number" type="text" placeholder="<?php echo esc_attr__('Member Number', 'vms-ops-console-premium'); ?>" required>
                    <button id="vms-ops-generate-member-number" type="button" class="vms-ops-secondary"><?php echo esc_html__('Generate', 'vms-ops-console-premium'); ?></button>
                </div>
                <input name="first_name" type="text" placeholder="<?php echo esc_attr__('First Name', 'vms-ops-console-premium'); ?>" required>
                <input name="last_name" type="text" placeholder="<?php echo esc_attr__('Last Name', 'vms-ops-console-premium'); ?>" required>
                <input name="date_of_birth" type="date" required>
                <input name="phone_number" type="tel" inputmode="tel" autocomplete="tel" placeholder="<?php echo esc_attr__('Phone Number', 'vms-ops-console-premium'); ?>">
                <input name="email_address" type="email" inputmode="email" autocomplete="email" placeholder="<?php echo esc_attr__('Email Address', 'vms-ops-console-premium'); ?>">
                <input name="address_line_1" type="text" placeholder="<?php echo esc_attr__('Address Line 1', 'vms-ops-console-premium'); ?>">
                <input name="city" type="text" placeholder="<?php echo esc_attr__('City', 'vms-ops-console-premium'); ?>">
                <input name="state" type="text" placeholder="<?php echo esc_attr__('State', 'vms-ops-console-premium'); ?>">
                <input name="postal_code" type="text" placeholder="<?php echo esc_attr__('Postal Code', 'vms-ops-console-premium'); ?>">
                <textarea name="notes" rows="3" placeholder="<?php echo esc_attr__('Member notes', 'vms-ops-console-premium'); ?>"></textarea>
                <label class="vms-ops-inline-check"><input name="lookup_caution_flag" type="checkbox" value="1"> <span><?php echo esc_html__('Require ID recheck for this member', 'vms-ops-console-premium'); ?></span></label>
                <textarea name="lookup_caution_note" rows="2" placeholder="<?php echo esc_attr__('Reason for caution / recheck requirement', 'vms-ops-console-premium'); ?>"></textarea>
                <label class="vms-ops-inline-check"><input name="photo_consent" type="checkbox" value="1"> <span><?php echo esc_html__('Member consented to an optional profile photo for identity confirmation', 'vms-ops-console-premium'); ?></span></label>
                <label class="vms-ops-file-field">
                    <span><?php echo esc_html__('Optional profile photo', 'vms-ops-console-premium'); ?></span>
                    <input name="profile_photo" type="file" accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.heic,.heif" capture="environment" data-camera-preference="environment">
                </label>
                <div class="vms-ops-member-photo-camera-row">
                    <span class="vms-ops-mini" data-member-photo-camera-label><?php echo esc_html__('Default: Rear Camera', 'vms-ops-console-premium'); ?></span>
                    <button type="button" class="vms-ops-secondary" data-member-photo-switch><?php echo esc_html__('Switch Camera', 'vms-ops-console-premium'); ?></button>
                </div>
                <button type="submit"><?php echo esc_html__('Create Member', 'vms-ops-console-premium'); ?></button>
            </form>
            </div>
        </section>

        <section class="vms-ops-panel vms-ops-panel-collapsible" id="vms-ops-member-lookup-panel" hidden>
            <h2 id="vms-ops-member-lookup-heading" class="vms-ops-collapsible-heading" role="button" tabindex="0" aria-expanded="false"><?php echo esc_html__('Member Lookup', 'vms-ops-console-premium'); ?></h2>
            <div id="vms-ops-member-lookup-body" class="vms-ops-panel-body" hidden>
                <div class="vms-ops-member-lookup-head" data-tour-anchor="member-lookup-intro">
                    <div>
                        <p id="vms-ops-member-lookup-policy" class="vms-ops-mini" hidden></p>
                    </div>
                    <button id="vms-ops-member-lookup-tour" type="button" class="vms-ops-secondary"><?php echo esc_html__('Lookup Help', 'vms-ops-console-premium'); ?></button>
                </div>
                <div class="vms-ops-row" data-tour-anchor="member-lookup-search">
                    <input id="vms-ops-member-lookup-query" type="search" inputmode="search" autocomplete="off" placeholder="<?php echo esc_attr__('Search by name, phone, member number, email, or DOB', 'vms-ops-console-premium'); ?>">
                    <button id="vms-ops-member-lookup-search" type="button"><?php echo esc_html__('Search Members', 'vms-ops-console-premium'); ?></button>
                    <button id="vms-ops-member-lookup-clear" type="button" class="vms-ops-secondary"><?php echo esc_html__('Clear', 'vms-ops-console-premium'); ?></button>
                </div>
                <p id="vms-ops-member-lookup-feedback" class="vms-ops-feedback" aria-live="polite"></p>
                <p id="vms-ops-member-lookup-meta" class="vms-ops-mini"></p>
                <div id="vms-ops-member-lookup-results" class="vms-ops-member-lookup-results" data-tour-anchor="member-lookup-results"></div>
                <section id="vms-ops-member-lookup-detail" class="vms-ops-member-lookup-detail" data-tour-anchor="member-lookup-detail">
                    <div id="vms-ops-member-lookup-detail-card">
                        <div class="vms-ops-member-lookup-detail-card is-placeholder">
                            <p class="vms-ops-member-lookup-detail-label"><?php echo esc_html__('Member Details', 'vms-ops-console-premium'); ?></p>
                            <strong><?php echo esc_html__('Select a member above', 'vms-ops-console-premium'); ?></strong>
                            <p class="vms-ops-member-lookup-detail-copy"><?php echo esc_html__('Search above and tap a result to open Member Details and edit options.', 'vms-ops-console-premium'); ?></p>
                        </div>
                    </div>
                </section>
            </div>
        </section>

        <section class="vms-ops-panel" id="vms-ops-alert-panel"<?php echo ($alert_staff_enabled && (!empty($config['caps']['sendAlerts']) || !empty($config['caps']['receiveAlerts']))) ? '' : ' hidden'; ?>>
            <h2><?php echo esc_html__('Alert Staff', 'vms-ops-console-premium'); ?></h2>
            <div class="vms-ops-row">
                <select id="vms-ops-alert-preset"></select>
                <input id="vms-ops-alert-message" class="vms-ops-hidden" type="text" placeholder="<?php echo esc_attr__('Alert message', 'vms-ops-console-premium'); ?>">
                <select id="vms-ops-alert-urgency">
                    <option value="normal"><?php echo esc_html__('Normal', 'vms-ops-console-premium'); ?></option>
                    <option value="high"><?php echo esc_html__('High', 'vms-ops-console-premium'); ?></option>
                    <option value="critical"><?php echo esc_html__('Critical', 'vms-ops-console-premium'); ?></option>
                </select>
                <button id="vms-ops-alert-send" type="button"><?php echo esc_html__('Send Alert', 'vms-ops-console-premium'); ?></button>
            </div>
            <p id="vms-ops-alert-routing-hint" class="vms-ops-mini"></p>
            <p id="vms-ops-alert-feedback" class="vms-ops-feedback" aria-live="polite"></p>
            <ul id="vms-ops-alert-feed" class="vms-ops-alert-feed"></ul>
        </section>

    </div>

    <div id="vms-ops-banned-overlay" class="vms-ops-banned-overlay" hidden>
        <div class="vms-ops-banned-card">
            <h2><?php echo esc_html__('Banned Member', 'vms-ops-console-premium'); ?></h2>
            <p id="vms-ops-banned-text"><?php echo esc_html__('Manager intervention required.', 'vms-ops-console-premium'); ?></p>
            <button id="vms-ops-banned-clear" type="button"><?php echo esc_html__('Press and Hold to Clear', 'vms-ops-console-premium'); ?></button>
        </div>
    </div>



    <div id="vms-ops-venue-overlay" class="vms-ops-venue-overlay" hidden>
        <div class="vms-ops-venue-card">
            <h2 id="vms-ops-venue-overlay-title"><?php echo esc_html__('Select a venue to begin', 'vms-ops-console-premium'); ?></h2>
            <p id="vms-ops-venue-overlay-lead" class="vms-ops-mini"><?php echo esc_html__('Venue selection is required before using the console.', 'vms-ops-console-premium'); ?></p>
            <p id="vms-ops-venue-overlay-status" class="vms-ops-feedback" aria-live="polite"></p>
            <label for="vms-ops-venue-select-overlay" class="vms-ops-mini"><?php echo esc_html__('Venue', 'vms-ops-console-premium'); ?></label>
            <select id="vms-ops-venue-select-overlay">
                <option value=""><?php echo esc_html__('Select venue', 'vms-ops-console-premium'); ?></option>
            </select>
            <button id="vms-ops-venue-continue" type="button"><?php echo esc_html__('Continue', 'vms-ops-console-premium'); ?></button>
            <button id="vms-ops-venue-retry" type="button" class="vms-ops-secondary" hidden><?php echo esc_html__('Retry', 'vms-ops-console-premium'); ?></button>
        </div>
    </div>

    <div id="vms-ops-call-modal" class="vms-ops-modal" hidden>
        <div class="vms-ops-modal-card" role="dialog" aria-modal="true" aria-labelledby="vms-ops-call-modal-title">
            <div class="vms-ops-modal-head">
                <h2 id="vms-ops-call-modal-title"><?php echo esc_html__('Alert Staff', 'vms-ops-console-premium'); ?></h2>
                <button id="vms-ops-call-modal-close" class="vms-ops-modal-close" type="button" aria-label="<?php echo esc_attr__('Close', 'vms-ops-console-premium'); ?>">&times;</button>
            </div>
            <div class="vms-ops-modal-body">
                <label for="vms-ops-call-modal-preset"><?php echo esc_html__('Preset', 'vms-ops-console-premium'); ?></label>
                <select id="vms-ops-call-modal-preset"></select>

                <div id="vms-ops-call-modal-message-wrap" hidden>
                    <label for="vms-ops-call-modal-message"><?php echo esc_html__('Message', 'vms-ops-console-premium'); ?></label>
                    <input id="vms-ops-call-modal-message" type="text" placeholder="<?php echo esc_attr__('Alert message', 'vms-ops-console-premium'); ?>">
                </div>

                <label for="vms-ops-call-modal-urgency"><?php echo esc_html__('Urgency', 'vms-ops-console-premium'); ?></label>
                <select id="vms-ops-call-modal-urgency">
                    <option value="normal"><?php echo esc_html__('Normal', 'vms-ops-console-premium'); ?></option>
                    <option value="high"><?php echo esc_html__('High', 'vms-ops-console-premium'); ?></option>
                    <option value="critical"><?php echo esc_html__('Critical', 'vms-ops-console-premium'); ?></option>
                </select>
                <p id="vms-ops-call-modal-routing" class="vms-ops-mini"></p>
            </div>
            <div class="vms-ops-modal-actions">
                <button id="vms-ops-call-modal-cancel" type="button"><?php echo esc_html__('Cancel', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-call-modal-send" type="button"><?php echo esc_html__('Send', 'vms-ops-console-premium'); ?></button>
            </div>
            <p id="vms-ops-call-modal-feedback" class="vms-ops-feedback" aria-live="polite"></p>
        </div>
    </div>

    <div id="vms-ops-scan-modal" class="vms-ops-modal vms-ops-scan-modal" hidden>
        <div class="vms-ops-modal-card vms-ops-scan-card" role="dialog" aria-modal="true" aria-labelledby="vms-ops-scan-title">
            <div class="vms-ops-modal-head">
                <h2 id="vms-ops-scan-title"><?php echo esc_html__('Scanner', 'vms-ops-console-premium'); ?></h2>
                <button id="vms-ops-scan-close" class="vms-ops-modal-close" type="button" aria-label="<?php echo esc_attr__('Close', 'vms-ops-console-premium'); ?>">&times;</button>
            </div>

            <div class="vms-ops-modal-body">
                <div id="vms-ops-scan-viewport" class="vms-ops-scan-viewport">
                    <video id="vms-ops-scan-video" playsinline webkit-playsinline autoplay muted disablepictureinpicture></video>
                    <div class="vms-ops-scan-overlay" aria-hidden="true">
                        <div id="vms-ops-scan-status" class="vms-ops-scan-status">SCANNING…</div>
                        <div id="vms-ops-scan-mask" class="vms-ops-scan-mask"></div>
                        <div id="vms-ops-scan-target" class="vms-ops-scan-target" data-mode="ticket"></div>
                    </div>
                    <div id="vms-ops-scan-focus-ring" class="vms-ops-scan-focus-ring" aria-hidden="true"></div>
                </div>
                <div id="vms-ops-scan-result" class="vms-ops-scan-result" hidden>
                    <strong id="vms-ops-scan-result-headline" class="vms-ops-scan-result-headline"></strong>
                    <span id="vms-ops-scan-result-detail" class="vms-ops-scan-result-detail"></span>
                </div>
                <p id="vms-ops-scan-hint" class="vms-ops-mini"></p>
                <p id="vms-ops-scan-feedback" class="vms-ops-feedback" aria-live="polite"></p>
            </div>

            <div class="vms-ops-modal-actions">
                <button id="vms-ops-scan-flip" type="button" class="vms-ops-secondary"><?php echo esc_html__('Flip Camera', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-scan-torch" type="button" class="vms-ops-secondary" hidden><?php echo esc_html__('Light On', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-scan-zoom-out" type="button" class="vms-ops-secondary" hidden><?php echo esc_html__('Zoom -', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-scan-zoom-reset" type="button" class="vms-ops-secondary" hidden><?php echo esc_html__('Zoom 1x', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-scan-zoom-in" type="button" class="vms-ops-secondary" hidden><?php echo esc_html__('Zoom +', 'vms-ops-console-premium'); ?></button>
                <button id="vms-ops-scan-cancel" type="button"><?php echo esc_html__('Cancel', 'vms-ops-console-premium'); ?></button>
            </div>
        </div>
    </div>
    <p id="vms-ops-global-feedback" class="vms-ops-global-feedback" aria-live="polite"></p>
    <?php if ($alert_staff_enabled && !empty($config['caps']['sendAlerts'])) : ?>
    <div class="vms-ops-floating-actions">
        <button id="vms-ops-call-staff" class="vms-ops-call-staff" type="button"><?php echo esc_html__('Alert Staff', 'vms-ops-console-premium'); ?></button>
    </div>
    <?php endif; ?>

    <script>
        window.vmsOpsConfig = <?php echo wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_HEX_APOS); ?>;
    </script>
    <script src="<?php echo esc_url(VMS_OPS_CONSOLE_URL . 'pwa/assets/js/member-lookup-access.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)); ?>" defer></script>
    <script src="<?php echo esc_url(VMS_OPS_CONSOLE_URL . 'pwa/assets/js/member-lookup-dob.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)); ?>" defer></script>
    <script src="<?php echo esc_url(VMS_OPS_CONSOLE_URL . 'pwa/assets/js/member-photo-capture.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)); ?>" defer></script>
    <script src="<?php echo esc_url(VMS_OPS_CONSOLE_URL . 'pwa/assets/js/app.js?ver=' . rawurlencode(VMS_OPS_CONSOLE_VERSION)); ?>" defer></script>
</body>
</html>
        <?php
        exit;
    }
}

if (!function_exists('vms_ops_template_router')) {
    function vms_ops_template_router(): void
    {
        if ((int) get_query_var('vms_ops_legacy_console') === 1 || vms_ops_is_legacy_console_request()) {
            vms_ops_redirect_legacy_console();
        }

        $icon_size = absint((string) get_query_var('vms_ops_icon'));
        if ($icon_size > 0) {
            vms_ops_render_icon($icon_size);
        }

        if ((int) get_query_var('vms_ops_manifest') === 1) {
            vms_ops_render_manifest();
        }

        if ((int) get_query_var('vms_ops_sw') === 1) {
            vms_ops_render_sw();
        }

        if ((int) get_query_var('vms_ops_pwa') === 1) {
            vms_ops_render_pwa_shell();
        }
    }
}
add_action('template_redirect', 'vms_ops_template_router', 0);

if (!function_exists('vms_ops_plugin_boot')) {
    function vms_ops_plugin_boot(): void
    {
        vms_ops_register_capabilities();
        vms_ops_seed_default_options();

        $stored_version = (string) get_option('vms_ops_console_version', '');
        if ($stored_version !== VMS_OPS_CONSOLE_VERSION) {
            update_option('vms_ops_console_version', VMS_OPS_CONSOLE_VERSION, false);
            vms_ops_schedule_rewrite_flush();
        }

        $schema_result = vms_ops_maybe_upgrade_schema();
        if (is_wp_error($schema_result)) {
            error_log('VMS Ops Console schema upgrade failed: ' . $schema_result->get_error_message());
        }
    }
}
add_action('plugins_loaded', 'vms_ops_plugin_boot', 8);

add_action('init', 'vms_ops_register_rewrite_rules', 9);

if (!function_exists('vms_ops_addons_manifest_entry')) {
    function vms_ops_addons_manifest_entry(): array
    {
        return array(
            'slug' => 'ops_console',
            'name' => 'VMS Ops Console',
            'description_short' => 'PWA ops console, ticket check-in, alert routing, and team capability tools.',
            'category' => 'Operations',
            'icon' => 'dashicons-smartphone',
            'plugin_file' => 'vms-ops-console-premium/vms-ops-console-premium.php',
            'settings_url' => admin_url('admin.php?page=vms-ops-console'),
            'docs_url' => '',
            'requires' => array(),
            'freemius' => array(
                'product_id' => 0,
            ),
            'install' => array(
                'method' => 'zip_upload',
                'notes' => 'Upload the premium Ops Console package, then activate it from Add-ons.',
            ),
            'safe_remove' => false,
        );
    }
}

if (!function_exists('vms_ops_filter_addons_manifest_entries')) {
    function vms_ops_filter_addons_manifest_entries(array $entries): array
    {
        $entry = vms_ops_addons_manifest_entry();
        $slug = sanitize_key((string) ($entry['slug'] ?? ''));
        if ($slug === '') {
            return $entries;
        }

        $replaced = false;
        foreach ($entries as $index => $candidate) {
            if (!is_array($candidate)) {
                continue;
            }

            $candidate_slug = sanitize_key((string) ($candidate['slug'] ?? ''));
            if ($candidate_slug !== $slug) {
                continue;
            }

            $entries[$index] = array_merge($candidate, $entry);
            $replaced = true;
            break;
        }

        if (!$replaced) {
            $entries[] = $entry;
        }

        return $entries;
    }
}
add_filter('vms_addons_manifest_entries', 'vms_ops_filter_addons_manifest_entries');
