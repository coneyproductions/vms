<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_setup_status_role_profile_meta_option_key')) {
    function vms_ops_setup_status_role_profile_meta_option_key(): string
    {
        return 'vms_ops_staff_role_cap_profile_meta';
    }
}

if (!function_exists('vms_ops_setup_status_user_sync_meta_key')) {
    function vms_ops_setup_status_user_sync_meta_key(): string
    {
        return 'vms_ops_last_role_sync_at';
    }
}

if (!function_exists('vms_ops_setup_status_user_sync_mode_meta_key')) {
    function vms_ops_setup_status_user_sync_mode_meta_key(): string
    {
        return 'vms_ops_last_role_sync_mode';
    }
}

if (!function_exists('vms_ops_setup_status_get_role_profile_meta')) {
    function vms_ops_setup_status_get_role_profile_meta(): array
    {
        $stored = get_option(vms_ops_setup_status_role_profile_meta_option_key(), array());
        if (!is_array($stored)) {
            return array();
        }

        $clean = array();
        foreach ($stored as $raw_role_id => $row) {
            $role_id = absint((string) $raw_role_id);
            if ($role_id <= 0 || !is_array($row)) {
                continue;
            }

            $updated_at = isset($row['updated_at']) ? absint((string) $row['updated_at']) : 0;
            if ($updated_at <= 0) {
                continue;
            }

            $clean[(string) $role_id] = array(
                'updated_at' => $updated_at,
            );
        }

        return $clean;
    }
}

if (!function_exists('vms_ops_setup_status_touch_role_profile_meta')) {
    function vms_ops_setup_status_touch_role_profile_meta(array $old_profiles, array $new_profiles): void
    {
        $old_profiles = is_array($old_profiles) ? $old_profiles : array();
        $new_profiles = is_array($new_profiles) ? $new_profiles : array();
        $meta = vms_ops_setup_status_get_role_profile_meta();
        $now = vms_ops_now_timestamp();

        $role_ids = array_unique(array_merge(array_keys($old_profiles), array_keys($new_profiles)));
        foreach ($role_ids as $raw_role_id) {
            $role_id = absint((string) $raw_role_id);
            if ($role_id <= 0) {
                continue;
            }

            $role_key = (string) $role_id;
            $before = isset($old_profiles[$role_key]) && is_array($old_profiles[$role_key]) ? array_values($old_profiles[$role_key]) : array();
            $after = isset($new_profiles[$role_key]) && is_array($new_profiles[$role_key]) ? array_values($new_profiles[$role_key]) : array();
            sort($before);
            sort($after);

            if ($before === $after) {
                continue;
            }

            $meta[$role_key] = array(
                'updated_at' => $now,
            );
        }

        update_option(vms_ops_setup_status_role_profile_meta_option_key(), $meta, false);
    }
}

if (!function_exists('vms_ops_setup_status_mark_user_synced')) {
    function vms_ops_setup_status_mark_user_synced(int $user_id, string $mode = 'replace'): void
    {
        $user_id = absint($user_id);
        if ($user_id <= 0) {
            return;
        }

        update_user_meta($user_id, vms_ops_setup_status_user_sync_meta_key(), vms_ops_now_timestamp());
        update_user_meta($user_id, vms_ops_setup_status_user_sync_mode_meta_key(), sanitize_key($mode));
    }
}

if (!function_exists('vms_ops_setup_status_related_role_slugs')) {
    function vms_ops_setup_status_related_role_slugs(): array
    {
        $slugs = array(
            'vms_door_staff',
            'door_staff',
            'event_manager',
            'vms_event_manager',
        );

        $slugs = apply_filters('vms_ops_setup_related_role_slugs', $slugs);
        $slugs = array_values(array_unique(array_filter(array_map('sanitize_key', (array) $slugs))));

        return $slugs;
    }
}

if (!function_exists('vms_ops_setup_status_get_user_role_labels')) {
    function vms_ops_setup_status_get_user_role_labels(WP_User $user): array
    {
        global $wp_roles;

        $labels = array();
        foreach ((array) $user->roles as $role_slug) {
            $role_slug = sanitize_key((string) $role_slug);
            if ($role_slug === '') {
                continue;
            }

            $label = '';
            if ($wp_roles instanceof WP_Roles && isset($wp_roles->roles[$role_slug]['name'])) {
                $label = sanitize_text_field((string) $wp_roles->roles[$role_slug]['name']);
            }

            $labels[$role_slug] = $label !== '' ? $label : $role_slug;
        }

        return $labels;
    }
}

if (!function_exists('vms_ops_setup_status_user_has_related_role')) {
    function vms_ops_setup_status_user_has_related_role(WP_User $user): bool
    {
        $labels = vms_ops_setup_status_get_user_role_labels($user);
        $tracked_slugs = array_fill_keys(vms_ops_setup_status_related_role_slugs(), true);

        foreach ($labels as $role_slug => $role_label) {
            if (isset($tracked_slugs[$role_slug])) {
                return true;
            }

            $role_slug = sanitize_key((string) $role_slug);
            $role_label = strtolower(trim((string) $role_label));
            if ($role_slug !== '' && strpos($role_slug, 'vms_ops') === 0) {
                return true;
            }
            if ($role_label !== '' && (strpos($role_label, 'door staff') !== false || strpos($role_label, 'ops') !== false)) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('vms_ops_setup_status_context')) {
    function vms_ops_setup_status_context(): array
    {
        static $context = null;
        if (is_array($context)) {
            return $context;
        }

        $context = array(
            'role_profiles' => function_exists('vms_ops_admin_role_profiles_get') ? vms_ops_admin_role_profiles_get() : array(),
            'linked_staff_index' => function_exists('vms_ops_admin_collect_linked_staff_index') ? vms_ops_admin_collect_linked_staff_index() : array(),
            'role_profile_meta' => vms_ops_setup_status_get_role_profile_meta(),
            'allowed_caps' => function_exists('vms_ops_admin_team_caps') ? vms_ops_admin_team_caps() : (function_exists('vms_ops_all_capabilities') ? vms_ops_all_capabilities() : array()),
        );

        return $context;
    }
}

if (!function_exists('vms_ops_setup_status_override_enabled_caps')) {
    function vms_ops_setup_status_override_enabled_caps(array $override_map): array
    {
        $caps = array();
        foreach ($override_map as $cap => $enabled) {
            $cap = sanitize_text_field((string) $cap);
            if ($cap === '' || empty($enabled)) {
                continue;
            }
            $caps[] = $cap;
        }

        $caps = array_values(array_unique($caps));
        sort($caps);

        return $caps;
    }
}

if (!function_exists('vms_ops_setup_status_staff_latest_change_at')) {
    function vms_ops_setup_status_staff_latest_change_at(array $staff_ids): int
    {
        $latest = 0;
        foreach ($staff_ids as $staff_id) {
            $staff_id = absint((string) $staff_id);
            if ($staff_id <= 0) {
                continue;
            }

            $modified = (int) get_post_modified_time('U', true, $staff_id);
            if ($modified > $latest) {
                $latest = $modified;
            }
        }

        return $latest;
    }
}

if (!function_exists('vms_ops_setup_status_build_role_profile_target')) {
    function vms_ops_setup_status_build_role_profile_target(array $role_ids, array $role_profiles, array $role_names = array()): array
    {
        if (function_exists('vms_ops_admin_resolve_caps_for_linked_staff_entry')) {
            return vms_ops_admin_resolve_caps_for_linked_staff_entry(array(
                'role_ids' => $role_ids,
                'role_names' => $role_names,
            ), $role_profiles);
        }

        $desired_caps = array();
        $missing_profiles = array();

        foreach ($role_ids as $raw_role_id) {
            $role_id = absint((string) $raw_role_id);
            if ($role_id <= 0) {
                continue;
            }

            $role_key = (string) $role_id;
            if (!array_key_exists($role_key, $role_profiles) || !is_array($role_profiles[$role_key])) {
                $missing_profiles[] = $role_id;
                continue;
            }

            foreach ($role_profiles[$role_key] as $cap) {
                $cap = sanitize_text_field((string) $cap);
                if ($cap !== '') {
                    $desired_caps[] = $cap;
                }
            }
        }

        $desired_caps = array_values(array_unique($desired_caps));
        sort($desired_caps);
        $missing_profiles = array_values(array_unique(array_map('absint', $missing_profiles)));

        return array(
            'desired_caps' => $desired_caps,
            'missing_profiles' => $missing_profiles,
        );
    }
}

if (!function_exists('vms_ops_setup_status_primary_label_map')) {
    function vms_ops_setup_status_primary_label_map(): array
    {
        return array(
            'ready' => __('Ready', 'vms-ops-console-premium'),
            'no_staff_link' => __('No Staff Link', 'vms-ops-console-premium'),
            'no_staff_role' => __('No Staff Role', 'vms-ops-console-premium'),
            'needs_role_sync' => __('Needs Role Sync', 'vms-ops-console-premium'),
            'permission_mismatch' => __('Permission Mismatch', 'vms-ops-console-premium'),
            'custom_override' => __('Custom Override', 'vms-ops-console-premium'),
            'no_ops_access' => __('No Ops Access', 'vms-ops-console-premium'),
        );
    }
}

if (!function_exists('vms_ops_setup_status_review_user_url')) {
    function vms_ops_setup_status_review_user_url(int $user_id): string
    {
        return (string) admin_url('user-edit.php?user_id=' . absint($user_id));
    }
}

if (!function_exists('vms_ops_setup_status_review_staff_url')) {
    function vms_ops_setup_status_review_staff_url(int $staff_id = 0): string
    {
        $staff_id = absint($staff_id);
        if ($staff_id > 0) {
            return (string) admin_url('post.php?post=' . $staff_id . '&action=edit');
        }

        return (string) admin_url('edit.php?post_type=vms_staff');
    }
}

if (!function_exists('vms_ops_setup_status_resync_user_url')) {
    function vms_ops_setup_status_resync_user_url(int $user_id): string
    {
        return (string) wp_nonce_url(
            admin_url('admin-post.php?action=vms_ops_resync_setup_user&user_id=' . absint($user_id)),
            'vms_ops_resync_setup_user_' . absint($user_id)
        );
    }
}

if (!function_exists('vms_ops_setup_status_resync_flagged_url')) {
    function vms_ops_setup_status_resync_flagged_url(): string
    {
        return (string) wp_nonce_url(
            admin_url('admin-post.php?action=vms_ops_resync_flagged_users'),
            'vms_ops_resync_flagged_users'
        );
    }
}

if (!function_exists('vms_ops_setup_status_for_user')) {
    function vms_ops_setup_status_for_user($user, ?array $context = null): array
    {
        if (!($user instanceof WP_User) || $user->ID <= 0) {
            return array(
                'tracked' => false,
                'ready' => false,
                'status_key' => 'no_ops_access',
                'status_label' => __('No Ops Access', 'vms-ops-console-premium'),
                'status_level' => 'neutral',
                'summary' => '',
                'counts' => array(),
                'checklist' => array(),
                'actions' => array(),
            );
        }

        $context = is_array($context) ? $context : vms_ops_setup_status_context();
        $allowed_caps = isset($context['allowed_caps']) && is_array($context['allowed_caps']) ? $context['allowed_caps'] : array();
        $linked_staff_index = isset($context['linked_staff_index']) && is_array($context['linked_staff_index']) ? $context['linked_staff_index'] : array();
        $role_profiles = isset($context['role_profiles']) && is_array($context['role_profiles']) ? $context['role_profiles'] : array();
        $role_profile_meta = isset($context['role_profile_meta']) && is_array($context['role_profile_meta']) ? $context['role_profile_meta'] : array();

        $user_id = (int) $user->ID;
        $linked_staff = isset($linked_staff_index[$user_id]) && is_array($linked_staff_index[$user_id])
            ? $linked_staff_index[$user_id]
            : array(
                'staff_ids' => array(),
                'staff_labels' => array(),
                'role_ids' => array(),
                'role_names' => array(),
            );

        $staff_ids = array_values(array_unique(array_map('absint', (array) ($linked_staff['staff_ids'] ?? array()))));
        $staff_labels = array_values(array_unique(array_filter(array_map('strval', (array) ($linked_staff['staff_labels'] ?? array())))));
        $role_ids = array_values(array_unique(array_map('absint', (array) ($linked_staff['role_ids'] ?? array()))));
        $role_names = array_values(array_unique(array_filter(array_map('strval', (array) ($linked_staff['role_names'] ?? array())))));

        $role_profile_target = vms_ops_setup_status_build_role_profile_target($role_ids, $role_profiles, $role_names);
        $desired_caps = (array) ($role_profile_target['desired_caps'] ?? array());
        $missing_role_profiles = (array) ($role_profile_target['missing_profiles'] ?? array());

        $effective_caps = function_exists('vms_ops_admin_user_effective_team_caps')
            ? vms_ops_admin_user_effective_team_caps($user, $allowed_caps)
            : array_values(array_filter($allowed_caps, static function (string $cap) use ($user): bool {
                return $cap !== '' && user_can($user, $cap);
            }));
        sort($effective_caps);

        $override_map = function_exists('vms_ops_get_user_cap_override_map') ? vms_ops_get_user_cap_override_map($user_id) : array();
        $override_caps = vms_ops_setup_status_override_enabled_caps($override_map);
        $desired_caps_sorted = $desired_caps;
        sort($desired_caps_sorted);
        $override_active = !empty($override_map) && $override_caps !== $desired_caps_sorted;

        $use_pwa_cap = function_exists('vms_ops_capability_use_pwa') ? vms_ops_capability_use_pwa() : 'vms_ops_use_pwa';
        $scan_tickets_cap = function_exists('vms_ops_capability_scan_tickets') ? vms_ops_capability_scan_tickets() : 'vms_ops_scan_tickets';
        $scan_ids_cap = function_exists('vms_ops_capability_scan_ids') ? vms_ops_capability_scan_ids() : 'vms_ops_scan_ids';
        $manage_lite_cap = function_exists('vms_ops_capability_manage_members_lite') ? vms_ops_capability_manage_members_lite() : 'vms_ops_manage_members_lite';
        $manage_admin_cap = function_exists('vms_ops_capability_manage_members_admin') ? vms_ops_capability_manage_members_admin() : 'vms_ops_manage_members_admin';

        $linked = !empty($staff_ids);
        $has_staff_role = !empty($role_ids) || !empty($role_names);
        $has_use_pwa = in_array($use_pwa_cap, $effective_caps, true);
        $missing_required_caps = array_values(array_diff($desired_caps_sorted, $effective_caps));
        $has_related_role = vms_ops_setup_status_user_has_related_role($user);
        $is_admin = user_can($user, 'manage_options') || in_array('administrator', (array) $user->roles, true);
        $has_non_admin_ops_caps = !$is_admin && !empty($effective_caps);
        $tracked = $linked || $override_active || $has_related_role || $has_non_admin_ops_caps;

        $staff_changed_at = vms_ops_setup_status_staff_latest_change_at($staff_ids);
        $profiles_changed_at = 0;
        foreach ($role_ids as $role_id) {
            $role_key = (string) absint($role_id);
            $candidate = isset($role_profile_meta[$role_key]['updated_at']) ? absint((string) $role_profile_meta[$role_key]['updated_at']) : 0;
            if ($candidate > $profiles_changed_at) {
                $profiles_changed_at = $candidate;
            }
        }

        $last_sync_at = absint((string) get_user_meta($user_id, vms_ops_setup_status_user_sync_meta_key(), true));
        $latest_relevant_change = max($staff_changed_at, $profiles_changed_at);
        $needs_sync = $tracked
            && $linked
            && $has_staff_role
            && !$override_active
            && (
                !empty($missing_role_profiles)
                || $last_sync_at <= 0
                || ($latest_relevant_change > 0 && $last_sync_at < $latest_relevant_change)
            );

        $permission_mismatch = $tracked
            && $linked
            && $has_staff_role
            && !$override_active
            && empty($needs_sync)
            && !empty($missing_required_caps);

        $no_ops_access = $tracked && !$has_use_pwa;

        $status_key = 'ready';
        if (!$tracked) {
            $status_key = 'no_ops_access';
        } elseif (!$linked) {
            $status_key = 'no_staff_link';
        } elseif (!$has_staff_role) {
            $status_key = 'no_staff_role';
        } elseif ($needs_sync) {
            $status_key = 'needs_role_sync';
        } elseif ($no_ops_access) {
            $status_key = 'no_ops_access';
        } elseif ($permission_mismatch) {
            $status_key = 'permission_mismatch';
        } elseif ($override_active) {
            $status_key = 'custom_override';
        }

        $labels = vms_ops_setup_status_primary_label_map();
        $status_label = $labels[$status_key] ?? $labels['no_ops_access'];
        $status_level = 'neutral';
        if ($status_key === 'ready') {
            $status_level = 'ready';
        } elseif (in_array($status_key, array('needs_role_sync', 'custom_override'), true)) {
            $status_level = 'warning';
        } elseif ($tracked) {
            $status_level = 'error';
        }

        $summary = '';
        switch ($status_key) {
            case 'no_staff_link':
                $summary = __('Setup incomplete: this user is not linked to a staff record. Ops permissions may not sync correctly.', 'vms-ops-console-premium');
                break;
            case 'no_staff_role':
                $summary = __('Setup incomplete: linked staff record has no VMS staff role.', 'vms-ops-console-premium');
                break;
            case 'no_ops_access':
                $summary = $tracked
                    ? __('Setup incomplete: this user cannot access the Ops console.', 'vms-ops-console-premium')
                    : __('This account is not configured for Ops access yet.', 'vms-ops-console-premium');
                break;
            case 'needs_role_sync':
                $summary = !empty($missing_role_profiles)
                    ? __('Setup incomplete: one or more linked staff roles do not have an Ops role profile yet, or the profile has not been synced to this user. Save the role profile, then run Role Sync.', 'vms-ops-console-premium')
                    : __('Setup incomplete: staff role permissions have not been synced to this user yet. Run Role Sync or use Resync From Role Profile for this user.', 'vms-ops-console-premium');
                break;
            case 'permission_mismatch':
                $summary = __('Permission mismatch: assigned staff role does not match current Ops capabilities.', 'vms-ops-console-premium');
                break;
            case 'custom_override':
                $summary = __('Custom override active: this user differs from the standard role profile.', 'vms-ops-console-premium');
                break;
            default:
                $summary = __('Ready: staff link, staff role, and Ops access line up for this user.', 'vms-ops-console-premium');
                break;
        }

        $checklist = array(
            array(
                'key' => 'wp_account',
                'label' => __('WordPress account exists', 'vms-ops-console-premium'),
                'ok' => true,
            ),
            array(
                'key' => 'ops_access',
                'label' => __('Ops/PWA access granted', 'vms-ops-console-premium'),
                'ok' => $has_use_pwa,
            ),
            array(
                'key' => 'staff_link',
                'label' => __('Linked to Staff record', 'vms-ops-console-premium'),
                'ok' => $linked,
            ),
            array(
                'key' => 'staff_role',
                'label' => __('Staff role assigned', 'vms-ops-console-premium'),
                'ok' => $has_staff_role,
            ),
            array(
                'key' => 'role_sync',
                'label' => __('Role profile synced', 'vms-ops-console-premium'),
                'ok' => $linked && $has_staff_role && empty($missing_role_profiles) && !$needs_sync,
            ),
            array(
                'key' => 'scan_tickets',
                'label' => __('Can scan tickets', 'vms-ops-console-premium'),
                'ok' => in_array($scan_tickets_cap, $effective_caps, true),
            ),
            array(
                'key' => 'scan_ids',
                'label' => __('Can scan IDs', 'vms-ops-console-premium'),
                'ok' => in_array($scan_ids_cap, $effective_caps, true),
            ),
            array(
                'key' => 'manage_members',
                'label' => __('Can manage members', 'vms-ops-console-premium'),
                'ok' => in_array($manage_lite_cap, $effective_caps, true) || in_array($manage_admin_cap, $effective_caps, true),
            ),
            array(
                'key' => 'manual_override',
                'label' => __('Has manual override', 'vms-ops-console-premium'),
                'ok' => $override_active,
            ),
        );

        $actions = array(
            array(
                'label' => __('Review WP User', 'vms-ops-console-premium'),
                'url' => vms_ops_setup_status_review_user_url($user_id),
                'kind' => 'secondary',
            ),
        );

        if (!$linked) {
            $actions[] = array(
                'label' => __('Add / Link Staff Record', 'vms-ops-console-premium'),
                'url' => vms_ops_setup_status_review_staff_url(0),
                'kind' => 'secondary',
            );
        } else {
            $actions[] = array(
                'label' => __('Review Staff Record', 'vms-ops-console-premium'),
                'url' => vms_ops_setup_status_review_staff_url((int) ($staff_ids[0] ?? 0)),
                'kind' => 'secondary',
            );
        }

        if ($tracked && ($needs_sync || $permission_mismatch || $no_ops_access)) {
            $actions[] = array(
                'label' => __('Resync From Role Profile', 'vms-ops-console-premium'),
                'url' => vms_ops_setup_status_resync_user_url($user_id),
                'kind' => 'primary',
            );
        }

        if (!empty($missing_role_profiles)) {
            $actions[] = array(
                'label' => __('Review Role Profiles', 'vms-ops-console-premium'),
                'url' => admin_url('admin.php?page=' . (function_exists('vms_ops_admin_teams_page_slug') ? vms_ops_admin_teams_page_slug() : 'vms-ops-console-teams') . '#vms-ops-team-role-profiles'),
                'kind' => 'secondary',
            );
        }

        if ($override_active) {
            $actions[] = array(
                'label' => __('Review Overrides', 'vms-ops-console-premium'),
                'url' => admin_url('admin.php?page=' . (function_exists('vms_ops_admin_teams_page_slug') ? vms_ops_admin_teams_page_slug() : 'vms-ops-console-teams') . '#vms-ops-team-user-' . $user_id),
                'kind' => 'secondary',
            );
        }

        return array(
            'tracked' => $tracked,
            'ready' => $tracked && $status_key === 'ready',
            'status_key' => $status_key,
            'status_label' => $status_label,
            'status_level' => $status_level,
            'summary' => $summary,
            'linked' => $linked,
            'has_staff_role' => $has_staff_role,
            'override_active' => $override_active,
            'needs_sync' => $needs_sync,
            'permission_mismatch' => $permission_mismatch,
            'no_ops_access' => $no_ops_access,
            'missing_required_caps' => $missing_required_caps,
            'desired_caps' => $desired_caps_sorted,
            'effective_caps' => $effective_caps,
            'missing_role_profiles' => $missing_role_profiles,
            'linked_staff' => array(
                'staff_ids' => $staff_ids,
                'staff_labels' => $staff_labels,
                'role_ids' => $role_ids,
                'role_names' => $role_names,
            ),
            'last_sync_at' => $last_sync_at,
            'latest_relevant_change' => $latest_relevant_change,
            'checklist' => $checklist,
            'actions' => $actions,
            'counts' => array(
                'users_need_setup' => ($tracked && !in_array($status_key, array('ready', 'custom_override'), true)) ? 1 : 0,
                'missing_staff_links' => ($tracked && !$linked) ? 1 : 0,
                'missing_staff_roles' => ($tracked && $linked && !$has_staff_role) ? 1 : 0,
                'needs_role_sync' => ($tracked && $needs_sync) ? 1 : 0,
                'permission_mismatch' => ($tracked && $permission_mismatch) ? 1 : 0,
                'custom_overrides' => ($tracked && $override_active) ? 1 : 0,
                'no_ops_access' => ($tracked && $no_ops_access) ? 1 : 0,
            ),
            'frontend' => array(
                'tracked' => $tracked ? 1 : 0,
                'ready' => ($tracked && $status_key === 'ready') ? 1 : 0,
                'status_key' => $status_key,
                'status_label' => $status_label,
                'status_level' => $status_level,
                'summary' => $summary,
                'checklist' => array_values(array_map(static function (array $item): array {
                    return array(
                        'label' => (string) ($item['label'] ?? ''),
                        'ok' => !empty($item['ok']) ? 1 : 0,
                    );
                }, $checklist)),
            ),
        );
    }
}

if (!function_exists('vms_ops_setup_status_frontend_payload_for_user')) {
    function vms_ops_setup_status_frontend_payload_for_user(int $user_id): array
    {
        $user = get_user_by('id', $user_id);
        $status = vms_ops_setup_status_for_user($user);

        return isset($status['frontend']) && is_array($status['frontend'])
            ? $status['frontend']
            : array();
    }
}

if (!function_exists('vms_ops_setup_status_user_column_label')) {
    function vms_ops_setup_status_user_column_label(): string
    {
        return __('Ops Setup', 'vms-ops-console-premium');
    }
}

if (!function_exists('vms_ops_setup_status_render_user_badge')) {
    function vms_ops_setup_status_render_user_badge(array $status): string
    {
        if (empty($status['tracked'])) {
            return '<span class="description">&mdash;</span>';
        }

        $badge_class = 'vms-ops-user-setup-badge';
        $level = sanitize_html_class((string) ($status['status_level'] ?? 'neutral'));
        if ($level !== '') {
            $badge_class .= ' is-' . $level;
        }

        $label = esc_html((string) ($status['status_label'] ?? __('Ops Setup', 'vms-ops-console-premium')));
        $summary = trim((string) ($status['summary'] ?? ''));
        $summary_html = $summary !== '' ? '<div class="vms-ops-user-setup-summary">' . esc_html($summary) . '</div>' : '';

        return '<span class="' . esc_attr($badge_class) . '">' . $label . '</span>' . $summary_html;
    }
}

add_filter('manage_users_columns', static function (array $columns): array {
    $columns['vms_ops_setup_status'] = vms_ops_setup_status_user_column_label();
    return $columns;
});

add_filter('manage_users_custom_column', static function (string $output, string $column_name, string $user_id) {
    if ($column_name !== 'vms_ops_setup_status') {
        return $output;
    }

    $user = get_user_by('id', absint($user_id));
    $status = vms_ops_setup_status_for_user($user);
    return vms_ops_setup_status_render_user_badge($status);
}, 10, 3);
