<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_rest_ok')) {
    function vms_ops_rest_ok(array $data = array(), int $status = 200): WP_REST_Response
    {
        return new WP_REST_Response(array(
            'ok' => true,
            'data' => $data,
            'error' => null,
        ), $status);
    }
}

if (!function_exists('vms_ops_rest_error')) {
    function vms_ops_rest_error(string $code, string $message, int $status = 400, $data = null): WP_REST_Response
    {
        return new WP_REST_Response(array(
            'ok' => false,
            'data' => $data,
            'error' => array(
                'code' => sanitize_key($code),
                'message' => $message,
            ),
        ), $status);
    }
}

if (!function_exists('vms_ops_rest_error_from_wp_error')) {
    function vms_ops_rest_error_from_wp_error(WP_Error $error): WP_REST_Response
    {
        $code = (string) $error->get_error_code();
        $message = (string) $error->get_error_message();
        $data = $error->get_error_data();

        $status = 400;
        if (is_array($data) && isset($data['status']) && is_numeric($data['status'])) {
            $status = (int) $data['status'];
        } else {
            if (strpos($code, 'forbidden') !== false) {
                $status = 403;
            } elseif (strpos($code, 'not_found') !== false) {
                $status = 404;
            } elseif (strpos($code, 'duplicate') !== false) {
                $status = 409;
            } elseif (strpos($code, 'failed') !== false || strpos($code, 'db_') === 0 || strpos($code, 'insert_') !== false || strpos($code, 'update_') !== false) {
                $status = 500;
            }
        }

        return vms_ops_rest_error($code !== '' ? $code : 'request_failed', $message, $status, $data);
    }
}

if (!function_exists('vms_ops_rest_verify_nonce')) {
    function vms_ops_rest_verify_nonce(WP_REST_Request $request): bool
    {
        $nonce = (string) $request->get_header('x_wp_nonce');
        if ($nonce === '') {
            $nonce = (string) $request->get_param('_wpnonce');
        }

        if ($nonce === '') {
            return false;
        }

        return wp_verify_nonce($nonce, 'wp_rest') === 1;
    }
}

if (!function_exists('vms_ops_rest_permission_callback')) {
    function vms_ops_rest_permission_callback(array $caps, array $context = array()): callable
    {
        return static function (WP_REST_Request $request) use ($caps, $context) {
            $route = method_exists($request, 'get_route') ? (string) $request->get_route() : '';
            $action = isset($context['action']) ? sanitize_key((string) $context['action']) : 'ops_request';
            $reason = isset($context['reason']) ? sanitize_key((string) $context['reason']) : 'missing_capability';
            $allow_manage_options = !array_key_exists('allow_manage_options', $context) || !empty($context['allow_manage_options']);

            if (!is_user_logged_in()) {
                return new WP_Error('forbidden', __('Authentication required.', 'vms-ops-console-premium'), array('status' => 401));
            }

            if (!vms_ops_rest_verify_nonce($request)) {
                if (function_exists('vms_ops_log_diagnostic_event')) {
                    vms_ops_log_diagnostic_event('rest_permission_denied', array(
                        'reason' => 'invalid_nonce',
                        'route' => $route,
                        'requested_action' => $action,
                        'selected_event_id' => absint($request->get_param('event_id')),
                    ));
                }
                return new WP_Error('invalid_nonce', __('Nonce validation failed.', 'vms-ops-console-premium'), array('status' => 403));
            }

            $has_permission = $allow_manage_options
                ? (function_exists('vms_ops_user_has_any_capability_or_admin')
                    ? vms_ops_user_has_any_capability_or_admin($caps)
                    : (current_user_can('manage_options') || vms_ops_user_has_any_capability($caps)))
                : vms_ops_user_has_any_capability($caps);

            if (!$has_permission) {
                $code = isset($context['code']) ? sanitize_key((string) $context['code']) : 'forbidden';
                $message = isset($context['message']) ? (string) $context['message'] : __('You do not have permission for this action.', 'vms-ops-console-premium');
                if (function_exists('vms_ops_log_diagnostic_event')) {
                    vms_ops_log_diagnostic_event('rest_permission_denied', array(
                        'reason' => $reason !== '' ? $reason : 'missing_capability',
                        'route' => $route,
                        'requested_action' => $action,
                        'required_caps' => array_values(array_map('strval', $caps)),
                        'allow_manage_options' => $allow_manage_options ? 1 : 0,
                        'has_manage_options' => current_user_can('manage_options') ? 1 : 0,
                        'selected_event_id' => absint($request->get_param('event_id')),
                        'venue_id' => absint($request->get_param('venue_id')),
                    ));
                }
                return new WP_Error($code !== '' ? $code : 'forbidden', $message, array(
                    'status' => 403,
                    'required_caps' => array_values(array_map('strval', $caps)),
                ));
            }

            return true;
        };
    }
}

if (!function_exists('vms_ops_rest_resolve_venue_id')) {
    function vms_ops_rest_resolve_venue_id(WP_REST_Request $request, bool $required = true)
    {
        $venue_id = absint($request->get_param('venue_id'));

        if ($venue_id <= 0 && function_exists('vms_ops_get_settings')) {
            $settings = vms_ops_get_settings();
            $venue_id = isset($settings['default_venue_id']) ? (int) $settings['default_venue_id'] : 0;
        }

        if ($venue_id <= 0 && function_exists('vms_ops_get_preferred_venue')) {
            $preferred_venue = vms_ops_get_preferred_venue();
            if (is_array($preferred_venue)) {
                $venue_id = (int) ($preferred_venue['id'] ?? 0);
            }
        }

        if ($venue_id <= 0 && function_exists('vms_ops_get_active_venues_list')) {
            $venues = vms_ops_get_active_venues_list();
            if (count($venues) === 1) {
                $venue_id = (int) ($venues[0]['id'] ?? 0);
            } elseif ($required && function_exists('vms_ops_get_fallback_venue')) {
                $fallback_venue = vms_ops_get_fallback_venue();
                if (is_array($fallback_venue)) {
                    $venue_id = (int) ($fallback_venue['id'] ?? 0);
                }
            }
        }

        if ($required && $venue_id <= 0) {
            return new WP_Error('invalid_venue', __('Venue is required.', 'vms-ops-console-premium'));
        }

        return max(0, $venue_id);
    }
}

if (!function_exists('vms_ops_rest_site_time_payload')) {
    function vms_ops_rest_site_time_payload(): array
    {
        if (function_exists('vms_ops_time_sync_payload')) {
            return vms_ops_time_sync_payload();
        }

        return array(
            'server_epoch_ms' => (int) vms_ops_now_timestamp() * 1000,
            'server_time_mysql' => vms_ops_now_mysql(),
            'timezone_string' => trim((string) wp_timezone_string()),
            'timezone_label' => trim((string) wp_timezone_string()) ?: __('Site Time', 'vms-ops-console-premium'),
            'timezone_offset_minutes' => 0,
            'date_format' => (string) get_option('date_format'),
            'time_format' => (string) get_option('time_format'),
        );
    }
}

if (!function_exists('vms_ops_rest_system_time')) {
    function vms_ops_rest_system_time(WP_REST_Request $request)
    {
        return vms_ops_rest_ok(vms_ops_rest_site_time_payload());
    }
}

if (!function_exists('vms_ops_rest_id_scan_debug_requested')) {
    function vms_ops_rest_id_scan_debug_requested(WP_REST_Request $request): bool
    {
        return !empty($request->get_param('debug'))
            && (
                function_exists('vms_ops_user_has_any_capability_or_admin')
                    ? vms_ops_user_has_any_capability_or_admin(array(vms_ops_capability_use_pwa()))
                    : (current_user_can(vms_ops_capability_use_pwa()) || current_user_can('manage_options'))
            );
    }
}

if (!function_exists('vms_ops_rest_timing_mark')) {
    function vms_ops_rest_timing_mark(): float
    {
        return microtime(true);
    }
}

if (!function_exists('vms_ops_rest_timing_elapsed_ms')) {
    function vms_ops_rest_timing_elapsed_ms(float $started_at): int
    {
        return max(0, (int) round((microtime(true) - $started_at) * 1000));
    }
}

if (!function_exists('vms_ops_rest_id_scan_debug_payload')) {
    function vms_ops_rest_id_scan_debug_payload(array $timings): array
    {
        $normalized = array();
        foreach ($timings as $key => $value) {
            $normalized[sanitize_key((string) $key)] = max(0, (int) round((float) $value));
        }

        if (!isset($normalized['save_ms'])) {
            $normalized['save_ms'] = max(
                0,
                (int) (
                    (int) ($normalized['renew_ms'] ?? 0)
                    + (int) ($normalized['visit_ms'] ?? 0)
                    + (int) ($normalized['verify_ms'] ?? 0)
                    + (int) ($normalized['alert_ms'] ?? 0)
                    + (int) ($normalized['scan_log_ms'] ?? 0)
                )
            );
        }

        return $normalized;
    }
}

if (!function_exists('vms_ops_rest_id_scan_attach_debug')) {
    function vms_ops_rest_id_scan_attach_debug(array $payload, array $timings, bool $enabled): array
    {
        if (!$enabled) {
            return $payload;
        }

        $payload['debug_timing'] = vms_ops_rest_id_scan_debug_payload($timings);
        return $payload;
    }
}

if (!function_exists('vms_ops_rest_id_scan_not_found_payload_meta')) {
    function vms_ops_rest_id_scan_not_found_payload_meta(array $parsed): array
    {
        return array(
            'member_number' => (string) ($parsed['member_number'] ?? ''),
            'first_name' => (string) ($parsed['first_name'] ?? ''),
            'last_name' => (string) ($parsed['last_name'] ?? ''),
            'date_of_birth' => (string) ($parsed['date_of_birth'] ?? ''),
            'city' => (string) ($parsed['address']['city'] ?? ''),
            'state' => (string) ($parsed['address']['state'] ?? ''),
            'postal_code' => (string) ($parsed['address']['postal_code'] ?? ''),
            'address_line_1_present' => !empty($parsed['address']['address_line_1']) ? 1 : 0,
        );
    }
}

if (!function_exists('vms_ops_rest_id_scan_member_status_payload_meta')) {
    function vms_ops_rest_id_scan_member_status_payload_meta(array $member, string $member_status): array
    {
        return array(
            'member_id' => (int) ($member['id'] ?? 0),
            'member_number' => (string) ($member['member_number'] ?? ''),
            'first_name' => (string) ($member['first_name'] ?? ''),
            'last_name' => (string) ($member['last_name'] ?? ''),
            'date_of_birth' => (string) ($member['date_of_birth'] ?? ''),
            'member_status' => $member_status,
        );
    }
}

if (!function_exists('vms_ops_rest_id_scan_processed_payload_meta')) {
    function vms_ops_rest_id_scan_processed_payload_meta(array $member, string $member_status, array $flags, bool $renewed): array
    {
        return array(
            'member_id' => (int) ($member['id'] ?? 0),
            'member_number' => (string) ($member['member_number'] ?? ''),
            'first_name' => (string) ($member['first_name'] ?? ''),
            'last_name' => (string) ($member['last_name'] ?? ''),
            'date_of_birth' => (string) ($member['date_of_birth'] ?? ''),
            'member_status' => $member_status,
            'vip' => !empty($member['vip']) ? 1 : 0,
            'address_mismatch' => !empty($flags['address_mismatch']) ? 1 : 0,
            'renewed' => $renewed ? 1 : 0,
        );
    }
}

if (!function_exists('vms_ops_rest_cache_ttl')) {
    function vms_ops_rest_cache_ttl(string $bucket): int
    {
        $default = ($bucket === 'ticket_events') ? 20 : 30;
        return max(5, (int) apply_filters('vms_ops_rest_cache_ttl', $default, $bucket));
    }
}

if (!function_exists('vms_ops_rest_cache_key')) {
    function vms_ops_rest_cache_key(string $bucket, array $parts = array()): string
    {
        $version = defined('VMS_OPS_CONSOLE_VERSION') ? (string) VMS_OPS_CONSOLE_VERSION : '0';
        array_unshift($parts, $bucket, $version, (string) get_current_blog_id());
        return 'vms_ops_rest_' . md5(wp_json_encode($parts));
    }
}

if (!function_exists('vms_ops_rest_cache_get')) {
    function vms_ops_rest_cache_get(string $bucket, array $parts = array())
    {
        $cached = get_transient(vms_ops_rest_cache_key($bucket, $parts));
        return is_array($cached) ? $cached : null;
    }
}

if (!function_exists('vms_ops_rest_cache_set')) {
    function vms_ops_rest_cache_set(string $bucket, array $parts, array $payload): void
    {
        set_transient(
            vms_ops_rest_cache_key($bucket, $parts),
            $payload,
            vms_ops_rest_cache_ttl($bucket)
        );
    }
}

if (!function_exists('vms_ops_rest_bootstrap_cached_payload')) {
    function vms_ops_rest_bootstrap_cached_payload(): array
    {
        $cache_parts = array('base');
        $cached = vms_ops_rest_cache_get('bootstrap', $cache_parts);
        if (is_array($cached)) {
            return $cached;
        }

        $payload = array(
            'settings' => vms_ops_get_settings(),
            'venues' => function_exists('vms_ops_get_active_venues_list') ? vms_ops_get_active_venues_list() : array(),
        );

        vms_ops_rest_cache_set('bootstrap', $cache_parts, $payload);
        return $payload;
    }
}

if (!function_exists('vms_ops_rest_bootstrap_cached_presets')) {
    function vms_ops_rest_bootstrap_cached_presets(int $venue_id): array
    {
        $cache_parts = array('presets', $venue_id, 'ops');
        $cached = vms_ops_rest_cache_get('bootstrap', $cache_parts);
        if (is_array($cached)) {
            return $cached;
        }

        $payload = function_exists('vms_ops_alert_staff_feature_enabled') && vms_ops_alert_staff_feature_enabled()
            ? (array) vms_ops_alert_presets_get($venue_id, 'ops')
            : array();

        vms_ops_rest_cache_set('bootstrap', $cache_parts, $payload);
        return $payload;
    }
}

if (!function_exists('vms_ops_rest_cached_ticket_events')) {
    function vms_ops_rest_cached_ticket_events(int $venue_id, int $limit): array
    {
        $cache_parts = array($venue_id, $limit);
        $cached = vms_ops_rest_cache_get('ticket_events', $cache_parts);
        if (is_array($cached)) {
            return $cached;
        }

        $payload = vms_ops_ticket_get_active_events($venue_id, $limit);
        vms_ops_rest_cache_set('ticket_events', $cache_parts, $payload);
        return $payload;
    }
}

if (!function_exists('vms_ops_rest_bootstrap')) {
    function vms_ops_rest_bootstrap(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, false);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $bootstrap = vms_ops_rest_bootstrap_cached_payload();
        $settings = is_array($bootstrap['settings'] ?? null) ? $bootstrap['settings'] : array();
        $venues = is_array($bootstrap['venues'] ?? null) ? $bootstrap['venues'] : array();
        $default_venue_id = isset($settings['default_venue_id']) ? (int) $settings['default_venue_id'] : 0;

        // Only published venues belong in the runtime selector payload.
        if ($default_venue_id > 0) {
            $default_candidates = function_exists('vms_ops_venues_from_ids')
                ? vms_ops_venues_from_ids(array($default_venue_id), function_exists('vms_ops_active_venue_statuses') ? vms_ops_active_venue_statuses() : array('publish'))
                : array();
            if (!empty($default_candidates)) {
                $default_row = $default_candidates[0];
                $default_row_id = (int) ($default_row['id'] ?? 0);
                $has_default = false;
                foreach ((array) $venues as $venue_row) {
                    $row_id = (int) ($venue_row['id'] ?? 0);
                    if ($row_id === $default_row_id) {
                        $has_default = true;
                        break;
                    }
                }
                if (!$has_default) {
                    $venues[] = $default_row;
                }
            }
        }

        // If a requested venue is no longer in the payload, clear it before fallback selection.
        if ((int) $venue_id > 0) {
            $has_requested = false;
            foreach ((array) $venues as $venue_row) {
                $row_id = (int) ($venue_row['id'] ?? 0);
                if ($row_id === (int) $venue_id) {
                    $has_requested = true;
                    break;
                }
            }
            if (!$has_requested) {
                $venue_id = 0;
            }
        }

        // QoL: if there is only one active venue, treat it as selected.
        if ((int) $venue_id <= 0 && count($venues) === 1) {
            $venue_id = (int) ($venues[0]['id'] ?? 0);
        }

        // Secondary fallback: default venue when available in payload.
        if ((int) $venue_id <= 0 && $default_venue_id > 0) {
            foreach ((array) $venues as $venue_row) {
                $row_id = (int) ($venue_row['id'] ?? 0);
                if ($row_id === $default_venue_id) {
                    $venue_id = $default_venue_id;
                    break;
                }
            }
        }

        return vms_ops_rest_ok(array_merge(vms_ops_rest_site_time_payload(), array(
            'server_time' => vms_ops_now_mysql(),
            'today' => vms_ops_today_ymd(),
            'settings' => $settings,
            'venue_id' => $venue_id,
            'venues' => $venues,
            'presets' => vms_ops_rest_bootstrap_cached_presets((int) $venue_id),
        )));
    }
}

if (!function_exists('vms_ops_rest_ticket_events')) {
    function vms_ops_rest_ticket_events(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, false);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $limit = max(1, min(100, absint($request->get_param('limit')) ?: 50));
        $events = vms_ops_rest_cached_ticket_events((int) $venue_id, $limit);

        return vms_ops_rest_ok(array(
            'items' => $events,
        ));
    }
}

if (!function_exists('vms_ops_rest_ticket_attendees')) {
    function vms_ops_rest_ticket_attendees(WP_REST_Request $request)
    {
        $event_id = absint($request->get_param('event_id'));
        if ($event_id <= 0) {
            return vms_ops_rest_error('invalid_event', __('Event is required.', 'vms-ops-console-premium'), 400);
        }

        $event = vms_ops_ticket_get_event($event_id, '');
        if (!is_array($event)) {
            return vms_ops_rest_error('invalid_event', __('Event is not available for scanning.', 'vms-ops-console-premium'), 404);
        }

        $attendees = vms_ops_ticket_get_event_attendees($event_id, (string) ($event['source'] ?? ''));

        return vms_ops_rest_ok(array(
            'event' => $event,
            'items' => $attendees,
            'count' => count($attendees),
            'cache_updated_at' => vms_ops_now_mysql(),
        ));
    }
}

if (!function_exists('vms_ops_rest_ticket_checkin')) {
    function vms_ops_rest_ticket_checkin(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $event_id = absint($request->get_param('event_id'));
        $scan_reference = (string) $request->get_param('scan_reference');
        $event_source = sanitize_key((string) $request->get_param('event_source'));

        $qty = absint($request->get_param('qty'));
        if ($qty <= 0) {
            $qty = 1;
        }

        $result = vms_ops_ticket_checkin((int) $venue_id, $event_id, $scan_reference, $event_source, $qty);
        if (is_wp_error($result)) {
            return vms_ops_rest_error_from_wp_error($result);
        }

        return vms_ops_rest_ok($result);
    }
}

if (!function_exists('vms_ops_rest_id_scan')) {
    function vms_ops_rest_id_scan(WP_REST_Request $request)
    {
        $debug_timing_enabled = vms_ops_rest_id_scan_debug_requested($request);
        $timings = array(
            'total_ms' => 0,
            'parse_ms' => 0,
            'lookup_ms' => 0,
            'renew_ms' => 0,
            'visit_ms' => 0,
            'verify_ms' => 0,
            'alert_ms' => 0,
            'scan_log_ms' => 0,
        );
        $total_started_at = vms_ops_rest_timing_mark();

        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $payload = (string) $request->get_param('payload');
        $parse_started_at = vms_ops_rest_timing_mark();
        $parsed = vms_ops_pc_parse_pdf417_payload($payload);
        $timings['parse_ms'] = vms_ops_rest_timing_elapsed_ms($parse_started_at);
        if (is_wp_error($parsed)) {
            return vms_ops_rest_error_from_wp_error($parsed);
        }

        $lookup_started_at = vms_ops_rest_timing_mark();
        $member = vms_ops_pc_get_member_by_number((int) $venue_id, (string) $parsed['member_number']);
        $timings['lookup_ms'] = vms_ops_rest_timing_elapsed_ms($lookup_started_at);
        if (!is_array($member)) {
            $scan_log_started_at = vms_ops_rest_timing_mark();
            $scan_log = vms_ops_pc_log_scan_event(array(
                'venue_id' => (int) $venue_id,
                'scan_hash' => (string) $parsed['scan_hash'],
                'scan_reference' => (string) $parsed['member_number'],
                'console_type' => 'id',
                'scan_type' => 'pdf417',
                'result_code' => 'member_not_found',
                'result_message' => 'No member record found for scanned ID.',
                'payload_meta' => vms_ops_rest_id_scan_not_found_payload_meta($parsed),
            ));
            $timings['scan_log_ms'] = vms_ops_rest_timing_elapsed_ms($scan_log_started_at);
            if (is_wp_error($scan_log)) {
                return vms_ops_rest_error_from_wp_error($scan_log);
            }

            $timings['total_ms'] = vms_ops_rest_timing_elapsed_ms($total_started_at);
            return vms_ops_rest_ok(vms_ops_rest_id_scan_attach_debug(array(
                'member_found' => 0,
                'manual_creation_required' => 1,
                'prefill' => array(
                    'member_number' => (string) $parsed['member_number'],
                    'first_name' => (string) $parsed['first_name'],
                    'last_name' => (string) $parsed['last_name'],
                    'date_of_birth' => (string) $parsed['date_of_birth'],
                    'address_line_1' => (string) ($parsed['address']['address_line_1'] ?? ''),
                    'city' => (string) ($parsed['address']['city'] ?? ''),
                    'state' => (string) ($parsed['address']['state'] ?? ''),
                    'postal_code' => (string) ($parsed['address']['postal_code'] ?? ''),
                ),
                'flags' => array(
                    'address_mismatch' => 0,
                    'birthday_window' => 0,
                    'vip' => 0,
                    'anniversary_lock' => 0,
                ),
            ), $timings, $debug_timing_enabled));
        }

        $member_id = (int) ($member['id'] ?? 0);
        $effective_status = vms_ops_pc_member_effective_status($member);
        $flags = vms_ops_pc_member_console_flags($member, (int) $venue_id);
        $flags['address_mismatch'] = vms_ops_pc_address_mismatch($member, $parsed) ? 1 : 0;

        if ($effective_status === 'banned') {
            $scan_log_started_at = vms_ops_rest_timing_mark();
            $scan_log = vms_ops_pc_log_scan_event(array(
                'venue_id' => (int) $venue_id,
                'member_id' => $member_id,
                'scan_hash' => (string) $parsed['scan_hash'],
                'scan_reference' => (string) $parsed['member_number'],
                'console_type' => 'id',
                'scan_type' => 'pdf417',
                'result_code' => 'banned',
                'result_message' => 'Banned member attempted entry.',
                'payload_meta' => vms_ops_rest_id_scan_member_status_payload_meta($member, $effective_status),
            ));
            $timings['scan_log_ms'] = vms_ops_rest_timing_elapsed_ms($scan_log_started_at);
            if (is_wp_error($scan_log)) {
                return vms_ops_rest_error_from_wp_error($scan_log);
            }

            $alert_started_at = vms_ops_rest_timing_mark();
            $alert_result = vms_ops_alert_send(array(
                'venue_id' => (int) $venue_id,
                'console_type' => 'id',
                'preset_key' => 'banned_scan',
                'message' => sprintf(
                    __('Banned member attempted entry: %1$s %2$s (%3$s)', 'vms-ops-console-premium'),
                    (string) ($member['first_name'] ?? ''),
                    (string) ($member['last_name'] ?? ''),
                    (string) ($member['member_number'] ?? '')
                ),
                'urgency' => 'critical',
            ));
            $timings['alert_ms'] = vms_ops_rest_timing_elapsed_ms($alert_started_at);

            if (is_wp_error($alert_result)) {
                return vms_ops_rest_error_from_wp_error($alert_result);
            }

            $timings['total_ms'] = vms_ops_rest_timing_elapsed_ms($total_started_at);
            return vms_ops_rest_ok(vms_ops_rest_id_scan_attach_debug(array(
                'member_found' => 1,
                'member' => vms_ops_pc_prepare_member_for_response($member, vms_ops_user_has_any_capability_or_admin(array(vms_ops_capability_manage_members_admin()))),
                'flags' => $flags,
                'banned_screen' => array(
                    'locked' => 1,
                    'member_id' => $member_id,
                ),
                'alert' => $alert_result,
            ), $timings, $debug_timing_enabled));
        }

        if ($effective_status === 'suspended') {
            $scan_log_started_at = vms_ops_rest_timing_mark();
            $scan_log = vms_ops_pc_log_scan_event(array(
                'venue_id' => (int) $venue_id,
                'member_id' => $member_id,
                'scan_hash' => (string) $parsed['scan_hash'],
                'scan_reference' => (string) $parsed['member_number'],
                'console_type' => 'id',
                'scan_type' => 'pdf417',
                'result_code' => 'suspended',
                'result_message' => 'Suspended member scan blocked.',
                'payload_meta' => vms_ops_rest_id_scan_member_status_payload_meta($member, $effective_status),
            ));
            $timings['scan_log_ms'] = vms_ops_rest_timing_elapsed_ms($scan_log_started_at);
            if (is_wp_error($scan_log)) {
                return vms_ops_rest_error_from_wp_error($scan_log);
            }

            $timings['total_ms'] = vms_ops_rest_timing_elapsed_ms($total_started_at);
            return vms_ops_rest_ok(vms_ops_rest_id_scan_attach_debug(array(
                'member_found' => 1,
                'member' => vms_ops_pc_prepare_member_for_response($member, vms_ops_user_has_any_capability_or_admin(array(vms_ops_capability_manage_members_admin()))),
                'flags' => $flags,
                'suspended_screen' => array(
                    'warning' => 1,
                ),
            ), $timings, $debug_timing_enabled));
        }

        $renewed = false;
        if ($effective_status === 'expired' && !empty($request->get_param('auto_renew')) && vms_ops_user_has_any_capability_or_admin(array(vms_ops_capability_manage_members_lite(), vms_ops_capability_manage_members_admin()))) {
            $renew_started_at = vms_ops_rest_timing_mark();
            $renewal = vms_ops_pc_renew_member($member_id, false);
            $timings['renew_ms'] = vms_ops_rest_timing_elapsed_ms($renew_started_at);
            if (is_wp_error($renewal)) {
                return vms_ops_rest_error_from_wp_error($renewal);
            }
            $member = $renewal;
            $flags = vms_ops_pc_member_console_flags($member, (int) $venue_id);
            $flags['address_mismatch'] = vms_ops_pc_address_mismatch($member, $parsed) ? 1 : 0;
            $renewed = true;
        }

        $visit = null;
        if (vms_ops_pc_member_effective_status($member) === 'active') {
            $visit_started_at = vms_ops_rest_timing_mark();
            $visit = vms_ops_pc_record_visit($member_id, (int) $venue_id, 'id_scan', 'ID scan check-in');
            $timings['visit_ms'] = vms_ops_rest_timing_elapsed_ms($visit_started_at);
            if (is_wp_error($visit)) {
                return vms_ops_rest_error_from_wp_error($visit);
            }
        }

        if (function_exists('vms_ops_pc_lookup_mark_age_verified')) {
            $verify_started_at = vms_ops_rest_timing_mark();
            $verified_member = vms_ops_pc_lookup_mark_age_verified($member_id);
            $timings['verify_ms'] = vms_ops_rest_timing_elapsed_ms($verify_started_at);
            if (is_wp_error($verified_member)) {
                return vms_ops_rest_error_from_wp_error($verified_member);
            }
            if (is_array($verified_member)) {
                $member = $verified_member;
            }
        }

        $scan_log_started_at = vms_ops_rest_timing_mark();
        $scan_log = vms_ops_pc_log_scan_event(array(
            'venue_id' => (int) $venue_id,
            'member_id' => $member_id,
            'scan_hash' => (string) $parsed['scan_hash'],
            'scan_reference' => (string) $parsed['member_number'],
            'console_type' => 'id',
            'scan_type' => 'pdf417',
            'result_code' => 'processed',
            'result_message' => 'ID scan processed.',
            'payload_meta' => vms_ops_rest_id_scan_processed_payload_meta(
                $member,
                vms_ops_pc_member_effective_status($member),
                $flags,
                $renewed
            ),
        ));
        $timings['scan_log_ms'] = vms_ops_rest_timing_elapsed_ms($scan_log_started_at);
        if (is_wp_error($scan_log)) {
            return vms_ops_rest_error_from_wp_error($scan_log);
        }

        $timings['total_ms'] = vms_ops_rest_timing_elapsed_ms($total_started_at);
        return vms_ops_rest_ok(vms_ops_rest_id_scan_attach_debug(array(
            'member_found' => 1,
                'member' => vms_ops_pc_prepare_member_for_response($member, vms_ops_user_has_any_capability_or_admin(array(vms_ops_capability_manage_members_admin()))),
            'flags' => $flags,
            'visit' => $visit,
            'renewed' => $renewed ? 1 : 0,
        ), $timings, $debug_timing_enabled));
    }
}

if (!function_exists('vms_ops_rest_manual_member_create')) {
    function vms_ops_rest_manual_member_create(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $can_manage_members = function_exists('vms_ops_user_has_any_capability_or_admin')
            ? vms_ops_user_has_any_capability_or_admin(array(
                vms_ops_capability_manage_members_lite(),
                vms_ops_capability_manage_members_admin(),
            ))
            : (
                current_user_can('manage_options')
                || current_user_can(vms_ops_capability_manage_members_lite())
                || current_user_can(vms_ops_capability_manage_members_admin())
            );
        $scan_only_create = !$can_manage_members && current_user_can(vms_ops_capability_scan_ids());

        $profile_photo_id = 0;
        $photo_consent = !empty($request->get_param('photo_consent')) ? 1 : 0;
        $file_params = method_exists($request, 'get_file_params') ? (array) $request->get_file_params() : array();
        $profile_photo_file = isset($file_params['profile_photo']) && is_array($file_params['profile_photo'])
            ? $file_params['profile_photo']
            : null;

        if ($scan_only_create) {
            if (is_array($profile_photo_file) && !empty($profile_photo_file['tmp_name'])) {
                return vms_ops_rest_error('manual_member_permission_required', __('Manual member form requires member manager access.', 'vms-ops-console-premium'), 403);
            }

            $disallowed_fields = array(
                'phone_number',
                'email_address',
                'notes',
                'vip',
                'lookup_caution_flag',
                'lookup_caution_note',
                'photo_consent',
            );
            foreach ($disallowed_fields as $field_name) {
                $value = $request->get_param($field_name);
                if (is_scalar($value) && trim((string) $value) !== '' && trim((string) $value) !== '0') {
                    return vms_ops_rest_error('manual_member_permission_required', __('Manual member form requires member manager access.', 'vms-ops-console-premium'), 403);
                }
                if (!is_scalar($value) && !empty($value)) {
                    return vms_ops_rest_error('manual_member_permission_required', __('Manual member form requires member manager access.', 'vms-ops-console-premium'), 403);
                }
            }
        }

        if (is_array($profile_photo_file) && !empty($profile_photo_file['tmp_name'])) {
            $settings = function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array();
            if (
                !function_exists('vms_ops_member_lookup_profile_photo_upload_allowed_for_user')
                || !vms_ops_member_lookup_profile_photo_upload_allowed_for_user($settings)
            ) {
                $error_code = function_exists('vms_ops_member_lookup_profile_photo_upload_denied_code')
                    ? vms_ops_member_lookup_profile_photo_upload_denied_code($settings)
                    : 'profile_photo_disabled';
                $error_message = function_exists('vms_ops_member_lookup_profile_photo_upload_denied_message')
                    ? vms_ops_member_lookup_profile_photo_upload_denied_message($settings)
                    : __('Profile photo uploads are disabled in Ops settings.', 'vms-ops-console-premium');
                $status = $error_code === 'profile_photo_manager_only' ? 403 : 400;
                return vms_ops_rest_error($error_code, $error_message, $status);
            }
            if (!$photo_consent) {
                return vms_ops_rest_error('photo_consent_required', __('Member consent is required before storing an optional profile photo.', 'vms-ops-console-premium'), 400);
            }

            $uploaded_photo = function_exists('vms_ops_pc_lookup_upload_profile_photo')
                ? vms_ops_pc_lookup_upload_profile_photo($profile_photo_file)
                : new WP_Error('profile_photo_unavailable', __('Profile photo uploads are unavailable.', 'vms-ops-console-premium'));
            if (is_wp_error($uploaded_photo)) {
                return vms_ops_rest_error_from_wp_error($uploaded_photo);
            }
            $profile_photo_id = (int) $uploaded_photo;
        }

        $member_data = array(
            'venue_id' => (int) $venue_id,
            'member_number' => (string) $request->get_param('member_number'),
            'first_name' => (string) $request->get_param('first_name'),
            'last_name' => (string) $request->get_param('last_name'),
            'date_of_birth' => (string) $request->get_param('date_of_birth'),
            'phone_number' => (string) $request->get_param('phone_number'),
            'email_address' => (string) $request->get_param('email_address'),
            'address_line_1' => (string) $request->get_param('address_line_1'),
            'address_line_2' => (string) $request->get_param('address_line_2'),
            'city' => (string) $request->get_param('city'),
            'state' => (string) $request->get_param('state'),
            'postal_code' => (string) $request->get_param('postal_code'),
            'notes' => (string) $request->get_param('notes'),
            'vip' => !empty($request->get_param('vip')) ? 1 : 0,
            'lookup_caution_flag' => !empty($request->get_param('lookup_caution_flag')) ? 1 : 0,
            'lookup_caution_note' => (string) $request->get_param('lookup_caution_note'),
            'age_verified' => !empty($request->get_param('age_verified')) ? 1 : 0,
            'age_verified_at' => (string) $request->get_param('age_verified_at'),
            'age_verified_by' => get_current_user_id(),
            'profile_photo_id' => $profile_photo_id,
            'photo_consent' => $photo_consent,
        );

        if ($scan_only_create) {
            $scan_payload = (string) $request->get_param('scan_payload');
            $parsed = vms_ops_pc_parse_pdf417_payload($scan_payload);
            if (is_wp_error($parsed)) {
                return vms_ops_rest_error_from_wp_error($parsed);
            }

            $member_data = array_merge($member_data, array(
                'member_number' => (string) ($parsed['member_number'] ?? ''),
                'first_name' => (string) ($parsed['first_name'] ?? ''),
                'last_name' => (string) ($parsed['last_name'] ?? ''),
                'date_of_birth' => (string) ($parsed['date_of_birth'] ?? ''),
                'phone_number' => '',
                'email_address' => '',
                'address_line_1' => (string) ($parsed['address']['address_line_1'] ?? ''),
                'address_line_2' => '',
                'city' => (string) ($parsed['address']['city'] ?? ''),
                'state' => (string) ($parsed['address']['state'] ?? ''),
                'postal_code' => (string) ($parsed['address']['postal_code'] ?? ''),
                'notes' => '',
                'vip' => 0,
                'lookup_caution_flag' => 0,
                'lookup_caution_note' => '',
                'age_verified' => 1,
                'age_verified_at' => vms_ops_now_mysql(),
                'profile_photo_id' => 0,
                'photo_consent' => 0,
            ));
        }

        $member = vms_ops_pc_create_member($member_data);

        if (is_wp_error($member)) {
            if ($profile_photo_id > 0) {
                wp_delete_attachment($profile_photo_id, true);
            }
            return vms_ops_rest_error_from_wp_error($member);
        }

        return vms_ops_rest_ok(array(
            'member' => vms_ops_pc_prepare_member_for_response($member, true),
        ), 201);
    }
}

if (!function_exists('vms_ops_rest_member_lookup_disabled')) {
    function vms_ops_rest_member_lookup_disabled(): bool
    {
        $settings = function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array();
        return !function_exists('vms_ops_member_lookup_is_enabled') || !vms_ops_member_lookup_is_enabled($settings);
    }
}

if (!function_exists('vms_ops_rest_member_lookup_require_enabled')) {
    function vms_ops_rest_member_lookup_require_enabled()
    {
        if (!vms_ops_rest_member_lookup_disabled()) {
            return true;
        }

        return new WP_Error(
            'member_lookup_disabled',
            __('Verified Member Lookup is disabled in VMS Ops Console settings.', 'vms-ops-console-premium'),
            array('status' => 403)
        );
    }
}

if (!function_exists('vms_ops_rest_member_lookup_find_member')) {
    function vms_ops_rest_member_lookup_find_member(int $member_id, int $venue_id)
    {
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member) || (int) ($member['venue_id'] ?? 0) !== $venue_id) {
            return new WP_Error('member_not_found', __('Member not found for this venue.', 'vms-ops-console-premium'), array('status' => 404));
        }

        return $member;
    }
}

if (!function_exists('vms_ops_rest_member_lookup_search')) {
    function vms_ops_rest_member_lookup_search(WP_REST_Request $request)
    {
        $enabled = vms_ops_rest_member_lookup_require_enabled();
        if (is_wp_error($enabled)) {
            return vms_ops_rest_error_from_wp_error($enabled);
        }

        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $query = sanitize_text_field((string) $request->get_param('q'));
        $limit = absint($request->get_param('limit')) ?: 20;
        if (trim($query) === '') {
            return vms_ops_rest_error('lookup_query_required', __('Enter a name, phone, member number, email, or DOB to search.', 'vms-ops-console-premium'), 400);
        }

        $settings = function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array();
        $results = function_exists('vms_ops_pc_lookup_search_members')
            ? vms_ops_pc_lookup_search_members((int) $venue_id, $query, $limit, $settings)
            : array('items' => array(), 'total_matches' => 0, 'truncated' => 0);

        $items = is_array($results['items'] ?? null) ? $results['items'] : array();
        if (empty($items) && function_exists('vms_ops_pc_member_lookup_log')) {
            $logged = vms_ops_pc_member_lookup_log((int) $venue_id, null, 'lookup_no_match', array(
                'search_term' => $query,
                'result_type' => 'lookup_no_match',
            ));
            if (is_wp_error($logged)) {
                return vms_ops_rest_error_from_wp_error($logged);
            }
        }

        return vms_ops_rest_ok(array(
            'query' => $query,
            'count' => count($items),
            'total_matches' => (int) ($results['total_matches'] ?? count($items)),
            'truncated' => !empty($results['truncated']) ? 1 : 0,
            'policy_text' => function_exists('vms_ops_member_lookup_policy_text')
                ? vms_ops_member_lookup_policy_text()
                : '',
            'items' => $items,
        ));
    }
}

if (!function_exists('vms_ops_rest_member_lookup_detail')) {
    function vms_ops_rest_member_lookup_detail(WP_REST_Request $request)
    {
        $enabled = vms_ops_rest_member_lookup_require_enabled();
        if (is_wp_error($enabled)) {
            return vms_ops_rest_error_from_wp_error($enabled);
        }

        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $member_id = absint($request->get_param('id'));
        $member = vms_ops_rest_member_lookup_find_member($member_id, (int) $venue_id);
        if (is_wp_error($member)) {
            return vms_ops_rest_error_from_wp_error($member);
        }

        $settings = function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array();
        $item = function_exists('vms_ops_pc_lookup_member_detail')
            ? vms_ops_pc_lookup_member_detail($member, (int) $venue_id, $settings)
            : array();

        if (vms_ops_user_has_any_capability_or_admin(array(vms_ops_capability_manage_members_admin()))) {
            $item['vip'] = !empty($member['vip']) ? 1 : 0;
            if (function_exists('vms_ops_pc_unpack_address')) {
                $address = vms_ops_pc_unpack_address((string) ($member['address_ciphertext'] ?? ''));
                $item['address'] = is_wp_error($address) ? array() : $address;
            }
        }

        if (function_exists('vms_ops_pc_member_lookup_log')) {
            $logged = vms_ops_pc_member_lookup_log((int) $venue_id, $member_id, 'lookup_opened', array(
                'search_term' => (string) $request->get_param('search_term'),
                'matched_member_id' => $member_id,
                'matched_member_name' => function_exists('vms_ops_pc_lookup_member_full_name')
                    ? vms_ops_pc_lookup_member_full_name($member)
                    : trim((string) ($member['first_name'] ?? '') . ' ' . (string) ($member['last_name'] ?? '')),
                'membership_status' => (string) ($item['status'] ?? ($member['status'] ?? 'active')),
                'result_type' => 'lookup_opened',
            ));
            if (is_wp_error($logged)) {
                return vms_ops_rest_error_from_wp_error($logged);
            }
        }

        if (function_exists('vms_ops_pc_lookup_mark_last_lookup')) {
            $stamped = vms_ops_pc_lookup_mark_last_lookup($member_id);
            if (is_wp_error($stamped)) {
                return vms_ops_rest_error_from_wp_error($stamped);
            }
        }

        return vms_ops_rest_ok(array(
            'item' => $item,
        ));
    }
}

if (!function_exists('vms_ops_rest_member_lookup_dob_input_shape')) {
    function vms_ops_rest_member_lookup_dob_input_shape(string $value): string
    {
        $raw = trim($value);
        if ($raw === '') {
            return 'empty';
        }

        if (preg_match('/^\d{8}$/', $raw) === 1) {
            return 'digits_only';
        }

        if (preg_match('/^\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4}$/', $raw) === 1) {
            return 'delimited';
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw) === 1) {
            return 'iso';
        }

        return 'other';
    }
}

if (!function_exists('vms_ops_rest_member_lookup_presence_context')) {
    function vms_ops_rest_member_lookup_presence_context(int $venue_id, string $device_id = '', string $console_type = 'ops'): array
    {
        $device_id = sanitize_text_field($device_id);
        $context = array(
            'device_id' => $device_id,
            'console_type' => $console_type !== '' ? sanitize_key($console_type) : 'ops',
        );

        if ($venue_id <= 0 || get_current_user_id() <= 0 || $device_id === '' || !function_exists('vms_ops_table_presence')) {
            return $context;
        }

        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . vms_ops_table_presence() . ' WHERE user_id = %d AND venue_id = %d AND device_id = %s AND status = %s ORDER BY id DESC LIMIT 1',
                get_current_user_id(),
                $venue_id,
                $device_id,
                'on_duty'
            ),
            ARRAY_A
        );

        if (!is_array($row)) {
            return $context;
        }

        $context['presence_id'] = (int) ($row['id'] ?? 0);
        $context['presence_status'] = sanitize_key((string) ($row['status'] ?? ''));
        $context['shift_started_at'] = (string) ($row['shift_started_at'] ?? '');
        $context['last_seen_at'] = (string) ($row['last_seen_at'] ?? '');
        $context['console_type'] = sanitize_key((string) ($row['console_type'] ?? $context['console_type'])) ?: $context['console_type'];

        return $context;
    }
}

if (!function_exists('vms_ops_rest_member_lookup_decision')) {
    function vms_ops_rest_member_lookup_decision(WP_REST_Request $request)
    {
        $enabled = vms_ops_rest_member_lookup_require_enabled();
        if (is_wp_error($enabled)) {
            return vms_ops_rest_error_from_wp_error($enabled);
        }

        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $member_id = absint($request->get_param('id'));
        $member = vms_ops_rest_member_lookup_find_member($member_id, (int) $venue_id);
        if (is_wp_error($member)) {
            return vms_ops_rest_error_from_wp_error($member);
        }

        $settings = function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array();
        $detail = function_exists('vms_ops_pc_lookup_member_detail')
            ? vms_ops_pc_lookup_member_detail($member, (int) $venue_id, $settings)
            : array();

        $decision = sanitize_key((string) $request->get_param('decision'));
        $search_term = sanitize_text_field((string) $request->get_param('search_term'));
        $dob_input = sanitize_text_field((string) $request->get_param('dob_input'));
        $confidence_ack = !empty($request->get_param('confidence_ack')) ? 1 : 0;
        $photo_match_confirmed = !empty($request->get_param('photo_match_confirmed')) ? 1 : 0;
        $reason_code = sanitize_key((string) $request->get_param('reason_code'));
        $device_id = sanitize_text_field((string) $request->get_param('device_id'));
        $console_type = sanitize_key((string) $request->get_param('console_type'));
        if ($console_type === '') {
            $console_type = 'ops';
        }
        $event_id = absint($request->get_param('event_id'));
        $status_at_action = (string) ($detail['status'] ?? ($member['status'] ?? 'active'));
        $member_name = function_exists('vms_ops_pc_lookup_member_full_name')
            ? vms_ops_pc_lookup_member_full_name($member)
            : trim((string) ($member['first_name'] ?? '') . ' ' . (string) ($member['last_name'] ?? ''));
        $member_number = trim((string) ($member['member_number'] ?? ''));
        $dob_input_normalized = function_exists('vms_ops_pc_normalize_dob')
            ? vms_ops_pc_normalize_dob($dob_input)
            : trim($dob_input);
        $dob_input_shape = function_exists('vms_ops_rest_member_lookup_dob_input_shape')
            ? vms_ops_rest_member_lookup_dob_input_shape($dob_input)
            : 'other';
        $presence_context = function_exists('vms_ops_rest_member_lookup_presence_context')
            ? vms_ops_rest_member_lookup_presence_context((int) $venue_id, $device_id, $console_type)
            : array(
                'device_id' => $device_id,
                'console_type' => $console_type,
            );
        $recheck_context = array(
            'member_id' => $member_id,
            'member_name' => $member_name,
            'member_number' => $member_number,
        );
        $log_details_base = array(
            'search_term' => $search_term,
            'matched_member_id' => $member_id,
            'matched_member_name' => $member_name,
            'member_number' => $member_number,
            'membership_status' => $status_at_action,
            'operator_user_id' => get_current_user_id(),
            'method' => 'verified_lookup',
            'confidence_required' => !empty($detail['requires_confidence']) ? 1 : 0,
            'confidence_ack' => $confidence_ack,
            'dob_required' => !empty($detail['requires_dob_entry']) ? 1 : 0,
            'dob_input_present' => $dob_input !== '' ? 1 : 0,
            'dob_input_shape' => $dob_input_shape,
            'photo_match_available' => !empty($detail['photo_match_available']) ? 1 : 0,
            'photo_match_confirmed' => $photo_match_confirmed,
            'age_verified_at' => (string) ($detail['age_verified_at'] ?? ''),
            'site_timezone' => function_exists('wp_timezone_string') ? (string) wp_timezone_string() : '',
            'site_time_mysql' => function_exists('vms_ops_now_mysql') ? (string) vms_ops_now_mysql() : '',
            'console_type' => (string) ($presence_context['console_type'] ?? $console_type),
            'device_id' => (string) ($presence_context['device_id'] ?? $device_id),
        );
        if ($event_id > 0) {
            $log_details_base['event_id'] = $event_id;
        }
        if (!empty($presence_context['presence_id'])) {
            $log_details_base['presence_id'] = (int) ($presence_context['presence_id'] ?? 0);
            $log_details_base['presence_status'] = (string) ($presence_context['presence_status'] ?? '');
            $log_details_base['shift_started_at'] = (string) ($presence_context['shift_started_at'] ?? '');
            $log_details_base['last_seen_at'] = (string) ($presence_context['last_seen_at'] ?? '');
        }
        $dob_confirmed = null;
        $photo_match_available = !empty($detail['photo_match_available']);
        $using_photo_match = false;
        $using_dob_confirmation = false;

        if ($decision === 'check_id_now') {
            if (function_exists('vms_ops_pc_member_lookup_log')) {
                $logged = vms_ops_pc_member_lookup_log((int) $venue_id, $member_id, 'redirected_to_id_check', array_merge($log_details_base, array(
                    'result_type' => 'redirected_to_id_check',
                    'reason_code' => $reason_code !== '' ? $reason_code : 'staff_selected_id_check',
                )));
                if (is_wp_error($logged)) {
                    return vms_ops_rest_error_from_wp_error($logged);
                }
            }

            if (function_exists('vms_ops_pc_lookup_mark_last_lookup')) {
                $stamped = vms_ops_pc_lookup_mark_last_lookup($member_id);
                if (is_wp_error($stamped)) {
                    return vms_ops_rest_error_from_wp_error($stamped);
                }
            }

            $message = current_user_can(vms_ops_capability_scan_ids())
                ? __('Switch to the ID Console and recheck the ID now.', 'vms-ops-console-premium')
                : __('Ask a staff member with ID scan access to recheck the ID now.', 'vms-ops-console-premium');

            return vms_ops_rest_ok(array(
                'decision' => 'check_id_now',
                'status' => 'redirected',
                'reason_code' => $reason_code !== '' ? $reason_code : 'staff_selected_id_check',
                'recheck_context' => array_merge($recheck_context, array(
                    'reason_code' => $reason_code !== '' ? $reason_code : 'staff_selected_id_check',
                )),
                'next_action' => 'id_console',
                'message' => $message,
            ));
        }

        if ($decision !== 'serve') {
            return vms_ops_rest_error('invalid_lookup_decision', __('Choose either Serve via Verified Lookup or Check ID Now.', 'vms-ops-console-premium'), 400);
        }

        if (!empty($detail['requires_confidence']) && !$confidence_ack) {
            return vms_ops_rest_error('lookup_confidence_required', __('Confirm that you confidently recognize the member before using Verified Lookup.', 'vms-ops-console-premium'), 400);
        }

        if ($photo_match_available && $photo_match_confirmed) {
            $using_photo_match = true;
        }

        if (!$using_photo_match && (!empty($detail['requires_dob_entry']) || $dob_input !== '')) {
            if ($dob_input === '' || $dob_input_normalized === '') {
                return vms_ops_rest_error('lookup_dob_required', __('Enter 8 digits: MMDDYYYY.', 'vms-ops-console-premium'), 400);
            }

            if (!function_exists('vms_ops_pc_lookup_compare_dob_input') || !vms_ops_pc_lookup_compare_dob_input((string) ($member['date_of_birth'] ?? ''), $dob_input)) {
                if (function_exists('vms_ops_pc_member_lookup_log')) {
                    $logged = vms_ops_pc_member_lookup_log((int) $venue_id, $member_id, 'dob_failed', array_merge($log_details_base, array(
                        'result_type' => 'dob_failed',
                        'reason_code' => 'dob_mismatch',
                        'dob_confirmed' => 0,
                    )));
                    if (is_wp_error($logged)) {
                        return vms_ops_rest_error_from_wp_error($logged);
                    }
                }

                return vms_ops_rest_ok(array(
                    'decision' => 'serve',
                    'status' => 'blocked',
                    'reason_code' => 'dob_mismatch',
                    'recheck_context' => array_merge($recheck_context, array(
                        'reason_code' => 'dob_mismatch',
                    )),
                    'next_action' => 'id_console',
                    'message' => __('DOB did not match this member record. Do not use lookup for service. Check ID now.', 'vms-ops-console-premium'),
                ));
            }
            $using_dob_confirmation = true;
            $dob_confirmed = 1;
        }

        if (!$using_photo_match && !$using_dob_confirmation && $photo_match_available) {
            return vms_ops_rest_error('lookup_photo_match_required', __('Confirm that the stored profile photo matches this member, or enter DOB before using Verified Lookup.', 'vms-ops-console-premium'), 400);
        }

        $blocking_reason = sanitize_key((string) ($detail['blocking_reason'] ?? ''));
        if ($blocking_reason !== '') {
            $action = ($blocking_reason === 'expired_member') ? 'blocked_expired_member' : 'blocked_missing_verification';
            $result_type = $action;
            $message = __('Lookup cannot be used for this member. Check ID now.', 'vms-ops-console-premium');

            if ($blocking_reason === 'expired_member') {
                $message = __('Membership is expired. Do not serve via lookup. Check ID now.', 'vms-ops-console-premium');
            } elseif ($blocking_reason === 'missing_verification' || $blocking_reason === 'stale_verification') {
                $message = __('Prior verification is missing or stale. Recheck ID now.', 'vms-ops-console-premium');
            } elseif ($blocking_reason === 'missing_photo') {
                $message = __('No profile photo is on file and your policy requires an ID recheck. Check ID now.', 'vms-ops-console-premium');
            } elseif ($blocking_reason === 'under_21') {
                $action = 'redirected_to_id_check';
                $result_type = 'redirected_to_id_check';
                $message = __('This member is marked under 21. Do not use lookup for alcohol service.', 'vms-ops-console-premium');
            } elseif ($blocking_reason === 'inactive_member') {
                $action = 'redirected_to_id_check';
                $result_type = 'redirected_to_id_check';
                $message = __('Membership is not active. Check ID now.', 'vms-ops-console-premium');
            } elseif ($blocking_reason === 'missing_dob') {
                $action = 'redirected_to_id_check';
                $result_type = 'redirected_to_id_check';
                $message = __('DOB is missing from the member record. Check ID now.', 'vms-ops-console-premium');
            }

            if (function_exists('vms_ops_pc_member_lookup_log')) {
                $log_details = array_merge($log_details_base, array(
                    'result_type' => $result_type,
                    'reason_code' => $blocking_reason,
                ));
                if ($dob_confirmed !== null) {
                    $log_details['dob_confirmed'] = $dob_confirmed;
                }

                $logged = vms_ops_pc_member_lookup_log((int) $venue_id, $member_id, $action, $log_details);
                if (is_wp_error($logged)) {
                    return vms_ops_rest_error_from_wp_error($logged);
                }
            }

            return vms_ops_rest_ok(array(
                'decision' => 'serve',
                'status' => 'blocked',
                'reason_code' => $blocking_reason,
                'recheck_context' => array_merge($recheck_context, array(
                    'reason_code' => $blocking_reason,
                )),
                'next_action' => 'id_console',
                'message' => $message,
            ));
        }

        $visit_source = $using_photo_match ? 'lookup_photo_match' : 'verified_lookup';
        $served_reason_code = $using_photo_match ? 'verified_lookup_photo_match' : 'verified_lookup';
        $visit = function_exists('vms_ops_pc_record_visit')
            ? vms_ops_pc_record_visit($member_id, (int) $venue_id, $visit_source, $using_photo_match ? 'Verified lookup photo match' : 'Verified lookup')
            : new WP_Error('visit_logging_unavailable', __('Visit logging is unavailable.', 'vms-ops-console-premium'), array('status' => 500));
        if (is_wp_error($visit)) {
            return vms_ops_rest_error_from_wp_error($visit);
        }

        if (function_exists('vms_ops_pc_lookup_mark_last_lookup')) {
            $stamped = vms_ops_pc_lookup_mark_last_lookup($member_id);
            if (is_wp_error($stamped)) {
                return vms_ops_rest_error_from_wp_error($stamped);
            }
        }

        $visit_duplicate = is_array($visit) && !empty($visit['duplicate']);
        $checked_in_at = is_array($visit) ? (string) ($visit['checked_in_at'] ?? '') : '';
        $checked_in_display = $checked_in_at !== '' && function_exists('vms_ops_pc_scan_log_format_datetime')
            ? vms_ops_pc_scan_log_format_datetime($checked_in_at)
            : $checked_in_at;

        if (function_exists('vms_ops_pc_member_lookup_log')) {
            $log_details = array_merge($log_details_base, array(
                'result_type' => $visit_duplicate ? 'verified_lookup_duplicate' : 'served_via_verified_lookup',
                'reason_code' => $visit_duplicate ? 'already_served_today' : $served_reason_code,
                'source' => $served_reason_code,
                'visit_source' => $visit_source,
                'visit_id' => is_array($visit) ? (int) ($visit['visit_id'] ?? 0) : 0,
                'visit_duplicate' => $visit_duplicate ? 1 : 0,
                'visit_date' => is_array($visit) ? (string) ($visit['visit_date'] ?? '') : '',
                'checked_in_at' => $checked_in_at,
                'checked_in_display' => $checked_in_display,
            ));
            if ($using_photo_match) {
                $log_details['dob_input_present'] = 0;
                $log_details['dob_required'] = 0;
                $log_details['dob_bypass_reason'] = 'profile_photo_match';
                $log_details['photo_match_confirmed'] = 1;
            }
            if ($dob_confirmed !== null) {
                $log_details['dob_confirmed'] = $dob_confirmed;
            }

            $logged = vms_ops_pc_member_lookup_log(
                (int) $venue_id,
                $member_id,
                $visit_duplicate ? 'verified_lookup_duplicate' : 'served_via_verified_lookup',
                $log_details
            );
            if (is_wp_error($logged)) {
                return vms_ops_rest_error_from_wp_error($logged);
            }
        }

        return vms_ops_rest_ok(array(
            'decision' => 'serve',
            'status' => $visit_duplicate ? 'duplicate' : 'served',
            'reason_code' => $visit_duplicate ? 'already_served_today' : $served_reason_code,
            'visit' => is_array($visit) ? $visit : array(),
            'next_action' => 'search_next_member',
            'message' => $visit_duplicate
                ? sprintf(
                    __('Already served via Verified Lookup at %s.', 'vms-ops-console-premium'),
                    $checked_in_display !== '' ? $checked_in_display : __('earlier today', 'vms-ops-console-premium')
                )
                : __('Served via Verified Lookup', 'vms-ops-console-premium'),
        ));
    }
}

if (!function_exists('vms_ops_rest_member_renew')) {
    function vms_ops_rest_member_renew(WP_REST_Request $request)
    {
        $member_id = absint($request->get_param('id'));
        $force = !empty($request->get_param('force'));

        $member = vms_ops_pc_renew_member($member_id, $force);
        if (is_wp_error($member)) {
            return vms_ops_rest_error_from_wp_error($member);
        }

        return vms_ops_rest_ok(array(
            'member' => vms_ops_pc_prepare_member_for_response($member, vms_ops_user_has_any_capability_or_admin(array(vms_ops_capability_manage_members_admin()))),
        ));
    }
}

if (!function_exists('vms_ops_rest_member_status')) {
    function vms_ops_rest_member_status(WP_REST_Request $request)
    {
        $member_id = absint($request->get_param('id'));
        $status = (string) $request->get_param('status');
        $reason = (string) $request->get_param('reason');

        $member = vms_ops_pc_update_status($member_id, $status, $reason);
        if (is_wp_error($member)) {
            return vms_ops_rest_error_from_wp_error($member);
        }

        if (sanitize_key($status) === 'banned') {
            $alert_result = vms_ops_alert_send(array(
                'venue_id' => (int) ($member['venue_id'] ?? 0),
                'console_type' => 'id',
                'preset_key' => 'banned_scan',
                'message' => sprintf(
                    __('Member banned: %1$s %2$s (%3$s)', 'vms-ops-console-premium'),
                    (string) ($member['first_name'] ?? ''),
                    (string) ($member['last_name'] ?? ''),
                    (string) ($member['member_number'] ?? '')
                ),
                'urgency' => 'critical',
            ));
            if (is_wp_error($alert_result)) {
                return vms_ops_rest_error_from_wp_error($alert_result);
            }
        }

        return vms_ops_rest_ok(array(
            'member' => vms_ops_pc_prepare_member_for_response($member, true),
        ));
    }
}

if (!function_exists('vms_ops_rest_member_vip')) {
    function vms_ops_rest_member_vip(WP_REST_Request $request)
    {
        $member_id = absint($request->get_param('id'));
        $vip = !empty($request->get_param('vip'));

        $member = vms_ops_pc_update_vip($member_id, $vip);
        if (is_wp_error($member)) {
            return vms_ops_rest_error_from_wp_error($member);
        }

        return vms_ops_rest_ok(array(
            'member' => vms_ops_pc_prepare_member_for_response($member, true),
        ));
    }
}

if (!function_exists('vms_ops_rest_member_address')) {
    function vms_ops_rest_member_address(WP_REST_Request $request)
    {
        $member_id = absint($request->get_param('id'));

        $member = vms_ops_pc_update_member_address($member_id, array(
            'address_line_1' => (string) $request->get_param('address_line_1'),
            'address_line_2' => (string) $request->get_param('address_line_2'),
            'city' => (string) $request->get_param('city'),
            'state' => (string) $request->get_param('state'),
            'postal_code' => (string) $request->get_param('postal_code'),
        ));

        if (is_wp_error($member)) {
            return vms_ops_rest_error_from_wp_error($member);
        }

        return vms_ops_rest_ok(array(
            'member' => vms_ops_pc_prepare_member_for_response($member, true),
        ));
    }
}

if (!function_exists('vms_ops_rest_member_photo_update')) {
    function vms_ops_rest_member_photo_update(WP_REST_Request $request)
    {
        $member_id = absint($request->get_param('id'));
        if ($member_id <= 0) {
            return vms_ops_rest_error('invalid_member', __('Member is required.', 'vms-ops-console-premium'), 400);
        }

        $settings = function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array();
        if (
            !function_exists('vms_ops_member_lookup_profile_photo_upload_allowed_for_user')
            || !vms_ops_member_lookup_profile_photo_upload_allowed_for_user($settings)
        ) {
            $error_code = function_exists('vms_ops_member_lookup_profile_photo_upload_denied_code')
                ? vms_ops_member_lookup_profile_photo_upload_denied_code($settings)
                : 'profile_photo_disabled';
            $error_message = function_exists('vms_ops_member_lookup_profile_photo_upload_denied_message')
                ? vms_ops_member_lookup_profile_photo_upload_denied_message($settings)
                : __('Profile photo uploads are disabled in Ops settings.', 'vms-ops-console-premium');
            $status = $error_code === 'profile_photo_manager_only' ? 403 : 400;
            return vms_ops_rest_error($error_code, $error_message, $status);
        }

        $file_params = method_exists($request, 'get_file_params') ? (array) $request->get_file_params() : array();
        $profile_photo_file = isset($file_params['profile_photo']) && is_array($file_params['profile_photo'])
            ? $file_params['profile_photo']
            : null;
        if (!is_array($profile_photo_file) || empty($profile_photo_file['tmp_name'])) {
            return vms_ops_rest_error('invalid_profile_photo', __('A valid profile photo upload is required.', 'vms-ops-console-premium'), 400);
        }

        $photo_consent = !empty($request->get_param('photo_consent'));
        if (!$photo_consent) {
            return vms_ops_rest_error('photo_consent_required', __('Member consent is required before storing an optional profile photo.', 'vms-ops-console-premium'), 400);
        }

        $uploaded_photo = function_exists('vms_ops_pc_lookup_upload_profile_photo')
            ? vms_ops_pc_lookup_upload_profile_photo($profile_photo_file)
            : new WP_Error('profile_photo_unavailable', __('Profile photo uploads are unavailable.', 'vms-ops-console-premium'));
        if (is_wp_error($uploaded_photo)) {
            return vms_ops_rest_error_from_wp_error($uploaded_photo);
        }

        $member = vms_ops_pc_update_member_profile_photo($member_id, (int) $uploaded_photo, true);
        if (is_wp_error($member)) {
            wp_delete_attachment((int) $uploaded_photo, true);
            return vms_ops_rest_error_from_wp_error($member);
        }

        $item = function_exists('vms_ops_pc_lookup_member_detail')
            ? vms_ops_pc_lookup_member_detail($member, (int) ($member['venue_id'] ?? 0), $settings)
            : array();

        return vms_ops_rest_ok(array(
            'member' => vms_ops_pc_prepare_member_for_response($member, true),
            'item' => $item,
        ));
    }
}

if (!function_exists('vms_ops_rest_member_photo_remove')) {
    function vms_ops_rest_member_photo_remove(WP_REST_Request $request)
    {
        $member_id = absint($request->get_param('id'));
        if ($member_id <= 0) {
            return vms_ops_rest_error('invalid_member', __('Member is required.', 'vms-ops-console-premium'), 400);
        }

        $settings = function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array();
        $member = vms_ops_pc_remove_member_profile_photo($member_id);
        if (is_wp_error($member)) {
            return vms_ops_rest_error_from_wp_error($member);
        }

        $item = function_exists('vms_ops_pc_lookup_member_detail')
            ? vms_ops_pc_lookup_member_detail($member, (int) ($member['venue_id'] ?? 0), $settings)
            : array();

        return vms_ops_rest_ok(array(
            'member' => vms_ops_pc_prepare_member_for_response($member, true),
            'item' => $item,
        ));
    }
}

if (!function_exists('vms_ops_rest_member_search')) {
    function vms_ops_rest_member_search(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $query = sanitize_text_field((string) $request->get_param('q'));
        $limit = absint($request->get_param('limit')) ?: 20;

        $rows = vms_ops_pc_search_members((int) $venue_id, $query, $limit);
        $items = array();
        foreach ($rows as $row) {
            $items[] = vms_ops_pc_prepare_member_for_response($row, vms_ops_user_has_any_capability_or_admin(array(vms_ops_capability_manage_members_admin())));
        }

        return vms_ops_rest_ok(array(
            'items' => $items,
        ));
    }
}

if (!function_exists('vms_ops_rest_member_delete')) {
    function vms_ops_rest_member_delete(WP_REST_Request $request)
    {
        $member_id = absint($request->get_param('id'));
        if ($member_id <= 0) {
            return vms_ops_rest_error('invalid_member', __('Member is required.', 'vms-ops-console-premium'), 400);
        }

        $deleted = vms_ops_pc_delete_member($member_id);
        if (is_wp_error($deleted)) {
            return vms_ops_rest_error_from_wp_error($deleted);
        }

        return vms_ops_rest_ok(array(
            'deleted' => 1,
            'member_id' => (int) ($deleted['member_id'] ?? $member_id),
            'member_number' => (string) ($deleted['member_number'] ?? ''),
            'member_name' => (string) ($deleted['member_name'] ?? ''),
        ));
    }
}

if (!function_exists('vms_ops_rest_banned_clear')) {
    function vms_ops_rest_banned_clear(WP_REST_Request $request)
    {
        $member_id = absint($request->get_param('member_id'));
        if ($member_id <= 0) {
            return vms_ops_rest_error('invalid_member', __('Member is required.', 'vms-ops-console-premium'), 400);
        }

        $logged = vms_ops_pc_log_banned_screen_clear($member_id);
        if (is_wp_error($logged)) {
            return vms_ops_rest_error_from_wp_error($logged);
        }

        return vms_ops_rest_ok(array(
            'cleared' => 1,
            'member_id' => $member_id,
        ));
    }
}

if (!function_exists('vms_ops_rest_alert_presets')) {
    function vms_ops_rest_alert_presets(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, false);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }
        $console = sanitize_key((string) $request->get_param('console_type'));
        if ($console === '') {
            $console = 'ops';
        }

        return vms_ops_rest_ok(array(
            'items' => vms_ops_alert_presets_get((int) $venue_id, $console),
        ));
    }
}

if (!function_exists('vms_ops_rest_alert_send')) {
    function vms_ops_rest_alert_send(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $result = vms_ops_alert_send(array(
            'venue_id' => (int) $venue_id,
            'console_type' => (string) $request->get_param('console_type'),
            'preset_key' => (string) $request->get_param('preset_key'),
            'message' => (string) $request->get_param('message'),
            'urgency' => (string) $request->get_param('urgency'),
            'audience' => (string) $request->get_param('audience'),
        ));

        if (is_wp_error($result)) {
            return vms_ops_rest_error_from_wp_error($result);
        }

        return vms_ops_rest_ok($result, 201);
    }
}

if (!function_exists('vms_ops_rest_alert_inbox')) {
    function vms_ops_rest_alert_inbox(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, false);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $since_id = absint($request->get_param('since_id'));
        $limit = absint($request->get_param('limit')) ?: 50;

        $rows = vms_ops_alert_inbox_for_user(get_current_user_id(), (int) $venue_id, $since_id, $limit);

        return vms_ops_rest_ok(array(
            'items' => $rows,
        ));
    }
}

if (!function_exists('vms_ops_rest_alert_ack')) {
    function vms_ops_rest_alert_ack(WP_REST_Request $request)
    {
        $alert_id = absint($request->get_param('id'));
        $result = vms_ops_alert_acknowledge($alert_id, get_current_user_id());
        if (is_wp_error($result)) {
            return vms_ops_rest_error_from_wp_error($result);
        }

        return vms_ops_rest_ok(array(
            'item' => $result,
        ));
    }
}

if (!function_exists('vms_ops_rest_presence_start')) {
    function vms_ops_rest_presence_start(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $device_id = sanitize_text_field((string) $request->get_param('device_id'));
        $console_type = sanitize_key((string) $request->get_param('console_type'));

        $result = vms_ops_presence_start_shift(get_current_user_id(), (int) $venue_id, $device_id, $console_type);
        if (is_wp_error($result)) {
            return vms_ops_rest_error_from_wp_error($result);
        }

        return vms_ops_rest_ok($result, 201);
    }
}

if (!function_exists('vms_ops_rest_presence_heartbeat')) {
    function vms_ops_rest_presence_heartbeat(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $device_id = sanitize_text_field((string) $request->get_param('device_id'));

        $result = vms_ops_presence_heartbeat(get_current_user_id(), (int) $venue_id, $device_id);
        if (is_wp_error($result)) {
            return vms_ops_rest_error_from_wp_error($result);
        }

        return vms_ops_rest_ok($result);
    }
}

if (!function_exists('vms_ops_rest_presence_end')) {
    function vms_ops_rest_presence_end(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $device_id = sanitize_text_field((string) $request->get_param('device_id'));

        $result = vms_ops_presence_end_shift(get_current_user_id(), (int) $venue_id, $device_id);
        if (is_wp_error($result)) {
            return vms_ops_rest_error_from_wp_error($result);
        }

        return vms_ops_rest_ok($result);
    }
}

if (!function_exists('vms_ops_rest_presence_on_duty')) {
    function vms_ops_rest_presence_on_duty(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, false);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $rows = vms_ops_presence_get_on_duty_rows((int) $venue_id);

        return vms_ops_rest_ok(array(
            'items' => $rows,
        ));
    }
}

if (!function_exists('vms_ops_rest_presence_status')) {
    function vms_ops_rest_presence_status(WP_REST_Request $request)
    {
        $venue_id = vms_ops_rest_resolve_venue_id($request, true);
        if (is_wp_error($venue_id)) {
            return vms_ops_rest_error_from_wp_error($venue_id);
        }

        $device_id = sanitize_text_field((string) $request->get_param('device_id'));
        if (trim($device_id) === '') {
            return vms_ops_rest_error('invalid_device', __('Device is required.', 'vms-ops-console-premium'), 400);
        }

        if (function_exists('vms_ops_presence_auto_expire')) {
            $expired = vms_ops_presence_auto_expire();
            if (is_wp_error($expired)) {
                return vms_ops_rest_error_from_wp_error($expired);
            }
        }

        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . vms_ops_table_presence() . ' WHERE user_id = %d AND venue_id = %d AND device_id = %s AND status = %s ORDER BY id DESC LIMIT 1',
                get_current_user_id(),
                (int) $venue_id,
                $device_id,
                'on_duty'
            ),
            ARRAY_A
        );

        $on_duty = is_array($row);

        return vms_ops_rest_ok(array(
            'venue_id' => (int) $venue_id,
            'device_id' => $device_id,
            'on_duty' => $on_duty,
            'status' => $on_duty ? 'on_duty' : 'off_duty',
            'last_seen_at' => $on_duty ? (string) ($row['last_seen_at'] ?? '') : '',
            'shift_started_at' => $on_duty ? (string) ($row['shift_started_at'] ?? '') : '',
        ));
    }
}

add_action('rest_api_init', static function (): void {
    register_rest_route('vms-ops/v1', '/system/time', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(function_exists('vms_ops_all_capabilities') ? vms_ops_all_capabilities() : array(vms_ops_capability_use_pwa())),
        'callback' => 'vms_ops_rest_system_time',
    ));

    register_rest_route('vms-ops/v1', '/bootstrap', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(function_exists('vms_ops_all_capabilities') ? vms_ops_all_capabilities() : array(vms_ops_capability_use_pwa())),
        'callback' => 'vms_ops_rest_bootstrap',
    ));

    register_rest_route('vms-ops/v1', '/ticket/events', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_scan_tickets()), array(
            'action' => 'ticket_console_events',
            'reason' => 'missing_scan_tickets',
            'code' => 'missing_scan_tickets_permission',
            'message' => __('Ticket scanning is not enabled for this user. Ask a manager to review the Ticket Checker setup in VMS > Teams.', 'vms-ops-console-premium'),
        )),
        'callback' => 'vms_ops_rest_ticket_events',
    ));

    register_rest_route('vms-ops/v1', '/ticket/events/(?P<event_id>\d+)/attendees', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_scan_tickets()), array(
            'action' => 'ticket_console_attendees',
            'reason' => 'missing_scan_tickets',
            'code' => 'missing_scan_tickets_permission',
            'message' => __('Ticket scanning is not enabled for this user. Ask a manager to review the Ticket Checker setup in VMS > Teams.', 'vms-ops-console-premium'),
        )),
        'callback' => 'vms_ops_rest_ticket_attendees',
    ));

    register_rest_route('vms-ops/v1', '/ticket/checkin', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_scan_tickets()), array(
            'action' => 'ticket_scan',
            'reason' => 'missing_scan_tickets',
            'code' => 'missing_scan_tickets_permission',
            'message' => __('Ticket scanning is not enabled for this user. Ask a manager to review the Ticket Checker setup in VMS > Teams.', 'vms-ops-console-premium'),
        )),
        'callback' => 'vms_ops_rest_ticket_checkin',
    ));

    register_rest_route('vms-ops/v1', '/id/scan', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_scan_ids()), array(
            'action' => 'id_scan',
            'reason' => 'missing_scan_ids',
            'code' => 'missing_scan_ids_permission',
            'message' => __('ID scanning is not enabled for this user. Ask a manager to review the Bar or ID scan setup in VMS > Teams.', 'vms-ops-console-premium'),
        )),
        'callback' => 'vms_ops_rest_id_scan',
    ));

    register_rest_route('vms-ops/v1', '/id/manual-member', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_scan_ids(), vms_ops_capability_manage_members_lite(), vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_manual_member_create',
    ));

    register_rest_route('vms-ops/v1', '/id/banned-clear', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_scan_ids(), vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_banned_clear',
    ));

    register_rest_route('vms-ops/v1', '/members/search', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_scan_ids(), vms_ops_capability_manage_members_lite(), vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_member_search',
    ));

    register_rest_route('vms-ops/v1', '/member-lookup/search', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_member_lookup()), array(
            'action' => 'member_lookup_search',
            'reason' => 'missing_member_lookup',
            'code' => 'missing_member_lookup_permission',
            'message' => __('Verified Member Lookup is not enabled for this user. Ask a manager to review the Member Lookup setup in VMS > Teams.', 'vms-ops-console-premium'),
        )),
        'callback' => 'vms_ops_rest_member_lookup_search',
    ));

    register_rest_route('vms-ops/v1', '/member-lookup/(?P<id>\d+)', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_member_lookup()), array(
            'action' => 'member_lookup_detail',
            'reason' => 'missing_member_lookup',
            'code' => 'missing_member_lookup_permission',
            'message' => __('Verified Member Lookup is not enabled for this user. Ask a manager to review the Member Lookup setup in VMS > Teams.', 'vms-ops-console-premium'),
        )),
        'callback' => 'vms_ops_rest_member_lookup_detail',
    ));

    register_rest_route('vms-ops/v1', '/member-lookup/(?P<id>\d+)/decision', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_member_lookup()), array(
            'action' => 'member_lookup_decision',
            'reason' => 'missing_member_lookup',
            'code' => 'missing_member_lookup_permission',
            'message' => __('Verified Member Lookup is not enabled for this user. Ask a manager to review the Member Lookup setup in VMS > Teams.', 'vms-ops-console-premium'),
        )),
        'callback' => 'vms_ops_rest_member_lookup_decision',
    ));

    register_rest_route('vms-ops/v1', '/members/(?P<id>\d+)/renew', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_manage_members_lite(), vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_member_renew',
    ));

    register_rest_route('vms-ops/v1', '/members/(?P<id>\d+)/status', array(
        'methods' => 'PATCH',
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_member_status',
    ));

    register_rest_route('vms-ops/v1', '/members/(?P<id>\d+)/vip', array(
        'methods' => 'PATCH',
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_member_vip',
    ));

    register_rest_route('vms-ops/v1', '/members/(?P<id>\d+)/address', array(
        'methods' => 'PATCH',
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_member_address',
    ));

    register_rest_route('vms-ops/v1', '/members/(?P<id>\d+)/photo', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_manage_members_lite(), vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_member_photo_update',
    ));

    register_rest_route('vms-ops/v1', '/members/(?P<id>\d+)/photo', array(
        'methods' => WP_REST_Server::DELETABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_manage_members_lite(), vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_member_photo_remove',
    ));

    register_rest_route('vms-ops/v1', '/members/(?P<id>\d+)', array(
        'methods' => WP_REST_Server::DELETABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_manage_members_admin())),
        'callback' => 'vms_ops_rest_member_delete',
    ));

    register_rest_route('vms-ops/v1', '/alerts/presets', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(function_exists('vms_ops_all_capabilities') ? vms_ops_all_capabilities() : array(vms_ops_capability_use_pwa())),
        'callback' => 'vms_ops_rest_alert_presets',
    ));

    register_rest_route('vms-ops/v1', '/alerts/send', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_send_alerts())),
        'callback' => 'vms_ops_rest_alert_send',
    ));

    register_rest_route('vms-ops/v1', '/alerts/inbox', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_receive_alerts())),
        'callback' => 'vms_ops_rest_alert_inbox',
    ));

    register_rest_route('vms-ops/v1', '/alerts/(?P<id>\d+)/ack', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_receive_alerts())),
        'callback' => 'vms_ops_rest_alert_ack',
    ));

    register_rest_route('vms-ops/v1', '/presence/start', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_presence_checkin())),
        'callback' => 'vms_ops_rest_presence_start',
    ));

    register_rest_route('vms-ops/v1', '/presence/heartbeat', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_presence_checkin())),
        'callback' => 'vms_ops_rest_presence_heartbeat',
    ));

    register_rest_route('vms-ops/v1', '/presence/end', array(
        'methods' => WP_REST_Server::CREATABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_presence_checkin())),
        'callback' => 'vms_ops_rest_presence_end',
    ));

    register_rest_route('vms-ops/v1', '/presence/on-duty', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_presence_checkin(), vms_ops_capability_receive_alerts())),
        'callback' => 'vms_ops_rest_presence_on_duty',
    ));

    register_rest_route('vms-ops/v1', '/presence/status', array(
        'methods' => WP_REST_Server::READABLE,
        'permission_callback' => vms_ops_rest_permission_callback(array(vms_ops_capability_presence_checkin())),
        'callback' => 'vms_ops_rest_presence_status',
        'args' => array(
            'venue_id' => array('required' => true),
            'device_id' => array('required' => true),
        ),
    ));
});
