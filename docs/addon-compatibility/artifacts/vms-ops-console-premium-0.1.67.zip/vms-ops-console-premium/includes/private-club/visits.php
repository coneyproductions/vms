<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_pc_record_visit')) {
    function vms_ops_pc_record_visit(int $member_id, int $venue_id, string $source = 'id_scan', string $notes = '')
    {
        if ($member_id <= 0 || $venue_id <= 0) {
            return new WP_Error('invalid_visit_args', __('Member and venue are required for visit logging.', 'vms-ops-console-premium'));
        }

        global $wpdb;

        $today = vms_ops_today_ymd();
        $existing = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . vms_ops_table_pc_visits() . ' WHERE member_id = %d AND venue_id = %d AND visit_date = %s LIMIT 1',
                $member_id,
                $venue_id,
                $today
            ),
            ARRAY_A
        );

        if (is_array($existing)) {
            return array(
                'duplicate' => 1,
                'visit_id' => (int) $existing['id'],
                'visit_date' => (string) $existing['visit_date'],
                'checked_in_at' => (string) $existing['checked_in_at'],
            );
        }

        $inserted = $wpdb->insert(
            vms_ops_table_pc_visits(),
            array(
                'member_id' => $member_id,
                'venue_id' => $venue_id,
                'visit_date' => $today,
                'checked_in_at' => vms_ops_now_mysql(),
                'scanned_by_user_id' => get_current_user_id(),
                'source' => sanitize_key($source),
                'notes' => sanitize_text_field($notes),
                'created_at' => vms_ops_now_mysql(),
            ),
            array('%d', '%d', '%s', '%s', '%d', '%s', '%s', '%s')
        );

        if ($inserted === false) {
            return vms_ops_db_write_error('visit_insert_failed', __('Could not log member visit.', 'vms-ops-console-premium'));
        }

        $visit_id = (int) $wpdb->insert_id;

        $member_update = $wpdb->update(
            vms_ops_table_pc_members(),
            array(
                'last_visit_on' => $today,
                'updated_by' => get_current_user_id(),
                'updated_at' => vms_ops_now_mysql(),
            ),
            array('id' => $member_id),
            array('%s', '%d', '%s'),
            array('%d')
        );

        if ($member_update === false) {
            return vms_ops_db_write_error('member_last_visit_update_failed', __('Could not update member visit metadata.', 'vms-ops-console-premium'));
        }

        return array(
            'duplicate' => 0,
            'visit_id' => $visit_id,
            'visit_date' => $today,
            'checked_in_at' => vms_ops_now_mysql(),
        );
    }
}

if (!function_exists('vms_ops_pc_log_scan_event')) {
    function vms_ops_pc_log_scan_event(array $args)
    {
        $venue_id = absint($args['venue_id'] ?? 0);
        $member_id = isset($args['member_id']) ? absint($args['member_id']) : 0;
        $event_id = isset($args['event_id']) ? absint($args['event_id']) : 0;
        $scan_hash = sanitize_text_field((string) ($args['scan_hash'] ?? ''));

        if ($venue_id <= 0 || $scan_hash === '') {
            return new WP_Error('invalid_scan_log_args', __('Venue and scan hash are required for scan logging.', 'vms-ops-console-premium'));
        }

        $meta = $args['payload_meta'] ?? array();
        if (!is_array($meta)) {
            $meta = array();
        }
        $meta_json = wp_json_encode($meta);
        if (!is_string($meta_json)) {
            $meta_json = '{}';
        }

        global $wpdb;
        $inserted = $wpdb->insert(
            vms_ops_table_pc_scan_log(),
            array(
                'venue_id' => $venue_id,
                'member_id' => $member_id > 0 ? $member_id : null,
                'event_id' => $event_id > 0 ? $event_id : null,
                'scanner_user_id' => get_current_user_id(),
                'console_type' => sanitize_key((string) ($args['console_type'] ?? 'ops')),
                'scan_type' => sanitize_key((string) ($args['scan_type'] ?? 'manual')),
                'scan_hash' => $scan_hash,
                'scan_reference' => sanitize_text_field((string) ($args['scan_reference'] ?? '')),
                'result_code' => sanitize_key((string) ($args['result_code'] ?? 'ok')),
                'result_message' => sanitize_text_field((string) ($args['result_message'] ?? '')),
                'payload_meta' => $meta_json,
                'created_at' => vms_ops_now_mysql(),
            ),
            array('%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        if ($inserted === false) {
            return vms_ops_db_write_error('scan_log_insert_failed', __('Could not write scan log.', 'vms-ops-console-premium'));
        }

        return (int) $wpdb->insert_id;
    }
}

if (!function_exists('vms_ops_pc_ticket_scan_is_duplicate')) {
    function vms_ops_pc_ticket_scan_is_duplicate(int $event_id, string $scan_hash): bool
    {
        if ($event_id <= 0 || $scan_hash === '') {
            return false;
        }

        global $wpdb;
        $count = (int) $wpdb->get_var(
            $wpdb->prepare(
                'SELECT COUNT(1) FROM ' . vms_ops_table_pc_scan_log() . ' WHERE event_id = %d AND scan_hash = %s AND result_code = %s',
                $event_id,
                $scan_hash,
                'checked_in'
            )
        );

        return $count > 0;
    }
}

if (!function_exists('vms_ops_pc_ticket_duplicate_scan_hashes_for_event')) {
    function vms_ops_pc_ticket_duplicate_scan_hashes_for_event(int $event_id, array $scan_hashes): array
    {
        if ($event_id <= 0 || empty($scan_hashes)) {
            return array();
        }

        $deduped = array();
        foreach ($scan_hashes as $scan_hash) {
            $scan_hash = sanitize_text_field((string) $scan_hash);
            if ($scan_hash === '') {
                continue;
            }

            $deduped[$scan_hash] = true;
        }

        $hashes = array_keys($deduped);
        if (empty($hashes)) {
            return array();
        }

        global $wpdb;
        $placeholders = implode(', ', array_fill(0, count($hashes), '%s'));
        $sql = 'SELECT DISTINCT scan_hash FROM ' . vms_ops_table_pc_scan_log() . " WHERE event_id = %d AND result_code = %s AND scan_hash IN ({$placeholders})";
        $prepared = $wpdb->prepare(
            $sql,
            array_merge(array($event_id, 'checked_in'), $hashes)
        );

        $rows = $wpdb->get_col($prepared);
        if (!is_array($rows) || empty($rows)) {
            return array();
        }

        $lookup = array();
        foreach ($rows as $row) {
            $scan_hash = sanitize_text_field((string) $row);
            if ($scan_hash === '') {
                continue;
            }

            $lookup[$scan_hash] = true;
        }

        return $lookup;
    }
}

if (!function_exists('vms_ops_pc_scan_log_default_filters')) {
    function vms_ops_pc_scan_log_default_filters(): array
    {
        $today = DateTimeImmutable::createFromFormat('!Y-m-d', vms_ops_today_ymd(), wp_timezone());
        if (!($today instanceof DateTimeImmutable)) {
            $today = new DateTimeImmutable('now', wp_timezone());
        }

        return array(
            'date_from' => $today->modify('-6 days')->format('Y-m-d'),
            'date_to' => $today->format('Y-m-d'),
            'venue_id' => 0,
            'result_code' => '',
            'scanner_user_id' => 0,
            'member_lookup' => '',
            'console_type' => 'id',
            'per_page' => 50,
            'page_num' => 1,
        );
    }
}

if (!function_exists('vms_ops_pc_scan_log_normalize_filters')) {
    function vms_ops_pc_scan_log_normalize_filters(array $raw): array
    {
        $defaults = vms_ops_pc_scan_log_default_filters();
        $allowed_results = array('processed', 'member_not_found', 'suspended', 'banned');
        $allowed_console_types = array('id', 'all');
        $allowed_per_page = array(25, 50, 100);

        $date_from = sanitize_text_field((string) ($raw['date_from'] ?? $defaults['date_from']));
        $date_to = sanitize_text_field((string) ($raw['date_to'] ?? $defaults['date_to']));

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)) {
            $date_from = $defaults['date_from'];
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to)) {
            $date_to = $defaults['date_to'];
        }

        if ($date_from > $date_to) {
            $swap = $date_from;
            $date_from = $date_to;
            $date_to = $swap;
        }

        $result_code = sanitize_key((string) ($raw['result_code'] ?? ''));
        if (!in_array($result_code, $allowed_results, true)) {
            $result_code = '';
        }

        $console_type = sanitize_key((string) ($raw['console_type'] ?? $defaults['console_type']));
        if (!in_array($console_type, $allowed_console_types, true)) {
            $console_type = $defaults['console_type'];
        }

        $per_page = (int) ($raw['per_page'] ?? $defaults['per_page']);
        if (!in_array($per_page, $allowed_per_page, true)) {
            $per_page = $defaults['per_page'];
        }

        return array(
            'date_from' => $date_from,
            'date_to' => $date_to,
            'venue_id' => max(0, absint((string) ($raw['venue_id'] ?? 0))),
            'result_code' => $result_code,
            'scanner_user_id' => max(0, absint((string) ($raw['scanner_user_id'] ?? 0))),
            'member_lookup' => sanitize_text_field((string) ($raw['member_lookup'] ?? '')),
            'console_type' => $console_type,
            'per_page' => $per_page,
            'page_num' => max(1, absint((string) ($raw['page_num'] ?? $raw['paged'] ?? $defaults['page_num']))),
        );
    }
}

if (!function_exists('vms_ops_pc_scan_log_decode_payload_meta')) {
    function vms_ops_pc_scan_log_decode_payload_meta($raw): array
    {
        if (is_array($raw)) {
            return $raw;
        }

        if (!is_string($raw) || trim($raw) === '') {
            return array();
        }

        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : array();
    }
}

if (!function_exists('vms_ops_pc_scan_log_mysql_to_timestamp')) {
    function vms_ops_pc_scan_log_mysql_to_timestamp(string $value): ?int
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $dt = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $value, wp_timezone());
        if (!($dt instanceof DateTimeImmutable)) {
            return null;
        }

        return $dt->getTimestamp();
    }
}

if (!function_exists('vms_ops_pc_scan_log_format_datetime')) {
    function vms_ops_pc_scan_log_format_datetime(string $value): string
    {
        $timestamp = vms_ops_pc_scan_log_mysql_to_timestamp($value);
        if ($timestamp === null) {
            return $value;
        }

        $format = trim((string) get_option('date_format') . ' ' . (string) get_option('time_format'));
        if ($format === '') {
            $format = 'M j, Y g:i A';
        }

        return (string) wp_date($format, $timestamp, wp_timezone());
    }
}

if (!function_exists('vms_ops_pc_scan_log_age_from_dob')) {
    function vms_ops_pc_scan_log_age_from_dob(string $dob): ?int
    {
        $dob = trim($dob);
        if ($dob === '') {
            return null;
        }

        $birth = DateTimeImmutable::createFromFormat('!Y-m-d', $dob, wp_timezone());
        if (!($birth instanceof DateTimeImmutable)) {
            return null;
        }

        $today = DateTimeImmutable::createFromFormat('!Y-m-d', vms_ops_today_ymd(), wp_timezone());
        if (!($today instanceof DateTimeImmutable)) {
            $today = new DateTimeImmutable('now', wp_timezone());
        }

        return max(0, (int) $birth->diff($today)->y);
    }
}

if (!function_exists('vms_ops_pc_scan_log_payload_items')) {
    function vms_ops_pc_scan_log_payload_items(array $payload_meta): array
    {
        $items = array();
        foreach ($payload_meta as $key => $value) {
            $key = sanitize_key((string) $key);
            if ($key === '' || $key === 'address_line_1') {
                continue;
            }

            if ($key === 'address_line_1_present') {
                $items[] = array(
                    'label' => __('Street Address Present', 'vms-ops-console-premium'),
                    'value' => !empty($value) ? __('Yes', 'vms-ops-console-premium') : __('No', 'vms-ops-console-premium'),
                );
                continue;
            }

            if (is_array($value)) {
                $value = wp_json_encode($value);
            } elseif (is_bool($value)) {
                $value = $value ? __('Yes', 'vms-ops-console-premium') : __('No', 'vms-ops-console-premium');
            }

            $string_value = trim((string) $value);
            if ($string_value === '') {
                continue;
            }

            $items[] = array(
                'label' => ucwords(str_replace('_', ' ', $key)),
                'value' => $string_value,
            );
        }

        return $items;
    }
}

if (!function_exists('vms_ops_pc_scan_log_venue_labels')) {
    function vms_ops_pc_scan_log_venue_labels(array $rows): array
    {
        $venue_ids = array();
        foreach ($rows as $row) {
            $venue_id = (int) ($row['venue_id'] ?? 0);
            if ($venue_id > 0) {
                $venue_ids[] = $venue_id;
            }
        }

        $venue_ids = array_values(array_unique(array_map('absint', $venue_ids)));
        if (empty($venue_ids)) {
            return array();
        }

        $labels = array();
        $allowed_statuses = function_exists('vms_ops_venue_allowed_statuses') ? vms_ops_venue_allowed_statuses() : null;
        $venues = function_exists('vms_ops_venues_from_ids') ? vms_ops_venues_from_ids($venue_ids, $allowed_statuses) : array();
        foreach ($venues as $venue) {
            $venue_id = (int) ($venue['id'] ?? 0);
            if ($venue_id <= 0) {
                continue;
            }
            $labels[$venue_id] = (string) ($venue['name'] ?? ('Venue #' . $venue_id));
        }

        foreach ($venue_ids as $venue_id) {
            if (!isset($labels[$venue_id])) {
                $fallback = sanitize_text_field((string) get_the_title($venue_id));
                $labels[$venue_id] = $fallback !== '' ? $fallback : ('Venue #' . $venue_id);
            }
        }

        return $labels;
    }
}

if (!function_exists('vms_ops_pc_scan_log_notes')) {
    function vms_ops_pc_scan_log_notes(string $result_message, array $payload_meta): string
    {
        $parts = array();
        $message = trim($result_message);
        if ($message !== '') {
            $parts[] = $message;
        }

        if (!empty($payload_meta['address_mismatch'])) {
            $parts[] = __('Address mismatch', 'vms-ops-console-premium');
        }
        if (!empty($payload_meta['renewed'])) {
            $parts[] = __('Auto-renewed', 'vms-ops-console-premium');
        }

        $parts = array_values(array_unique(array_filter(array_map('trim', $parts))));
        return implode(' • ', $parts);
    }
}

if (!function_exists('vms_ops_pc_scan_log_prepare_row')) {
    function vms_ops_pc_scan_log_prepare_row(array $row, array $venue_labels = array()): array
    {
        $payload_meta = vms_ops_pc_scan_log_decode_payload_meta($row['payload_meta'] ?? array());

        $member_number = trim((string) ($row['member_number_db'] ?? ''));
        if ($member_number === '') {
            $member_number = trim((string) ($payload_meta['member_number'] ?? ''));
        }
        if ($member_number === '') {
            $member_number = trim((string) ($row['scan_reference'] ?? ''));
        }

        $first_name = trim((string) ($row['member_first_name_db'] ?? ''));
        if ($first_name === '') {
            $first_name = trim((string) ($payload_meta['first_name'] ?? ''));
        }

        $last_name = trim((string) ($row['member_last_name_db'] ?? ''));
        if ($last_name === '') {
            $last_name = trim((string) ($payload_meta['last_name'] ?? ''));
        }

        $member_name = trim($first_name . ' ' . $last_name);
        if ($member_name === '') {
            $member_name = trim((string) ($row['member_name_db'] ?? ''));
        }

        $member_status = trim((string) ($row['member_status_db'] ?? ''));
        if ($member_status === '') {
            $member_status = trim((string) ($payload_meta['member_status'] ?? ''));
        }

        $date_of_birth = trim((string) ($row['member_date_of_birth_db'] ?? ''));
        if ($date_of_birth === '') {
            $date_of_birth = trim((string) ($payload_meta['date_of_birth'] ?? ''));
        }

        $age = vms_ops_pc_scan_log_age_from_dob($date_of_birth);
        $scanner_user_id = (int) ($row['scanner_user_id'] ?? 0);
        $scanner_display_name = trim((string) ($row['scanner_display_name'] ?? ''));
        if ($scanner_display_name === '' && $scanner_user_id > 0) {
            $scanner_display_name = 'User #' . $scanner_user_id;
        }

        $venue_id = (int) ($row['venue_id'] ?? 0);
        $event_id = (int) ($row['event_id'] ?? 0);
        $event_title = trim((string) ($row['event_title_db'] ?? ''));
        if ($event_title === '' && $event_id > 0) {
            $event_title = 'Event #' . $event_id;
        }

        return array(
            'id' => (int) ($row['id'] ?? 0),
            'created_at' => (string) ($row['created_at'] ?? ''),
            'created_at_display' => vms_ops_pc_scan_log_format_datetime((string) ($row['created_at'] ?? '')),
            'venue_id' => $venue_id,
            'venue_label' => (string) ($venue_labels[$venue_id] ?? ($venue_id > 0 ? ('Venue #' . $venue_id) : '—')),
            'scanner_user_id' => $scanner_user_id,
            'scanner_display_name' => $scanner_display_name !== '' ? $scanner_display_name : '—',
            'console_type' => (string) ($row['console_type'] ?? ''),
            'scan_type' => (string) ($row['scan_type'] ?? ''),
            'result_code' => (string) ($row['result_code'] ?? ''),
            'result_message' => (string) ($row['result_message'] ?? ''),
            'member_id' => (int) ($row['member_id'] ?? 0),
            'member_number' => $member_number,
            'member_name' => $member_name !== '' ? $member_name : '—',
            'member_status' => $member_status,
            'date_of_birth' => $date_of_birth,
            'age_years' => $age,
            'age_display' => $age !== null ? (string) $age : '—',
            'scan_reference' => (string) ($row['scan_reference'] ?? ''),
            'event_id' => $event_id,
            'event_title' => $event_title,
            'payload_meta' => $payload_meta,
            'payload_meta_items' => vms_ops_pc_scan_log_payload_items($payload_meta),
            'notes' => vms_ops_pc_scan_log_notes((string) ($row['result_message'] ?? ''), $payload_meta),
        );
    }
}

if (!function_exists('vms_ops_pc_scan_log_build_where_sql')) {
    function vms_ops_pc_scan_log_build_where_sql(array $filters, array &$params): string
    {
        global $wpdb;

        $params = array();
        $where = array('1=1');

        if (($filters['console_type'] ?? 'id') !== 'all') {
            $where[] = 'sl.console_type = %s';
            $params[] = (string) $filters['console_type'];
        }

        if (!empty($filters['result_code'])) {
            $where[] = 'sl.result_code = %s';
            $params[] = (string) $filters['result_code'];
        }

        if (!empty($filters['venue_id'])) {
            $where[] = 'sl.venue_id = %d';
            $params[] = (int) $filters['venue_id'];
        }

        if (!empty($filters['scanner_user_id'])) {
            $where[] = 'sl.scanner_user_id = %d';
            $params[] = (int) $filters['scanner_user_id'];
        }

        if (!empty($filters['date_from'])) {
            $where[] = 'sl.created_at >= %s';
            $params[] = (string) $filters['date_from'] . ' 00:00:00';
        }

        if (!empty($filters['date_to'])) {
            $date_to = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $filters['date_to'], wp_timezone());
            if ($date_to instanceof DateTimeImmutable) {
                $where[] = 'sl.created_at < %s';
                $params[] = $date_to->modify('+1 day')->format('Y-m-d 00:00:00');
            }
        }

        $lookup = trim((string) ($filters['member_lookup'] ?? ''));
        if ($lookup !== '') {
            $like = '%' . $wpdb->esc_like($lookup) . '%';
            $where[] = '(sl.scan_reference LIKE %s OR CAST(sl.payload_meta AS CHAR) LIKE %s OR m.member_number LIKE %s OR m.first_name LIKE %s OR m.last_name LIKE %s OR CONCAT_WS(" ", m.first_name, m.last_name) LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        return implode(' AND ', $where);
    }
}

if (!function_exists('vms_ops_pc_scan_log_base_select_sql')) {
    function vms_ops_pc_scan_log_base_select_sql(): string
    {
        global $wpdb;

        return ' FROM ' . vms_ops_table_pc_scan_log() . ' sl
            LEFT JOIN ' . vms_ops_table_pc_members() . ' m ON m.id = sl.member_id
            LEFT JOIN ' . $wpdb->users . ' u ON u.ID = sl.scanner_user_id
            LEFT JOIN ' . $wpdb->posts . ' e ON e.ID = sl.event_id ';
    }
}

if (!function_exists('vms_ops_pc_scan_log_get_rows')) {
    function vms_ops_pc_scan_log_get_rows(array $filters, int $per_page, int $page_num): array
    {
        global $wpdb;

        $normalized = vms_ops_pc_scan_log_normalize_filters(array_merge($filters, array(
            'per_page' => $per_page,
            'page_num' => $page_num,
        )));

        $params = array();
        $where_sql = vms_ops_pc_scan_log_build_where_sql($normalized, $params);
        $limit = max(1, min(100, (int) $normalized['per_page']));
        $offset = max(0, ((int) $normalized['page_num'] - 1) * $limit);

        $sql = 'SELECT
                sl.*,
                m.member_number AS member_number_db,
                m.first_name AS member_first_name_db,
                m.last_name AS member_last_name_db,
                CONCAT_WS(" ", m.first_name, m.last_name) AS member_name_db,
                m.status AS member_status_db,
                m.date_of_birth AS member_date_of_birth_db,
                u.display_name AS scanner_display_name,
                e.post_title AS event_title_db'
            . vms_ops_pc_scan_log_base_select_sql()
            . ' WHERE ' . $where_sql
            . ' ORDER BY sl.created_at DESC, sl.id DESC LIMIT %d OFFSET %d';

        $query_params = array_merge($params, array($limit, $offset));
        $prepared = $wpdb->prepare($sql, $query_params);
        $rows = $wpdb->get_results($prepared, ARRAY_A);
        if (!is_array($rows)) {
            return array();
        }

        $venue_labels = vms_ops_pc_scan_log_venue_labels($rows);
        $prepared_rows = array();
        foreach ($rows as $row) {
            $prepared_rows[] = vms_ops_pc_scan_log_prepare_row($row, $venue_labels);
        }

        return $prepared_rows;
    }
}

if (!function_exists('vms_ops_pc_scan_log_get_total')) {
    function vms_ops_pc_scan_log_get_total(array $filters): int
    {
        global $wpdb;

        $normalized = vms_ops_pc_scan_log_normalize_filters($filters);
        $params = array();
        $where_sql = vms_ops_pc_scan_log_build_where_sql($normalized, $params);

        $sql = 'SELECT COUNT(1)' . vms_ops_pc_scan_log_base_select_sql() . ' WHERE ' . $where_sql;
        $prepared = !empty($params) ? $wpdb->prepare($sql, $params) : $sql;

        return (int) $wpdb->get_var($prepared);
    }
}

if (!function_exists('vms_ops_pc_scan_log_get_row')) {
    function vms_ops_pc_scan_log_get_row(int $scan_log_id): ?array
    {
        global $wpdb;

        $scan_log_id = absint($scan_log_id);
        if ($scan_log_id <= 0) {
            return null;
        }

        $sql = 'SELECT
                sl.*,
                m.member_number AS member_number_db,
                m.first_name AS member_first_name_db,
                m.last_name AS member_last_name_db,
                CONCAT_WS(" ", m.first_name, m.last_name) AS member_name_db,
                m.status AS member_status_db,
                m.date_of_birth AS member_date_of_birth_db,
                u.display_name AS scanner_display_name,
                e.post_title AS event_title_db'
            . vms_ops_pc_scan_log_base_select_sql()
            . ' WHERE sl.id = %d LIMIT 1';

        $row = $wpdb->get_row($wpdb->prepare($sql, $scan_log_id), ARRAY_A);
        if (!is_array($row)) {
            return null;
        }

        $venue_labels = vms_ops_pc_scan_log_venue_labels(array($row));
        return vms_ops_pc_scan_log_prepare_row($row, $venue_labels);
    }
}

if (!function_exists('vms_ops_pc_scan_log_export_rows')) {
    function vms_ops_pc_scan_log_export_rows(array $filters): array
    {
        global $wpdb;

        $normalized = vms_ops_pc_scan_log_normalize_filters($filters);
        $params = array();
        $where_sql = vms_ops_pc_scan_log_build_where_sql($normalized, $params);

        $sql = 'SELECT
                sl.*,
                m.member_number AS member_number_db,
                m.first_name AS member_first_name_db,
                m.last_name AS member_last_name_db,
                CONCAT_WS(" ", m.first_name, m.last_name) AS member_name_db,
                m.status AS member_status_db,
                m.date_of_birth AS member_date_of_birth_db,
                u.display_name AS scanner_display_name,
                e.post_title AS event_title_db'
            . vms_ops_pc_scan_log_base_select_sql()
            . ' WHERE ' . $where_sql
            . ' ORDER BY sl.created_at DESC, sl.id DESC';

        $prepared = !empty($params) ? $wpdb->prepare($sql, $params) : $sql;
        $rows = $wpdb->get_results($prepared, ARRAY_A);
        if (!is_array($rows)) {
            return array();
        }

        $venue_labels = vms_ops_pc_scan_log_venue_labels($rows);
        $prepared_rows = array();
        foreach ($rows as $row) {
            $prepared_rows[] = vms_ops_pc_scan_log_prepare_row($row, $venue_labels);
        }

        return $prepared_rows;
    }
}

if (!function_exists('vms_ops_pc_scan_log_get_scanner_options')) {
    function vms_ops_pc_scan_log_get_scanner_options(): array
    {
        global $wpdb;

        $sql = 'SELECT DISTINCT sl.scanner_user_id, u.display_name
            FROM ' . vms_ops_table_pc_scan_log() . ' sl
            LEFT JOIN ' . $wpdb->users . ' u ON u.ID = sl.scanner_user_id
            WHERE sl.console_type = %s
            ORDER BY u.display_name ASC, sl.scanner_user_id ASC';

        $rows = $wpdb->get_results($wpdb->prepare($sql, 'id'), ARRAY_A);
        if (!is_array($rows)) {
            return array();
        }

        $options = array();
        foreach ($rows as $row) {
            $user_id = (int) ($row['scanner_user_id'] ?? 0);
            if ($user_id <= 0) {
                continue;
            }

            $label = trim((string) ($row['display_name'] ?? ''));
            if ($label === '') {
                $label = 'User #' . $user_id;
            }

            $options[] = array(
                'id' => $user_id,
                'label' => $label,
            );
        }

        return $options;
    }
}
