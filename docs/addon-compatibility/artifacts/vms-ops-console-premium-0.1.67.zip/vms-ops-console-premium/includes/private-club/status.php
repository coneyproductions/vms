<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_pc_member_effective_status')) {
    function vms_ops_pc_member_effective_status(array $member_row): string
    {
        $status = sanitize_key((string) ($member_row['status'] ?? 'active'));
        if (!in_array($status, array('active', 'suspended', 'banned'), true)) {
            $status = 'active';
        }

        if ($status === 'banned' || $status === 'suspended') {
            return $status;
        }

        $expires = (string) ($member_row['membership_expires_on'] ?? '');
        if ($expires !== '' && $expires < vms_ops_today_ymd()) {
            return 'expired';
        }

        return 'active';
    }
}

if (!function_exists('vms_ops_pc_is_within_birthday_window')) {
    function vms_ops_pc_is_within_birthday_window(string $dob, int $window_days): bool
    {
        if ($dob === '' || $window_days < 0) {
            return false;
        }

        $birth = DateTimeImmutable::createFromFormat('Y-m-d', $dob, wp_timezone());
        if (!($birth instanceof DateTimeImmutable)) {
            return false;
        }

        $today = new DateTimeImmutable(vms_ops_today_ymd(), wp_timezone());
        $month = (int) $birth->format('m');
        $day = (int) $birth->format('d');
        $year = (int) $today->format('Y');

        $candidates = array(
            DateTimeImmutable::createFromFormat('Y-m-d', sprintf('%04d-%02d-%02d', $year - 1, $month, $day), wp_timezone()),
            DateTimeImmutable::createFromFormat('Y-m-d', sprintf('%04d-%02d-%02d', $year, $month, $day), wp_timezone()),
            DateTimeImmutable::createFromFormat('Y-m-d', sprintf('%04d-%02d-%02d', $year + 1, $month, $day), wp_timezone()),
        );

        foreach ($candidates as $candidate) {
            if (!($candidate instanceof DateTimeImmutable)) {
                continue;
            }
            $delta = (int) $today->diff($candidate)->format('%r%a');
            if (abs($delta) <= $window_days) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('vms_ops_pc_member_console_flags')) {
    function vms_ops_pc_member_console_flags(array $member_row, int $venue_id): array
    {
        $birthday_window_days = function_exists('vms_ops_get_venue_setting')
            ? (int) vms_ops_get_venue_setting($venue_id, 'birthday_window_days', 7)
            : 7;

        return array(
            'effective_status' => vms_ops_pc_member_effective_status($member_row),
            'birthday_window' => vms_ops_pc_is_within_birthday_window((string) ($member_row['date_of_birth'] ?? ''), max(0, $birthday_window_days)) ? 1 : 0,
            'anniversary_lock' => vms_ops_pc_is_anniversary_locked($member_row) ? 1 : 0,
            'vip' => !empty($member_row['vip']) ? 1 : 0,
        );
    }
}

if (!function_exists('vms_ops_pc_update_status')) {
    function vms_ops_pc_update_status(int $member_id, string $new_status, string $reason = '')
    {
        $new_status = sanitize_key($new_status);
        if (!in_array($new_status, array('active', 'suspended', 'banned'), true)) {
            return new WP_Error('invalid_status', __('Invalid member status.', 'vms-ops-console-premium'));
        }

        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_not_found', __('Member not found.', 'vms-ops-console-premium'));
        }

        $updates = array(
            'status' => $new_status,
            'updated_by' => get_current_user_id(),
            'updated_at' => vms_ops_now_mysql(),
        );
        $formats = array('%s', '%d', '%s');

        if ($new_status === 'suspended') {
            $updates['suspended_at'] = vms_ops_now_mysql();
            $updates['suspended_reason'] = sanitize_textarea_field($reason);
            $formats[] = '%s';
            $formats[] = '%s';
        } elseif ($new_status === 'banned') {
            $updates['banned_at'] = vms_ops_now_mysql();
            $updates['banned_reason'] = sanitize_textarea_field($reason);
            $formats[] = '%s';
            $formats[] = '%s';
        } else {
            $updates['suspended_at'] = null;
            $updates['suspended_reason'] = null;
            $updates['banned_at'] = null;
            $updates['banned_reason'] = null;
            $formats[] = '%s';
            $formats[] = '%s';
            $formats[] = '%s';
            $formats[] = '%s';
        }

        global $wpdb;
        $updated = $wpdb->update(
            vms_ops_table_pc_members(),
            $updates,
            array('id' => $member_id),
            $formats,
            array('%d')
        );

        if ($updated === false) {
            return vms_ops_db_write_error('member_status_update_failed', __('Could not update member status.', 'vms-ops-console-premium'));
        }

        $action = 'status_set_active';
        if ($new_status === 'suspended') {
            $action = 'suspend';
        } elseif ($new_status === 'banned') {
            $action = 'ban';
        } elseif (sanitize_key((string) ($member['status'] ?? '')) === 'banned') {
            $action = 'unban';
        }

        $audit = vms_ops_pc_audit_log((int) $member['venue_id'], $member_id, $action, array(
            'reason' => $reason,
        ));
        if (is_wp_error($audit)) {
            return $audit;
        }

        $fresh = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($fresh)) {
            return new WP_Error('member_lookup_failed', __('Could not load updated member.', 'vms-ops-console-premium'));
        }

        return $fresh;
    }
}

if (!function_exists('vms_ops_pc_update_vip')) {
    function vms_ops_pc_update_vip(int $member_id, bool $vip)
    {
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_not_found', __('Member not found.', 'vms-ops-console-premium'));
        }

        global $wpdb;
        $updated = $wpdb->update(
            vms_ops_table_pc_members(),
            array(
                'vip' => $vip ? 1 : 0,
                'updated_by' => get_current_user_id(),
                'updated_at' => vms_ops_now_mysql(),
            ),
            array('id' => $member_id),
            array('%d', '%d', '%s'),
            array('%d')
        );

        if ($updated === false) {
            return vms_ops_db_write_error('vip_update_failed', __('Could not update VIP state.', 'vms-ops-console-premium'));
        }

        $audit = vms_ops_pc_audit_log((int) $member['venue_id'], $member_id, 'vip_change', array(
            'vip' => $vip ? 1 : 0,
        ));
        if (is_wp_error($audit)) {
            return $audit;
        }

        $fresh = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($fresh)) {
            return new WP_Error('member_lookup_failed', __('Could not load updated member.', 'vms-ops-console-premium'));
        }

        return $fresh;
    }
}

if (!function_exists('vms_ops_pc_log_banned_screen_clear')) {
    function vms_ops_pc_log_banned_screen_clear(int $member_id)
    {
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_not_found', __('Member not found.', 'vms-ops-console-premium'));
        }

        return vms_ops_pc_audit_log((int) $member['venue_id'], $member_id, 'banned_screen_clear', array());
    }
}
