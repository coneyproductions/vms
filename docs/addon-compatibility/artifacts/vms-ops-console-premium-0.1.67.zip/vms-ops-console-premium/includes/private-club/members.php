<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_pc_sanitize_member_number')) {
    function vms_ops_pc_sanitize_member_number(string $value): string
    {
        $value = strtoupper(trim($value));
        $value = preg_replace('/[^A-Z0-9\-]/', '', $value);
        return (string) $value;
    }
}

if (!function_exists('vms_ops_pc_normalize_dob')) {
    function vms_ops_pc_normalize_dob(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        $timezone = wp_timezone();
        $today = new DateTimeImmutable('now', $timezone);
        $oldest = $today->modify('-130 years');

        $parse_format = static function (string $raw, string $format) use ($timezone): ?DateTimeImmutable {
            $date = DateTimeImmutable::createFromFormat('!' . $format, $raw, $timezone);
            if (!($date instanceof DateTimeImmutable)) {
                return null;
            }

            $errors = DateTimeImmutable::getLastErrors();
            $has_errors = is_array($errors) && (
                !empty($errors['warning_count']) || !empty($errors['error_count'])
            );
            if ($has_errors) {
                return null;
            }

            return $date;
        };

        $is_plausible = static function (DateTimeImmutable $date) use ($today, $oldest): bool {
            if ($date > $today) {
                return false;
            }

            if ($date < $oldest) {
                return false;
            }

            $year = (int) $date->format('Y');
            return $year >= 1900;
        };

        $raw_digits = preg_replace('/\D+/', '', $value);
        $formats = array(
            'Y-m-d',
            'm/d/Y',
            'm-d-Y',
            'n/j/Y',
            'n-j-Y',
            'm/d/y',
            'm-d-y',
            'Ymd',
            'mdY',
        );

        $candidate_values = array($value);
        if (preg_match('/\d{8}/', $value, $match_8) === 1) {
            $candidate_values[] = (string) $match_8[0];
        }
        if (preg_match('/\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}/', $value, $match_delimited) === 1) {
            $candidate_values[] = (string) $match_delimited[0];
        }

        if (is_string($raw_digits) && strlen($raw_digits) === 8) {
            $candidate_values[] = $raw_digits;
        }

        foreach ($candidate_values as $candidate_value) {
            $candidate_value = trim((string) $candidate_value);
            if ($candidate_value === '') {
                continue;
            }

            $candidate_digits = preg_replace('/\D+/', '', $candidate_value);
            $candidate_formats = $formats;

            // AAMVA payloads often provide 8 digits (CCYYMMDD or MMDDYYYY).
            if (is_string($candidate_digits) && strlen($candidate_digits) === 8) {
                $candidate_formats = array_merge(array('Ymd', 'mdY', 'dmY'), $candidate_formats);
                $candidate_value = $candidate_digits;
            }

            $seen = array();
            foreach ($candidate_formats as $format) {
                if (isset($seen[$format])) {
                    continue;
                }
                $seen[$format] = true;

                $date = $parse_format($candidate_value, $format);
                if ($date instanceof DateTimeImmutable && $is_plausible($date)) {
                    return $date->format('Y-m-d');
                }
            }
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return '';
        }

        $fallback = (new DateTimeImmutable('@' . $timestamp))->setTimezone($timezone);
        if (!$is_plausible($fallback)) {
            return '';
        }

        return $fallback->format('Y-m-d');
    }
}

if (!function_exists('vms_ops_pc_normalize_postal_code')) {
    function vms_ops_pc_normalize_postal_code(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        $digits = preg_replace('/\D+/', '', $value);
        if (is_string($digits) && strlen($digits) >= 5) {
            return substr($digits, 0, 5);
        }

        return sanitize_text_field($value);
    }
}

if (!function_exists('vms_ops_pc_normalize_phone_number')) {
    function vms_ops_pc_normalize_phone_number(string $value): string
    {
        $digits = preg_replace('/\D+/', '', trim($value));
        if (!is_string($digits)) {
            return '';
        }

        return substr($digits, 0, 20);
    }
}

if (!function_exists('vms_ops_pc_sanitize_phone_number')) {
    function vms_ops_pc_sanitize_phone_number(string $value): string
    {
        $value = sanitize_text_field($value);
        $digits = vms_ops_pc_normalize_phone_number($value);
        if ($digits === '') {
            return '';
        }

        return $value !== '' ? $value : $digits;
    }
}

if (!function_exists('vms_ops_pc_normalize_email_address')) {
    function vms_ops_pc_normalize_email_address(string $value): string
    {
        $email = sanitize_email(trim($value));
        if ($email === '' || !is_email($email)) {
            return '';
        }

        return strtolower($email);
    }
}

if (!function_exists('vms_ops_pc_sanitize_address')) {
    function vms_ops_pc_sanitize_address(array $address): array
    {
        return array(
            'address_line_1' => sanitize_text_field((string) ($address['address_line_1'] ?? '')),
            'address_line_2' => sanitize_text_field((string) ($address['address_line_2'] ?? '')),
            'city' => sanitize_text_field((string) ($address['city'] ?? '')),
            'state' => strtoupper(sanitize_text_field((string) ($address['state'] ?? ''))),
            'postal_code' => vms_ops_pc_normalize_postal_code((string) ($address['postal_code'] ?? '')),
        );
    }
}

if (!function_exists('vms_ops_pc_pack_address')) {
    function vms_ops_pc_pack_address(array $address)
    {
        $sanitized = vms_ops_pc_sanitize_address($address);
        $json = wp_json_encode($sanitized);
        if (!is_string($json)) {
            return new WP_Error('address_encode_failed', __('Could not encode address payload.', 'vms-ops-console-premium'));
        }

        $cipher = vms_ops_encrypt_text($json);
        if (is_wp_error($cipher)) {
            return $cipher;
        }

        return array(
            'ciphertext' => (string) $cipher,
            'hash' => vms_ops_build_address_hash($sanitized),
            'sanitized' => $sanitized,
        );
    }
}

if (!function_exists('vms_ops_pc_unpack_address')) {
    function vms_ops_pc_unpack_address(string $ciphertext)
    {
        if ($ciphertext === '') {
            return array();
        }

        $json = vms_ops_decrypt_text($ciphertext);
        if (is_wp_error($json)) {
            return $json;
        }

        $decoded = json_decode((string) $json, true);
        if (!is_array($decoded)) {
            return new WP_Error('address_decode_failed', __('Could not decode encrypted address.', 'vms-ops-console-premium'));
        }

        return vms_ops_pc_sanitize_address($decoded);
    }
}

if (!function_exists('vms_ops_pc_get_member_by_id')) {
    function vms_ops_pc_get_member_by_id(int $member_id): ?array
    {
        if ($member_id <= 0) {
            return null;
        }

        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare('SELECT * FROM ' . vms_ops_table_pc_members() . ' WHERE id = %d', $member_id),
            ARRAY_A
        );

        return is_array($row) ? $row : null;
    }
}

if (!function_exists('vms_ops_pc_get_member_by_number')) {
    function vms_ops_pc_get_member_by_number(int $venue_id, string $member_number): ?array
    {
        if ($venue_id <= 0 || $member_number === '') {
            return null;
        }

        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . vms_ops_table_pc_members() . ' WHERE venue_id = %d AND member_number = %s LIMIT 1',
                $venue_id,
                $member_number
            ),
            ARRAY_A
        );

        return is_array($row) ? $row : null;
    }
}

if (!function_exists('vms_ops_pc_prepare_member_for_response')) {
    function vms_ops_pc_prepare_member_for_response(array $member, bool $include_address = false): array
    {
        $prepared = array(
            'id' => (int) ($member['id'] ?? 0),
            'venue_id' => (int) ($member['venue_id'] ?? 0),
            'member_number' => (string) ($member['member_number'] ?? ''),
            'first_name' => (string) ($member['first_name'] ?? ''),
            'last_name' => (string) ($member['last_name'] ?? ''),
            'date_of_birth' => (string) ($member['date_of_birth'] ?? ''),
            'status' => (string) ($member['status'] ?? 'active'),
            'vip' => !empty($member['vip']) ? 1 : 0,
            'membership_started_on' => (string) ($member['membership_started_on'] ?? ''),
            'membership_expires_on' => (string) ($member['membership_expires_on'] ?? ''),
            'anniversary_lock_until' => (string) ($member['anniversary_lock_until'] ?? ''),
            'last_visit_on' => (string) ($member['last_visit_on'] ?? ''),
            'notes' => (string) ($member['notes'] ?? ''),
            'profile_photo_id' => (int) ($member['profile_photo_id'] ?? 0),
            'photo_consent' => !empty($member['photo_consent']) ? 1 : 0,
            'has_photo' => !empty($member['profile_photo_id']) ? 1 : 0,
            'photo_url' => function_exists('vms_ops_pc_lookup_member_photo_url')
                ? vms_ops_pc_lookup_member_photo_url($member)
                : '',
        );

        if ($include_address) {
            $address = vms_ops_pc_unpack_address((string) ($member['address_ciphertext'] ?? ''));
            if (is_wp_error($address)) {
                $prepared['address'] = array();
            } else {
                $prepared['address'] = $address;
            }
        }

        return $prepared;
    }
}

if (!function_exists('vms_ops_pc_create_member')) {
    function vms_ops_pc_create_member(array $args)
    {
        $venue_id = absint($args['venue_id'] ?? 0);
        $member_number = vms_ops_pc_sanitize_member_number((string) ($args['member_number'] ?? ''));
        $first_name = sanitize_text_field((string) ($args['first_name'] ?? ''));
        $last_name = sanitize_text_field((string) ($args['last_name'] ?? ''));
        $dob = vms_ops_pc_normalize_dob((string) ($args['date_of_birth'] ?? ''));
        $phone_number = vms_ops_pc_sanitize_phone_number((string) ($args['phone_number'] ?? ''));
        $phone_norm = vms_ops_pc_normalize_phone_number($phone_number);
        $email_address = vms_ops_pc_normalize_email_address((string) ($args['email_address'] ?? ''));
        $notes = sanitize_textarea_field((string) ($args['notes'] ?? ''));
        $lookup_caution_flag = !empty($args['lookup_caution_flag']) ? 1 : 0;
        $lookup_caution_note = sanitize_textarea_field((string) ($args['lookup_caution_note'] ?? ''));
        $age_verified = !empty($args['age_verified']) ? 1 : 0;
        $age_verified_at = $age_verified ? (string) ($args['age_verified_at'] ?? vms_ops_now_mysql()) : null;
        $age_verified_by = $age_verified ? absint((string) ($args['age_verified_by'] ?? get_current_user_id())) : 0;
        $profile_photo_id = absint((string) ($args['profile_photo_id'] ?? 0));
        $photo_consent = !empty($args['photo_consent']) ? 1 : 0;

        if ($venue_id <= 0) {
            return new WP_Error('invalid_venue', __('Venue is required.', 'vms-ops-console-premium'));
        }
        if ($member_number === '' || $first_name === '' || $last_name === '' || $dob === '') {
            return new WP_Error('invalid_member_payload', __('Member number, first name, last name, and date of birth are required.', 'vms-ops-console-premium'));
        }
        if ((string) ($args['email_address'] ?? '') !== '' && $email_address === '') {
            return new WP_Error('invalid_email_address', __('Email address must be valid.', 'vms-ops-console-premium'));
        }
        if ($profile_photo_id > 0 && !$photo_consent) {
            return new WP_Error('photo_consent_required', __('Profile photo consent is required before saving a member photo.', 'vms-ops-console-premium'));
        }

        if (vms_ops_pc_get_member_by_number($venue_id, $member_number)) {
            return new WP_Error('member_exists', __('Member already exists for this venue.', 'vms-ops-console-premium'));
        }

        $address_pack = vms_ops_pc_pack_address(array(
            'address_line_1' => (string) ($args['address_line_1'] ?? ''),
            'address_line_2' => (string) ($args['address_line_2'] ?? ''),
            'city' => (string) ($args['city'] ?? ''),
            'state' => (string) ($args['state'] ?? ''),
            'postal_code' => (string) ($args['postal_code'] ?? ''),
        ));
        if (is_wp_error($address_pack)) {
            return $address_pack;
        }

        $today = vms_ops_today_ymd();
        $expires_on = vms_ops_pc_build_renewal_expiry_date();
        $status = sanitize_key((string) ($args['status'] ?? 'active'));
        if (!in_array($status, array('active', 'suspended', 'banned'), true)) {
            $status = 'active';
        }

        global $wpdb;
        $inserted = $wpdb->insert(
            vms_ops_table_pc_members(),
            array(
                'venue_id' => $venue_id,
                'member_number' => $member_number,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'date_of_birth' => $dob,
                'phone_number' => $phone_number !== '' ? $phone_number : null,
                'phone_norm' => $phone_norm !== '' ? $phone_norm : null,
                'email_address' => $email_address !== '' ? $email_address : null,
                'email_norm' => $email_address !== '' ? $email_address : null,
                'address_ciphertext' => (string) $address_pack['ciphertext'],
                'address_hash' => (string) $address_pack['hash'],
                'status' => $status,
                'vip' => !empty($args['vip']) ? 1 : 0,
                'age_verified' => $age_verified,
                'age_verified_at' => $age_verified_at,
                'age_verified_by' => $age_verified_by > 0 ? $age_verified_by : null,
                'profile_photo_id' => $profile_photo_id > 0 ? $profile_photo_id : null,
                'photo_consent' => $photo_consent,
                'lookup_caution_flag' => $lookup_caution_flag,
                'lookup_caution_note' => $lookup_caution_note !== '' ? $lookup_caution_note : null,
                'membership_started_on' => $today,
                'membership_expires_on' => $expires_on,
                'anniversary_lock_until' => null,
                'suspended_at' => null,
                'suspended_reason' => null,
                'banned_at' => null,
                'banned_reason' => null,
                'last_visit_on' => null,
                'last_lookup_at' => null,
                'notes' => $notes,
                'created_by' => get_current_user_id(),
                'updated_by' => null,
                'created_at' => vms_ops_now_mysql(),
                'updated_at' => null,
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s')
        );

        if ($inserted === false) {
            return vms_ops_db_write_error('member_insert_failed', __('Could not create member.', 'vms-ops-console-premium'));
        }

        $member_id = (int) $wpdb->insert_id;
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_lookup_failed', __('Member was created but could not be loaded.', 'vms-ops-console-premium'));
        }

        $audit = vms_ops_pc_audit_log($venue_id, $member_id, 'member_create', array(
            'member_number' => $member_number,
        ));
        if (is_wp_error($audit)) {
            return $audit;
        }

        return $member;
    }
}

if (!function_exists('vms_ops_pc_update_member_address')) {
    function vms_ops_pc_update_member_address(int $member_id, array $address)
    {
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_not_found', __('Member not found.', 'vms-ops-console-premium'));
        }

        $pack = vms_ops_pc_pack_address($address);
        if (is_wp_error($pack)) {
            return $pack;
        }

        global $wpdb;
        $updated = $wpdb->update(
            vms_ops_table_pc_members(),
            array(
                'address_ciphertext' => (string) $pack['ciphertext'],
                'address_hash' => (string) $pack['hash'],
                'updated_by' => get_current_user_id(),
                'updated_at' => vms_ops_now_mysql(),
            ),
            array('id' => $member_id),
            array('%s', '%s', '%d', '%s'),
            array('%d')
        );

        if ($updated === false) {
            return vms_ops_db_write_error('member_address_update_failed', __('Could not update member address.', 'vms-ops-console-premium'));
        }

        $audit = vms_ops_pc_audit_log((int) $member['venue_id'], $member_id, 'address_update', array());
        if (is_wp_error($audit)) {
            return $audit;
        }

        $fresh = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($fresh)) {
            return new WP_Error('member_lookup_failed', __('Could not load updated member.', 'vms-ops-console-premium'));
        }

        return $fresh;
    }
}

if (!function_exists('vms_ops_pc_update_member_profile_photo')) {
    function vms_ops_pc_update_member_profile_photo(int $member_id, int $profile_photo_id, bool $photo_consent = true)
    {
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_not_found', __('Member not found.', 'vms-ops-console-premium'));
        }

        $profile_photo_id = absint($profile_photo_id);
        $consent_value = $profile_photo_id > 0 && $photo_consent ? 1 : 0;
        if ($profile_photo_id > 0 && !$consent_value) {
            return new WP_Error('photo_consent_required', __('Profile photo consent is required before saving a member photo.', 'vms-ops-console-premium'));
        }

        $previous_photo_id = absint((string) ($member['profile_photo_id'] ?? 0));

        global $wpdb;
        $updated = $wpdb->update(
            vms_ops_table_pc_members(),
            array(
                'profile_photo_id' => $profile_photo_id > 0 ? $profile_photo_id : null,
                'photo_consent' => $consent_value,
                'updated_by' => get_current_user_id(),
                'updated_at' => vms_ops_now_mysql(),
            ),
            array('id' => $member_id),
            array('%d', '%d', '%d', '%s'),
            array('%d')
        );

        if ($updated === false) {
            return vms_ops_db_write_error('member_photo_update_failed', __('Could not update member photo.', 'vms-ops-console-premium'));
        }

        if ($previous_photo_id > 0 && $previous_photo_id !== $profile_photo_id) {
            wp_delete_attachment($previous_photo_id, true);
        }

        $action = 'member_photo_add';
        if ($previous_photo_id > 0 && $profile_photo_id > 0) {
            $action = 'member_photo_replace';
        } elseif ($profile_photo_id <= 0) {
            $action = 'member_photo_remove';
        }

        $audit = vms_ops_pc_audit_log((int) ($member['venue_id'] ?? 0), $member_id, $action, array(
            'previous_photo_id' => $previous_photo_id > 0 ? $previous_photo_id : null,
            'profile_photo_id' => $profile_photo_id > 0 ? $profile_photo_id : null,
            'photo_consent' => $consent_value,
        ));
        if (is_wp_error($audit)) {
            return $audit;
        }

        $fresh = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($fresh)) {
            return new WP_Error('member_lookup_failed', __('Could not load updated member.', 'vms-ops-console-premium'));
        }

        return $fresh;
    }
}

if (!function_exists('vms_ops_pc_remove_member_profile_photo')) {
    function vms_ops_pc_remove_member_profile_photo(int $member_id)
    {
        return vms_ops_pc_update_member_profile_photo($member_id, 0, false);
    }
}

if (!function_exists('vms_ops_pc_delete_member')) {
    function vms_ops_pc_delete_member(int $member_id)
    {
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_not_found', __('Member not found.', 'vms-ops-console-premium'));
        }

        global $wpdb;

        $visits_deleted = $wpdb->delete(
            vms_ops_table_pc_visits(),
            array('member_id' => $member_id),
            array('%d')
        );
        if ($visits_deleted === false) {
            return vms_ops_db_write_error('member_visit_delete_failed', __('Could not remove member visits.', 'vms-ops-console-premium'));
        }

        $scan_log_detached = $wpdb->update(
            vms_ops_table_pc_scan_log(),
            array('member_id' => null),
            array('member_id' => $member_id),
            array('%d'),
            array('%d')
        );
        if ($scan_log_detached === false) {
            return vms_ops_db_write_error('member_scan_log_detach_failed', __('Could not preserve scan history for this member.', 'vms-ops-console-premium'));
        }

        $audit_log_detached = $wpdb->update(
            vms_ops_table_pc_audit_log(),
            array('member_id' => null),
            array('member_id' => $member_id),
            array('%d'),
            array('%d')
        );
        if ($audit_log_detached === false) {
            return vms_ops_db_write_error('member_audit_log_detach_failed', __('Could not preserve audit history for this member.', 'vms-ops-console-premium'));
        }

        $deleted = $wpdb->delete(
            vms_ops_table_pc_members(),
            array('id' => $member_id),
            array('%d')
        );
        if ($deleted === false) {
            return vms_ops_db_write_error('member_delete_failed', __('Could not delete member.', 'vms-ops-console-premium'));
        }

        $profile_photo_id = absint((string) ($member['profile_photo_id'] ?? 0));
        if ($profile_photo_id > 0) {
            wp_delete_attachment($profile_photo_id, true);
        }

        $audit = vms_ops_pc_audit_log((int) ($member['venue_id'] ?? 0), null, 'member_delete', array(
            'deleted_member_id' => $member_id,
            'member_number' => (string) ($member['member_number'] ?? ''),
            'first_name' => (string) ($member['first_name'] ?? ''),
            'last_name' => (string) ($member['last_name'] ?? ''),
        ));
        if (is_wp_error($audit)) {
            return $audit;
        }

        return array(
            'member_id' => $member_id,
            'venue_id' => (int) ($member['venue_id'] ?? 0),
            'member_number' => (string) ($member['member_number'] ?? ''),
            'member_name' => trim((string) ($member['first_name'] ?? '') . ' ' . (string) ($member['last_name'] ?? '')),
        );
    }
}

if (!function_exists('vms_ops_pc_search_members')) {
    function vms_ops_pc_search_members(int $venue_id, string $query, int $limit = 20): array
    {
        global $wpdb;

        $limit = max(1, min(100, $limit));
        $query = trim($query);

        $where = array('venue_id = %d');
        $params = array($venue_id);

        if ($query !== '') {
            $where[] = '(member_number LIKE %s OR first_name LIKE %s OR last_name LIKE %s)';
            $wild = '%' . $wpdb->esc_like($query) . '%';
            $params[] = $wild;
            $params[] = $wild;
            $params[] = $wild;
        }

        $sql = 'SELECT * FROM ' . vms_ops_table_pc_members() . ' WHERE ' . implode(' AND ', $where) . ' ORDER BY last_name ASC, first_name ASC, id DESC LIMIT %d';
        $params[] = $limit;

        $prepared = $wpdb->prepare($sql, $params);
        $rows = $wpdb->get_results($prepared, ARRAY_A);

        return is_array($rows) ? $rows : array();
    }
}

if (!function_exists('vms_ops_pc_parse_pdf417_payload')) {
    function vms_ops_pc_parse_pdf417_payload(string $payload)
    {
        $payload = trim($payload);
        if ($payload === '') {
            return new WP_Error('empty_payload', __('Scan payload is required.', 'vms-ops-console-premium'));
        }

        $normalized = str_replace(array("\r\n", "\r", "\x1e", "\x1f", "\x1d"), "\n", $payload);

        $extract = static function (string $code) use ($normalized): string {
            $pattern = '/(?:^|\\n)' . preg_quote($code, '/') . '([^\\n]+)/';
            if (preg_match($pattern, $normalized, $matches) === 1) {
                return trim((string) $matches[1]);
            }
            return '';
        };

        $member_number = vms_ops_pc_sanitize_member_number($extract('DAQ'));
        $last_name = sanitize_text_field($extract('DCS'));
        $first_name = sanitize_text_field($extract('DAC'));
        $dob = vms_ops_pc_normalize_dob($extract('DBB'));

        $address = array(
            'address_line_1' => sanitize_text_field($extract('DAG')),
            'address_line_2' => '',
            'city' => sanitize_text_field($extract('DAI')),
            'state' => strtoupper(sanitize_text_field($extract('DAJ'))),
            'postal_code' => vms_ops_pc_normalize_postal_code($extract('DAK')),
        );

        if ($member_number === '' || $first_name === '' || $last_name === '' || $dob === '') {
            return new WP_Error('invalid_pdf417_payload', __('Scan payload is missing required identity fields.', 'vms-ops-console-premium'));
        }

        return array(
            'member_number' => $member_number,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'date_of_birth' => $dob,
            'address' => $address,
            'address_hash' => vms_ops_build_address_hash($address),
            'scan_hash' => vms_ops_hash_scan_payload($payload),
        );
    }
}

if (!function_exists('vms_ops_pc_address_mismatch')) {
    function vms_ops_pc_address_mismatch(array $member_row, array $parsed_scan): bool
    {
        $stored_hash = (string) ($member_row['address_hash'] ?? '');
        $scan_hash = (string) ($parsed_scan['address_hash'] ?? '');

        if ($stored_hash === '' || $scan_hash === '') {
            return false;
        }

        return !hash_equals($stored_hash, $scan_hash);
    }
}
