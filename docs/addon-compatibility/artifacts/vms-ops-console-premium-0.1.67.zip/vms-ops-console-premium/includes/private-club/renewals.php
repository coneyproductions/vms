<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_pc_build_renewal_expiry_date')) {
    function vms_ops_pc_build_renewal_expiry_date(): string
    {
        $timezone = wp_timezone();
        $date = new DateTimeImmutable('now', $timezone);
        return $date->modify('+1 year')->format('Y-m-d');
    }
}

if (!function_exists('vms_ops_pc_build_anniversary_lock_until')) {
    function vms_ops_pc_build_anniversary_lock_until(int $days): string
    {
        $days = max(0, $days);
        $timezone = wp_timezone();
        $date = new DateTimeImmutable('now', $timezone);
        return $date->modify('+' . $days . ' days')->format('Y-m-d');
    }
}

if (!function_exists('vms_ops_pc_is_anniversary_locked')) {
    function vms_ops_pc_is_anniversary_locked(array $member_row): bool
    {
        $lock_until = trim((string) ($member_row['anniversary_lock_until'] ?? ''));
        if ($lock_until === '') {
            return false;
        }

        return $lock_until >= vms_ops_today_ymd();
    }
}

if (!function_exists('vms_ops_pc_renew_member')) {
    function vms_ops_pc_renew_member(int $member_id, bool $force = false)
    {
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_not_found', __('Member not found.', 'vms-ops-console-premium'));
        }

        $raw_status = sanitize_key((string) ($member['status'] ?? 'active'));
        if ($raw_status === 'banned') {
            return new WP_Error('member_banned', __('Banned members cannot be renewed.', 'vms-ops-console-premium'));
        }

        if (!$force && vms_ops_pc_is_anniversary_locked($member)) {
            return new WP_Error('anniversary_lock_active', __('Member is currently in anniversary lock.', 'vms-ops-console-premium'));
        }

        $venue_id = (int) ($member['venue_id'] ?? 0);
        $lock_days = function_exists('vms_ops_get_venue_setting')
            ? (int) vms_ops_get_venue_setting($venue_id, 'anniversary_lock_days', 30)
            : 30;

        global $wpdb;
        $updated = $wpdb->update(
            vms_ops_table_pc_members(),
            array(
                'status' => 'active',
                'membership_expires_on' => vms_ops_pc_build_renewal_expiry_date(),
                'anniversary_lock_until' => vms_ops_pc_build_anniversary_lock_until($lock_days),
                'updated_by' => get_current_user_id(),
                'updated_at' => vms_ops_now_mysql(),
            ),
            array('id' => $member_id),
            array('%s', '%s', '%s', '%d', '%s'),
            array('%d')
        );

        if ($updated === false) {
            return vms_ops_db_write_error('member_renewal_failed', __('Could not renew member.', 'vms-ops-console-premium'));
        }

        $audit = vms_ops_pc_audit_log($venue_id, $member_id, 'renewal', array(
            'forced' => $force ? 1 : 0,
        ));
        if (is_wp_error($audit)) {
            return $audit;
        }

        $fresh = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($fresh)) {
            return new WP_Error('member_lookup_failed', __('Could not load renewed member.', 'vms-ops-console-premium'));
        }

        return $fresh;
    }
}
