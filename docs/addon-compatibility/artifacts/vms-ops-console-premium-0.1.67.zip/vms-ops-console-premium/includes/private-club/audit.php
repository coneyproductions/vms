<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_pc_audit_log')) {
    function vms_ops_pc_audit_log(int $venue_id, ?int $member_id, string $action, array $details = array())
    {
        global $wpdb;

        $payload = null;
        if (!empty($details)) {
            $payload = wp_json_encode($details);
            if (!is_string($payload)) {
                $payload = null;
            }
        }

        $inserted = $wpdb->insert(
            vms_ops_table_pc_audit_log(),
            array(
                'venue_id' => $venue_id,
                'member_id' => $member_id,
                'actor_user_id' => get_current_user_id(),
                'action' => sanitize_key($action),
                'details' => $payload,
                'created_at' => vms_ops_now_mysql(),
            ),
            array('%d', '%d', '%d', '%s', '%s', '%s')
        );

        if ($inserted === false) {
            return vms_ops_db_write_error('audit_insert_failed', __('Could not write audit entry.', 'vms-ops-console-premium'));
        }

        return true;
    }
}
