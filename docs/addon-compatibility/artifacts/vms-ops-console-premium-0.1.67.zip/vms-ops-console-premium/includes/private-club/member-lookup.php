<?php

defined('ABSPATH') || exit;

if (!defined('VMS_OPS_MEMBER_PROFILE_PHOTO_MAX_UPLOAD_BYTES')) {
    define('VMS_OPS_MEMBER_PROFILE_PHOTO_MAX_UPLOAD_BYTES', 10 * 1024 * 1024);
}

if (!defined('VMS_OPS_MEMBER_PROFILE_PHOTO_WARN_UPLOAD_BYTES')) {
    define('VMS_OPS_MEMBER_PROFILE_PHOTO_WARN_UPLOAD_BYTES', 5 * 1024 * 1024);
}

if (!defined('VMS_OPS_MEMBER_PROFILE_PHOTO_MAX_DIMENSION')) {
    define('VMS_OPS_MEMBER_PROFILE_PHOTO_MAX_DIMENSION', 1280);
}

if (!defined('VMS_OPS_MEMBER_PROFILE_PHOTO_QUALITY')) {
    define('VMS_OPS_MEMBER_PROFILE_PHOTO_QUALITY', 72);
}

if (!function_exists('vms_ops_member_lookup_policy_text')) {
    function vms_ops_member_lookup_policy_text(): string
    {
        return __('Verified Member Lookup is for known, active, previously verified members. Staff should confirm DOB or a stored profile photo match and use lookup only when they are confident they have the right person. Recheck ID whenever there is uncertainty.', 'vms-ops-console-premium');
    }
}

if (!function_exists('vms_ops_member_lookup_is_enabled')) {
    function vms_ops_member_lookup_is_enabled(?array $settings = null): bool
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        return !empty($settings['member_lookup_enabled']);
    }
}

if (!function_exists('vms_ops_member_lookup_dob_policy')) {
    function vms_ops_member_lookup_dob_policy(?array $settings = null): string
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        $policy = sanitize_key((string) ($settings['member_lookup_dob_policy'] ?? ''));
        if (in_array($policy, array('always', 'no_photo', 'never_for_active_verified'), true)) {
            return $policy;
        }

        return !empty($settings['member_lookup_require_dob_entry']) ? 'always' : 'no_photo';
    }
}

if (!function_exists('vms_ops_member_lookup_photo_match_available')) {
    function vms_ops_member_lookup_photo_match_available(?array $settings = null, array $context = array()): bool
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        if (vms_ops_member_lookup_dob_policy($settings) === 'always' || !vms_ops_member_lookup_allows_profile_photo($settings)) {
            return false;
        }

        return !empty($context['allow_lookup'])
            && !empty($context['has_photo'])
            && !empty($context['has_prior_verification'])
            && empty($context['verification_stale']);
    }
}

if (!function_exists('vms_ops_member_lookup_requires_dob_entry')) {
    function vms_ops_member_lookup_requires_dob_entry(?array $settings = null, array $context = array()): bool
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        $policy = vms_ops_member_lookup_dob_policy($settings);
        if ($policy === 'always') {
            return true;
        }

        if (empty($context)) {
            return false;
        }

        if ($policy === 'never_for_active_verified') {
            return empty($context['allow_lookup']);
        }

        return !vms_ops_member_lookup_photo_match_available($settings, $context);
    }
}

if (!function_exists('vms_ops_member_lookup_requires_confidence')) {
    function vms_ops_member_lookup_requires_confidence(?array $settings = null): bool
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        return !empty($settings['member_lookup_require_confidence']);
    }
}

if (!function_exists('vms_ops_member_lookup_allows_profile_photo')) {
    function vms_ops_member_lookup_allows_profile_photo(?array $settings = null): bool
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        return !empty($settings['member_lookup_allow_profile_photo']);
    }
}

if (!function_exists('vms_ops_member_lookup_profile_photo_upload_mode')) {
    function vms_ops_member_lookup_profile_photo_upload_mode(?array $settings = null): string
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        $mode = sanitize_key((string) ($settings['member_lookup_profile_photo_upload_mode'] ?? 'enabled'));
        if (in_array($mode, array('enabled', 'managers_only', 'disabled'), true)) {
            return $mode;
        }

        return 'enabled';
    }
}

if (!function_exists('vms_ops_member_lookup_profile_photo_upload_allowed_for_user')) {
    function vms_ops_member_lookup_profile_photo_upload_allowed_for_user(?array $settings = null, $user = null): bool
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        if (!vms_ops_member_lookup_allows_profile_photo($settings)) {
            return false;
        }

        $mode = vms_ops_member_lookup_profile_photo_upload_mode($settings);
        if ($mode === 'disabled') {
            return false;
        }

        if ($user === null && function_exists('wp_get_current_user')) {
            $user = wp_get_current_user();
        }

        if ($mode === 'managers_only') {
            return function_exists('user_can')
                ? (user_can($user, 'manage_options') || user_can($user, vms_ops_capability_manage_members_admin()))
                : (current_user_can('manage_options') || current_user_can(vms_ops_capability_manage_members_admin()));
        }

        return function_exists('user_can')
            ? (
                user_can($user, 'manage_options')
                || user_can($user, vms_ops_capability_manage_members_lite())
                || user_can($user, vms_ops_capability_manage_members_admin())
            )
            : (
                current_user_can('manage_options')
                || current_user_can(vms_ops_capability_manage_members_lite())
                || current_user_can(vms_ops_capability_manage_members_admin())
            );
    }
}

if (!function_exists('vms_ops_member_lookup_profile_photo_upload_denied_code')) {
    function vms_ops_member_lookup_profile_photo_upload_denied_code(?array $settings = null): string
    {
        return vms_ops_member_lookup_profile_photo_upload_mode($settings) === 'managers_only'
            ? 'profile_photo_manager_only'
            : 'profile_photo_disabled';
    }
}

if (!function_exists('vms_ops_member_lookup_profile_photo_upload_denied_message')) {
    function vms_ops_member_lookup_profile_photo_upload_denied_message(?array $settings = null): string
    {
        return vms_ops_member_lookup_profile_photo_upload_mode($settings) === 'managers_only'
            ? __('Only managers can upload profile photos right now.', 'vms-ops-console-premium')
            : __('Profile photo uploads are disabled in Ops settings.', 'vms-ops-console-premium');
    }
}

if (!function_exists('vms_ops_member_lookup_requires_photo_recheck')) {
    function vms_ops_member_lookup_requires_photo_recheck(?array $settings = null): bool
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        return !empty($settings['member_lookup_require_photo_recheck']);
    }
}

if (!function_exists('vms_ops_member_lookup_should_mask_dob')) {
    function vms_ops_member_lookup_should_mask_dob(?array $settings = null): bool
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        return (($settings['member_lookup_dob_display'] ?? 'full') === 'masked');
    }
}

if (!function_exists('vms_ops_member_lookup_freshness_days')) {
    function vms_ops_member_lookup_freshness_days(?array $settings = null): int
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        return max(0, (int) ($settings['member_lookup_freshness_days'] ?? 365));
    }
}

if (!function_exists('vms_ops_pc_member_photo_harden_dir')) {
    function vms_ops_pc_member_photo_harden_dir(string $path): void
    {
        $path = trim($path);
        if ($path === '') {
            return;
        }

        if (!is_dir($path)) {
            wp_mkdir_p($path);
        }

        $index = trailingslashit($path) . 'index.php';
        if (!file_exists($index)) {
            @file_put_contents($index, "<?php\n// Silence is golden.\n");
        }

        $htaccess = trailingslashit($path) . '.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess, "Deny from all\n");
        }

        $webconfig = trailingslashit($path) . 'web.config';
        if (!file_exists($webconfig)) {
            @file_put_contents($webconfig, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n");
        }
    }
}

if (!function_exists('vms_ops_pc_member_photo_private_root')) {
    function vms_ops_pc_member_photo_private_root(): string
    {
        $upload_dir = wp_upload_dir(null, false);
        $base = isset($upload_dir['basedir']) ? trim((string) $upload_dir['basedir']) : '';
        $subdir = isset($upload_dir['subdir']) ? trim((string) $upload_dir['subdir']) : '';
        if ($subdir !== '' && substr($base, -strlen($subdir)) === $subdir) {
            $base = substr($base, 0, -strlen($subdir));
        }
        if ($base === '') {
            return '';
        }

        $path = trailingslashit($base) . 'vms-private/member-photos';
        vms_ops_pc_member_photo_harden_dir($path);
        return $path;
    }
}

if (!function_exists('vms_ops_pc_member_photo_attachment_candidates')) {
    function vms_ops_pc_member_photo_attachment_candidates(int $attachment_id): array
    {
        $attachment_id = absint($attachment_id);
        if ($attachment_id <= 0) {
            return array();
        }

        $raw = trim((string) get_post_meta($attachment_id, '_wp_attached_file', true));
        if ($raw === '') {
            return array();
        }

        $root = vms_ops_pc_member_photo_private_root();
        $normalized_raw = ltrim(str_replace('\\', '/', $raw), '/');
        $marker = 'vms-private/member-photos/';
        $relative = $normalized_raw;
        $marker_pos = strpos($normalized_raw, $marker);
        if ($marker_pos !== false) {
            $relative = substr($normalized_raw, $marker_pos + strlen($marker));
        }
        $relative = ltrim((string) $relative, '/');

        $candidates = array($raw);
        if ($root !== '') {
            if ($relative !== '') {
                $candidates[] = trailingslashit($root) . $relative;
            }
            $basename = basename($relative !== '' ? $relative : $normalized_raw);
            if ($basename !== '') {
                $candidates[] = trailingslashit($root) . $basename;
            }
        }

        $deduped = array();
        foreach ($candidates as $candidate) {
            $candidate = trim((string) $candidate);
            if ($candidate === '') {
                continue;
            }
            $deduped[$candidate] = true;
        }

        return array_keys($deduped);
    }
}

if (!function_exists('vms_ops_pc_member_photo_path_within_root')) {
    function vms_ops_pc_member_photo_path_within_root(string $path): bool
    {
        $path = trim($path);
        if ($path === '') {
            return false;
        }

        $root = vms_ops_pc_member_photo_private_root();
        if ($root === '') {
            return false;
        }

        $real_path = realpath($path);
        $real_root = realpath($root);
        if ($real_path === false || $real_root === false) {
            return false;
        }

        $real_path = wp_normalize_path($real_path);
        $real_root = trailingslashit(wp_normalize_path($real_root));
        return $real_path !== '' && $real_root !== '' && strpos($real_path, $real_root) === 0;
    }
}

if (!function_exists('vms_ops_pc_member_photo_get_attached_file_filter')) {
    function vms_ops_pc_member_photo_get_attached_file_filter($file, int $attachment_id)
    {
        $attachment_id = absint($attachment_id);
        if ($attachment_id <= 0 || !get_post_meta($attachment_id, '_vms_ops_private_member_photo', true)) {
            return $file;
        }

        $candidates = function_exists('vms_ops_pc_member_photo_attachment_candidates')
            ? vms_ops_pc_member_photo_attachment_candidates($attachment_id)
            : array();

        foreach ($candidates as $candidate) {
            if (!file_exists($candidate) || !vms_ops_pc_member_photo_path_within_root($candidate)) {
                continue;
            }

            $normalized = wp_normalize_path($candidate);
            if ($normalized !== '' && trim((string) get_post_meta($attachment_id, '_wp_attached_file', true)) !== $normalized) {
                update_post_meta($attachment_id, '_wp_attached_file', $normalized);
            }

            return $normalized;
        }

        return $file;
    }
}
add_filter('get_attached_file', 'vms_ops_pc_member_photo_get_attached_file_filter', 10, 2);

if (!function_exists('vms_ops_pc_member_photo_upload_context')) {
    function vms_ops_pc_member_photo_upload_context(?bool $active = null): bool
    {
        static $is_active = false;

        if ($active !== null) {
            $is_active = $active;
        }

        return $is_active;
    }
}

if (!function_exists('vms_ops_pc_member_photo_upload_dir_filter')) {
    function vms_ops_pc_member_photo_upload_dir_filter(array $uploads): array
    {
        if (!vms_ops_pc_member_photo_upload_context()) {
            return $uploads;
        }

        $basedir = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        $baseurl = isset($uploads['baseurl']) ? (string) $uploads['baseurl'] : '';
        $subdir = isset($uploads['subdir']) ? (string) $uploads['subdir'] : '';

        if ($subdir !== '' && substr($basedir, -strlen($subdir)) === $subdir) {
            $basedir = substr($basedir, 0, -strlen($subdir));
        }
        if ($subdir !== '' && substr($baseurl, -strlen($subdir)) === $subdir) {
            $baseurl = substr($baseurl, 0, -strlen($subdir));
        }

        $basedir = rtrim($basedir, '/\\');
        $baseurl = rtrim($baseurl, '/');
        if ($basedir === '' || $baseurl === '') {
            return $uploads;
        }

        $private_subdir = '/vms-private/member-photos';
        $private_path = $basedir . $private_subdir;
        vms_ops_pc_member_photo_harden_dir($private_path);

        $uploads['path'] = $private_path;
        $uploads['basedir'] = $private_path;
        $uploads['subdir'] = $private_subdir;
        $uploads['url'] = $baseurl . $private_subdir;
        $uploads['baseurl'] = $baseurl . $private_subdir;

        return $uploads;
    }
}
add_filter('upload_dir', 'vms_ops_pc_member_photo_upload_dir_filter');

if (!function_exists('vms_ops_pc_member_photo_image_sizes_filter')) {
    function vms_ops_pc_member_photo_image_sizes_filter(array $sizes): array
    {
        if (!vms_ops_pc_member_photo_upload_context()) {
            return $sizes;
        }

        $allowed = array(
            'thumbnail' => true,
            'medium' => true,
        );

        return array_intersect_key($sizes, $allowed);
    }
}
add_filter('intermediate_image_sizes_advanced', 'vms_ops_pc_member_photo_image_sizes_filter');

if (!function_exists('vms_ops_pc_member_photo_can_view')) {
    function vms_ops_pc_member_photo_can_view(): bool
    {
        if (!is_user_logged_in()) {
            return false;
        }

        if (current_user_can('manage_options')) {
            return true;
        }

        $caps = array();
        foreach (array(
            'vms_ops_capability_manage_members_lite',
            'vms_ops_capability_manage_members_admin',
            'vms_ops_capability_member_lookup',
            'vms_ops_capability_scan_ids',
        ) as $cap_callback) {
            if (function_exists($cap_callback)) {
                $caps[] = (string) $cap_callback();
            }
        }

        foreach ($caps as $cap) {
            if ($cap !== '' && current_user_can($cap)) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('vms_ops_pc_member_photo_stream_url')) {
    function vms_ops_pc_member_photo_stream_url(int $attachment_id, string $size = 'medium'): string
    {
        $attachment_id = absint($attachment_id);
        if ($attachment_id <= 0) {
            return '';
        }

        $size = sanitize_key($size);
        if (!in_array($size, array('thumbnail', 'medium', 'full'), true)) {
            $size = 'medium';
        }

        return add_query_arg(array(
            'vms_ops_member_photo' => $attachment_id,
            'size' => $size,
        ), home_url('/'));
    }
}

if (!function_exists('vms_ops_pc_member_photo_resolve_path')) {
    /**
     * @return array{path:string,mime:string}
     */
    function vms_ops_pc_member_photo_resolve_path(int $attachment_id, string $size = 'medium')
    {
        $attachment_id = absint($attachment_id);
        if ($attachment_id <= 0) {
            return new WP_Error('profile_photo_not_found', __('Profile photo not found.', 'vms-ops-console-premium'), array('status' => 404));
        }

        $full_path = get_attached_file($attachment_id);
        if (!is_string($full_path) || $full_path === '' || !file_exists($full_path) || !vms_ops_pc_member_photo_path_within_root($full_path)) {
            $full_path = '';
            $candidates = function_exists('vms_ops_pc_member_photo_attachment_candidates')
                ? vms_ops_pc_member_photo_attachment_candidates($attachment_id)
                : array();
            foreach ($candidates as $candidate) {
                if (file_exists($candidate) && vms_ops_pc_member_photo_path_within_root($candidate)) {
                    $full_path = $candidate;
                    break;
                }
            }
            if ($full_path === '') {
                return new WP_Error('profile_photo_not_found', __('Profile photo not found.', 'vms-ops-console-premium'), array('status' => 404));
            }
        }

        $serve_path = $full_path;
        $size = sanitize_key($size);
        if ($size !== '' && $size !== 'full') {
            $intermediate = image_get_intermediate_size($attachment_id, $size);
            if (is_array($intermediate) && !empty($intermediate['file'])) {
                $candidate = trailingslashit(dirname($full_path)) . ltrim((string) $intermediate['file'], '/\\');
                if (file_exists($candidate) && vms_ops_pc_member_photo_path_within_root($candidate)) {
                    $serve_path = $candidate;
                }
            }
        }

        $mime = (string) get_post_mime_type($attachment_id);
        if ($mime === '') {
            $checked = wp_check_filetype($serve_path);
            $mime = (string) ($checked['type'] ?? 'image/jpeg');
        }

        return array(
            'path' => $serve_path,
            'mime' => $mime !== '' ? $mime : 'image/jpeg',
        );
    }
}

if (!function_exists('vms_ops_pc_member_photo_stream')) {
    function vms_ops_pc_member_photo_stream(): void
    {
        if (!vms_ops_pc_member_photo_can_view()) {
            $response_code = is_user_logged_in() ? 403 : 401;
            status_header($response_code);
            wp_die(
                esc_html__('You do not have permission to view this photo.', 'vms-ops-console-premium'),
                '',
                array('response' => $response_code)
            );
        }

        $attachment_id = isset($_GET['attachment_id']) ? absint($_GET['attachment_id']) : 0;
        if ($attachment_id <= 0 && isset($_GET['vms_ops_member_photo'])) {
            $attachment_id = absint(wp_unslash($_GET['vms_ops_member_photo']));
        }
        $size = isset($_GET['size']) ? sanitize_key((string) wp_unslash($_GET['size'])) : 'medium';
        $resolved = vms_ops_pc_member_photo_resolve_path($attachment_id, $size);
        if (is_wp_error($resolved)) {
            $response_code = (int) ($resolved->get_error_data()['status'] ?? 404);
            status_header($response_code);
            wp_die(
                esc_html($resolved->get_error_message()),
                '',
                array('response' => $response_code)
            );
        }

        nocache_headers();
        header('Content-Type: ' . sanitize_text_field((string) ($resolved['mime'] ?? 'image/jpeg')));
        header('Content-Length: ' . (string) @filesize((string) $resolved['path']));
        header('X-Robots-Tag: noindex, noimageindex');
        readfile((string) $resolved['path']);
        exit;
    }
}

if (!function_exists('vms_ops_pc_member_photo_template_redirect')) {
    function vms_ops_pc_member_photo_template_redirect(): void
    {
        if (!isset($_GET['vms_ops_member_photo'])) {
            return;
        }

        vms_ops_pc_member_photo_stream();
    }
}
add_action('template_redirect', 'vms_ops_pc_member_photo_template_redirect', 0);
add_action('admin_post_vms_ops_member_photo', 'vms_ops_pc_member_photo_stream');
add_action('admin_post_nopriv_vms_ops_member_photo', 'vms_ops_pc_member_photo_stream');

if (!function_exists('vms_ops_pc_member_photo_optimize_uploaded_file')) {
    /**
     * @param array<string,mixed> $handled
     * @return array<string,mixed>|WP_Error
     */
    function vms_ops_pc_member_photo_optimize_uploaded_file(array $handled)
    {
        $file = isset($handled['file']) ? trim((string) $handled['file']) : '';
        if ($file === '' || !file_exists($file)) {
            return new WP_Error('profile_photo_process_failed', __('Could not process image. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 422));
        }

        $editor = wp_get_image_editor($file);
        if (is_wp_error($editor)) {
            return new WP_Error('profile_photo_process_failed', __('Could not process image. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 422));
        }

        $rotated = $editor->maybe_exif_rotate();
        if (is_wp_error($rotated)) {
            return new WP_Error('profile_photo_process_failed', __('Could not process image. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 422));
        }

        $size = $editor->get_size();
        if (is_wp_error($size) || !is_array($size)) {
            return new WP_Error('profile_photo_process_failed', __('Could not process image. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 422));
        }

        $width = isset($size['width']) ? (int) $size['width'] : 0;
        $height = isset($size['height']) ? (int) $size['height'] : 0;
        $max_dimension = max(800, (int) VMS_OPS_MEMBER_PROFILE_PHOTO_MAX_DIMENSION);
        if ($width > $max_dimension || $height > $max_dimension) {
            $resized = $editor->resize($max_dimension, $max_dimension, false);
            if (is_wp_error($resized)) {
                return new WP_Error('profile_photo_process_failed', __('Could not process image. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 422));
            }
        }

        if (method_exists($editor, 'set_quality')) {
            $editor->set_quality(max(60, min(92, (int) VMS_OPS_MEMBER_PROFILE_PHOTO_QUALITY)));
        }

        $target = preg_replace('/\.[^.]+$/', '', $file) . '.jpg';
        $saved = $editor->save($target, 'image/jpeg');
        if (is_wp_error($saved) || empty($saved['path']) || !file_exists((string) $saved['path'])) {
            return new WP_Error('profile_photo_process_failed', __('Could not process image. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 422));
        }

        if ((string) $saved['path'] !== $file && file_exists($file)) {
            @unlink($file);
        }
        @chmod((string) $saved['path'], 0640);

        if ((int) @filesize((string) $saved['path']) > (int) VMS_OPS_MEMBER_PROFILE_PHOTO_MAX_UPLOAD_BYTES) {
            @unlink((string) $saved['path']);
            return new WP_Error('profile_photo_too_large', __('Image too large. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 413));
        }

        $handled['file'] = (string) $saved['path'];
        $handled['type'] = (string) ($saved['mime-type'] ?? 'image/jpeg');
        $handled['url'] = trailingslashit(dirname((string) ($handled['url'] ?? ''))) . basename((string) $saved['path']);

        return $handled;
    }
}

if (!function_exists('vms_ops_pc_lookup_normalize_name_fragment')) {
    function vms_ops_pc_lookup_normalize_name_fragment(string $value): string
    {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9\s]+/', ' ', $value);
        $value = preg_replace('/\s+/', ' ', (string) $value);
        return trim((string) $value);
    }
}

if (!function_exists('vms_ops_pc_lookup_member_full_name')) {
    function vms_ops_pc_lookup_member_full_name(array $member): string
    {
        return trim(trim((string) ($member['first_name'] ?? '')) . ' ' . trim((string) ($member['last_name'] ?? '')));
    }
}

if (!function_exists('vms_ops_pc_lookup_member_initials')) {
    function vms_ops_pc_lookup_member_initials(array $member): string
    {
        $parts = array(
            trim((string) ($member['first_name'] ?? '')),
            trim((string) ($member['last_name'] ?? '')),
        );

        $initials = '';
        foreach ($parts as $part) {
            if ($part === '') {
                continue;
            }
            $initials .= strtoupper(substr($part, 0, 1));
        }

        return $initials !== '' ? substr($initials, 0, 2) : 'M';
    }
}

if (!function_exists('vms_ops_pc_lookup_member_photo_url')) {
    function vms_ops_pc_lookup_member_photo_url(array $member, ?array $settings = null): string
    {
        if (!vms_ops_member_lookup_allows_profile_photo($settings)) {
            return '';
        }

        $attachment_id = absint((string) ($member['profile_photo_id'] ?? 0));
        if ($attachment_id <= 0) {
            return '';
        }
        return function_exists('vms_ops_pc_member_photo_stream_url')
            ? vms_ops_pc_member_photo_stream_url($attachment_id, 'medium')
            : '';
    }
}

if (!function_exists('vms_ops_pc_lookup_member_age_years')) {
    function vms_ops_pc_lookup_member_age_years(array $member): ?int
    {
        $dob = trim((string) ($member['date_of_birth'] ?? ''));
        if ($dob === '') {
            return null;
        }

        $birth = DateTimeImmutable::createFromFormat('!Y-m-d', $dob, wp_timezone());
        if (!($birth instanceof DateTimeImmutable)) {
            return null;
        }

        $today = DateTimeImmutable::createFromFormat('!Y-m-d', vms_ops_today_ymd(), wp_timezone());
        if (!($today instanceof DateTimeImmutable)) {
            $today = new DateTimeImmutable('now', wp_timezone());
        }

        return (int) $birth->diff($today)->y;
    }
}

if (!function_exists('vms_ops_pc_lookup_format_dob_display')) {
    function vms_ops_pc_lookup_format_dob_display(string $dob, bool $masked = false): string
    {
        $dob = trim($dob);
        if ($dob === '') {
            return __('Missing DOB', 'vms-ops-console-premium');
        }

        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $dob, wp_timezone());
        if (!($date instanceof DateTimeImmutable)) {
            return $dob;
        }

        if ($masked) {
            return sprintf('••/••/%04d', (int) $date->format('Y'));
        }

        return $date->format('m/d/Y');
    }
}

if (!function_exists('vms_ops_pc_lookup_partial_dob_query')) {
    function vms_ops_pc_lookup_partial_dob_query(string $query): string
    {
        $query = trim($query);
        if (preg_match('/^(\d{1,2})[\/\-](\d{1,2})$/', $query, $matches) !== 1) {
            return '';
        }

        return sprintf('%02d/%02d', (int) $matches[1], (int) $matches[2]);
    }
}

if (!function_exists('vms_ops_pc_lookup_last_verified_datetime')) {
    function vms_ops_pc_lookup_last_verified_datetime(array $member): ?DateTimeImmutable
    {
        $raw = trim((string) ($member['age_verified_at'] ?? ''));
        if ($raw === '') {
            return null;
        }

        return function_exists('vms_ops_parse_wp_datetime') ? vms_ops_parse_wp_datetime($raw) : null;
    }
}

if (!function_exists('vms_ops_pc_lookup_verification_stale')) {
    function vms_ops_pc_lookup_verification_stale(array $member, ?array $settings = null): bool
    {
        $window_days = vms_ops_member_lookup_freshness_days($settings);
        if ($window_days <= 0) {
            return false;
        }

        $verified_at = vms_ops_pc_lookup_last_verified_datetime($member);
        if (!($verified_at instanceof DateTimeImmutable)) {
            return false;
        }

        $threshold = vms_ops_now_datetime()->modify('-' . $window_days . ' days');
        return $verified_at < $threshold;
    }
}

if (!function_exists('vms_ops_pc_lookup_duplicate_name_count')) {
    function vms_ops_pc_lookup_duplicate_name_count(int $venue_id, array $member): int
    {
        $first_name = trim((string) ($member['first_name'] ?? ''));
        $last_name = trim((string) ($member['last_name'] ?? ''));
        if ($venue_id <= 0 || $first_name === '' || $last_name === '') {
            return 0;
        }

        global $wpdb;
        $count = (int) $wpdb->get_var($wpdb->prepare(
            'SELECT COUNT(1) FROM ' . vms_ops_table_pc_members() . ' WHERE venue_id = %d AND LOWER(first_name) = LOWER(%s) AND LOWER(last_name) = LOWER(%s)',
            $venue_id,
            $first_name,
            $last_name
        ));

        return max(0, $count);
    }
}

if (!function_exists('vms_ops_pc_lookup_match_score')) {
    function vms_ops_pc_lookup_match_score(array $member, string $query): int
    {
        $query = trim($query);
        if ($query === '') {
            return 0;
        }

        $query_norm = vms_ops_pc_lookup_normalize_name_fragment($query);
        $query_upper = strtoupper(trim($query));
        $query_digits = vms_ops_pc_normalize_phone_number($query);
        $query_email = vms_ops_pc_normalize_email_address($query);
        $query_dob = vms_ops_pc_normalize_dob($query);
        $query_dob_partial = vms_ops_pc_lookup_partial_dob_query($query);

        $member_number = strtoupper(trim((string) ($member['member_number'] ?? '')));
        $first_name = trim((string) ($member['first_name'] ?? ''));
        $last_name = trim((string) ($member['last_name'] ?? ''));
        $full_name = vms_ops_pc_lookup_member_full_name($member);
        $full_name_norm = vms_ops_pc_lookup_normalize_name_fragment($full_name);
        $reverse_name_norm = vms_ops_pc_lookup_normalize_name_fragment($last_name . ' ' . $first_name);
        $email_norm = strtolower(trim((string) ($member['email_norm'] ?? '')));
        $phone_norm = trim((string) ($member['phone_norm'] ?? ''));
        $dob = trim((string) ($member['date_of_birth'] ?? ''));

        if ($query_upper !== '' && $member_number === $query_upper) {
            return 200;
        }
        if ($query_email !== '' && $email_norm !== '' && $email_norm === $query_email) {
            return 190;
        }
        if ($query_digits !== '' && $phone_norm !== '' && $phone_norm === $query_digits) {
            return 185;
        }
        if ($query_dob !== '' && $dob === $query_dob) {
            return 180;
        }
        if ($query_dob_partial !== '' && $dob !== '') {
            $dob_display = vms_ops_pc_lookup_format_dob_display($dob, false);
            if (strpos($dob_display, $query_dob_partial) === 0) {
                return 170;
            }
        }
        if ($query_norm !== '' && ($full_name_norm === $query_norm || $reverse_name_norm === $query_norm)) {
            return 160;
        }
        if ($query_norm !== '' && ($full_name_norm !== '' && strpos($full_name_norm, $query_norm) === 0)) {
            return 150;
        }

        $tokens = array_values(array_filter(explode(' ', $query_norm), static function (string $value): bool {
            return $value !== '';
        }));
        if (!empty($tokens)) {
            $all_name_tokens_match = true;
            foreach ($tokens as $token) {
                if (strpos($full_name_norm, $token) === false && strpos($reverse_name_norm, $token) === false) {
                    $all_name_tokens_match = false;
                    break;
                }
            }
            if ($all_name_tokens_match) {
                return 140;
            }
        }

        if ($query_norm !== '' && (
            strpos(vms_ops_pc_lookup_normalize_name_fragment($first_name), $query_norm) !== false
            || strpos(vms_ops_pc_lookup_normalize_name_fragment($last_name), $query_norm) !== false
        )) {
            return 125;
        }
        if ($query_digits !== '' && $phone_norm !== '' && strpos($phone_norm, $query_digits) !== false) {
            return 120;
        }
        if ($query_email !== '' && $email_norm !== '' && strpos($email_norm, $query_email) !== false) {
            return 115;
        }
        if ($query_upper !== '' && $member_number !== '' && strpos($member_number, $query_upper) !== false) {
            return 110;
        }
        if ($query_norm !== '' && $email_norm !== '' && strpos($email_norm, $query_norm) !== false) {
            return 105;
        }

        return 0;
    }
}

if (!function_exists('vms_ops_pc_lookup_evaluate_member')) {
    function vms_ops_pc_lookup_evaluate_member(array $member, int $venue_id, ?array $settings = null, int $duplicate_count = 0): array
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        $status = function_exists('vms_ops_pc_member_effective_status')
            ? vms_ops_pc_member_effective_status($member)
            : sanitize_key((string) ($member['status'] ?? 'active'));
        $age_years = vms_ops_pc_lookup_member_age_years($member);
        $has_dob = trim((string) ($member['date_of_birth'] ?? '')) !== '';
        $is_21_plus = $age_years !== null ? ($age_years >= 21) : false;
        $has_prior_verification = !empty($member['age_verified']) && trim((string) ($member['age_verified_at'] ?? '')) !== '';
        $verification_stale = $has_prior_verification && vms_ops_pc_lookup_verification_stale($member, $settings);
        $photo_url = vms_ops_pc_lookup_member_photo_url($member, $settings);
        $has_photo = $photo_url !== '';
        $photo_required_block = !$has_photo && vms_ops_member_lookup_requires_photo_recheck($settings);
        $manual_caution = !empty($member['lookup_caution_flag']);
        $level = 'ok';
        $label = __('Active + previously verified', 'vms-ops-console-premium');
        $warnings = array();
        $blocking_reason = '';

        if ($status !== 'active') {
            $blocking_reason = $status === 'expired' ? 'expired_member' : 'inactive_member';
            $warnings[] = sprintf(
                /* translators: %s: membership status */
                __('Membership is %s.', 'vms-ops-console-premium'),
                strtolower($status)
            );
        }
        if (!$has_dob) {
            $blocking_reason = $blocking_reason !== '' ? $blocking_reason : 'missing_dob';
            $warnings[] = __('No DOB is on file.', 'vms-ops-console-premium');
        }
        if ($age_years !== null && $age_years < 21) {
            $blocking_reason = $blocking_reason !== '' ? $blocking_reason : 'under_21';
            $warnings[] = __('Member is under 21.', 'vms-ops-console-premium');
        }
        if (!$has_prior_verification) {
            $blocking_reason = $blocking_reason !== '' ? $blocking_reason : 'missing_verification';
            $warnings[] = __('Prior ID verification is not on file.', 'vms-ops-console-premium');
        }
        if ($verification_stale) {
            $blocking_reason = $blocking_reason !== '' ? $blocking_reason : 'stale_verification';
            $warnings[] = __('Prior verification is older than the configured freshness window.', 'vms-ops-console-premium');
        }
        if ($manual_caution) {
            $blocking_reason = $blocking_reason !== '' ? $blocking_reason : 'caution_flag';
            $warnings[] = __('Recheck ID is required for this member.', 'vms-ops-console-premium');
        }
        if (!$has_photo) {
            $warnings[] = __('No profile photo is on file.', 'vms-ops-console-premium');
            if ($photo_required_block) {
                $blocking_reason = $blocking_reason !== '' ? $blocking_reason : 'missing_photo';
            }
        }
        if ($duplicate_count > 1) {
            $warnings[] = __('Multiple similar member records were found. Confirm carefully or check ID now.', 'vms-ops-console-premium');
        }
        if (trim((string) ($member['lookup_caution_note'] ?? '')) !== '') {
            $warnings[] = trim((string) $member['lookup_caution_note']);
        }

        if ($blocking_reason !== '') {
            $level = 'danger';
            $label = __('ID Required', 'vms-ops-console-premium');
        } elseif ($duplicate_count > 1 || !$has_photo) {
            $level = 'caution';
            $label = __('Needs caution', 'vms-ops-console-premium');
        }

        return array(
            'status' => $status,
            'level' => $level,
            'label' => $label,
            'age_years' => $age_years,
            'is_21_plus' => $is_21_plus,
            'has_dob' => $has_dob,
            'has_prior_verification' => $has_prior_verification,
            'verification_stale' => $verification_stale,
            'has_photo' => $has_photo,
            'photo_required_block' => $photo_required_block,
            'manual_caution' => $manual_caution,
            'duplicate_count' => $duplicate_count,
            'blocking_reason' => $blocking_reason,
            'allow_lookup' => $blocking_reason === '',
            'warnings' => array_values(array_unique(array_filter($warnings))),
        );
    }
}

if (!function_exists('vms_ops_pc_lookup_age_badge_label')) {
    function vms_ops_pc_lookup_age_badge_label(array $evaluation): string
    {
        $age_years = isset($evaluation['age_years']) ? $evaluation['age_years'] : null;
        if (!is_int($age_years)) {
            return __('Age unknown', 'vms-ops-console-premium');
        }

        if ($age_years < 21) {
            return sprintf(__('Age %d - Under 21', 'vms-ops-console-premium'), $age_years);
        }

        return sprintf(__('Age %d - 21+', 'vms-ops-console-premium'), $age_years);
    }
}

if (!function_exists('vms_ops_pc_lookup_status_descriptor')) {
    function vms_ops_pc_lookup_status_descriptor(array $evaluation, array $member, ?array $settings = null): array
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        $dob_context = array(
            'allow_lookup' => !empty($evaluation['allow_lookup']),
            'has_photo' => !empty($evaluation['has_photo']),
            'has_prior_verification' => !empty($evaluation['has_prior_verification']),
            'verification_stale' => !empty($evaluation['verification_stale']),
        );
        $photo_match_available = vms_ops_member_lookup_photo_match_available($settings, $dob_context);
        $requires_dob_entry = vms_ops_member_lookup_requires_dob_entry($settings, $dob_context);
        $requires_confidence = $photo_match_available ? false : vms_ops_member_lookup_requires_confidence($settings);
        $has_non_blocking_caution = (int) ($evaluation['duplicate_count'] ?? 0) > 1
            || trim((string) ($member['lookup_caution_note'] ?? '')) !== '';

        $status_key = 'lookup_ok';
        $label = __('Lookup OK', 'vms-ops-console-premium');
        $level = 'ok';

        if (empty($evaluation['allow_lookup'])) {
            $status_key = 'id_required';
            $label = __('ID Required', 'vms-ops-console-premium');
            $level = 'danger';
        } elseif ($has_non_blocking_caution) {
            $status_key = 'needs_caution';
            $label = __('Needs Caution', 'vms-ops-console-premium');
            $level = 'caution';
        } elseif ($requires_dob_entry) {
            $status_key = 'dob_confirm';
            $label = __('DOB Confirm', 'vms-ops-console-premium');
            $level = 'caution';
        }

        return array(
            'status_key' => $status_key,
            'label' => $label,
            'level' => $level,
            'photo_match_available' => $photo_match_available ? 1 : 0,
            'requires_dob_entry' => $requires_dob_entry ? 1 : 0,
            'requires_confidence' => $requires_confidence ? 1 : 0,
        );
    }
}

if (!function_exists('vms_ops_pc_lookup_member_card')) {
    function vms_ops_pc_lookup_member_card(array $member, int $venue_id, ?array $settings = null, int $duplicate_count = 0): array
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        $evaluation = vms_ops_pc_lookup_evaluate_member($member, $venue_id, $settings, $duplicate_count);
        $status_descriptor = vms_ops_pc_lookup_status_descriptor($evaluation, $member, $settings);
        $last_verified_raw = trim((string) ($member['age_verified_at'] ?? ''));
        $last_lookup_raw = trim((string) ($member['last_lookup_at'] ?? ''));
        $last_visit_raw = trim((string) ($member['last_visit_on'] ?? ''));
        $status = (string) ($evaluation['status'] ?? 'active');

        return array(
            'id' => (int) ($member['id'] ?? 0),
            'member_number' => trim((string) ($member['member_number'] ?? '')),
            'full_name' => vms_ops_pc_lookup_member_full_name($member),
            'status' => $status,
            'status_label' => ucfirst($status),
            'dob_display' => vms_ops_pc_lookup_format_dob_display((string) ($member['date_of_birth'] ?? ''), vms_ops_member_lookup_should_mask_dob($settings)),
            'age_label' => vms_ops_pc_lookup_age_badge_label($evaluation),
            'last_verified_at' => $last_verified_raw,
            'last_verified_display' => $last_verified_raw !== '' && function_exists('vms_ops_pc_scan_log_format_datetime')
                ? vms_ops_pc_scan_log_format_datetime($last_verified_raw)
                : __('Never', 'vms-ops-console-premium'),
            'last_visit_on' => $last_visit_raw,
            'last_visit_display' => $last_visit_raw !== ''
                ? vms_ops_pc_lookup_format_dob_display($last_visit_raw, false)
                : __('No visit logged', 'vms-ops-console-premium'),
            'last_lookup_at' => $last_lookup_raw,
            'last_lookup_display' => $last_lookup_raw !== '' && function_exists('vms_ops_pc_scan_log_format_datetime')
                ? vms_ops_pc_scan_log_format_datetime($last_lookup_raw)
                : __('No lookup logged', 'vms-ops-console-premium'),
            'phone_suffix' => substr(trim((string) ($member['phone_norm'] ?? '')), -4),
            'email_address' => trim((string) ($member['email_address'] ?? '')),
            'lookup_level' => (string) ($status_descriptor['level'] ?? ($evaluation['level'] ?? 'ok')),
            'lookup_label' => (string) ($status_descriptor['label'] ?? ($evaluation['label'] ?? '')),
            'lookup_status_key' => (string) ($status_descriptor['status_key'] ?? 'lookup_ok'),
            'blocking_reason' => (string) ($evaluation['blocking_reason'] ?? ''),
            'warnings' => (array) ($evaluation['warnings'] ?? array()),
            'duplicate_count' => (int) ($evaluation['duplicate_count'] ?? 0),
            'has_photo' => !empty($evaluation['has_photo']) ? 1 : 0,
            'photo_url' => vms_ops_pc_lookup_member_photo_url($member, $settings),
            'photo_initials' => vms_ops_pc_lookup_member_initials($member),
            'allow_lookup' => !empty($evaluation['allow_lookup']) ? 1 : 0,
            'has_prior_verification' => !empty($evaluation['has_prior_verification']) ? 1 : 0,
            'verification_stale' => !empty($evaluation['verification_stale']) ? 1 : 0,
            'photo_match_available' => !empty($status_descriptor['photo_match_available']) ? 1 : 0,
            'requires_dob_entry' => !empty($status_descriptor['requires_dob_entry']) ? 1 : 0,
            'requires_confidence' => !empty($status_descriptor['requires_confidence']) ? 1 : 0,
        );
    }
}

if (!function_exists('vms_ops_pc_lookup_member_detail')) {
    function vms_ops_pc_lookup_member_detail(array $member, int $venue_id, ?array $settings = null): array
    {
        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        $duplicate_count = vms_ops_pc_lookup_duplicate_name_count($venue_id, $member);
        $card = vms_ops_pc_lookup_member_card($member, $venue_id, $settings, $duplicate_count);
        $card['policy_text'] = vms_ops_member_lookup_policy_text();
        $card['dob_full_display'] = vms_ops_pc_lookup_format_dob_display((string) ($member['date_of_birth'] ?? ''), false);
        $card['dob_policy'] = vms_ops_member_lookup_dob_policy($settings);
        $card['photo_consent'] = !empty($member['photo_consent']) ? 1 : 0;
        $card['lookup_caution_flag'] = !empty($member['lookup_caution_flag']) ? 1 : 0;
        $card['lookup_caution_note'] = trim((string) ($member['lookup_caution_note'] ?? ''));
        $card['notes'] = trim((string) ($member['notes'] ?? ''));
        $card['age_verified_at'] = trim((string) ($member['age_verified_at'] ?? ''));
        return $card;
    }
}

if (!function_exists('vms_ops_pc_lookup_sort_results')) {
    function vms_ops_pc_lookup_sort_results(array $left, array $right): int
    {
        $score_compare = (int) ($right['_lookup_score'] ?? 0) <=> (int) ($left['_lookup_score'] ?? 0);
        if ($score_compare !== 0) {
            return $score_compare;
        }

        $level_rank = array('ok' => 0, 'caution' => 1, 'danger' => 2);
        $left_level = $level_rank[(string) ($left['lookup_level'] ?? 'danger')] ?? 9;
        $right_level = $level_rank[(string) ($right['lookup_level'] ?? 'danger')] ?? 9;
        if ($left_level !== $right_level) {
            return $left_level <=> $right_level;
        }

        return strcasecmp((string) ($left['full_name'] ?? ''), (string) ($right['full_name'] ?? ''));
    }
}

if (!function_exists('vms_ops_pc_lookup_search_members')) {
    function vms_ops_pc_lookup_search_members(int $venue_id, string $query, int $limit = 20, ?array $settings = null): array
    {
        global $wpdb;

        $limit = max(1, min(50, $limit));
        $query = trim($query);
        if ($venue_id <= 0 || $query === '') {
            return array(
                'items' => array(),
                'total_matches' => 0,
                'truncated' => 0,
            );
        }

        $settings = is_array($settings) ? $settings : (function_exists('vms_ops_get_settings') ? vms_ops_get_settings() : array());
        $upper_query = strtoupper($query);
        $name_like = '%' . $wpdb->esc_like($query) . '%';
        $compact_like = '%' . $wpdb->esc_like(str_replace(',', ' ', $query)) . '%';
        $phone_digits = vms_ops_pc_normalize_phone_number($query);
        $phone_like = '%' . $wpdb->esc_like($phone_digits) . '%';
        $email_query = vms_ops_pc_normalize_email_address($query);
        $dob_query = vms_ops_pc_normalize_dob($query);
        $dob_partial = vms_ops_pc_lookup_partial_dob_query($query);

        $clauses = array(
            'member_number LIKE %s',
            'first_name LIKE %s',
            'last_name LIKE %s',
            'CONCAT(first_name, " ", last_name) LIKE %s',
            'CONCAT(last_name, " ", first_name) LIKE %s',
            'CONCAT(last_name, ", ", first_name) LIKE %s',
        );
        $params = array(
            $venue_id,
            '%' . $wpdb->esc_like($upper_query) . '%',
            $name_like,
            $name_like,
            $compact_like,
            $compact_like,
            $name_like,
        );

        if ($phone_digits !== '') {
            $clauses[] = 'phone_norm LIKE %s';
            $params[] = $phone_like;
        }
        if ($email_query !== '') {
            $clauses[] = 'email_norm LIKE %s';
            $params[] = '%' . $wpdb->esc_like($email_query) . '%';
        }
        if ($dob_query !== '') {
            $clauses[] = 'date_of_birth = %s';
            $params[] = $dob_query;
        }
        if ($dob_partial !== '') {
            $clauses[] = 'DATE_FORMAT(date_of_birth, "%%m/%%d") = %s';
            $params[] = $dob_partial;
        }

        $sql = 'SELECT * FROM ' . vms_ops_table_pc_members()
            . ' WHERE venue_id = %d AND (' . implode(' OR ', $clauses) . ')'
            . ' ORDER BY last_name ASC, first_name ASC, id DESC LIMIT 75';
        $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        $rows = is_array($rows) ? $rows : array();

        $items = array();
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $score = vms_ops_pc_lookup_match_score($row, $query);
            if ($score <= 0) {
                continue;
            }

            $duplicate_count = vms_ops_pc_lookup_duplicate_name_count($venue_id, $row);
            $card = vms_ops_pc_lookup_member_card($row, $venue_id, $settings, $duplicate_count);
            $card['_lookup_score'] = $score;
            $items[] = $card;
        }

        usort($items, 'vms_ops_pc_lookup_sort_results');
        $truncated = count($items) > $limit ? 1 : 0;
        $total_matches = count($items);
        $items = array_slice($items, 0, $limit);

        return array(
            'items' => $items,
            'total_matches' => $total_matches,
            'truncated' => $truncated,
        );
    }
}

if (!function_exists('vms_ops_pc_lookup_safe_search_term')) {
    function vms_ops_pc_lookup_safe_search_term(string $value): string
    {
        $value = sanitize_text_field($value);
        if (strlen($value) <= 120) {
            return $value;
        }

        return substr($value, 0, 120);
    }
}

if (!function_exists('vms_ops_pc_member_lookup_log')) {
    function vms_ops_pc_member_lookup_log(int $venue_id, ?int $member_id, string $action, array $details = array())
    {
        $user = wp_get_current_user();
        if ($user instanceof WP_User) {
            $details['actor_username'] = (string) $user->user_login;
            $details['actor_name'] = (string) $user->display_name;
        }

        if (isset($details['search_term'])) {
            $details['search_term'] = vms_ops_pc_lookup_safe_search_term((string) $details['search_term']);
        }

        return vms_ops_pc_audit_log($venue_id, $member_id, $action, $details);
    }
}

if (!function_exists('vms_ops_pc_lookup_compare_dob_input')) {
    function vms_ops_pc_lookup_compare_dob_input(string $stored_dob, string $input): bool
    {
        $stored_dob = trim($stored_dob);
        $input = trim($input);
        if ($stored_dob === '' || $input === '') {
            return false;
        }

        return vms_ops_pc_normalize_dob($stored_dob) === vms_ops_pc_normalize_dob($input);
    }
}

if (!function_exists('vms_ops_pc_lookup_upload_profile_photo')) {
    function vms_ops_pc_lookup_upload_profile_photo(array $file)
    {
        if (empty($file['tmp_name']) || !is_uploaded_file((string) $file['tmp_name'])) {
            return new WP_Error('invalid_profile_photo', __('A valid profile photo upload is required.', 'vms-ops-console-premium'), array('status' => 400));
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $size = isset($file['size']) ? (int) $file['size'] : 0;
        if ($size <= 0 && !empty($file['tmp_name']) && file_exists((string) $file['tmp_name'])) {
            $size = (int) @filesize((string) $file['tmp_name']);
        }
        if ($size > (int) VMS_OPS_MEMBER_PROFILE_PHOTO_MAX_UPLOAD_BYTES) {
            return new WP_Error('profile_photo_too_large', __('Image too large. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 413));
        }

        vms_ops_pc_member_photo_upload_context(true);
        try {
            $handled = wp_handle_upload($file, array(
                'test_form' => false,
                'mimes' => array(
                    'jpg|jpeg|jpe' => 'image/jpeg',
                    'png' => 'image/png',
                    'webp' => 'image/webp',
                    'heic|heics' => 'image/heic',
                    'heif|heifs' => 'image/heif',
                ),
            ));

            if (!is_array($handled) || !empty($handled['error']) || empty($handled['file'])) {
                return new WP_Error('profile_photo_upload_failed', __('Could not process image. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 422));
            }

            $optimized = vms_ops_pc_member_photo_optimize_uploaded_file($handled);
            if (is_wp_error($optimized)) {
                if (!empty($handled['file']) && file_exists((string) $handled['file'])) {
                    @unlink((string) $handled['file']);
                }
                return $optimized;
            }
            $handled = $optimized;

            $attachment = array(
                'post_mime_type' => (string) ($handled['type'] ?? 'image/jpeg'),
                'post_title' => sanitize_file_name(pathinfo((string) ($file['name'] ?? 'member-photo'), PATHINFO_FILENAME)),
                'post_content' => '',
                'post_status' => 'inherit',
            );

            $attach_id = wp_insert_attachment($attachment, (string) $handled['file']);
            if (is_wp_error($attach_id) || $attach_id <= 0) {
                if (!empty($handled['file']) && file_exists((string) $handled['file'])) {
                    @unlink((string) $handled['file']);
                }
                return new WP_Error('profile_photo_attachment_failed', __('Could not process image. Try a smaller photo.', 'vms-ops-console-premium'), array('status' => 500));
            }

            update_post_meta((int) $attach_id, '_vms_ops_private_member_photo', 1);
            update_post_meta((int) $attach_id, '_wp_attached_file', wp_normalize_path((string) $handled['file']));

            $metadata = wp_generate_attachment_metadata((int) $attach_id, (string) $handled['file']);
            if (is_array($metadata)) {
                wp_update_attachment_metadata((int) $attach_id, $metadata);
            }
        } finally {
            vms_ops_pc_member_photo_upload_context(false);
        }

        return (int) $attach_id;
    }
}

if (!function_exists('vms_ops_pc_lookup_mark_age_verified')) {
    function vms_ops_pc_lookup_mark_age_verified(int $member_id)
    {
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_not_found', __('Member not found.', 'vms-ops-console-premium'));
        }

        global $wpdb;
        $updated = $wpdb->update(
            vms_ops_table_pc_members(),
            array(
                'age_verified' => 1,
                'age_verified_at' => vms_ops_now_mysql(),
                'age_verified_by' => get_current_user_id() ?: null,
                'updated_by' => get_current_user_id() ?: null,
                'updated_at' => vms_ops_now_mysql(),
            ),
            array('id' => $member_id),
            array('%d', '%s', '%d', '%d', '%s'),
            array('%d')
        );

        if ($updated === false) {
            return vms_ops_db_write_error('member_verify_update_failed', __('Could not update member verification.', 'vms-ops-console-premium'));
        }

        $fresh = vms_ops_pc_get_member_by_id($member_id);
        return is_array($fresh)
            ? $fresh
            : new WP_Error('member_lookup_failed', __('Could not load the verified member.', 'vms-ops-console-premium'));
    }
}

if (!function_exists('vms_ops_pc_lookup_mark_last_lookup')) {
    function vms_ops_pc_lookup_mark_last_lookup(int $member_id)
    {
        $member = vms_ops_pc_get_member_by_id($member_id);
        if (!is_array($member)) {
            return new WP_Error('member_not_found', __('Member not found.', 'vms-ops-console-premium'));
        }

        global $wpdb;
        $updated = $wpdb->update(
            vms_ops_table_pc_members(),
            array(
                'last_lookup_at' => vms_ops_now_mysql(),
                'updated_by' => get_current_user_id() ?: null,
                'updated_at' => vms_ops_now_mysql(),
            ),
            array('id' => $member_id),
            array('%s', '%d', '%s'),
            array('%d')
        );

        if ($updated === false) {
            return vms_ops_db_write_error('member_lookup_stamp_failed', __('Could not update the member lookup timestamp.', 'vms-ops-console-premium'));
        }

        return true;
    }
}
