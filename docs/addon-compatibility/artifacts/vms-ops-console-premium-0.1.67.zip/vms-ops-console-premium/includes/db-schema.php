<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_db_option_key')) {
    function vms_ops_db_option_key(): string
    {
        return 'vms_ops_console_db_version';
    }
}

if (!function_exists('vms_ops_db_target_version')) {
    function vms_ops_db_target_version(): string
    {
        return '1.1.0';
    }
}

if (!function_exists('vms_ops_table_pc_members')) {
    function vms_ops_table_pc_members(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'vms_pc_members';
    }
}

if (!function_exists('vms_ops_table_pc_visits')) {
    function vms_ops_table_pc_visits(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'vms_pc_visits';
    }
}

if (!function_exists('vms_ops_table_pc_scan_log')) {
    function vms_ops_table_pc_scan_log(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'vms_pc_scan_log';
    }
}

if (!function_exists('vms_ops_table_pc_audit_log')) {
    function vms_ops_table_pc_audit_log(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'vms_pc_audit_log';
    }
}

if (!function_exists('vms_ops_table_alerts')) {
    function vms_ops_table_alerts(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'vms_ops_alerts';
    }
}

if (!function_exists('vms_ops_table_presence')) {
    function vms_ops_table_presence(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'vms_ops_presence';
    }
}

if (!function_exists('vms_ops_now_datetime')) {
    function vms_ops_now_datetime(): DateTimeImmutable
    {
        if (function_exists('current_datetime')) {
            $now = current_datetime();
            if ($now instanceof DateTimeImmutable) {
                return $now;
            }
            if ($now instanceof DateTimeInterface) {
                return new DateTimeImmutable($now->format('Y-m-d H:i:s'), $now->getTimezone());
            }
        }

        return new DateTimeImmutable('now', wp_timezone());
    }
}

if (!function_exists('vms_ops_now_timestamp')) {
    function vms_ops_now_timestamp(): int
    {
        return (int) vms_ops_now_datetime()->getTimestamp();
    }
}

if (!function_exists('vms_ops_parse_wp_datetime')) {
    function vms_ops_parse_wp_datetime(string $value): ?DateTimeImmutable
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $tz = wp_timezone();
        $normalized = preg_replace('/\s+/', ' ', str_replace('T', ' ', $value));
        $normalized = is_string($normalized) ? trim($normalized) : $value;

        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $normalized)) {
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $normalized, $tz);
            return $parsed instanceof DateTimeImmutable ? $parsed : null;
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $normalized)) {
            $normalized .= ':00';
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $normalized)) {
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $normalized, $tz);
            return $parsed instanceof DateTimeImmutable ? $parsed : null;
        }

        try {
            return (new DateTimeImmutable($value, $tz))->setTimezone($tz);
        } catch (Exception $exception) {
            return null;
        }
    }
}

if (!function_exists('vms_ops_now_mysql')) {
    function vms_ops_now_mysql(): string
    {
        return (string) wp_date('Y-m-d H:i:s', vms_ops_now_timestamp(), wp_timezone());
    }
}

if (!function_exists('vms_ops_today_ymd')) {
    function vms_ops_today_ymd(): string
    {
        return (string) wp_date('Y-m-d', vms_ops_now_timestamp(), wp_timezone());
    }
}

if (!function_exists('vms_ops_db_write_error')) {
    function vms_ops_db_write_error(string $code, string $message): WP_Error
    {
        global $wpdb;

        $db_error = is_string($wpdb->last_error) ? trim($wpdb->last_error) : '';
        $text = $db_error !== '' ? ($message . ' ' . $db_error) : $message;

        return new WP_Error($code, $text, array(
            'db_error' => $db_error,
        ));
    }
}

if (!function_exists('vms_ops_install_schema')) {
    function vms_ops_install_schema()
    {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql_members = 'CREATE TABLE ' . vms_ops_table_pc_members() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            venue_id BIGINT(20) UNSIGNED NOT NULL,
            member_number VARCHAR(64) NOT NULL,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            date_of_birth DATE NOT NULL,
            phone_number VARCHAR(40) NULL,
            phone_norm VARCHAR(40) NULL,
            email_address VARCHAR(190) NULL,
            email_norm VARCHAR(190) NULL,
            address_ciphertext LONGTEXT NULL,
            address_hash CHAR(64) NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            vip TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
            age_verified TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
            age_verified_at DATETIME NULL,
            age_verified_by BIGINT(20) UNSIGNED NULL,
            profile_photo_id BIGINT(20) UNSIGNED NULL,
            photo_consent TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
            lookup_caution_flag TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
            lookup_caution_note TEXT NULL,
            membership_started_on DATE NOT NULL,
            membership_expires_on DATE NOT NULL,
            anniversary_lock_until DATE NULL,
            suspended_at DATETIME NULL,
            suspended_reason TEXT NULL,
            banned_at DATETIME NULL,
            banned_reason TEXT NULL,
            last_visit_on DATE NULL,
            last_lookup_at DATETIME NULL,
            notes TEXT NULL,
            created_by BIGINT(20) UNSIGNED NOT NULL,
            updated_by BIGINT(20) UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY venue_member_number (venue_id, member_number),
            KEY venue_status (venue_id, status),
            KEY member_name (last_name, first_name),
            KEY phone_norm (phone_norm),
            KEY email_norm (email_norm),
            KEY age_verified (age_verified, age_verified_at),
            KEY membership_expires (membership_expires_on),
            KEY birthday_idx (date_of_birth)
        ) {$charset_collate};";

        $sql_visits = 'CREATE TABLE ' . vms_ops_table_pc_visits() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            member_id BIGINT(20) UNSIGNED NOT NULL,
            venue_id BIGINT(20) UNSIGNED NOT NULL,
            visit_date DATE NOT NULL,
            checked_in_at DATETIME NOT NULL,
            scanned_by_user_id BIGINT(20) UNSIGNED NOT NULL,
            source VARCHAR(20) NOT NULL,
            notes VARCHAR(190) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY member_venue_visit_date (member_id, venue_id, visit_date),
            KEY venue_visit_date (venue_id, visit_date),
            KEY member_visit_date (member_id, visit_date)
        ) {$charset_collate};";

        $sql_scan_log = 'CREATE TABLE ' . vms_ops_table_pc_scan_log() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            venue_id BIGINT(20) UNSIGNED NOT NULL,
            member_id BIGINT(20) UNSIGNED NULL,
            event_id BIGINT(20) UNSIGNED NULL,
            scanner_user_id BIGINT(20) UNSIGNED NOT NULL,
            console_type VARCHAR(20) NOT NULL,
            scan_type VARCHAR(20) NOT NULL,
            scan_hash CHAR(64) NOT NULL,
            scan_reference VARCHAR(120) NULL,
            result_code VARCHAR(40) NOT NULL,
            result_message VARCHAR(190) NULL,
            payload_meta LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY venue_created (venue_id, created_at),
            KEY event_hash_result (event_id, scan_hash, result_code),
            KEY member_created (member_id, created_at)
        ) {$charset_collate};";

        $sql_audit_log = 'CREATE TABLE ' . vms_ops_table_pc_audit_log() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            venue_id BIGINT(20) UNSIGNED NOT NULL,
            member_id BIGINT(20) UNSIGNED NULL,
            actor_user_id BIGINT(20) UNSIGNED NOT NULL,
            action VARCHAR(64) NOT NULL,
            details LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY venue_created (venue_id, created_at),
            KEY member_created (member_id, created_at),
            KEY actor_created (actor_user_id, created_at)
        ) {$charset_collate};";

        $sql_alerts = 'CREATE TABLE ' . vms_ops_table_alerts() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            venue_id BIGINT(20) UNSIGNED NOT NULL,
            sender_user_id BIGINT(20) UNSIGNED NOT NULL,
            preset_key VARCHAR(80) NULL,
            message TEXT NOT NULL,
            urgency VARCHAR(20) NOT NULL DEFAULT 'normal',
            console_type VARCHAR(20) NOT NULL DEFAULT 'ops',
            routed_user_ids LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            acknowledged_by BIGINT(20) UNSIGNED NULL,
            acknowledged_at DATETIME NULL,
            PRIMARY KEY  (id),
            KEY venue_created (venue_id, created_at),
            KEY ack_lookup (venue_id, acknowledged_at)
        ) {$charset_collate};";

        $sql_presence = 'CREATE TABLE ' . vms_ops_table_presence() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            venue_id BIGINT(20) UNSIGNED NOT NULL,
            device_id VARCHAR(120) NOT NULL,
            status VARCHAR(20) NOT NULL,
            shift_started_at DATETIME NOT NULL,
            last_seen_at DATETIME NOT NULL,
            shift_ended_at DATETIME NULL,
            console_type VARCHAR(20) NULL,
            PRIMARY KEY  (id),
            KEY user_venue_status (user_id, venue_id, status),
            KEY venue_status_seen (venue_id, status, last_seen_at),
            KEY device_status (device_id, status)
        ) {$charset_collate};";

        dbDelta($sql_members);
        dbDelta($sql_visits);
        dbDelta($sql_scan_log);
        dbDelta($sql_audit_log);
        dbDelta($sql_alerts);
        dbDelta($sql_presence);

        $required_tables = array(
            vms_ops_table_pc_members(),
            vms_ops_table_pc_visits(),
            vms_ops_table_pc_scan_log(),
            vms_ops_table_pc_audit_log(),
            vms_ops_table_alerts(),
            vms_ops_table_presence(),
        );

        foreach ($required_tables as $table) {
            $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
            if ($exists !== $table) {
                return new WP_Error(
                    'schema_install_failed',
                    sprintf(__('Table creation failed for %s.', 'vms-ops-console-premium'), $table)
                );
            }
        }

        update_option(vms_ops_db_option_key(), vms_ops_db_target_version(), false);
        return true;
    }
}

if (!function_exists('vms_ops_maybe_upgrade_schema')) {
    function vms_ops_maybe_upgrade_schema()
    {
        $current = (string) get_option(vms_ops_db_option_key(), '');
        $target = vms_ops_db_target_version();

        if ($current === $target) {
            return true;
        }

        return vms_ops_install_schema();
    }
}
