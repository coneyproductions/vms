<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_ticket_normalize_scan_reference')) {
    function vms_ops_ticket_normalize_scan_reference(string $value): string
    {
        $value = trim($value);
        $value = preg_replace('/\s+/', '', $value);
        return sanitize_text_field((string) $value);
    }
}

if (!function_exists('vms_ops_ticket_scan_extract_reference')) {
    function vms_ops_ticket_scan_extract_reference(string $scan_reference_raw): array
    {
        $original = vms_ops_ticket_normalize_scan_reference($scan_reference_raw);
        if ($original === '') {
            return array(
                'scan_reference' => '',
                'scanned_event_id' => 0,
            );
        }

        $parts = wp_parse_url($scan_reference_raw);
        if (!is_array($parts) || empty($parts['query'])) {
            return array(
                'scan_reference' => $original,
                'scanned_event_id' => 0,
            );
        }

        $query = array();
        parse_str((string) $parts['query'], $query);
        if (!is_array($query)) {
            return array(
                'scan_reference' => $original,
                'scanned_event_id' => 0,
            );
        }

        $ticket_id = vms_ops_ticket_normalize_scan_reference((string) ($query['ticket_id'] ?? ''));
        if ($ticket_id === '') {
            return array(
                'scan_reference' => $original,
                'scanned_event_id' => 0,
            );
        }

        return array(
            'scan_reference' => $ticket_id,
            'scanned_event_id' => absint($query['event_id'] ?? 0),
        );
    }
}

if (!function_exists('vms_ops_log_diagnostic_event')) {
    function vms_ops_log_diagnostic_event(string $action, array $details = array()): void
    {
        $payload = array_merge(array(
            'action' => sanitize_key($action),
            'timestamp_site' => vms_ops_now_mysql(),
            'user_id' => get_current_user_id(),
            'linked_staff_id' => (int) get_user_meta(get_current_user_id(), '_vms_staff_id', true),
        ), $details);

        $json = wp_json_encode($payload);
        if (is_string($json) && $json !== '') {
            error_log('VMS Ops Console diagnostic ' . $json);
        }
    }
}

if (!function_exists('vms_ops_ticket_scanner_diagnostic_context')) {
    function vms_ops_ticket_scanner_diagnostic_context(
        array $event,
        int $event_id,
        string $reason,
        string $source,
        ?DateTimeInterface $opens = null,
        ?DateTimeInterface $closes = null,
        ?DateTimeInterface $event_end = null,
        ?DateTimeInterface $reopen_closes = null
    ): array {
        $format = static function (?DateTimeInterface $value): string {
            return $value instanceof DateTimeInterface ? $value->format('Y-m-d H:i:s') : '';
        };

        return array(
            'reason' => $reason,
            'event_id' => (int) $event_id,
            'now' => vms_ops_now_mysql(),
            'event_showtime' => (string) ($event['start_at'] ?? ''),
            'checkin_open_time' => $format($opens),
            'checkin_close_time' => $format($closes),
            'event_end_time' => $format($event_end),
            'event_status' => (string) ($event['scan_state'] ?? ($event['status'] ?? '')),
            'previous_event_status' => (string) ($event['previous_scan_state'] ?? ''),
            'scanner_session_expires_at' => '',
            'route' => '/ticket/checkin',
            'source' => $source,
            'reopen_closes_at' => $format($reopen_closes),
        );
    }
}

if (!function_exists('vms_ops_ticket_checkin_assert_window')) {
    function vms_ops_ticket_checkin_assert_window(array $event, int $event_id)
    {
        $tz = wp_timezone();
        $now = vms_ops_now_datetime();

        $start_raw = (string) ($event['start_at'] ?? '');
        if ($start_raw === '') {
            return true;
        }

        $start = vms_ops_parse_wp_datetime($start_raw);
        if (!($start instanceof DateTimeImmutable)) {
            static $start_parse_error_logged = false;
            if (!$start_parse_error_logged) {
                $start_parse_error_logged = true;
                error_log('VMS Ops Console check-in window parse failed for event start_at.');
            }
            return true;
        }

        $opens = function_exists('vms_ops_ticket_checkin_open_datetime') ? vms_ops_ticket_checkin_open_datetime($start) : $start;

        $open_day_ymd = (string) apply_filters(
            'vms_ops_ticket_checkin_earliest_ymd',
            $opens->format('Y-m-d'),
            $event,
            (int) $event_id
        );
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $open_day_ymd)) {
            $filtered_open = vms_ops_parse_wp_datetime($open_day_ymd . ' ' . $opens->format('H:i:s'));
            if ($filtered_open instanceof DateTimeImmutable) {
                $opens = $filtered_open;
            }
        }

        $closes = vms_ops_parse_wp_datetime((string) ($event['checkin_close_at'] ?? ($event['scan_closes_at'] ?? '')));
        $raw_event_end = vms_ops_parse_wp_datetime((string) ($event['end_at'] ?? ''));
        $resolved_event_end = vms_ops_ticket_resolve_operational_event_end($start, $raw_event_end, null);
        $event_end = ($resolved_event_end['datetime'] ?? null) instanceof DateTimeImmutable
            ? $resolved_event_end['datetime']
            : vms_ops_ticket_default_event_end_datetime($start);

        if (!($closes instanceof DateTimeImmutable)) {
            $closes = vms_ops_ticket_apply_post_show_buffer($event_end);
        }

        $filtered_opens = apply_filters('vms_ops_ticket_checkin_opens_at', $opens, $event, (int) $event_id);
        if ($filtered_opens instanceof DateTimeInterface) {
            $opens = new DateTimeImmutable($filtered_opens->format('Y-m-d H:i:s'), $tz);
        }

        $filtered_closes = apply_filters('vms_ops_ticket_checkin_closes_at', $closes, $event, (int) $event_id);
        if ($filtered_closes instanceof DateTimeInterface) {
            $closes = new DateTimeImmutable($filtered_closes->format('Y-m-d H:i:s'), $tz);
        }

        $buffer_hours = vms_ops_ticket_post_show_scan_buffer_hours();
        $reopen_closes = function_exists('vms_ops_ticket_apply_reopen_past_window')
            ? vms_ops_ticket_apply_reopen_past_window($closes)
            : null;

        $effective_close = $reopen_closes instanceof DateTimeImmutable ? $reopen_closes : $closes;
        $eligibility = vms_ops_ticket_get_scanner_eligibility(array(
            'now' => $now,
            'start_at' => $start,
            'checkin_open_at' => $opens,
            'checkin_close_at' => $effective_close,
            'event_status' => (string) ($event['scan_state'] ?? ($event['status'] ?? '')),
        ));

        if (($eligibility['reason'] ?? '') === 'CHECK_IN_NOT_OPEN_YET') {
            vms_ops_log_diagnostic_event('scanner_close_decision', vms_ops_ticket_scanner_diagnostic_context(
                $event,
                $event_id,
                'CHECK_IN_NOT_OPEN_YET',
                'api_response',
                $opens,
                $closes,
                $event_end,
                $reopen_closes
            ));
            $open_label = vms_ops_ticket_format_console_datetime_label($opens);
            return new WP_Error(
                'checkin_not_open',
                sprintf(__('Check-in opens %s.', 'vms-ops-console-premium'), $open_label),
                array(
                    'status' => 409,
                    'opens_at' => $opens->format('Y-m-d H:i:s'),
                    'checkin_close_at' => $closes->format('Y-m-d H:i:s'),
                    'event_end_at' => $event_end->format('Y-m-d H:i:s'),
                    'event_id' => (int) $event_id,
                )
            );
        }

        if (($eligibility['reason'] ?? '') === 'CHECK_IN_CLOSED') {
            vms_ops_log_diagnostic_event('scanner_close_decision', vms_ops_ticket_scanner_diagnostic_context(
                $event,
                $event_id,
                'CHECK_IN_CLOSED',
                'api_response',
                $opens,
                $closes,
                $event_end,
                $reopen_closes
            ));
            $closed_message = $reopen_closes instanceof DateTimeImmutable
                ? sprintf(
                    __('This event is outside the reopened testing window. Scanning closed at %s.', 'vms-ops-console-premium'),
                    vms_ops_ticket_format_console_datetime_label($reopen_closes)
                )
                : (
                    $buffer_hours > 0
                        ? sprintf(
                            __('This event is outside the %1$d-hour post-show scan buffer. Scanning closed at %2$s.', 'vms-ops-console-premium'),
                            $buffer_hours,
                            vms_ops_ticket_format_console_datetime_label($closes)
                        )
                        : __('This event has ended. Tickets for this event are expired.', 'vms-ops-console-premium')
                );
            return new WP_Error(
                'checkin_closed',
                $closed_message,
                array(
                    'status' => 409,
                    'closes_at' => $closes->format('Y-m-d H:i:s'),
                    'event_end_at' => $event_end->format('Y-m-d H:i:s'),
                    'buffer_hours' => $buffer_hours,
                    'reopen_closes_at' => $reopen_closes instanceof DateTimeImmutable ? $reopen_closes->format('Y-m-d H:i:s') : '',
                    'event_id' => (int) $event_id,
                )
            );
        }

        return true;
    }
}

if (!function_exists('vms_ops_ticket_is_pre_event_window_error')) {
    function vms_ops_ticket_is_pre_event_window_error($window_result): bool
    {
        return $window_result instanceof WP_Error && (string) $window_result->get_error_code() === 'checkin_not_open';
    }
}

if (!function_exists('vms_ops_ticket_validation_only_result')) {
    function vms_ops_ticket_validation_only_result(
        int $venue_id,
        int $event_id,
        string $scan_reference,
        string $scan_hash,
        array $event,
        array $attendee,
        string $scan_type = 'ticket',
        array $window_data = array(),
        array $payload_meta = array()
    ) {
        $scan_type = sanitize_key($scan_type);
        $message = $scan_type === 'guest_list'
            ? __('Guest List entry verified for this upcoming event. Test only; no check-in was recorded.', 'vms-ops-console-premium')
            : __('Ticket verified for this upcoming event. Test only; no check-in was recorded.', 'vms-ops-console-premium');
        $result_message = $scan_type === 'guest_list'
            ? 'Guest List entry validated before the check-in window opened.'
            : 'Ticket validated before the check-in window opened.';

        $log = vms_ops_pc_log_scan_event(array(
            'venue_id' => $venue_id,
            'event_id' => $event_id,
            'member_id' => 0,
            'console_type' => 'ticket',
            'scan_type' => $scan_type !== '' ? $scan_type : 'ticket',
            'scan_hash' => $scan_hash,
            'scan_reference' => $scan_reference,
            'result_code' => 'validated_pre_event',
            'result_message' => $result_message,
            'payload_meta' => array_merge(array(
                'event_source' => $event['source'] ?? '',
                'window' => is_array($window_data) ? $window_data : array(),
                'attendee_id' => (int) ($attendee['attendee_id'] ?? 0),
            ), $payload_meta),
        ));
        if (is_wp_error($log)) {
            return $log;
        }

        return array(
            'event' => $event,
            'attendee' => $attendee,
            'scan_reference' => $scan_reference,
            'validation_only' => 1,
            'validated_at' => vms_ops_now_mysql(),
            'message' => $message,
            'window' => is_array($window_data) ? $window_data : array(),
        );
    }
}

if (!function_exists('vms_ops_ticket_find_attendee')) {
    function vms_ops_ticket_find_attendee(array $attendees, string $scan_reference): ?array
    {
        $scan_lower = strtolower($scan_reference);

        foreach ($attendees as $attendee) {
            if (!is_array($attendee)) {
                continue;
            }

            $ticket_ref = strtolower((string) ($attendee['ticket_ref'] ?? ''));
            $attendee_id = (string) (int) ($attendee['attendee_id'] ?? 0);
            $email = strtolower((string) ($attendee['email'] ?? ''));

            if ($ticket_ref !== '' && $ticket_ref === $scan_lower) {
                return $attendee;
            }
            if ($attendee_id !== '0' && $attendee_id === $scan_reference) {
                return $attendee;
            }
            if ($email !== '' && $email === $scan_lower) {
                return $attendee;
            }
        }

        return null;
    }
}

if (!function_exists('vms_ops_ticket_mark_external_checkin')) {
    function vms_ops_ticket_mark_external_checkin(int $event_id, array $attendee): void
    {
        do_action('vms_ops_ticket_mark_external_checkin', $event_id, $attendee);
    }
}

if (!function_exists('vms_ops_ticket_checkin')) {
    function vms_ops_ticket_checkin(int $venue_id, int $event_id, string $scan_reference, string $event_source = '', int $qty = 1)
    {
        if ($venue_id <= 0 || $event_id <= 0) {
            return new WP_Error('invalid_ticket_checkin_args', __('Venue and event are required for check-in.', 'vms-ops-console-premium'));
        }

        $scan_reference = vms_ops_ticket_normalize_scan_reference($scan_reference);
        if ($scan_reference === '') {
            return new WP_Error('invalid_scan_reference', __('Scan reference is required.', 'vms-ops-console-premium'));
        }

        $event = vms_ops_ticket_get_event($event_id, $event_source);
        if (!is_array($event)) {
            return new WP_Error('invalid_event', __('Selected event is not available for scanning.', 'vms-ops-console-premium'));
        }

        $scan_meta = vms_ops_ticket_scan_extract_reference($scan_reference);
        $scan_reference = (string) ($scan_meta['scan_reference'] ?? $scan_reference);
        $scanned_event_id = (int) ($scan_meta['scanned_event_id'] ?? 0);

        if ($scan_reference === '') {
            return new WP_Error('invalid_scan_reference', __('Scan reference is required.', 'vms-ops-console-premium'));
        }

        if ($scanned_event_id > 0 && $scanned_event_id !== (int) $event_id) {
            $scanned_post = get_post($scanned_event_id);
            if ($scanned_post instanceof WP_Post) {
                $types = function_exists('vms_ops_ticket_supported_post_types') ? vms_ops_ticket_supported_post_types() : array();
                if (in_array($scanned_post->post_type, $types, true) && function_exists('vms_ops_ticket_prepare_event')) {
                    $scanned_event = vms_ops_ticket_prepare_event($scanned_post);
                    $ended = function_exists('vms_ops_ticket_is_expired')
                        ? vms_ops_ticket_is_expired(
                            (string) ($scanned_event['end_at'] ?? ''),
                            (string) ($scanned_event['start_at'] ?? ''),
                            (string) ($scanned_event['checkin_close_at'] ?? ($scanned_event['scan_closes_at'] ?? ''))
                        )
                        : false;
                    if ($ended) {
                        vms_ops_log_diagnostic_event('ticket_scan_blocked', array(
                            'reason' => 'event_expired_beyond_buffer',
                            'selected_event_id' => (int) $event_id,
                            'scanned_event_id' => (int) $scanned_event_id,
                        ));
                        vms_ops_pc_log_scan_event(array(
                            'venue_id' => $venue_id,
                            'event_id' => $event_id,
                            'member_id' => 0,
                            'console_type' => 'ticket',
                            'scan_type' => 'ticket',
                            'scan_hash' => vms_ops_hash_scan_payload($scan_reference),
                            'scan_reference' => $scan_reference,
                            'result_code' => 'checkin_expired_ticket',
                            'result_message' => 'Scanned ticket is for an event outside the post-show scan buffer.',
                            'payload_meta' => array(
                                'event_source' => $event['source'] ?? '',
                                'expected_event_id' => (int) $event_id,
                                'scanned_event_id' => (int) $scanned_event_id,
                            ),
                        ));
                        return new WP_Error(
                            'checkin_expired_ticket',
                            __('Scanned ticket is for an event outside the post-show scan buffer.', 'vms-ops-console-premium'),
                            array(
                                'status' => 409,
                                'expected_event_id' => (int) $event_id,
                                'scanned_event_id' => (int) $scanned_event_id,
                                'ticket_id' => (string) $scan_reference,
                            )
                        );
                    }
                }
            }

            vms_ops_log_diagnostic_event('ticket_scan_blocked', array(
                'reason' => 'ticket_for_different_event',
                'selected_event_id' => (int) $event_id,
                'scanned_event_id' => (int) $scanned_event_id,
            ));
            vms_ops_pc_log_scan_event(array(
                'venue_id' => $venue_id,
                'event_id' => $event_id,
                'member_id' => 0,
                'console_type' => 'ticket',
                'scan_type' => 'ticket',
                'scan_hash' => vms_ops_hash_scan_payload($scan_reference),
                'scan_reference' => $scan_reference,
                'result_code' => 'checkin_wrong_event',
                'result_message' => 'Scanned ticket belongs to a different event.',
                'payload_meta' => array(
                    'event_source' => $event['source'] ?? '',
                    'expected_event_id' => (int) $event_id,
                    'scanned_event_id' => (int) $scanned_event_id,
                ),
            ));
            return new WP_Error(
                'checkin_wrong_event',
                'Scanned ticket belongs to a different event.',
                array(
                    'status' => 409,
                    'expected_event_id' => (int) $event_id,
                    'scanned_event_id' => (int) $scanned_event_id,
                    'ticket_id' => (string) $scan_reference,
                )
            );
        }

        $scan_hash = vms_ops_hash_scan_payload($scan_reference);
        if (vms_ops_pc_ticket_scan_is_duplicate($event_id, $scan_hash)) {
            $log = vms_ops_pc_log_scan_event(array(
                'venue_id' => $venue_id,
                'event_id' => $event_id,
                'member_id' => 0,
                'console_type' => 'ticket',
                'scan_type' => 'ticket',
                'scan_hash' => $scan_hash,
                'scan_reference' => $scan_reference,
                'result_code' => 'duplicate',
                'result_message' => 'Duplicate ticket check-in blocked.',
                'payload_meta' => array('event_source' => $event['source'] ?? ''),
            ));
            if (is_wp_error($log)) {
                return $log;
            }

            return new WP_Error('duplicate_checkin', __('Ticket already checked in.', 'vms-ops-console-premium'));
        }

        // Guest List / Comp Admission (VMS) support.
        // These references are minted as: gl:<entry_id>
        if (stripos($scan_reference, 'gl:') === 0) {
            $entry_id = absint(substr($scan_reference, 3));
            if ($entry_id <= 0) {
                return new WP_Error('invalid_guest_list_ref', __('Invalid guest list reference.', 'vms-ops-console-premium'));
            }

            $gl = vms_ops_ticket_checkin_guest_list_entry($venue_id, $event_id, $entry_id, $scan_reference, $scan_hash, $event, $qty);
            if (is_wp_error($gl)) {
                return $gl;
            }
            return $gl;
        }

        $attendee = function_exists('vms_ops_ticket_get_event_attendee_by_scan_reference')
            ? vms_ops_ticket_get_event_attendee_by_scan_reference($event_id, $scan_reference)
            : null;
        if (
            !is_array($attendee)
            && apply_filters('vms_ops_ticket_checkin_use_full_attendee_fallback', false, $event_id, $scan_reference, (string) ($event['source'] ?? ''))
        ) {
            $attendees = vms_ops_ticket_get_event_attendees($event_id, (string) ($event['source'] ?? ''));
            $attendee = vms_ops_ticket_find_attendee($attendees, $scan_reference);
        }
        if (!is_array($attendee)) {
            $log = vms_ops_pc_log_scan_event(array(
                'venue_id' => $venue_id,
                'event_id' => $event_id,
                'member_id' => 0,
                'console_type' => 'ticket',
                'scan_type' => 'ticket',
                'scan_hash' => $scan_hash,
                'scan_reference' => $scan_reference,
                'result_code' => 'not_found',
                'result_message' => 'Ticket reference not found for selected event.',
                'payload_meta' => array('event_source' => $event['source'] ?? ''),
            ));
            if (is_wp_error($log)) {
                return $log;
            }

            return new WP_Error('ticket_not_found', __('Ticket was not found for this event.', 'vms-ops-console-premium'));
        }

        $window_ok = vms_ops_ticket_checkin_assert_window($event, $event_id);
        if (is_wp_error($window_ok)) {
            if (vms_ops_ticket_is_pre_event_window_error($window_ok)) {
                return vms_ops_ticket_validation_only_result(
                    $venue_id,
                    $event_id,
                    $scan_reference,
                    $scan_hash,
                    $event,
                    $attendee,
                    'ticket',
                    (array) $window_ok->get_error_data()
                );
            }

            vms_ops_log_diagnostic_event('ticket_scan_blocked', array(
                'reason' => (string) $window_ok->get_error_code(),
                'selected_event_id' => (int) $event_id,
            ));
            $log = vms_ops_pc_log_scan_event(array(
                'venue_id' => $venue_id,
                'event_id' => $event_id,
                'member_id' => 0,
                'console_type' => 'ticket',
                'scan_type' => 'ticket',
                'scan_hash' => $scan_hash,
                'scan_reference' => $scan_reference,
                'result_code' => (string) $window_ok->get_error_code(),
                'result_message' => (string) $window_ok->get_error_message(),
                'payload_meta' => array(
                    'event_source' => $event['source'] ?? '',
                    'window' => $window_ok->get_error_data(),
                ),
            ));
            if (is_wp_error($log)) {
                return $log;
            }
            return $window_ok;
        }

        vms_ops_ticket_mark_external_checkin($event_id, $attendee);

        $log = vms_ops_pc_log_scan_event(array(
            'venue_id' => $venue_id,
            'event_id' => $event_id,
            'member_id' => 0,
            'console_type' => 'ticket',
            'scan_type' => 'ticket',
            'scan_hash' => $scan_hash,
            'scan_reference' => $scan_reference,
            'result_code' => 'checked_in',
            'result_message' => 'Ticket checked in successfully.',
            'payload_meta' => array(
                'event_source' => $event['source'] ?? '',
                'attendee_id' => (int) ($attendee['attendee_id'] ?? 0),
            ),
        ));
        if (is_wp_error($log)) {
            return $log;
        }

        return array(
            'event' => $event,
            'attendee' => $attendee,
            'scan_reference' => $scan_reference,
            'checked_in_at' => vms_ops_now_mysql(),
        );
    }
}

if (!function_exists('vms_ops_ticket_user_can_admin_window_override')) {
    function vms_ops_ticket_user_can_admin_window_override(): bool
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        if (function_exists('vms_ops_capability_manage_members_admin') && current_user_can(vms_ops_capability_manage_members_admin())) {
            return true;
        }
        return false;
    }
}

if (!function_exists('vms_ops_ticket_get_pass_batch_for_entry')) {
    function vms_ops_ticket_get_pass_batch_for_entry(array $entry): ?array
    {
        $batch_id = max(0, (int) ($entry['pass_batch_id'] ?? 0));
        if ($batch_id <= 0) {
            return null;
        }

        static $cache = array();
        if (array_key_exists($batch_id, $cache)) {
            return is_array($cache[$batch_id]) ? $cache[$batch_id] : null;
        }

        $batch = null;
        if (vms_ops_has_core_function('vms_pass_claims_get_batch_by_id')) {
            $row = vms_ops_call_core_function('vms_pass_claims_get_batch_by_id', $batch_id);
            if (is_array($row)) {
                $batch = $row;
            }
        }

        if (!is_array($batch)) {
            global $wpdb;
            $table = $wpdb->prefix . 'vms_pass_batches';
            $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
            if (is_string($exists) && $exists === $table) {
                $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $batch_id), ARRAY_A);
                if (is_array($row)) {
                    $batch = $row;
                }
            }
        }

        $cache[$batch_id] = is_array($batch) ? $batch : null;
        return is_array($cache[$batch_id]) ? $cache[$batch_id] : null;
    }
}

if (!function_exists('vms_ops_ticket_pass_claim_start_at')) {
    function vms_ops_ticket_pass_claim_start_at(array $event, int $event_plan_id): ?DateTimeImmutable
    {
        $start_raw = trim((string) ($event['start_at'] ?? ''));
        if ($start_raw !== '') {
            $start = vms_ops_parse_wp_datetime($start_raw);
            if ($start instanceof DateTimeImmutable) {
                return $start;
            }
        }

        if ($event_plan_id > 0) {
            $event_date = trim((string) get_post_meta($event_plan_id, '_vms_event_date', true));
            if ($event_date !== '') {
                $start = vms_ops_parse_wp_datetime($event_date . ' 00:00:00');
                if ($start instanceof DateTimeImmutable) {
                    return $start;
                }
            }
        }

        return null;
    }
}

if (!function_exists('vms_ops_ticket_pass_claim_end_at')) {
    function vms_ops_ticket_pass_claim_end_at(array $event, ?DateTimeImmutable $event_start): ?DateTimeImmutable
    {
        if (!($event_start instanceof DateTimeImmutable)) {
            return null;
        }

        $end_raw = trim((string) ($event['end_at'] ?? ''));
        $end = $end_raw !== '' ? vms_ops_parse_wp_datetime($end_raw) : null;
        $resolved = vms_ops_ticket_resolve_operational_event_end($event_start, $end, null);
        return ($resolved['datetime'] ?? null) instanceof DateTimeImmutable
            ? $resolved['datetime']
            : $event_start->setTime(23, 59, 59);
    }
}

if (!function_exists('vms_ops_ticket_pass_claim_checkin_assert_window')) {
    function vms_ops_ticket_pass_claim_checkin_assert_window(array $entry, array $event, int $event_id, int $event_plan_id)
    {
        $batch = vms_ops_ticket_get_pass_batch_for_entry($entry);
        if (!is_array($batch)) {
            return vms_ops_ticket_checkin_assert_window($event, $event_id);
        }

        $mode = sanitize_key((string) ($batch['checkin_open_mode'] ?? 'same_day'));
        if (!in_array($mode, array('same_day', '24h', '48h', 'admins_only'), true)) {
            $mode = 'same_day';
        }

        $event_start = vms_ops_ticket_pass_claim_start_at($event, $event_plan_id);
        if (!($event_start instanceof DateTimeImmutable)) {
            return vms_ops_ticket_checkin_assert_window($event, $event_id);
        }

        $event_end = vms_ops_ticket_pass_claim_end_at($event, $event_start);
        if (!($event_end instanceof DateTimeImmutable)) {
            return vms_ops_ticket_checkin_assert_window($event, $event_id);
        }

        $tz = wp_timezone();
        $now = vms_ops_now_datetime();
        $opens = $event_start->setTime(0, 0, 0);

        if ($mode === 'admins_only') {
            if (vms_ops_ticket_user_can_admin_window_override()) {
                $opens = $now;
            } else {
                $mode = 'same_day';
            }
        }

        if ($mode === '24h') {
            $opens = $event_start->sub(new DateInterval('PT24H'));
        } elseif ($mode === '48h') {
            $opens = $event_start->sub(new DateInterval('PT48H'));
        } elseif ($mode === 'same_day') {
            $opens = $event_start->setTime(0, 0, 0);
        }

        $filtered_opens = apply_filters('vms_ops_ticket_pass_checkin_opens_at', $opens, $event, $event_id, $entry, $batch, $mode);
        if ($filtered_opens instanceof DateTimeInterface) {
            $opens = new DateTimeImmutable($filtered_opens->format('Y-m-d H:i:s'), $tz);
        }

        $filtered_closes = apply_filters('vms_ops_ticket_pass_checkin_closes_at', $event_end, $event, $event_id, $entry, $batch, $mode);
        if ($filtered_closes instanceof DateTimeInterface) {
            $event_end = new DateTimeImmutable($filtered_closes->format('Y-m-d H:i:s'), $tz);
        }

        $buffer_hours = vms_ops_ticket_post_show_scan_buffer_hours();
        $buffer_closes = vms_ops_ticket_apply_post_show_buffer($event_end);
        $reopen_closes = function_exists('vms_ops_ticket_apply_reopen_past_window')
            ? vms_ops_ticket_apply_reopen_past_window($buffer_closes)
            : null;

        if ($now < $opens) {
            $date_format = (string) get_option('date_format');
            $time_format = (string) get_option('time_format');
            if ($date_format === '') {
                $date_format = 'Y-m-d';
            }
            if ($time_format === '') {
                $time_format = 'g:i a';
            }
            $opens_label = wp_date(trim($date_format . ' ' . $time_format), $opens->getTimestamp(), $tz);
            return new WP_Error(
                'checkin_not_open',
                sprintf(__('Check-in for this pass batch opens %s.', 'vms-ops-console-premium'), $opens_label),
                array(
                    'status' => 409,
                    'opens_at' => $opens->format('Y-m-d H:i:s'),
                    'checkin_open_mode' => $mode,
                    'pass_batch_id' => (int) ($batch['id'] ?? 0),
                    'event_plan_id' => $event_plan_id,
                )
            );
        }

        if ($now > $buffer_closes) {
            $within_reopen_window = $reopen_closes instanceof DateTimeImmutable && $now <= $reopen_closes;
            if (!$within_reopen_window) {
                return new WP_Error(
                    'checkin_closed',
                    $reopen_closes instanceof DateTimeImmutable
                        ? sprintf(
                            __('This event is outside the reopened testing window. Scanning closed at %s.', 'vms-ops-console-premium'),
                            vms_ops_ticket_format_console_datetime_label($reopen_closes)
                        )
                        : (
                            $buffer_hours > 0
                                ? sprintf(
                                    __('This event is outside the %1$d-hour post-show scan buffer. Scanning closed at %2$s.', 'vms-ops-console-premium'),
                                    $buffer_hours,
                                    vms_ops_ticket_format_console_datetime_label($buffer_closes)
                                )
                                : __('This event has ended. Tickets for this event are expired.', 'vms-ops-console-premium')
                        ),
                    array(
                        'status' => 409,
                        'closes_at' => $buffer_closes->format('Y-m-d H:i:s'),
                        'event_end_at' => $event_end->format('Y-m-d H:i:s'),
                        'buffer_hours' => $buffer_hours,
                        'reopen_closes_at' => $reopen_closes instanceof DateTimeImmutable ? $reopen_closes->format('Y-m-d H:i:s') : '',
                        'checkin_open_mode' => $mode,
                        'pass_batch_id' => (int) ($batch['id'] ?? 0),
                        'event_plan_id' => $event_plan_id,
                    )
                );
            }
        }

        return true;
    }
}

if (!function_exists('vms_ops_ticket_checkin_guest_list_entry')) {
    function vms_ops_ticket_checkin_guest_list_entry(int $venue_id, int $event_id, int $entry_id, string $scan_reference, string $scan_hash, array $event, int $qty = 1)
    {
        if ($qty <= 0) {
            $qty = 1;
        }

        if (!function_exists('vms_ops_ticket_resolve_event_plan_id_for_guest_list')) {
            return new WP_Error('guest_list_unavailable', __('Guest List is not available (VMS not active).', 'vms-ops-console-premium'));
        }

        $event_plan_id = (int) vms_ops_ticket_resolve_event_plan_id_for_guest_list($event_id, (string) ($event['source'] ?? ''));
        if ($event_plan_id <= 0) {
            return new WP_Error(
                'guest_list_not_linked',
                __('This event is not linked to an Event Plan Guest List.', 'vms-ops-console-premium'),
                array('status' => 404)
            );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'vms_admission_entries';
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d AND event_plan_id = %d",
                $entry_id,
                $event_plan_id
            ),
            ARRAY_A
        );

        if (!is_array($row)) {
            $log = vms_ops_pc_log_scan_event(array(
                'venue_id' => $venue_id,
                'event_id' => $event_id,
                'member_id' => 0,
                'console_type' => 'ticket',
                'scan_type' => 'guest_list',
                'scan_hash' => $scan_hash,
                'scan_reference' => $scan_reference,
                'result_code' => 'not_found',
                'result_message' => 'Guest List entry not found for selected event.',
                'payload_meta' => array('event_source' => $event['source'] ?? '', 'entry_id' => $entry_id),
            ));
            if (is_wp_error($log)) {
                return $log;
            }

            return new WP_Error('guest_list_not_found', __('Guest List entry not found for this event.', 'vms-ops-console-premium'));
        }

        $status = sanitize_key((string) ($row['status'] ?? 'active'));
        if ($status === 'canceled') {
            return new WP_Error(
                'guest_list_ineligible',
                __('Guest List entry is canceled.', 'vms-ops-console-premium'),
                array('status' => 409)
            );
        }

        $party_size = max(1, (int) ($row['party_size'] ?? 1));
        $checked_in_qty = max(0, (int) ($row['checked_in_qty'] ?? 0));

        if ($checked_in_qty >= $party_size || $status === 'checked_in') {
            return new WP_Error('duplicate_checkin', __('Guest List entry already fully checked in.', 'vms-ops-console-premium'));
        }

        $window_ok = vms_ops_ticket_pass_claim_checkin_assert_window($row, $event, $event_id, $event_plan_id);
        if (is_wp_error($window_ok)) {
            if (vms_ops_ticket_is_pre_event_window_error($window_ok)) {
                $attendee = array(
                    'attendee_id' => 0,
                    'name' => sanitize_text_field((string) ($row['guest_name'] ?? '')),
                    'email' => '',
                    'ticket_ref' => 'gl:' . $entry_id,
                    'checked_in' => ($status === 'checked_in') ? 1 : 0,
                    'kind' => 'guest_list',
                    'party_size' => $party_size,
                    'checked_in_qty' => $checked_in_qty,
                    'remaining_qty' => max(0, $party_size - $checked_in_qty),
                    'phone' => sanitize_text_field((string) ($row['phone'] ?? '')),
                    'notes' => sanitize_text_field((string) ($row['notes'] ?? '')),
                    'checked_in_at' => sanitize_text_field((string) ($row['checked_in_at'] ?? '')),
                    'status' => $status,
                );

                return vms_ops_ticket_validation_only_result(
                    $venue_id,
                    $event_id,
                    $scan_reference,
                    $scan_hash,
                    $event,
                    $attendee,
                    'guest_list',
                    (array) $window_ok->get_error_data(),
                    array(
                        'entry_id' => $entry_id,
                        'event_plan_id' => $event_plan_id,
                        'party_size' => $party_size,
                        'checked_in_qty' => $checked_in_qty,
                    )
                );
            }

            $log = vms_ops_pc_log_scan_event(array(
                'venue_id' => $venue_id,
                'event_id' => $event_id,
                'member_id' => 0,
                'console_type' => 'ticket',
                'scan_type' => 'guest_list',
                'scan_hash' => $scan_hash,
                'scan_reference' => $scan_reference,
                'result_code' => (string) $window_ok->get_error_code(),
                'result_message' => (string) $window_ok->get_error_message(),
                'payload_meta' => array(
                    'event_source' => $event['source'] ?? '',
                    'entry_id' => $entry_id,
                    'event_plan_id' => $event_plan_id,
                    'window' => $window_ok->get_error_data(),
                ),
            ));
            if (is_wp_error($log)) {
                return $log;
            }
            return $window_ok;
        }

        $new_qty = min($party_size, $checked_in_qty + $qty);
        $new_status = ($new_qty >= $party_size) ? 'checked_in' : 'partial';

        $now = vms_ops_now_mysql();
        $user_id = get_current_user_id();

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table}
                 SET status = %s,
                     checked_in_qty = %d,
                     checked_in_at = %s,
                     checked_in_by = %d,
                     updated_at = %s,
                     updated_by = %d
                 WHERE id = %d AND status <> 'canceled'",
                $new_status,
                $new_qty,
                $now,
                $user_id,
                $now,
                $user_id,
                $entry_id
            )
        );

        if ($updated === false) {
            return new WP_Error('guest_list_db_error', __('Could not check in Guest List entry.', 'vms-ops-console-premium'));
        }
        if ((int) $updated === 0) {
            // Another device may have just checked this in, or it was canceled.
            $fresh = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $entry_id), ARRAY_A);
            if (is_array($fresh)) {
                $fresh_party = max(1, (int) ($fresh['party_size'] ?? 1));
                $fresh_qty = max(0, (int) ($fresh['checked_in_qty'] ?? 0));
                if ((string) ($fresh['status'] ?? '') === 'canceled') {
                    return new WP_Error('guest_list_ineligible', __('Guest List entry is canceled.', 'vms-ops-console-premium'), array('status' => 409));
                }
                if ($fresh_qty >= $fresh_party || (string) ($fresh['status'] ?? '') === 'checked_in') {
                    return new WP_Error('duplicate_checkin', __('Guest List entry already fully checked in.', 'vms-ops-console-premium'));
                }
            }
            return new WP_Error('guest_list_conflict', __('Could not check in Guest List entry (please retry).', 'vms-ops-console-premium'), array('status' => 409));
        }

        if (vms_ops_has_core_function('vms_admission_audit_log')) {
            vms_ops_call_core_function('vms_admission_audit_log', $event_plan_id, $entry_id, 'checkin', $user_id, 'ops', array('qty' => $qty));
        }

        $attendee = array(
            'attendee_id' => 0,
            'name' => sanitize_text_field((string) ($row['guest_name'] ?? '')),
            'email' => '',
            'ticket_ref' => 'gl:' . $entry_id,
            'checked_in' => ($new_status === 'checked_in') ? 1 : 0,
            'kind' => 'guest_list',
            'party_size' => $party_size,
            'checked_in_qty' => $new_qty,
            'remaining_qty' => max(0, $party_size - $new_qty),
            'phone' => sanitize_text_field((string) ($row['phone'] ?? '')),
            'notes' => sanitize_text_field((string) ($row['notes'] ?? '')),
            'checked_in_at' => $now,
            'status' => $new_status,
        );

        $result_code = ($new_status === 'checked_in') ? 'checked_in' : 'checked_in_partial';
        $result_message = ($new_status === 'checked_in')
            ? 'Guest List entry fully checked in.'
            : sprintf('Guest List entry checked in (%d/%d).', $new_qty, $party_size);

        $log = vms_ops_pc_log_scan_event(array(
            'venue_id' => $venue_id,
            'event_id' => $event_id,
            'member_id' => 0,
            'console_type' => 'ticket',
            'scan_type' => 'guest_list',
            'scan_hash' => $scan_hash,
            'scan_reference' => $scan_reference,
            'result_code' => $result_code,
            'result_message' => $result_message,
            'payload_meta' => array(
                'event_source' => $event['source'] ?? '',
                'entry_id' => $entry_id,
                'event_plan_id' => $event_plan_id,
                'qty' => $qty,
                'checked_in_qty' => $new_qty,
                'party_size' => $party_size,
            ),
        ));
        if (is_wp_error($log)) {
            return $log;
        }

        return array(
            'event' => $event,
            'attendee' => $attendee,
            'scan_reference' => $scan_reference,
            'checked_in_at' => $now,
        );
    }
}
