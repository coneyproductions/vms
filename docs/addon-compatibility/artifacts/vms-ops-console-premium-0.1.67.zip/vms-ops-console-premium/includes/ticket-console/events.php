<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_ticket_supported_post_types')) {
    function vms_ops_ticket_supported_post_types(): array
    {
        // Include TEC + VMS Event Plans; Event Plans are filtered to only those
        // with active guest-list/pass-claim entries.
        $types = array('tribe_events', 'vms_event_plan');

        $types = apply_filters('vms_ops_ticket_event_post_types', $types);
        $types = array_values(array_unique(array_filter((array) $types, 'is_string')));

        return $types;
    }
}

if (!function_exists('vms_ops_ticket_event_start_for_post')) {
    function vms_ops_ticket_event_start_for_post(WP_Post $post): string
    {
        if (function_exists('vms_ops_ticket_event_schedule_for_post')) {
            $schedule = vms_ops_ticket_event_schedule_for_post($post);
            if (($schedule['showtime'] ?? null) instanceof DateTimeImmutable) {
                return $schedule['showtime']->format('Y-m-d H:i:s');
            }
        }

        if ($post->post_type === 'tribe_events') {
            $value = (string) get_post_meta($post->ID, '_EventStartDate', true);
            if ($value !== '') {
                return $value;
            }
        }

        return (string) $post->post_date;
    }
}

if (!function_exists('vms_ops_ticket_event_end_for_post')) {
    function vms_ops_ticket_event_end_for_post(WP_Post $post): string
    {
        if (function_exists('vms_ops_ticket_event_schedule_for_post')) {
            $schedule = vms_ops_ticket_event_schedule_for_post($post);
            if (($schedule['event_end'] ?? null) instanceof DateTimeImmutable) {
                return $schedule['event_end']->format('Y-m-d H:i:s');
            }
        }

        if ($post->post_type === 'tribe_events') {
            $value = (string) get_post_meta($post->ID, '_EventEndDate', true);
            if ($value !== '') {
                return $value;
            }
        }

        return (string) $post->post_date;
    }
}

if (!function_exists('vms_ops_ticket_post_show_scan_buffer_hours')) {
    function vms_ops_ticket_post_show_scan_buffer_hours(): int
    {
        $defaults = function_exists('vms_ops_default_settings') ? vms_ops_default_settings() : array('post_show_scan_buffer_hours' => 4);
        $fallback = isset($defaults['post_show_scan_buffer_hours']) ? (int) $defaults['post_show_scan_buffer_hours'] : 4;

        if (function_exists('vms_ops_get_settings')) {
            $settings = vms_ops_get_settings();
            $fallback = isset($settings['post_show_scan_buffer_hours']) ? (int) $settings['post_show_scan_buffer_hours'] : $fallback;
        }

        return max(0, min(12, $fallback));
    }
}

if (!function_exists('vms_ops_ticket_checkin_open_lead_minutes')) {
    function vms_ops_ticket_checkin_open_lead_minutes(): int
    {
        $minutes = (int) apply_filters('vms_ops_ticket_checkin_open_lead_minutes', 60);
        return max(0, min(240, $minutes));
    }
}

if (!function_exists('vms_ops_ticket_checkin_open_datetime')) {
    function vms_ops_ticket_checkin_open_datetime(DateTimeImmutable $event_start): DateTimeImmutable
    {
        $lead_minutes = vms_ops_ticket_checkin_open_lead_minutes();
        if ($lead_minutes <= 0) {
            return $event_start;
        }

        return $event_start->sub(new DateInterval('PT' . $lead_minutes . 'M'));
    }
}

if (!function_exists('vms_ops_ticket_reopen_past_events_days')) {
    function vms_ops_ticket_reopen_past_events_days(): int
    {
        $defaults = function_exists('vms_ops_default_settings')
            ? vms_ops_default_settings()
            : array('ticket_reopen_past_events_days' => 3);
        $fallback = isset($defaults['ticket_reopen_past_events_days']) ? (int) $defaults['ticket_reopen_past_events_days'] : 3;

        if (function_exists('vms_ops_get_settings')) {
            $settings = vms_ops_get_settings();
            $fallback = isset($settings['ticket_reopen_past_events_days']) ? (int) $settings['ticket_reopen_past_events_days'] : $fallback;
        }

        return max(0, min(30, $fallback));
    }
}

if (!function_exists('vms_ops_ticket_reopen_past_events_enabled')) {
    function vms_ops_ticket_reopen_past_events_enabled(): bool
    {
        $defaults = function_exists('vms_ops_default_settings')
            ? vms_ops_default_settings()
            : array('ticket_reopen_past_events_enabled' => 0);
        $enabled = !empty($defaults['ticket_reopen_past_events_enabled']);

        if (function_exists('vms_ops_get_settings')) {
            $settings = vms_ops_get_settings();
            $enabled = !empty($settings['ticket_reopen_past_events_enabled']);
        }

        return $enabled && vms_ops_ticket_reopen_past_events_days() > 0;
    }
}

if (!function_exists('vms_ops_ticket_format_console_datetime_label')) {
    function vms_ops_ticket_format_console_datetime_label(DateTimeInterface $datetime): string
    {
        $date_format = trim((string) get_option('date_format'));
        $time_format = trim((string) get_option('time_format'));
        $format = trim($date_format . ' ' . $time_format);
        if ($format === '') {
            $format = 'M j, g:i A';
        }

        return (string) wp_date($format, $datetime->getTimestamp(), wp_timezone());
    }
}

if (!function_exists('vms_ops_ticket_apply_reopen_past_window')) {
    function vms_ops_ticket_apply_reopen_past_window(DateTimeImmutable $window_end): ?DateTimeImmutable
    {
        if (!vms_ops_ticket_reopen_past_events_enabled()) {
            return null;
        }

        $reopen_days = vms_ops_ticket_reopen_past_events_days();
        if ($reopen_days <= 0) {
            return null;
        }

        return $window_end->add(new DateInterval('P' . $reopen_days . 'D'));
    }
}

if (!function_exists('vms_ops_ticket_apply_post_show_buffer')) {
    function vms_ops_ticket_apply_post_show_buffer(DateTimeImmutable $event_end): DateTimeImmutable
    {
        $buffer_hours = vms_ops_ticket_post_show_scan_buffer_hours();
        if ($buffer_hours <= 0) {
            return $event_end;
        }

        return $event_end->add(new DateInterval('PT' . $buffer_hours . 'H'));
    }
}

if (!function_exists('vms_ops_ticket_event_plan_datetime_from_parts')) {
    function vms_ops_ticket_event_plan_datetime_from_parts(int $plan_id, string $time_meta_key): ?DateTimeImmutable
    {
        $event_date = trim((string) get_post_meta($plan_id, '_vms_event_date', true));
        $time_value = trim((string) get_post_meta($plan_id, $time_meta_key, true));
        if ($event_date === '' || $time_value === '') {
            return null;
        }

        $normalized_time = preg_match('/^\d{2}:\d{2}$/', $time_value) ? ($time_value . ':00') : $time_value;
        return vms_ops_parse_wp_datetime($event_date . ' ' . $normalized_time);
    }
}

if (!function_exists('vms_ops_ticket_event_plan_start_datetime')) {
    function vms_ops_ticket_event_plan_start_datetime(int $plan_id): ?DateTimeImmutable
    {
        $start = vms_ops_parse_wp_datetime((string) get_post_meta($plan_id, '_vms_event_plan_start_datetime', true));
        if ($start instanceof DateTimeImmutable) {
            return $start;
        }

        $start = vms_ops_ticket_event_plan_datetime_from_parts($plan_id, '_vms_start_time');
        if ($start instanceof DateTimeImmutable) {
            return $start;
        }

        $event_date = trim((string) get_post_meta($plan_id, '_vms_event_date', true));
        return $event_date !== '' ? vms_ops_parse_wp_datetime($event_date . ' 00:00:00') : null;
    }
}

if (!function_exists('vms_ops_ticket_event_plan_end_datetime')) {
    function vms_ops_ticket_event_plan_end_datetime(int $plan_id): ?DateTimeImmutable
    {
        $start = vms_ops_ticket_event_plan_start_datetime($plan_id);
        $end = vms_ops_ticket_event_plan_datetime_from_parts($plan_id, '_vms_end_time');
        if (!($end instanceof DateTimeImmutable)) {
            return null;
        }

        if ($start instanceof DateTimeImmutable && $end <= $start) {
            return $end->add(new DateInterval('P1D'));
        }

        return $end;
    }
}

if (!function_exists('vms_ops_ticket_linked_event_plan_id_for_post')) {
    function vms_ops_ticket_linked_event_plan_id_for_post(WP_Post $post): int
    {
        if ($post->post_type === 'vms_event_plan') {
            return (int) $post->ID;
        }

        if ($post->post_type === 'tribe_events' && vms_ops_has_core_function('vms_get_event_plan_for_tec_event')) {
            return (int) vms_ops_call_core_function('vms_get_event_plan_for_tec_event', (int) $post->ID);
        }

        return 0;
    }
}

if (!function_exists('vms_ops_ticket_explicit_checkin_close_for_post')) {
    function vms_ops_ticket_explicit_checkin_close_for_post(WP_Post $post, int $linked_plan_id = 0): ?DateTimeImmutable
    {
        $linked_plan_id = $linked_plan_id > 0 ? $linked_plan_id : vms_ops_ticket_linked_event_plan_id_for_post($post);
        $plan_meta_key = vms_ops_has_core_function('vms_meta_key') ? ((string) vms_ops_call_core_function('vms_meta_key', 'event_plan', 'checkin_close_at')) : '';
        if ($plan_meta_key === '') {
            $plan_meta_key = '_checkin_close_at';
        }

        $candidates = array();
        if ($post->post_type === 'vms_event_plan') {
            $candidates[] = (string) get_post_meta($post->ID, $plan_meta_key, true);
        } else {
            $candidates[] = (string) get_post_meta($post->ID, '_checkin_close_at', true);
            if ($linked_plan_id > 0) {
                $candidates[] = (string) get_post_meta($linked_plan_id, $plan_meta_key, true);
            }
        }

        foreach ($candidates as $candidate) {
            $parsed = vms_ops_parse_wp_datetime($candidate);
            if ($parsed instanceof DateTimeImmutable) {
                return $parsed;
            }
        }

        return null;
    }
}

if (!function_exists('vms_ops_ticket_event_schedule_for_post')) {
    function vms_ops_ticket_event_schedule_for_post(WP_Post $post): array
    {
        $raw_start = null;
        $raw_end = null;

        if ($post->post_type === 'tribe_events') {
            $raw_start = vms_ops_parse_wp_datetime((string) get_post_meta($post->ID, '_EventStartDate', true));
            $raw_end = vms_ops_parse_wp_datetime((string) get_post_meta($post->ID, '_EventEndDate', true));
        } else {
            $raw_start = vms_ops_ticket_event_plan_start_datetime((int) $post->ID);
            $raw_end = vms_ops_ticket_event_plan_end_datetime((int) $post->ID);
        }

        if (!($raw_start instanceof DateTimeImmutable)) {
            $raw_start = vms_ops_parse_wp_datetime((string) $post->post_date);
        }

        $linked_plan_id = vms_ops_ticket_linked_event_plan_id_for_post($post);
        $canonical_end = $linked_plan_id > 0 ? vms_ops_ticket_event_plan_end_datetime($linked_plan_id) : null;
        $explicit_checkin_close = vms_ops_ticket_explicit_checkin_close_for_post($post, $linked_plan_id);
        if (
            $explicit_checkin_close instanceof DateTimeImmutable
            && $raw_start instanceof DateTimeImmutable
            && $explicit_checkin_close <= $raw_start
        ) {
            $explicit_checkin_close = null;
        }

        $resolved_end = vms_ops_ticket_resolve_operational_event_end($raw_start, $raw_end, $canonical_end);
        $event_end = ($resolved_end['datetime'] ?? null) instanceof DateTimeImmutable ? $resolved_end['datetime'] : null;
        $checkin_open = $raw_start instanceof DateTimeImmutable ? vms_ops_ticket_checkin_open_datetime($raw_start) : null;
        $checkin_close = $explicit_checkin_close instanceof DateTimeImmutable
            ? $explicit_checkin_close
            : ($event_end instanceof DateTimeImmutable ? vms_ops_ticket_apply_post_show_buffer($event_end) : null);
        $checkin_close_source = $explicit_checkin_close instanceof DateTimeImmutable
            ? 'explicit_meta'
            : ($event_end instanceof DateTimeImmutable ? 'derived_event_end' : 'missing');

        return array(
            'showtime' => $raw_start,
            'event_end' => $event_end,
            'checkin_open' => $checkin_open,
            'checkin_close' => $checkin_close,
            'checkin_close_source' => $checkin_close_source,
            'event_end_source' => (string) ($resolved_end['source'] ?? 'missing'),
            'used_end_fallback' => !empty($resolved_end['used_fallback']),
            'linked_event_plan_id' => $linked_plan_id,
        );
    }
}

if (!function_exists('vms_ops_ticket_scan_window_state')) {
    function vms_ops_ticket_scan_window_state(string $end_datetime, string $start_datetime = '', string $checkin_close_datetime = ''): array
    {
        $now = vms_ops_now_datetime();
        $start = vms_ops_parse_wp_datetime($start_datetime);
        $end = vms_ops_parse_wp_datetime($end_datetime);
        $checkin_close = vms_ops_parse_wp_datetime($checkin_close_datetime);

        $opens = $start instanceof DateTimeImmutable ? vms_ops_ticket_checkin_open_datetime($start) : null;
        $buffer_end = $checkin_close instanceof DateTimeImmutable
            ? $checkin_close
            : ($end instanceof DateTimeImmutable ? vms_ops_ticket_apply_post_show_buffer($end) : null);
        $reopen_end = $buffer_end instanceof DateTimeImmutable ? vms_ops_ticket_apply_reopen_past_window($buffer_end) : null;
        $state = 'live';
        if ($opens instanceof DateTimeImmutable && $now < $opens) {
            $state = 'upcoming';
        } elseif ($buffer_end instanceof DateTimeImmutable && $now > $buffer_end) {
            $state = ($reopen_end instanceof DateTimeImmutable && $now <= $reopen_end) ? 'reopened' : 'expired';
        } elseif ($end instanceof DateTimeImmutable && $now > $end) {
            $state = 'buffer';
        }

        return array(
            'now' => $now,
            'opens' => $opens,
            'start' => $start,
            'end' => $end,
            'checkin_close' => $buffer_end,
            'buffer_end' => $buffer_end,
            'reopen_end' => $reopen_end,
            'buffer_hours' => vms_ops_ticket_post_show_scan_buffer_hours(),
            'reopen_days' => vms_ops_ticket_reopen_past_events_days(),
            'reopen_enabled' => vms_ops_ticket_reopen_past_events_enabled(),
            'checkin_open_lead_minutes' => vms_ops_ticket_checkin_open_lead_minutes(),
            'state' => $state,
            'expired' => $state === 'expired',
            'within_buffer' => $state === 'buffer',
            'reopened' => $state === 'reopened',
        );
    }
}

if (!function_exists('vms_ops_ticket_event_venue_for_post')) {
    function vms_ops_ticket_event_venue_for_post(WP_Post $post): int
    {
        if ($post->post_type === 'vms_event_plan') {
            return (int) get_post_meta($post->ID, '_vms_venue_id', true);
        }

        if ($post->post_type === 'tribe_events') {
            // TEC stores its own venue post IDs in _EventVenueID, which are NOT VMS venue IDs.
            // We only return a VMS venue ID if the event is explicitly linked to one.
            $linked = (int) get_post_meta($post->ID, '_vms_venue_id', true);
            if ($linked > 0) {
                return $linked;
            }
            $linked = (int) get_post_meta($post->ID, 'vms_venue_id', true);
            if ($linked > 0) {
                return $linked;
            }

            return 0;
        }

        return 0;
    }
}

if (!function_exists('vms_ops_ticket_is_expired')) {
    function vms_ops_ticket_is_expired(string $end_datetime, string $start_datetime = '', string $checkin_close_datetime = ''): bool
    {
        $window = vms_ops_ticket_scan_window_state($end_datetime, $start_datetime, $checkin_close_datetime);
        return !empty($window['expired']);
    }
}

if (!function_exists('vms_ops_ticket_prepare_event')) {
    function vms_ops_ticket_prepare_event(WP_Post $post): array
    {
        $schedule = vms_ops_ticket_event_schedule_for_post($post);
        $start_dt = ($schedule['showtime'] ?? null) instanceof DateTimeImmutable ? $schedule['showtime'] : null;
        $end_dt = ($schedule['event_end'] ?? null) instanceof DateTimeImmutable ? $schedule['event_end'] : null;
        $scan_opens = ($schedule['checkin_open'] ?? null) instanceof DateTimeImmutable ? $schedule['checkin_open'] : null;
        $checkin_close = ($schedule['checkin_close'] ?? null) instanceof DateTimeImmutable ? $schedule['checkin_close'] : null;
        $start_at = $start_dt instanceof DateTimeImmutable ? $start_dt->format('Y-m-d H:i:s') : '';
        $end_at = $end_dt instanceof DateTimeImmutable ? $end_dt->format('Y-m-d H:i:s') : '';
        $window = vms_ops_ticket_scan_window_state(
            $end_at,
            $start_at,
            $checkin_close instanceof DateTimeImmutable ? $checkin_close->format('Y-m-d H:i:s') : ''
        );
        $buffer_end = $window['buffer_end'] instanceof DateTimeImmutable ? $window['buffer_end'] : $checkin_close;
        $reopen_end = $window['reopen_end'] instanceof DateTimeImmutable ? $window['reopen_end'] : null;

        $scan_state = (string) ($window['state'] ?? 'live');
        $scan_state_label = '';
        if ($scan_state === 'buffer') {
            $scan_state_label = __('Post-show scan window', 'vms-ops-console-premium');
        } elseif ($scan_state === 'reopened') {
            $scan_state_label = __('Reopened for testing', 'vms-ops-console-premium');
        } elseif ($scan_state === 'upcoming') {
            $scan_state_label = __('Upcoming', 'vms-ops-console-premium');
        } else {
            $scan_state_label = __('Live', 'vms-ops-console-premium');
        }

        $scan_closes = $scan_state === 'reopened' && $reopen_end instanceof DateTimeImmutable
            ? $reopen_end
            : $buffer_end;

        return array(
            'id' => (int) $post->ID,
            'title' => html_entity_decode(wp_strip_all_tags($post->post_title), ENT_QUOTES, get_bloginfo('charset')),
            'source' => $post->post_type,
            'start_at' => $start_at,
            'end_at' => $end_at,
            'venue_id' => vms_ops_ticket_event_venue_for_post($post),
            'status' => (string) $post->post_status,
            'start_at_label' => $start_dt instanceof DateTimeImmutable ? vms_ops_ticket_format_console_datetime_label($start_dt) : '',
            'end_at_label' => $end_dt instanceof DateTimeImmutable ? vms_ops_ticket_format_console_datetime_label($end_dt) : '',
            'start_at_epoch_ms' => $start_dt instanceof DateTimeImmutable ? ((int) $start_dt->getTimestamp() * 1000) : 0,
            'end_at_epoch_ms' => $end_dt instanceof DateTimeImmutable ? ((int) $end_dt->getTimestamp() * 1000) : 0,
            'event_end_source' => (string) ($schedule['event_end_source'] ?? 'missing'),
            'checkin_open_at' => $scan_opens instanceof DateTimeImmutable ? $scan_opens->format('Y-m-d H:i:s') : '',
            'checkin_open_label' => $scan_opens instanceof DateTimeImmutable ? vms_ops_ticket_format_console_datetime_label($scan_opens) : '',
            'checkin_open_epoch_ms' => $scan_opens instanceof DateTimeImmutable ? ((int) $scan_opens->getTimestamp() * 1000) : 0,
            'checkin_close_at' => $buffer_end instanceof DateTimeImmutable ? $buffer_end->format('Y-m-d H:i:s') : '',
            'checkin_close_label' => $buffer_end instanceof DateTimeImmutable ? vms_ops_ticket_format_console_datetime_label($buffer_end) : '',
            'checkin_close_epoch_ms' => $buffer_end instanceof DateTimeImmutable ? ((int) $buffer_end->getTimestamp() * 1000) : 0,
            'checkin_close_source' => (string) ($schedule['checkin_close_source'] ?? 'derived_event_end'),
            'scan_opens_at' => $scan_opens instanceof DateTimeImmutable ? $scan_opens->format('Y-m-d H:i:s') : '',
            'scan_opens_label' => $scan_opens instanceof DateTimeImmutable ? vms_ops_ticket_format_console_datetime_label($scan_opens) : '',
            'scan_opens_epoch_ms' => $scan_opens instanceof DateTimeImmutable ? ((int) $scan_opens->getTimestamp() * 1000) : 0,
            'scan_closes_at' => $scan_closes instanceof DateTimeImmutable ? $scan_closes->format('Y-m-d H:i:s') : '',
            'scan_closes_label' => $scan_closes instanceof DateTimeImmutable ? vms_ops_ticket_format_console_datetime_label($scan_closes) : '',
            'scan_closes_epoch_ms' => $scan_closes instanceof DateTimeImmutable ? ((int) $scan_closes->getTimestamp() * 1000) : 0,
            'scan_state' => $scan_state,
            'scan_state_label' => $scan_state_label,
            'within_buffer' => !empty($window['within_buffer']) ? 1 : 0,
            'scan_buffer_hours' => (int) ($window['buffer_hours'] ?? 0),
            'buffer_end_at' => $buffer_end instanceof DateTimeImmutable ? $buffer_end->format('Y-m-d H:i:s') : '',
            'buffer_end_epoch_ms' => $buffer_end instanceof DateTimeImmutable ? ((int) $buffer_end->getTimestamp() * 1000) : 0,
            'checkin_open_lead_minutes' => (int) ($window['checkin_open_lead_minutes'] ?? 0),
            'reopened_for_testing' => !empty($window['reopened']) ? 1 : 0,
            'reopen_until_at' => $reopen_end instanceof DateTimeImmutable ? $reopen_end->format('Y-m-d H:i:s') : '',
            'reopen_until_label' => $reopen_end instanceof DateTimeImmutable ? vms_ops_ticket_format_console_datetime_label($reopen_end) : '',
            'reopen_until_epoch_ms' => $reopen_end instanceof DateTimeImmutable ? ((int) $reopen_end->getTimestamp() * 1000) : 0,
            'reopen_days' => (int) ($window['reopen_days'] ?? 0),
        );
    }
}

if (!function_exists('vms_ops_ticket_event_plan_ids_with_guest_list_entries')) {
    function vms_ops_ticket_event_plan_ids_with_guest_list_entries(int $venue_id = 0, int $limit = 300): array
    {
        $venue_id = max(0, $venue_id);
        $limit = max(1, min(2000, $limit));
        $cache_key = $venue_id . '|' . $limit;
        static $cache = array();
        if (isset($cache[$cache_key]) && is_array($cache[$cache_key])) {
            return $cache[$cache_key];
        }

        global $wpdb;
        $table = $wpdb->prefix . 'vms_admission_entries';
        $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if (!is_string($table_exists) || $table_exists !== $table) {
            $cache[$cache_key] = array();
            return $cache[$cache_key];
        }

        $ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT event_plan_id
                 FROM {$table}
                 WHERE event_plan_id > 0
                   AND status IN ('active','partial','checked_in')
                 ORDER BY event_plan_id DESC
                 LIMIT %d",
                $limit
            )
        );
        if (!is_array($ids) || empty($ids)) {
            $cache[$cache_key] = array();
            return $cache[$cache_key];
        }

        $out = array();
        foreach ($ids as $raw_id) {
            $event_plan_id = absint($raw_id);
            if ($event_plan_id <= 0) {
                continue;
            }
            $post = get_post($event_plan_id);
            if (!($post instanceof WP_Post) || $post->post_type !== 'vms_event_plan') {
                continue;
            }
            if (!in_array((string) $post->post_status, array('publish', 'future', 'private'), true)) {
                continue;
            }
            if ($venue_id > 0) {
                $event_venue_id = (int) get_post_meta($event_plan_id, '_vms_venue_id', true);
                if ($event_venue_id > 0 && $event_venue_id !== $venue_id) {
                    continue;
                }
            }
            $out[] = $event_plan_id;
        }

        $out = array_values(array_unique(array_map('absint', $out)));
        $cache[$cache_key] = $out;
        return $out;
    }
}

if (!function_exists('vms_ops_ticket_resolve_event_plan_id_for_guest_list')) {
    function vms_ops_ticket_resolve_event_plan_id_for_guest_list(int $event_id, string $event_source = ''): int
    {
        $event_id = absint($event_id);
        if ($event_id <= 0) {
            return 0;
        }

        $event_source = sanitize_key($event_source);
        if ($event_source === '') {
            $event_source = sanitize_key((string) get_post_type($event_id));
        }

        if ($event_source === 'vms_event_plan') {
            $valid_ids = vms_ops_ticket_event_plan_ids_with_guest_list_entries(0, 2000);
            return in_array($event_id, $valid_ids, true) ? $event_id : 0;
        }

        if (!vms_ops_has_core_function('vms_get_event_plan_for_tec_event')) {
            return 0;
        }

        $event_plan_id = (int) vms_ops_call_core_function('vms_get_event_plan_for_tec_event', $event_id);
        if ($event_plan_id <= 0) {
            return 0;
        }

        $valid_ids = vms_ops_ticket_event_plan_ids_with_guest_list_entries(0, 2000);
        return in_array($event_plan_id, $valid_ids, true) ? $event_plan_id : 0;
    }
}

if (!function_exists('vms_ops_ticket_get_active_events')) {
    function vms_ops_ticket_get_active_events(int $venue_id = 0, int $limit = 50): array
    {
        $limit = max(1, min(200, $limit));
        $guest_list_event_plan_ids = function_exists('vms_ops_ticket_event_plan_ids_with_guest_list_entries')
            ? vms_ops_ticket_event_plan_ids_with_guest_list_entries($venue_id, max(200, $limit * 8))
            : array();
        $guest_list_event_plan_set = array();
        foreach ($guest_list_event_plan_ids as $event_plan_id) {
            $guest_list_event_plan_set[(int) $event_plan_id] = true;
        }

        $types = vms_ops_ticket_supported_post_types();
        $posts = get_posts(array(
            'post_type' => $types,
            'post_status' => array('publish', 'future', 'private'),
            'numberposts' => $limit * 4,
            'orderby' => 'date',
            'order' => 'ASC',
            'suppress_filters' => false,
        ));

        $events = array();
        $seen = array();
        foreach ((array) $posts as $post) {
            if (!($post instanceof WP_Post)) {
                continue;
            }

            $event = vms_ops_ticket_prepare_event($post);
            if ($post->post_type === 'vms_event_plan' && !isset($guest_list_event_plan_set[(int) $post->ID])) {
                continue;
            }
            $event_key = (string) ($event['source'] ?? '') . ':' . (string) ($event['id'] ?? 0);
            if ($event_key !== ':' && isset($seen[$event_key])) {
                continue;
            }

            if ($venue_id > 0) {
                $eventVenue = (int) ($event['venue_id'] ?? 0);
                // Only filter when the event is mapped to a VMS venue. Unmapped events are still shown.
                if ($eventVenue > 0 && $eventVenue !== $venue_id) {
                    continue;
                }
            }

            if (vms_ops_ticket_is_expired(
                (string) $event['end_at'],
                (string) ($event['start_at'] ?? ''),
                (string) ($event['checkin_close_at'] ?? ($event['scan_closes_at'] ?? ''))
            )) {
                continue;
            }

            $seen[$event_key] = true;
            $events[] = $event;
        }

        foreach ($guest_list_event_plan_ids as $event_plan_id) {
            if (count($events) >= $limit) {
                break;
            }
            $event_plan_id = absint($event_plan_id);
            if ($event_plan_id <= 0) {
                continue;
            }
            $event_key = 'vms_event_plan:' . (string) $event_plan_id;
            if (isset($seen[$event_key])) {
                continue;
            }
            $post = get_post($event_plan_id);
            if (!($post instanceof WP_Post) || $post->post_type !== 'vms_event_plan') {
                continue;
            }
            if (!in_array((string) $post->post_status, array('publish', 'future', 'private'), true)) {
                continue;
            }

            $event = vms_ops_ticket_prepare_event($post);
            if ($venue_id > 0) {
                $eventVenue = (int) ($event['venue_id'] ?? 0);
                if ($eventVenue > 0 && $eventVenue !== $venue_id) {
                    continue;
                }
            }
            if (vms_ops_ticket_is_expired(
                (string) $event['end_at'],
                (string) ($event['start_at'] ?? ''),
                (string) ($event['checkin_close_at'] ?? ($event['scan_closes_at'] ?? ''))
            )) {
                continue;
            }

            $seen[$event_key] = true;
            $events[] = $event;
        }

        usort($events, static function (array $left, array $right): int {
            return strcmp((string) $left['start_at'], (string) $right['start_at']);
        });

        if (count($events) > $limit) {
            $events = array_slice($events, 0, $limit);
        }

        return $events;
    }
}

if (!function_exists('vms_ops_ticket_get_event')) {
    function vms_ops_ticket_get_event(int $event_id, string $source = ''): ?array
    {
        $post = get_post($event_id);
        if (!($post instanceof WP_Post)) {
            return null;
        }

        $types = vms_ops_ticket_supported_post_types();
        if (!in_array($post->post_type, $types, true)) {
            return null;
        }

        if ($source !== '' && $post->post_type !== $source) {
            return null;
        }

        $event = vms_ops_ticket_prepare_event($post);
        if ($post->post_type === 'vms_event_plan') {
            $event_plan_id = function_exists('vms_ops_ticket_resolve_event_plan_id_for_guest_list')
                ? vms_ops_ticket_resolve_event_plan_id_for_guest_list((int) $post->ID, 'vms_event_plan')
                : 0;
            if ($event_plan_id <= 0) {
                return null;
            }
        }
        if (vms_ops_ticket_is_expired(
            (string) $event['end_at'],
            (string) ($event['start_at'] ?? ''),
            (string) ($event['checkin_close_at'] ?? ($event['scan_closes_at'] ?? ''))
        )) {
            return null;
        }

        return $event;
    }
}

if (!function_exists('vms_ops_ticket_attendee_key')) {
    function vms_ops_ticket_attendee_key(array $attendee): string
    {
        $ref = (string) ($attendee['ticket_ref'] ?? '');
        $id = (string) ($attendee['attendee_id'] ?? '');
        if ($id !== '' && $id !== '0') {
            return 'id:' . $id;
        }
        if ($ref !== '') {
            return 'ref:' . strtolower($ref);
        }
        return 'name:' . strtolower((string) ($attendee['name'] ?? '')) . '|' . strtolower((string) ($attendee['email'] ?? ''));
    }
}

if (!function_exists('vms_ops_ticket_attendee_post_types')) {
    function vms_ops_ticket_attendee_post_types(): array
    {
        return array(
            'tribe_rsvp_attendee',
            'tribe_rsvp_attendees',
            'tribe_tpp_attendee',
            'tribe_tpp_attendees',
            'tribe_wooticket',
            'tribe_wooticket_attendees',
            'tribe_wootickets_attendees',
        );
    }
}

if (!function_exists('vms_ops_ticket_attendee_event_meta_keys')) {
    function vms_ops_ticket_attendee_event_meta_keys(): array
    {
        return array(
            '_tribe_event_id',
            '_tribe_ticket_event',
            '_tribe_rsvp_event',
            '_tribe_wooticket_event',
        );
    }
}

if (!function_exists('vms_ops_ticket_attendee_reference_meta_keys')) {
    function vms_ops_ticket_attendee_reference_meta_keys(): array
    {
        return array(
            '_unique_id',
            '_tribe_ticket_id',
            '_tribe_wooticket_security_code',
            '_tec_tickets_commerce_security_code',
        );
    }
}

if (!function_exists('vms_ops_ticket_attendee_email_meta_keys')) {
    function vms_ops_ticket_attendee_email_meta_keys(): array
    {
        return array(
            '_tribe_attendee_email',
            '_tribe_email',
        );
    }
}

if (!function_exists('vms_ops_ticket_normalize_attendee_row')) {
    function vms_ops_ticket_normalize_attendee_row(array $raw): array
    {
        $attendee_id = (int) ($raw['attendee_id'] ?? ($raw['id'] ?? 0));
        $name = sanitize_text_field((string) ($raw['holder_name'] ?? ($raw['full_name'] ?? ($raw['attendee_name'] ?? ($raw['name'] ?? '')))));
        $email = sanitize_email((string) ($raw['holder_email'] ?? ($raw['email'] ?? '')));

        $ticket_ref = (string) ($raw['ticket_id'] ?? ($raw['order_id'] ?? ''));
        if ($ticket_ref === '' && $attendee_id > 0) {
            $ticket_ref = (string) $attendee_id;
        }

        $checked_in = !empty($raw['checked_in']) || !empty($raw['check_in']) ? 1 : 0;

        return array(
            'attendee_id' => $attendee_id,
            'name' => $name,
            'email' => $email,
            'ticket_ref' => sanitize_text_field($ticket_ref),
            'checked_in' => $checked_in,
        );
    }
}

if (!function_exists('vms_ops_ticket_get_event_attendee_from_post')) {
    function vms_ops_ticket_get_event_attendee_from_post(int $post_id, int $event_id = 0): ?array
    {
        $post_id = absint($post_id);
        if ($post_id <= 0) {
            return null;
        }

        $post = get_post($post_id);
        if (!($post instanceof WP_Post)) {
            return null;
        }

        if (!in_array((string) $post->post_type, vms_ops_ticket_attendee_post_types(), true)) {
            return null;
        }

        if (!in_array((string) $post->post_status, array('publish', 'private'), true)) {
            return null;
        }

        $linked_event_id = 0;
        foreach (vms_ops_ticket_attendee_event_meta_keys() as $meta_key) {
            $maybe = (int) get_post_meta($post_id, $meta_key, true);
            if ($maybe > 0) {
                $linked_event_id = $maybe;
                break;
            }
        }

        if ($event_id > 0 && $linked_event_id !== $event_id) {
            return null;
        }

        return vms_ops_ticket_normalize_attendee_row(array(
            'attendee_id' => $post_id,
            'holder_name' => (string) (get_post_meta($post_id, '_tribe_attendee_name', true) ?: get_post_meta($post_id, '_tribe_full_name', true) ?: get_post_meta($post_id, '_tribe_tickets_full_name', true)),
            'holder_email' => (string) (get_post_meta($post_id, '_tribe_attendee_email', true) ?: get_post_meta($post_id, '_tribe_email', true) ?: get_post_meta($post_id, '_tribe_tickets_email', true)),
            'ticket_id' => (string) (
                get_post_meta($post_id, '_unique_id', true)
                ?: get_post_meta($post_id, '_tribe_ticket_id', true)
                ?: get_post_meta($post_id, '_tribe_wooticket_security_code', true)
                ?: get_post_meta($post_id, '_tec_tickets_commerce_security_code', true)
            ),
            'checked_in' => (int) get_post_meta($post_id, '_tribe_qr_status', true) > 0 ? 1 : 0,
        ));
    }
}

if (!function_exists('vms_ops_ticket_find_attendee_post_id')) {
    function vms_ops_ticket_find_attendee_post_id(int $event_id, string $scan_reference): int
    {
        $event_id = absint($event_id);
        $scan_reference = trim(sanitize_text_field($scan_reference));
        if ($event_id <= 0 || $scan_reference === '') {
            return 0;
        }

        if (ctype_digit($scan_reference)) {
            $post_id = absint($scan_reference);
            return is_array(vms_ops_ticket_get_event_attendee_from_post($post_id, $event_id)) ? $post_id : 0;
        }

        global $wpdb;
        if (!($wpdb instanceof wpdb)) {
            return 0;
        }

        $post_types = vms_ops_ticket_attendee_post_types();
        $event_meta_keys = vms_ops_ticket_attendee_event_meta_keys();
        $lookup_meta_keys = strpos($scan_reference, '@') !== false
            ? vms_ops_ticket_attendee_email_meta_keys()
            : vms_ops_ticket_attendee_reference_meta_keys();

        $post_type_placeholders = implode(', ', array_fill(0, count($post_types), '%s'));
        $event_meta_placeholders = implode(', ', array_fill(0, count($event_meta_keys), '%s'));
        $lookup_meta_placeholders = implode(', ', array_fill(0, count($lookup_meta_keys), '%s'));

        $sql = "
            SELECT p.ID
            FROM {$wpdb->posts} p
            WHERE p.post_type IN ({$post_type_placeholders})
              AND p.post_status IN ('publish', 'private')
              AND EXISTS (
                  SELECT 1
                  FROM {$wpdb->postmeta} em
                  WHERE em.post_id = p.ID
                    AND em.meta_key IN ({$event_meta_placeholders})
                    AND em.meta_value = %d
              )
              AND EXISTS (
                  SELECT 1
                  FROM {$wpdb->postmeta} lm
                  WHERE lm.post_id = p.ID
                    AND lm.meta_key IN ({$lookup_meta_placeholders})
                    AND lm.meta_value = %s
              )
            ORDER BY p.ID DESC
            LIMIT 1
        ";

        $params = array_merge(
            $post_types,
            $event_meta_keys,
            array($event_id),
            $lookup_meta_keys,
            array($scan_reference)
        );

        return absint($wpdb->get_var($wpdb->prepare($sql, $params)));
    }
}

if (!function_exists('vms_ops_ticket_get_event_attendee_by_scan_reference')) {
    function vms_ops_ticket_get_event_attendee_by_scan_reference(int $event_id, string $scan_reference): ?array
    {
        $post_id = vms_ops_ticket_find_attendee_post_id($event_id, $scan_reference);
        if ($post_id <= 0) {
            return null;
        }

        return vms_ops_ticket_get_event_attendee_from_post($post_id, $event_id);
    }
}

if (!function_exists('vms_ops_ticket_get_event_attendees_from_tribe')) {
    function vms_ops_ticket_get_event_attendees_from_tribe(int $event_id): array
    {
        $raw = null;

        // Preferred: Event Tickets API.
        // (Newer versions expose an instance method; calling it statically can return empty or emit notices.)
        if (class_exists('Tribe__Tickets__Tickets')) {
            if (method_exists('Tribe__Tickets__Tickets', 'get_instance')) {
                $instance = Tribe__Tickets__Tickets::get_instance();
                if (is_object($instance) && method_exists($instance, 'get_event_attendees')) {
                    try {
                        $raw = $instance->get_event_attendees($event_id);
                    } catch (Throwable $e) {
                        $raw = null;
                    }
                }
            }

            if (!is_array($raw) && method_exists('Tribe__Tickets__Tickets', 'get_event_attendees')) {
                try {
                    $raw = Tribe__Tickets__Tickets::get_event_attendees($event_id);
                } catch (Throwable $e) {
                    $raw = null;
                }
            }
        }

        // Back-compat helpers (older ET versions).
        if (!is_array($raw) && function_exists('tribe_tickets_get_attendees')) {
            $raw = tribe_tickets_get_attendees($event_id);
        }
        if (!is_array($raw) && function_exists('tribe_tickets_get_event_attendees')) {
            $raw = tribe_tickets_get_event_attendees($event_id);
        }

        if (!is_array($raw)) {
            return array();
        }

        $out = array();
        foreach ($raw as $item) {
            if ($item instanceof WP_Post) {
                $out[] = vms_ops_ticket_normalize_attendee_row(array(
                    "attendee_id" => (int) $item->ID,
                    "holder_name" => (string) (get_post_meta($item->ID, "_tribe_attendee_name", true) ?: get_post_meta($item->ID, "_tribe_full_name", true)),
                    "holder_email" => (string) (get_post_meta($item->ID, "_tribe_attendee_email", true) ?: get_post_meta($item->ID, "_tribe_email", true)),
                    "ticket_id" => (string) (get_post_meta($item->ID, "_unique_id", true) ?: get_post_meta($item->ID, "_tribe_ticket_id", true) ?: get_post_meta($item->ID, "_tribe_wooticket_security_code", true) ?: get_post_meta($item->ID, "_tribe_product_id", true)),
                    "checked_in" => (int) get_post_meta($item->ID, "_tribe_qr_status", true) > 0 ? 1 : 0,
                ));
                continue;
            }

            if (is_object($item) && isset($item->ID)) {
                $post_id = (int) $item->ID;
                if ($post_id > 0) {
                    $out[] = vms_ops_ticket_normalize_attendee_row(array(
                        "attendee_id" => $post_id,
                        "holder_name" => (string) (get_post_meta($post_id, "_tribe_attendee_name", true) ?: get_post_meta($post_id, "_tribe_full_name", true)),
                        "holder_email" => (string) (get_post_meta($post_id, "_tribe_attendee_email", true) ?: get_post_meta($post_id, "_tribe_email", true)),
                        "ticket_id" => (string) (get_post_meta($post_id, "_unique_id", true) ?: get_post_meta($post_id, "_tribe_ticket_id", true) ?: get_post_meta($post_id, "_tribe_wooticket_security_code", true) ?: get_post_meta($post_id, "_tribe_product_id", true)),
                        "checked_in" => (int) get_post_meta($post_id, "_tribe_qr_status", true) > 0 ? 1 : 0,
                    ));
                    continue;
                }
            }

            if (!is_array($item)) {
                continue;
            }

            $out[] = vms_ops_ticket_normalize_attendee_row($item);
        }

        return $out;
    }
}

if (!function_exists('vms_ops_ticket_get_event_attendees_from_posts')) {
    function vms_ops_ticket_get_event_attendees_from_posts(int $event_id): array
    {
        $posts = get_posts(array(
            'post_type' => vms_ops_ticket_attendee_post_types(),
            'post_status' => array('publish', 'private'),
            'numberposts' => 1000,
            'orderby' => 'ID',
            'order' => 'DESC',
        ));

        $rows = array();
        foreach ((array) $posts as $post) {
            if (!($post instanceof WP_Post)) {
                continue;
            }

            $normalized = vms_ops_ticket_get_event_attendee_from_post((int) $post->ID, $event_id);
            if (!is_array($normalized)) {
                continue;
            }

            $rows[] = $normalized;
        }

        $out = array();
        foreach ($rows as $row) {
            $out[] = vms_ops_ticket_normalize_attendee_row($row);
        }

        return $out;
    }
}

if (!function_exists('vms_ops_ticket_get_event_attendees')) {
    function vms_ops_ticket_get_event_attendees(int $event_id, string $event_source = ''): array
    {
        $from_tribe = vms_ops_ticket_get_event_attendees_from_tribe($event_id);
        $from_posts = vms_ops_ticket_get_event_attendees_from_posts($event_id);
        $from_guest_list = function_exists('vms_ops_ticket_get_event_attendees_from_guest_list')
            ? vms_ops_ticket_get_event_attendees_from_guest_list($event_id, $event_source)
            : array();

        $merged = array();
        $index = array();
        foreach (array_merge($from_tribe, $from_posts, $from_guest_list) as $attendee) {
            $key = vms_ops_ticket_attendee_key($attendee);
            if (isset($index[$key])) {
                continue;
            }
            $index[$key] = true;
            $merged[] = $attendee;
        }

        $scan_hashes_by_index = array();
        foreach ($merged as $idx => $attendee) {
            $scan_hash = vms_ops_hash_scan_payload((string) ($attendee['ticket_ref'] ?? ''));
            if ($scan_hash === '') {
                continue;
            }

            $scan_hashes_by_index[$idx] = $scan_hash;
        }

        $duplicate_hashes = function_exists('vms_ops_pc_ticket_duplicate_scan_hashes_for_event')
            ? vms_ops_pc_ticket_duplicate_scan_hashes_for_event($event_id, array_values($scan_hashes_by_index))
            : array();

        foreach ($merged as $idx => &$attendee) {
            $scan_hash = $scan_hashes_by_index[$idx] ?? '';
            $attendee['checked_in_local'] = ($scan_hash !== '' && !empty($duplicate_hashes[$scan_hash])) ? 1 : 0;
        }
        unset($attendee);

        return $merged;
    }
}

if (!function_exists('vms_ops_ticket_get_event_attendees_from_guest_list')) {
    /**
     * Pull Guest List / Comp Admission entries from VMS and expose them as "attendees" in Ops.
     *
     * This keeps the door workflow dead-simple: Guest List entries show up in Attendee Lookup
     * and can be checked in using the same console.
     */
    function vms_ops_ticket_get_event_attendees_from_guest_list(int $event_id, string $event_source = ''): array
    {
        $event_plan_id = function_exists('vms_ops_ticket_resolve_event_plan_id_for_guest_list')
            ? (int) vms_ops_ticket_resolve_event_plan_id_for_guest_list($event_id, $event_source)
            : 0;
        if ($event_plan_id <= 0) {
            return array();
        }

        global $wpdb;
        $table = $wpdb->prefix . 'vms_admission_entries';

        // Only active + checked-in entries should be considered at the door.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, guest_name, phone, notes, party_size, checked_in_qty, status, checked_in_at FROM {$table} WHERE event_plan_id = %d AND status IN ('active','partial','checked_in') ORDER BY id DESC",
                $event_plan_id
            ),
            ARRAY_A
        );

        if (!is_array($rows) || empty($rows)) {
            return array();
        }

        $out = array();
        foreach ($rows as $row) {
            $entry_id = (int) ($row['id'] ?? 0);
            if ($entry_id <= 0) {
                continue;
            }

            $ticket_ref = 'gl:' . $entry_id;

            $party_size = max(1, (int) ($row['party_size'] ?? 1));
            $checked_in_qty = max(0, (int) ($row['checked_in_qty'] ?? 0));
            $checked_in = ($checked_in_qty >= $party_size) || ((string) ($row['status'] ?? '') === 'checked_in');
            $out[] = array(
                // Keep attendee_id at 0 to avoid collisions with TEC attendee IDs.
                'attendee_id' => 0,
                'name' => sanitize_text_field((string) ($row['guest_name'] ?? '')),
                'email' => '',
                'ticket_ref' => $ticket_ref,
                'checked_in' => $checked_in ? 1 : 0,
                'kind' => 'guest_list',
                'party_size' => $party_size,
                'checked_in_qty' => $checked_in_qty,
                'remaining_qty' => max(0, $party_size - $checked_in_qty),
                'phone' => sanitize_text_field((string) ($row['phone'] ?? '')),
                'notes' => sanitize_text_field((string) ($row['notes'] ?? '')),
                'checked_in_at' => sanitize_text_field((string) ($row['checked_in_at'] ?? '')),
                'status' => sanitize_key((string) ($row['status'] ?? '')),
            );
        }

        return $out;
    }
}
