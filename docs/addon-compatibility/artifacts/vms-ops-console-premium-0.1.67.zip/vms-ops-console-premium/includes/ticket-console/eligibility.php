<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_ticket_status_key')) {
    function vms_ops_ticket_status_key(string $status): string
    {
        if (function_exists('sanitize_key')) {
            return sanitize_key($status);
        }

        $status = strtolower(trim($status));
        return preg_replace('/[^a-z0-9_\-]/', '', $status) ?: '';
    }
}

if (!function_exists('vms_ops_ticket_default_event_duration_hours')) {
    function vms_ops_ticket_default_event_duration_hours(): int
    {
        $hours = 2;
        if (function_exists('apply_filters')) {
            $hours = (int) apply_filters('vms_ops_ticket_default_event_duration_hours', $hours);
        }

        return max(1, min(12, $hours));
    }
}

if (!function_exists('vms_ops_ticket_parse_datetime_like')) {
    function vms_ops_ticket_parse_datetime_like($value): ?DateTimeImmutable
    {
        if ($value instanceof DateTimeImmutable) {
            return $value;
        }

        if ($value instanceof DateTimeInterface) {
            return new DateTimeImmutable($value->format(DateTimeInterface::ATOM));
        }

        $raw = trim((string) $value);
        if ($raw === '') {
            return null;
        }

        if (function_exists('vms_ops_parse_wp_datetime')) {
            $parsed = vms_ops_parse_wp_datetime($raw);
            if ($parsed instanceof DateTimeImmutable) {
                return $parsed;
            }
        }

        $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
        try {
            return new DateTimeImmutable($raw, $tz);
        } catch (Exception $exception) {
            return null;
        }
    }
}

if (!function_exists('vms_ops_ticket_default_event_end_datetime')) {
    function vms_ops_ticket_default_event_end_datetime(DateTimeImmutable $showtime): DateTimeImmutable
    {
        return $showtime->add(new DateInterval('PT' . vms_ops_ticket_default_event_duration_hours() . 'H'));
    }
}

if (!function_exists('vms_ops_ticket_resolve_operational_event_end')) {
    function vms_ops_ticket_resolve_operational_event_end(
        ?DateTimeImmutable $showtime,
        ?DateTimeImmutable $raw_end = null,
        ?DateTimeImmutable $canonical_end = null
    ): array {
        $candidates = array(
            'canonical_end' => $canonical_end,
            'event_end' => $raw_end,
        );

        foreach ($candidates as $source => $candidate) {
            if (!($candidate instanceof DateTimeImmutable)) {
                continue;
            }
            if ($showtime instanceof DateTimeImmutable && $candidate <= $showtime) {
                continue;
            }

            return array(
                'datetime' => $candidate,
                'source' => $source,
                'used_fallback' => false,
            );
        }

        if ($showtime instanceof DateTimeImmutable) {
            return array(
                'datetime' => vms_ops_ticket_default_event_end_datetime($showtime),
                'source' => 'fallback_duration',
                'used_fallback' => true,
            );
        }

        foreach ($candidates as $source => $candidate) {
            if ($candidate instanceof DateTimeImmutable) {
                return array(
                    'datetime' => $candidate,
                    'source' => $source,
                    'used_fallback' => false,
                );
            }
        }

        return array(
            'datetime' => null,
            'source' => 'missing',
            'used_fallback' => false,
        );
    }
}

if (!function_exists('vms_ops_ticket_get_scanner_eligibility')) {
    function vms_ops_ticket_get_scanner_eligibility(array $input): array
    {
        $now = vms_ops_ticket_parse_datetime_like($input['now'] ?? null);
        if (!($now instanceof DateTimeImmutable)) {
            $now = function_exists('vms_ops_now_datetime')
                ? vms_ops_now_datetime()
                : new DateTimeImmutable('now', function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC'));
        }

        $showtime = vms_ops_ticket_parse_datetime_like($input['showtime_at'] ?? ($input['start_at'] ?? null));
        $checkin_open = vms_ops_ticket_parse_datetime_like($input['checkin_open_at'] ?? null);
        $checkin_close = vms_ops_ticket_parse_datetime_like($input['checkin_close_at'] ?? null);
        $session_expires = vms_ops_ticket_parse_datetime_like($input['scanner_session_expires_at'] ?? null);

        $status = vms_ops_ticket_status_key((string) ($input['event_status'] ?? ''));
        $cancelled = !empty($input['event_cancelled']);
        $deleted = !empty($input['event_deleted']) || !empty($input['event_archived']);
        $operator_authorized = !array_key_exists('operator_authorized', $input) || !empty($input['operator_authorized']);
        $session_revoked = !empty($input['scanner_session_revoked']);

        $disallowed_status_reasons = array(
            'cancelled' => 'EVENT_CANCELLED',
            'deleted' => 'EVENT_DELETED',
            'archived' => 'EVENT_DELETED',
            'trash' => 'EVENT_DELETED',
            'completed' => 'CHECK_IN_CLOSED',
            'ended' => 'CHECK_IN_CLOSED',
            'closed' => 'CHECK_IN_CLOSED',
            'check_in_closed' => 'CHECK_IN_CLOSED',
        );

        $reason = 'ALLOWED';
        if ($cancelled || (isset($disallowed_status_reasons[$status]) && $disallowed_status_reasons[$status] === 'EVENT_CANCELLED')) {
            $reason = 'EVENT_CANCELLED';
        } elseif ($deleted || (isset($disallowed_status_reasons[$status]) && $disallowed_status_reasons[$status] === 'EVENT_DELETED')) {
            $reason = 'EVENT_DELETED';
        } elseif (!$operator_authorized) {
            $reason = 'UNAUTHORIZED';
        } elseif ($session_revoked) {
            $reason = 'SCANNER_SESSION_REVOKED';
        } elseif ($session_expires instanceof DateTimeImmutable && $now > $session_expires) {
            $reason = 'SCANNER_SESSION_EXPIRED';
        } elseif ($checkin_open instanceof DateTimeImmutable && $now < $checkin_open) {
            $reason = 'CHECK_IN_NOT_OPEN_YET';
        } elseif ($checkin_close instanceof DateTimeImmutable && $now > $checkin_close) {
            $reason = 'CHECK_IN_CLOSED';
        } elseif (isset($disallowed_status_reasons[$status])) {
            $reason = $disallowed_status_reasons[$status];
        }

        return array(
            'allowed' => $reason === 'ALLOWED',
            'reason' => $reason,
            'now' => $now,
            'showtime' => $showtime,
            'checkin_open' => $checkin_open,
            'checkin_close' => $checkin_close,
            'event_status' => $status,
            'scanner_session_expires_at' => $session_expires,
        );
    }
}
