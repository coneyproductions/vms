<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_encryption_key')) {
    function vms_ops_encryption_key(): string
    {
        $material = wp_salt('auth') . '|' . wp_salt('secure_auth') . '|vms_ops_console_private_club';
        return hash('sha256', $material, true);
    }
}

if (!function_exists('vms_ops_encrypt_text')) {
    function vms_ops_encrypt_text(string $plaintext)
    {
        if ($plaintext === '') {
            return '';
        }

        if (!function_exists('openssl_encrypt')) {
            return new WP_Error('openssl_missing', __('OpenSSL is required for address encryption.', 'vms-ops-console-premium'));
        }

        try {
            $iv = random_bytes(12);
        } catch (Exception $exception) {
            return new WP_Error('encryption_iv_error', $exception->getMessage());
        }

        $tag = '';
        $ciphertext = openssl_encrypt(
            $plaintext,
            'aes-256-gcm',
            vms_ops_encryption_key(),
            OPENSSL_RAW_DATA,
            $iv,
            $tag,
            '',
            16
        );

        if ($ciphertext === false) {
            return new WP_Error('encryption_failed', __('Could not encrypt payload.', 'vms-ops-console-premium'));
        }

        return base64_encode($iv . $tag . $ciphertext);
    }
}

if (!function_exists('vms_ops_decrypt_text')) {
    function vms_ops_decrypt_text(string $packed)
    {
        if ($packed === '') {
            return '';
        }

        if (!function_exists('openssl_decrypt')) {
            return new WP_Error('openssl_missing', __('OpenSSL is required for address decryption.', 'vms-ops-console-premium'));
        }

        $raw = base64_decode($packed, true);
        if (!is_string($raw) || strlen($raw) < 28) {
            return new WP_Error('invalid_encrypted_payload', __('Invalid encrypted payload format.', 'vms-ops-console-premium'));
        }

        $iv = substr($raw, 0, 12);
        $tag = substr($raw, 12, 16);
        $ciphertext = substr($raw, 28);

        $plaintext = openssl_decrypt(
            $ciphertext,
            'aes-256-gcm',
            vms_ops_encryption_key(),
            OPENSSL_RAW_DATA,
            $iv,
            $tag,
            ''
        );

        if ($plaintext === false) {
            return new WP_Error('decryption_failed', __('Could not decrypt payload.', 'vms-ops-console-premium'));
        }

        return (string) $plaintext;
    }
}

if (!function_exists('vms_ops_normalize_address_line')) {
    function vms_ops_normalize_address_line(string $value): string
    {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9]+/', ' ', $value);
        return trim((string) $value);
    }
}

if (!function_exists('vms_ops_build_address_hash')) {
    function vms_ops_build_address_hash(array $address_parts): string
    {
        $ordered = array(
            vms_ops_normalize_address_line((string) ($address_parts['address_line_1'] ?? '')),
            vms_ops_normalize_address_line((string) ($address_parts['address_line_2'] ?? '')),
            vms_ops_normalize_address_line((string) ($address_parts['city'] ?? '')),
            vms_ops_normalize_address_line((string) ($address_parts['state'] ?? '')),
            vms_ops_normalize_address_line((string) ($address_parts['postal_code'] ?? '')),
        );

        return hash('sha256', implode('|', $ordered));
    }
}

if (!function_exists('vms_ops_hash_scan_payload')) {
    function vms_ops_hash_scan_payload(string $payload): string
    {
        return hash('sha256', trim($payload));
    }
}
