<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_alert_recipient_ids_from_json')) {
    function vms_ops_alert_recipient_ids_from_json(string $json): array
    {
        if ($json === '') {
            return array();
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return array();
        }

        $ids = array();
        foreach ($decoded as $user_id) {
            $user_id = (int) $user_id;
            if ($user_id > 0) {
                $ids[] = $user_id;
            }
        }

        return array_values(array_unique($ids));
    }
}

if (!function_exists('vms_ops_alert_user_display_name')) {
    function vms_ops_alert_user_display_name(int $user_id): string
    {
        static $cache = array();

        $user_id = max(0, $user_id);
        if ($user_id <= 0) {
            return '';
        }

        if (array_key_exists($user_id, $cache)) {
            return (string) $cache[$user_id];
        }

        $user = get_userdata($user_id);
        $name = '';
        if ($user instanceof WP_User) {
            $name = trim((string) $user->display_name);
        }
        if ($name === '') {
            $name = sprintf(__('User #%d', 'vms-ops-console-premium'), $user_id);
        }

        $cache[$user_id] = $name;
        return $name;
    }
}

if (!function_exists('vms_ops_alert_enrich_row')) {
    function vms_ops_alert_enrich_row(array $row): array
    {
        $preset_key = sanitize_key((string) ($row['preset_key'] ?? ''));
        $console_type = sanitize_key((string) ($row['console_type'] ?? 'ops'));
        if ($console_type === '') {
            $console_type = 'ops';
        }

        if ($preset_key !== '') {
            $preset = vms_ops_alert_preset_find((int) ($row['venue_id'] ?? 0), $console_type, $preset_key);
            if (is_array($preset)) {
                $row['preset_label'] = (string) ($preset['label'] ?? '');
                if (empty($row['audience']) && !empty($preset['audience'])) {
                    $row['audience'] = sanitize_key((string) $preset['audience']);
                }
            }
        }

        if (empty($row['audience'])) {
            $row['audience'] = 'all';
        }

        $recipient_ids = vms_ops_alert_recipient_ids_from_json((string) ($row['routed_user_ids'] ?? ''));
        $row['recipient_ids'] = $recipient_ids;
        $row['recipient_count'] = count($recipient_ids);
        $row['sender_name'] = vms_ops_alert_user_display_name((int) ($row['sender_user_id'] ?? 0));
        $row['acknowledged_by_name'] = vms_ops_alert_user_display_name((int) ($row['acknowledged_by'] ?? 0));
        $row['is_acknowledged'] = !empty($row['acknowledged_at']) ? 1 : 0;

        return $row;
    }
}

if (!function_exists('vms_ops_alert_send')) {
    function vms_ops_alert_send(array $args)
    {
        $venue_id = absint($args['venue_id'] ?? 0);
        $console_type = sanitize_key((string) ($args['console_type'] ?? 'ops'));
        $preset_key = sanitize_key((string) ($args['preset_key'] ?? ''));
        $urgency = vms_ops_alert_sanitize_urgency((string) ($args['urgency'] ?? 'normal'));
        $message = sanitize_text_field((string) ($args['message'] ?? ''));
        $audience = sanitize_key((string) ($args['audience'] ?? ''));

        if ($venue_id <= 0) {
            return new WP_Error('invalid_venue', __('Venue is required for alerts.', 'vms-ops-console-premium'));
        }

        if ($console_type === '') {
            $console_type = 'ops';
        }

        $preset = null;
        if ($preset_key !== '') {
            $preset = vms_ops_alert_preset_find($venue_id, $console_type, $preset_key);
            if (is_array($preset)) {
                if ($message === '') {
                    $message = (string) ($preset['message'] ?? '');
                }
                if ($urgency === 'normal' && !empty($preset['urgency'])) {
                    $urgency = vms_ops_alert_sanitize_urgency((string) $preset['urgency']);
                }
                if ($audience === '' && !empty($preset['audience'])) {
                    $audience = sanitize_key((string) $preset['audience']);
                }
            }
        }

        if ($audience === '') {
            $audience = 'all';
        }

        if ($message === '') {
            return new WP_Error('invalid_alert_message', __('Alert message is required.', 'vms-ops-console-premium'));
        }

        $route = vms_ops_alert_route_user_ids($venue_id, $audience);
        $recipient_ids = is_array($route['user_ids'] ?? null) ? $route['user_ids'] : array();
        if (empty($recipient_ids)) {
            return new WP_Error('no_alert_recipients', __('No alert recipients are currently available.', 'vms-ops-console-premium'));
        }

        $json_recipients = wp_json_encode(array_values(array_unique(array_map('intval', $recipient_ids))));
        if (!is_string($json_recipients)) {
            $json_recipients = '[]';
        }

        global $wpdb;
        $inserted = $wpdb->insert(
            vms_ops_table_alerts(),
            array(
                'venue_id' => $venue_id,
                'sender_user_id' => get_current_user_id(),
                'preset_key' => $preset_key !== '' ? $preset_key : null,
                'message' => $message,
                'urgency' => $urgency,
                'console_type' => $console_type,
                'routed_user_ids' => $json_recipients,
                'created_at' => vms_ops_now_mysql(),
                'acknowledged_by' => null,
                'acknowledged_at' => null,
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s')
        );

        if ($inserted === false) {
            return vms_ops_db_write_error('alert_insert_failed', __('Could not send alert.', 'vms-ops-console-premium'));
        }

        $alert_id = (int) $wpdb->insert_id;

        $audit = vms_ops_pc_audit_log($venue_id, null, 'alert_send', array(
            'alert_id' => $alert_id,
            'urgency' => $urgency,
            'preset_key' => $preset_key,
            'audience' => $audience,
            'route_strategy' => (string) ($route['strategy'] ?? 'unknown'),
            'recipient_count' => count($recipient_ids),
        ));
        if (is_wp_error($audit)) {
            return $audit;
        }

        $response = array(
            'id' => $alert_id,
            'venue_id' => $venue_id,
            'preset_key' => $preset_key,
            'preset_label' => is_array($preset) ? (string) ($preset['label'] ?? '') : '',
            'message' => $message,
            'urgency' => $urgency,
            'console_type' => $console_type,
            'created_at' => vms_ops_now_mysql(),
            'sender_user_id' => get_current_user_id(),
            'routed_user_ids' => $json_recipients,
            'acknowledged_by' => null,
            'acknowledged_at' => null,
            'audience' => $audience,
            'route_strategy' => (string) ($route['strategy'] ?? 'unknown'),
        );

        return vms_ops_alert_enrich_row($response);
    }
}

if (!function_exists('vms_ops_alert_acknowledge')) {
    function vms_ops_alert_acknowledge(int $alert_id, int $user_id = 0)
    {
        if ($alert_id <= 0) {
            return new WP_Error('invalid_alert_id', __('Alert id is required.', 'vms-ops-console-premium'));
        }

        if ($user_id <= 0) {
            $user_id = get_current_user_id();
        }

        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare('SELECT * FROM ' . vms_ops_table_alerts() . ' WHERE id = %d LIMIT 1', $alert_id),
            ARRAY_A
        );

        if (!is_array($row)) {
            return new WP_Error('alert_not_found', __('Alert not found.', 'vms-ops-console-premium'));
        }

        if (!empty($row['acknowledged_at'])) {
            return vms_ops_alert_enrich_row($row);
        }

        $updated = $wpdb->update(
            vms_ops_table_alerts(),
            array(
                'acknowledged_by' => $user_id,
                'acknowledged_at' => vms_ops_now_mysql(),
            ),
            array('id' => $alert_id),
            array('%d', '%s'),
            array('%d')
        );

        if ($updated === false) {
            return vms_ops_db_write_error('alert_ack_failed', __('Could not acknowledge alert.', 'vms-ops-console-premium'));
        }

        $audit_warning = '';
        $audit = vms_ops_pc_audit_log((int) ($row['venue_id'] ?? 0), null, 'alert_ack', array(
            'alert_id' => $alert_id,
            'acknowledged_by' => $user_id,
            'sender_user_id' => (int) ($row['sender_user_id'] ?? 0),
        ));
        if (is_wp_error($audit)) {
            $audit_warning = (string) $audit->get_error_message();
        }

        $fresh = $wpdb->get_row(
            $wpdb->prepare('SELECT * FROM ' . vms_ops_table_alerts() . ' WHERE id = %d LIMIT 1', $alert_id),
            ARRAY_A
        );

        if (!is_array($fresh)) {
            return new WP_Error('alert_lookup_failed', __('Could not load acknowledged alert.', 'vms-ops-console-premium'));
        }

        $enriched = vms_ops_alert_enrich_row($fresh);
        if ($audit_warning !== '') {
            $enriched['audit_warning'] = $audit_warning;
        }

        return $enriched;
    }
}

if (!function_exists('vms_ops_alert_inbox_for_user')) {
    function vms_ops_alert_inbox_for_user(int $user_id, int $venue_id = 0, int $since_id = 0, int $limit = 40): array
    {
        $user_id = max(0, $user_id);
        if ($user_id <= 0) {
            return array();
        }

        global $wpdb;

        $where = array('id > %d', 'routed_user_ids LIKE %s');
        $params = array(
            max(0, $since_id),
            '%"' . $wpdb->esc_like((string) $user_id) . '"%',
        );

        if ($venue_id > 0) {
            $where[] = 'venue_id = %d';
            $params[] = $venue_id;
        }

        $limit = max(1, min(200, $limit));

        $sql = 'SELECT id, venue_id, sender_user_id, preset_key, message, urgency, console_type, routed_user_ids, created_at, acknowledged_by, acknowledged_at
            FROM ' . vms_ops_table_alerts() . '
            WHERE ' . implode(' AND ', $where) . '
            ORDER BY id DESC
            LIMIT %d';
        $params[] = $limit;

        $prepared = $wpdb->prepare($sql, $params);
        $rows = $wpdb->get_results($prepared, ARRAY_A);
        if (!is_array($rows)) {
            return array();
        }

        $enriched = array();
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $enriched[] = vms_ops_alert_enrich_row($row);
        }

        return $enriched;
    }
}
