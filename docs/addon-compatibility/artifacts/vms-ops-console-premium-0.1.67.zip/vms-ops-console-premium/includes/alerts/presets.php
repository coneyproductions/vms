<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_alert_default_presets')) {
    function vms_ops_alert_default_presets(): array
    {
        return array(
            array(
                'key' => 'call_staff',
                'label' => __('Alert Staff', 'vms-ops-console-premium'),
                'audience' => 'all',
                'urgency' => 'high',
                'message' => __('Staff assist needed at console.', 'vms-ops-console-premium'),
            ),
            array(
                'key' => 'id_issue',
                'label' => __('ID Issue', 'vms-ops-console-premium'),
                'audience' => 'id',
                'urgency' => 'normal',
                'message' => __('Assistance requested for ID verification.', 'vms-ops-console-premium'),
            ),
            array(
                'key' => 'security_assist',
                'label' => __('Security Assist', 'vms-ops-console-premium'),
                'audience' => 'managers',
                'urgency' => 'critical',
                'message' => __('Security assistance required immediately.', 'vms-ops-console-premium'),
            ),
            array(
                'key' => 'banned_scan',
                'label' => __('Banned Scan', 'vms-ops-console-premium'),
                'audience' => 'managers',
                'urgency' => 'critical',
                'message' => __('Banned member scan detected. Manager required.', 'vms-ops-console-premium'),
            ),
        );
    }
}

if (!function_exists('vms_ops_alert_sanitize_urgency')) {
    function vms_ops_alert_sanitize_urgency(string $urgency): string
    {
        $urgency = sanitize_key($urgency);
        if (!in_array($urgency, array('low', 'normal', 'high', 'critical'), true)) {
            return 'normal';
        }
        return $urgency;
    }
}

if (!function_exists('vms_ops_alert_preset_storage_key')) {
    function vms_ops_alert_preset_storage_key(int $venue_id, string $console_type): string
    {
        $venue_id = max(0, $venue_id);
        $console_type = sanitize_key($console_type);
        if ($console_type === '') {
            $console_type = 'ops';
        }

        return $venue_id . ':' . $console_type;
    }
}

if (!function_exists('vms_ops_alert_sanitize_presets')) {
    function vms_ops_alert_sanitize_presets($presets): array
    {
        if (!is_array($presets)) {
            return vms_ops_alert_default_presets();
        }
        $allowed_audiences = array('all', 'ticket', 'id', 'managers');
        $clean = array();
        $used_keys = array();

        foreach ($presets as $preset) {
            if (!is_array($preset)) {
                continue;
            }

            $label = sanitize_text_field((string) ($preset['label'] ?? ''));
            $message = sanitize_text_field((string) ($preset['message'] ?? ''));
            $urgency = vms_ops_alert_sanitize_urgency((string) ($preset['urgency'] ?? 'normal'));
            $audience = sanitize_key((string) ($preset['audience'] ?? 'all'));

            $key = sanitize_key((string) ($preset['key'] ?? ''));
            if ($key === '') {
                $key = sanitize_key($label);
            }

            if (!in_array($audience, $allowed_audiences, true)) {
                $audience = 'all';
            }

            // Ensure uniqueness to avoid accidental overwrites.
            if ($key !== '') {
                $base = $key;
                $suffix = 2;
                while (isset($used_keys[$key])) {
                    $key = $base . '_' . (string) $suffix;
                    $suffix++;
                }
            }

            if ($key === '' || $label === '' || $message === '') {
                continue;
            }

            $used_keys[$key] = true;
            $clean[] = array(
                'key' => $key,
                'label' => $label,
                'audience' => $audience,
                'urgency' => $urgency,
                'message' => $message,
            );
        }

        if (empty($clean)) {
            return vms_ops_alert_default_presets();
        }

        return $clean;
    }
}

if (!function_exists('vms_ops_alert_presets_get')) {
    function vms_ops_alert_presets_get(int $venue_id, string $console_type = 'ops'): array
    {
        $all = get_option('vms_ops_alert_presets', array());
        if (!is_array($all)) {
            $all = array();
        }

        $console_type = sanitize_key($console_type);
        if ($console_type === '') {
            $console_type = 'ops';
        }

        $lookup_keys = array(
            vms_ops_alert_preset_storage_key($venue_id, $console_type),
            vms_ops_alert_preset_storage_key($venue_id, 'all'),
            vms_ops_alert_preset_storage_key(0, $console_type),
            vms_ops_alert_preset_storage_key(0, 'all'),
        );

        foreach ($lookup_keys as $key) {
            if (!isset($all[$key]) || !is_array($all[$key])) {
                continue;
            }
            return vms_ops_alert_sanitize_presets($all[$key]);
        }

        return vms_ops_alert_default_presets();
    }
}

if (!function_exists('vms_ops_alert_preset_find')) {
    function vms_ops_alert_preset_find(int $venue_id, string $console_type, string $preset_key): ?array
    {
        $preset_key = sanitize_key($preset_key);
        if ($preset_key === '') {
            return null;
        }

        $presets = vms_ops_alert_presets_get($venue_id, $console_type);
        foreach ($presets as $preset) {
            if (($preset['key'] ?? '') === $preset_key) {
                return $preset;
            }
        }

        return null;
    }
}

if (!function_exists('vms_ops_alert_presets_save')) {
    function vms_ops_alert_presets_save(int $venue_id, string $console_type, array $presets)
    {
        $all = get_option('vms_ops_alert_presets', array());
        if (!is_array($all)) {
            $all = array();
        }

        $key = vms_ops_alert_preset_storage_key($venue_id, $console_type);
        $all[$key] = vms_ops_alert_sanitize_presets($presets);

        $previous = get_option('vms_ops_alert_presets', null);
        $updated = update_option('vms_ops_alert_presets', $all, false);

        if ($updated === false && $previous !== $all) {
            return new WP_Error('alert_preset_save_failed', __('Could not save alert presets.', 'vms-ops-console-premium'));
        }

        return true;
    }
}
