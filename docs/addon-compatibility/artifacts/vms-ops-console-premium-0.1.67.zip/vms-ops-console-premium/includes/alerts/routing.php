<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_alert_filter_receive_cap')) {
    function vms_ops_alert_filter_receive_cap(array $user_ids): array
    {
        $filtered = array();
        foreach ($user_ids as $user_id) {
            $user_id = (int) $user_id;
            if ($user_id <= 0) {
                continue;
            }
            if (!user_can($user_id, vms_ops_capability_receive_alerts()) && !user_can($user_id, 'manage_options')) {
                continue;
            }
            $filtered[] = $user_id;
        }

        return array_values(array_unique($filtered));
    }
}

if (!function_exists('vms_ops_alert_manager_fallback_user_ids')) {
    function vms_ops_alert_manager_fallback_user_ids(): array
    {
        $users = get_users(array(
            'fields' => array('ID'),
            'number' => 200,
            'orderby' => 'ID',
            'order' => 'ASC',
        ));

        $ids = array();
        foreach ($users as $user) {
            $user_id = (int) ($user->ID ?? 0);
            if ($user_id <= 0) {
                continue;
            }
            if (
                user_can($user_id, 'manage_options') ||
                user_can($user_id, vms_ops_capability_manage_members_admin())
            ) {
                $ids[] = $user_id;
            }
        }

        return vms_ops_alert_filter_receive_cap($ids);
    }
}

if (!function_exists('vms_ops_alert_route_user_ids')) {
    function vms_ops_alert_route_user_ids(int $venue_id, string $audience = 'all'): array
    {
        $venue_id = max(0, $venue_id);
        $audience = sanitize_key($audience);
        if ($audience === '') {
            $audience = 'all';
        }

        $on_duty = array();
        if (function_exists('vms_ops_presence_get_on_duty_user_ids')) {
            $on_duty = vms_ops_presence_get_on_duty_user_ids($venue_id);
        }
        $on_duty = vms_ops_alert_filter_receive_cap($on_duty);

        if (!empty($on_duty)) {
            $filtered = vms_ops_alert_filter_user_ids_for_audience($on_duty, $audience);
            if (!empty($filtered)) {
                return array(
                    'user_ids' => $filtered,
                    'strategy' => $audience === 'all' ? 'on_duty' : 'on_duty_filtered',
                );
            }
        }

        $fallback = vms_ops_alert_manager_fallback_user_ids();

        return array(
            'user_ids' => $fallback,
            'strategy' => 'manager_fallback',
        );
    }
}

if (!function_exists('vms_ops_alert_filter_user_ids_for_audience')) {
    function vms_ops_alert_filter_user_ids_for_audience(array $user_ids, string $audience): array
    {
        $audience = sanitize_key($audience);
        if ($audience === '' || $audience === 'all') {
            return $user_ids;
        }

        $filtered = array();
        foreach ($user_ids as $user_id) {
            $user_id = (int) $user_id;
            if ($user_id <= 0) {
                continue;
            }

            if ($audience === 'ticket') {
                if (!user_can($user_id, vms_ops_capability_scan_tickets())) {
                    continue;
                }
            } elseif ($audience === 'id') {
                if (!user_can($user_id, vms_ops_capability_scan_ids())) {
                    continue;
                }
            } elseif ($audience === 'managers') {
                if (!(user_can($user_id, 'manage_options') || user_can($user_id, vms_ops_capability_manage_members_admin()))) {
                    continue;
                }
            }

            $filtered[] = $user_id;
        }

        return array_values(array_unique($filtered));
    }
}
