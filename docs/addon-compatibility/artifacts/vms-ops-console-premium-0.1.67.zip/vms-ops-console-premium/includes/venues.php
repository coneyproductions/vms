<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_venue_post_type')) {
    function vms_ops_venue_post_type(): string
    {
        $raw = apply_filters('vms_venue_post_type', 'vms_venue');
        $post_type = sanitize_key((string) $raw);
        return $post_type !== '' ? $post_type : 'vms_venue';
    }
}

if (!function_exists('vms_ops_venue_allowed_statuses')) {
    function vms_ops_venue_allowed_statuses(): array
    {
        return array('publish', 'private', 'draft', 'pending', 'future');
    }
}

if (!function_exists('vms_ops_active_venue_statuses')) {
    function vms_ops_active_venue_statuses(): array
    {
        return array('publish');
    }
}

if (!function_exists('vms_ops_venue_label_for_post')) {
    function vms_ops_venue_label_for_post(int $venue_post_id): string
    {
        $title = sanitize_text_field((string) get_the_title($venue_post_id));
        if ($title === '') {
            $title = 'Venue ' . $venue_post_id;
        }
        return $title;
    }
}

if (!function_exists('vms_ops_venue_template_meta_key')) {
    function vms_ops_venue_template_meta_key(): string
    {
        $core_template_key = vms_ops_core_constant('VMS_VENUE_TEMPLATE_META_KEY', '');
        if (is_string($core_template_key) && $core_template_key !== '') {
            $key = $core_template_key;
            if ($key !== '') {
                return $key;
            }
        }

        return '_vms_is_template';
    }
}

if (!function_exists('vms_ops_venue_is_template')) {
    function vms_ops_venue_is_template(int $venue_post_id): bool
    {
        if ($venue_post_id <= 0) {
            return false;
        }

        return get_post_meta($venue_post_id, vms_ops_venue_template_meta_key(), true) === '1';
    }
}

if (!function_exists('vms_ops_venues_from_ids')) {
    /**
     * @param array<int|string> $ids
     * @param array<int,string>|null $allowed_statuses
     * @return array<int, array{id:int, name:string}>
     */
    function vms_ops_venues_from_ids(array $ids, ?array $allowed_statuses = null): array
    {
        $venues = array();
        $seen = array();
        $status_allow = null;
        if (is_array($allowed_statuses) && !empty($allowed_statuses)) {
            $status_allow = array_fill_keys(array_map('sanitize_key', $allowed_statuses), true);
        }

        foreach ($ids as $raw_id) {
            $venue_post_id = (int) $raw_id;
            if ($venue_post_id <= 0) {
                continue;
            }
            if (is_array($status_allow)) {
                $post_status = sanitize_key((string) get_post_status($venue_post_id));
                if ($post_status === '' || !isset($status_allow[$post_status])) {
                    continue;
                }
            }
            if (vms_ops_venue_is_template($venue_post_id)) {
                continue;
            }
            if (isset($seen[$venue_post_id])) {
                continue;
            }
            $seen[$venue_post_id] = true;
            $venues[] = array(
                'id' => $venue_post_id,
                'name' => vms_ops_venue_label_for_post($venue_post_id),
            );
        }

        return $venues;
    }
}

if (!function_exists('vms_ops_get_single_published_venue')) {
    /**
     * Return the only published, non-template venue when exactly one exists.
     *
     * @return array{id:int,name:string}|null
     */
    function vms_ops_get_single_published_venue(): ?array
    {
        $post_type = vms_ops_venue_post_type();
        $venue_rows = get_posts(array(
            'post_type' => $post_type,
            'post_status' => array('publish'),
            'posts_per_page' => 50,
            'orderby' => 'title',
            'order' => 'ASC',
            'fields' => 'ids',
            'no_found_rows' => true,
        ));

        $venues = vms_ops_venues_from_ids((array) $venue_rows);
        if (count($venues) === 1) {
            return $venues[0];
        }

        return null;
    }
}

if (!function_exists('vms_ops_get_preferred_venue')) {
    /**
     * Choose the venue Ops should auto-select when no explicit venue was picked.
     *
     * @return array{id:int,name:string}|null
     */
    function vms_ops_get_preferred_venue(): ?array
    {
        $active_statuses = vms_ops_active_venue_statuses();

        if (function_exists('vms_ops_get_settings')) {
            $settings = (array) vms_ops_get_settings();
            $default_venue_id = isset($settings['default_venue_id']) ? (int) $settings['default_venue_id'] : 0;
            $default_candidates = vms_ops_venues_from_ids(array($default_venue_id), $active_statuses);
            if (!empty($default_candidates)) {
                return $default_candidates[0];
            }
        }

        $single_published = vms_ops_get_single_published_venue();
        if (is_array($single_published)) {
            return $single_published;
        }

        if (vms_ops_has_core_function('vms_get_current_venue_id')) {
            $current_venue_id = (int) vms_ops_call_core_function('vms_get_current_venue_id');
            $current_candidates = vms_ops_venues_from_ids(array($current_venue_id), $active_statuses);
            if (!empty($current_candidates)) {
                return $current_candidates[0];
            }
        }

        return null;
    }
}

if (!function_exists('vms_ops_get_fallback_venue')) {
    /**
     * Best-effort single-venue fallback for operators who should not be blocked
     * by an empty venue payload when the site only has one usable venue.
     *
     * @return array{id:int,name:string}|null
     */
    function vms_ops_get_fallback_venue(): ?array
    {
        $preferred = vms_ops_get_preferred_venue();
        if (is_array($preferred)) {
            return $preferred;
        }

        $post_type = vms_ops_venue_post_type();
        global $wpdb;
        if ($wpdb instanceof wpdb) {
            $statuses = vms_ops_venue_allowed_statuses();
            $status_placeholders = implode(', ', array_fill(0, count($statuses), '%s'));
            $params = array_merge(array($post_type), array_values($statuses));
            $sql = "SELECT ID, post_title
                    FROM {$wpdb->posts}
                    WHERE post_type = %s
                      AND post_status IN ({$status_placeholders})
                    ORDER BY post_title ASC, ID ASC
                    LIMIT 1";
            $row = $wpdb->get_row($wpdb->prepare($sql, $params), ARRAY_A);
            if (is_array($row)) {
                $venue_post_id = (int) ($row['ID'] ?? 0);
                if ($venue_post_id > 0 && !vms_ops_venue_is_template($venue_post_id)) {
                    $label = sanitize_text_field((string) ($row['post_title'] ?? ''));
                    if ($label === '') {
                        $label = 'Venue ' . $venue_post_id;
                    }
                    return array(
                        'id' => $venue_post_id,
                        'name' => $label,
                    );
                }
            }
        }

        return null;
    }
}

if (!function_exists('vms_ops_get_active_venues_list')) {
    /**
     * Return published, non-template VMS venues as [{id, name}, …].
     */
    function vms_ops_get_active_venues_list(): array
    {
        $post_type = vms_ops_venue_post_type();
        $statuses = vms_ops_active_venue_statuses();

        $venue_rows = get_posts(array(
            'post_type' => $post_type,
            'post_status' => $statuses,
            'posts_per_page' => 300,
            'orderby' => 'title',
            'order' => 'ASC',
            'fields' => 'ids',
            'no_found_rows' => true,
        ));

        $venues = vms_ops_venues_from_ids((array) $venue_rows, $statuses);

        // Fallback: bypass capability-filtered post query for Ops users when there are
        // published venues but the post query still returns an empty payload.
        if (empty($venues)) {
            global $wpdb;
            if ($wpdb instanceof wpdb && !empty($statuses)) {
                $status_placeholders = implode(', ', array_fill(0, count($statuses), '%s'));
                $params = array_merge(array($post_type), array_values($statuses));
                $sql = "SELECT ID, post_title
                        FROM {$wpdb->posts}
                        WHERE post_type = %s
                          AND post_status IN ({$status_placeholders})
                        ORDER BY post_title ASC, ID ASC";
                $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
                if (is_array($rows)) {
                    $seen = array();
                    foreach ($rows as $row) {
                        $venue_post_id = (int) ($row['ID'] ?? 0);
                        if ($venue_post_id <= 0 || isset($seen[$venue_post_id]) || vms_ops_venue_is_template($venue_post_id)) {
                            continue;
                        }
                        $seen[$venue_post_id] = true;
                        $label = sanitize_text_field((string) ($row['post_title'] ?? ''));
                        if ($label === '') {
                            $label = 'Venue ' . $venue_post_id;
                        }
                        $venues[] = array(
                            'id' => $venue_post_id,
                            'name' => $label,
                        );
                    }
                }
            }
        }

        return $venues;
    }
}

if (!function_exists('vms_ops_get_venues_list')) {
    /**
     * Return active VMS venues as [{id, name}, …].
     */
    function vms_ops_get_venues_list(): array
    {
        $post_type = vms_ops_venue_post_type();
        $statuses = vms_ops_venue_allowed_statuses();

        $venue_rows = get_posts(array(
            'post_type' => $post_type,
            'post_status' => $statuses,
            'posts_per_page' => 300,
            'orderby' => 'title',
            'order' => 'ASC',
            'fields' => 'ids',
            'no_found_rows' => true,
        ));

        $venues = vms_ops_venues_from_ids((array) $venue_rows);

        // Fallback: bypass capability-filtered post query for Ops users that cannot read private venue posts.
        if (empty($venues)) {
            global $wpdb;
            if ($wpdb instanceof wpdb && !empty($statuses)) {
                $status_placeholders = implode(', ', array_fill(0, count($statuses), '%s'));
                $params = array_merge(array($post_type), array_values($statuses));
                $sql = "SELECT ID, post_title
                        FROM {$wpdb->posts}
                        WHERE post_type = %s
                          AND post_status IN ({$status_placeholders})
                        ORDER BY post_title ASC, ID ASC";
                $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
                if (is_array($rows)) {
                    $seen = array();
                    foreach ($rows as $row) {
                        $venue_post_id = (int) ($row['ID'] ?? 0);
                        if ($venue_post_id <= 0 || isset($seen[$venue_post_id])) {
                            continue;
                        }
                        $seen[$venue_post_id] = true;
                        $label = sanitize_text_field((string) ($row['post_title'] ?? ''));
                        if ($label === '') {
                            $label = 'Venue ' . $venue_post_id;
                        }
                        $venues[] = array(
                            'id' => $venue_post_id,
                            'name' => $label,
                        );
                    }
                }
            }
        }

        // Last fallback: keep Ops reachable when only a default venue is configured.
        if (empty($venues)) {
            $fallback_venue = vms_ops_get_fallback_venue();
            if (is_array($fallback_venue) && !empty($fallback_venue['id'])) {
                $venues[] = $fallback_venue;
            }
        }

        if (empty($venues) && defined('WP_DEBUG') && WP_DEBUG) {
            error_log(
                sprintf(
                    'VMS Ops venues list is empty (user_id=%d, post_type=%s, statuses=%s).',
                    (int) get_current_user_id(),
                    $post_type,
                    implode(',', $statuses)
                )
            );
        }

        return $venues;
    }
}
