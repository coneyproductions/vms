<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_presence_auto_expire')) {
    function vms_ops_presence_auto_expire()
    {
        global $wpdb;

        $updated = $wpdb->query(
            $wpdb->prepare(
                'UPDATE ' . vms_ops_table_presence() . '
                SET status = %s, shift_ended_at = %s
                WHERE status = %s AND last_seen_at < %s',
                'off_duty',
                vms_ops_now_mysql(),
                'on_duty',
                vms_ops_presence_cutoff_mysql()
            )
        );

        if ($updated === false) {
            return vms_ops_db_write_error('presence_auto_expire_failed', __('Could not auto-expire stale presence records.', 'vms-ops-console-premium'));
        }

        return true;
    }
}
add_action('vms_ops_presence_expire_event', 'vms_ops_presence_auto_expire');

if (!function_exists('vms_ops_presence_start_shift')) {
    function vms_ops_presence_start_shift(int $user_id, int $venue_id, string $device_id, string $console_type = 'ops')
    {
        if ($user_id <= 0 || $venue_id <= 0 || trim($device_id) === '') {
            return new WP_Error('invalid_presence_args', __('User, venue, and device are required to start shift.', 'vms-ops-console-premium'));
        }

        $expired = vms_ops_presence_auto_expire();
        if (is_wp_error($expired)) {
            return $expired;
        }

        global $wpdb;

        $closed = $wpdb->query(
            $wpdb->prepare(
                'UPDATE ' . vms_ops_table_presence() . '
                SET status = %s, shift_ended_at = %s
                WHERE user_id = %d AND venue_id = %d AND status = %s',
                'off_duty',
                vms_ops_now_mysql(),
                $user_id,
                $venue_id,
                'on_duty'
            )
        );

        if ($closed === false) {
            return vms_ops_db_write_error('presence_close_previous_failed', __('Could not close existing shift.', 'vms-ops-console-premium'));
        }

        $inserted = $wpdb->insert(
            vms_ops_table_presence(),
            array(
                'user_id' => $user_id,
                'venue_id' => $venue_id,
                'device_id' => sanitize_text_field($device_id),
                'status' => 'on_duty',
                'shift_started_at' => vms_ops_now_mysql(),
                'last_seen_at' => vms_ops_now_mysql(),
                'shift_ended_at' => null,
                'console_type' => sanitize_key($console_type),
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        if ($inserted === false) {
            return vms_ops_db_write_error('presence_start_failed', __('Could not start shift.', 'vms-ops-console-premium'));
        }

        return array(
            'id' => (int) $wpdb->insert_id,
            'user_id' => $user_id,
            'venue_id' => $venue_id,
            'status' => 'on_duty',
            'last_seen_at' => vms_ops_now_mysql(),
        );
    }
}

if (!function_exists('vms_ops_presence_heartbeat')) {
    function vms_ops_presence_heartbeat(int $user_id, int $venue_id, string $device_id)
    {
        if ($user_id <= 0 || $venue_id <= 0 || trim($device_id) === '') {
            return new WP_Error('invalid_presence_heartbeat_args', __('User, venue, and device are required for heartbeat.', 'vms-ops-console-premium'));
        }

        $expired = vms_ops_presence_auto_expire();
        if (is_wp_error($expired)) {
            return $expired;
        }

        global $wpdb;
        $current = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT id FROM ' . vms_ops_table_presence() . ' WHERE user_id = %d AND venue_id = %d AND device_id = %s AND status = %s ORDER BY id DESC LIMIT 1',
                $user_id,
                $venue_id,
                sanitize_text_field($device_id),
                'on_duty'
            ),
            ARRAY_A
        );

        if (!is_array($current)) {
            return vms_ops_presence_start_shift($user_id, $venue_id, $device_id);
        }

        $updated = $wpdb->update(
            vms_ops_table_presence(),
            array(
                'last_seen_at' => vms_ops_now_mysql(),
            ),
            array(
                'id' => (int) $current['id'],
            ),
            array('%s'),
            array('%d')
        );

        if ($updated === false) {
            return vms_ops_db_write_error('presence_heartbeat_failed', __('Could not update heartbeat.', 'vms-ops-console-premium'));
        }

        return array(
            'id' => (int) $current['id'],
            'user_id' => $user_id,
            'venue_id' => $venue_id,
            'status' => 'on_duty',
            'last_seen_at' => vms_ops_now_mysql(),
        );
    }
}

if (!function_exists('vms_ops_presence_end_shift')) {
    function vms_ops_presence_end_shift(int $user_id, int $venue_id, string $device_id)
    {
        if ($user_id <= 0 || $venue_id <= 0 || trim($device_id) === '') {
            return new WP_Error('invalid_presence_end_args', __('User, venue, and device are required to end shift.', 'vms-ops-console-premium'));
        }

        global $wpdb;

        $updated = $wpdb->query(
            $wpdb->prepare(
                'UPDATE ' . vms_ops_table_presence() . '
                SET status = %s, shift_ended_at = %s
                WHERE user_id = %d AND venue_id = %d AND device_id = %s AND status = %s',
                'off_duty',
                vms_ops_now_mysql(),
                $user_id,
                $venue_id,
                sanitize_text_field($device_id),
                'on_duty'
            )
        );

        if ($updated === false) {
            return vms_ops_db_write_error('presence_end_failed', __('Could not end shift.', 'vms-ops-console-premium'));
        }

        return array(
            'user_id' => $user_id,
            'venue_id' => $venue_id,
            'status' => 'off_duty',
            'shift_ended_at' => vms_ops_now_mysql(),
        );
    }
}

if (!function_exists('vms_ops_presence_get_on_duty_rows')) {
    function vms_ops_presence_get_on_duty_rows(int $venue_id = 0): array
    {
        $expired = vms_ops_presence_auto_expire();
        if (is_wp_error($expired)) {
            return array();
        }

        global $wpdb;
        if ($venue_id > 0) {
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    'SELECT * FROM ' . vms_ops_table_presence() . ' WHERE venue_id = %d AND status = %s ORDER BY last_seen_at DESC',
                    $venue_id,
                    'on_duty'
                ),
                ARRAY_A
            );
        } else {
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    'SELECT * FROM ' . vms_ops_table_presence() . ' WHERE status = %s ORDER BY last_seen_at DESC',
                    'on_duty'
                ),
                ARRAY_A
            );
        }

        return is_array($rows) ? $rows : array();
    }
}

if (!function_exists('vms_ops_presence_get_on_duty_user_ids')) {
    function vms_ops_presence_get_on_duty_user_ids(int $venue_id = 0): array
    {
        $rows = vms_ops_presence_get_on_duty_rows($venue_id);
        $ids = array();
        foreach ($rows as $row) {
            $ids[] = (int) ($row['user_id'] ?? 0);
        }
        $ids = array_filter($ids, static function (int $value): bool {
            return $value > 0;
        });

        return array_values(array_unique($ids));
    }
}
