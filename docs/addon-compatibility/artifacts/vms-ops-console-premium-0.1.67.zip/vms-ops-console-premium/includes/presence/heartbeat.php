<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_presence_timeout_seconds')) {
    function vms_ops_presence_timeout_seconds(): int
    {
        $defaults = function_exists('vms_ops_default_settings') ? vms_ops_default_settings() : array('presence_timeout_seconds' => 180);
        $fallback = (int) ($defaults['presence_timeout_seconds'] ?? 180);

        if (function_exists('vms_ops_get_settings')) {
            $settings = vms_ops_get_settings();
            $value = isset($settings['presence_timeout_seconds']) ? (int) $settings['presence_timeout_seconds'] : $fallback;
        } else {
            $value = $fallback;
        }

        return max(60, min(3600, $value));
    }
}

if (!function_exists('vms_ops_presence_cutoff_mysql')) {
    function vms_ops_presence_cutoff_mysql(): string
    {
        $timeout = vms_ops_presence_timeout_seconds();
        $timestamp = time() - $timeout;
        return (string) wp_date('Y-m-d H:i:s', $timestamp, wp_timezone());
    }
}

if (!function_exists('vms_ops_presence_schedule_interval')) {
    function vms_ops_presence_schedule_interval(array $schedules): array
    {
        if (!isset($schedules['vms_ops_every_minute'])) {
            $schedules['vms_ops_every_minute'] = array(
                'interval' => 60,
                'display' => __('Every Minute (VMS Ops)', 'vms-ops-console-premium'),
            );
        }

        return $schedules;
    }
}
add_filter('cron_schedules', 'vms_ops_presence_schedule_interval');

if (!function_exists('vms_ops_presence_schedule_event')) {
    function vms_ops_presence_schedule_event(): void
    {
        if (!wp_next_scheduled('vms_ops_presence_expire_event')) {
            wp_schedule_event(time() + 60, 'vms_ops_every_minute', 'vms_ops_presence_expire_event');
        }
    }
}

if (!function_exists('vms_ops_presence_clear_scheduled_event')) {
    function vms_ops_presence_clear_scheduled_event(): void
    {
        $timestamp = wp_next_scheduled('vms_ops_presence_expire_event');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'vms_ops_presence_expire_event');
        }
    }
}
