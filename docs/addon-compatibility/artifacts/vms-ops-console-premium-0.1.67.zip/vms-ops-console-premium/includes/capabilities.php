<?php

defined('ABSPATH') || exit;

if (!function_exists('vms_ops_capability_use_pwa')) {
    function vms_ops_capability_use_pwa(): string
    {
        return 'vms_ops_use_pwa';
    }
}

if (!function_exists('vms_ops_capability_scan_tickets')) {
    function vms_ops_capability_scan_tickets(): string
    {
        return 'vms_ops_scan_tickets';
    }
}

if (!function_exists('vms_ops_capability_scan_ids')) {
    function vms_ops_capability_scan_ids(): string
    {
        return 'vms_ops_scan_ids';
    }
}

if (!function_exists('vms_ops_capability_member_lookup')) {
    function vms_ops_capability_member_lookup(): string
    {
        return 'vms_ops_member_lookup';
    }
}

if (!function_exists('vms_ops_capability_manage_members_lite')) {
    function vms_ops_capability_manage_members_lite(): string
    {
        return 'vms_ops_manage_members_lite';
    }
}

if (!function_exists('vms_ops_capability_manage_members_admin')) {
    function vms_ops_capability_manage_members_admin(): string
    {
        return 'vms_ops_manage_members_admin';
    }
}

if (!function_exists('vms_ops_capability_send_alerts')) {
    function vms_ops_capability_send_alerts(): string
    {
        return 'vms_ops_send_alerts';
    }
}

if (!function_exists('vms_ops_capability_receive_alerts')) {
    function vms_ops_capability_receive_alerts(): string
    {
        return 'vms_ops_receive_alerts';
    }
}

if (!function_exists('vms_ops_capability_presence_checkin')) {
    function vms_ops_capability_presence_checkin(): string
    {
        return 'vms_ops_presence_checkin';
    }
}

if (!function_exists('vms_ops_all_capabilities')) {
    function vms_ops_all_capabilities(): array
    {
        return array(
            vms_ops_capability_use_pwa(),
            vms_ops_capability_scan_tickets(),
            vms_ops_capability_scan_ids(),
            vms_ops_capability_member_lookup(),
            vms_ops_capability_manage_members_lite(),
            vms_ops_capability_manage_members_admin(),
            vms_ops_capability_send_alerts(),
            vms_ops_capability_receive_alerts(),
            vms_ops_capability_presence_checkin(),
        );
    }
}

if (!function_exists('vms_ops_user_cap_override_meta_key')) {
    function vms_ops_user_cap_override_meta_key(): string
    {
        return 'vms_ops_cap_overrides';
    }
}

if (!function_exists('vms_ops_sanitize_cap_override_map')) {
    function vms_ops_sanitize_cap_override_map(array $raw): array
    {
        $allowed_caps = vms_ops_all_capabilities();
        $clean = array();

        foreach ($raw as $cap => $enabled) {
            $cap = sanitize_text_field((string) $cap);
            if ($cap === '' || !in_array($cap, $allowed_caps, true)) {
                continue;
            }

            $clean[$cap] = !empty($enabled) ? 1 : 0;
        }

        return $clean;
    }
}

if (!function_exists('vms_ops_get_user_cap_override_map')) {
    function vms_ops_get_user_cap_override_map(?int $user_id = null): array
    {
        $user_id = $user_id !== null ? absint($user_id) : absint(get_current_user_id());
        if ($user_id <= 0) {
            return array();
        }

        $stored = get_user_meta($user_id, vms_ops_user_cap_override_meta_key(), true);
        if (!is_array($stored)) {
            return array();
        }

        return vms_ops_sanitize_cap_override_map($stored);
    }
}

if (!function_exists('vms_ops_set_user_cap_override_map')) {
    function vms_ops_set_user_cap_override_map(int $user_id, array $raw): void
    {
        $user_id = absint($user_id);
        if ($user_id <= 0) {
            return;
        }

        $clean = vms_ops_sanitize_cap_override_map($raw);
        if (empty($clean)) {
            delete_user_meta($user_id, vms_ops_user_cap_override_meta_key());
            return;
        }

        update_user_meta($user_id, vms_ops_user_cap_override_meta_key(), $clean);
    }
}

if (!function_exists('vms_ops_set_user_cap_override_selection')) {
    function vms_ops_set_user_cap_override_selection(int $user_id, array $selected_caps, ?array $allowed_caps = null): void
    {
        $user_id = absint($user_id);
        if ($user_id <= 0) {
            return;
        }

        $allowed_caps = is_array($allowed_caps) && !empty($allowed_caps)
            ? array_values(array_unique(array_map('sanitize_text_field', $allowed_caps)))
            : vms_ops_all_capabilities();

        $selected = array();
        foreach ($selected_caps as $cap) {
            $cap = sanitize_text_field((string) $cap);
            if ($cap === '' || !in_array($cap, $allowed_caps, true)) {
                continue;
            }
            $selected[] = $cap;
        }
        $selected = array_values(array_unique($selected));

        $override_map = array();
        foreach ($allowed_caps as $cap) {
            $override_map[$cap] = in_array($cap, $selected, true) ? 1 : 0;
        }

        vms_ops_set_user_cap_override_map($user_id, $override_map);
    }
}

if (!function_exists('vms_ops_clear_user_cap_override_map')) {
    function vms_ops_clear_user_cap_override_map(int $user_id): void
    {
        $user_id = absint($user_id);
        if ($user_id <= 0) {
            return;
        }

        delete_user_meta($user_id, vms_ops_user_cap_override_meta_key());
    }
}

if (!function_exists('vms_ops_register_capabilities')) {
    function vms_ops_register_capabilities(): void
    {
        // Only auto-grant to administrators.
        // All other access is managed via Ops Console → Teams (per-user capability assignment).
        $all_caps = vms_ops_all_capabilities();

        $administrator = get_role('administrator');
        if ($administrator instanceof WP_Role) {
            foreach ($all_caps as $cap) {
                if (!$administrator->has_cap($cap)) {
                    $administrator->add_cap($cap);
                }
            }
        }
    }
}

if (!function_exists('vms_ops_user_has_any_capability')) {
    function vms_ops_user_has_any_capability(array $caps, ?int $user_id = null): bool
    {
        $user = $user_id ? get_user_by('id', $user_id) : wp_get_current_user();
        if (!($user instanceof WP_User)) {
            return false;
        }

        foreach ($caps as $cap) {
            if (user_can($user, $cap)) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('vms_ops_user_has_manage_options')) {
    function vms_ops_user_has_manage_options(?int $user_id = null): bool
    {
        $user = $user_id ? get_user_by('id', $user_id) : wp_get_current_user();
        if (!($user instanceof WP_User)) {
            return false;
        }

        return user_can($user, 'manage_options');
    }
}

if (!function_exists('vms_ops_user_has_any_capability_or_admin')) {
    function vms_ops_user_has_any_capability_or_admin(array $caps, ?int $user_id = null): bool
    {
        if (vms_ops_user_has_manage_options($user_id)) {
            return true;
        }

        return vms_ops_user_has_any_capability($caps, $user_id);
    }
}

if (!function_exists('vms_ops_resolve_user_role_profile_caps')) {
    function vms_ops_resolve_user_role_profile_caps(?int $user_id = null): array
    {
        $user_id = $user_id !== null ? absint($user_id) : absint(get_current_user_id());
        if ($user_id <= 0) {
            return array();
        }

        static $caps_cache = array();
        if (array_key_exists($user_id, $caps_cache)) {
            return is_array($caps_cache[$user_id]) ? $caps_cache[$user_id] : array();
        }

        if (!function_exists('vms_ops_admin_collect_linked_staff_index') || !function_exists('vms_ops_admin_resolve_caps_for_linked_staff_entry')) {
            $caps_cache[$user_id] = array();
            return array();
        }

        static $linked_staff_index = null;
        if (!is_array($linked_staff_index)) {
            $linked_staff_index = vms_ops_admin_collect_linked_staff_index();
        }

        $linked_staff_entry = isset($linked_staff_index[$user_id]) && is_array($linked_staff_index[$user_id])
            ? $linked_staff_index[$user_id]
            : array();
        if (empty($linked_staff_entry)) {
            $caps_cache[$user_id] = array();
            return array();
        }

        $resolved = vms_ops_admin_resolve_caps_for_linked_staff_entry((array) $linked_staff_entry);
        $caps = array_values(array_unique(array_filter(array_map(
            'sanitize_text_field',
            (array) ($resolved['desired_caps'] ?? array())
        ))));

        $caps_cache[$user_id] = $caps;
        return $caps;
    }
}

if (!function_exists('vms_ops_filter_user_has_cap_overrides')) {
    function vms_ops_filter_user_has_cap_overrides(array $allcaps, array $caps, array $args, $user): array
    {
        if (!($user instanceof WP_User) || $user->ID <= 0) {
            return $allcaps;
        }

        // Keep canonical linked staff roles operational even when the saved
        // Teams profile has gone blank or the user has not been resynced yet.
        foreach (vms_ops_resolve_user_role_profile_caps((int) $user->ID) as $cap) {
            if ($cap !== '') {
                $allcaps[$cap] = true;
            }
        }

        $overrides = vms_ops_get_user_cap_override_map((int) $user->ID);
        if (empty($overrides)) {
            return $allcaps;
        }

        // Per-user Ops overrides must win over inherited role capabilities.
        foreach ($overrides as $cap => $enabled) {
            $allcaps[$cap] = !empty($enabled);
        }

        return $allcaps;
    }
}
add_filter('user_has_cap', 'vms_ops_filter_user_has_cap_overrides', 20, 4);
