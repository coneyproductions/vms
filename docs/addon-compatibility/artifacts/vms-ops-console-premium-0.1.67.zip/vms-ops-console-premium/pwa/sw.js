const CACHE_NAME = 'vms-ops-shell-__VERSION__';
const SHELL_URL = '__SHELL_URL__';
const MEMBER_LOOKUP_ACCESS_JS = '__MEMBER_LOOKUP_ACCESS_JS__';
const MEMBER_LOOKUP_DOB_JS = '__MEMBER_LOOKUP_DOB_JS__';
const MEMBER_PHOTO_CAPTURE_JS = '__MEMBER_PHOTO_CAPTURE_JS__';
const APP_JS = '__APP_JS__';
const APP_CSS = '__APP_CSS__';
const ZXING_LIBRARY_JS = '__ZXING_LIBRARY_JS__';
const ZXING_BROWSER_JS = '__ZXING_BROWSER_JS__';
const STATIC_ASSETS = [
  MEMBER_LOOKUP_ACCESS_JS,
  MEMBER_LOOKUP_DOB_JS,
  MEMBER_PHOTO_CAPTURE_JS,
  APP_JS,
  APP_CSS,
  ZXING_LIBRARY_JS,
  ZXING_BROWSER_JS
];
const STATIC_PATHS = STATIC_ASSETS.map((asset) => new URL(asset).pathname);
const SHELL_PATH = (() => {
  const pathname = new URL(SHELL_URL).pathname.replace(/\/+$/, '');
  return pathname || '/';
})();

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.map((key) => {
      if (key !== CACHE_NAME) {
        return caches.delete(key);
      }
      return Promise.resolve();
    })))
  );
  self.clients.claim();
});

function isShellRequest(request, url) {
  if (url.origin !== self.location.origin) {
    return false;
  }

  const normalizedPath = url.pathname.replace(/\/+$/, '') || '/';
  return request.mode === 'navigate' || normalizedPath === SHELL_PATH;
}

function isStaticAssetRequest(url) {
  return url.origin === self.location.origin && STATIC_PATHS.includes(url.pathname);
}

async function networkFirstShell(request) {
  const cache = await caches.open(CACHE_NAME);

  try {
    const response = await fetch(request);
    if (response && response.ok && response.type === 'basic' && !response.redirected) {
      cache.put(SHELL_URL, response.clone());
    }
    return response;
  } catch (_error) {
    const cached = await cache.match(SHELL_URL);
    if (cached) {
      return cached;
    }
    throw _error;
  }
}

async function cacheFirstStatic(request) {
  const cached = await caches.match(request);
  if (cached) {
    return cached;
  }

  const response = await fetch(request);
  if (response && response.ok && response.type === 'basic') {
    const cache = await caches.open(CACHE_NAME);
    cache.put(request, response.clone());
  }
  return response;
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);

  if (request.method !== 'GET') {
    return;
  }

  if (url.pathname.startsWith('/wp-json/')) {
    event.respondWith(
      fetch(request).catch(() => new Response(JSON.stringify({
        ok: false,
        offline: true
      }), {
        status: 503,
        headers: {
          'Content-Type': 'application/json'
        }
      }))
    );
    return;
  }

  if (isShellRequest(request, url)) {
    event.respondWith(networkFirstShell(request));
    return;
  }

  if (isStaticAssetRequest(url)) {
    event.respondWith(cacheFirstStatic(request));
    return;
  }

  event.respondWith(
    fetch(request).catch(() => caches.match(request))
  );
});
