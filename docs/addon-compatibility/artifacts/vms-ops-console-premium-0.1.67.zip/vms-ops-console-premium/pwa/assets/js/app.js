(() => {
  const config = window.vmsOpsConfig || {};
  const memberLookupAccessHelper = window.VMS_OPS_MEMBER_LOOKUP_ACCESS
    && typeof window.VMS_OPS_MEMBER_LOOKUP_ACCESS.getMemberLookupAccessState === 'function'
    ? window.VMS_OPS_MEMBER_LOOKUP_ACCESS
    : null;
  const memberLookupDobHelper = window.VMS_OPS_MEMBER_LOOKUP_DOB
    && typeof window.VMS_OPS_MEMBER_LOOKUP_DOB.getDobInputState === 'function'
    ? window.VMS_OPS_MEMBER_LOOKUP_DOB
    : null;
  const memberPhotoCaptureHelper = window.VMS_OPS_MEMBER_PHOTO_CAPTURE
    && typeof window.VMS_OPS_MEMBER_PHOTO_CAPTURE.normalizeCaptureMode === 'function'
    ? window.VMS_OPS_MEMBER_PHOTO_CAPTURE
    : null;
  const els = {
    app: document.getElementById('vms-ops-app'),
    siteTime: document.getElementById('vms-ops-site-time'),
    siteTimeValue: document.getElementById('vms-ops-site-time-value'),
    siteTimeMeta: document.getElementById('vms-ops-site-time-meta'),
    venueSelect: document.getElementById('vms-ops-venue-select'),
    venueLabel: document.querySelector('label[for="vms-ops-venue-select"]'),
    venueOverlay: document.getElementById('vms-ops-venue-overlay'),
    venueOverlayTitle: document.getElementById('vms-ops-venue-overlay-title'),
    venueOverlayLead: document.getElementById('vms-ops-venue-overlay-lead'),
    venueOverlayStatus: document.getElementById('vms-ops-venue-overlay-status'),
    venueOverlaySelect: document.getElementById('vms-ops-venue-select-overlay'),
    venueOverlayLabel: document.querySelector('label[for="vms-ops-venue-select-overlay"]'),
    venueOverlayContinue: document.getElementById('vms-ops-venue-continue'),
    venueRetry: document.getElementById('vms-ops-venue-retry'),
    presenceHeading: document.getElementById('vms-ops-presence-heading'),
    presencePanel: document.getElementById('vms-ops-presence-panel'),

    startShift: document.getElementById('vms-ops-start-shift'),
    endShift: document.getElementById('vms-ops-end-shift'),
    presenceStatus: document.getElementById('vms-ops-presence-status'),
    presenceLoading: document.getElementById('vms-ops-presence-loading'),

    ticketPanel: document.getElementById('vms-ops-ticket-panel'),
    ticketHeading: document.getElementById('vms-ops-ticket-heading'),
    ticketBody: document.getElementById('vms-ops-ticket-body'),
    idPanel: document.getElementById('vms-ops-id-panel'),
    idHeading: document.getElementById('vms-ops-id-heading'),
    idBody: document.getElementById('vms-ops-id-body'),
    memberLookupPanel: document.getElementById('vms-ops-member-lookup-panel'),
    memberLookupHeading: document.getElementById('vms-ops-member-lookup-heading'),
    memberLookupBody: document.getElementById('vms-ops-member-lookup-body'),
    memberLookupPolicy: document.getElementById('vms-ops-member-lookup-policy'),
    memberLookupTour: document.getElementById('vms-ops-member-lookup-tour'),
    memberLookupQuery: document.getElementById('vms-ops-member-lookup-query'),
    memberLookupSearch: document.getElementById('vms-ops-member-lookup-search'),
    memberLookupClear: document.getElementById('vms-ops-member-lookup-clear'),
    memberLookupFeedback: document.getElementById('vms-ops-member-lookup-feedback'),
    memberLookupMeta: document.getElementById('vms-ops-member-lookup-meta'),
    memberLookupResults: document.getElementById('vms-ops-member-lookup-results'),
    memberLookupDetail: document.getElementById('vms-ops-member-lookup-detail'),
    memberLookupDetailCard: document.getElementById('vms-ops-member-lookup-detail-card'),
    alertPanel: document.getElementById('vms-ops-alert-panel'),

    eventSelect: document.getElementById('vms-ops-ticket-event'),
    activeEventCard: document.getElementById('vms-ops-active-event-card'),
    activeEventName: document.getElementById('vms-ops-active-event-name'),
    activeEventMeta: document.getElementById('vms-ops-active-event-meta'),
    activeEventStatus: document.getElementById('vms-ops-active-event-status'),
    confirmEvent: document.getElementById('vms-ops-confirm-event'),
    changeEvent: document.getElementById('vms-ops-change-event'),
    refreshEvents: document.getElementById('vms-ops-refresh-events'),
    loadAttendees: document.getElementById('vms-ops-load-attendees'),
    ticketScan: document.getElementById('vms-ops-ticket-scan'),
    ticketScanCamera: document.getElementById('vms-ops-ticket-scan-camera'),
    ticketSubmit: document.getElementById('vms-ops-ticket-submit'),
    ticketSubmitAll: document.getElementById('vms-ops-ticket-submit-all'),
    ticketNotice: document.getElementById('vms-ops-ticket-notice'),
    ticketScanHint: document.getElementById('vms-ops-ticket-scan-hint'),
    ticketFeedback: document.getElementById('vms-ops-ticket-feedback'),
    ticketCacheMeta: document.getElementById('vms-ops-ticket-cache-meta'),
    ticketCacheDebug: document.getElementById('vms-ops-ticket-cache-debug'),
    attendeeSearch: document.getElementById('vms-ops-attendee-search'),
    attendeeClear: document.getElementById('vms-ops-attendee-clear'),
    attendeeResults: document.getElementById('vms-ops-attendee-results'),
    attendeeMeta: document.getElementById('vms-ops-attendee-meta'),


    idPayload: document.getElementById('vms-ops-id-payload'),
    idAdvanced: document.getElementById('vms-ops-id-advanced'),
    idScanCamera: document.getElementById('vms-ops-id-scan-camera'),
    idProcess: document.getElementById('vms-ops-id-process'),
    idRetryLog: document.getElementById('vms-ops-id-retry-log'),
    idDebugTiming: document.getElementById('vms-ops-id-debug-timing'),
    idFeedback: document.getElementById('vms-ops-id-feedback'),
    idResult: document.getElementById('vms-ops-id-result'),
    idRecheckContext: document.getElementById('vms-ops-id-recheck-context'),
    idAgeCutoffNote: document.getElementById('vms-ops-id-age-cutoff-note'),
    idAgeWarning: document.getElementById('vms-ops-id-age-warning'),
    idNotFound: document.getElementById('vms-ops-id-not-found'),
    idNotFoundSummary: document.getElementById('vms-ops-id-not-found-summary'),
    idNotFoundAction: document.getElementById('vms-ops-id-not-found-action'),
    idAddMember: document.getElementById('vms-ops-id-add-member'),
    idNotFoundCancel: document.getElementById('vms-ops-id-not-found-cancel'),
    manualHeading: document.getElementById('vms-ops-manual-member-heading'),
    manualForm: document.getElementById('vms-ops-manual-member-form'),
    memberNumberInput: document.getElementById('vms-ops-member-number'),
    generateMemberNumber: document.getElementById('vms-ops-generate-member-number'),

    alertPreset: document.getElementById('vms-ops-alert-preset'),
    alertMessage: document.getElementById('vms-ops-alert-message'),
    alertUrgency: document.getElementById('vms-ops-alert-urgency'),
    alertSend: document.getElementById('vms-ops-alert-send'),
    alertRoutingHint: document.getElementById('vms-ops-alert-routing-hint'),
    alertFeedback: document.getElementById('vms-ops-alert-feedback'),
    alertFeed: document.getElementById('vms-ops-alert-feed'),

    callStaff: document.getElementById('vms-ops-call-staff'),
    callModal: document.getElementById('vms-ops-call-modal'),
    callModalClose: document.getElementById('vms-ops-call-modal-close'),
    callModalCancel: document.getElementById('vms-ops-call-modal-cancel'),
    callModalSend: document.getElementById('vms-ops-call-modal-send'),
    callModalMessageWrap: document.getElementById('vms-ops-call-modal-message-wrap'),
    openPresence: document.getElementById('vms-ops-open-presence'),
    presenceModal: document.getElementById('vms-ops-presence-modal'),
    presenceModalClose: document.getElementById('vms-ops-presence-modal-close'),
    presenceModalCancel: document.getElementById('vms-ops-presence-modal-cancel'),
    callModalPreset: document.getElementById('vms-ops-call-modal-preset'),
    callModalMessage: document.getElementById('vms-ops-call-modal-message'),
    callModalUrgency: document.getElementById('vms-ops-call-modal-urgency'),
    callModalRouting: document.getElementById('vms-ops-call-modal-routing'),
    callModalFeedback: document.getElementById('vms-ops-call-modal-feedback'),
    scanModal: document.getElementById('vms-ops-scan-modal'),
    scanClose: document.getElementById('vms-ops-scan-close'),
    scanCancel: document.getElementById('vms-ops-scan-cancel'),
    scanFlip: document.getElementById('vms-ops-scan-flip'),
    scanTorch: document.getElementById('vms-ops-scan-torch'),
    scanZoomIn: document.getElementById('vms-ops-scan-zoom-in'),
    scanZoomOut: document.getElementById('vms-ops-scan-zoom-out'),
    scanZoomReset: document.getElementById('vms-ops-scan-zoom-reset'),
    scanViewport: document.getElementById('vms-ops-scan-viewport'),
    scanMask: document.getElementById('vms-ops-scan-mask'),
    scanTarget: document.getElementById('vms-ops-scan-target'),
    scanFocusRing: document.getElementById('vms-ops-scan-focus-ring'),
    scanVideo: document.getElementById('vms-ops-scan-video'),
    scanStatus: document.getElementById('vms-ops-scan-status'),
    scanTitle: document.getElementById('vms-ops-scan-title'),
    scanHint: document.getElementById('vms-ops-scan-hint'),
    scanResult: document.getElementById('vms-ops-scan-result'),
    scanResultHeadline: document.getElementById('vms-ops-scan-result-headline'),
    scanResultDetail: document.getElementById('vms-ops-scan-result-detail'),
    scanFeedback: document.getElementById('vms-ops-scan-feedback'),
    globalFeedback: document.getElementById('vms-ops-global-feedback'),

    bannedOverlay: document.getElementById('vms-ops-banned-overlay'),
    bannedText: document.getElementById('vms-ops-banned-text'),
    bannedClear: document.getElementById('vms-ops-banned-clear')
  };

  const state = {
    mode: 'mobile',
    onDuty: false,
    selectedEventId: 0,
    selectedEventSource: '',
    ticketEventConfirmedId: 0,
    ticketEventConfirmedAt: 0,
    ticketEventConfirmationSource: '',
    attendeeSearchTerm: '',
    attendeesCache: {},
    bannedMemberId: 0,
    bannedHoldInterval: null,
    holdStartAt: 0,
    lastAlertId: 0,
    queueBusy: false,
    queue: [],
    localCheckedKeys: {},
    ticketCollapsed: false,
    idCollapsed: false,
    memberLookupCollapsed: true,
    presenceCollapsed: false,
    presenceBusy: false,
    venuesLoaded: false,
    bootstrapBusy: true,
    bootstrapFailed: false,
    bootstrapErrorMessage: '',
    venues: [],
    siteTimeOffsetMs: 0,
    siteTimeAvailable: false,
    siteTimeSyncedAt: 0,
    siteTimeLastAttemptAt: 0,
    siteTimeSyncBusy: false,
    siteTimeTimezone: String(config.serverTimezone || '').trim(),
    siteTimeTimezoneLabel: String(config.serverTimezoneLabel || '').trim() || 'Site Time',
    siteTimeTimezoneOffsetMinutes: Number.isFinite(Number(config.serverTimezoneOffsetMinutes))
      ? Number(config.serverTimezoneOffsetMinutes)
      : 0,
    siteDateFormat: String(config.serverDateFormat || '').trim(),
    siteTimeFormat: String(config.serverTimeFormat || '').trim(),
    siteClockTimer: null,
    siteTimeSyncTimer: null,
    globalFeedbackTimer: null,
    eventsLoading: false,
    ticketEvents: [],
    previousEventRuntimeStates: {},
    attendeesLoading: false,
    guestListCacheRef: '',
    guestListCacheAt: 0,
    memberLookupBusy: false,
    memberLookupQuery: '',
    memberLookupResults: [],
    memberLookupCurrent: null,
    memberLookupApiForbidden: false,
    memberLookupApiForbiddenDetail: '',
    memberLookupDisabledReason: '',
    memberLookupDisabledDetail: '',
    memberLookupDiagnosticKey: '',
    idRecheckContext: null,
    bannedClearBusy: false,
    idScanBusy: false,
    pendingManualPrefill: null,
    manualMemberNumberFromScan: false,
    alertPresets: [],
    scannerMode: '',
    scannerFacingMode: 'environment',
    scannerActive: false,
    scannerBusy: false,
    scannerStream: null,
    scannerTrack: null,
    scannerWarmStream: null,
    scannerWarmFacingMode: '',
    scannerWarmAt: 0,
    scannerCapabilities: null,
    scannerTorchSupported: false,
    scannerTorchOn: false,
    scannerZoomSupported: false,
    scannerWarmReused: false,
    scannerZoomMin: 1,
    scannerZoomMax: 1,
    scannerZoomStep: 0.1,
    scannerZoomValue: 1,
    scannerLoopTimer: null,
    scannerLoopToken: 0,
    scannerLastRaw: '',
    scannerLastRawAt: 0,
    scannerStableValue: '',
    scannerStableCount: 0,
    scannerScanFeedbackTimer: null,
    scannerLowLightHintTimer: null,
    scannerStatusValue: '',
    scannerSuccessAudioCtx: null,
    scannerResumeTimer: null,
    scannerPrefs: {
      ticket: {
        facingMode: 'environment',
        torchOn: false,
        zoomValue: 0,
        deviceId: ''
      },
      id: {
        facingMode: 'environment',
        torchOn: false,
        zoomValue: 0,
        deviceId: ''
      }
    },
    ticketCheckinBusy: false,
    attendeesLoadingSilent: false,
    attendeeAutoRefreshBusy: false,
    attendeeAutoRefreshLastAt: 0,
    attendeeAutoRefreshLastResultAt: 0,
    attendeeAutoRefreshLastManualAt: 0,
    attendeeAutoRefreshLastBackgroundStartAt: 0,
    attendeeAutoRefreshLastBackgroundCompleteAt: 0,
    attendeeAutoRefreshNextAt: 0,
    attendeeAutoRefreshCatchupPending: false,
    attendeeAutoRefreshLastSkipReason: '',
    attendeeAutoRefreshMessage: '',
    attendeeAutoRefreshIntervalMs: 5 * 60 * 1000,
    attendeeAutoRefreshJitterMs: 0,
    attendeeAutoRefreshTimer: null,
    idScanDebugMetrics: null,
    scannerZxingReader: null,
    scannerZxingControls: null,
    scannerZxingLoadingPromise: null
  };

  let memberLookupTourOverlay = null;
  let memberLookupTourStep = 0;

  const queueKey = `vms_ops_ticket_queue_${config.user?.id || 'anon'}`;
  const checkedKey = `vms_ops_checked_${config.user?.id || 'anon'}`;
  const alertsKey = `vms_ops_last_alert_${config.user?.id || 'anon'}`;

  const venueKey = `vms_ops_selected_venue_${config.user?.id || 'anon'}`;
  const eventKeyPrefix = `vms_ops_selected_event_${config.user?.id || 'anon'}`;
  const eventConfirmKeyPrefix = `vms_ops_confirmed_event_${config.user?.id || 'anon'}`;
  const panelPrefsKey = `vms_ops_panel_prefs_${config.user?.id || 'anon'}`;
  const sessionMarkerKey = `vms_ops_session_marker_${config.user?.id || 'anon'}`;
  const scannerPrefsKey = 'vms_ops_scanner_prefs_v1';
  const scannerLifecycleKey = `vms_ops_scanner_lifecycle_${config.user?.id || 'anon'}`;

  function isAlertStaffEnabled() {
    return !!config.features?.alertStaffEnabled;
  }

  function computeDeviceJitterMs(maxMs = 30000) {
    const ceiling = Math.max(0, Number.parseInt(String(maxMs || '0'), 10) || 0);
    if (ceiling <= 0) {
      return 0;
    }

    const seed = String(config.deviceId || config.user?.id || navigator.userAgent || 'vms-ops');
    let hash = 0;
    for (let index = 0; index < seed.length; index += 1) {
      hash = ((hash * 31) + seed.charCodeAt(index)) >>> 0;
    }

    return hash % ceiling;
  }

  function scannerLifecycleNowLabel() {
    const siteNow = getSiteNowDate();
    if (siteNow instanceof Date && !Number.isNaN(siteNow.getTime())) {
      return siteNow.toISOString();
    }
    return new Date().toISOString();
  }

  function getScannerLifecycleEventContext(eventOverride = null) {
    const event = eventOverride || getSelectedEventRecord();
    const eventId = parsePositiveInt(event?.id);
    const currentStatus = event ? getEventRuntimeWindow(event).state : '';
    const previousStatus = eventId > 0 ? String(state.previousEventRuntimeStates?.[eventId] || '') : '';

    return {
      eventId,
      now: scannerLifecycleNowLabel(),
      eventShowtime: String(event?.start_at || '').trim(),
      checkInOpenTime: String(event?.checkin_open_at || event?.scan_opens_at || '').trim(),
      checkInCloseTime: String(event?.checkin_close_at || event?.scan_closes_at || '').trim(),
      eventStatus: currentStatus,
      previousEventStatus: previousStatus,
      route: String(window.location?.pathname || '/vms-ops/'),
    };
  }

  function recordScannerLifecycleEvent(input = {}) {
    const entry = Object.assign({
      reason: '',
      source: 'scanner',
      operatorId: Number.parseInt(String(config.user?.id || '0'), 10) || 0,
      scannerSessionId: String(config.deviceId || '').trim(),
      scannerSessionExpiresAt: '',
    }, getScannerLifecycleEventContext(input.event || null), input);

    try {
      const raw = localStorage.getItem(scannerLifecycleKey);
      const rows = raw ? JSON.parse(raw) : [];
      const next = Array.isArray(rows) ? rows.slice(-49) : [];
      next.push(entry);
      localStorage.setItem(scannerLifecycleKey, JSON.stringify(next));
    } catch (_error) {
      // ignore storage failures
    }

    if (window.console && typeof window.console.info === 'function') {
      window.console.info('VMS Ops scanner lifecycle', entry);
    }
  }

  function defaultScannerPrefs() {
    return {
      ticket: {
        facingMode: 'environment',
        torchOn: false,
        zoomValue: 0,
        deviceId: ''
      },
      id: {
        facingMode: 'environment',
        torchOn: false,
        zoomValue: 0,
        deviceId: ''
      }
    };
  }

  function sanitizeScannerModePrefs(raw) {
    const row = raw && typeof raw === 'object' ? raw : {};
    return {
      facingMode: row.facingMode === 'user' ? 'user' : 'environment',
      torchOn: !!row.torchOn,
      zoomValue: Number.isFinite(Number(row.zoomValue)) ? Number(row.zoomValue) : 0,
      deviceId: String(row.deviceId || '').trim()
    };
  }

  function getScannerModeKey(mode) {
    return mode === 'id' ? 'id' : 'ticket';
  }

  function loadPersistedScannerPrefs() {
    const defaults = defaultScannerPrefs();
    try {
      const raw = JSON.parse(localStorage.getItem(scannerPrefsKey) || '{}');
      state.scannerPrefs = {
        ticket: sanitizeScannerModePrefs(raw?.ticket || defaults.ticket),
        id: sanitizeScannerModePrefs(raw?.id || defaults.id)
      };
    } catch (_error) {
      state.scannerPrefs = defaults;
    }
  }

  function persistScannerPrefs() {
    try {
      localStorage.setItem(scannerPrefsKey, JSON.stringify(state.scannerPrefs || defaultScannerPrefs()));
    } catch (_error) {
      // no-op
    }
  }

  function getScannerPrefs(mode) {
    const modeKey = getScannerModeKey(mode);
    if (!state.scannerPrefs || typeof state.scannerPrefs !== 'object') {
      state.scannerPrefs = defaultScannerPrefs();
    }
    if (!state.scannerPrefs[modeKey] || typeof state.scannerPrefs[modeKey] !== 'object') {
      state.scannerPrefs[modeKey] = sanitizeScannerModePrefs({});
    }
    return state.scannerPrefs[modeKey];
  }

  function updateScannerPrefs(mode, patch = {}) {
    const modeKey = getScannerModeKey(mode);
    const current = sanitizeScannerModePrefs(getScannerPrefs(modeKey));
    const next = sanitizeScannerModePrefs({ ...current, ...patch });
    state.scannerPrefs[modeKey] = next;
    persistScannerPrefs();
    return next;
  }

  function getPersistedVenueId() {
    try {
      const raw = localStorage.getItem(venueKey);
      const parsed = Number.parseInt(String(raw || '0'), 10);
      return Number.isNaN(parsed) || parsed <= 0 ? 0 : parsed;
    } catch (e) {
      return 0;
    }
  }

  function persistVenueId(venueId) {
    const safe = Number.isFinite(venueId) && venueId > 0 ? Math.floor(venueId) : 0;
    try {
      if (safe > 0) {
        localStorage.setItem(venueKey, String(safe));
      } else {
        localStorage.removeItem(venueKey);
      }
    } catch (e) {
      /* no-op */
    }
  }

  function maybeResetSessionScopedVenueState() {
    const marker = String(config.deviceId || '').trim();
    if (!marker) {
      return;
    }

    try {
      const previousMarker = localStorage.getItem(sessionMarkerKey);
      if (previousMarker && previousMarker !== marker) {
        const previousVenueId = getPersistedVenueId();
        if (previousVenueId > 0) {
          localStorage.removeItem(eventStorageKey(previousVenueId));
          localStorage.removeItem(eventConfirmStorageKey(previousVenueId));
        }
        localStorage.removeItem(venueKey);
      }
      localStorage.setItem(sessionMarkerKey, marker);
    } catch (_error) {
      /* no-op */
    }
  }

  function eventStorageKey(venueId) {
    const safeVenueId = Number.isFinite(venueId) && venueId > 0 ? Math.floor(venueId) : 0;
    return `${eventKeyPrefix}_${safeVenueId}`;
  }

  function getPersistedEventId(venueId) {
    if (!(Number.isFinite(venueId) && venueId > 0)) {
      return 0;
    }
    const key = eventStorageKey(venueId);
    try {
      const raw = localStorage.getItem(key);
      const parsed = Number.parseInt(String(raw || '0'), 10);
      return Number.isNaN(parsed) || parsed <= 0 ? 0 : parsed;
    } catch (_error) {
      return 0;
    }
  }

  function persistEventId(venueId, eventId) {
    if (!(Number.isFinite(venueId) && venueId > 0)) {
      return;
    }
    const key = eventStorageKey(venueId);
    const safeEventId = Number.isFinite(eventId) && eventId > 0 ? Math.floor(eventId) : 0;
    try {
      if (safeEventId > 0) {
        localStorage.setItem(key, String(safeEventId));
      } else {
        localStorage.removeItem(key);
      }
    } catch (_error) {
      /* no-op */
    }
  }

  function eventConfirmStorageKey(venueId) {
    const safeVenueId = Number.isFinite(venueId) && venueId > 0 ? Math.floor(venueId) : 0;
    const today = getSiteTodayYmd() || 'unsynced';
    return `${eventConfirmKeyPrefix}_${safeVenueId}_${today}`;
  }

  function getPersistedConfirmedEventId(venueId) {
    if (!(Number.isFinite(venueId) && venueId > 0)) {
      return 0;
    }

    try {
      const raw = localStorage.getItem(eventConfirmStorageKey(venueId));
      if (!raw) {
        return 0;
      }
      const parsed = JSON.parse(raw);
      const eventId = Number.parseInt(String(parsed?.event_id || parsed?.eventId || '0'), 10);
      return Number.isNaN(eventId) || eventId <= 0 ? 0 : eventId;
    } catch (_error) {
      return 0;
    }
  }

  function persistConfirmedEventId(venueId, eventId) {
    if (!(Number.isFinite(venueId) && venueId > 0)) {
      return;
    }

    const safeEventId = Number.isFinite(eventId) && eventId > 0 ? Math.floor(eventId) : 0;
    try {
      const key = eventConfirmStorageKey(venueId);
      if (safeEventId > 0) {
        localStorage.setItem(key, JSON.stringify({
          event_id: safeEventId,
          confirmed_at: Date.now()
        }));
      } else {
        localStorage.removeItem(key);
      }
    } catch (_error) {
      /* no-op */
    }
  }

  function syncPersistedEventConfirmation(venueId, eventId) {
    const safeEventId = Number.parseInt(String(eventId || '0'), 10);
    const persistedConfirmedId = getPersistedConfirmedEventId(venueId);
    if (!Number.isNaN(safeEventId) && safeEventId > 0 && persistedConfirmedId === safeEventId) {
      state.ticketEventConfirmedId = safeEventId;
      state.ticketEventConfirmedAt = Date.now();
      state.ticketEventConfirmationSource = 'persisted';
      return true;
    }

    state.ticketEventConfirmedId = 0;
    state.ticketEventConfirmedAt = 0;
    state.ticketEventConfirmationSource = '';
    return false;
  }

  function modeFromWidth(width) {
    return width < 768 ? 'mobile' : 'tablet';
  }

  function setMode() {
    state.mode = modeFromWidth(window.innerWidth || 0);
    if (els.app) {
      els.app.dataset.mode = state.mode;
    }
    if (els.modePill) {
      els.modePill.textContent = state.mode === 'tablet' ? 'Tablet' : 'Mobile';
    }
    if (state.scannerActive) {
      applyScannerViewportMode(state.scannerMode || 'ticket');
    }
  }

  function getSiteTimezoneLabel() {
    return state.siteTimeTimezoneLabel || state.siteTimeTimezone || 'Site Time';
  }

  function getSiteNowDate() {
    if (!state.siteTimeAvailable) {
      return null;
    }

    return new Date(Date.now() + state.siteTimeOffsetMs);
  }

  function usesTwelveHourSiteClock() {
    const raw = String(state.siteTimeFormat || config.serverTimeFormat || '').trim();
    if (/[ghaA]/.test(raw)) {
      return true;
    }
    if (/[GH]/.test(raw)) {
      return false;
    }
    return true;
  }

  function formatSiteTimeWithOptions(date, options) {
    if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
      return '';
    }

    const formatterOptions = options && typeof options === 'object' ? { ...options } : {};
    const timezone = String(state.siteTimeTimezone || '').trim();
    if (timezone) {
      try {
        return new Intl.DateTimeFormat(undefined, {
          ...formatterOptions,
          timeZone: timezone
        }).format(date);
      } catch (_error) {
        // Fall back to offset-based formatting below.
      }
    }

    if (Number.isFinite(state.siteTimeTimezoneOffsetMinutes)) {
      const shifted = new Date(date.getTime() + (state.siteTimeTimezoneOffsetMinutes * 60000));
      return new Intl.DateTimeFormat(undefined, {
        ...formatterOptions,
        timeZone: 'UTC'
      }).format(shifted);
    }

    return '';
  }

  function getSiteTodayParts() {
    const now = getSiteNowDate();
    if (!now) {
      return null;
    }

    const timezone = String(state.siteTimeTimezone || '').trim();
    if (timezone) {
      try {
        const parts = new Intl.DateTimeFormat('en-CA', {
          timeZone: timezone,
          year: 'numeric',
          month: '2-digit',
          day: '2-digit'
        }).formatToParts(now);
        const year = Number.parseInt(parts.find((part) => part.type === 'year')?.value || '', 10);
        const month = Number.parseInt(parts.find((part) => part.type === 'month')?.value || '', 10);
        const day = Number.parseInt(parts.find((part) => part.type === 'day')?.value || '', 10);

        if (Number.isFinite(year) && Number.isFinite(month) && Number.isFinite(day)) {
          return { year, month, day };
        }
      } catch (_error) {
        // Fall back to offset-based formatting below.
      }
    }

    if (Number.isFinite(state.siteTimeTimezoneOffsetMinutes)) {
      const shifted = new Date(now.getTime() + (state.siteTimeTimezoneOffsetMinutes * 60000));
      return {
        year: shifted.getUTCFullYear(),
        month: shifted.getUTCMonth() + 1,
        day: shifted.getUTCDate()
      };
    }

    return null;
  }

  function getSiteTodayYmd() {
    const today = getSiteTodayParts();
    if (!today) {
      return '';
    }

    return [
      String(today.year).padStart(4, '0'),
      String(today.month).padStart(2, '0'),
      String(today.day).padStart(2, '0')
    ].join('-');
  }

  function renderSiteTime() {
    if (!els.siteTime || !els.siteTimeValue || !els.siteTimeMeta) {
      renderIdAgeCutoffNote();
      return;
    }

    els.siteTime.classList.remove('is-unavailable', 'is-stale');

    const now = getSiteNowDate();
    if (!now) {
      els.siteTimeValue.textContent = '--:--';
      els.siteTimeMeta.textContent = 'Site time unavailable - Refresh to sync';
      els.siteTime.classList.add('is-unavailable');
      renderIdAgeCutoffNote();
      return;
    }

    const timeText = formatSiteTimeWithOptions(now, {
      hour: 'numeric',
      minute: '2-digit',
      hour12: usesTwelveHourSiteClock()
    }) || '--:--';
    const dateText = formatSiteTimeWithOptions(now, {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
    const metaParts = [];
    if (dateText) {
      metaParts.push(dateText);
    }
    metaParts.push(getSiteTimezoneLabel());

    if (state.siteTimeSyncedAt > 0 && (Date.now() - state.siteTimeSyncedAt) > (15 * 60 * 1000)) {
      metaParts.push('Sync delayed');
      els.siteTime.classList.add('is-stale');
    }

    els.siteTimeValue.textContent = timeText;
    els.siteTimeMeta.textContent = metaParts.join(' - ');
    renderIdAgeCutoffNote();
  }

  function applySiteTimePayload(source) {
    const payload = source && typeof source === 'object' ? source : {};
    const epochMs = Number(payload.server_epoch_ms ?? payload.serverEpochMs ?? 0);
    const timezone = String(payload.timezone_string ?? payload.serverTimezone ?? '').trim();
    const timezoneLabel = String(payload.timezone_label ?? payload.serverTimezoneLabel ?? '').trim();
    const offsetMinutes = Number(payload.timezone_offset_minutes ?? payload.serverTimezoneOffsetMinutes ?? state.siteTimeTimezoneOffsetMinutes);
    const dateFormat = String(payload.date_format ?? payload.serverDateFormat ?? '').trim();
    const timeFormat = String(payload.time_format ?? payload.serverTimeFormat ?? '').trim();

    if (timezone) {
      state.siteTimeTimezone = timezone;
    }
    if (timezoneLabel) {
      state.siteTimeTimezoneLabel = timezoneLabel;
    }
    if (Number.isFinite(offsetMinutes)) {
      state.siteTimeTimezoneOffsetMinutes = offsetMinutes;
    }
    if (dateFormat) {
      state.siteDateFormat = dateFormat;
    }
    if (timeFormat) {
      state.siteTimeFormat = timeFormat;
    }

    if (Number.isFinite(epochMs) && epochMs > 0) {
      state.siteTimeOffsetMs = epochMs - Date.now();
      state.siteTimeAvailable = true;
      state.siteTimeSyncedAt = Date.now();
      renderSiteTime();
      return true;
    }

    renderSiteTime();
    return false;
  }

  async function syncSiteTime(reason = 'background', force = false) {
    if (state.siteTimeSyncBusy) {
      return false;
    }

    const now = Date.now();
    if (!force && state.siteTimeLastAttemptAt > 0 && (now - state.siteTimeLastAttemptAt) < 30000) {
      return false;
    }

    state.siteTimeSyncBusy = true;
    state.siteTimeLastAttemptAt = now;

    try {
      const data = await api('/system/time', {
        skipTimeSync: true,
        timeoutMs: 8000
      });
      return applySiteTimePayload(data);
    } catch (_error) {
      renderSiteTime();
      return false;
    } finally {
      state.siteTimeSyncBusy = false;
    }
  }

  function maybeScheduleSiteTimeSync(reason = 'background', force = false) {
    if (force || !state.siteTimeSyncedAt || (Date.now() - state.siteTimeSyncedAt) > (5 * 60 * 1000)) {
      syncSiteTime(reason, force);
    }
  }

  function startSiteTimeClock() {
    renderSiteTime();

    if (state.siteClockTimer) {
      return;
    }

    state.siteClockTimer = window.setInterval(renderSiteTime, 1000);
  }

  function normalizeScanRef(value) {
    return (value || '').trim().replace(/\s+/g, '');
  }

  function parseTicketScanPayload(value) {
    const raw = String(value || '').trim();
    const fallback = {
      scanReference: normalizeScanRef(raw),
      scannedEventId: 0
    };

    if (!raw) {
      return fallback;
    }

    try {
      const url = new URL(raw, window.location.origin);
      const ticketId = normalizeScanRef(url.searchParams.get('ticket_id') || '');
      if (!ticketId) {
        return fallback;
      }

      const parsedEventId = Number.parseInt(url.searchParams.get('event_id') || '0', 10);
      return {
        scanReference: ticketId,
        scannedEventId: Number.isNaN(parsedEventId) || parsedEventId <= 0 ? 0 : parsedEventId
      };
    } catch (_error) {
      return fallback;
    }
  }

  function showGlobalFeedback(message, isError = false) {
    if (!els.globalFeedback) {
      return;
    }

    if (state.globalFeedbackTimer) {
      clearTimeout(state.globalFeedbackTimer);
      state.globalFeedbackTimer = null;
    }

    els.globalFeedback.textContent = message || '';
    els.globalFeedback.style.background = isError ? 'rgba(127, 29, 29, 0.95)' : 'rgba(15, 26, 43, 0.9)';
    if (message) {
      els.globalFeedback.classList.add('is-visible');
      state.globalFeedbackTimer = setTimeout(() => {
        els.globalFeedback.classList.remove('is-visible');
      }, 2600);
      return;
    }

    els.globalFeedback.classList.remove('is-visible');
  }

  function isLoginRequired() {
    return Boolean(config.caps && config.caps.presenceCheckin);
  }

  function isAuthError(error) {
    const code = String(error?.code || '').toLowerCase();
    const status = Number(error?.status || 0);
    return status === 401
      || code === 'rest_not_logged_in'
      || code === 'not_logged_in'
      || code === 'invalid_nonce'
      || code === 'rest_cookie_invalid_nonce';
  }

  function getPresenceActionDisabledReason() {
    if (!isLoginRequired()) {
      return '';
    }
    if (state.presenceBusy) {
      return 'busy';
    }
    if (state.bootstrapBusy) {
      return 'loading';
    }
    if (state.bootstrapFailed || !state.venuesLoaded) {
      return 'venue';
    }
    if (!config.deviceId) {
      return 'device';
    }
    const venueId = getVenueId(false);
    if (!venueId) {
      return 'venue';
    }
    return '';
  }

  function syncPresenceToggleLabel() {
    if (!els.openPresence) {
      return;
    }
    if (state.presenceBusy) {
      return;
    }

    const disabledReason = getPresenceActionDisabledReason();
    if (disabledReason === 'loading') {
      els.openPresence.textContent = 'Loading Venues';
      return;
    }
    if (disabledReason === 'venue') {
      els.openPresence.textContent = state.bootstrapFailed ? 'Retry Venues' : 'Select Venue';
      return;
    }
    if (disabledReason === 'device') {
      els.openPresence.textContent = 'Device Not Ready';
      return;
    }

    els.openPresence.textContent = state.onDuty ? 'Log Out' : 'Log In';
  }

  function syncPresenceActionAvailability() {
    if (!els.openPresence || !isLoginRequired()) {
      return;
    }

    const disabledReason = getPresenceActionDisabledReason();
    els.openPresence.disabled = disabledReason !== '';
    els.openPresence.classList.toggle('is-disabled', disabledReason !== '');
    if (disabledReason) {
      els.openPresence.dataset.disabledReason = disabledReason;
    } else {
      delete els.openPresence.dataset.disabledReason;
    }
    syncPresenceToggleLabel();
  }

  function syncAuthBodyClass() {
    if (!document.body) {
      return;
    }

    document.body.classList.toggle('vms-ops-auth-on', !!state.onDuty);
  }

  function applyLoginGateVisibility() {
    syncPresenceToggleLabel();
    syncAuthBodyClass();

    if (!isLoginRequired()) {
      return;
    }

    const locked = !state.onDuty;
    if (locked) {
      clearScannerWarmStream();
      closeScanner({ keepWarm: false, reason: 'OPERATOR_SIGNED_OUT', source: 'auth_refresh' });
      if (els.ticketPanel) {
        els.ticketPanel.hidden = true;
      }
      if (els.idPanel) {
        els.idPanel.hidden = true;
      }
      if (els.alertPanel) {
        els.alertPanel.hidden = true;
      }
      if (els.callStaff) {
        els.callStaff.hidden = true;
      }
      if (!state.bootstrapBusy && !state.bootstrapFailed && getVenueId(false) > 0) {
        showGlobalFeedback('Log in to begin.');
      }
    }

    syncMemberLookupAvailability('login_gate');
  }

  async function loadPresenceStatus() {
    if (!isLoginRequired()) {
      return;
    }

    ensureSingleVenueSelected();
    const venueId = getVenueId(false);
    if (!venueId || !config.deviceId) {
      state.onDuty = false;
      clearScannerWarmStream();
      syncPresenceToggleLabel();
      syncAuthBodyClass();
      syncPresenceActionAvailability();
      scheduleAttendeeAutoRefresh('presence-missing-venue');
      renderTicketMeta();
      return;
    }

    try {
      const data = await api(`/presence/status?venue_id=${encodeURIComponent(String(venueId))}&device_id=${encodeURIComponent(String(config.deviceId))}`);
      state.onDuty = Boolean(data && data.on_duty);
    } catch (error) {
      if (isAuthError(error)) {
        state.onDuty = false;
      }
    }

    syncPresenceToggleLabel();
    syncAuthBodyClass();
    syncPresenceActionAvailability();
    applyCapabilityVisibility();
    applyLoginGateVisibility();

    if (els.presenceStatus) {
      setFeedback(els.presenceStatus, state.onDuty ? 'Logged in.' : 'Logged out.');
    }
    scheduleAttendeeAutoRefresh('presence-status');
    renderTicketMeta();
  }

  function setVenueId(value) {
    const venueId = Number.parseInt(String(value || '0'), 10);
    const safeVenueId = Number.isNaN(venueId) || venueId <= 0 ? 0 : venueId;

    if (els.venueSelect && els.venueSelect.options.length > 0) {
      const hasOption = Array.from(els.venueSelect.options).some((option) => Number.parseInt(option.value || '0', 10) === safeVenueId);
      if (hasOption) {
        els.venueSelect.value = String(safeVenueId);
      } else if (safeVenueId === 0) {
        els.venueSelect.value = '';
      }
    }

    if (els.venueOverlaySelect && els.venueOverlaySelect.options.length > 0) {
      const hasOption = Array.from(els.venueOverlaySelect.options).some((option) => Number.parseInt(option.value || '0', 10) === safeVenueId);
      if (hasOption) {
        els.venueOverlaySelect.value = String(safeVenueId);
      } else if (safeVenueId === 0) {
        els.venueOverlaySelect.value = '';
      }
    }

    syncPresenceActionAvailability();
  }

  function getVenueId(required = true) {
    const fromSelect = Number.parseInt(String(els.venueSelect?.value || '0'), 10);
    const parsed = !Number.isNaN(fromSelect) && fromSelect > 0 ? fromSelect : 0;
    if (Number.isNaN(parsed) || parsed <= 0) {
      if (required) {
        throw new Error('Venue is required.');
      }
      return 0;
    }
    return parsed;
  }

  function setFeedback(el, message, isError = false) {
    if (!el) {
      return;
    }
    const safeMessage = String(message || '').trim();
    el.textContent = safeMessage;
    el.classList.remove('is-error', 'is-ok');
    if (safeMessage) {
      el.classList.add(isError ? 'is-error' : 'is-ok');
    }
  }

  function setTicketNotice(message, tone = 'success') {
    if (!els.ticketNotice) {
      return;
    }

    els.ticketNotice.textContent = message || '';
    els.ticketNotice.classList.remove('is-ok', 'is-error', 'is-info');
    if (!message) {
      return;
    }

    if (tone === 'error') {
      els.ticketNotice.classList.add('is-error');
      return;
    }
    if (tone === 'info') {
      els.ticketNotice.classList.add('is-info');
      return;
    }
    els.ticketNotice.classList.add('is-ok');
  }

  function clearTicketNotice() {
    setTicketNotice('');
  }

  function setTicketStatus(message, tone = 'success') {
    setTicketNotice(message, tone);
    setFeedback(els.ticketFeedback, '');
  }

  function canManageMembers() {
    return !!(config.caps?.manageAdmin || config.caps?.manageLite);
  }

  function canCreateMembers() {
    return !!(config.caps?.manageAdmin || config.caps?.manageLite);
  }

  function canCreateMembersFromScan() {
    return canCreateMembers() || !!config.caps?.scanIds;
  }

  function canEditMembers() {
    return !!config.caps?.manageAdmin;
  }

  function getMemberPhotoUploadMode() {
    const mode = String(config.settings?.member_lookup_profile_photo_upload_mode || 'enabled').trim().toLowerCase();
    return ['enabled', 'managers_only', 'disabled'].includes(mode) ? mode : 'enabled';
  }

  function canManageMemberPhotos() {
    if (!config.settings?.member_lookup_allow_profile_photo) {
      return false;
    }

    const mode = getMemberPhotoUploadMode();
    if (mode === 'disabled') {
      return false;
    }

    if (mode === 'managers_only') {
      return !!config.caps?.manageAdmin;
    }

    return !!(config.caps?.manageAdmin || config.caps?.manageLite);
  }

  function getMemberPhotoUploadDisabledMessage() {
    const mode = getMemberPhotoUploadMode();
    if (mode === 'managers_only' && !config.caps?.manageAdmin) {
      return 'Only managers can upload profile photos right now.';
    }

    return 'Profile photo uploads are disabled in settings.';
  }

  function canDeleteMembers() {
    return !!config.caps?.manageAdmin;
  }

  function normalizeMemberPhotoCaptureMode(value = '') {
    if (memberPhotoCaptureHelper) {
      return memberPhotoCaptureHelper.normalizeCaptureMode(value);
    }

    return String(value || '').trim().toLowerCase() === 'user' ? 'user' : 'environment';
  }

  function toggleMemberPhotoCaptureMode(value = '') {
    if (memberPhotoCaptureHelper) {
      return memberPhotoCaptureHelper.toggleCaptureMode(value);
    }

    return normalizeMemberPhotoCaptureMode(value) === 'environment' ? 'user' : 'environment';
  }

  function getMemberPhotoCaptureLabel(value = '') {
    if (memberPhotoCaptureHelper) {
      return memberPhotoCaptureHelper.cameraModeLabel(value);
    }

    return normalizeMemberPhotoCaptureMode(value) === 'environment' ? 'Rear Camera' : 'Front Camera';
  }

  function applyMemberPhotoCaptureMode(input, mode = '') {
    const nextMode = normalizeMemberPhotoCaptureMode(mode || input?.getAttribute?.('capture') || '');
    if (memberPhotoCaptureHelper && typeof memberPhotoCaptureHelper.applyCaptureMode === 'function') {
      return memberPhotoCaptureHelper.applyCaptureMode(input, nextMode);
    }

    if (input && typeof input.setAttribute === 'function') {
      input.setAttribute('capture', nextMode);
      input.setAttribute('data-camera-preference', nextMode);
    }
    return nextMode;
  }

  function attachMemberPhotoCaptureControls(root) {
    if (!root || typeof root.querySelectorAll !== 'function') {
      return;
    }

    const photoInputs = Array.from(root.querySelectorAll('input[name="profile_photo"][type="file"]'));
    photoInputs.forEach((input) => {
      const scope = input.closest('.vms-ops-member-editor-photo') || input.closest('form') || root;
      const switchButton = scope.querySelector('[data-member-photo-switch]');
      const modeLabel = scope.querySelector('[data-member-photo-camera-label]');
      const syncMode = (preferredMode = '') => {
        const activeMode = applyMemberPhotoCaptureMode(input, preferredMode || input.getAttribute('data-camera-preference') || input.getAttribute('capture') || 'environment');
        if (modeLabel) {
          modeLabel.textContent = `Default: ${getMemberPhotoCaptureLabel(activeMode)}`;
        }
      };

      syncMode(input.getAttribute('data-camera-preference') || input.getAttribute('capture') || 'environment');
      if (switchButton && !switchButton.dataset.bound) {
        switchButton.dataset.bound = '1';
        switchButton.addEventListener('click', () => {
          const currentMode = input.getAttribute('data-camera-preference') || input.getAttribute('capture') || 'environment';
          syncMode(toggleMemberPhotoCaptureMode(currentMode));
        });
      }
    });
  }

  function getMemberLookupDobState(value = '') {
    if (memberLookupDobHelper) {
      return memberLookupDobHelper.getDobInputState(value);
    }

    const rawValue = String(value || '');
    const digits = rawValue.replace(/\D+/g, '').slice(0, 8);
    const formattedValue = digits.length <= 2
      ? digits
      : (digits.length <= 4 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`);

    return {
      rawValue,
      formattedValue,
      normalizedValue: digits.length === 8 ? digits : '',
      digits,
      digitCount: digits.length,
      hasDelimiters: /[/-]/.test(rawValue),
      isDigitsEntry: !/[/-]/.test(rawValue),
      isComplete: digits.length === 8,
      needsMoreDigits: digits.length < 8
    };
  }

  function setMemberLookupDobFeedback(element, message = '', tone = '') {
    if (!element) {
      return;
    }

    element.textContent = String(message || '').trim();
    element.classList.remove('is-error', 'is-ok');
    if (tone === 'error') {
      element.classList.add('is-error');
    } else if (tone === 'ok') {
      element.classList.add('is-ok');
    }
  }

  function syncMemberLookupDobInput(input, feedbackEl, options = {}) {
    const field = input || null;
    const currentValue = field ? String(field.value || '') : String(options.value || '');
    const dobState = getMemberLookupDobState(currentValue);
    if (field && dobState.formattedValue !== currentValue) {
      field.value = dobState.formattedValue;
    }

    const overrideMessage = String(options.message || '').trim();
    if (overrideMessage !== '') {
      setMemberLookupDobFeedback(feedbackEl, overrideMessage, options.tone === 'ok' ? 'ok' : (options.tone === 'error' ? 'error' : ''));
      return dobState;
    }

    const helperFeedback = memberLookupDobHelper && typeof memberLookupDobHelper.getDobFeedbackMessage === 'function'
      ? String(memberLookupDobHelper.getDobFeedbackMessage(currentValue, options) || '')
      : '';

    if (!dobState.isComplete) {
      if (helperFeedback !== '') {
        setMemberLookupDobFeedback(feedbackEl, helperFeedback, 'error');
        return dobState;
      }

      setMemberLookupDobFeedback(feedbackEl, '');
      return dobState;
    }

    setMemberLookupDobFeedback(feedbackEl, '');
    return dobState;
  }

  function applyMemberLookupDobEdit(input, event) {
    if (!input || !event || !memberLookupDobHelper || typeof memberLookupDobHelper.applyDobInputEdit !== 'function') {
      return false;
    }

    const inputType = String(event.inputType || '').trim();
    if (inputType === '') {
      return false;
    }

    const edit = memberLookupDobHelper.applyDobInputEdit(
      String(input.value || ''),
      Number.isFinite(input.selectionStart) ? input.selectionStart : String(input.value || '').length,
      Number.isFinite(input.selectionEnd) ? input.selectionEnd : Number.isFinite(input.selectionStart) ? input.selectionStart : String(input.value || '').length,
      inputType,
      String(event.data || '')
    );

    if (!edit || !edit.handled) {
      return false;
    }

    event.preventDefault();
    input.value = String(edit.formattedValue || '');
    if (typeof input.setSelectionRange === 'function') {
      input.setSelectionRange(edit.selectionStart, edit.selectionEnd);
    }
    return true;
  }

  function focusMemberLookupQuery() {
    if (!els.memberLookupQuery) {
      return;
    }

    window.requestAnimationFrame(() => {
      try {
        els.memberLookupQuery.focus({ preventScroll: true });
      } catch (_error) {
        els.memberLookupQuery.focus();
      }
      if (typeof els.memberLookupQuery.select === 'function') {
        els.memberLookupQuery.select();
      }
    });
  }

  function focusMemberLookupDobInput(input) {
    if (!input) {
      return;
    }

    window.setTimeout(() => {
      try {
        input.focus({ preventScroll: true });
      } catch (_error) {
        input.focus();
      }
      if (typeof input.select === 'function') {
        input.select();
      }
    }, 60);
  }

  function focusMemberLookupPhotoMatchInput(input) {
    if (!input) {
      return;
    }

    window.setTimeout(() => {
      try {
        input.focus({ preventScroll: true });
      } catch (_error) {
        input.focus();
      }
    }, 60);
  }

  function finishMemberLookupAction(message) {
    const nextMessage = String(message || '').trim();
    state.memberLookupResults = [];
    state.memberLookupCurrent = null;
    state.memberLookupQuery = '';
    renderIdRecheckContext(null);

    if (els.memberLookupQuery) {
      els.memberLookupQuery.value = '';
    }
    if (els.memberLookupResults) {
      els.memberLookupResults.innerHTML = '';
    }
    if (els.memberLookupMeta) {
      els.memberLookupMeta.textContent = '';
    }
    clearMemberLookupDetail(`${nextMessage !== '' ? `${nextMessage}. ` : ''}Search the next member.`);
    setFeedback(els.memberLookupFeedback, nextMessage);
    if (nextMessage !== '') {
      showGlobalFeedback(nextMessage);
    }
    focusMemberLookupQuery();
  }

  function hasActiveVenueForMemberLookup() {
    if (state.bootstrapBusy || state.bootstrapFailed) {
      return false;
    }

    try {
      return getVenueId(false) > 0;
    } catch (_error) {
      return false;
    }
  }

  function getMemberLookupAccessState() {
    const baseState = memberLookupAccessHelper
      ? memberLookupAccessHelper.getMemberLookupAccessState({
        caps: config.caps || {},
        settings: config.settings || {},
        permissionPayloadVersion: Number(config.permissionPayloadVersion || 0),
        requiresPresence: isLoginRequired(),
        onDuty: !!state.onDuty,
        hasActiveVenue: hasActiveVenueForMemberLookup()
      })
      : {
        visible: !!config.settings?.member_lookup_enabled,
        allowed: !!config.caps?.memberLookup && !!config.settings?.member_lookup_enabled,
        reason: '',
        detail: ''
      };

    if (state.memberLookupApiForbidden && baseState.visible) {
      return {
        visible: true,
        allowed: false,
        reason: 'api_forbidden',
        detail: state.memberLookupApiForbiddenDetail || 'permission_denied'
      };
    }

    return baseState;
  }

  function getMemberLookupPermissionSnapshot() {
    const raw = config.permissionPayload && typeof config.permissionPayload === 'object'
      ? config.permissionPayload
      : {};

    return {
      permissionPayloadVersion: Number(config.permissionPayloadVersion || 0),
      effectiveCaps: {
        manageOptions: !!config.caps?.manageOptions,
        usePwa: !!config.caps?.usePwa,
        memberLookup: !!config.caps?.memberLookup,
        manageLite: !!config.caps?.manageLite,
        manageAdmin: !!config.caps?.manageAdmin,
        presenceCheckin: !!config.caps?.presenceCheckin
      },
      rawCaps: {
        manageOptions: !!raw.manageOptions,
        usePwa: !!raw.usePwa,
        memberLookup: !!raw.memberLookup,
        manageLite: !!raw.manageLite,
        manageAdmin: !!raw.manageAdmin,
        presenceCheckin: !!raw.presenceCheckin
      }
    };
  }

  function isMemberLookupDisabledReasonError(reason) {
    return ['missing_member_lookup_cap', 'missing_ops_access', 'stale_session_payload', 'api_forbidden'].includes(String(reason || '').trim());
  }

  function getMemberLookupDisabledMessage(accessState) {
    const reason = String(accessState?.reason || '').trim();
    const detail = String(accessState?.detail || '').trim();

    if (reason === 'missing_member_lookup_cap') {
      return 'Member Lookup is disabled (missing_member_lookup_cap). Ask a manager to grant Member Lookup access.';
    }

    if (reason === 'missing_ops_access') {
      return 'Member Lookup is unavailable (missing_ops_access). Ops/PWA access is missing for this account.';
    }

    if (reason === 'stale_session_payload') {
      return 'Member Lookup is unavailable (stale_session_payload). Refresh Ops Console after clearing the app cache.';
    }

    if (reason === 'api_forbidden') {
      return 'Member Lookup is unavailable (api_forbidden). Refresh Ops Console and verify server-side permissions.';
    }

    if (reason === 'no_active_session') {
      return 'Member Lookup is disabled (no_active_session). Log in through Presence to begin this shift.';
    }

    if (detail === 'venue_required') {
      return 'Member Lookup is disabled (unknown). Select a venue to continue.';
    }

    if (detail === 'feature_disabled') {
      return 'Member Lookup is disabled (unknown). Verified Member Lookup is turned off in Ops settings.';
    }

    return 'Member Lookup is disabled (unknown).';
  }

  function logMemberLookupAccess(accessState, source = 'runtime') {
    const snapshot = getMemberLookupPermissionSnapshot();
    const diagnosticKey = [
      Number(accessState?.visible ? 1 : 0),
      Number(accessState?.allowed ? 1 : 0),
      String(accessState?.reason || ''),
      String(accessState?.detail || ''),
      Number(snapshot.effectiveCaps.manageOptions ? 1 : 0),
      Number(snapshot.effectiveCaps.usePwa ? 1 : 0),
      Number(snapshot.effectiveCaps.memberLookup ? 1 : 0),
      Number(snapshot.effectiveCaps.presenceCheckin ? 1 : 0),
      Number(state.onDuty ? 1 : 0),
      Number(hasActiveVenueForMemberLookup() ? 1 : 0)
    ].join(':');

    if (diagnosticKey === state.memberLookupDiagnosticKey) {
      return;
    }

    state.memberLookupDiagnosticKey = diagnosticKey;
    if (window.console && typeof window.console.info === 'function') {
      window.console.info('VMS Ops member lookup access', {
        source,
        access: accessState,
        snapshot
      });
    }
  }

  function syncMemberLookupAvailability(source = 'runtime') {
    const previousReason = String(state.memberLookupDisabledReason || '').trim();
    const previousMessage = previousReason !== '' ? getMemberLookupDisabledMessage({
      reason: previousReason,
      detail: state.memberLookupDisabledDetail
    }) : '';
    const accessState = getMemberLookupAccessState();
    const disabledReason = String(accessState.reason || '').trim();
    const disabledMessage = disabledReason !== '' ? getMemberLookupDisabledMessage(accessState) : '';
    const disabled = !accessState.allowed || state.memberLookupBusy;

    logMemberLookupAccess(accessState, source);

    state.memberLookupDisabledReason = disabledReason;
    state.memberLookupDisabledDetail = String(accessState.detail || '').trim();

    if (els.memberLookupPanel) {
      els.memberLookupPanel.hidden = !accessState.visible;
      if (disabledReason) {
        els.memberLookupPanel.dataset.disabledReason = disabledReason;
      } else {
        delete els.memberLookupPanel.dataset.disabledReason;
      }
    }

    [els.memberLookupQuery, els.memberLookupSearch, els.memberLookupClear, els.memberLookupTour, els.memberLookupDetail].forEach((element) => {
      if (!element) {
        return;
      }

      if ('disabled' in element) {
        element.disabled = disabled;
      }
      if (disabledReason) {
        element.dataset.disabledReason = disabledReason;
      } else {
        delete element.dataset.disabledReason;
      }
    });

    if (!accessState.visible) {
      closeMemberLookupTour();
      clearMemberLookupState({ preserveQuery: false });
      return;
    }

    if (!accessState.allowed) {
      closeMemberLookupTour();
      clearMemberLookupState({ preserveQuery: false });
      setFeedback(els.memberLookupFeedback, disabledMessage, isMemberLookupDisabledReasonError(disabledReason));
      return;
    }

    if (previousMessage !== '' && String(els.memberLookupFeedback?.textContent || '').trim() === previousMessage) {
      setFeedback(els.memberLookupFeedback, '');
    }
  }

  function markMemberLookupApiForbidden(error) {
    state.memberLookupApiForbidden = true;
    state.memberLookupApiForbiddenDetail = String(error?.code || error?.status || 'permission_denied').trim() || 'permission_denied';
    syncMemberLookupAvailability('api_forbidden');
  }

  function clearMemberLookupApiForbidden() {
    state.memberLookupApiForbidden = false;
    state.memberLookupApiForbiddenDetail = '';
  }

  function canUseMemberLookup() {
    return !!getMemberLookupAccessState().allowed;
  }

  function normalizeMemberStatus(value) {
    const status = String(value || '').trim().toLowerCase();
    return ['active', 'suspended', 'banned'].includes(status) ? status : 'active';
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function describeUiError(error) {
    const code = String(error?.code || '').trim().toLowerCase();
    const status = Number(error?.status || 0);
    const rawMessage = String(error?.rawMessage || error?.message || '').trim();

    if (
      status === 401
      || code === 'rest_not_logged_in'
      || code === 'not_logged_in'
      || code === 'invalid_nonce'
      || code === 'rest_cookie_invalid_nonce'
    ) {
      return {
        category: 'session',
        message: 'Session expired. Refresh Ops Console and log in again.'
      };
    }

    if (status === 403 || code === 'forbidden') {
      const lowerMessage = rawMessage.toLowerCase();
      const genericPermissionMessage = (
        rawMessage === ''
        || lowerMessage === 'forbidden'
        || lowerMessage === 'forbidden.'
        || lowerMessage.indexOf('you do not have permission') === 0
      );
      const shouldKeepServerMessage = !genericPermissionMessage && (
        code.indexOf('permission') !== -1
        || lowerMessage.indexOf('not enabled for this user') !== -1
        || lowerMessage.indexOf('review the') !== -1
        || lowerMessage.indexOf('vms > teams') !== -1
      );

      if (shouldKeepServerMessage) {
        return {
          category: 'permission',
          message: rawMessage
        };
      }
    }

    if (status === 403 || code === 'forbidden') {
      return {
        category: 'permission',
        message: 'Permission issue. Ask a manager if you need access to this action.'
      };
    }

    if (code === 'network_unavailable') {
      return {
        category: 'network',
        message: 'Network issue. Check the connection and try again.'
      };
    }

    if (code === 'request_timeout') {
      return {
        category: 'network',
        message: 'Network timeout. Check the connection and try again.'
      };
    }

    if (code === 'empty_payload') {
      return {
        category: 'read',
        message: 'No ID payload was detected. Scan again or paste a valid PDF417 payload.'
      };
    }

    if (code === 'invalid_pdf417_payload' || code.includes('payload') || code.includes('parse')) {
      return {
        category: 'read',
        message: 'ID could not be read. Rescan the barcode or verify the ID manually.'
      };
    }

    return {
      category: 'general',
      message: rawMessage || 'Request failed.'
    };
  }

  function normalizeUiError(error) {
    if (!error || typeof error !== 'object') {
      return error;
    }

    const details = describeUiError(error);
    error.category = details.category;
    if (!error.rawMessage) {
      error.rawMessage = String(error.message || '').trim();
    }
    error.message = details.message;
    return error;
  }

  function setHeadingExpanded(headingEl, expanded) {
    if (!headingEl) {
      return;
    }
    headingEl.setAttribute('aria-expanded', expanded ? 'true' : 'false');
  }

  function setEventsLoading(loading) {
    state.eventsLoading = !!loading;

    if (els.refreshEvents) {
      if (!els.refreshEvents.dataset.defaultLabel) {
        els.refreshEvents.dataset.defaultLabel = els.refreshEvents.textContent || 'Refresh Events';
      }
      els.refreshEvents.textContent = state.eventsLoading ? 'Loading...' : els.refreshEvents.dataset.defaultLabel;
      els.refreshEvents.disabled = state.eventsLoading;
    }

    if (els.eventSelect) {
      els.eventSelect.disabled = state.eventsLoading;
    }

    if (els.loadAttendees) {
      els.loadAttendees.disabled = state.eventsLoading || state.attendeesLoading;
    }

    if (state.eventsLoading) {
      setTicketStatus('Loading events...', 'info');
    }
    renderActiveEventCard();
  }

  function setAttendeesLoading(loading) {
    state.attendeesLoading = !!loading;

    if (els.loadAttendees) {
      if (!els.loadAttendees.dataset.defaultLabel) {
        els.loadAttendees.dataset.defaultLabel = els.loadAttendees.textContent || 'Cache Attendees';
      }
      els.loadAttendees.textContent = state.attendeesLoading ? 'Caching…' : els.loadAttendees.dataset.defaultLabel;
      els.loadAttendees.disabled = state.eventsLoading || state.attendeesLoading;
    }

    if (state.attendeesLoading && !state.attendeesLoadingSilent) {
      setTicketStatus('Caching attendees…', 'info');
    }
    renderActiveEventCard();
  }

  function formatEventDateLabel(value) {
    const source = String(value || '').trim();
    if (source === '') {
      return '';
    }

    const parsed = new Date(source);
    if (Number.isNaN(parsed.getTime())) {
      return source;
    }

    return parsed.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  }

  function getEventLabel(event, key, fallbackKey) {
    const primary = String(event?.[key] || '').trim();
    if (primary) {
      return primary;
    }

    if (!fallbackKey) {
      return '';
    }

    return formatEventDateLabel(event?.[fallbackKey] || '');
  }

  function buildEventOptionLabel(event) {
    const id = Number.parseInt(String(event?.id || '0'), 10);
    const source = String(event?.source || '').trim();
    const title = String(event?.title || '').trim();
    const scanState = String(event?.scan_state || '').trim();
    const scanStateLabel = String(event?.scan_state_label || '').trim();
    const startLabel = getEventLabel(event, 'start_at_label', 'start_at');
    const scanClosesLabel = getEventLabel(event, 'scan_closes_label', 'scan_closes_at');

    const baseTitle = title || (id > 0 ? `Event ${id}` : 'Event');
    let whenPart = '';
    if (scanState === 'reopened' && scanClosesLabel) {
      whenPart = ` — ${(scanStateLabel || 'Reopened for testing')} until ${scanClosesLabel}`;
    } else if (scanState === 'buffer' && scanClosesLabel) {
      whenPart = ` — ${(scanStateLabel || 'Post-show scan window')} until ${scanClosesLabel}`;
    } else if (scanState === 'upcoming' && startLabel) {
      whenPart = ` — ${(scanStateLabel || 'Upcoming')} ${startLabel}`;
    } else if (startLabel) {
      whenPart = ` — ${startLabel}`;
    }

    // Put the identifier at the END, not the beginning.
    let idPart = '';
    if (id > 0) {
      if (!source || source === 'tribe_events') {
        idPart = ` (TEC #${id})`;
      } else {
        idPart = ` (${source} #${id})`;
      }
    }

    return `${baseTitle}${whenPart}${idPart}`;
  }

  function getSelectedEventRecord() {
    const selected = getSelectedEvent();
    if (!selected) {
      return null;
    }

    const eventId = selected.id;
    return state.ticketEvents.find((event) => {
      const rowId = Number.parseInt(String(event?.id || '0'), 10);
      return !Number.isNaN(rowId) && rowId === eventId;
    }) || null;
  }

  function buildTicketMetaText(event) {
    const queueCount = Array.isArray(state.queue) ? state.queue.length : 0;
    const parts = [];

    if (event && typeof event === 'object') {
      const runtime = getEventRuntimeWindow(event);
      const scanState = runtime.state;
      const scanStateLabel = String(event.scan_state_label || '').trim();
      const startLabel = getEventLabel(event, 'start_at_label', 'start_at');
      const endLabel = getEventLabel(event, 'end_at_label', 'end_at');
      const scanOpensLabel = getEventLabel(event, 'scan_opens_label', 'scan_opens_at');
      const scanClosesLabel = getEventLabel(event, 'scan_closes_label', 'scan_closes_at');

      if (scanState === 'reopened') {
        let message = `${scanStateLabel || 'Reopened for testing'}.`;
        if (endLabel) {
          message += ` Event ended ${endLabel}.`;
        }
        message += ' Real ticket check-ins are allowed in this testing window.';
        if (scanClosesLabel) {
          message += ` Testing closes ${scanClosesLabel} Site Time.`;
        }
        parts.push(message);
      } else if (scanState === 'buffer') {
        let message = `${scanStateLabel || 'Post-show scan window'}.`;
        if (endLabel) {
          message += ` Event ended ${endLabel}.`;
        }
        if (scanClosesLabel) {
          message += ` Scanning closes ${scanClosesLabel} Site Time.`;
        }
        parts.push(message);
      } else if (scanState === 'upcoming') {
        let message = `${scanStateLabel || 'Upcoming'}.`;
        if (startLabel) {
          message += ` Starts ${startLabel}.`;
        }
        if (scanOpensLabel) {
          message += ` Check-ins open ${scanOpensLabel}.`;
        }
        message += ' Pre-event scans validate tickets only; no check-in is recorded until the window opens.';
        if (scanClosesLabel) {
          message += ` Scanning closes ${scanClosesLabel} Site Time.`;
        }
        parts.push(message);
      } else {
        let message = `${scanStateLabel || 'Live'}.`;
        if (startLabel) {
          message += ` Starts ${startLabel}.`;
        }
        if (endLabel) {
          message += ` Ends ${endLabel}.`;
        }
        if (scanClosesLabel && scanClosesLabel !== endLabel) {
          message += ` Post-show access closes ${scanClosesLabel} Site Time.`;
        }
        parts.push(message);
      }
    } else {
      const bufferHours = Number.parseInt(String(config.settings?.post_show_scan_buffer_hours || '0'), 10) || 0;
      if (bufferHours > 0) {
        parts.push(`Site Time controls scan cutoffs. Ended events stay available for ${bufferHours} hour${bufferHours === 1 ? '' : 's'} after show end.`);
      } else {
        parts.push('Site Time controls scan cutoffs for ticket scanning.');
      }
    }

    if (queueCount > 0) {
      parts.push(`Offline queue: ${queueCount}`);
    }

    if (state.attendeeAutoRefreshMessage) {
      parts.push(state.attendeeAutoRefreshMessage);
    }

    return parts.join(' • ');
  }

  function isSelectedTicketEventConfirmed() {
    const selected = getSelectedEvent();
    return !!selected && state.ticketEventConfirmedId === selected.id;
  }

  function getEventDisplayTitle(event) {
    const id = Number.parseInt(String(event?.id || '0'), 10);
    const title = String(event?.title || '').trim();
    return title || (id > 0 ? `Event ${id}` : 'Selected event');
  }

  function buildActiveEventMeta(event) {
    if (!event || typeof event !== 'object') {
      return '';
    }

    const parts = [];
    const startLabel = getEventLabel(event, 'start_at_label', 'start_at');
    const endLabel = getEventLabel(event, 'end_at_label', 'end_at');
    const scanClosesLabel = getEventLabel(event, 'scan_closes_label', 'scan_closes_at');

    if (startLabel) {
      parts.push(startLabel);
    }
    if (endLabel) {
      parts.push(`Ends ${endLabel}`);
    }
    if (scanClosesLabel && scanClosesLabel !== endLabel) {
      parts.push(`Scan window until ${scanClosesLabel}`);
    }

    const id = Number.parseInt(String(event?.id || '0'), 10);
    if (id > 0) {
      parts.push(`Event #${id}`);
    }

    return parts.join(' • ');
  }

  function getOfflineReadiness(eventId) {
    const selected = getSelectedEvent();
    const safeEventId = Number.parseInt(String(eventId || selected?.id || '0'), 10);
    const cache = getAttendeeCache(safeEventId);
    const total = Array.isArray(cache.items) ? cache.items.length : 0;

    if (!(safeEventId > 0)) {
      return { state: 'none', label: 'Online required', detail: 'No event selected.' };
    }

    if (total > 0) {
      const updated = String(cache.updatedAt || '').trim();
      return {
        state: 'ready',
        label: navigator.onLine ? 'Online — offline backup ready' : 'Offline backup ready',
        detail: updated ? `${total} cached • ${updated}` : `${total} cached`
      };
    }

    if (navigator.onLine) {
      return { state: 'limited', label: 'Online only right now', detail: 'Cache attendees before relying on offline backup scanning.' };
    }

    return { state: 'required', label: 'Online Required', detail: 'No attendee cache is available on this device.' };
  }

  function getSelectedVenueRecord() {
    const venueId = (() => {
      try {
        return getVenueId(false);
      } catch (_error) {
        return 0;
      }
    })();

    if (!(venueId > 0)) {
      return null;
    }

    return (Array.isArray(state.venues) ? state.venues : []).find((venue) => parsePositiveInt(venue?.id) === venueId) || null;
  }

  function formatAutoRefreshTime(epochMs) {
    const safeEpochMs = Number(epochMs || 0);
    if (!(safeEpochMs > 0)) {
      return '—';
    }

    try {
      return new Date(safeEpochMs).toLocaleString([], {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        second: '2-digit'
      });
    } catch (_error) {
      return '—';
    }
  }

  function formatAutoRefreshNextTime(epochMs) {
    const safeEpochMs = Number(epochMs || 0);
    if (!(safeEpochMs > 0)) {
      return '—';
    }

    const baseLabel = formatAutoRefreshTime(safeEpochMs);
    return safeEpochMs <= Date.now() ? `${baseLabel} (due)` : baseLabel;
  }

  function renderAttendeeCacheDiagnostics() {
    if (!els.ticketCacheDebug) {
      return;
    }

    const debugLevel = config.debugMode ? 'full' : (config.caps?.manageAdmin ? 'compact' : 'hidden');
    if (debugLevel === 'hidden') {
      els.ticketCacheDebug.hidden = true;
      els.ticketCacheDebug.textContent = '';
      return;
    }

    const shouldShow = debugLevel === 'full'
      || !!state.attendeeAutoRefreshLastSkipReason
      || state.attendeeAutoRefreshNextAt > 0
      || state.attendeeAutoRefreshLastManualAt > 0
      || state.attendeeAutoRefreshLastBackgroundStartAt > 0
      || state.attendeeAutoRefreshLastBackgroundCompleteAt > 0;

    els.ticketCacheDebug.hidden = !shouldShow;
    if (!shouldShow) {
      els.ticketCacheDebug.textContent = '';
      return;
    }

    const venue = getSelectedVenueRecord();
    const event = getSelectedEventRecord();
    const eventId = parsePositiveInt(event?.id);
    const venueId = parsePositiveInt(venue?.id);
    const venueName = String(venue?.name || '').trim() || '—';
    const userLabel = String(config.user?.roleLabel || '').trim()
      || String(config.wpAuthLabel || '').trim()
      || String(config.user?.name || '').trim()
      || '—';
    const visibilityState = String(document.visibilityState || (document.hidden ? 'hidden' : 'visible') || 'unknown');

    const parts = debugLevel === 'full'
      ? [
        `v${String(config.appVersion || 'dev').trim() || 'dev'}`,
        `User ${userLabel}`,
        `Ops ${state.onDuty ? 'logged in' : 'logged out'}`,
        `Venue ${venueId > 0 ? `${venueId} ${venueName}` : '—'}`,
        `Event ${eventId > 0 ? eventId : '—'}`,
        `Manual ${formatAutoRefreshTime(state.attendeeAutoRefreshLastManualAt)}`,
        `BG start ${formatAutoRefreshTime(state.attendeeAutoRefreshLastBackgroundStartAt)}`,
        `BG done ${formatAutoRefreshTime(state.attendeeAutoRefreshLastBackgroundCompleteAt)}`,
        `Next ${formatAutoRefreshNextTime(state.attendeeAutoRefreshNextAt)}`,
        `Skip ${state.attendeeAutoRefreshLastSkipReason || '—'}`,
        `Visibility ${visibilityState}`
      ]
      : [
        `v${String(config.appVersion || 'dev').trim() || 'dev'}`,
        `Venue ${venueId > 0 ? venueName : '—'}`,
        `Event ${eventId > 0 ? eventId : '—'}`,
        `Last BG ${formatAutoRefreshTime(state.attendeeAutoRefreshLastBackgroundCompleteAt)}`,
        `Next ${formatAutoRefreshNextTime(state.attendeeAutoRefreshNextAt)}`,
        `Skip ${state.attendeeAutoRefreshLastSkipReason || '—'}`
      ];

    els.ticketCacheDebug.textContent = parts.join(' • ');
  }

  function updateTicketActionAvailability() {
    const selected = getSelectedEvent();
    const confirmed = isSelectedTicketEventConfirmed();
    const locked = isLoginRequired() && !state.onDuty;
    const canTickets = !!config.caps?.scanTickets;
    const scanLocked = !canTickets || locked || !selected || !confirmed;

    if (els.ticketScan) {
      els.ticketScan.disabled = scanLocked;
      if (!selected) {
        els.ticketScan.placeholder = 'Select and confirm an event first';
      } else if (!confirmed) {
        els.ticketScan.placeholder = 'Confirm active event before scanning';
      } else {
        els.ticketScan.placeholder = 'Scan or enter ticket code';
      }
    }
    if (els.ticketScanCamera) {
      els.ticketScanCamera.disabled = scanLocked || state.scannerBusy;
    }
    if (els.ticketSubmit) {
      els.ticketSubmit.disabled = scanLocked || state.ticketCheckinBusy;
    }
  }

  function renderActiveEventCard() {
    const selected = getSelectedEvent();
    const event = getSelectedEventRecord();

    if (!els.activeEventCard) {
      updateTicketActionAvailability();
      return;
    }

    if (!selected || !event) {
      els.activeEventCard.hidden = true;
      if (els.activeEventName) {
        els.activeEventName.textContent = 'No event selected';
      }
      if (els.activeEventMeta) {
        els.activeEventMeta.textContent = '';
      }
      if (els.activeEventStatus) {
        els.activeEventStatus.textContent = 'Select event';
        els.activeEventStatus.dataset.state = 'required';
      }
      updateTicketActionAvailability();
      return;
    }

    const confirmed = isSelectedTicketEventConfirmed();
    const readiness = getOfflineReadiness(selected.id);
    els.activeEventCard.hidden = false;
    els.activeEventCard.classList.toggle('is-confirmed', confirmed);
    els.activeEventCard.classList.toggle('is-unconfirmed', !confirmed);
    els.activeEventCard.classList.toggle('is-offline-ready', readiness.state === 'ready');

    if (els.activeEventName) {
      els.activeEventName.textContent = getEventDisplayTitle(event);
    }
    if (els.activeEventMeta) {
      const meta = buildActiveEventMeta(event);
      els.activeEventMeta.textContent = [meta, readiness.detail].filter(Boolean).join(' • ');
    }
    if (els.activeEventStatus) {
      els.activeEventStatus.textContent = confirmed ? readiness.label : 'Needs confirmation';
      els.activeEventStatus.dataset.state = confirmed ? readiness.state : 'confirm';
    }
    if (els.confirmEvent) {
      els.confirmEvent.hidden = confirmed;
      els.confirmEvent.disabled = !selected || state.attendeesLoading;
    }
    if (els.changeEvent) {
      els.changeEvent.hidden = false;
      els.changeEvent.disabled = state.eventsLoading;
    }

    updateTicketActionAvailability();
  }

  function renderTicketMeta() {
    if (els.ticketCacheMeta) {
      els.ticketCacheMeta.textContent = buildTicketMetaText(getSelectedEventRecord());
    }
    renderAttendeeCacheDiagnostics();
    renderActiveEventCard();
  }

  function toEpochMs(value) {
    const parsed = Number.parseInt(String(value || '0'), 10);
    return Number.isNaN(parsed) || parsed <= 0 ? 0 : parsed;
  }

  function getEventRuntimeWindow(event) {
    const fallbackState = String(event?.scan_state || '').trim() || 'live';
    const now = Date.now();

    const scanOpensAt = toEpochMs(event?.checkin_open_epoch_ms || event?.scan_opens_epoch_ms);
    const startAt = toEpochMs(event?.start_at_epoch_ms);
    const endAt = toEpochMs(event?.end_at_epoch_ms);
    const bufferEndAt = toEpochMs(event?.buffer_end_epoch_ms);
    const reopenUntilAt = toEpochMs(event?.reopen_until_epoch_ms);
    const scanClosesAt = toEpochMs(event?.checkin_close_epoch_ms || event?.scan_closes_epoch_ms);

    let stateValue = fallbackState;
    if (scanOpensAt > 0 && now < scanOpensAt) {
      stateValue = 'upcoming';
    } else if (scanClosesAt > 0 && now > scanClosesAt) {
      stateValue = reopenUntilAt > 0 && now <= reopenUntilAt ? 'reopened' : 'expired';
    } else if (endAt > 0 && now > endAt) {
      stateValue = 'buffer';
    } else if (startAt > 0 && now >= startAt) {
      stateValue = 'live';
    }

    return {
      state: stateValue,
      scanOpensAt,
      startAt,
      endAt,
      bufferEndAt,
      reopenUntilAt,
      scanClosesAt
    };
  }

  function eventShouldAutoRefreshAttendees(event) {
    if (!event || typeof event !== 'object') {
      return false;
    }

    const runtime = getEventRuntimeWindow(event);
    return runtime.state === 'live' || runtime.state === 'buffer' || runtime.state === 'reopened';
  }

  function getAttendeeLookupActionLabel(event) {
    const runtime = getEventRuntimeWindow(event);
    return runtime.state === 'upcoming' ? 'Validate' : 'Check In';
  }

  function dedupeEvents(events) {
    const rows = Array.isArray(events) ? events : [];
    const seen = {};
    const out = [];

    rows.forEach((event) => {
      const id = Number.parseInt(String(event?.id || '0'), 10);
      if (Number.isNaN(id) || id <= 0) {
        return;
      }

      const key = `id:${id}`;
      const index = seen[key];

      if (index === undefined) {
        seen[key] = out.length;
        out.push(event);
        return;
      }

      const current = out[index] || {};
      const currentScore = (
        (String(current.source || '').trim() ? 1 : 0)
        + (String(current.start_at || '').trim() ? 1 : 0)
        + (String(current.end_at || '').trim() ? 1 : 0)
      );
      const nextScore = (
        (String(event?.source || '').trim() ? 1 : 0)
        + (String(event?.start_at || '').trim() ? 1 : 0)
        + (String(event?.end_at || '').trim() ? 1 : 0)
      );

      if (nextScore >= currentScore) {
        out[index] = event;
      }
    });

    return out;
  }

  function parsePositiveInt(value) {
    const parsed = Number.parseInt(String(value || '0'), 10);
    return Number.isNaN(parsed) || parsed <= 0 ? 0 : parsed;
  }

  function getEventStartYmd(event) {
    const startAt = String(event?.start_at || '').trim();
    return /^\d{4}-\d{2}-\d{2}/.test(startAt) ? startAt.slice(0, 10) : '';
  }

  function firstEventId(events) {
    const rows = Array.isArray(events) ? events : [];
    for (let index = 0; index < rows.length; index += 1) {
      const eventId = parsePositiveInt(rows[index]?.id);
      if (eventId > 0) {
        return eventId;
      }
    }
    return 0;
  }

  function hasEventId(events, eventId) {
    const safeEventId = parsePositiveInt(eventId);
    if (safeEventId <= 0) {
      return false;
    }

    return (Array.isArray(events) ? events : []).some((event) => parsePositiveInt(event?.id) === safeEventId);
  }

  function getLoginDefaultEventId(events) {
    const rows = Array.isArray(events) ? events : [];
    if (!rows.length) {
      return 0;
    }

    const todayYmd = getSiteTodayYmd();
    if (todayYmd !== '') {
      const sameDay = rows.find((event) => getEventStartYmd(event) === todayYmd);
      const sameDayId = parsePositiveInt(sameDay?.id);
      if (sameDayId > 0) {
        return sameDayId;
      }

      const nextEvent = rows.find((event) => {
        const eventYmd = getEventStartYmd(event);
        return eventYmd !== '' && eventYmd > todayYmd;
      });
      const nextEventId = parsePositiveInt(nextEvent?.id);
      if (nextEventId > 0) {
        return nextEventId;
      }
    }

    return firstEventId(rows);
  }

  function resolveTicketEventSelection(events, previousSelected, venueId, selectionMode = 'preserve') {
    const rows = Array.isArray(events) ? events : [];
    if (!rows.length) {
      return 0;
    }

    const previousId = parsePositiveInt(previousSelected);
    const persistedId = getPersistedEventId(venueId);
    const persistedConfirmedId = getPersistedConfirmedEventId(venueId);
    const defaultId = getLoginDefaultEventId(rows);

    if (selectionMode === 'login-default') {
      const todayYmd = getSiteTodayYmd();
      if (todayYmd !== '' && hasEventId(rows, persistedConfirmedId)) {
        const confirmedEvent = rows.find((event) => parsePositiveInt(event?.id) === persistedConfirmedId) || null;
        if (confirmedEvent && getEventStartYmd(confirmedEvent) === todayYmd) {
          return persistedConfirmedId;
        }
      }
      return defaultId || persistedId || previousId || firstEventId(rows);
    }

    if (hasEventId(rows, previousId)) {
      return previousId;
    }
    if (hasEventId(rows, persistedId)) {
      return persistedId;
    }

    return defaultId || firstEventId(rows);
  }

  function setPanelCollapsed(panelEl, headingEl, bodyEl, collapsed) {
    const isCollapsed = !!collapsed;

    if (panelEl) {
      panelEl.classList.toggle('is-collapsed', isCollapsed);
    }
    if (bodyEl) {
      bodyEl.hidden = isCollapsed;
    }
    setHeadingExpanded(headingEl, !isCollapsed);
  }

  function persistPanelPrefs() {
    const payload = {
      ticketCollapsed: !!state.ticketCollapsed,
      idCollapsed: !!state.idCollapsed,
      memberLookupCollapsed: !!state.memberLookupCollapsed
    };
    try {
      localStorage.setItem(panelPrefsKey, JSON.stringify(payload));
    } catch (_error) {
      /* no-op */
    }
  }

  function setTicketCollapsed(collapsed, persist = true) {
    state.ticketCollapsed = !!collapsed;
    setPanelCollapsed(els.ticketPanel, els.ticketHeading, els.ticketBody, state.ticketCollapsed);
    if (persist) {
      persistPanelPrefs();
    }
  }

  function setIdCollapsed(collapsed, persist = true) {
    state.idCollapsed = !!collapsed;
    setPanelCollapsed(els.idPanel, els.idHeading, els.idBody, state.idCollapsed);
    if (persist) {
      persistPanelPrefs();
    }
  }

  function setMemberLookupCollapsed(collapsed, persist = true) {
    state.memberLookupCollapsed = !!collapsed;
    setPanelCollapsed(els.memberLookupPanel, els.memberLookupHeading, els.memberLookupBody, state.memberLookupCollapsed);
    if (persist) {
      persistPanelPrefs();
    }
  }

  function setPresenceCollapsed(collapsed) {
    state.presenceCollapsed = !!collapsed;

    if (els.presencePanel) {
      els.presencePanel.classList.toggle('is-collapsed', state.presenceCollapsed);
    }
    setHeadingExpanded(els.presenceHeading, !state.presenceCollapsed);
  }

  function setManualFormVisible(visible) {
    if (els.manualForm) {
      els.manualForm.hidden = !visible;
    }
    setHeadingExpanded(els.manualHeading, !!visible);
  }

  function syncManualMemberPhotoFields() {
    if (!els.manualForm) {
      return;
    }

    const photoEnabled = canManageMemberPhotos();
    const photoConsentToggle = els.manualForm.querySelector('input[name="photo_consent"]')?.closest('.vms-ops-inline-check');
    const photoUploadField = els.manualForm.querySelector('.vms-ops-file-field');
    const photoUploadInput = els.manualForm.querySelector('input[name="profile_photo"]');

    if (photoConsentToggle) {
      photoConsentToggle.hidden = !photoEnabled;
    }
    if (photoUploadField) {
      photoUploadField.hidden = !photoEnabled;
    }
    if (!photoEnabled) {
      if (photoUploadInput) {
        photoUploadInput.value = '';
      }
      const photoConsentInput = els.manualForm.querySelector('input[name="photo_consent"]');
      if (photoConsentInput) {
        photoConsentInput.checked = false;
      }
    }

    attachMemberPhotoCaptureControls(els.manualForm);
  }

  function toggleManualMemberForm() {
    if (!els.manualForm) {
      return;
    }

    setManualFormVisible(!!els.manualForm.hidden);
  }

  function loadPersistedState() {
    try {
      state.queue = JSON.parse(localStorage.getItem(queueKey) || '[]');
      if (!Array.isArray(state.queue)) {
        state.queue = [];
      }
    } catch (_error) {
      state.queue = [];
    }

    try {
      state.localCheckedKeys = JSON.parse(localStorage.getItem(checkedKey) || '{}');
      if (!state.localCheckedKeys || typeof state.localCheckedKeys !== 'object') {
        state.localCheckedKeys = {};
      }
    } catch (_error) {
      state.localCheckedKeys = {};
    }

    const lastAlert = Number.parseInt(localStorage.getItem(alertsKey) || '0', 10);
    state.lastAlertId = Number.isNaN(lastAlert) ? 0 : lastAlert;

    try {
      const rawPrefs = JSON.parse(localStorage.getItem(panelPrefsKey) || '{}');
      if (rawPrefs && typeof rawPrefs === 'object') {
        if (typeof rawPrefs.ticketCollapsed === 'boolean') {
          state.ticketCollapsed = rawPrefs.ticketCollapsed;
        }
        if (typeof rawPrefs.idCollapsed === 'boolean') {
          state.idCollapsed = rawPrefs.idCollapsed;
        }
        if (typeof rawPrefs.memberLookupCollapsed === 'boolean') {
          state.memberLookupCollapsed = rawPrefs.memberLookupCollapsed;
        }
      }
    } catch (_error) {
      state.ticketCollapsed = false;
      state.idCollapsed = false;
      state.memberLookupCollapsed = true;
    }
  }

  function persistQueue() {
    localStorage.setItem(queueKey, JSON.stringify(state.queue));
  }

  function persistChecked() {
    localStorage.setItem(checkedKey, JSON.stringify(state.localCheckedKeys));
  }

  function persistAlertCursor() {
    localStorage.setItem(alertsKey, String(state.lastAlertId));
  }

  function resetVenueSelectors() {
    if (els.venueSelect) {
      els.venueSelect.innerHTML = '<option value="">Select venue</option>';
      els.venueSelect.value = '';
    }
    if (els.venueOverlaySelect) {
      els.venueOverlaySelect.innerHTML = '<option value="">Select venue</option>';
      els.venueOverlaySelect.value = '';
    }
    state.venues = [];
  }

  function renderVenueOptions(venues, selectedVenueId = 0) {
    const validVenues = Array.isArray(venues) ? venues : [];
    state.venuesLoaded = true;
    state.bootstrapBusy = false;
    state.bootstrapFailed = false;
    state.bootstrapErrorMessage = '';
    if (els.app) {
      els.app.classList.remove('is-venues-loading');
    }
    syncPresenceActionAvailability();

    resetVenueSelectors();

    const activeVenues = [];
    const seenVenueIds = new Set();

    validVenues.forEach((venue) => {
      const rawVenueId = venue && typeof venue === 'object'
        ? (venue.id ?? venue.venue_id ?? venue.post_id ?? venue.ID ?? 0)
        : 0;
      const venueId = Number.parseInt(String(rawVenueId || '0'), 10);
      if (Number.isNaN(venueId) || venueId <= 0) {
        return;
      }
      if (seenVenueIds.has(venueId)) {
        return;
      }
      seenVenueIds.add(venueId);

      const rawLabel = venue && typeof venue === 'object'
        ? (venue.name ?? venue.title ?? venue.post_title ?? '')
        : '';
      const label = String(rawLabel || '').trim() || `Venue ${venueId}`;

      activeVenues.push({ id: venueId, name: label });

      if (els.venueSelect) {
        const option = document.createElement('option');
        option.value = String(venueId);
        option.textContent = label;
        els.venueSelect.appendChild(option);
      }

      if (els.venueOverlaySelect) {
        const option = document.createElement('option');
        option.value = String(venueId);
        option.textContent = label;
        els.venueOverlaySelect.appendChild(option);
      }
    });

    state.venues = activeVenues;

    const setVenuePickerVisible = (visible) => {
      const shouldShow = state.venuesLoaded && !!visible;
      if (els.venueLabel) {
        els.venueLabel.hidden = !shouldShow;
      }
      if (els.venueSelect) {
        els.venueSelect.hidden = !shouldShow;
      }
      if (els.venueOverlayLabel) {
        els.venueOverlayLabel.hidden = !shouldShow;
      }
      if (els.venueOverlaySelect) {
        els.venueOverlaySelect.hidden = !shouldShow;
      }
      if (els.venueOverlayContinue) {
        els.venueOverlayContinue.hidden = !shouldShow;
      }
    };

    const applyToSelects = (venueId) => {
      if (els.venueSelect) {
        els.venueSelect.value = venueId > 0 ? String(venueId) : '';
      }
      if (els.venueOverlaySelect) {
        els.venueOverlaySelect.value = venueId > 0 ? String(venueId) : '';
      }
      if (els.venueOverlayContinue) {
        els.venueOverlayContinue.disabled = !(venueId > 0);
      }
    };

    if (activeVenues.length < 1) {
      setVenuePickerVisible(false);
      applyToSelects(0);
      setVenueId(0);
      updateVenueOverlayState();
      return;
    }

    // QoL: if there is only one active venue, auto-select it and hide the picker.
    if (activeVenues.length === 1) {
      const onlyVenueId = Number.parseInt(String(activeVenues[0].id || '0'), 10);
      if (!Number.isNaN(onlyVenueId) && onlyVenueId > 0) {
        setVenuePickerVisible(false);
        applyToSelects(onlyVenueId);
        setVenueId(onlyVenueId);
        persistVenueId(onlyVenueId);
        if (els.venueOverlay) {
          els.venueOverlay.hidden = true;
        }
        updateVenueOverlayState();
        return;
      }
    }

    setVenuePickerVisible(true);

    if (selectedVenueId > 0) {
      applyToSelects(selectedVenueId);
      setVenueId(selectedVenueId);
      updateVenueOverlayState();
      return;
    }

    try {
      const current = getVenueId(false);
      applyToSelects(current);
      setVenueId(current);
    } catch (_error) {
      applyToSelects(0);
      setVenueId(0);
    }
    updateVenueOverlayState();
  }

  function getSingleActiveVenueId() {
    if (!Array.isArray(state.venues) || state.venues.length !== 1) {
      return 0;
    }

    const onlyVenueId = Number.parseInt(String(state.venues[0]?.id || '0'), 10);
    if (Number.isNaN(onlyVenueId) || onlyVenueId <= 0) {
      return 0;
    }
    return onlyVenueId;
  }

  function ensureSingleVenueSelected() {
    const onlyVenueId = getSingleActiveVenueId();
    if (!(onlyVenueId > 0)) {
      return false;
    }

    setVenueId(onlyVenueId);
    persistVenueId(onlyVenueId);

    if (els.venueOverlay) {
      els.venueOverlay.hidden = true;
    }
    if (els.app) {
      els.app.classList.remove('is-venue-locked');
    }
    return true;
  }

  function applyBootstrapData(data) {
    const bootstrap = data && typeof data === 'object' ? data : {};
    const venues = Array.isArray(bootstrap.venues) ? bootstrap.venues : [];
    applySiteTimePayload(bootstrap);

    // Venue selection precedence: already-selected (overlay) > persisted > server bootstrap > settings default.
    const alreadySelected = (() => {
      try {
        return getVenueId(false);
      } catch (e) {
        return 0;
      }
    })();

    const persisted = getPersistedVenueId();
    const bootstrapVenueId = Number.parseInt(String(bootstrap.venue_id || '0'), 10) || 0;

    let venueId = alreadySelected || persisted || bootstrapVenueId || config.defaultVenueId || 0;
    if (venueId > 0 && venues.length > 0 && !venues.some((venue) => {
      const rowId = venue && typeof venue === 'object'
        ? (venue.id ?? venue.venue_id ?? venue.post_id ?? venue.ID ?? 0)
        : 0;
      return Number.parseInt(String(rowId || '0'), 10) === venueId;
    })) {
      venueId = 0;
    }

    renderVenueOptions(venues, venueId);
  }



  function applyCapabilityVisibility() {
    const caps = config.caps || {};
    const canTickets = !!caps.scanTickets;
    const canIds = !!caps.scanIds;
    const alertStaffEnabled = isAlertStaffEnabled();
    const canSend = alertStaffEnabled && !!caps.sendAlerts;
    const canReceive = alertStaffEnabled && !!caps.receiveAlerts;
    const canMembers = !!(caps.manageAdmin || caps.manageLite);
    const canCreateMembers = !!(caps.manageAdmin || caps.manageLite);
    const canPresence = !!caps.presenceCheckin;
    const locked = isLoginRequired() && !state.onDuty;

    if (els.ticketPanel) {
      els.ticketPanel.hidden = !canTickets || locked;
    }
    if (els.ticketScanCamera) {
      els.ticketScanCamera.hidden = !canTickets;
      els.ticketScanCamera.disabled = !canTickets || locked;
    }
    if (els.ticketSubmitAll) {
      els.ticketSubmitAll.hidden = !canTickets;
      els.ticketSubmitAll.disabled = !canTickets || locked;
    }

    if (els.idPanel) {
      els.idPanel.hidden = !(canIds || canMembers) || locked;
    }

    // ID scan UI should only appear for ID-scanning staff.
    if (els.idAdvanced) {
      els.idAdvanced.hidden = !canIds || !config.debugMode;
    }
    if (els.idPayload) {
      els.idPayload.disabled = !canIds || locked;
    }
    if (els.idProcess) {
      if (!canIds) {
        els.idProcess.hidden = true;
      }
      els.idProcess.disabled = !canIds || locked;
    }
    if (els.idRetryLog) {
      if (!canIds) {
        els.idRetryLog.hidden = true;
      }
      els.idRetryLog.disabled = !canIds || locked;
    }
    if (els.idScanCamera) {
      els.idScanCamera.hidden = !canIds;
      els.idScanCamera.disabled = !canIds || locked;
    }
    if (!canIds || locked) {
      hideIdNotFoundPrompt();
    }

    // Manual member creation is limited to member managers/lite managers; scanned-ID add uses scan permission.
    if (els.manualHeading) {
      els.manualHeading.hidden = !canCreateMembers;
    }
    if (els.manualForm && !canCreateMembers) {
      els.manualForm.hidden = true;
    }

    if (els.alertPanel) {
      els.alertPanel.hidden = !(canSend || canReceive) || locked;
    }

    if (els.callStaff) {
      els.callStaff.hidden = !canSend || locked;
    }

    if (els.openPresence) {
      els.openPresence.hidden = !canPresence;
    }
    syncPresenceActionAvailability();
    syncMemberLookupAvailability('capabilities');

    syncTicketSubmitAllButton();
  }

  function updateVenueOverlayState() {
    const hasSelectableVenues = Array.isArray(state.venues) && state.venues.length > 1;
    const hasSingleVenue = getSingleActiveVenueId() > 0;
    const selectedVenueId = (() => {
      try {
        return getVenueId(false);
      } catch (_error) {
        return 0;
      }
    })();

    if (els.venueOverlayTitle) {
      let title = 'Select a venue to begin';
      if (state.bootstrapBusy) {
        title = 'Loading console...';
      } else if (state.bootstrapFailed) {
        title = 'Could not load venues';
      } else if (hasSingleVenue && selectedVenueId > 0) {
        title = 'Opening venue...';
      }
      els.venueOverlayTitle.textContent = title;
    }

    if (els.venueOverlayLead) {
      let lead = 'Venue selection is required before using the console.';
      if (state.bootstrapBusy) {
        lead = 'Checking venues and restoring this device.';
      } else if (state.bootstrapFailed) {
        lead = 'Retry the venue load or log out and back in.';
      } else if (hasSingleVenue && selectedVenueId > 0) {
        lead = 'Opening the only active venue for this device.';
      }
      els.venueOverlayLead.textContent = lead;
    }

    if (els.venueOverlayStatus) {
      let message = 'Venue selection is required before using the console.';
      let isError = false;

      if (state.bootstrapBusy) {
        message = 'Loading venues…';
      } else if (state.bootstrapFailed) {
        message = state.bootstrapErrorMessage || 'Could not load venues. Retry or log out and back in.';
        isError = true;
      } else if (hasSingleVenue && selectedVenueId > 0) {
        message = 'Opening the only active venue for this device.';
      }

      els.venueOverlayStatus.textContent = message;
      els.venueOverlayStatus.classList.remove('is-error', 'is-ok');
      if (isError) {
        els.venueOverlayStatus.classList.add('is-error');
      }
    }

    const showPicker = !state.bootstrapBusy && !state.bootstrapFailed && hasSelectableVenues;
    if (els.venueOverlayLabel) {
      els.venueOverlayLabel.hidden = !showPicker;
    }
    if (els.venueOverlaySelect) {
      els.venueOverlaySelect.hidden = !showPicker;
      els.venueOverlaySelect.disabled = !showPicker || state.bootstrapBusy;
    }
    if (els.venueOverlayContinue) {
      els.venueOverlayContinue.hidden = !showPicker;
      els.venueOverlayContinue.disabled = !showPicker || !(selectedVenueId > 0) || state.bootstrapBusy;
    }
    if (els.venueRetry) {
      els.venueRetry.hidden = !state.bootstrapFailed;
      els.venueRetry.disabled = state.bootstrapBusy;
    }
  }


  function setVenueGateOpen(open) {
    let locked = !!open;
    if (!state.bootstrapBusy && !state.bootstrapFailed && locked && ensureSingleVenueSelected()) {
      locked = false;
    }

    if (locked) {
      closeMemberLookupTour();
      clearMemberLookupState({ preserveQuery: false });
      closeScanner({ reason: 'VENUE_REQUIRED', source: 'route_guard' });
    }

    if (els.venueOverlay) {
      els.venueOverlay.hidden = !locked;
    }
    updateVenueOverlayState();

    if (els.app) {
      els.app.classList.toggle('is-venue-locked', locked);
    }

    if (els.callStaff) {
      els.callStaff.disabled = locked || !isAlertStaffEnabled() || !config.caps?.sendAlerts;
      els.callStaff.classList.toggle('is-disabled', els.callStaff.disabled);
    }

    const buttonsToDisable = [
      els.refreshEvents,
      els.loadAttendees,
      els.ticketScanCamera,
      els.ticketSubmit,
      els.ticketSubmitAll,
      els.idScanCamera,
      els.idProcess,
      els.idRetryLog,
      els.idAddMember,
      els.idNotFoundCancel,
      els.startShift,
      els.endShift,
      els.alertSend
    ];

    buttonsToDisable.forEach((button) => {
      if (!button) {
        return;
      }
      button.disabled = locked;
    });

    if (els.ticketScan) {
      els.ticketScan.disabled = locked;
    }

    syncTicketSubmitAllButton();

    if (els.idPayload) {
      els.idPayload.disabled = locked;
    }
    if (els.idAdvanced) {
      els.idAdvanced.classList.toggle('is-disabled', locked);
    }

    if (els.alertPreset) {
      els.alertPreset.disabled = locked;
    }

    if (els.alertMessage) {
      els.alertMessage.disabled = locked;
    }

    if (els.alertUrgency) {
      els.alertUrgency.disabled = locked;
    }

    syncMemberLookupAvailability('venue_gate');
  }

  function enforceVenueGate() {
    if (state.bootstrapBusy || state.bootstrapFailed) {
      setVenueGateOpen(true);
      syncPresenceActionAvailability();
      return 0;
    }

    if (ensureSingleVenueSelected()) {
      return getVenueId(false);
    }

    let venueId = 0;
    try {
      venueId = getVenueId(false);
    } catch (_error) {
      venueId = 0;
    }

    setVenueGateOpen(!(venueId > 0));
    syncPresenceActionAvailability();
    return venueId;
  }
  async function api(path, options = {}) {
    const url = `${config.restRoot}${path}`;
    const isFormData = !!options.formData;
    const fetchOptions = {
      method: options.method || 'GET',
      credentials: 'same-origin',
      headers: {
        'X-WP-Nonce': config.nonce,
        Accept: 'application/json'
      }
    };

    if (options.body !== undefined) {
      if (isFormData) {
        fetchOptions.body = options.body;
      } else {
        fetchOptions.headers['Content-Type'] = 'application/json';
        fetchOptions.body = JSON.stringify(options.body);
      }
    }

    const controller = new AbortController();
    const timeoutMs = Number.isFinite(options.timeoutMs) ? options.timeoutMs : 12000;
    const timer = window.setTimeout(() => controller.abort(), timeoutMs);
    fetchOptions.signal = controller.signal;

    let response;
    try {
      response = await fetch(url, fetchOptions);
    } catch (error) {
      if (error && error.name === 'AbortError') {
        const wrapped = new Error('Request timed out.');
        wrapped.code = 'request_timeout';
        wrapped.original = error;
        throw normalizeUiError(wrapped);
      }
      const wrapped = new Error('Network unavailable.');
      wrapped.code = 'network_unavailable';
      wrapped.original = error;
      throw normalizeUiError(wrapped);
    } finally {
      window.clearTimeout(timer);
    }

    let payload = null;
    try {
      payload = await response.json();
    } catch (_error) {
      payload = null;
    }

    if (!response.ok || !payload || payload.ok === false) {
      const message = payload?.error?.message || `Request failed (${response.status})`;
      const error = new Error(message);
      error.code = payload?.error?.code || 'request_failed';
      error.status = response.status;
      error.payload = payload;
      error.rawMessage = message;
      throw normalizeUiError(error);
    }

    if (payload?.data && typeof payload.data === 'object') {
      applySiteTimePayload(payload.data);
    }
    if (!options.skipTimeSync) {
      maybeScheduleSiteTimeSync('api');
    }

    return payload.data;
  }

  function formatUploadBytes(bytes) {
    const size = Number(bytes || 0);
    if (!(size > 0)) {
      return '0 B';
    }
    if (size < 1024) {
      return `${size} B`;
    }

    const units = ['KB', 'MB', 'GB'];
    let value = size / 1024;
    let index = 0;
    while (value >= 1024 && index < units.length - 1) {
      value /= 1024;
      index += 1;
    }

    const decimals = value >= 100 ? 0 : (value >= 10 ? 1 : 2);
    return `${value.toFixed(decimals)} ${units[index]}`;
  }

  function replaceUploadExtension(filename, nextExtension) {
    const safeName = String(filename || 'upload').trim() || 'upload';
    const base = safeName.replace(/\.[^.]+$/, '');
    return `${base}.${nextExtension}`;
  }

  function supportsUploadCanvasMimeType(mimeType) {
    try {
      const canvas = document.createElement('canvas');
      return canvas.toDataURL(mimeType).indexOf(`data:${mimeType}`) === 0;
    } catch (_error) {
      return false;
    }
  }

  async function loadUploadImageSource(file) {
    if (typeof window.createImageBitmap === 'function') {
      try {
        const bitmap = await window.createImageBitmap(file, { imageOrientation: 'from-image' });
        return {
          source: bitmap,
          width: bitmap.width,
          height: bitmap.height,
          cleanup: () => {
            if (typeof bitmap.close === 'function') {
              bitmap.close();
            }
          }
        };
      } catch (_error) {
        try {
          const bitmap = await window.createImageBitmap(file);
          return {
            source: bitmap,
            width: bitmap.width,
            height: bitmap.height,
            cleanup: () => {
              if (typeof bitmap.close === 'function') {
                bitmap.close();
              }
            }
          };
        } catch (_ignored) {
          /* fall through */
        }
      }
    }

    const objectUrl = window.URL.createObjectURL(file);
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        resolve({
          source: image,
          width: image.naturalWidth || image.width,
          height: image.naturalHeight || image.height,
          cleanup: () => window.URL.revokeObjectURL(objectUrl)
        });
      };
      image.onerror = () => {
        window.URL.revokeObjectURL(objectUrl);
        reject(new Error('image_load_failed'));
      };
      image.src = objectUrl;
    });
  }

  function canvasToUploadBlob(canvas, mimeType, quality) {
    return new Promise((resolve, reject) => {
      if (typeof canvas.toBlob !== 'function') {
        reject(new Error('canvas_blob_unsupported'));
        return;
      }

      canvas.toBlob((blob) => {
        if (blob) {
          resolve(blob);
          return;
        }
        reject(new Error('canvas_blob_failed'));
      }, mimeType, quality);
    });
  }

  async function optimizePhotoUpload(file, options = {}) {
    const loaded = await loadUploadImageSource(file);
    try {
      const maxDimension = Math.max(640, Number(options.maxDimension || 1280));
      const quality = Math.max(0.6, Math.min(0.92, Number(options.quality || 0.72)));
      const longestSide = Math.max(Number(loaded.width || 0), Number(loaded.height || 0), 1);
      const scale = Math.min(1, maxDimension / longestSide);
      const targetWidth = Math.max(1, Math.round((Number(loaded.width || 1)) * scale));
      const targetHeight = Math.max(1, Math.round((Number(loaded.height || 1)) * scale));
      const outputType = supportsUploadCanvasMimeType('image/webp') ? 'image/webp' : 'image/jpeg';
      const outputExtension = outputType === 'image/webp' ? 'webp' : 'jpg';
      const canvas = document.createElement('canvas');
      canvas.width = targetWidth;
      canvas.height = targetHeight;

      const context = canvas.getContext('2d', { alpha: outputType !== 'image/jpeg' });
      if (!context) {
        throw new Error('canvas_context_failed');
      }

      if (outputType === 'image/jpeg') {
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, targetWidth, targetHeight);
      }
      context.drawImage(loaded.source, 0, 0, targetWidth, targetHeight);

      const blob = await canvasToUploadBlob(canvas, outputType, quality);
      return {
        blob,
        filename: replaceUploadExtension(file.name, outputExtension),
        originalSize: file.size,
        outputSize: blob.size,
        usedFallback: false
      };
    } finally {
      if (loaded && typeof loaded.cleanup === 'function') {
        loaded.cleanup();
      }
    }
  }

  function describePhotoCompression(uploadMeta) {
    if (!uploadMeta || !(uploadMeta.originalSize > 0)) {
      return '';
    }
    return `${formatUploadBytes(uploadMeta.originalSize)} -> ${formatUploadBytes(uploadMeta.outputSize)}`;
  }

  function buildPhotoStageMessage(stage, uploadMeta) {
    const detail = describePhotoCompression(uploadMeta);
    if (!detail || !config.debugMode) {
      return uploadMeta && uploadMeta.usedFallback
        ? `${stage} (original file fallback)`
        : stage;
    }
    return `${stage} (${detail})`;
  }

  function mapProfilePhotoUploadMessage(error) {
    const code = String(error?.code || '').trim().toLowerCase();
    if (code === 'profile_photo_too_large' || code === 'file_too_large') {
      return 'Image too large';
    }
    if (code === 'profile_photo_manager_only') {
      return 'Only managers can upload profile photos right now.';
    }
    if (code === 'profile_photo_disabled') {
      return 'Profile photo uploads are disabled in settings.';
    }
    if (code === 'profile_photo_process_failed' || code === 'profile_photo_upload_failed' || code === 'profile_photo_attachment_failed') {
      return 'Could not process image';
    }
    if (code === 'request_timeout' || code === 'network_timeout') {
      return 'Network timeout';
    }
    return String(error?.message || 'Could not process image');
  }

  function renderEventOptions(events) {
    if (!els.eventSelect) {
      return;
    }

    els.eventSelect.innerHTML = '<option value="">Select an event</option>';
    events.forEach((event) => {
      const option = document.createElement('option');
      option.value = String(event.id);
      option.dataset.source = event.source || '';
      const optionLabel = buildEventOptionLabel(event);
      option.textContent = optionLabel;
      option.title = optionLabel;
      els.eventSelect.appendChild(option);
    });
  }

  async function refreshEvents(options = {}) {
    if (!config.caps?.scanTickets) {
      return;
    }

    if (isLoginRequired() && !state.onDuty) {
      throw new Error('Log in to view events.');
    }
    if (state.eventsLoading) {
      return;
    }

    clearTicketNotice();
    const selectionMode = options && options.selectionMode === 'login-default'
      ? 'login-default'
      : 'preserve';

    let venueId = 0;
    try {
      venueId = getVenueId(false);
    } catch (_error) {
      venueId = 0;
    }

    const previousSelected = state.selectedEventId > 0 ? String(state.selectedEventId) : String(els.eventSelect?.value || '');
    setEventsLoading(true);

    try {
      const data = await api(`/ticket/events?venue_id=${venueId}`);
      const items = dedupeEvents(data.items || []);
      const previousRuntimeStates = {};
      (Array.isArray(state.ticketEvents) ? state.ticketEvents : []).forEach((event) => {
        const eventId = parsePositiveInt(event?.id);
        if (eventId > 0) {
          previousRuntimeStates[eventId] = getEventRuntimeWindow(event).state;
        }
      });
      state.previousEventRuntimeStates = previousRuntimeStates;
      state.ticketEvents = items;
      renderEventOptions(items);
      const selectedEventId = resolveTicketEventSelection(items, previousSelected, venueId, selectionMode);
      if (selectedEventId > 0) {
        selectTicketEventById(selectedEventId, { persist: true, venueId });
      } else {
        state.selectedEventId = 0;
        state.selectedEventSource = '';
        state.ticketEventConfirmedId = 0;
        state.ticketEventConfirmedAt = 0;
        state.ticketEventConfirmationSource = '';
        resetAttendeeAutoRefreshState();
        persistEventId(venueId, 0);
        renderTicketMeta();
        renderAttendeeLookup();
      }

      if (items.length === 0) {
        setTicketStatus('No events available for scanning for this venue.', 'error');
      } else {
        const todayYmd = getSiteTodayYmd();
        const sameDayCount = todayYmd ? items.filter((event) => getEventStartYmd(event) === todayYmd).length : 0;
        if (sameDayCount > 1) {
          setTicketStatus('Multiple events are available today. Confirm the correct active event before scanning.', 'info');
        } else if (isSelectedTicketEventConfirmed()) {
          setTicketStatus(`${items.length} event${items.length === 1 ? '' : 's'} available. Active event confirmed.`, 'info');
        } else {
          setTicketStatus(`${items.length} event${items.length === 1 ? '' : 's'} available. Confirm active event before scanning.`, 'info');
        }
      }

      maybeAutoRefreshAttendees({ force: true }).catch(() => {});
    } finally {
      setEventsLoading(false);
    }
  }

  function getSelectedEvent() {
    const eventId = Number.parseInt(String(els.eventSelect?.value || '0'), 10);
    if (Number.isNaN(eventId) || eventId <= 0) {
      return null;
    }

    const option = els.eventSelect.options[els.eventSelect.selectedIndex];
    return {
      id: eventId,
      source: option?.dataset?.source || ''
    };
  }

  function selectTicketEventById(eventId, options = {}) {
    const safeEventId = Number.parseInt(String(eventId || '0'), 10);
    if (!els.eventSelect || Number.isNaN(safeEventId) || safeEventId <= 0) {
      return false;
    }

    const targetValue = String(safeEventId);
    const option = Array.from(els.eventSelect.options).find((item) => item.value === targetValue);
    if (!option) {
      return false;
    }

    const nextSource = option.dataset?.source || '';
    const eventChanged = state.selectedEventId !== safeEventId || state.selectedEventSource !== nextSource;
    els.eventSelect.value = targetValue;
    state.selectedEventId = safeEventId;
    state.selectedEventSource = nextSource;
    if (eventChanged) {
      resetAttendeeAutoRefreshState();
    }
    let venueId = parsePositiveInt(options.venueId);
    if (!(venueId > 0)) {
      try {
        venueId = getVenueId(false);
      } catch (_error) {
        venueId = 0;
      }
    }
    if (state.ticketEventConfirmedId !== safeEventId) {
      syncPersistedEventConfirmation(venueId, safeEventId);
    }
    if (options.persist) {
      persistEventId(venueId, safeEventId);
    }
    renderTicketMeta();
    renderAttendeeLookup();
    if (isSelectedTicketEventConfirmed()) {
      maybeAutoRefreshAttendees({ force: true }).catch(() => {});
    } else {
      scheduleAttendeeAutoRefresh('event-selection');
    }
    return true;
  }

  async function confirmSelectedTicketEvent() {
    const selected = getSelectedEvent();
    const selectedEvent = getSelectedEventRecord();
    if (!selected || !selectedEvent) {
      setTicketStatus('Select an event before scanning.', 'error');
      return false;
    }

    let venueId = 0;
    try {
      venueId = getVenueId(true);
    } catch (error) {
      setTicketStatus(error.message, 'error');
      return false;
    }

    state.ticketEventConfirmedId = selected.id;
    state.ticketEventConfirmedAt = Date.now();
    state.ticketEventConfirmationSource = 'operator';
    persistEventId(venueId, selected.id);
    persistConfirmedEventId(venueId, selected.id);
    renderTicketMeta();
    clearTicketNotice();

    try {
      await loadAttendeesToCache({ silent: false });
    } catch (error) {
      setTicketStatus(`Active event confirmed, but attendee cache could not refresh: ${error.message}`, 'error');
      renderTicketMeta();
      return true;
    }

    setTicketStatus('Active event confirmed. Scanner is ready.', 'info');
    renderTicketMeta();
    return true;
  }

  function focusEventPickerForChange() {
    state.ticketEventConfirmedId = 0;
    state.ticketEventConfirmedAt = 0;
    state.ticketEventConfirmationSource = '';

    let venueId = 0;
    try {
      venueId = getVenueId(false);
    } catch (_error) {
      venueId = 0;
    }
    if (venueId > 0) {
      persistConfirmedEventId(venueId, 0);
    }

    scheduleAttendeeAutoRefresh('change-event');
    renderTicketMeta();
    setTicketStatus('Choose the correct event, then confirm before scanning.', 'info');
    if (els.eventSelect && typeof els.eventSelect.focus === 'function') {
      els.eventSelect.focus();
    }
  }

  function requireConfirmedTicketEvent() {
    if (isSelectedTicketEventConfirmed()) {
      return true;
    }
    const selected = getSelectedEvent();
    if (!selected) {
      setTicketStatus('Select an event before scanning.', 'error');
    } else {
      setTicketStatus('Confirm the active event before scanning.', 'error');
    }
    renderTicketMeta();
    return false;
  }

  function scannerModeTitle(mode) {
    return mode === 'id' ? 'Scan ID' : 'Scan Ticket';
  }

  function scannerModeHint(mode) {
    if (mode === 'id') {
      return 'Hold ID steady 1-2 seconds. Keep barcode flat, no glare. Tip: tilt slightly to remove glare.';
    }
    return 'Center the QR code in the box. Hold steady.';
  }

  function scannerCoachingHint(mode) {
    if (mode === 'id') {
      return 'Hold steady 1-2 seconds. Keep barcode flat, no glare.';
    }
    return 'Move closer until QR fills the box. Hold steady.';
  }

  function scannerFormats(mode) {
    if (mode === 'id') {
      return {
        native: ['pdf417'],
        zxing: [window.ZXing?.BarcodeFormat?.PDF_417].filter((format) => typeof format !== 'undefined')
      };
    }

    return {
      native: ['qr_code'],
      zxing: [window.ZXing?.BarcodeFormat?.QR_CODE].filter((format) => typeof format !== 'undefined')
    };
  }

  function scannerScanInterval(mode) {
    return mode === 'id' ? 210 : 120;
  }

  function scannerRequiredStableCount(mode) {
    return mode === 'id' ? 2 : 1;
  }

  function clampNumber(value, min, max) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) {
      return min;
    }
    return Math.max(min, Math.min(max, parsed));
  }

  function isAppleMobileCameraDevice() {
    const ua = String(navigator.userAgent || '');
    const platform = String(navigator.platform || '');
    const maxTouchPoints = Number(navigator.maxTouchPoints || 0);
    return /iPhone|iPad|iPod/i.test(ua) || (/Mac/i.test(platform) && maxTouchPoints > 1);
  }

  function buildScannerVideoConstraints(facingMode, deviceId = '') {
    const safeFacing = facingMode === 'user' ? 'user' : 'environment';
    const constraints = {
      width: { ideal: 1920 },
      height: { ideal: 1080 },
      frameRate: { ideal: 30, max: 30 }
    };

    if (deviceId) {
      constraints.deviceId = { exact: deviceId };
      return constraints;
    }

    constraints.facingMode = { ideal: safeFacing };
    return constraints;
  }

  async function requestScannerStream(facingMode, deviceId = '') {
    const safeFacing = facingMode === 'user' ? 'user' : 'environment';
    const primary = {
      audio: false,
      video: buildScannerVideoConstraints(safeFacing, deviceId)
    };

    try {
      return await navigator.mediaDevices.getUserMedia(primary);
    } catch (error) {
      if (error?.name === 'NotAllowedError' || error?.name === 'SecurityError' || error?.name === 'PermissionDeniedError') {
        throw error;
      }

      if (deviceId) {
        return navigator.mediaDevices.getUserMedia({
          audio: false,
          video: { deviceId: { exact: deviceId } }
        });
      }

      return navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: safeFacing }
        }
      });
    }
  }

  function scoreScannerVideoDevice(device, facingMode, index) {
    const label = String(device?.label || '').trim().toLowerCase();
    const safeFacing = facingMode === 'user' ? 'user' : 'environment';
    let score = 0;

    if (safeFacing === 'user') {
      if (label.includes('front') || label.includes('facetime') || label.includes('selfie')) {
        score += 900;
      }
      if (label.includes('back') || label.includes('rear') || label.includes('world')) {
        score -= 900;
      }
      if (label.includes('continuity') || label.includes('desk') || label.includes('external')) {
        score -= 500;
      }
      if (!label && isAppleMobileCameraDevice() && index === 0) {
        score += 120;
      }
      return score;
    }

    if (label.includes('back') || label.includes('rear') || label.includes('world')) {
      score += 920;
    }
    if (label.includes('wide')) {
      score += 520;
    }
    if (label.includes('front') || label.includes('facetime') || label.includes('selfie')) {
      score -= 1200;
    }
    if (label.includes('ultra') || label.includes('0.5') || label.includes('macro')) {
      score -= 820;
    }
    if (label.includes('tele')) {
      score -= 240;
    }
    if (label.includes('continuity') || label.includes('desk') || label.includes('external')) {
      score -= 1200;
    }

    if (!label && isAppleMobileCameraDevice()) {
      if (index === 1) {
        score += 180;
      } else if (index === 0) {
        score -= 180;
      }
    }

    return score;
  }

  async function findPreferredScannerDeviceId(facingMode, currentTrack) {
    if (!navigator.mediaDevices || typeof navigator.mediaDevices.enumerateDevices !== 'function') {
      return '';
    }

    let devices = [];
    try {
      devices = await navigator.mediaDevices.enumerateDevices();
    } catch (_error) {
      return '';
    }

    const videoInputs = devices.filter((device) => device && device.kind === 'videoinput');
    if (videoInputs.length < 2) {
      return '';
    }

    const safeFacing = facingMode === 'user' ? 'user' : 'environment';
    const currentDeviceId = String(currentTrack?.getSettings?.().deviceId || '').trim();
    let currentScore = Number.NEGATIVE_INFINITY;
    let bestDeviceId = '';
    let bestScore = Number.NEGATIVE_INFINITY;

    videoInputs.forEach((device, index) => {
      const deviceId = String(device.deviceId || '').trim();
      if (!deviceId) {
        return;
      }

      const score = scoreScannerVideoDevice(device, safeFacing, index);
      if (deviceId === currentDeviceId) {
        currentScore = score;
      }
      if (score > bestScore) {
        bestScore = score;
        bestDeviceId = deviceId;
      }
    });

    if (!bestDeviceId || bestScore <= currentScore || bestScore < 100) {
      return '';
    }

    return bestDeviceId;
  }

  function loadExternalScript(src) {
    return new Promise((resolve, reject) => {
      const url = String(src || '').trim();
      if (!url) {
        reject(new Error('Missing script URL.'));
        return;
      }

      const existing = Array.from(document.getElementsByTagName('script')).find((node) => node.dataset?.vmsOpsSrc === url);
      if (existing) {
        if (existing.dataset?.vmsOpsLoaded === '1') {
          resolve();
          return;
        }
        existing.addEventListener('load', () => resolve(), { once: true });
        existing.addEventListener('error', () => reject(new Error(`Failed to load ${url}`)), { once: true });
        return;
      }

      const script = document.createElement('script');
      script.src = url;
      script.async = true;
      script.dataset.vmsOpsSrc = url;
      script.addEventListener('load', () => {
        script.dataset.vmsOpsLoaded = '1';
        resolve();
      }, { once: true });
      script.addEventListener('error', () => reject(new Error(`Failed to load ${url}`)), { once: true });
      document.head.appendChild(script);
    });
  }

  async function ensureZxingLoaded() {
    if (window.ZXing && window.ZXingBrowser) {
      return;
    }

    if (state.scannerZxingLoadingPromise) {
      await state.scannerZxingLoadingPromise;
      return;
    }

    const zxingLibrary = String(config.assets?.zxingLibrary || '').trim();
    const zxingBrowser = String(config.assets?.zxingBrowser || '').trim();
    if (!zxingLibrary || !zxingBrowser) {
      throw new Error('Scanner dependencies are not configured.');
    }

    state.scannerZxingLoadingPromise = loadExternalScript(zxingLibrary)
      .then(() => loadExternalScript(zxingBrowser))
      .then(() => {
        if (!window.ZXing || !window.ZXingBrowser) {
          throw new Error('Scanner dependencies failed to initialize.');
        }
      })
      .finally(() => {
        state.scannerZxingLoadingPromise = null;
      });

    await state.scannerZxingLoadingPromise;
  }

  function resetScannerStableReadState() {
    state.scannerStableValue = '';
    state.scannerStableCount = 0;
  }

  function setScannerStatus(status, tone = 'scan') {
    state.scannerStatusValue = String(status || '').trim();
    if (!els.scanStatus) {
      return;
    }

    els.scanStatus.textContent = state.scannerStatusValue;
    els.scanStatus.classList.remove('is-hold', 'is-success', 'is-error', 'is-warning');
    if (tone === 'hold') {
      els.scanStatus.classList.add('is-hold');
      return;
    }
    if (tone === 'success') {
      els.scanStatus.classList.add('is-success');
      return;
    }
    if (tone === 'warning') {
      els.scanStatus.classList.add('is-warning');
      return;
    }
    if (tone === 'error') {
      els.scanStatus.classList.add('is-error');
    }
  }

  function setScannerResultCard(headline, detail = '', tone = 'info') {
    if (!els.scanResult || !els.scanResultHeadline || !els.scanResultDetail) {
      return;
    }

    const safeHeadline = String(headline || '').trim();
    const safeDetail = String(detail || '').trim();
    const visible = safeHeadline !== '' || safeDetail !== '';

    els.scanResult.hidden = !visible;
    els.scanResult.classList.remove('is-info', 'is-success', 'is-warning', 'is-error');
    if (!visible) {
      els.scanResultHeadline.textContent = '';
      els.scanResultDetail.textContent = '';
      return;
    }

    els.scanResultHeadline.textContent = safeHeadline;
    els.scanResultDetail.textContent = safeDetail;
    els.scanResult.classList.add(
      tone === 'success' ? 'is-success' : (
        tone === 'warning' ? 'is-warning' : (
          tone === 'error' ? 'is-error' : 'is-info'
        )
      )
    );
  }

  function playScannerSuccessSignal() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (typeof AudioCtx === 'function') {
      try {
        if (!state.scannerSuccessAudioCtx) {
          state.scannerSuccessAudioCtx = new AudioCtx();
        }
        const ctx = state.scannerSuccessAudioCtx;
        if (ctx.state === 'suspended') {
          ctx.resume().catch(() => {});
        }

        const oscillator = ctx.createOscillator();
        const gain = ctx.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.value = 1120;
        gain.gain.value = 0.0001;
        oscillator.connect(gain);
        gain.connect(ctx.destination);
        const now = ctx.currentTime;
        gain.gain.exponentialRampToValueAtTime(0.14, now + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.13);
        oscillator.start(now);
        oscillator.stop(now + 0.14);
      } catch (_error) {
        // no-op
      }
    }

    if (typeof navigator.vibrate === 'function') {
      navigator.vibrate(100);
    }
  }

  function playScannerErrorSignal(kind = 'error') {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (typeof AudioCtx === 'function') {
      try {
        if (!state.scannerSuccessAudioCtx) {
          state.scannerSuccessAudioCtx = new AudioCtx();
        }
        const ctx = state.scannerSuccessAudioCtx;
        if (ctx.state === 'suspended') {
          ctx.resume().catch(() => {});
        }

        const gain = ctx.createGain();
        const noteOne = ctx.createOscillator();
        const noteTwo = ctx.createOscillator();
        const now = ctx.currentTime;
        const isWarning = kind === 'warning';

        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.16, now + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + (isWarning ? 0.24 : 0.34));
        gain.connect(ctx.destination);

        noteOne.type = 'square';
        noteOne.frequency.setValueAtTime(isWarning ? 410 : 280, now);
        noteOne.connect(gain);
        noteOne.start(now);
        noteOne.stop(now + 0.12);

        noteTwo.type = 'square';
        noteTwo.frequency.setValueAtTime(isWarning ? 360 : 220, now + 0.14);
        noteTwo.connect(gain);
        noteTwo.start(now + 0.14);
        noteTwo.stop(now + (isWarning ? 0.24 : 0.34));
      } catch (_error) {
        // no-op
      }
    }

    if (typeof navigator.vibrate === 'function') {
      navigator.vibrate(kind === 'warning' ? [55, 25, 55] : [120, 40, 120]);
    }
  }

  function playTicketCheckinChime() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (typeof AudioCtx === 'function') {
      try {
        if (!state.scannerSuccessAudioCtx) {
          state.scannerSuccessAudioCtx = new AudioCtx();
        }
        const ctx = state.scannerSuccessAudioCtx;
        if (ctx.state === 'suspended') {
          ctx.resume().catch(() => {});
        }

        const gain = ctx.createGain();
        const noteOne = ctx.createOscillator();
        const noteTwo = ctx.createOscillator();
        const now = ctx.currentTime;

        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.18, now + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.12, now + 0.14);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.36);
        gain.connect(ctx.destination);

        noteOne.type = 'triangle';
        noteOne.frequency.setValueAtTime(740, now);
        noteOne.connect(gain);
        noteOne.start(now);
        noteOne.stop(now + 0.18);

        noteTwo.type = 'triangle';
        noteTwo.frequency.setValueAtTime(988, now + 0.12);
        noteTwo.connect(gain);
        noteTwo.start(now + 0.12);
        noteTwo.stop(now + 0.36);
      } catch (_error) {
        // no-op
      }
    }

    if (typeof navigator.vibrate === 'function') {
      navigator.vibrate([35, 25, 60]);
    }
  }

  function stopScannerCoachingTimer() {
    if (state.scannerScanFeedbackTimer) {
      window.clearTimeout(state.scannerScanFeedbackTimer);
      state.scannerScanFeedbackTimer = null;
    }
    if (state.scannerLowLightHintTimer) {
      window.clearTimeout(state.scannerLowLightHintTimer);
      state.scannerLowLightHintTimer = null;
    }
  }

  function startScannerCoachingTimer(mode) {
    stopScannerCoachingTimer();
    state.scannerScanFeedbackTimer = window.setTimeout(() => {
      if (!state.scannerActive) {
        return;
      }
      if (mode === 'id') {
        setScannerStatus('HOLD STILL...', 'hold');
        setScannerResultCard('Reading ID', 'Hold steady. Keep the barcode flat and avoid glare.', 'info');
      }
      if (els.scanHint) {
        els.scanHint.textContent = scannerCoachingHint(mode);
      }
      setFeedback(els.scanFeedback, 'Hold steady...');
    }, mode === 'id' ? 800 : 1400);

    state.scannerLowLightHintTimer = window.setTimeout(() => {
      if (!state.scannerActive || state.scannerBusy || state.scannerMode !== mode) {
        return;
      }

      if (els.scanHint) {
        if (state.scannerTorchSupported || state.scannerZoomSupported) {
          els.scanHint.textContent = 'Low light detected or scan is taking longer than usual. Try turning on the light, moving closer, or increasing zoom.';
        } else {
          els.scanHint.textContent = 'Low light detected or scan is taking longer than usual. Try moving closer, improving lighting, and holding steady.';
        }
      }
      setFeedback(els.scanFeedback, 'Scanning is taking longer than usual.');
    }, mode === 'id' ? 4200 : 3600);
  }

  function setScannerTorchButtonVisible(visible) {
    if (!els.scanTorch) {
      return;
    }
    els.scanTorch.hidden = !visible;
    els.scanTorch.disabled = !visible;
  }

  function setScannerZoomButtonsVisible(visible) {
    if (els.scanZoomIn) {
      els.scanZoomIn.hidden = !visible;
      els.scanZoomIn.disabled = !visible;
    }
    if (els.scanZoomOut) {
      els.scanZoomOut.hidden = !visible;
      els.scanZoomOut.disabled = !visible;
    }
    if (els.scanZoomReset) {
      els.scanZoomReset.hidden = !visible;
      els.scanZoomReset.disabled = !visible;
    }
  }

  function updateScannerTorchButton() {
    if (!els.scanTorch) {
      return;
    }
    els.scanTorch.textContent = state.scannerTorchOn ? 'Light Off' : 'Light On';
    els.scanTorch.classList.toggle('is-active', state.scannerTorchOn);
  }

  function updateScannerZoomButtons() {
    if (!state.scannerZoomSupported) {
      setScannerZoomButtonsVisible(false);
      return;
    }

    setScannerZoomButtonsVisible(true);

    if (els.scanZoomIn) {
      els.scanZoomIn.disabled = state.scannerZoomValue >= (state.scannerZoomMax - (state.scannerZoomStep / 2));
    }
    if (els.scanZoomOut) {
      els.scanZoomOut.disabled = state.scannerZoomValue <= (state.scannerZoomMin + (state.scannerZoomStep / 2));
    }
    if (els.scanZoomReset) {
      const normalZoom = getScannerNormalZoomValue();
      const currentZoom = Number.isFinite(Number(state.scannerZoomValue)) ? Number(state.scannerZoomValue) : normalZoom;
      els.scanZoomReset.textContent = `Zoom ${currentZoom.toFixed(1)}x`;
      els.scanZoomReset.disabled = Math.abs(state.scannerZoomValue - normalZoom) <= (state.scannerZoomStep / 2);
    }
  }

  function rememberActiveScannerDevice(mode) {
    const deviceId = String(state.scannerTrack?.getSettings?.().deviceId || '').trim();
    updateScannerPrefs(mode, {
      facingMode: state.scannerFacingMode === 'user' ? 'user' : 'environment',
      deviceId
    });
  }

  function applyScannerViewportMode(mode) {
    const safeMode = mode === 'id' ? 'id' : 'ticket';
    if (els.scanViewport) {
      els.scanViewport.classList.toggle('is-mode-id', safeMode === 'id');
      els.scanViewport.classList.toggle('is-mode-ticket', safeMode !== 'id');
    }
    if (els.scanMask) {
      els.scanMask.dataset.mode = safeMode;
    }
    if (els.scanTarget) {
      els.scanTarget.dataset.mode = safeMode;
    }
  }

  function getScanTargetRectForViewport(mode, viewportWidth, viewportHeight) {
    const width = Math.max(0, Number(viewportWidth || 0));
    const height = Math.max(0, Number(viewportHeight || 0));

    if (!(width > 0) || !(height > 0)) {
      return null;
    }

    if (mode === 'id') {
      const targetWidth = Math.min(width * 0.9, 520);
      const targetHeight = Math.min(Math.max(height * 0.22, 96), 140);
      const x = Math.max(0, (width - targetWidth) / 2);
      const yCenter = height * 0.65;
      const y = Math.min(Math.max(0, yCenter - (targetHeight / 2)), Math.max(0, height - targetHeight));
      return { x, y, width: targetWidth, height: targetHeight };
    }

    const targetSize = Math.min(width * 0.7, 320, height * 0.72);
    const x = Math.max(0, (width - targetSize) / 2);
    const y = Math.max(0, (height - targetSize) / 2);
    return { x, y, width: targetSize, height: targetSize };
  }

  function getScannerRoiRect(mode) {
    const video = els.scanVideo;
    const viewport = els.scanViewport;
    if (!video || !viewport || video.videoWidth <= 0 || video.videoHeight <= 0) {
      return null;
    }

    const target = getScanTargetRectForViewport(mode, viewport.clientWidth, viewport.clientHeight);
    if (!target) {
      return null;
    }

    const viewportWidth = Math.max(1, viewport.clientWidth);
    const viewportHeight = Math.max(1, viewport.clientHeight);
    const videoWidth = Math.max(1, video.videoWidth);
    const videoHeight = Math.max(1, video.videoHeight);

    const scale = Math.max(viewportWidth / videoWidth, viewportHeight / videoHeight);
    const renderedWidth = videoWidth * scale;
    const renderedHeight = videoHeight * scale;
    const offsetX = (viewportWidth - renderedWidth) / 2;
    const offsetY = (viewportHeight - renderedHeight) / 2;

    const x = clampNumber(Math.floor((target.x - offsetX) / scale), 0, videoWidth - 1);
    const y = clampNumber(Math.floor((target.y - offsetY) / scale), 0, videoHeight - 1);
    const width = clampNumber(Math.ceil(target.width / scale), 1, videoWidth - x);
    const height = clampNumber(Math.ceil(target.height / scale), 1, videoHeight - y);

    if (width < 8 || height < 8) {
      return null;
    }

    return {
      x: Math.floor(x),
      y: Math.floor(y),
      width: Math.floor(width),
      height: Math.floor(height)
    };
  }

  async function applyScannerTorchState(enabled, silent = false) {
    const track = state.scannerTrack;
    if (!track || !state.scannerTorchSupported) {
      return false;
    }

    try {
      await track.applyConstraints({ advanced: [{ torch: !!enabled }] });
      state.scannerTorchOn = !!enabled;
      updateScannerPrefs(state.scannerMode || 'ticket', {
        facingMode: state.scannerFacingMode === 'user' ? 'user' : 'environment',
        torchOn: state.scannerTorchOn
      });
      updateScannerTorchButton();
      return true;
    } catch (_error) {
      if (!silent) {
        setFeedback(els.scanFeedback, 'Torch is unavailable on this camera.', true);
      }
      return false;
    }
  }

  function getScannerNormalZoomValue() {
    if (!state.scannerZoomSupported) {
      return 1;
    }
    if (state.scannerZoomMin <= 1 && state.scannerZoomMax >= 1) {
      return 1;
    }
    return state.scannerZoomMin;
  }

  async function applyScannerZoomValue(value, silent = false) {
    const track = state.scannerTrack;
    if (!track || !state.scannerZoomSupported) {
      return false;
    }

    const targetValue = clampNumber(value, state.scannerZoomMin, state.scannerZoomMax);
    try {
      await track.applyConstraints({ advanced: [{ zoom: targetValue }] });
      state.scannerZoomValue = targetValue;
      updateScannerPrefs(state.scannerMode || 'ticket', {
        facingMode: state.scannerFacingMode === 'user' ? 'user' : 'environment',
        zoomValue: targetValue
      });
      updateScannerZoomButtons();
      return true;
    } catch (_error) {
      if (!silent) {
        setFeedback(els.scanFeedback, 'Zoom controls are unavailable on this camera.', true);
      }
      return false;
    }
  }

  async function bumpScannerZoom(delta) {
    if (!state.scannerZoomSupported) {
      return;
    }
    const direction = Number(delta) > 0 ? 1 : -1;
    const nextValue = state.scannerZoomValue + (direction * state.scannerZoomStep);
    await applyScannerZoomValue(nextValue);
  }

  async function resetScannerZoom() {
    if (!state.scannerZoomSupported) {
      return;
    }
    await applyScannerZoomValue(getScannerNormalZoomValue());
  }

  async function analyzeScannerTrackCapabilities(mode) {
    const scannerMode = getScannerModeKey(mode);
    const savedPrefs = getScannerPrefs(scannerMode);
    state.scannerTrack = state.scannerStream?.getVideoTracks?.()[0] || null;
    state.scannerCapabilities = null;
    state.scannerTorchSupported = false;
    state.scannerTorchOn = false;
    state.scannerZoomSupported = false;
    state.scannerZoomMin = 1;
    state.scannerZoomMax = 1;
    state.scannerZoomStep = 0.1;
    state.scannerZoomValue = 1;

    setScannerTorchButtonVisible(false);
    setScannerZoomButtonsVisible(false);
    updateScannerTorchButton();

    const track = state.scannerTrack;
    if (!track) {
      return;
    }

    let capabilities = null;
    try {
      capabilities = typeof track.getCapabilities === 'function' ? track.getCapabilities() : null;
    } catch (_error) {
      capabilities = null;
    }

    state.scannerCapabilities = capabilities || null;

    const focusModes = Array.isArray(capabilities?.focusMode) ? capabilities.focusMode : [];
    if (focusModes.includes('continuous') || (mode === 'id' && focusModes.includes('single-shot'))) {
      try {
        await track.applyConstraints({
          advanced: [{
            focusMode: focusModes.includes('continuous') ? 'continuous' : 'single-shot'
          }]
        });
      } catch (_error) {
        // Focus tuning is optional and device-dependent.
      }
    }

    const torchSupported = Boolean(capabilities && capabilities.torch);
    state.scannerTorchSupported = torchSupported;
    setScannerTorchButtonVisible(torchSupported);

    const zoomCaps = capabilities && capabilities.zoom ? capabilities.zoom : null;
    const zoomSupported = Boolean(
      zoomCaps
      && Number.isFinite(zoomCaps.min)
      && Number.isFinite(zoomCaps.max)
      && zoomCaps.max > zoomCaps.min
    );

    state.scannerZoomSupported = zoomSupported;
    if (zoomSupported) {
      state.scannerZoomMin = Number(zoomCaps.min);
      state.scannerZoomMax = Number(zoomCaps.max);
      const zoomRange = Math.max(0, state.scannerZoomMax - state.scannerZoomMin);
      state.scannerZoomStep = Number.isFinite(Number(zoomCaps.step)) && Number(zoomCaps.step) > 0
        ? Number(zoomCaps.step)
        : Math.max(zoomRange * 0.08, 0.05);

      const settingsZoom = Number(track.getSettings?.().zoom);
      state.scannerZoomValue = Number.isFinite(settingsZoom)
        ? clampNumber(settingsZoom, state.scannerZoomMin, state.scannerZoomMax)
        : getScannerNormalZoomValue();

      const preferredZoom = Number.isFinite(Number(savedPrefs.zoomValue)) && Number(savedPrefs.zoomValue) > 0
        ? clampNumber(savedPrefs.zoomValue, state.scannerZoomMin, state.scannerZoomMax)
        : getScannerNormalZoomValue();
      await applyScannerZoomValue(preferredZoom, true);
    }

    if (torchSupported && savedPrefs.torchOn) {
      await applyScannerTorchState(true, true);
    }

    rememberActiveScannerDevice(scannerMode);
    updateScannerTorchButton();
    updateScannerZoomButtons();
  }

  function stopScannerDetection() {
    state.scannerLoopToken += 1;
    stopScannerCoachingTimer();

    if (state.scannerLoopTimer) {
      window.clearTimeout(state.scannerLoopTimer);
      state.scannerLoopTimer = null;
    }

    try {
      state.scannerZxingControls?.stop?.();
    } catch (_error) {
      // no-op
    }

    try {
      state.scannerZxingReader?.reset?.();
    } catch (_error) {
      // no-op
    }

    state.scannerZxingControls = null;
    state.scannerZxingReader = null;
  }

  function clearScannerResumeTimer() {
    if (state.scannerResumeTimer) {
      window.clearTimeout(state.scannerResumeTimer);
      state.scannerResumeTimer = null;
    }
  }

  function resumeActiveScannerLoop() {
    if (!state.scannerMode || !state.scannerStream || !els.scanModal || els.scanModal.hidden) {
      return;
    }

    state.scannerActive = true;
    state.scannerBusy = false;
    resetScannerStableReadState();
    setScannerStatus('SCANNING...');
    setScannerResultCard('', '');
    setFeedback(els.scanFeedback, 'Ready for next scan.');
    startScannerDetectionLoop(state.scannerMode).catch((error) => {
      state.scannerActive = false;
      stopScannerDetection();
      stopScannerStream();
      setFeedback(els.scanFeedback, describeCameraError(error), true);
    }).finally(() => {
      if (state.scannerActive) {
        startScannerCoachingTimer(state.scannerMode);
      }
    });
  }

  function scheduleScannerResume(delay = 1200) {
    clearScannerResumeTimer();
    state.scannerResumeTimer = window.setTimeout(() => {
      state.scannerResumeTimer = null;
      resumeActiveScannerLoop();
    }, Math.max(250, Number(delay) || 1200));
  }

  function streamHasLiveVideoTrack(stream) {
    return !!stream?.getVideoTracks?.().some((track) => track && track.readyState === 'live');
  }

  function clearScannerWarmStream() {
    const stream = state.scannerWarmStream;
    if (stream && typeof stream.getTracks === 'function') {
      stream.getTracks().forEach((streamTrack) => {
        try {
          streamTrack.stop();
        } catch (_error) {
          // no-op
        }
      });
    }
    state.scannerWarmStream = null;
    state.scannerWarmFacingMode = '';
    state.scannerWarmAt = 0;
  }

  function takeScannerWarmStream(facingMode) {
    const safeFacing = facingMode === 'user' ? 'user' : 'environment';
    if (!state.scannerWarmStream || state.scannerWarmFacingMode !== safeFacing || !streamHasLiveVideoTrack(state.scannerWarmStream)) {
      clearScannerWarmStream();
      return null;
    }

    const stream = state.scannerWarmStream;
    state.scannerWarmStream = null;
    state.scannerWarmFacingMode = '';
    state.scannerWarmAt = 0;
    return stream;
  }

  function resetScannerTrackState() {
    state.scannerTrack = null;
    state.scannerCapabilities = null;
    state.scannerTorchSupported = false;
    state.scannerTorchOn = false;
    state.scannerZoomSupported = false;
    state.scannerWarmReused = false;
    state.scannerZoomMin = 1;
    state.scannerZoomMax = 1;
    state.scannerZoomStep = 0.1;
    state.scannerZoomValue = 1;
    setScannerTorchButtonVisible(false);
    setScannerZoomButtonsVisible(false);
    updateScannerTorchButton();
  }

  function detachScannerVideo() {
    if (els.scanVideo) {
      els.scanVideo.pause();
      els.scanVideo.srcObject = null;
      els.scanVideo.removeAttribute('src');
    }
  }

  function stopScannerStream(options = {}) {
    const track = state.scannerTrack;
    if (track && state.scannerTorchOn) {
      track.applyConstraints({ advanced: [{ torch: false }] }).catch(() => {});
    }

    const stream = state.scannerStream;
    const keepWarm = !!options.keepWarm && streamHasLiveVideoTrack(stream);

    if (keepWarm) {
      clearScannerWarmStream();
      state.scannerWarmStream = stream;
      state.scannerWarmFacingMode = state.scannerFacingMode === 'user' ? 'user' : 'environment';
      state.scannerWarmAt = Date.now();
    } else if (stream && typeof stream.getTracks === 'function') {
      stream.getTracks().forEach((streamTrack) => {
        try {
          streamTrack.stop();
        } catch (_error) {
          // no-op
        }
      });
    }

    state.scannerStream = null;
    resetScannerTrackState();
    detachScannerVideo();
  }

  function closeScanner(options = {}) {
    if (els.scanModal) {
      els.scanModal.hidden = true;
    }

    const reason = String(options.reason || 'USER_EXITED').trim() || 'USER_EXITED';
    const source = String(options.source || 'scanner').trim() || 'scanner';
    const keepWarm = Object.prototype.hasOwnProperty.call(options, 'keepWarm')
      ? !!options.keepWarm
      : !!(isLoginRequired() && state.onDuty);

    recordScannerLifecycleEvent({
      reason,
      source,
      scannerSessionExpiresAt: String(options.scannerSessionExpiresAt || '').trim(),
    });

    state.scannerActive = false;
    state.scannerBusy = false;
    state.scannerMode = '';

    resetScannerStableReadState();
    clearScannerResumeTimer();
    stopScannerDetection();
    stopScannerStream({ keepWarm });

    if (els.scanViewport) {
      els.scanViewport.classList.remove('is-mode-id', 'is-mode-ticket');
    }
    if (els.scanHint) {
      els.scanHint.textContent = '';
    }
    setScannerStatus('SCANNING...');
    setScannerResultCard('', '');
    if (els.scanFocusRing) {
      els.scanFocusRing.classList.remove('is-active');
    }
    setFeedback(els.scanFeedback, '');
  }

  function describeCameraError(error) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return 'Camera scanning is not supported on this device. Use manual entry.';
    }

    const name = String(error?.name || '');
    if (name === 'NotAllowedError' || name === 'SecurityError' || name === 'PermissionDeniedError') {
      return 'Camera permission was denied. Allow camera access and try again.';
    }
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
      return 'No camera was found on this device.';
    }
    if (name === 'NotReadableError' || name === 'TrackStartError') {
      return 'Camera is busy in another app. Close it and retry.';
    }

    return 'Unable to start camera. Use manual entry if needed.';
  }

  async function startScannerStream(facingMode, preferredDeviceId = '') {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('Camera API unavailable.');
    }

    stopScannerDetection();
    stopScannerStream();

    const safeFacing = facingMode === 'user' ? 'user' : 'environment';
    let stream = takeScannerWarmStream(safeFacing);
    const reusedWarmStream = !!stream;
    state.scannerWarmReused = reusedWarmStream;
    const preferredDevice = String(preferredDeviceId || '').trim();

    if (!stream) {
      if (preferredDevice) {
        try {
          stream = await requestScannerStream(safeFacing, preferredDevice);
        } catch (_error) {
          stream = null;
        }
      }
      if (!stream) {
        try {
          stream = await requestScannerStream(safeFacing);
        } catch (error) {
          if (error?.name === 'NotAllowedError' || error?.name === 'SecurityError' || error?.name === 'PermissionDeniedError') {
            throw error;
          }
          stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: true });
        }
      }
    }

    const initialTrack = stream?.getVideoTracks?.()[0] || null;
    const heuristicDeviceId = (reusedWarmStream || preferredDevice) ? '' : await findPreferredScannerDeviceId(safeFacing, initialTrack);
    if (heuristicDeviceId) {
      try {
        const replacementStream = await requestScannerStream(safeFacing, heuristicDeviceId);
        if (stream && typeof stream.getTracks === 'function') {
          stream.getTracks().forEach((streamTrack) => {
            try {
              streamTrack.stop();
            } catch (_error) {
              // no-op
            }
          });
        }
        stream = replacementStream;
      } catch (_error) {
        // Keep the initial stream if the preferred-device retry fails.
      }
    }

    state.scannerStream = stream;
    state.scannerFacingMode = safeFacing;
    state.scannerTrack = stream?.getVideoTracks?.()[0] || null;

    if (!els.scanVideo) {
      throw new Error('Scanner video element is missing.');
    }

    els.scanVideo.srcObject = stream;
    await els.scanVideo.play().catch(() => {});
  }

  async function canUseBarcodeDetector(mode) {
    if (!('BarcodeDetector' in window)) {
      return false;
    }

    const requiredFormats = scannerFormats(mode).native;
    if (!Array.isArray(requiredFormats) || requiredFormats.length === 0) {
      return false;
    }

    if (typeof window.BarcodeDetector.getSupportedFormats !== 'function') {
      return true;
    }

    try {
      const supported = await window.BarcodeDetector.getSupportedFormats();
      return requiredFormats.every((format) => supported.includes(format));
    } catch (_error) {
      return false;
    }
  }

  async function startBarcodeDetectorLoop(mode) {
    const formats = scannerFormats(mode).native;
    if (!Array.isArray(formats) || formats.length === 0) {
      return false;
    }

    let detector;
    try {
      detector = new window.BarcodeDetector({ formats });
    } catch (_error) {
      return false;
    }

    const fullCanvas = document.createElement('canvas');
    const fullContext = fullCanvas.getContext('2d', { willReadFrequently: true }) || fullCanvas.getContext('2d');
    const roiCanvas = document.createElement('canvas');
    const roiContext = roiCanvas.getContext('2d', { willReadFrequently: true }) || roiCanvas.getContext('2d');

    if (!fullContext || !roiContext) {
      return false;
    }

    const token = state.scannerLoopToken + 1;
    state.scannerLoopToken = token;
    const delay = scannerScanInterval(mode);

    const loop = async () => {
      if (!state.scannerActive || state.scannerMode !== mode || token !== state.scannerLoopToken) {
        return;
      }

      try {
        const video = els.scanVideo;
        if (video && video.readyState >= 2 && video.videoWidth > 0 && video.videoHeight > 0) {
          const roi = getScannerRoiRect(mode);
          let source = null;

          if (roi && roi.width > 0 && roi.height > 0) {
            if (roiCanvas.width !== roi.width || roiCanvas.height !== roi.height) {
              roiCanvas.width = roi.width;
              roiCanvas.height = roi.height;
            }
            roiContext.drawImage(video, roi.x, roi.y, roi.width, roi.height, 0, 0, roi.width, roi.height);
            source = roiCanvas;
          } else {
            if (fullCanvas.width !== video.videoWidth || fullCanvas.height !== video.videoHeight) {
              fullCanvas.width = video.videoWidth;
              fullCanvas.height = video.videoHeight;
            }
            fullContext.drawImage(video, 0, 0, fullCanvas.width, fullCanvas.height);
            source = fullCanvas;
          }

          const matches = await detector.detect(source);
          if (Array.isArray(matches) && matches.length > 0) {
            const rawValue = String(matches[0]?.rawValue || '').trim();
            if (rawValue !== '') {
              onScannerDecoded(rawValue);
              return;
            }
          }
        }
      } catch (_error) {
        // Keep loop running: transient camera/frame errors are expected.
      }

      state.scannerLoopTimer = window.setTimeout(loop, delay);
    };

    loop();
    return true;
  }

  async function startZxingDetectorLoop(mode) {
    await ensureZxingLoaded();

    const Reader = window.ZXingBrowser?.BrowserMultiFormatReader;
    if (typeof Reader !== 'function') {
      throw new Error('Scanner engine unavailable.');
    }

    const hints = new Map();
    if (window.ZXing?.DecodeHintType?.POSSIBLE_FORMATS) {
      const zxingFormats = scannerFormats(mode).zxing;
      if (zxingFormats.length > 0) {
        hints.set(window.ZXing.DecodeHintType.POSSIBLE_FORMATS, zxingFormats);
      }
    }

    const reader = new Reader(hints, scannerScanInterval(mode));
    state.scannerZxingReader = reader;

    const controls = await reader.decodeFromVideoElement(els.scanVideo, (result, error, activeControls) => {
      if (!state.scannerActive || state.scannerMode !== mode) {
        activeControls?.stop?.();
        return;
      }

      const text = String(result?.getText ? result.getText() : (result?.text || '')).trim();
      if (text) {
        onScannerDecoded(text);
        return;
      }

      if (!error) {
        return;
      }

      const errorName = String(error.name || error.constructor?.name || '');
      if (errorName === 'NotFoundException' || errorName === 'ChecksumException' || errorName === 'FormatException') {
        return;
      }
    });

    if (!state.scannerActive || state.scannerMode !== mode) {
      controls?.stop?.();
      return false;
    }

    state.scannerZxingControls = controls || null;
    return true;
  }

  async function startScannerDetectionLoop(mode) {
    const canUseNative = await canUseBarcodeDetector(mode);
    if (canUseNative) {
      const started = await startBarcodeDetectorLoop(mode);
      if (started) {
        return;
      }
    }

    await startZxingDetectorLoop(mode);
  }

  function scannerResultIsDuplicate(rawValue) {
    const normalized = String(rawValue || '').trim();
    if (!normalized) {
      return true;
    }

    const now = Date.now();
    if (normalized === state.scannerLastRaw && (now - state.scannerLastRawAt) < 4000) {
      return true;
    }

    state.scannerLastRaw = normalized;
    state.scannerLastRawAt = now;
    return false;
  }

  function scannerValueIsStable(rawValue) {
    const normalized = String(rawValue || '').trim();
    if (!normalized) {
      return '';
    }

    if (normalized === state.scannerStableValue) {
      state.scannerStableCount += 1;
    } else {
      state.scannerStableValue = normalized;
      state.scannerStableCount = 1;
    }

    const requiredCount = scannerRequiredStableCount(state.scannerMode || 'ticket');
    if (state.scannerStableCount < requiredCount) {
      setScannerStatus('SCANNING...');
      setFeedback(els.scanFeedback, 'Scanning...');
      return '';
    }

    return normalized;
  }

  async function applyDecodedTicketResult(rawValue, options = {}) {
    const parsed = parseTicketScanPayload(rawValue);
    if (!parsed.scanReference) {
      const invalidPayloadError = new Error('Could not read ticket payload. Enter ticket code manually.');
      invalidPayloadError.code = 'ticket_payload_invalid';
      throw invalidPayloadError;
    }

    if (parsed.scannedEventId > 0) {
      const switched = selectTicketEventById(parsed.scannedEventId);
      if (!switched) {
        showGlobalFeedback('Ticket is for a different event. Refresh Events if it is missing.', true);
      }
    }

    if (els.ticketScan) {
      els.ticketScan.value = parsed.scanReference;
    }

    return submitTicketCheckin({
      scanReference: parsed.scanReference,
      fromScanner: !!options.fromScanner,
      preserveInput: false
    });
  }

  function applyDecodedIdResult(rawValue, options = {}) {
    if (els.idPayload) {
      els.idPayload.value = rawValue;
    }
    if (els.idAdvanced) {
      els.idAdvanced.open = false;
    }
    setIdProcessButtonVisible(false);
    setIdRetryLogVisible(false);
    hideIdNotFoundPrompt();
    return processIdPayload({
      fromScanner: !!options.fromScanner,
      preserveProcessButton: !!options.preserveProcessButton
    }).catch((error) => setFeedback(els.idFeedback, error.message, true));
  }

  function getScannerServerSuccessMessage(result) {
    const message = typeof result?.message === 'string' ? result.message.trim() : '';
    const attendeeKind = String(result?.attendee?.kind || '').trim().toLowerCase();
    return attendeeKind === 'season_pass' ? message : '';
  }

  function getScannerServerErrorMessage(error) {
    const rawMessage = typeof error?.rawMessage === 'string' ? error.rawMessage.trim() : '';
    if (rawMessage !== '') {
      return rawMessage;
    }

    return typeof error?.message === 'string' ? error.message.trim() : '';
  }

  function describeTicketScannerOutcome(result, error) {
    if (!error) {
      if (result?.validation_only) {
        return {
          headline: 'TICKET VERIFIED',
          detail: 'Validation only. No check-in was recorded.',
          tone: 'success',
          pauseMs: 1600,
          signal: 'success'
        };
      }

      if (result?.queued) {
        return {
          headline: 'QUEUED OFFLINE',
          detail: 'Saved locally and ready to sync.',
          tone: 'warning',
          pauseMs: 1500,
          signal: 'warning'
        };
      }

      return {
        headline: 'CHECKED IN',
        detail: 'Ticket accepted.',
        tone: 'success',
        pauseMs: 1400,
        signal: 'success'
      };
    }

    const code = String(error?.code || '').trim().toLowerCase();
    const category = String(error?.category || '').trim().toLowerCase();

    if (code === 'duplicate_local') {
      return {
        headline: 'ALREADY SCANNED',
        detail: 'Duplicate scan blocked from local cache.',
        tone: 'warning',
        pauseMs: 2000,
        signal: 'warning'
      };
    }

    if (code === 'duplicate_checkin') {
      return {
        headline: 'ALREADY CHECKED IN',
        detail: getScannerServerErrorMessage(error) || 'Already checked in.',
        tone: 'warning',
        pauseMs: 2000,
        signal: 'warning'
      };
    }

    if (
      code === 'ticket_not_found'
      || code === 'guest_list_not_found'
      || code === 'ticket_payload_invalid'
      || code === 'invalid_event'
    ) {
      return {
        headline: 'INVALID TICKET',
        detail: 'Ticket not recognized for this event.',
        tone: 'error',
        pauseMs: 2200,
        signal: 'error'
      };
    }

    if (code === 'checkin_wrong_event') {
      return {
        headline: 'INVALID TICKET',
        detail: 'Ticket belongs to a different event.',
        tone: 'warning',
        pauseMs: 2200,
        signal: 'warning'
      };
    }

    if (category === 'session' || category === 'permission' || category === 'network') {
      return {
        headline: 'CONNECTION OR PERMISSION ERROR',
        detail: 'Reconnect or log in again.',
        tone: 'error',
        pauseMs: 2400,
        signal: 'error'
      };
    }

    return {
      headline: 'TRY AGAIN',
      detail: String(error?.message || 'Unable to check in ticket.'),
      tone: 'error',
      pauseMs: 2200,
      signal: 'error'
    };
  }

  function onScannerDecoded(rawValue) {
    if (!state.scannerActive) {
      return;
    }

    const stableValue = scannerValueIsStable(rawValue);
    if (!stableValue || scannerResultIsDuplicate(stableValue)) {
      return;
    }

    const mode = state.scannerMode || 'ticket';
    stopScannerDetection();
    state.scannerActive = false;
    state.scannerBusy = true;

    if (mode === 'id') {
      if (state.idScanDebugMetrics) {
        state.idScanDebugMetrics.readMs = Math.max(0, Math.round(performance.now() - state.idScanDebugMetrics.openedAt - (state.idScanDebugMetrics.warmupMs || 0)));
      }
      setIdScanPhase('Processing', 'Checking member record and visit history.', { fromScanner: true, tone: 'info' });
      setFeedback(els.scanFeedback, 'Processing ID...');
      applyDecodedIdResult(stableValue, { fromScanner: true }).catch(() => {});
      return;
    }

    setScannerStatus('CHECKING IN…');
    setScannerResultCard('', '');
    setFeedback(els.scanFeedback, 'Processing ticket…');

    applyDecodedTicketResult(stableValue, { fromScanner: true })
      .then((result) => {
        const attendeeName = String(result?.attendee?.name || '').trim();
        const outcome = describeTicketScannerOutcome(result, null);
        const detail = getScannerServerSuccessMessage(result)
          || (attendeeName && outcome.headline === 'CHECKED IN'
            ? `${attendeeName} checked in.`
            : outcome.detail);

        setScannerStatus(outcome.headline, outcome.tone === 'warning' ? 'warning' : 'success');
        setScannerResultCard(outcome.headline, detail, outcome.tone);
        setFeedback(els.scanFeedback, detail);
        if (outcome.signal === 'warning') {
          playScannerErrorSignal('warning');
        } else {
          playTicketCheckinChime();
        }
        scheduleScannerResume(outcome.pauseMs);
      })
      .catch((error) => {
        const outcome = describeTicketScannerOutcome(null, error);
        setScannerStatus(outcome.headline, outcome.tone === 'warning' ? 'warning' : 'error');
        setScannerResultCard(outcome.headline, outcome.detail, outcome.tone);
        setFeedback(els.scanFeedback, outcome.detail, outcome.tone === 'error');
        playScannerErrorSignal(outcome.signal === 'warning' ? 'warning' : 'error');
        scheduleScannerResume(outcome.pauseMs);
      });
  }

  function showScannerFocusRing(clientX, clientY) {
    if (!els.scanFocusRing || !els.scanViewport) {
      return;
    }

    const rect = els.scanViewport.getBoundingClientRect();
    const x = clampNumber(clientX - rect.left, 0, rect.width);
    const y = clampNumber(clientY - rect.top, 0, rect.height);

    els.scanFocusRing.style.left = `${x}px`;
    els.scanFocusRing.style.top = `${y}px`;
    els.scanFocusRing.classList.remove('is-active');
    // Trigger animation restart.
    void els.scanFocusRing.offsetWidth;
    els.scanFocusRing.classList.add('is-active');
  }

  async function handleScannerViewportTap(clientX, clientY) {
    if (!state.scannerActive) {
      return;
    }

    showScannerFocusRing(clientX, clientY);

    const track = state.scannerTrack;
    const caps = state.scannerCapabilities;
    if (!track || !caps) {
      if (els.scanHint) {
        els.scanHint.textContent = 'Tip: Move closer and hold steady.';
      }
      return;
    }

    const focusModes = Array.isArray(caps.focusMode) ? caps.focusMode : [];
    const advanced = {};

    if (focusModes.includes('continuous')) {
      advanced.focusMode = 'continuous';
    } else if (focusModes.includes('single-shot')) {
      advanced.focusMode = 'single-shot';
    }

    if (
      caps.focusDistance
      && Number.isFinite(caps.focusDistance.min)
      && Number.isFinite(caps.focusDistance.max)
      && caps.focusDistance.max > caps.focusDistance.min
    ) {
      advanced.focusDistance = caps.focusDistance.min + ((caps.focusDistance.max - caps.focusDistance.min) * 0.45);
    }

    if (Object.keys(advanced).length === 0) {
      if (els.scanHint) {
        els.scanHint.textContent = 'Tip: Move closer and hold steady.';
      }
      return;
    }

    try {
      await track.applyConstraints({ advanced: [advanced] });
      if (els.scanHint) {
        els.scanHint.textContent = scannerCoachingHint(state.scannerMode || 'ticket');
      }
    } catch (_error) {
      if (els.scanHint) {
        els.scanHint.textContent = 'Tip: Move closer and hold steady.';
      }
    }
  }

  async function openScanner(mode) {
    const scannerMode = mode === 'id' ? 'id' : 'ticket';
    const scannerPrefs = getScannerPrefs(scannerMode);
    if (state.scannerBusy || !els.scanModal || !els.scanVideo) {
      return;
    }

    if (isLoginRequired() && !state.onDuty) {
      const message = scannerMode === 'id' ? 'Log in to scan IDs.' : 'Log in to scan tickets.';
      if (scannerMode === 'id') {
        setFeedback(els.idFeedback, message, true);
      } else {
        setTicketStatus(message, 'error');
      }
      return;
    }

    clearScannerResumeTimer();
    state.scannerBusy = true;
    state.scannerActive = true;
    state.scannerMode = scannerMode;
    state.scannerFacingMode = scannerPrefs.facingMode === 'user' ? 'user' : 'environment';
    state.idScanDebugMetrics = null;
    resetScannerStableReadState();
    applyScannerViewportMode(scannerMode);
    setScannerResultCard('', '');
    if (scannerMode === 'id') {
      hideIdNotFoundPrompt();
      setIdRetryLogVisible(false);
      setIdProcessButtonVisible(false);
      renderIdAgeCard(null);
      clearIdDebugTiming();
      state.idScanDebugMetrics = {
        openedAt: performance.now(),
        warmupMs: 0,
        readMs: 0,
        requestMs: 0,
        renderMs: 0,
        totalMs: 0,
        autoAddMs: 0,
        warmReused: false,
        server: null
      };
    }

    if (els.scanTitle) {
      els.scanTitle.textContent = scannerModeTitle(scannerMode);
    }
    if (els.scanHint) {
      els.scanHint.textContent = scannerModeHint(scannerMode);
    }
    if (scannerMode === 'id') {
      setScannerStatus('WARMING UP...');
      setScannerResultCard('Reading ID', 'Starting camera. First scan may take a few seconds.', 'info');
      setFeedback(els.scanFeedback, 'Opening camera...');
    } else {
      setScannerStatus('SCANNING...');
      setFeedback(els.scanFeedback, 'Opening camera...');
    }
    els.scanModal.hidden = false;

    try {
      await startScannerStream(state.scannerFacingMode, scannerPrefs.deviceId);
      if (scannerMode === 'id' && state.idScanDebugMetrics) {
        state.idScanDebugMetrics.warmupMs = Math.max(0, Math.round(performance.now() - state.idScanDebugMetrics.openedAt));
        state.idScanDebugMetrics.warmReused = !!state.scannerWarmReused;
      }
      await analyzeScannerTrackCapabilities(scannerMode);
      await startScannerDetectionLoop(scannerMode);
      setScannerStatus('SCANNING...');
      if (scannerMode === 'id') {
        setScannerResultCard(
          'Reading ID',
          state.scannerWarmReused
            ? 'Camera ready. Hold steady and keep the barcode flat.'
            : 'Camera ready. Hold steady while the first scan warms up.',
          'info'
        );
      }
      setFeedback(els.scanFeedback, 'Scanning...');
      startScannerCoachingTimer(scannerMode);
    } catch (error) {
      state.scannerActive = false;
      stopScannerDetection();
      stopScannerStream();
      recordScannerLifecycleEvent({
        reason: 'FATAL_CAMERA_ERROR',
        source: 'camera_error',
      });
      setScannerStatus('SCANNER ERROR', 'error');
      const fallback = String(error?.message || '').toLowerCase().includes('dependencies')
        ? 'Scanner engine failed to load. Enter the code manually.'
        : describeCameraError(error);
      setFeedback(els.scanFeedback, fallback, true);
    } finally {
      state.scannerBusy = false;
    }
  }

  async function flipScannerCamera() {
    if (!state.scannerActive || state.scannerBusy) {
      return;
    }

    state.scannerBusy = true;
    const scannerMode = state.scannerMode || 'ticket';
    const previousFacing = state.scannerFacingMode === 'user' ? 'user' : 'environment';
    const nextFacing = state.scannerFacingMode === 'environment' ? 'user' : 'environment';
    setFeedback(els.scanFeedback, 'Switching camera...');

    try {
      await startScannerStream(nextFacing);
      updateScannerPrefs(scannerMode, { facingMode: nextFacing, deviceId: '' });
      await analyzeScannerTrackCapabilities(scannerMode);
      await startScannerDetectionLoop(scannerMode);
      setScannerStatus('SCANNING...');
      setFeedback(els.scanFeedback, 'Scanning...');
      startScannerCoachingTimer(scannerMode);
    } catch (error) {
      try {
        await startScannerStream(previousFacing);
        updateScannerPrefs(scannerMode, { facingMode: previousFacing, deviceId: '' });
        await analyzeScannerTrackCapabilities(scannerMode);
        await startScannerDetectionLoop(scannerMode);
      } catch (_retryError) {
        state.scannerActive = false;
        stopScannerDetection();
        stopScannerStream();
        recordScannerLifecycleEvent({
          reason: 'FATAL_CAMERA_ERROR',
          source: 'camera_error',
        });
      }
      setFeedback(els.scanFeedback, describeCameraError(error), true);
    } finally {
      state.scannerBusy = false;
    }
  }

  function clearAttendeeAutoRefreshTimer() {
    if (state.attendeeAutoRefreshTimer) {
      window.clearTimeout(state.attendeeAutoRefreshTimer);
      state.attendeeAutoRefreshTimer = null;
    }
  }

  function resetAttendeeAutoRefreshState() {
    clearAttendeeAutoRefreshTimer();
    state.attendeeAutoRefreshBusy = false;
    state.attendeeAutoRefreshLastAt = 0;
    state.attendeeAutoRefreshLastResultAt = 0;
    state.attendeeAutoRefreshLastManualAt = 0;
    state.attendeeAutoRefreshLastBackgroundStartAt = 0;
    state.attendeeAutoRefreshLastBackgroundCompleteAt = 0;
    state.attendeeAutoRefreshNextAt = 0;
    state.attendeeAutoRefreshCatchupPending = false;
    state.attendeeAutoRefreshLastSkipReason = '';
    state.attendeeAutoRefreshMessage = '';
  }

  function getAttendeeAutoRefreshCadenceMs() {
    return Math.max(
      5 * 60 * 1000,
      Number(state.attendeeAutoRefreshIntervalMs || (5 * 60 * 1000))
        + Number(state.attendeeAutoRefreshJitterMs || 0)
    );
  }

  function getAttendeeAutoRefreshAnchorAt() {
    return Math.max(
      Number(state.attendeeAutoRefreshLastManualAt || 0),
      Number(state.attendeeAutoRefreshLastBackgroundCompleteAt || 0),
      Number(state.attendeeAutoRefreshLastBackgroundStartAt || 0)
    );
  }

  function armAttendeeAutoRefreshTimer(nextAt) {
    const targetAt = Number(nextAt || 0);
    if (!(targetAt > 0)) {
      return;
    }

    clearAttendeeAutoRefreshTimer();
    state.attendeeAutoRefreshTimer = window.setTimeout(() => {
      maybeAutoRefreshAttendees({ trigger: 'timer' }).catch(() => {});
    }, Math.max(0, targetAt - Date.now()));
  }

  function getAttendeeAutoRefreshErrorReason(error) {
    if (isAuthError(error) || Number(error?.status || 0) === 403) {
      return 'permission error';
    }

    const category = String(error?.category || '').toLowerCase();
    const code = String(error?.code || '').toLowerCase();
    if (
      category === 'network'
      || code === 'network_unavailable'
      || code === 'request_timeout'
      || code === 'request_failed'
    ) {
      return 'network error';
    }

    return 'network error';
  }

  function getAttendeeAutoRefreshSkipReason(options = {}) {
    if (!config.caps?.scanTickets) {
      return 'cache disabled';
    }

    if (state.attendeeAutoRefreshBusy || state.attendeesLoading || state.ticketCheckinBusy || state.scannerBusy) {
      return 'previous request still running';
    }

    if (isLoginRequired() && !state.onDuty) {
      return 'permission error';
    }

    if (!navigator.onLine) {
      return 'network error';
    }

    let venueId = 0;
    try {
      venueId = getVenueId(false);
    } catch (_error) {
      venueId = 0;
    }
    if (!(venueId > 0)) {
      return 'no venue';
    }

    const selected = getSelectedEventRecord();
    if (!selected || !isSelectedTicketEventConfirmed() || !eventShouldAutoRefreshAttendees(selected)) {
      return 'no active event';
    }

    if (!options.force && document.visibilityState !== 'visible') {
      return 'hidden tab';
    }

    return '';
  }

  function scheduleAttendeeAutoRefresh(reason = 'schedule') {
    clearAttendeeAutoRefreshTimer();

    const selected = getSelectedEventRecord();
    const hasVenue = (() => {
      try {
        return getVenueId(false) > 0;
      } catch (_error) {
        return false;
      }
    })();

    if (!config.caps?.scanTickets || !hasVenue || !selected || !isSelectedTicketEventConfirmed() || !eventShouldAutoRefreshAttendees(selected)) {
      state.attendeeAutoRefreshNextAt = 0;
      state.attendeeAutoRefreshLastSkipReason = getAttendeeAutoRefreshSkipReason({ force: false }) || state.attendeeAutoRefreshLastSkipReason;
      renderTicketMeta();
      return;
    }

    const nowMs = Date.now();
    const anchorAt = getAttendeeAutoRefreshAnchorAt();
    const nextAt = (anchorAt > 0 ? anchorAt : nowMs) + getAttendeeAutoRefreshCadenceMs();
    state.attendeeAutoRefreshNextAt = nextAt;

    if (document.visibilityState !== 'visible' && nextAt <= nowMs) {
      renderTicketMeta();
      return;
    }

    armAttendeeAutoRefreshTimer(nextAt);
    renderTicketMeta();
  }

  function handleAttendeeAutoRefreshWake(trigger = 'wake') {
    const dueAt = Number(state.attendeeAutoRefreshNextAt || 0);
    const nowMs = Date.now();
    const shouldCatchUp = document.visibilityState === 'visible'
      && (state.attendeeAutoRefreshCatchupPending || (dueAt > 0 && nowMs >= dueAt));

    if (shouldCatchUp) {
      maybeAutoRefreshAttendees({ trigger }).catch(() => {});
      return;
    }

    scheduleAttendeeAutoRefresh(trigger);
  }

  async function loadAttendeesToCache(options = {}) {
    if (state.attendeesLoading) {
      return null;
    }

    const silent = !!options.silent;
    const source = options.source === 'background' ? 'background' : 'manual';
    state.attendeesLoadingSilent = silent;

    if (!silent) {
      clearTicketNotice();
    }

    const selected = getSelectedEvent();
    if (!selected) {
      setTicketStatus('Select an event before caching attendees.', 'error');
      state.attendeesLoadingSilent = false;
      return null;
    }

    setAttendeesLoading(true);
    try {
      const data = await api(`/ticket/events/${selected.id}/attendees`);
      const completedAt = Date.now();
      state.selectedEventId = selected.id;
      state.selectedEventSource = selected.source;
      state.attendeesCache[selected.id] = {
        items: data.items || [],
        updatedAt: data.cache_updated_at || ''
      };
      localStorage.setItem(`vms_ops_attendees_${selected.id}`, JSON.stringify(state.attendeesCache[selected.id]));
      state.attendeeAutoRefreshLastAt = completedAt;
      if (source === 'background') {
        state.attendeeAutoRefreshLastResultAt = completedAt;
        state.attendeeAutoRefreshLastBackgroundCompleteAt = completedAt;
        state.attendeeAutoRefreshMessage = `Last background sync: ${new Date(completedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
      } else {
        state.attendeeAutoRefreshLastManualAt = completedAt;
        if (state.attendeeAutoRefreshMessage === 'Background attendee sync will retry.') {
          state.attendeeAutoRefreshMessage = '';
        }
        showGlobalFeedback(`Cached ${(data.items || []).length} attendees.`);
        setTicketStatus('Attendee cache updated.', 'info');
      }
      state.attendeeAutoRefreshLastSkipReason = '';
      state.attendeeAutoRefreshCatchupPending = false;
      scheduleAttendeeAutoRefresh(source === 'background' ? 'background-success' : 'manual-success');
      renderAttendeeLookup();
      updateTicketScanHint();
      renderTicketMeta();
      return data;
    } catch (error) {
      state.attendeeAutoRefreshLastSkipReason = getAttendeeAutoRefreshErrorReason(error);
      if (source === 'background') {
        state.attendeeAutoRefreshMessage = 'Background attendee sync will retry.';
      }
      scheduleAttendeeAutoRefresh(source === 'background' ? 'background-error' : 'manual-error');
      renderTicketMeta();
      throw error;
    } finally {
      state.attendeesLoadingSilent = false;
      setAttendeesLoading(false);
    }
  }


  function getAttendeeCache(eventId) {
    const safeEventId = Number.parseInt(String(eventId || '0'), 10);
    if (Number.isNaN(safeEventId) || safeEventId <= 0) {
      return { items: [], updatedAt: '' };
    }

    if (state.attendeesCache[safeEventId]) {
      return state.attendeesCache[safeEventId];
    }

    try {
      const raw = localStorage.getItem(`vms_ops_attendees_${safeEventId}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.items)) {
          state.attendeesCache[safeEventId] = {
            items: parsed.items || [],
            updatedAt: parsed.updatedAt || ''
          };
          return state.attendeesCache[safeEventId];
        }
      }
    } catch (_error) {
      // ignore
    }

    return { items: [], updatedAt: '' };
  }

  function findCachedAttendeeByRef(eventId, scanReference) {
    const safeRef = normalizeScanRef(String(scanReference || '')).toLowerCase();
    if (!safeRef) {
      return null;
    }

    const cache = getAttendeeCache(eventId);
    const items = Array.isArray(cache.items) ? cache.items : [];
    for (let i = 0; i < items.length; i += 1) {
      const attendee = items[i];
      const ticketRef = normalizeScanRef(String(attendee?.ticket_ref || '')).toLowerCase();
      if (ticketRef && ticketRef === safeRef) {
        return attendee;
      }
    }

    return null;
  }

  function guestListProgressForRef(eventId, scanReference) {
    const attendee = findCachedAttendeeByRef(eventId, scanReference);
    if (!attendee || attendee.kind !== 'guest_list') {
      return null;
    }

    const partySize = Math.max(1, Number.parseInt(String(attendee.party_size || '1'), 10) || 1);
    const checkedInQty = Math.max(0, Number.parseInt(String(attendee.checked_in_qty || '0'), 10) || 0);
    const remaining = Math.max(0, partySize - checkedInQty);

    return {
      attendee,
      partySize,
      checkedInQty,
      remaining
    };
  }

  function syncTicketSubmitAllButton() {
    if (!els.ticketSubmitAll) {
      updateTicketScanHint();
      updateTicketActionAvailability();
      return;
    }

    const selected = getSelectedEvent();
    const scanReference = normalizeScanRef(String(els.ticketScan?.value || ''));
    const isGuestListRef = scanReference.toLowerCase().startsWith('gl:');
    const canTickets = !!config.caps?.scanTickets;
    const locked = isLoginRequired() && !state.onDuty;
    const confirmed = isSelectedTicketEventConfirmed();
    updateTicketActionAvailability();

    if (!canTickets || !selected || !confirmed || !isGuestListRef) {
      els.ticketSubmitAll.hidden = true;
      els.ticketSubmitAll.disabled = true;
      els.ticketSubmitAll.textContent = 'Check In All';
      updateTicketScanHint();
      return;
    }

    els.ticketSubmitAll.hidden = false;

    const progress = guestListProgressForRef(selected.id, scanReference);
    if (!progress) {
      els.ticketSubmitAll.disabled = true;
      els.ticketSubmitAll.textContent = 'Load attendee cache first';
      updateTicketScanHint();
      return;
    }

    if (progress.remaining <= 0) {
      els.ticketSubmitAll.disabled = true;
      els.ticketSubmitAll.textContent = 'Fully checked in';
      updateTicketScanHint();
      return;
    }

    if (progress.remaining === 1) {
      els.ticketSubmitAll.disabled = true;
      els.ticketSubmitAll.textContent = '1 guest left';
      updateTicketScanHint();
      return;
    }

    els.ticketSubmitAll.disabled = locked;
    els.ticketSubmitAll.textContent = `Check In All (${progress.remaining})`;
    updateTicketScanHint();
    updateTicketActionAvailability();
  }

  function updateTicketScanHint() {
    if (!els.ticketScanHint) {
      return;
    }

    const selected = getSelectedEvent();
    const scanReference = normalizeScanRef(String(els.ticketScan?.value || ''));
    const isGuestListRef = scanReference.toLowerCase().startsWith('gl:');

    if (!selected || !isGuestListRef) {
      els.ticketScanHint.textContent = '';
      return;
    }

    const progress = guestListProgressForRef(selected.id, scanReference);
    if (progress) {
      if (progress.remaining <= 0) {
        els.ticketScanHint.textContent = 'This reservation is fully checked in.';
        return;
      }
      if (progress.remaining === 1) {
        els.ticketScanHint.textContent = `In ${progress.checkedInQty}/${progress.partySize}. Use Check In for the last guest.`;
        return;
      }
      els.ticketScanHint.textContent = `In ${progress.checkedInQty}/${progress.partySize}. Use Check In All (${progress.remaining}).`;
      return;
    }

    const cache = getAttendeeCache(selected.id);
    const total = Array.isArray(cache.items) ? cache.items.length : 0;
    if (!total) {
      els.ticketScanHint.textContent = 'Tap Cache Attendees to enable Check In All.';
      return;
    }

    els.ticketScanHint.textContent = 'If this was just claimed, tap Cache Attendees to refresh.';
  }

  async function ensureGuestListProgress(eventId, scanReference, options = {}) {
    let progress = guestListProgressForRef(eventId, scanReference);
    if (progress || !options.autoRefresh) {
      return progress;
    }
    if (!navigator.onLine || state.attendeesLoading) {
      return null;
    }

    const safeRef = normalizeScanRef(String(scanReference || '')).toLowerCase();
    if (!safeRef) {
      return null;
    }

    const throttleKey = `${eventId}:${safeRef}`;
    const nowMs = Date.now();
    if (state.guestListCacheRef === throttleKey && (nowMs - state.guestListCacheAt) < 8000) {
      return null;
    }
    state.guestListCacheRef = throttleKey;
    state.guestListCacheAt = nowMs;

    setTicketStatus('Refreshing attendee cache...', 'info');
    try {
      await loadAttendeesToCache();
    } catch (_error) {
      return null;
    }

    progress = guestListProgressForRef(eventId, scanReference);
    return progress;
  }

  async function maybeAutoRefreshAttendees(options = {}) {
    const force = !!options.force;
    const skipReason = getAttendeeAutoRefreshSkipReason({ force });
    const nowMs = Date.now();
    if (!force && state.attendeeAutoRefreshNextAt > nowMs && state.attendeeAutoRefreshNextAt > 0) {
      scheduleAttendeeAutoRefresh('too-early');
      return null;
    }
    if (skipReason) {
      state.attendeeAutoRefreshLastSkipReason = skipReason;
      state.attendeeAutoRefreshCatchupPending = skipReason === 'hidden tab';
      clearAttendeeAutoRefreshTimer();
      if (skipReason === 'network error' || skipReason === 'permission error') {
        state.attendeeAutoRefreshNextAt = nowMs + getAttendeeAutoRefreshCadenceMs();
        if (document.visibilityState === 'visible') {
          armAttendeeAutoRefreshTimer(state.attendeeAutoRefreshNextAt);
        }
      } else if (skipReason === 'hidden tab' || skipReason === 'previous request still running') {
        if (!(state.attendeeAutoRefreshNextAt > 0)) {
          const anchorAt = getAttendeeAutoRefreshAnchorAt();
          state.attendeeAutoRefreshNextAt = (anchorAt > 0 ? anchorAt : nowMs) + getAttendeeAutoRefreshCadenceMs();
        }
      } else {
        state.attendeeAutoRefreshNextAt = 0;
      }
      renderTicketMeta();
      return null;
    }

    state.attendeeAutoRefreshBusy = true;
    state.attendeeAutoRefreshLastAt = nowMs;
    state.attendeeAutoRefreshLastBackgroundStartAt = nowMs;
    state.attendeeAutoRefreshLastSkipReason = '';
    state.attendeeAutoRefreshCatchupPending = false;
    renderTicketMeta();
    try {
      const data = await loadAttendeesToCache({ silent: true, source: 'background' });
      return data;
    } catch (_error) {
      return null;
    } finally {
      state.attendeeAutoRefreshBusy = false;
      scheduleAttendeeAutoRefresh('background-finished');
      renderTicketMeta();
    }
  }

  function normalizeSearch(value) {
    return String(value || '').trim().toLowerCase();
  }

  function buildAttendeeCacheMeta(total, updatedAt) {
    if (!total) {
      return updatedAt ? `No cached attendees. Last cached: ${updatedAt}` : 'No cached attendees. Use "Cache Attendees" first.';
    }

    return updatedAt ? `${total} cached. Last cached: ${updatedAt}` : `${total} cached.`;
  }

  function renderAttendeeLookup() {
    if (!els.attendeeResults || !els.attendeeMeta) {
      return;
    }

    const selected = getSelectedEvent();
    const selectedEventRecord = getSelectedEventRecord();
    if (!selected) {
      els.attendeeResults.textContent = 'Select an event to search cached attendees.';
      els.attendeeMeta.textContent = '';
      syncTicketSubmitAllButton();
      return;
    }

    const cache = getAttendeeCache(selected.id);
    const items = Array.isArray(cache.items) ? cache.items : [];
    const total = items.length;
    const cacheMeta = buildAttendeeCacheMeta(total, cache.updatedAt);

    const term = normalizeSearch(els.attendeeSearch?.value || state.attendeeSearchTerm);
    state.attendeeSearchTerm = term;

    if (!term) {
      els.attendeeMeta.textContent = cacheMeta;
      els.attendeeResults.textContent = total
        ? 'Type a name or email above to search the cached attendee list.'
        : 'No cached attendees yet. Use "Cache Attendees" first.';
      syncTicketSubmitAllButton();
      return;
    }

    const matches = items.filter((attendee) => {
      const name = normalizeSearch(attendee?.name);
      const email = normalizeSearch(attendee?.email);
      const phone = normalizeSearch(attendee?.phone);
      return name.includes(term) || email.includes(term) || phone.includes(term);
    });

    els.attendeeResults.innerHTML = '';

    if (matches.length == 0) {
      els.attendeeResults.textContent = 'No matching attendees found in the cache.';
      els.attendeeMeta.textContent = `${cacheMeta}`;
      syncTicketSubmitAllButton();
      return;
    }

    const list = document.createElement('div');
    list.className = 'vms-ops-attendee-list';
    const rowActionLabel = getAttendeeLookupActionLabel(selectedEventRecord);

    matches.slice(0, 30).forEach((attendee) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'vms-ops-attendee-row';

      const left = document.createElement('div');
      left.className = 'vms-ops-attendee-left';

      const name = document.createElement('div');
      name.className = 'vms-ops-attendee-name';
      name.textContent = attendee?.name || 'Unnamed attendee';

      const sub = document.createElement('div');
      sub.className = 'vms-ops-attendee-sub';
      const email = attendee?.email ? String(attendee.email) : '';
      const ticketRef = attendee?.ticket_ref ? `Ref: ${attendee.ticket_ref}` : '';
      const partySize = attendee?.party_size ? `Party: ${attendee.party_size}` : '';
      const glProgress = attendee?.kind === 'guest_list' && typeof attendee?.checked_in_qty !== 'undefined' && attendee?.party_size
        ? `In: ${attendee.checked_in_qty}/${attendee.party_size}`
        : '';
      sub.textContent = [email, partySize, glProgress, ticketRef].filter(Boolean).join(' • ');

      left.appendChild(name);
      if (sub.textContent) {
        left.appendChild(sub);
      }

      const status = document.createElement('span');
      status.className = 'vms-ops-attendee-status';

      const locallyChecked = attendee?.ticket_ref ? isCheckedLocal(selected.id, String(attendee.ticket_ref)) : false;
      const isGuestList = attendee?.kind === 'guest_list';
      let isOpen = false;

      if (isGuestList && attendee?.party_size && typeof attendee?.checked_in_qty !== 'undefined') {
        const inQty = Number.parseInt(String(attendee.checked_in_qty || '0'), 10) || 0;
        const totalQty = Number.parseInt(String(attendee.party_size || '1'), 10) || 1;
        const full = inQty >= totalQty;
        isOpen = !full;
        status.textContent = full ? 'Checked In' : (inQty > 0 ? `In ${inQty}/${totalQty}` : rowActionLabel);
        status.dataset.state = full ? 'checked' : (inQty > 0 ? 'partial' : 'open');
      } else {
        const checked = Boolean(attendee?.checked_in) || Boolean(attendee?.checked_in_local) || locallyChecked;
        isOpen = !checked;
        status.textContent = checked ? 'Checked In' : rowActionLabel;
        status.dataset.state = checked ? 'checked' : 'open';
      }

      if (!isOpen) {
        button.disabled = true;
        button.classList.add('is-disabled');
      }

      button.appendChild(left);
      button.appendChild(status);

      button.addEventListener('click', () => {
        const scanReference = normalizeScanRef(String(attendee?.ticket_ref || ''));
        if (!scanReference) {
          return;
        }

        const confirmParts = [
          `${rowActionLabel} this ticket?`,
          attendee?.name ? `Name: ${attendee.name}` : '',
          attendee?.ticket_ref ? `Ref: ${attendee.ticket_ref}` : ''
        ];

        if (isGuestList && attendee?.party_size && typeof attendee?.checked_in_qty !== 'undefined') {
          const inQty = Number.parseInt(String(attendee.checked_in_qty || '0'), 10) || 0;
          const totalQty = Number.parseInt(String(attendee.party_size || '1'), 10) || 1;
          const remaining = Math.max(0, totalQty - inQty);
          confirmParts.push(`Remaining: ${remaining}`);
        }

        if (!window.confirm(confirmParts.filter(Boolean).join('\n'))) {
          return;
        }

        if (els.ticketScan) {
          els.ticketScan.value = scanReference;
          syncTicketSubmitAllButton();
        }

        submitTicketCheckin({
          scanReference,
          preserveInput: false,
          fromLookup: true
        }).catch(() => {});
      });

      list.appendChild(button);
    });

    els.attendeeResults.appendChild(list);
    els.attendeeMeta.textContent = `${matches.length} match${matches.length === 1 ? '' : 'es'} • ${cacheMeta}`;
    syncTicketSubmitAllButton();
  }

  function clearAttendeeLookup() {
    state.attendeeSearchTerm = '';
    if (els.attendeeSearch) {
      els.attendeeSearch.value = '';
    }
    if (els.ticketScan) {
      els.ticketScan.value = '';
    }

    renderAttendeeLookup();
    syncTicketSubmitAllButton();
  }

  function markCheckedLocal(eventId, scanRef) {
    const key = `${eventId}:${scanRef.toLowerCase()}`;
    state.localCheckedKeys[key] = 1;
    persistChecked();
  }

  function isCheckedLocal(eventId, scanRef) {
    const key = `${eventId}:${scanRef.toLowerCase()}`;
    return !!state.localCheckedKeys[key];
  }

  
  function applyCheckinResultToCache(eventId, attendee) {
    const safeEventId = Number.parseInt(String(eventId || '0'), 10);
    if (Number.isNaN(safeEventId) || safeEventId <= 0) {
      return;
    }
    if (!attendee || !attendee.ticket_ref) {
      return;
    }
    const cache = getAttendeeCache(safeEventId);
    const items = Array.isArray(cache.items) ? cache.items : [];
    const ref = String(attendee.ticket_ref).toLowerCase();

    let updated = false;
    const nextItems = items.map((item) => {
      if (!item || !item.ticket_ref) {
        return item;
      }
      if (String(item.ticket_ref).toLowerCase() !== ref) {
        return item;
      }
      updated = true;
      return Object.assign({}, item, attendee);
    });

    if (!updated) {
      nextItems.push(attendee);
    }

    state.attendeesCache[safeEventId] = {
      items: nextItems,
      updatedAt: cache.updatedAt || ''
    };

    try {
      localStorage.setItem(`vms_ops_attendees_${safeEventId}`, JSON.stringify(state.attendeesCache[safeEventId]));
    } catch (_error) {
      // ignore
    }

    syncTicketSubmitAllButton();
  }

function enqueueTicketScan(payload) {
    state.queue.push(payload);
    persistQueue();
    renderTicketMeta();
  }

  async function submitTicketCheckin(options = {}) {
    const explicitScanReference = normalizeScanRef(String(options.scanReference || ''));
    const retryWrongEvent = options.retryWrongEvent !== false;
    const retryAfterAttendeeRefresh = options.retryAfterAttendeeRefresh !== false;
    const qtyMode = options.qtyMode === 'all_remaining' ? 'all_remaining' : 'single';
    const preserveInput = !!options.preserveInput;

    if (state.ticketCheckinBusy) {
      throw new Error('Ticket check-in is already in progress.');
    }

    clearTicketNotice();

    const selected = getSelectedEvent();
    const selectedEvent = getSelectedEventRecord();
    if (!selected || !selectedEvent) {
      setTicketStatus('Select an event first.', 'error');
      throw new Error('Select an event first.');
    }
    if (!requireConfirmedTicketEvent()) {
      throw new Error('Confirm the active event before scanning.');
    }

    let scanReference = explicitScanReference || normalizeScanRef(String(els.ticketScan?.value || ''));
    if (!scanReference) {
      setTicketStatus('Scan or enter a ticket reference.', 'error');
      throw new Error('Scan or enter a ticket reference.');
    }

    let qty = 1;
    const isGuestListRef = String(scanReference || '').toLowerCase().startsWith('gl:');
    if (qtyMode === 'all_remaining' && isGuestListRef) {
      let progress = guestListProgressForRef(selected.id, scanReference);
      if (!progress) {
        progress = await ensureGuestListProgress(selected.id, scanReference, { autoRefresh: true });
      }
      if (!progress) {
        setTicketStatus('Refresh attendees first so remaining party size can be verified.', 'error');
        updateTicketScanHint();
        throw new Error('Refresh attendees first so remaining party size can be verified.');
      }
      if (progress.remaining <= 0) {
        setTicketStatus('This Guest List reservation is already fully checked in.', 'error');
        updateTicketScanHint();
        throw new Error('This Guest List reservation is already fully checked in.');
      }
      qty = progress.remaining;
    }

    const venueId = getVenueId(true);

    if (isCheckedLocal(selected.id, scanReference)) {
      setTicketStatus('Duplicate scan blocked (local cache).', 'error');
      const duplicateError = new Error('Duplicate scan blocked from local cache.');
      duplicateError.code = 'duplicate_local';
      throw duplicateError;
    }

    const payload = {
      venue_id: venueId,
      event_id: selected.id,
      event_source: selected.source,
      scan_reference: scanReference,
      qty,
      queued_at: new Date().toISOString()
    };
    const validationOnlyMode = getEventRuntimeWindow(selectedEvent).state === 'upcoming';

    state.ticketCheckinBusy = true;
    try {
      if (!navigator.onLine) {
        if (validationOnlyMode) {
          setTicketStatus('Upcoming-event test scans require a live connection. Nothing was queued.', 'error');
          throw new Error('Upcoming-event test scans require a live connection. Nothing was queued.');
        }
        enqueueTicketScan(payload);
        if (!isGuestListRef) {
          markCheckedLocal(selected.id, scanReference);
        }
        renderAttendeeLookup();
        if (els.ticketScan && !preserveInput) {
          els.ticketScan.value = '';
        }
        syncTicketSubmitAllButton();
        setTicketStatus('Offline: scan queued for sync.', 'info');
        return {
          queued: 1,
          event: selectedEvent,
          scan_reference: scanReference,
          attendee: findCachedAttendeeByRef(selected.id, scanReference) || null,
          message: 'Offline: scan queued for sync.'
        };
      }

      const data = await api('/ticket/checkin', { method: 'POST', body: payload });
      const attendee = data?.attendee || {};
      if (!data?.validation_only) {
        applyCheckinResultToCache(selected.id, attendee);
        const shouldMarkLocal = attendee.kind !== 'guest_list' || Boolean(attendee.checked_in);
        if (shouldMarkLocal) {
          markCheckedLocal(selected.id, scanReference);
        }
      }
      renderAttendeeLookup();
      if (els.ticketScan && !preserveInput) {
        els.ticketScan.value = '';
      }
      syncTicketSubmitAllButton();
      if (data?.validation_only) {
        setTicketNotice(
          String(data.message || 'Ticket verified for this upcoming event. Test only; no check-in was recorded.'),
          'info'
        );
        setFeedback(els.ticketFeedback, '');
      } else if (typeof data?.message === 'string' && data.message.trim()) {
        setTicketNotice(data.message.trim());
        setFeedback(els.ticketFeedback, '');
        playTicketCheckinChime();
      } else if (attendee.kind === 'guest_list' && attendee.party_size && typeof attendee.checked_in_qty !== 'undefined') {
        const inQty = Number.parseInt(String(attendee.checked_in_qty || '0'), 10) || 0;
        const totalQty = Number.parseInt(String(attendee.party_size || '1'), 10) || 1;
        const name = attendee.name ? `${attendee.name}: ` : '';
        setTicketNotice(`Check-In Successful: ${name}In ${inQty}/${totalQty}.`);
        setFeedback(els.ticketFeedback, '');
        playTicketCheckinChime();
      } else {
        const attendeeName = attendee?.name ? `${attendee.name} checked in.` : 'Ticket checked in.';
        setTicketNotice(`Check-In Successful: ${attendeeName}`);
        setFeedback(els.ticketFeedback, '');
        playTicketCheckinChime();
      }

      maybeAutoRefreshAttendees({ force: false }).catch(() => {});
      return data;
    } catch (error) {
      const errorData = error?.payload?.data && typeof error.payload.data === 'object' ? error.payload.data : {};

      if (error.code === 'network_unavailable') {
        if (validationOnlyMode) {
          setTicketStatus('Upcoming-event test scans require a live connection. Nothing was queued.', 'error');
          throw error;
        }
        enqueueTicketScan(payload);
        if (!isGuestListRef) {
          markCheckedLocal(selected.id, scanReference);
        }
        renderAttendeeLookup();
        if (els.ticketScan && !preserveInput) {
          els.ticketScan.value = '';
        }
        syncTicketSubmitAllButton();
        setTicketStatus('Connection lost: scan queued for sync.', 'info');
        return {
          queued: 1,
          event: selectedEvent,
          scan_reference: scanReference,
          attendee: findCachedAttendeeByRef(selected.id, scanReference) || null,
          message: 'Connection lost: scan queued for sync.'
        };
      }

      if (error.code === 'checkin_not_open' || error.code === 'checkin_closed' || error.code === 'checkin_expired_ticket') {
        setTicketStatus(error.message, 'error');
        throw error;
      }

      if (error.code === 'checkin_wrong_event') {
        const scannedEventId = Number.parseInt(String(errorData.scanned_event_id || '0'), 10);
        if (retryWrongEvent && !Number.isNaN(scannedEventId) && scannedEventId > 0) {
          const switched = selectTicketEventById(scannedEventId, { persist: true, venueId: getVenueId(false) });
          if (switched) {
            setTicketStatus('Ticket belongs to a different event. Switched to that event; confirm it before scanning.', 'info');
            renderTicketMeta();
            const switchedEventError = new Error('Ticket belongs to a different event. Confirm it before scanning.');
            switchedEventError.code = 'checkin_wrong_event';
            throw switchedEventError;
          }
          setTicketStatus('This ticket is for a different event. Refresh Events and try again.', 'error');
          throw error;
        }

        setTicketStatus(error.message, 'error');
        throw error;
      }

      if ((error.code === 'ticket_not_found' || error.code === 'guest_list_not_found') && retryAfterAttendeeRefresh && navigator.onLine) {
        setTicketStatus('Ticket not found. Refreshing attendees and trying once more...', 'info');
        try {
          await loadAttendeesToCache({ silent: true });
          renderTicketMeta();
          state.ticketCheckinBusy = false;
          return submitTicketCheckin({
            retryWrongEvent,
            retryAfterAttendeeRefresh: false,
            qtyMode,
            scanReference,
            preserveInput
          });
        } catch (_refreshError) {
          // Fall through to the original not-found message if refresh or retry fails.
        }
      }

      if (error.code === 'duplicate_checkin') {
        markCheckedLocal(selected.id, scanReference);
        renderAttendeeLookup();
      }
      syncTicketSubmitAllButton();
      setTicketStatus(error.message, 'error');
      throw error;
    } finally {
      state.ticketCheckinBusy = false;
    }
  }

  async function syncTicketQueue() {
    if (state.queueBusy || !navigator.onLine || state.queue.length === 0) {
      return;
    }

    state.queueBusy = true;
    try {
      const pending = [...state.queue];
      const nextQueue = [];

      for (const item of pending) {
        try {
          await api('/ticket/checkin', { method: 'POST', body: item });
        } catch (error) {
          if (error.code === 'duplicate_checkin') {
            continue;
          }
          if (error.code === 'ticket_not_found') {
            continue;
          }
          nextQueue.push(item);
        }
      }

      state.queue = nextQueue;
      persistQueue();
      renderTicketMeta();
    } finally {
      state.queueBusy = false;
    }
  }

  function clearMemberLookupState(options = {}) {
    const preserveQuery = !!options.preserveQuery;
    state.memberLookupBusy = false;
    state.memberLookupResults = [];
    state.memberLookupCurrent = null;

    if (!preserveQuery) {
      state.memberLookupQuery = '';
      if (els.memberLookupQuery) {
        els.memberLookupQuery.value = '';
      }
    }

    if (els.memberLookupResults) {
      els.memberLookupResults.innerHTML = '';
    }
    clearMemberLookupDetail();
    if (els.memberLookupMeta) {
      els.memberLookupMeta.textContent = '';
    }
    setFeedback(els.memberLookupFeedback, '');
  }

  function memberLookupDetailPlaceholderHtml(message = 'Search above and tap a result to open Member Details and edit options.') {
    return `
      <div class="vms-ops-member-lookup-detail-card is-placeholder">
        <p class="vms-ops-member-lookup-detail-label">Member Details</p>
        <strong>Select a member above</strong>
        <p class="vms-ops-member-lookup-detail-copy">${escapeHtml(message)}</p>
      </div>
    `;
  }

  function clearMemberLookupDetail(message = '') {
    if (els.memberLookupDetailCard) {
      els.memberLookupDetailCard.innerHTML = memberLookupDetailPlaceholderHtml(
        String(message || '').trim() !== ''
          ? String(message || '').trim()
          : 'Search above and tap a result to open Member Details and edit options.'
      );
    }
    if (els.memberLookupDetail) {
      els.memberLookupDetail.hidden = false;
    }
    state.memberLookupCurrent = null;
  }

  function renderMemberLookupMeta(totalMatches = 0, truncated = false) {
    if (!els.memberLookupMeta) {
      return;
    }

    const total = Number.parseInt(String(totalMatches || '0'), 10) || 0;
    if (total <= 0) {
      els.memberLookupMeta.textContent = '';
      return;
    }

    const metaParts = [`${total} match${total === 1 ? '' : 'es'} found`];
    if (truncated) {
      metaParts.push('showing the best matches first');
    }
    els.memberLookupMeta.textContent = metaParts.join(' • ');
  }

  function clearMemberLookupTourHighlights() {
    document.querySelectorAll('.vms-tour-highlight').forEach((element) => {
      element.classList.remove('vms-tour-highlight');
    });
  }

  function closeMemberLookupTour() {
    clearMemberLookupTourHighlights();
    if (memberLookupTourOverlay && memberLookupTourOverlay.parentNode) {
      memberLookupTourOverlay.parentNode.removeChild(memberLookupTourOverlay);
    }
    memberLookupTourOverlay = null;
  }

  function getMemberLookupTourSteps() {
    const introSelector = '[data-tour-anchor="member-lookup-intro"]';
    const searchSelector = '[data-tour-anchor="member-lookup-search"]';
    const detailSelector = document.querySelector('[data-tour-anchor="member-lookup-detail"]')
      ? '[data-tour-anchor="member-lookup-detail"]'
      : introSelector;
    const actionSelector = document.querySelector('[data-tour-anchor="member-lookup-actions"]')
      ? '[data-tour-anchor="member-lookup-actions"]'
      : searchSelector;

    return [
      {
        selector: introSelector,
        title: 'Why this exists',
        body: 'Use Verified Lookup only when you already believe this is a known returning member. It is a convenience path, not a substitute for judgment or ID checks.'
      },
      {
        selector: searchSelector,
        title: 'Search carefully',
        body: 'Search by name, phone, member number, email, or DOB so you can narrow to the right record. If the match feels uncertain, stop and check ID now.'
      },
      {
        selector: detailSelector,
        title: 'Confirm DOB and record quality',
        body: 'Open the member record, compare the photo if one exists, and ask the member to state their DOB. Missing, stale, or incomplete records should push you back to an ID check.'
      },
      {
        selector: actionSelector,
        title: 'Use the confidence pause',
        body: 'Serve via Verified Lookup only after you confidently recognize the member and DOB matches. If you are not confident, use Check ID Now instead.'
      },
      {
        selector: actionSelector,
        title: 'Actions are logged',
        body: 'Opening a record, DOB failures, verified-lookup service, and Check ID Now decisions are all logged. The audit trail should make the choice visible after the shift.'
      },
      {
        selector: detailSelector,
        title: 'Photos stay optional',
        body: 'Profile photos are optional and consent-aware. A missing photo should increase caution, not create blind trust or replace DOB confirmation.'
      }
    ].filter((step) => document.querySelector(step.selector));
  }

  function renderMemberLookupTourStep() {
    if (!memberLookupTourOverlay) {
      return;
    }

    const steps = getMemberLookupTourSteps();
    if (steps.length === 0) {
      closeMemberLookupTour();
      return;
    }

    if (memberLookupTourStep < 0) {
      memberLookupTourStep = 0;
    }
    if (memberLookupTourStep >= steps.length) {
      memberLookupTourStep = steps.length - 1;
    }

    const step = steps[memberLookupTourStep];
    const target = document.querySelector(step.selector);
    clearMemberLookupTourHighlights();
    if (target) {
      target.classList.add('vms-tour-highlight');
      if (typeof target.scrollIntoView === 'function') {
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }

    const progress = memberLookupTourOverlay.querySelector('.vms-ops-tour-progress');
    const title = memberLookupTourOverlay.querySelector('.vms-ops-tour-title');
    const body = memberLookupTourOverlay.querySelector('.vms-ops-tour-body');
    const previous = memberLookupTourOverlay.querySelector('[data-tour-action="prev"]');
    const next = memberLookupTourOverlay.querySelector('[data-tour-action="next"]');

    if (progress) {
      progress.textContent = `Step ${memberLookupTourStep + 1} of ${steps.length}`;
    }
    if (title) {
      title.textContent = step.title;
    }
    if (body) {
      body.textContent = step.body;
    }
    if (previous) {
      previous.disabled = memberLookupTourStep === 0;
    }
    if (next) {
      next.textContent = memberLookupTourStep === (steps.length - 1) ? 'Finish' : 'Next';
    }
  }

  function openMemberLookupTour() {
    if (memberLookupTourOverlay) {
      renderMemberLookupTourStep();
      return;
    }

    memberLookupTourOverlay = document.createElement('div');
    memberLookupTourOverlay.className = 'vms-ops-tour-overlay';
    memberLookupTourOverlay.innerHTML = `
      <div class="vms-ops-tour-card" role="dialog" aria-modal="true" aria-labelledby="vms-ops-tour-title">
        <div class="vms-ops-tour-progress"></div>
        <h3 id="vms-ops-tour-title" class="vms-ops-tour-title"></h3>
        <p class="vms-ops-tour-body"></p>
        <div class="vms-ops-tour-actions">
          <button type="button" class="vms-ops-secondary" data-tour-action="prev">Back</button>
          <button type="button" data-tour-action="next">Next</button>
          <button type="button" class="vms-ops-secondary" data-tour-action="close">Close</button>
        </div>
      </div>
    `;

    memberLookupTourOverlay.addEventListener('click', (event) => {
      if (event.target === memberLookupTourOverlay) {
        closeMemberLookupTour();
      }
    });
    memberLookupTourOverlay.querySelector('[data-tour-action="prev"]')?.addEventListener('click', () => {
      memberLookupTourStep -= 1;
      renderMemberLookupTourStep();
    });
    memberLookupTourOverlay.querySelector('[data-tour-action="next"]')?.addEventListener('click', () => {
      const steps = getMemberLookupTourSteps();
      if (memberLookupTourStep >= (steps.length - 1)) {
        closeMemberLookupTour();
        return;
      }
      memberLookupTourStep += 1;
      renderMemberLookupTourStep();
    });
    memberLookupTourOverlay.querySelector('[data-tour-action="close"]')?.addEventListener('click', () => {
      closeMemberLookupTour();
    });

    document.body.appendChild(memberLookupTourOverlay);
    memberLookupTourStep = 0;
    renderMemberLookupTourStep();
  }

  function buildMemberLookupPhotoHtml(item, large = false) {
    const photoUrl = String(item?.photo_url || '').trim();
    const initials = String(item?.photo_initials || '').trim() || 'M';
    const className = large
      ? 'vms-ops-member-lookup-photo is-large'
      : 'vms-ops-member-lookup-photo';

    if (photoUrl) {
      const alt = String(item?.full_name || 'Member').trim() || 'Member';
      return `<img class="${className}" src="${escapeHtml(photoUrl)}" alt="${escapeHtml(alt)}" loading="lazy" />`;
    }

    return `<div class="${className} is-placeholder" aria-hidden="true">${escapeHtml(initials)}</div>`;
  }

  function buildMemberLookupPhotoPreviewHtml(item, large = false) {
    const photoUrl = String(item?.photo_url || '').trim();
    if (photoUrl === '') {
      return buildMemberLookupPhotoHtml(item, large);
    }

    const memberName = String(item?.full_name || 'Member').trim() || 'Member';
    return `
      <button
        type="button"
        class="vms-ops-member-lookup-photo-button"
        data-member-photo-preview="${escapeHtml(photoUrl)}"
        aria-label="${escapeHtml(`Preview profile photo for ${memberName}`)}"
      >
        ${buildMemberLookupPhotoHtml(item, large)}
      </button>
    `;
  }

  function ensureMemberLookupPhotoModal() {
    let modal = document.getElementById('vms-ops-member-photo-preview-modal');
    if (modal) {
      return modal;
    }

    modal = document.createElement('div');
    modal.id = 'vms-ops-member-photo-preview-modal';
    modal.className = 'vms-ops-member-photo-preview-modal';
    modal.hidden = true;
    modal.innerHTML = `
      <div class="vms-ops-member-photo-preview-card" role="dialog" aria-modal="true" aria-labelledby="vms-ops-member-photo-preview-title">
        <div class="vms-ops-member-photo-preview-head">
          <h3 id="vms-ops-member-photo-preview-title">Profile Photo</h3>
          <button type="button" class="vms-ops-member-photo-preview-close" aria-label="Close profile photo preview">Close</button>
        </div>
        <div class="vms-ops-member-photo-preview-body">
          <img alt="" />
        </div>
      </div>
    `;

    modal.addEventListener('click', (event) => {
      if (event.target === modal) {
        closeMemberLookupPhotoPreview();
      }
    });
    modal.querySelector('.vms-ops-member-photo-preview-close')?.addEventListener('click', () => {
      closeMemberLookupPhotoPreview();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !modal.hidden) {
        closeMemberLookupPhotoPreview();
      }
    });

    document.body.appendChild(modal);
    return modal;
  }

  function openMemberLookupPhotoPreview(item = {}) {
    const photoUrl = String(item?.photo_url || '').trim();
    if (photoUrl === '') {
      return;
    }

    const modal = ensureMemberLookupPhotoModal();
    const image = modal.querySelector('img');
    const title = modal.querySelector('#vms-ops-member-photo-preview-title');
    const closeButton = modal.querySelector('.vms-ops-member-photo-preview-close');
    const memberName = String(item?.full_name || 'Member').trim() || 'Member';

    if (image) {
      image.src = photoUrl;
      image.alt = memberName;
    }
    if (title) {
      title.textContent = memberName;
    }

    modal.hidden = false;
    closeButton?.focus();
  }

  function closeMemberLookupPhotoPreview() {
    const modal = document.getElementById('vms-ops-member-photo-preview-modal');
    if (!modal) {
      return;
    }

    const image = modal.querySelector('img');
    if (image) {
      image.removeAttribute('src');
      image.alt = '';
    }
    modal.hidden = true;
  }

  function renderMemberLookupResults(items = []) {
    if (!els.memberLookupResults) {
      return;
    }

    if (!Array.isArray(items) || items.length === 0) {
      els.memberLookupResults.innerHTML = `
        <div class="vms-ops-member-lookup-empty">
          <strong>No matching members found.</strong>
          <span>Use Member Lookup only for known returning members. If the match is uncertain, check ID now.</span>
        </div>
      `;
      return;
    }

    els.memberLookupResults.innerHTML = items.map((item) => {
      const decisionStatusLabel = getMemberLookupDecisionStatusLabel(item);
      const memberNumber = String(item?.member_number || '').trim();
      const statusLabel = String(item?.status_label || item?.status || '').trim();
      const primaryReason = !item?.allow_lookup ? getMemberLookupPrimaryReason(item) : '';
      const showStatusBadge = statusLabel !== '' && statusLabel.toLowerCase() !== 'active';

      return `
        <button type="button" class="vms-ops-member-lookup-card is-${escapeHtml(String(item.lookup_level || 'caution'))}" data-lookup-member-open="${escapeHtml(String(item.id || '0'))}">
          <div class="vms-ops-member-lookup-card-photo">
            ${buildMemberLookupPhotoHtml(item)}
          </div>
          <div class="vms-ops-member-lookup-card-copy">
            <div class="vms-ops-member-lookup-card-badges">
              <span class="vms-ops-member-lookup-status is-${escapeHtml(String(item.lookup_level || 'caution'))}">${escapeHtml(decisionStatusLabel)}</span>
              ${showStatusBadge ? `<span class="vms-ops-badge">${escapeHtml(statusLabel)}</span>` : ''}
            </div>
            <p class="vms-ops-member-lookup-card-name"><strong>${escapeHtml(String(item.full_name || 'Member'))}</strong></p>
            <p class="vms-ops-member-lookup-card-meta">${escapeHtml(memberNumber !== '' ? `#${memberNumber}` : 'Member # unavailable')}</p>
            <p class="vms-ops-member-lookup-card-meta">${escapeHtml(String(item.dob_display || 'Missing DOB'))} • ${escapeHtml(String(item.age_label || 'Age unknown'))}</p>
            ${primaryReason ? `<p class="vms-ops-member-lookup-card-note is-danger">${escapeHtml(primaryReason)}</p>` : ''}
            <p class="vms-ops-member-lookup-card-meta vms-ops-member-lookup-card-action">Tap to open Member Details</p>
          </div>
        </button>
      `;
    }).join('');
  }

  async function deleteMemberRecord(memberId, options = {}) {
    const safeMemberId = Number.parseInt(String(memberId || '0'), 10);
    if (!canDeleteMembers()) {
      throw new Error('Only admins can delete members.');
    }
    if (Number.isNaN(safeMemberId) || safeMemberId <= 0) {
      throw new Error('Select a valid member first.');
    }

    const memberName = String(options.memberName || '').trim();
    const confirmMessage = memberName !== ''
      ? `Delete ${memberName}? This permanently removes the member record so the ID can be added again only by creating a new member.`
      : 'Delete this member? This removes the member record so the ID can be added again.';

    if (typeof window.confirm === 'function' && !window.confirm(confirmMessage)) {
      return null;
    }

    if (memberName !== '') {
      if (typeof window.prompt === 'function') {
        const typedName = window.prompt(`Type "${memberName}" to confirm member deletion.`, '');
        if (typedName === null) {
          return null;
        }
        if (typedName.trim().toLowerCase() !== memberName.toLowerCase()) {
          throw new Error('Delete cancelled. Member name did not match.');
        }
      } else if (typeof window.confirm === 'function' && !window.confirm(`Delete ${memberName} permanently? This cannot be undone.`)) {
        return null;
      }
    }

    return api(`/members/${encodeURIComponent(String(safeMemberId))}`, {
      method: 'DELETE',
      body: {
        venue_id: getVenueId(true)
      }
    });
  }

  function getMemberEditorState(source = {}) {
    const address = source?.address && typeof source.address === 'object' ? source.address : {};
    return {
      status: normalizeMemberStatus(source?.status),
      vip: !!source?.vip,
      has_photo: !!source?.has_photo || String(source?.photo_url || '').trim() !== '',
      photo_consent: !!source?.photo_consent,
      photo_url: String(source?.photo_url || '').trim(),
      address_line_1: String(address.address_line_1 || '').trim(),
      address_line_2: String(address.address_line_2 || '').trim(),
      city: String(address.city || '').trim(),
      state: String(address.state || '').trim(),
      postal_code: String(address.postal_code || '').trim()
    };
  }

  function buildMemberEditorHtml(source = {}, options = {}) {
    const memberId = Number.parseInt(String(source?.id || source?.member_id || '0'), 10);
    if (Number.isNaN(memberId) || memberId <= 0) {
      return '';
    }

    const canEditFullMember = canEditMembers();
    const canManagePhotos = canManageMemberPhotos();
    const stateValue = getMemberEditorState(source);
    const fullName = String(
      options.memberName
      || source?.full_name
      || `${String(source?.first_name || '').trim()} ${String(source?.last_name || '').trim()}`
    ).trim() || 'Member';
    const memberNumber = String(source?.member_number || '').trim();
    const photoEnabled = !!config.settings?.member_lookup_allow_profile_photo && canManagePhotos;
    if (!canEditFullMember && !photoEnabled) {
      return '';
    }

    const photoLabel = stateValue.has_photo ? 'Replace or Take Profile Photo' : 'Upload or Take Profile Photo';
    const photoInitials = String(source?.photo_initials || '').trim()
      || fullName.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part.charAt(0).toUpperCase()).join('');
    const photoCaptureMode = normalizeMemberPhotoCaptureMode('environment');
    const deleteHtml = canDeleteMembers()
      ? `
        <button type="button" class="vms-ops-secondary vms-ops-danger-button" data-member-editor-delete="${escapeHtml(String(memberId))}" data-member-name="${escapeHtml(fullName)}">
          ${escapeHtml('Delete Member')}
        </button>
      `
      : '';
    const photoHtml = photoEnabled ? `
      <div class="vms-ops-member-editor-photo">
        <div class="vms-ops-member-editor-photo-head">
          ${buildMemberLookupPhotoHtml({
            photo_url: stateValue.photo_url,
            photo_initials: photoInitials
          })}
          <div class="vms-ops-member-editor-photo-copy">
            <strong>${escapeHtml('Profile Photo')}</strong>
            <p class="vms-ops-member-editor-photo-help">${escapeHtml('Point the camera at the member, take the photo, then save. JPG, HEIC, PNG, or WebP up to 10 MB. Photos are downsized before upload when possible.')}</p>
          </div>
        </div>
        <div class="vms-ops-member-photo-camera-row">
          <span class="vms-ops-mini" data-member-photo-camera-label>${escapeHtml(`Default: ${getMemberPhotoCaptureLabel(photoCaptureMode)}`)}</span>
          <button type="button" class="vms-ops-secondary" data-member-photo-switch>${escapeHtml('Switch Camera')}</button>
        </div>
        <label class="vms-ops-file-field">
          <span>${escapeHtml(photoLabel)}</span>
          <input name="profile_photo" type="file" accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.heic,.heif" capture="${escapeHtml(photoCaptureMode)}" data-camera-preference="${escapeHtml(photoCaptureMode)}" />
        </label>
        <label class="vms-ops-inline-check vms-ops-member-editor-toggle">
          <input name="photo_consent" type="checkbox" value="1"${stateValue.photo_consent || stateValue.has_photo ? ' checked' : ''} />
          <span>Member consented to store a profile photo for identity confirmation</span>
        </label>
        ${stateValue.has_photo ? `
          <button type="button" class="vms-ops-secondary" data-member-photo-remove="${escapeHtml(String(memberId))}" data-member-name="${escapeHtml(fullName)}">
            ${escapeHtml('Remove Photo')}
          </button>
        ` : ''}
      </div>
    ` : '';
    const memberSettingsHtml = canEditFullMember ? `
      <div class="vms-ops-member-editor-grid">
        <label>
          <span>Status</span>
          <select name="status">
            <option value="active"${stateValue.status === 'active' ? ' selected' : ''}>Active</option>
            <option value="suspended"${stateValue.status === 'suspended' ? ' selected' : ''}>Suspended</option>
            <option value="banned"${stateValue.status === 'banned' ? ' selected' : ''}>Banned</option>
          </select>
        </label>
        <label>
          <span>Address Line 1</span>
          <input name="address_line_1" type="text" value="${escapeHtml(stateValue.address_line_1)}" />
        </label>
        <label>
          <span>Address Line 2</span>
          <input name="address_line_2" type="text" value="${escapeHtml(stateValue.address_line_2)}" />
        </label>
        <label>
          <span>City</span>
          <input name="city" type="text" value="${escapeHtml(stateValue.city)}" />
        </label>
        <label>
          <span>State</span>
          <input name="state" type="text" value="${escapeHtml(stateValue.state)}" />
        </label>
        <label>
          <span>Postal Code</span>
          <input name="postal_code" type="text" value="${escapeHtml(stateValue.postal_code)}" />
        </label>
      </div>
      <label class="vms-ops-inline-check vms-ops-member-editor-toggle">
        <input name="vip" type="checkbox" value="1"${stateValue.vip ? ' checked' : ''} />
        <span>VIP Member</span>
      </label>
      <label class="vms-ops-member-editor-reason">
        <span>Suspension / Ban Reason</span>
        <textarea name="status_reason" rows="2" placeholder="${escapeHtml('Optional note when suspending or banning a member')}"></textarea>
      </label>
    ` : '';

    return `
      <details class="vms-ops-member-editor">
        <summary>${escapeHtml(canEditFullMember ? 'Edit Member' : 'Profile Photo')}</summary>
        <form class="vms-ops-member-editor-form" data-member-editor="${escapeHtml(String(memberId))}">
          <p class="vms-ops-member-editor-summary">
            ${escapeHtml(fullName)}${memberNumber !== '' ? ` · #${escapeHtml(memberNumber)}` : ''}
          </p>
          ${memberSettingsHtml}
          ${photoHtml}
          <div class="vms-ops-member-editor-actions">
            <button type="submit">${escapeHtml(canEditFullMember ? 'Save Member Changes' : 'Save Profile Photo')}</button>
            <button type="reset" class="vms-ops-secondary">${escapeHtml('Reset')}</button>
            ${deleteHtml}
          </div>
          <p class="vms-ops-feedback" data-member-editor-feedback aria-live="polite"></p>
        </form>
      </details>
    `;
  }

  function attachMemberEditorHandlers(form, options = {}) {
    if (!form) {
      return;
    }

    const memberId = Number.parseInt(String(form.getAttribute('data-member-editor') || '0'), 10);
    if (Number.isNaN(memberId) || memberId <= 0) {
      return;
    }

    const feedbackEl = form.querySelector('[data-member-editor-feedback]');
    const controls = Array.from(form.querySelectorAll('input, select, textarea, button'));
    const originalState = getMemberEditorState(options.member || {});
    const deleteButton = form.querySelector('[data-member-editor-delete]');
    const removePhotoButton = form.querySelector('[data-member-photo-remove]');
    const hasFullEditControls = !!form.elements.status;

    attachMemberPhotoCaptureControls(form);

    const setBusy = (busy) => {
      controls.forEach((control) => {
        control.disabled = !!busy;
      });
      if (typeof options.onBusyChange === 'function') {
        options.onBusyChange(!!busy);
      }
    };

    form.addEventListener('reset', () => {
      window.requestAnimationFrame(() => {
        setFeedback(feedbackEl, '');
      });
    });

    const uploadSelectedPhoto = async (photoFile, photoConsent, currentMember) => {
      let preparedPhotoUpload = null;

      if (!(photoFile instanceof File) || photoFile.name === '' || photoFile.size <= 0) {
        return currentMember;
      }

      if (!canManageMemberPhotos()) {
        throw new Error(getMemberPhotoUploadDisabledMessage());
      }

      if (!photoConsent) {
        throw new Error('Profile photo consent is required before saving a member photo.');
      }

      const largeOriginal = photoFile.size > (5 * 1024 * 1024);
      setFeedback(feedbackEl, largeOriginal ? 'Preparing photo - large image detected' : 'Preparing photo');
      try {
        preparedPhotoUpload = await optimizePhotoUpload(photoFile, {
          maxDimension: 1280,
          quality: 0.72
        });
      } catch (_error) {
        if (photoFile.size > (10 * 1024 * 1024)) {
          const tooLargeError = new Error('Image too large');
          tooLargeError.code = 'profile_photo_too_large';
          throw tooLargeError;
        }

        preparedPhotoUpload = {
          blob: photoFile,
          filename: photoFile.name,
          originalSize: photoFile.size,
          outputSize: photoFile.size,
          usedFallback: true
        };
      }

      const uploadBody = new FormData();
      uploadBody.append('photo_consent', photoConsent ? '1' : '0');
      uploadBody.append(
        'profile_photo',
        preparedPhotoUpload && preparedPhotoUpload.blob ? preparedPhotoUpload.blob : photoFile,
        preparedPhotoUpload && preparedPhotoUpload.filename ? preparedPhotoUpload.filename : photoFile.name
      );
      setFeedback(feedbackEl, buildPhotoStageMessage('Uploading', preparedPhotoUpload));
      const data = await api(`/members/${memberId}/photo`, {
        method: 'POST',
        body: uploadBody,
        formData: true
      });

      return {
        ...currentMember,
        ...(data?.member || {}),
        ...(data?.item || {})
      };
    };

    removePhotoButton?.addEventListener('click', async () => {
      const memberName = String(removePhotoButton.getAttribute('data-member-name') || options.member?.full_name || 'this member').trim();
      const confirmed = typeof window.confirm !== 'function'
        || window.confirm(`Remove the profile photo for ${memberName || 'this member'}?`);
      if (!confirmed) {
        return;
      }

      setBusy(true);
      setFeedback(feedbackEl, 'Removing profile photo...');

      try {
        const data = await api(`/members/${memberId}/photo`, {
          method: 'DELETE',
          body: {
            venue_id: getVenueId(true)
          }
        });
        const updatedMember = {
          ...(options.member || {}),
          ...(data?.member || {}),
          ...(data?.item || {})
        };
        setFeedback(feedbackEl, 'Profile photo removed.');
        showGlobalFeedback('Profile photo removed.');

        if (typeof options.onSaved === 'function') {
          await options.onSaved(updatedMember);
        }
      } catch (error) {
        setFeedback(feedbackEl, mapProfilePhotoUploadMessage(error), true);
      } finally {
        setBusy(false);
      }
    });

    deleteButton?.addEventListener('click', async () => {
      setBusy(true);
      setFeedback(feedbackEl, 'Deleting member...');

      try {
        const deleted = await deleteMemberRecord(memberId, {
          memberName: String(deleteButton.getAttribute('data-member-name') || '').trim()
        });
        if (!deleted) {
          setFeedback(feedbackEl, '');
          return;
        }

        if (typeof options.onDeleted === 'function') {
          await options.onDeleted(deleted);
        }
      } catch (error) {
        setFeedback(feedbackEl, error.message, true);
      } finally {
        setBusy(false);
      }
    });

    form.addEventListener('submit', async (event) => {
      event.preventDefault();

      const nextState = {
        status: hasFullEditControls ? normalizeMemberStatus(form.elements.status?.value) : originalState.status,
        vip: hasFullEditControls ? !!form.elements.vip?.checked : originalState.vip,
        address_line_1: hasFullEditControls ? String(form.elements.address_line_1?.value || '').trim() : originalState.address_line_1,
        address_line_2: hasFullEditControls ? String(form.elements.address_line_2?.value || '').trim() : originalState.address_line_2,
        city: hasFullEditControls ? String(form.elements.city?.value || '').trim() : originalState.city,
        state: hasFullEditControls ? String(form.elements.state?.value || '').trim() : originalState.state,
        postal_code: hasFullEditControls ? String(form.elements.postal_code?.value || '').trim() : originalState.postal_code,
        status_reason: hasFullEditControls ? String(form.elements.status_reason?.value || '').trim() : ''
      };
      const photoConsent = !!form.elements.photo_consent?.checked;
      const photoFile = form.elements.profile_photo?.files?.[0] || null;
      const hasPhotoUpload = photoFile instanceof File && photoFile.name !== '' && photoFile.size > 0;

      const statusChanged = hasFullEditControls && nextState.status !== originalState.status;
      const vipChanged = hasFullEditControls && nextState.vip !== originalState.vip;
      const addressChanged = hasFullEditControls && (
        nextState.address_line_1 !== originalState.address_line_1
        || nextState.address_line_2 !== originalState.address_line_2
        || nextState.city !== originalState.city
        || nextState.state !== originalState.state
        || nextState.postal_code !== originalState.postal_code
      );

      if (hasPhotoUpload && !photoConsent) {
        setFeedback(feedbackEl, 'Profile photo consent is required before saving a member photo.', true);
        return;
      }

      if (!statusChanged && !vipChanged && !addressChanged && !hasPhotoUpload) {
        setFeedback(feedbackEl, 'No member changes to save.');
        return;
      }

      setBusy(true);
      setFeedback(feedbackEl, 'Saving member changes...');

      try {
        let updatedMember = { ...(options.member || {}) };

        if (statusChanged) {
          const data = await api(`/members/${memberId}/status`, {
            method: 'PATCH',
            body: {
              status: nextState.status,
              reason: nextState.status_reason
            }
          });
          updatedMember = { ...updatedMember, ...(data?.member || {}) };
        }

        if (vipChanged) {
          const data = await api(`/members/${memberId}/vip`, {
            method: 'PATCH',
            body: {
              vip: nextState.vip ? 1 : 0
            }
          });
          updatedMember = { ...updatedMember, ...(data?.member || {}) };
        }

        if (addressChanged) {
          const data = await api(`/members/${memberId}/address`, {
            method: 'PATCH',
            body: {
              address_line_1: nextState.address_line_1,
              address_line_2: nextState.address_line_2,
              city: nextState.city,
              state: nextState.state,
              postal_code: nextState.postal_code
            }
          });
          updatedMember = { ...updatedMember, ...(data?.member || {}) };
        }

        if (hasPhotoUpload) {
          updatedMember = await uploadSelectedPhoto(photoFile, photoConsent, updatedMember);
        }

        setFeedback(feedbackEl, 'Member updated.');
        showGlobalFeedback('Member updated.');

        if (typeof options.onSaved === 'function') {
          await options.onSaved(updatedMember);
        }
      } catch (error) {
        const message = hasPhotoUpload ? mapProfilePhotoUploadMessage(error) : error.message;
        setFeedback(feedbackEl, message, true);
      } finally {
        setBusy(false);
      }
    });
  }

  function renderIdRecheckContext(context = null) {
    state.idRecheckContext = context && typeof context === 'object' ? { ...context } : null;
    if (!els.idRecheckContext) {
      return;
    }

    if (!state.idRecheckContext) {
      els.idRecheckContext.hidden = true;
      els.idRecheckContext.innerHTML = '';
      return;
    }

    const memberName = String(state.idRecheckContext.member_name || 'Selected member').trim() || 'Selected member';
    const memberNumber = String(state.idRecheckContext.member_number || '').trim();
    const reasonCode = String(state.idRecheckContext.reason_code || '').trim();
    const reasonMessage = reasonCode === 'dob_mismatch'
      ? 'DOB mismatch logged.'
      : (reasonCode === 'missing_photo'
        ? 'No profile photo on file.'
        : (reasonCode === 'expired_member'
          ? 'Membership is expired.'
          : (reasonCode === 'missing_verification' || reasonCode === 'stale_verification'
            ? 'Prior verification is missing or stale.'
            : (reasonCode === 'inactive_member'
              ? 'Membership is not active.'
              : (reasonCode === 'missing_dob'
                ? 'DOB is missing from the member record.'
                : 'Carry this member through the ID recheck.')))));

    els.idRecheckContext.hidden = false;
    els.idRecheckContext.innerHTML = `
      <strong>ID Recheck Pending</strong>
      <span>${escapeHtml(memberName)}${memberNumber !== '' ? ` (${escapeHtml(memberNumber)})` : ''}</span>
      <span>${escapeHtml(reasonMessage)}</span>
    `;
  }

  function openIdRecheckFlow(reasonCode = '', context = null) {
    const reason = String(reasonCode || '').trim();
    if (config.caps?.scanIds && els.idPanel && !els.idPanel.hidden) {
      renderIdRecheckContext(context && typeof context === 'object'
        ? {
          member_id: context.member_id || context.id || 0,
          member_name: context.member_name || context.full_name || '',
          member_number: context.member_number || '',
          reason_code: reason
        }
        : null);
      setIdCollapsed(false);
      if (typeof els.idPanel.scrollIntoView === 'function') {
        els.idPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      let nextMessage = 'Ready to recheck the ID now.';
      if (reason === 'dob_mismatch') {
        nextMessage = 'DOB mismatch logged. Recheck the ID now.';
      } else if (reason === 'missing_verification' || reason === 'stale_verification') {
        nextMessage = 'Prior verification is missing or stale. Recheck the ID now.';
      } else if (reason === 'expired_member') {
        nextMessage = 'Membership is expired. ID required. Check the ID now.';
      } else if (reason === 'missing_photo') {
        nextMessage = 'No profile photo on file. Check the ID now.';
      } else if (reason === 'inactive_member') {
        nextMessage = 'Membership is not active. Recheck the ID now.';
      } else if (reason === 'missing_dob') {
        nextMessage = 'DOB is missing from the member record. Recheck the ID now.';
      }
      setFeedback(els.idFeedback, nextMessage);
      return;
    }

    showGlobalFeedback('Ask a staff member with ID scan access to recheck the ID now.', true);
  }

  function syncMemberLookupServeButton() {
    if (!els.memberLookupDetailCard) {
      return;
    }

    const serveButton = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-serve');
    if (!serveButton) {
      return;
    }

    const detail = state.memberLookupCurrent || {};
    const confidence = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-confidence');
    const photoMatch = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-photo-match');
    const dobInput = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-dob-input');
    const dobState = getMemberLookupDobState(dobInput ? dobInput.value : '');
    const photoMatchAvailable = !!detail.photo_match_available;

    let disabled = !detail.allow_lookup || state.memberLookupBusy;
    if (!disabled && photoMatchAvailable) {
      disabled = !(photoMatch && photoMatch.checked) && !dobState.isComplete;
    }
    if (!disabled && detail.requires_confidence) {
      disabled = !(confidence && confidence.checked);
    }
    if (!disabled && detail.requires_dob_entry) {
      disabled = !dobState.isComplete;
    }

    serveButton.disabled = !!disabled;
  }

  function getMemberLookupDecisionStatusLabel(item = {}) {
    if (!item || typeof item !== 'object') {
      return 'Lookup OK';
    }

    const lookupStatusKey = String(item.lookup_status_key || '').trim();
    if (lookupStatusKey === 'id_required') {
      return 'ID Required';
    }
    if (lookupStatusKey === 'needs_caution') {
      return 'Needs Caution';
    }
    if (lookupStatusKey === 'dob_confirm') {
      return 'DOB Confirm';
    }
    if (lookupStatusKey === 'lookup_ok') {
      return 'Lookup OK';
    }

    if (!item.allow_lookup) {
      return 'ID Required';
    }

    if (Number.parseInt(String(item.duplicate_count || '0'), 10) > 1 || String(item.lookup_caution_note || '').trim() !== '') {
      return 'Needs Caution';
    }

    if (item.requires_dob_entry) {
      return 'DOB Confirm';
    }

    return 'Lookup OK';
  }

  function getMemberLookupDetailWarnings(item = {}) {
    const warnings = Array.isArray(item?.warnings) ? item.warnings : [];
    const cautionNote = String(item?.lookup_caution_note || '').trim();

    return warnings.filter((warning) => {
      const text = String(warning || '').trim();
      if (text === '') {
        return false;
      }
      if (text === 'No profile photo is on file.') {
        return false;
      }
      if (cautionNote !== '' && text === cautionNote) {
        return false;
      }
      return true;
    });
  }

  function getMemberLookupPrimaryReason(item = {}) {
    const warnings = getMemberLookupDetailWarnings(item);
    return warnings.length > 0 ? String(warnings[0] || '').trim() : '';
  }

  function buildMemberLookupDetailRow(label, value, className = '') {
    return `
      <div class="vms-ops-member-lookup-detail-row${className ? ` ${className}` : ''}">
        <span>${escapeHtml(String(label || '').trim())}</span>
        <strong>${escapeHtml(String(value || '').trim())}</strong>
      </div>
    `;
  }

  function renderMemberLookupDetail(item) {
    if (!els.memberLookupDetail || !els.memberLookupDetailCard || !item || typeof item !== 'object') {
      return;
    }

    renderIdRecheckContext(null);
    state.memberLookupCurrent = item;
    const warnings = getMemberLookupDetailWarnings(item);
    const warningsHtml = warnings.length
      ? `<ul class="vms-ops-member-lookup-warnings">${warnings.map((warning) => `<li>${escapeHtml(String(warning || ''))}</li>`).join('')}</ul>`
      : '';
    const notesHtml = String(item.notes || '').trim() !== ''
      ? `<div class="vms-ops-member-lookup-note">${escapeHtml(String(item.notes || '').trim())}</div>`
      : '';
    const cautionNoteHtml = String(item.lookup_caution_note || '').trim() !== ''
      ? `<div class="vms-ops-member-lookup-note is-warning">${escapeHtml(String(item.lookup_caution_note || '').trim())}</div>`
      : '';
    const requiresDob = !!item.requires_dob_entry;
    const requiresConfidence = !!item.requires_confidence;
    const photoMatchAvailable = !!item.photo_match_available;
    const decisionStatusLabel = getMemberLookupDecisionStatusLabel(item);
    const memberNumber = String(item.member_number || '').trim();
    const memberNumberDisplay = memberNumber !== '' ? `#${memberNumber}` : 'Member # unavailable';
    const primaryReason = !item.allow_lookup ? getMemberLookupPrimaryReason(item) : '';
    const detailFactsHtml = `
      <div class="vms-ops-member-lookup-detail-rows">
        ${buildMemberLookupDetailRow('Member #', memberNumberDisplay)}
        ${buildMemberLookupDetailRow('DOB', String(item.dob_display || 'Missing DOB'))}
        ${buildMemberLookupDetailRow('Age / 21+', String(item.age_label || 'Age unknown'))}
        ${buildMemberLookupDetailRow('Status', String(item.status_label || item.status || 'Member'))}
      </div>
    `;
    const moreFacts = [
      buildMemberLookupDetailRow('Last Verified', String(item.last_verified_display || 'Never')),
      buildMemberLookupDetailRow('Last Visit', String(item.last_visit_display || 'No visit logged')),
      buildMemberLookupDetailRow('Last Lookup', String(item.last_lookup_display || 'No lookup logged'))
    ].join('');
    const moreDetailsHtml = (warningsHtml !== '' || cautionNoteHtml !== '' || notesHtml !== '' || moreFacts !== '')
      ? `
        <details class="vms-ops-member-lookup-more">
          <summary>More Details</summary>
          <div class="vms-ops-member-lookup-detail-rows is-secondary">
            ${moreFacts}
          </div>
          ${warningsHtml}
          ${cautionNoteHtml}
          ${notesHtml}
        </details>
      `
      : '';
    const editorHtml = buildMemberEditorHtml(item, {
      memberName: String(item.full_name || 'Member').trim()
    });

    els.memberLookupDetailCard.innerHTML = `
      <div class="vms-ops-member-lookup-detail-card">
        <p class="vms-ops-member-lookup-detail-label">Member Details</p>
        <h3 class="vms-ops-member-lookup-detail-name">${escapeHtml(String(item.full_name || 'Member'))}</h3>
        <div class="vms-ops-member-lookup-primary" data-tour-anchor="member-lookup-detail">
          <div class="vms-ops-member-lookup-primary-photo">
            ${buildMemberLookupPhotoPreviewHtml(item, true)}
          </div>
          <div class="vms-ops-member-lookup-primary-copy">
            ${detailFactsHtml}
            <div class="vms-ops-member-lookup-primary-status">
              <span class="vms-ops-member-lookup-status is-${escapeHtml(String(item.lookup_level || 'caution'))}">${escapeHtml(decisionStatusLabel)}</span>
              ${primaryReason ? `<p class="vms-ops-member-lookup-primary-note">${escapeHtml(primaryReason)}</p>` : ''}
            </div>
          </div>
        </div>
        ${moreDetailsHtml}
        ${editorHtml}
        <div class="vms-ops-member-lookup-confirm">
          ${photoMatchAvailable ? `
            <label class="vms-ops-inline-check vms-ops-member-lookup-confidence">
              <input id="vms-ops-member-lookup-photo-match" type="checkbox" />
              <span>Photo matches this member</span>
            </label>
            <details class="vms-ops-member-lookup-dob-optional">
              <summary>${escapeHtml('Use DOB instead')}</summary>
              <label for="vms-ops-member-lookup-dob-input"><strong>Ask the member to state their date of birth.</strong></label>
              <input id="vms-ops-member-lookup-dob-input" type="text" inputmode="numeric" autocomplete="off" autocapitalize="off" spellcheck="false" maxlength="10" enterkeyhint="done" placeholder="MM/DD/YYYY" />
              <p class="vms-ops-mini">Enter 8 digits: MMDDYYYY</p>
              <p id="vms-ops-member-lookup-dob-feedback" class="vms-ops-feedback vms-ops-member-lookup-dob-feedback" aria-live="polite"></p>
            </details>
          ` : requiresDob ? `
            <label for="vms-ops-member-lookup-dob-input"><strong>Ask the member to state their date of birth.</strong></label>
            <input id="vms-ops-member-lookup-dob-input" type="text" inputmode="numeric" autocomplete="off" autocapitalize="off" spellcheck="false" maxlength="10" enterkeyhint="done" placeholder="MM/DD/YYYY" />
            <p class="vms-ops-mini">Enter 8 digits: MMDDYYYY</p>
            <p id="vms-ops-member-lookup-dob-feedback" class="vms-ops-feedback vms-ops-member-lookup-dob-feedback" aria-live="polite"></p>
          ` : `
            <p class="vms-ops-mini">DOB entry is disabled here, but staff must still verbally confirm DOB before using lookup.</p>
          `}
          ${photoMatchAvailable ? '' : `
            <label class="vms-ops-inline-check vms-ops-member-lookup-confidence">
              <input id="vms-ops-member-lookup-confidence" type="checkbox" ${requiresConfidence ? '' : 'checked'} />
              <span>I confidently recognize this member and confirmed DOB</span>
            </label>
          `}
        </div>
        <div class="vms-ops-member-lookup-actions" data-tour-anchor="member-lookup-actions">
          <button id="vms-ops-member-lookup-serve" type="button">${escapeHtml('Serve via Verified Lookup')}</button>
          <button id="vms-ops-member-lookup-check-id" type="button" class="vms-ops-secondary">${escapeHtml('Check ID Now')}</button>
          <button id="vms-ops-member-lookup-cancel" type="button" class="vms-ops-secondary">${escapeHtml('Cancel')}</button>
        </div>
        <p id="vms-ops-member-lookup-decision-feedback" class="vms-ops-feedback" aria-live="polite"></p>
      </div>
    `;

    els.memberLookupDetail.hidden = false;
    if (typeof els.memberLookupDetail.scrollIntoView === 'function') {
      els.memberLookupDetail.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    const serveButton = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-serve');
    const checkIdButton = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-check-id');
    const cancelButton = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-cancel');
    const feedbackEl = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-decision-feedback');
    const confidence = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-confidence');
    const photoMatch = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-photo-match');
    const dobInput = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-dob-input');
    const dobFeedback = els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-dob-feedback');
    const editorForm = els.memberLookupDetailCard.querySelector('[data-member-editor]');
    const photoPreviewButton = els.memberLookupDetailCard.querySelector('[data-member-photo-preview]');
    const syncDob = (options = {}) => {
      syncMemberLookupDobInput(dobInput, dobFeedback, {
        optionalInput: photoMatchAvailable,
        ...options
      });
      syncMemberLookupServeButton();
    };

    photoPreviewButton?.addEventListener('click', () => {
      openMemberLookupPhotoPreview(item);
    });
    confidence?.addEventListener('change', syncMemberLookupServeButton);
    photoMatch?.addEventListener('change', syncMemberLookupServeButton);
    dobInput?.addEventListener('beforeinput', (event) => {
      if (applyMemberLookupDobEdit(dobInput, event)) {
        syncDob();
      }
    });
    dobInput?.addEventListener('input', () => {
      syncDob();
    });
    dobInput?.addEventListener('blur', () => {
      syncDob();
    });
    dobInput?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        if (serveButton && !serveButton.disabled) {
          serveButton.click();
        }
      }
    });
    serveButton?.addEventListener('click', () => {
      submitMemberLookupDecision('serve').catch((error) => {
        setFeedback(els.memberLookupFeedback, error.message, true);
      });
    });
    checkIdButton?.addEventListener('click', () => {
      submitMemberLookupDecision('check_id_now', 'staff_selected_id_check').catch((error) => {
        setFeedback(els.memberLookupFeedback, error.message, true);
      });
    });
    cancelButton?.addEventListener('click', () => {
      clearMemberLookupDetail();
      setFeedback(els.memberLookupFeedback, 'Member lookup cleared.');
      focusMemberLookupQuery();
    });
    attachMemberEditorHandlers(editorForm, {
      member: item,
      onBusyChange: (busy) => {
        if (serveButton) {
          serveButton.disabled = !!busy;
        }
        if (checkIdButton) {
          checkIdButton.disabled = !!busy;
        }
        if (cancelButton) {
          cancelButton.disabled = !!busy;
        }
        if (!busy) {
          syncMemberLookupServeButton();
        }
      },
      onSaved: async (updatedMember) => {
        const nextMemberId = Number.parseInt(String(updatedMember?.id || item.id || '0'), 10);
        if (String(state.memberLookupQuery || '').trim() !== '') {
          await searchMembersForLookup().catch(() => {});
        }
        if (!Number.isNaN(nextMemberId) && nextMemberId > 0) {
          await openMemberLookup(nextMemberId);
          setFeedback(els.memberLookupFeedback, 'Member updated. Review the member record before deciding.');
        }
      },
      onDeleted: async () => {
        state.memberLookupResults = state.memberLookupResults.filter((row) => (
          Number.parseInt(String(row?.id || '0'), 10) !== Number.parseInt(String(item.id || '0'), 10)
        ));
        renderMemberLookupResults(state.memberLookupResults);
        renderMemberLookupMeta(state.memberLookupResults.length, false);
        clearMemberLookupDetail('Member deleted. Search the next member.');
        setFeedback(els.memberLookupFeedback, 'Member deleted.');
        showGlobalFeedback('Member deleted.');
        focusMemberLookupQuery();
      }
    });

    syncDob();
    syncMemberLookupServeButton();
    if (photoMatchAvailable && photoMatch) {
      focusMemberLookupPhotoMatchInput(photoMatch);
    } else if (requiresDob && dobInput) {
      focusMemberLookupDobInput(dobInput);
    }
  }

  async function openMemberLookup(memberId) {
    const safeMemberId = Number.parseInt(String(memberId || '0'), 10);
    if (state.memberLookupBusy || Number.isNaN(safeMemberId) || safeMemberId <= 0) {
      return;
    }

    if (!canUseMemberLookup()) {
      syncMemberLookupAvailability('open_guard');
      return;
    }

    state.memberLookupBusy = true;
    syncMemberLookupAvailability('open_start');
    setFeedback(els.memberLookupFeedback, 'Loading member record...');

    try {
      clearMemberLookupApiForbidden();
      const searchTerm = encodeURIComponent(String(state.memberLookupQuery || '').trim());
      const venueId = encodeURIComponent(String(getVenueId(true)));
      const data = await api(`/member-lookup/${safeMemberId}?venue_id=${venueId}&search_term=${searchTerm}`);
      renderMemberLookupDetail(data.item || {});
      setFeedback(els.memberLookupFeedback, 'Review the member record before deciding.');
    } catch (error) {
      const isPermissionError = error?.category === 'permission' || Number(error?.status || 0) === 403;
      if (isPermissionError) {
        markMemberLookupApiForbidden(error);
      }
      setFeedback(els.memberLookupFeedback, isPermissionError ? getMemberLookupDisabledMessage(getMemberLookupAccessState()) : error.message, true);
    } finally {
      state.memberLookupBusy = false;
      syncMemberLookupAvailability('open_complete');
      syncMemberLookupServeButton();
    }
  }

  async function submitMemberLookupDecision(decision, reasonCode = '') {
    if (state.memberLookupBusy) {
      return;
    }

    const detail = state.memberLookupCurrent;
    if (!detail || !detail.id) {
      setFeedback(els.memberLookupFeedback, 'Select a member first.', true);
      return;
    }

    if (!canUseMemberLookup()) {
      syncMemberLookupAvailability('decision_guard');
      return;
    }

    const feedbackEl = els.memberLookupDetailCard
      ? els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-decision-feedback')
      : null;
    const confidence = els.memberLookupDetailCard
      ? els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-confidence')
      : null;
    const photoMatch = els.memberLookupDetailCard
      ? els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-photo-match')
      : null;
    const dobInput = els.memberLookupDetailCard
      ? els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-dob-input')
      : null;
    const dobFeedback = els.memberLookupDetailCard
      ? els.memberLookupDetailCard.querySelector('#vms-ops-member-lookup-dob-feedback')
      : null;
    const photoMatchAvailable = !!detail.photo_match_available;
    const dobState = syncMemberLookupDobInput(dobInput, dobFeedback, {
      optionalInput: photoMatchAvailable
    });
    const requiresDob = !!detail.requires_dob_entry;
    const requiresConfidence = !!detail.requires_confidence;
    const photoMatchConfirmed = !!photoMatch?.checked;

    if (decision === 'serve' && requiresConfidence && !(confidence && confidence.checked)) {
      const message = 'Confirm that you confidently recognize the member before using Verified Lookup.';
      setFeedback(feedbackEl, message, true);
      setFeedback(els.memberLookupFeedback, message, true);
      return;
    }

    if (decision === 'serve' && photoMatchAvailable && !photoMatchConfirmed && !dobState.isComplete) {
      const message = 'Confirm the stored profile photo matches this member, or enter DOB.';
      setFeedback(feedbackEl, message, true);
      setFeedback(els.memberLookupFeedback, message, true);
      if (photoMatch) {
        focusMemberLookupPhotoMatchInput(photoMatch);
      } else {
        focusMemberLookupDobInput(dobInput);
      }
      return;
    }

    if (decision === 'serve' && !photoMatchAvailable && requiresDob && !dobState.isComplete) {
      const message = dobState.digitCount >= 8 && !dobState.needsMoreDigits
        ? 'Enter a valid DOB: MMDDYYYY.'
        : 'Enter 8 digits: MMDDYYYY.';
      setMemberLookupDobFeedback(dobFeedback, message.replace(/\.$/, ''), 'error');
      setFeedback(feedbackEl, message, true);
      setFeedback(els.memberLookupFeedback, message, true);
      focusMemberLookupDobInput(dobInput);
      return;
    }

    state.memberLookupBusy = true;
    syncMemberLookupAvailability('decision_start');
    syncMemberLookupServeButton();
    setFeedback(feedbackEl, decision === 'serve' ? 'Validating member lookup…' : 'Logging ID recheck…');

    try {
      clearMemberLookupApiForbidden();
      const data = await api(`/member-lookup/${encodeURIComponent(String(detail.id))}/decision`, {
        method: 'POST',
        body: {
          venue_id: getVenueId(true),
          decision,
          search_term: String(state.memberLookupQuery || '').trim(),
          dob_input: String(dobInput?.value || '').trim(),
          confidence_ack: !!confidence?.checked ? 1 : 0,
          photo_match_confirmed: photoMatchConfirmed ? 1 : 0,
          reason_code: reasonCode,
          device_id: String(config.deviceId || '').trim(),
          console_type: 'ops',
          event_id: Number.parseInt(String(getSelectedEvent()?.id || '0'), 10) || 0
        }
      });

      const status = String(data?.status || '').trim();
      const resolvedReasonCode = String(data?.reason_code || reasonCode || '').trim();
      const message = String(data?.message || '').trim() || 'Lookup updated.';
      const isError = status === 'blocked';
      setFeedback(feedbackEl, message, isError);
      setFeedback(els.memberLookupFeedback, message, isError);

      if (decision === 'serve' && (requiresDob || dobState.digitCount > 0)) {
        if (status === 'served' || status === 'duplicate') {
          setMemberLookupDobFeedback(dobFeedback, 'DOB confirmed', 'ok');
        } else if (resolvedReasonCode === 'dob_mismatch') {
          setMemberLookupDobFeedback(dobFeedback, 'DOB does not match', 'error');
        } else if (resolvedReasonCode !== '') {
          syncMemberLookupDobInput(dobInput, dobFeedback, {
            optionalInput: photoMatchAvailable
          });
        }
      }

      if (decision === 'check_id_now' || status === 'blocked') {
        openIdRecheckFlow(resolvedReasonCode, data?.recheck_context || detail);
      }

      if (status === 'served') {
        finishMemberLookupAction(message || 'Served via Verified Lookup');
        return;
      }

      if (status === 'duplicate') {
        finishMemberLookupAction(message || 'Already served via Verified Lookup');
        return;
      } else if (decision === 'check_id_now') {
        showGlobalFeedback(message || 'Check ID now path logged.');
      } else if (status === 'blocked') {
        showGlobalFeedback(message, true);
      }
    } catch (error) {
      const isPermissionError = error?.category === 'permission' || Number(error?.status || 0) === 403;
      if (isPermissionError) {
        markMemberLookupApiForbidden(error);
      }
      if (String(error?.code || '').trim() === 'lookup_dob_required') {
        setMemberLookupDobFeedback(dobFeedback, 'Enter 8 digits: MMDDYYYY', 'error');
        focusMemberLookupDobInput(dobInput);
      }
      if (String(error?.code || '').trim() === 'lookup_photo_match_required' && photoMatch) {
        focusMemberLookupPhotoMatchInput(photoMatch);
      }
      const message = isPermissionError ? getMemberLookupDisabledMessage(getMemberLookupAccessState()) : error.message;
      setFeedback(feedbackEl, message, true);
      setFeedback(els.memberLookupFeedback, message, true);
      throw error;
    } finally {
      state.memberLookupBusy = false;
      syncMemberLookupAvailability('decision_complete');
      syncMemberLookupServeButton();
    }
  }

  async function searchMembersForLookup() {
    if (state.memberLookupBusy) {
      return;
    }

    if (!canUseMemberLookup()) {
      syncMemberLookupAvailability('search_guard');
      return;
    }

    const query = String(els.memberLookupQuery?.value || '').trim();
    state.memberLookupQuery = query;

    if (query === '') {
      clearMemberLookupState({ preserveQuery: false });
      setFeedback(els.memberLookupFeedback, 'Enter a member name, phone, member number, email, or DOB to search.', true);
      return;
    }

    state.memberLookupBusy = true;
    syncMemberLookupAvailability('search_start');
    clearMemberLookupDetail();
    setFeedback(els.memberLookupFeedback, 'Searching members…');

    try {
      clearMemberLookupApiForbidden();
      const venueId = encodeURIComponent(String(getVenueId(true)));
      const q = encodeURIComponent(query);
      const data = await api(`/member-lookup/search?venue_id=${venueId}&q=${q}&limit=20`);
      const items = Array.isArray(data?.items) ? data.items : [];
      state.memberLookupResults = items;
      renderMemberLookupResults(items);
      renderMemberLookupMeta(data?.total_matches || items.length, !!data?.truncated);

      if (items.length === 0) {
        setFeedback(els.memberLookupFeedback, 'No matching members found. If the member is not known, check ID now.', true);
      } else {
        setFeedback(els.memberLookupFeedback, 'Tap a matching member card to open Member Details and edit options.');
      }
    } catch (error) {
      const isPermissionError = error?.category === 'permission' || Number(error?.status || 0) === 403;
      if (isPermissionError) {
        markMemberLookupApiForbidden(error);
      }
      state.memberLookupResults = [];
      renderMemberLookupResults([]);
      renderMemberLookupMeta(0, false);
      setFeedback(els.memberLookupFeedback, isPermissionError ? getMemberLookupDisabledMessage(getMemberLookupAccessState()) : error.message, true);
    } finally {
      state.memberLookupBusy = false;
      syncMemberLookupAvailability('search_complete');
      syncMemberLookupServeButton();
    }
  }

  function renderMemberResult(data) {
    if (!els.idResult) {
      return;
    }

    renderIdRecheckContext(null);
    const member = data.member || {};
    const flags = data.flags || {};
    const badges = [];
    const ageState = buildIdAgeState(member.date_of_birth || '');
    const fullName = `${String(member.first_name || '').trim()} ${String(member.last_name || '').trim()}`.trim() || 'Member';
    const memberNumber = String(member.member_number || '').trim();
    const status = String(flags.effective_status || member.status || 'unknown').trim() || 'unknown';
    const expires = String(member.membership_expires_on || 'N/A').trim() || 'N/A';
    const memberId = Number.parseInt(String(member.id || '0'), 10);

    if (flags.vip) {
      badges.push('<span class="vms-ops-badge vip">VIP</span>');
    }
    if (flags.birthday_window) {
      badges.push('<span class="vms-ops-badge birthday">Birthday Window</span>');
    }
    if (flags.effective_status === 'suspended') {
      badges.push('<span class="vms-ops-badge suspended">Suspended</span>');
    }
    if (flags.effective_status === 'expired') {
      badges.push('<span class="vms-ops-badge expired">Expired</span>');
    }

    renderIdAgeCard(ageState);

    const mismatch = flags.address_mismatch
      ? '<p class="vms-ops-member-result-alert"><strong>Address mismatch detected.</strong> Verify identity before entry.</p>'
      : '';
    const editorHtml = buildMemberEditorHtml(member, { memberName: fullName });
    els.idResult.innerHTML = `
      <div class="vms-ops-member-result">
        <div class="vms-ops-member-result-badges">${badges.join(' ')}</div>
        <p class="vms-ops-member-result-name">
          <strong>${escapeHtml(fullName)}</strong>${memberNumber ? ` <span class="vms-ops-member-result-number">(${escapeHtml(memberNumber)})</span>` : ''}
        </p>
        <div class="vms-ops-member-result-grid">
          <p><strong>Status:</strong> ${escapeHtml(status)}</p>
          <p><strong>Expires:</strong> ${escapeHtml(expires)}</p>
        </div>
        ${mismatch}
        ${editorHtml}
      </div>
    `;

    const editorForm = els.idResult.querySelector('[data-member-editor]');
    attachMemberEditorHandlers(editorForm, {
      member,
      onSaved: async (updatedMember) => {
        const nextFlags = {
          ...(flags || {}),
          effective_status: String(updatedMember?.status || flags.effective_status || member.status || 'active').trim() || 'active',
          vip: updatedMember?.vip ? 1 : 0
        };
        renderMemberResult({
          ...(data || {}),
          member: updatedMember,
          flags: nextFlags
        });
        setFeedback(els.idFeedback, 'Member updated.');
      },
      onDeleted: async () => {
        els.idResult.innerHTML = '';
        setFeedback(els.idFeedback, 'Member deleted.');
        showGlobalFeedback('Member deleted.');
      }
    });
  }

  function setIdProcessButtonVisible(visible) {
    if (!els.idProcess) {
      return;
    }
    els.idProcess.hidden = !visible;
  }

  function setIdRetryLogVisible(visible) {
    if (!els.idRetryLog) {
      return;
    }
    els.idRetryLog.hidden = !visible;
  }

  function renderIdAgeCard(ageState) {
    if (!els.idAgeWarning) {
      return;
    }

    if (!ageState) {
      els.idAgeWarning.innerHTML = '';
      els.idAgeWarning.hidden = true;
      els.idAgeWarning.classList.remove('is-ok', 'is-critical', 'is-caution');
      return;
    }

    const label = 'ID AGE STATUS';
    const meta = ageState.dob ? `DOB ${ageState.dob}` : '';

    els.idAgeWarning.innerHTML = `
      <div class="vms-ops-age-card-label">${escapeHtml(label)}</div>
      <div class="vms-ops-age-card-value">${escapeHtml(ageState.headline || 'AGE UNKNOWN')}</div>
      <div class="vms-ops-age-card-detail">${escapeHtml(ageState.detail || 'VERIFY MANUALLY')}</div>
      ${meta ? `<div class="vms-ops-age-card-meta">${escapeHtml(meta)}</div>` : ''}
    `;
    els.idAgeWarning.hidden = false;
    els.idAgeWarning.classList.toggle('is-ok', ageState.level === 'ok');
    els.idAgeWarning.classList.toggle('is-critical', ageState.level === 'critical');
    els.idAgeWarning.classList.toggle('is-caution', ageState.level === 'caution');
  }

  function normalizeDobForAge(value) {
    const dob = String(value || '').trim();
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dob);
    if (!match) {
      return null;
    }

    const year = Number.parseInt(match[1] || '', 10);
    const month = Number.parseInt(match[2] || '', 10);
    const day = Number.parseInt(match[3] || '', 10);
    const parsed = new Date(Date.UTC(year, month - 1, day));

    if (
      Number.isNaN(parsed.getTime())
      || parsed.getUTCFullYear() !== year
      || (parsed.getUTCMonth() + 1) !== month
      || parsed.getUTCDate() !== day
    ) {
      return null;
    }

    return { year, month, day, dob };
  }

  function computeAgeYears(value) {
    const dob = normalizeDobForAge(value);
    if (!dob) {
      return null;
    }

    const today = getSiteTodayParts();
    if (!today) {
      return null;
    }

    let age = today.year - dob.year;
    const monthDelta = today.month - dob.month;
    if (monthDelta < 0 || (monthDelta === 0 && today.day < dob.day)) {
      age -= 1;
    }
    return age;
  }

  function getTwentyOneCutoffParts() {
    const today = getSiteTodayParts();
    if (!today) {
      return null;
    }

    const cutoffYear = today.year - 21;
    const maxDay = new Date(Date.UTC(cutoffYear, today.month, 0)).getUTCDate();

    return {
      year: cutoffYear,
      month: today.month,
      day: Math.min(today.day, maxDay)
    };
  }

  function formatDatePartsLong(parts) {
    if (!parts || !Number.isFinite(parts.year) || !Number.isFinite(parts.month) || !Number.isFinite(parts.day)) {
      return '';
    }

    const date = new Date(Date.UTC(parts.year, parts.month - 1, parts.day, 12, 0, 0));
    if (Number.isNaN(date.getTime())) {
      return '';
    }

    return new Intl.DateTimeFormat(undefined, {
      timeZone: 'UTC',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  }

  function renderIdAgeCutoffNote() {
    if (!els.idAgeCutoffNote) {
      return;
    }

    const cutoff = getTwentyOneCutoffParts();
    const cutoffText = formatDatePartsLong(cutoff);
    if (!cutoff || !cutoffText) {
      els.idAgeCutoffNote.textContent = '';
      els.idAgeCutoffNote.hidden = true;
      return;
    }

    els.idAgeCutoffNote.innerHTML = `
      <strong>${escapeHtml('21+ cutoff today:')}</strong>
      <span>${escapeHtml(`DOB must be ${cutoffText} or earlier.`)}</span>
    `;
    els.idAgeCutoffNote.hidden = false;
  }

  function buildIdAgeState(dobValue) {
    const dob = String(dobValue || '').trim();
    const ageYears = computeAgeYears(dob);

    if (!dob || !Number.isFinite(ageYears)) {
      return {
        known: false,
        ageYears: null,
        dob,
        level: 'caution',
        headline: 'AGE UNKNOWN',
        detail: 'VERIFY MANUALLY'
      };
    }

    if (ageYears < 21) {
      return {
        known: true,
        ageYears,
        dob,
        level: 'critical',
        headline: `AGE ${ageYears} - UNDER 21`,
        detail: 'DO NOT SERVE'
      };
    }

    return {
      known: true,
      ageYears,
      dob,
      level: 'ok',
      headline: `AGE ${ageYears}`,
      detail: '21+ VERIFIED'
    };
  }

  function hideIdNotFoundPrompt() {
    state.pendingManualPrefill = null;
    if (els.idNotFound) {
      els.idNotFound.hidden = true;
      els.idNotFound.classList.remove('is-manager-required');
    }
    if (els.idNotFoundSummary) {
      els.idNotFoundSummary.textContent = '';
    }
    if (els.idNotFoundAction) {
      els.idNotFoundAction.textContent = '';
    }
    if (els.idAddMember) {
      els.idAddMember.hidden = false;
      els.idAddMember.disabled = false;
    }
  }

  function renderIdNotFoundPrompt(prefill = {}) {
    const data = prefill && typeof prefill === 'object' ? prefill : {};
    state.pendingManualPrefill = data;
    const canCreate = canCreateMembersFromScan();
    const firstName = String(data.first_name || '').trim();
    const lastName = String(data.last_name || '').trim();
    const fullName = `${firstName} ${lastName}`.trim() || 'Unknown';
    const dob = String(data.date_of_birth || '').trim() || 'Unknown';
    const memberNumber = String(data.member_number || '').trim() || 'Unknown';

    renderIdAgeCard(buildIdAgeState(data.date_of_birth || ''));

    if (els.idNotFoundSummary) {
      els.idNotFoundSummary.textContent = `Name: ${fullName} • DOB: ${dob} • DL #: ${memberNumber}`;
    }
    if (els.idNotFoundAction) {
      els.idNotFoundAction.textContent = canCreate
        ? 'Review the scan details, then add the member if appropriate.'
        : 'Manager access or scan-add permission required to add this member.';
    }
    if (els.idAddMember) {
      els.idAddMember.hidden = !canCreate;
      els.idAddMember.disabled = !canCreate;
    }
    if (els.idNotFound) {
      els.idNotFound.classList.toggle('is-manager-required', !canCreate);
      els.idNotFound.hidden = false;
    }
  }

  function buildMemberCreateBody(prefill = {}) {
    return {
      venue_id: getVenueId(true),
      member_number: String(prefill.member_number || ''),
      first_name: String(prefill.first_name || ''),
      last_name: String(prefill.last_name || ''),
      date_of_birth: String(prefill.date_of_birth || ''),
      address_line_1: String(prefill.address_line_1 || ''),
      city: String(prefill.city || ''),
      state: String(prefill.state || ''),
      postal_code: String(prefill.postal_code || ''),
      age_verified: 1,
      scan_payload: String(prefill.scan_payload || '')
    };
  }

  function clearIdDebugTiming() {
    state.idScanDebugMetrics = null;
    if (!els.idDebugTiming) {
      return;
    }
    els.idDebugTiming.textContent = '';
    els.idDebugTiming.hidden = true;
  }

  function formatTimingValue(ms) {
    const value = Number(ms || 0);
    if (!Number.isFinite(value) || value <= 0) {
      return '0ms';
    }
    if (value >= 1000) {
      return `${(value / 1000).toFixed(value >= 3000 ? 1 : 2)}s`;
    }
    return `${Math.round(value)}ms`;
  }

  function renderIdDebugTiming(metrics = null) {
    if (!config.debugMode || !els.idDebugTiming) {
      return;
    }

    const data = metrics && typeof metrics === 'object' ? metrics : null;
    if (!data) {
      els.idDebugTiming.textContent = '';
      els.idDebugTiming.hidden = true;
      return;
    }

    const lines = [];
    lines.push(`Warmup: ${formatTimingValue(data.warmupMs || 0)}${data.warmReused ? ' (reused camera)' : ''}`);
    lines.push(`Reading ID: ${formatTimingValue(data.readMs || 0)}`);
    lines.push(`Server round-trip: ${formatTimingValue(data.requestMs || 0)}`);
    if (data.autoAddMs) {
      lines.push(`Auto-add member: ${formatTimingValue(data.autoAddMs)}`);
    }
    if (data.server && typeof data.server === 'object') {
      lines.push(
        `Server detail: parse ${formatTimingValue(data.server.parse_ms || 0)} • `
        + `lookup ${formatTimingValue(data.server.lookup_ms || 0)} • `
        + `save ${formatTimingValue(data.server.save_ms || 0)} • `
        + `log ${formatTimingValue(data.server.scan_log_ms || 0)}`
      );
    }
    lines.push(`Render: ${formatTimingValue(data.renderMs || 0)}`);
    lines.push(`Total: ${formatTimingValue(data.totalMs || 0)}`);

    els.idDebugTiming.textContent = lines.join('\n');
    els.idDebugTiming.hidden = false;

    if (typeof console !== 'undefined' && typeof console.debug === 'function') {
      console.debug('VMS Ops ID scan timing', data);
    }
  }

  function setIdScanPhase(label, detail = '', options = {}) {
    const safeLabel = String(label || '').trim();
    const safeDetail = String(detail || '').trim();
    if (safeLabel === '') {
      return;
    }

    const feedbackMessage = safeDetail ? `${safeLabel} — ${safeDetail}` : safeLabel;
    if (!options.suppressPanelFeedback) {
      setFeedback(els.idFeedback, feedbackMessage, !!options.isError);
    }

    if (options.fromScanner && els.scanModal && !els.scanModal.hidden) {
      const tone = options.tone || 'info';
      const statusTone = tone === 'success' ? 'success' : (tone === 'warning' ? 'warning' : (tone === 'error' ? 'error' : 'scan'));
      setScannerStatus(safeLabel.toUpperCase(), statusTone);
      setScannerResultCard(safeLabel, safeDetail, tone);
    }
  }

  async function requestIdScan(payload) {
    return api('/id/scan', {
      method: 'POST',
      body: {
        venue_id: getVenueId(true),
        payload,
        auto_renew: 1,
        debug: config.debugMode ? 1 : 0
      }
    });
  }

  async function autoAddMemberFromScan(prefill, payload) {
    let created = false;
    const createBody = buildMemberCreateBody({
      ...(prefill || {}),
      scan_payload: String(payload || '')
    });

    try {
      await api('/id/manual-member', { method: 'POST', body: createBody });
      created = true;
    } catch (error) {
      if (String(error?.code || '').trim() !== 'member_exists') {
        throw error;
      }
    }

    const data = await requestIdScan(payload);
    if (data?.manual_creation_required) {
      const retryError = new Error('Member could not be added from this scan. Review the details.');
      retryError.code = 'member_auto_create_failed';
      throw retryError;
    }

    data.scanNotice = created
      ? 'Member not found on scan. Added automatically.'
      : 'Member record already existed. Showing current record.';
    data.autoCreatedFromScan = created ? 1 : 0;
    return data;
  }

  function applyProcessedIdScanResult(data, options = {}) {
    hideIdNotFoundPrompt();
    setIdProcessButtonVisible(!!options.preserveProcessButton);
    setIdRetryLogVisible(false);

    if (data?.banned_screen?.locked) {
      showBannedOverlay(data.banned_screen.member_id, 'Banned member. Press and hold to clear screen.');
    } else {
      hideBannedOverlay();
    }

    const resultData = {
      ...(data || {}),
      scanNotice: String(options.scanNotice || data?.scanNotice || data?.scan_notice || '').trim()
    };
    renderMemberResult(resultData);

    if (data?.suspended_screen?.warning) {
      setFeedback(els.idFeedback, 'Suspended member warning shown.', true);
      return;
    }

    if (String(options.feedbackMessage || '').trim() !== '') {
      setFeedback(els.idFeedback, String(options.feedbackMessage || '').trim(), !!options.feedbackIsError);
      return;
    }

    const visitText = data?.visit?.duplicate ? 'already logged today.' : 'logged.';
    const renewalText = data?.renewed ? ' Renewed.' : '';
    setFeedback(els.idFeedback, `Member Found ✓ ${visitText}${renewalText}`);
  }

  async function addMemberFromScanPrompt() {
    const prefill = state.pendingManualPrefill || null;
    const payload = String(els.idPayload?.value || '').trim();
    if (!prefill) {
      setFeedback(els.idFeedback, 'No scanned member data is available.', true);
      return;
    }
    if (!payload) {
      setFeedback(els.idFeedback, 'ID payload is required.', true);
      return;
    }
    if (!canCreateMembersFromScan()) {
      renderIdNotFoundPrompt(prefill);
      setFeedback(els.idFeedback, 'Manager access or scan-add permission required to add this member.', true);
      return;
    }

    try {
      hideIdNotFoundPrompt();
      setFeedback(els.idFeedback, 'Adding member...');
      const data = await autoAddMemberFromScan(prefill, payload);
      applyProcessedIdScanResult(data, {
        preserveProcessButton: true,
        scanNotice: String(data?.scanNotice || '').trim(),
        feedbackMessage: data?.autoCreatedFromScan
          ? 'Member not found. Added automatically and logged.'
          : 'Member record refreshed.'
      });
    } catch (error) {
      renderIdNotFoundPrompt(prefill);
      setIdProcessButtonVisible(true);
      setIdRetryLogVisible(true);
      setFeedback(els.idFeedback, error.message, true);
    }
  }

  function showManualMemberForm(prefill = {}) {
    if (!els.manualForm) {
      return;
    }

    const fields = ['member_number', 'first_name', 'last_name', 'date_of_birth', 'address_line_1', 'city', 'state', 'postal_code'];
    fields.forEach((name) => {
      const input = els.manualForm.querySelector(`[name="${name}"]`);
      if (input) {
        input.value = prefill[name] || '';
      }
    });
    state.manualMemberNumberFromScan = String(prefill.member_number || '').trim() !== '';

    setManualFormVisible(true);
    if (els.manualHeading && typeof els.manualHeading.scrollIntoView === 'function') {
      els.manualHeading.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

  function hideManualMemberForm() {
    state.manualMemberNumberFromScan = false;
    setManualFormVisible(false);
  }

  function showBannedOverlay(memberId, message) {
    const parsedMemberId = Number.parseInt(String(memberId || '0'), 10);
    if (Number.isNaN(parsedMemberId) || parsedMemberId <= 0) {
      hideBannedOverlay();
      return;
    }

    state.bannedMemberId = parsedMemberId;
    if (els.bannedText) {
      els.bannedText.textContent = message || 'Manager intervention required.';
    }
    if (els.bannedOverlay) {
      els.bannedOverlay.hidden = false;
    }
  }

  function hideBannedOverlay() {
    state.bannedMemberId = 0;
    state.bannedClearBusy = false;
    clearBannedHoldTimer();
    if (els.bannedOverlay) {
      els.bannedOverlay.hidden = true;
    }
    if (els.bannedClear) {
      els.bannedClear.textContent = 'Press and Hold to Clear';
    }
  }

  function clearBannedHoldTimer() {
    if (state.bannedHoldInterval) {
      clearInterval(state.bannedHoldInterval);
      state.bannedHoldInterval = null;
    }
    state.holdStartAt = 0;
  }

  async function clearBannedScreen() {
    if (state.bannedClearBusy) {
      return;
    }

    if (!state.bannedMemberId) {
      hideBannedOverlay();
      return;
    }

    state.bannedClearBusy = true;
    try {
      await api('/id/banned-clear', {
        method: 'POST',
        body: {
          member_id: state.bannedMemberId
        }
      });
      hideBannedOverlay();
      setFeedback(els.idFeedback, 'Banned lock cleared and audit logged.');
    } catch (error) {
      setFeedback(els.idFeedback, error.message, true);
      if (els.bannedClear) {
        els.bannedClear.textContent = 'Press and Hold to Clear';
      }
    } finally {
      state.bannedClearBusy = false;
    }
  }

  function getBannedHoldSeconds() {
    const parsed = Number(config.settings?.banned_clear_hold_seconds || 3);
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return 3;
    }
    return parsed;
  }

  function startBannedHold() {
    if (!state.bannedMemberId) {
      hideBannedOverlay();
      return;
    }

    clearBannedHoldTimer();

    const holdSeconds = getBannedHoldSeconds();
    state.holdStartAt = Date.now();

    state.bannedHoldInterval = setInterval(() => {
      const elapsed = (Date.now() - state.holdStartAt) / 1000;
      const remaining = Math.max(0, holdSeconds - elapsed);
      if (els.bannedClear) {
        els.bannedClear.textContent = `Hold ${remaining.toFixed(1)}s`;
      }
      if (remaining <= 0) {
        clearBannedHoldTimer();
        clearBannedScreen();
      }
    }, 100);
  }

  function releaseBannedHold() {
    if (!state.holdStartAt) {
      return;
    }

    const holdSeconds = getBannedHoldSeconds();
    const elapsed = (Date.now() - state.holdStartAt) / 1000;
    clearBannedHoldTimer();

    if (elapsed >= holdSeconds) {
      clearBannedScreen();
      return;
    }

    if (els.bannedClear) {
      els.bannedClear.textContent = 'Press and Hold to Clear';
    }
  }

  async function processIdPayload(options = {}) {
    if (state.idScanBusy) {
      return;
    }

    const fromScanner = !!options.fromScanner;
    const debugMetrics = state.idScanDebugMetrics && typeof state.idScanDebugMetrics === 'object'
      ? { ...state.idScanDebugMetrics }
      : {
        openedAt: performance.now(),
        warmupMs: 0,
        readMs: 0,
        requestMs: 0,
        renderMs: 0,
        totalMs: 0,
        autoAddMs: 0,
        warmReused: false,
        server: null
      };
    const totalStartedAt = performance.now();

    if (isLoginRequired() && !state.onDuty) {
      setFeedback(els.idFeedback, 'Log in to scan IDs.', true);
      return;
    }

    const payload = String(els.idPayload?.value || '').trim();
    if (!payload) {
      setIdProcessButtonVisible(true);
      setFeedback(els.idFeedback, 'ID payload is required.', true);
      return;
    }

    state.idScanBusy = true;
    renderIdDebugTiming(null);
    setIdRetryLogVisible(false);
    hideIdNotFoundPrompt();
    hideManualMemberForm();
    renderIdAgeCard(null);
    hideBannedOverlay();
    if (els.idResult) {
      els.idResult.textContent = '';
    }

    try {
      setIdScanPhase(
        fromScanner ? 'Processing' : 'Reading ID',
        fromScanner ? 'Checking member record and visit history.' : 'Preparing scanned ID data.',
        { fromScanner, tone: 'info' }
      );
      const requestStartedAt = performance.now();
      const data = await requestIdScan(payload);
      debugMetrics.requestMs = Math.max(0, Math.round(performance.now() - requestStartedAt));
      if (data?.debug_timing && typeof data.debug_timing === 'object') {
        debugMetrics.server = data.debug_timing;
      }

      if (data.manual_creation_required) {
        const prefill = data.prefill || {};
        if (canCreateMembers()) {
          try {
            setIdScanPhase('Saving', 'Adding member from scanned ID.', { fromScanner, tone: 'warning' });
            const autoAddStartedAt = performance.now();
            const autoCreated = await autoAddMemberFromScan(prefill, payload);
            debugMetrics.autoAddMs = Math.max(0, Math.round(performance.now() - autoAddStartedAt));
            if (autoCreated?.debug_timing && typeof autoCreated.debug_timing === 'object') {
              debugMetrics.server = autoCreated.debug_timing;
            }
            setIdScanPhase('Saving', 'Finalizing member record.', { fromScanner, tone: 'info' });
            const renderStartedAt = performance.now();
            applyProcessedIdScanResult(autoCreated, {
              preserveProcessButton: !!options.preserveProcessButton,
              scanNotice: String(autoCreated?.scanNotice || '').trim(),
              feedbackMessage: autoCreated?.autoCreatedFromScan
                ? 'Member not found. Added automatically and logged.'
                : 'Member record refreshed.'
            });
            debugMetrics.renderMs = Math.max(0, Math.round(performance.now() - renderStartedAt));
            debugMetrics.totalMs = Math.max(0, Math.round(performance.now() - totalStartedAt));
            state.idScanDebugMetrics = debugMetrics;
            renderIdDebugTiming(debugMetrics);
            if (fromScanner) {
              setIdScanPhase('Done', 'Member processed.', { fromScanner, tone: 'success', suppressPanelFeedback: true });
              playScannerSuccessSignal();
              window.setTimeout(() => closeScanner({ reason: 'ID_SCAN_COMPLETED', source: 'scanner_result' }), 900);
            }
            return;
          } catch (error) {
            debugMetrics.totalMs = Math.max(0, Math.round(performance.now() - totalStartedAt));
            state.idScanDebugMetrics = debugMetrics;
            renderIdDebugTiming(debugMetrics);
            setIdProcessButtonVisible(true);
            setIdRetryLogVisible(true);
            renderIdNotFoundPrompt(prefill);
            setFeedback(els.idFeedback, error.message, true);
            if (els.idResult) {
              els.idResult.textContent = '';
            }
            if (fromScanner) {
              const isConnectionError = ['session', 'permission', 'network'].includes(String(error?.category || '').trim().toLowerCase());
              setIdScanPhase(
                'Done',
                isConnectionError ? 'Reconnect or log in again.' : String(error?.message || 'Review the scan and try again.'),
                { fromScanner, tone: 'error', isError: true, suppressPanelFeedback: true }
              );
              playScannerErrorSignal('error');
              window.setTimeout(() => closeScanner({ reason: 'ID_SCAN_ERROR', source: 'scanner_result' }), 1400);
            }
            return;
          }
        }

        setIdProcessButtonVisible(true);
        renderIdNotFoundPrompt(prefill);
        setFeedback(
          els.idFeedback,
          canCreateMembersFromScan()
            ? 'Member not found. Review the scan and add the member if appropriate.'
            : 'Member not found. Manager access or scan-add permission required to add this member.',
          true
        );
        debugMetrics.totalMs = Math.max(0, Math.round(performance.now() - totalStartedAt));
        state.idScanDebugMetrics = debugMetrics;
        renderIdDebugTiming(debugMetrics);
        if (els.idResult) {
          els.idResult.textContent = '';
        }
        if (fromScanner) {
          setIdScanPhase('Done', 'Member not found. Review the scan below.', {
            fromScanner,
            tone: 'warning',
            suppressPanelFeedback: true
          });
          playScannerErrorSignal('warning');
          window.setTimeout(() => closeScanner({ reason: 'ID_SCAN_REVIEW_REQUIRED', source: 'scanner_result' }), 1200);
        }
        return;
      }

      setIdScanPhase('Saving', 'Recording visit and scan log.', { fromScanner, tone: 'info' });
      const renderStartedAt = performance.now();
      applyProcessedIdScanResult(data, {
        preserveProcessButton: !!options.preserveProcessButton
      });
      debugMetrics.renderMs = Math.max(0, Math.round(performance.now() - renderStartedAt));
      debugMetrics.totalMs = Math.max(0, Math.round(performance.now() - totalStartedAt));
      state.idScanDebugMetrics = debugMetrics;
      renderIdDebugTiming(debugMetrics);
      if (fromScanner) {
        setIdScanPhase('Done', 'ID processed.', { fromScanner, tone: 'success', suppressPanelFeedback: true });
        playScannerSuccessSignal();
        window.setTimeout(() => closeScanner({ reason: 'ID_SCAN_COMPLETED', source: 'scanner_result' }), 900);
      }
    } catch (error) {
      debugMetrics.totalMs = Math.max(0, Math.round(performance.now() - totalStartedAt));
      state.idScanDebugMetrics = debugMetrics;
      renderIdDebugTiming(debugMetrics);
      setIdProcessButtonVisible(true);
      setIdRetryLogVisible(true);
      setFeedback(els.idFeedback, error.message, true);
      if (fromScanner) {
        const isConnectionError = ['session', 'permission', 'network'].includes(String(error?.category || '').trim().toLowerCase());
        setIdScanPhase(
          'Done',
          isConnectionError ? 'Reconnect or log in again.' : String(error?.message || 'Review the scan and try again.'),
          { fromScanner, tone: 'error', isError: true, suppressPanelFeedback: true }
        );
        playScannerErrorSignal('error');
        window.setTimeout(() => closeScanner({ reason: 'ID_SCAN_ERROR', source: 'scanner_result' }), 1400);
      }
    } finally {
      state.idScanBusy = false;
    }
  }

  async function submitManualMember(event) {
    event.preventDefault();
    const formData = new FormData(els.manualForm);

    const body = {
      venue_id: getVenueId(true),
      member_number: String(formData.get('member_number') || ''),
      first_name: String(formData.get('first_name') || ''),
      last_name: String(formData.get('last_name') || ''),
      date_of_birth: String(formData.get('date_of_birth') || ''),
      phone_number: String(formData.get('phone_number') || ''),
      email_address: String(formData.get('email_address') || ''),
      address_line_1: String(formData.get('address_line_1') || ''),
      city: String(formData.get('city') || ''),
      state: String(formData.get('state') || ''),
      postal_code: String(formData.get('postal_code') || ''),
      notes: String(formData.get('notes') || ''),
      lookup_caution_flag: formData.get('lookup_caution_flag') ? 1 : 0,
      lookup_caution_note: String(formData.get('lookup_caution_note') || ''),
      photo_consent: formData.get('photo_consent') ? 1 : 0
    };
    const photoUpload = formData.get('profile_photo');
    const hasProfilePhoto = photoUpload instanceof File && photoUpload.name !== '' && photoUpload.size > 0;
    let preparedPhotoUpload = null;

    try {
      if (hasProfilePhoto && !canManageMemberPhotos()) {
        throw new Error(getMemberPhotoUploadDisabledMessage());
      }
      if (hasProfilePhoto && !body.photo_consent) {
        throw new Error('Profile photo consent is required before saving a member photo.');
      }

      if (hasProfilePhoto) {
        const largeOriginal = photoUpload.size > (5 * 1024 * 1024);
        setFeedback(els.idFeedback, largeOriginal ? 'Preparing photo - large image detected' : 'Preparing photo');
        try {
          setFeedback(els.idFeedback, largeOriginal ? 'Compressing - large image detected' : 'Compressing');
          preparedPhotoUpload = await optimizePhotoUpload(photoUpload, {
            maxDimension: 1280,
            quality: 0.72
          });
        } catch (_error) {
          if (photoUpload.size > (10 * 1024 * 1024)) {
            const tooLargeError = new Error('Image too large');
            tooLargeError.code = 'profile_photo_too_large';
            throw tooLargeError;
          }

          preparedPhotoUpload = {
            blob: photoUpload,
            filename: photoUpload.name,
            originalSize: photoUpload.size,
            outputSize: photoUpload.size,
            usedFallback: true
          };
        }

        if (config.debugMode && typeof console !== 'undefined' && typeof console.debug === 'function') {
          console.debug('VMS Ops profile photo upload', {
            original_size: preparedPhotoUpload.originalSize,
            compressed_size: preparedPhotoUpload.outputSize,
            used_fallback: !!preparedPhotoUpload.usedFallback
          });
        }
      }

      let requestOptions = { method: 'POST', body };
      if (hasProfilePhoto) {
        const uploadBody = new FormData();
        Object.entries(body).forEach(([key, value]) => {
          uploadBody.append(key, String(value ?? ''));
        });
        uploadBody.append(
          'profile_photo',
          preparedPhotoUpload && preparedPhotoUpload.blob ? preparedPhotoUpload.blob : photoUpload,
          preparedPhotoUpload && preparedPhotoUpload.filename ? preparedPhotoUpload.filename : photoUpload.name
        );
        requestOptions = { method: 'POST', body: uploadBody, formData: true };
        setFeedback(els.idFeedback, buildPhotoStageMessage('Uploading', preparedPhotoUpload));
      }

      const data = await api('/id/manual-member', requestOptions);
      if (hasProfilePhoto) {
        setFeedback(els.idFeedback, buildPhotoStageMessage('Saving', preparedPhotoUpload));
      }
      hideManualMemberForm();
      state.manualMemberNumberFromScan = false;
      if (hasProfilePhoto) {
        setFeedback(els.idFeedback, 'Done');
      }
      if (String(els.idPayload?.value || '').trim() !== '') {
        window.setTimeout(() => {
          setFeedback(els.idFeedback, 'Member Added ✓. Logging...');
        }, hasProfilePhoto ? 100 : 0);
        await processIdPayload({ preserveProcessButton: true });
        return;
      }
      renderMemberResult({ member: data.member, flags: { effective_status: data.member.status } });
      window.setTimeout(() => {
        setFeedback(els.idFeedback, 'Member Added ✓');
      }, hasProfilePhoto ? 100 : 0);
    } catch (error) {
      setIdRetryLogVisible(true);
      let photoMessage = hasProfilePhoto ? mapProfilePhotoUploadMessage(error) : String(error?.message || 'Could not process image');
      if (hasProfilePhoto && (photoMessage === 'Image too large' || photoMessage === 'Could not process image')) {
        photoMessage = `${photoMessage}. Try a smaller photo.`;
      }
      setFeedback(els.idFeedback, photoMessage, true);
    }
  }

  function alertAudienceLabel(audience) {
    const key = String(audience || 'all').trim().toLowerCase();
    if (key === 'ticket') {
      return 'Ticket scanners';
    }
    if (key === 'id') {
      return 'ID scanners';
    }
    if (key === 'managers') {
      return 'Managers';
    }
    return 'All on-duty staff';
  }

  function alertRouteStrategyLabel(strategy) {
    const key = String(strategy || '').trim().toLowerCase();
    if (key === 'on_duty') {
      return 'On-duty routing';
    }
    if (key === 'on_duty_filtered') {
      return 'On-duty filtered routing';
    }
    if (key === 'manager_fallback') {
      return 'Manager fallback routing';
    }
    return '';
  }

  function getAlertRecipientCount(item) {
    const explicit = Number.parseInt(String(item?.recipient_count || '0'), 10);
    if (!Number.isNaN(explicit) && explicit > 0) {
      return explicit;
    }

    if (Array.isArray(item?.recipient_ids)) {
      return item.recipient_ids.length;
    }

    return 0;
  }

  function setAlertRoutingHint(targetEl, preset) {
    if (!targetEl) {
      return;
    }

    if (!preset || typeof preset !== 'object') {
      targetEl.textContent = '';
      return;
    }

    const audience = alertAudienceLabel(String(preset.audience || 'all'));
    const urgency = String(preset.urgency || 'normal').trim() || 'normal';
    targetEl.textContent = `Routes to: ${audience}. Default urgency: ${urgency}.`;
  }

  function syncAlertComposerFromPreset() {
    if (!els.alertPreset) {
      return;
    }

    const presetKey = String(els.alertPreset.value || '').trim();
    const preset = getAlertPresetByKey(presetKey);
    if (!preset) {
      setAlertRoutingHint(els.alertRoutingHint, null);
      return;
    }

    const isOther = presetKey === 'other';

    if (els.alertMessage) {
      els.alertMessage.classList.toggle('vms-ops-hidden', !isOther);
      els.alertMessage.disabled = !isOther;
      els.alertMessage.value = isOther ? '' : String(preset.message || '').trim();
    }

    if (els.alertUrgency) {
      els.alertUrgency.value = String(preset.urgency || 'normal').trim() || 'normal';
    }

    setAlertRoutingHint(els.alertRoutingHint, preset);
  }

  function isAlertRendered(alertId) {
    const safeAlertId = Number.parseInt(String(alertId || '0'), 10);
    if (Number.isNaN(safeAlertId) || safeAlertId <= 0 || !els.alertFeed) {
      return false;
    }
    return !!els.alertFeed.querySelector(`li[data-alert-id="${safeAlertId}"]`);
  }

  function renderAlerts(items) {
    if (!els.alertFeed) {
      return;
    }

    items.forEach((item) => {
      const current = Number(item.id || 0);
      if (current > state.lastAlertId) {
        state.lastAlertId = current;
      }

      if (isAlertRendered(current)) {
        return;
      }

      const li = document.createElement('li');
      li.dataset.alertId = String(current);
      li.dataset.urgency = item.urgency || 'normal';
      if (item.acknowledged_at) {
        li.classList.add('is-acked');
      }

      const title = document.createElement('strong');
      title.className = 'vms-ops-alert-feed-title';
      const urgencyText = String(item.urgency || 'normal').trim() || 'normal';
      const presetLabel = String(item.preset_label || item.preset_key || '').trim();
      title.textContent = presetLabel ? `${urgencyText} - ${presetLabel}` : `${urgencyText} - Alert Staff`;

      const message = document.createElement('p');
      message.className = 'vms-ops-alert-feed-message';
      message.textContent = String(item.message || '').trim() || 'New alert';

      const meta = document.createElement('small');
      meta.className = 'vms-ops-alert-feed-meta';
      const createdAt = String(item.created_at || '').trim();
      const senderName = String(item.sender_name || '').trim();
      if (createdAt && senderName) {
        meta.textContent = `${createdAt} • Sent by ${senderName}`;
      } else if (createdAt) {
        meta.textContent = createdAt;
      } else if (senderName) {
        meta.textContent = `Sent by ${senderName}`;
      } else {
        meta.textContent = '';
      }

      const status = document.createElement('small');
      status.className = 'vms-ops-alert-feed-status';
      const recipientCount = getAlertRecipientCount(item);
      const routeLabel = alertRouteStrategyLabel(item.route_strategy);
      const statusParts = [];
      if (recipientCount > 0) {
        statusParts.push(`Delivered to ${recipientCount}`);
      }
      if (routeLabel) {
        statusParts.push(routeLabel);
      }
      if (item.acknowledged_at) {
        const ackBy = String(item.acknowledged_by_name || '').trim();
        const ackAt = String(item.acknowledged_at || '').trim();
        if (ackBy && ackAt) {
          statusParts.push(`Acknowledged by ${ackBy} at ${ackAt}`);
        } else if (ackBy) {
          statusParts.push(`Acknowledged by ${ackBy}`);
        } else if (ackAt) {
          statusParts.push(`Acknowledged at ${ackAt}`);
        } else {
          statusParts.push('Acknowledged');
        }
      }
      status.textContent = statusParts.join(' • ');

      const ack = document.createElement('button');
      ack.type = 'button';
      ack.textContent = item.acknowledged_at ? 'Acknowledged' : 'Acknowledge';
      ack.disabled = !!item.acknowledged_at;
      ack.addEventListener('click', async () => {
        try {
          const response = await api(`/alerts/${item.id}/ack`, { method: 'POST', body: {} });
          const ackItem = response?.item && typeof response.item === 'object' ? response.item : {};
          const ackBy = String(ackItem.acknowledged_by_name || '').trim();
          const ackAt = String(ackItem.acknowledged_at || '').trim();
          const nextStatusParts = [];
          if (recipientCount > 0) {
            nextStatusParts.push(`Delivered to ${recipientCount}`);
          }
          if (routeLabel) {
            nextStatusParts.push(routeLabel);
          }
          if (ackBy && ackAt) {
            nextStatusParts.push(`Acknowledged by ${ackBy} at ${ackAt}`);
          } else if (ackBy) {
            nextStatusParts.push(`Acknowledged by ${ackBy}`);
          } else if (ackAt) {
            nextStatusParts.push(`Acknowledged at ${ackAt}`);
          } else {
            nextStatusParts.push('Acknowledged');
          }
          status.textContent = nextStatusParts.join(' • ');
          li.classList.add('is-acked');
          ack.textContent = 'Acknowledged';
          ack.disabled = true;
          if (ackItem.audit_warning) {
            setFeedback(els.alertFeedback, `Acknowledged with audit warning: ${ackItem.audit_warning}`, true);
          }
        } catch (error) {
          setFeedback(els.alertFeedback, error.message, true);
        }
      });

      li.appendChild(title);
      li.appendChild(message);
      li.appendChild(meta);
      if (status.textContent !== '') {
        li.appendChild(status);
      }
      li.appendChild(ack);
      els.alertFeed.prepend(li);

      if (!item.acknowledged_at && 'Notification' in window && Notification.permission === 'granted') {
        new Notification('VMS Ops Alert', {
          body: item.message || 'New alert',
          tag: `vms-alert-${item.id}`
        });
      }
    });

    persistAlertCursor();
  }

  async function loadAlertPresets() {
    if (!isAlertStaffEnabled()) {
      state.alertPresets = [];
      return [];
    }

    const venueId = getVenueId(false);
    const data = await api(`/alerts/presets?venue_id=${venueId}&console_type=ops`);
    const rawItems = Array.isArray(data.items) ? data.items : [];
    const items = rawItems.slice();

    if (!items.some((preset) => String(preset?.key || '') === 'other')) {
      items.push({
        key: 'other',
        label: 'Other',
        audience: 'all',
        message: '',
        urgency: 'normal'
      });
    }

    state.alertPresets = items;

    const fillSelect = (select) => {
      if (!select) {
        return;
      }

      select.innerHTML = '';
      items.forEach((preset) => {
        const option = document.createElement('option');
        option.value = preset.key;
        option.textContent = preset.label;
        option.dataset.message = preset.message;
        option.dataset.urgency = preset.urgency;
        option.dataset.audience = preset.audience || 'all';
        select.appendChild(option);
      });
    };

    fillSelect(els.alertPreset);
    fillSelect(els.callModalPreset);

    if (items[0] && els.alertPreset) {
      els.alertPreset.value = String(items[0].key || '').trim();
    }
    if (items[0] && els.callModalPreset) {
      els.callModalPreset.value = String(items[0].key || '').trim();
    }

    syncAlertComposerFromPreset();
    syncCallModalFromPreset();
    return items;
  }

  function getAlertPresetByKey(key) {
    const target = String(key || '').trim();
    if (!target) {
      return null;
    }
    return state.alertPresets.find((item) => String(item?.key || '') === target) || null;
  }

  async function sendAlert(options = {}) {
    if (!isAlertStaffEnabled()) {
      throw new Error('Alert Staff is disabled.');
    }

    if (!config.caps?.sendAlerts) {
      throw new Error('Your account is missing alert permissions.');
    }

    if (isLoginRequired() && !state.onDuty) {
      throw new Error('Log in to send alerts.');
    }

    const venueId = getVenueId(true);
    const presetKey = String(options.presetKey || els.alertPreset?.value || '').trim();
    const preset = getAlertPresetByKey(presetKey);
    const isOther = presetKey === 'other';
    const hasMessageOverride = typeof options.message === 'string';
    const hasUrgencyOverride = typeof options.urgency === 'string';
    const hasAudienceOverride = typeof options.audience === 'string';

    let message = hasMessageOverride ? String(options.message).trim() : '';
    let urgency = hasUrgencyOverride ? String(options.urgency).trim() : String(els.alertUrgency?.value || 'normal').trim();
    let audience = hasAudienceOverride ? String(options.audience).trim() : String(preset?.audience || 'all').trim();

    if (!hasMessageOverride) {
      if (isOther) {
        message = String(els.alertMessage?.value || '').trim();
      } else if (preset) {
        message = String(preset.message || '').trim();
      }
    }

    if (!hasUrgencyOverride && preset && (urgency === '' || urgency === 'normal')) {
      urgency = String(preset.urgency || 'normal').trim();
    }
    if (!hasAudienceOverride && preset && audience === '') {
      audience = String(preset.audience || 'all').trim();
    }
    if (audience === '') {
      audience = 'all';
    }

    if (message === '') {
      throw new Error(isOther ? 'Enter a custom message.' : 'Select an alert preset.');
    }

    if (!hasMessageOverride && preset && message === '') {
      message = String(preset.message || '').trim();
    }

    if (!hasUrgencyOverride && preset && (urgency === '' || urgency === 'normal')) {
      urgency = String(preset.urgency || 'normal').trim();
    }

    const data = await api('/alerts/send', {
      method: 'POST',
      body: {
        venue_id: venueId,
        console_type: 'ops',
        preset_key: presetKey,
        message,
        urgency,
        audience
      }
    });

    renderAlerts([data]);

    const recipientCount = getAlertRecipientCount(data);
    const routeLabel = alertRouteStrategyLabel(data.route_strategy);
    const feedbackMessage = routeLabel
      ? `Alert sent to ${recipientCount} recipients (${routeLabel}).`
      : `Alert sent to ${recipientCount} recipients.`;

    setFeedback(els.alertFeedback, feedbackMessage);
    showGlobalFeedback(options.successMessage || feedbackMessage);
    return data;
  }

  async function pollAlerts() {
    if (!isAlertStaffEnabled()) {
      return;
    }

    if (!config.caps?.receiveAlerts) {
      return;
    }

    if (isLoginRequired() && !state.onDuty) {
      return;
    }

    const venueId = getVenueId(false);
    try {
      const data = await api(`/alerts/inbox?venue_id=${venueId}&since_id=${state.lastAlertId}`);
      const items = data.items || [];
      if (items.length > 0) {
        renderAlerts(items.reverse());
      }
    } catch (error) {
      setFeedback(els.alertFeedback, error.message, true);
    }
  }

  function setPresenceLoading(loading, message) {
    const busy = !!loading;
    state.presenceBusy = busy;

    if (els.openPresence) {
      if (busy) {
        els.openPresence.dataset.originalText = els.openPresence.textContent || '';
        els.openPresence.textContent = typeof message === 'string' && message.trim() !== '' ? message.trim() : 'Working…';
        els.openPresence.disabled = true;
      } else {
        delete els.openPresence.dataset.originalText;
      }
    }

    if (els.venueSelect) {
      els.venueSelect.disabled = busy;
    }
    if (els.venueOverlaySelect) {
      els.venueOverlaySelect.disabled = busy;
    }
    if (els.venueOverlayContinue) {
      els.venueOverlayContinue.disabled = busy || !getVenueId(false);
    }

    syncPresenceActionAvailability();
  }

  async function startShift() {
    try {
      setPresenceLoading(true, 'Logging in…');
      const data = await api('/presence/start', {
        method: 'POST',
        body: {
          venue_id: getVenueId(true),
          device_id: config.deviceId,
          console_type: state.mode
        }
      });
      state.onDuty = true;
      syncPresenceToggleLabel();
      applyCapabilityVisibility();
      applyLoginGateVisibility();
      scheduleAttendeeAutoRefresh('start-shift');
      renderTicketMeta();

      setPresenceLoading(false);
      showGlobalFeedback('Logged in.');

      const activeVenueId = enforceVenueGate();
      if (activeVenueId > 0) {
        if (config.caps?.scanTickets) {
          refreshEvents({ selectionMode: 'login-default' }).catch((error) => setTicketStatus(error.message, 'error'));
        }
        if (isAlertStaffEnabled() && (config.caps?.sendAlerts || config.caps?.receiveAlerts)) {
          loadAlertPresets().catch((error) => setFeedback(els.alertFeedback, error.message, true));
        }
      }
    } catch (error) {
      setPresenceLoading(false);
      showGlobalFeedback(error.message, true);
    }
  }

  async function heartbeat() {
    if (!state.onDuty) {
      return;
    }

    try {
      await api('/presence/heartbeat', {
        method: 'POST',
        body: {
          venue_id: getVenueId(true),
          device_id: config.deviceId
        }
      });
    } catch (error) {
      if (isAuthError(error)) {
        state.onDuty = false;
        clearScannerWarmStream();
        syncPresenceToggleLabel();
        applyCapabilityVisibility();
        applyLoginGateVisibility();
        setPresenceCollapsed(false);
        scheduleAttendeeAutoRefresh('heartbeat-auth');
        renderTicketMeta();
        return;
      }
      setFeedback(els.presenceStatus, 'Connection issue. Still logged in locally.', true);
    }
  }

  async function endShift() {
    try {
      setPresenceLoading(true, "Logging out…");
      await api('/presence/end', {
        method: 'POST',
        body: {
          venue_id: getVenueId(true),
          device_id: config.deviceId
        }
      });
      state.onDuty = false;
      clearScannerWarmStream();
      syncPresenceToggleLabel();
      applyCapabilityVisibility();
      applyLoginGateVisibility();
      setPresenceCollapsed(false);
      scheduleAttendeeAutoRefresh('end-shift');
      renderTicketMeta();

      setPresenceLoading(false);
      showGlobalFeedback('Logged out.');
    } catch (error) {
      setPresenceLoading(false);
      showGlobalFeedback(error.message, true);
    }
  }

  function closeCallModal() {
    if (els.callModal) {
      els.callModal.hidden = true;
    }
    setFeedback(els.callModalFeedback, '');
  }

  function openCallModal(presetKey = 'call_staff') {
    if (!els.callModal) {
      return;
    }

    const preset = getAlertPresetByKey(presetKey) || state.alertPresets[0] || null;
    if (els.callModalPreset && preset) {
      els.callModalPreset.value = String(preset.key || '').trim();
    }

    syncCallModalFromPreset();

    els.callModal.hidden = false;

    setTimeout(() => {
      els.callModalPreset?.focus();
    }, 50);
  }

  function syncCallModalFromPreset() {
    if (!els.callModalPreset) {
      return;
    }
    const presetKey = String(els.callModalPreset.value || "").trim();
    const preset = getAlertPresetByKey(presetKey);
    if (!preset) {
      setAlertRoutingHint(els.callModalRouting, null);
      return;
    }

    const isOther = presetKey === "other";

    if (els.callModalMessageWrap) {
      els.callModalMessageWrap.hidden = !isOther;
    }

    if (els.callModalMessage) {
      els.callModalMessage.disabled = !isOther;
      els.callModalMessage.value = isOther ? "" : String(preset.message || "").trim();
    }
    if (els.callModalUrgency) {
      els.callModalUrgency.value = String(preset.urgency || "normal").trim() || "normal";
    }

    setAlertRoutingHint(els.callModalRouting, preset);
  }


  async function sendCallModalAlert() {
    try {
      const presetKey = String(els.callModalPreset?.value || '').trim();
      const isOther = presetKey === 'other';

      const payload = {
        presetKey
      };

      if (isOther) {
        payload.message = String(els.callModalMessage?.value || '').trim();
      }

      payload.urgency = String(els.callModalUrgency?.value || 'normal').trim();

      await sendAlert(payload);
      closeCallModal();
    } catch (error) {
      setFeedback(els.callModalFeedback, error.message, true);
      showGlobalFeedback(error.message, true);
    }
  }


  async function callStaffQuick() {
    if (!isAlertStaffEnabled()) {
      showGlobalFeedback('Alert Staff is disabled.', true);
      return;
    }

    if (!config.caps?.sendAlerts) {
      showGlobalFeedback('Alert Staff unavailable: missing alert permission.', true);
      return;
    }

    if (!state.alertPresets || state.alertPresets.length === 0) {
      try {
        await loadAlertPresets();
      } catch (error) {
        setFeedback(els.alertFeedback, error.message, true);
        showGlobalFeedback(error.message, true);
        return;
      }
    }

    openCallModal('call_staff');
  }

  async function onVenueChanged() {
    let venueId = 0;
    try {
      venueId = getVenueId(false);
    } catch (_error) {
      venueId = 0;
    }

    clearMemberLookupApiForbidden();
    setVenueId(venueId);
    if (venueId > 0) {
      persistVenueId(venueId);
    }
    resetAttendeeAutoRefreshState();
    closeMemberLookupTour();
    clearMemberLookupState({ preserveQuery: false });
    const activeVenueId = enforceVenueGate();

    if (!(activeVenueId > 0)) {
      scheduleAttendeeAutoRefresh('venue-change');
      setTicketStatus('Select a venue to load events.', 'info');
      setFeedback(els.alertFeedback, 'Select a venue to load alerts.', false);
      syncMemberLookupAvailability('venue_change');
      return;
    }

    showGlobalFeedback(`Venue set: ${activeVenueId}`);

    await loadPresenceStatus();
    applyCapabilityVisibility();
    applyLoginGateVisibility();

    if (isLoginRequired() && !state.onDuty) {
      return;
    }

    if (config.caps?.scanTickets) {
      refreshEvents({ selectionMode: 'login-default' }).catch((error) => setTicketStatus(error.message, 'error'));
    }

    if (isAlertStaffEnabled() && (config.caps?.sendAlerts || config.caps?.receiveAlerts)) {
      loadAlertPresets().catch((error) => setFeedback(els.alertFeedback, error.message, true));
    }

    scheduleAttendeeAutoRefresh('venue-change');
  }

  function bindEvents() {
    window.addEventListener('resize', setMode);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        renderSiteTime();
        maybeScheduleSiteTimeSync('visibility', true);
        handleAttendeeAutoRefreshWake('visibility');
      }
    });
    window.addEventListener('pageshow', () => {
      renderSiteTime();
      maybeScheduleSiteTimeSync('pageshow', true);
      handleAttendeeAutoRefreshWake('pageshow');
    });
    window.addEventListener('focus', () => {
      handleAttendeeAutoRefreshWake('focus');
    });
    document.addEventListener('resume', () => {
      handleAttendeeAutoRefreshWake('resume');
    });

    els.refreshEvents?.addEventListener('click', () => {
      refreshEvents().catch((error) => setTicketStatus(error.message, 'error'));
    });

    els.eventSelect?.addEventListener('change', () => {
      const selected = getSelectedEvent();
      state.selectedEventId = selected?.id || 0;
      state.selectedEventSource = selected?.source || '';
      let venueId = 0;
      try {
        venueId = getVenueId(false);
      } catch (_error) {
        venueId = 0;
      }
      persistEventId(venueId, state.selectedEventId);
      syncPersistedEventConfirmation(venueId, state.selectedEventId);
      clearTicketNotice();

      renderTicketMeta();
      clearAttendeeLookup();
      renderAttendeeLookup();

      if (state.selectedEventId > 0 && isSelectedTicketEventConfirmed()) {
        loadAttendeesToCache().catch((error) => setTicketStatus(error.message, 'error'));
      } else if (state.selectedEventId > 0) {
        setTicketStatus('Confirm this active event before scanning.', 'info');
      }
      scheduleAttendeeAutoRefresh('event-change');
    });

    els.confirmEvent?.addEventListener('click', () => {
      confirmSelectedTicketEvent().catch((error) => setTicketStatus(error.message, 'error'));
    });

    els.changeEvent?.addEventListener('click', () => {
      focusEventPickerForChange();
    });

    els.loadAttendees?.addEventListener('click', () => {
      loadAttendeesToCache().catch((error) => setTicketStatus(error.message, 'error'));
    });

    els.attendeeSearch?.addEventListener('input', () => {
      renderAttendeeLookup();
    });

    els.attendeeSearch?.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        clearAttendeeLookup();
      }
    });

    els.attendeeClear?.addEventListener('click', () => {
      clearAttendeeLookup();
    });

    els.memberLookupSearch?.addEventListener('click', () => {
      searchMembersForLookup().catch((error) => setFeedback(els.memberLookupFeedback, error.message, true));
    });
    els.memberLookupQuery?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        searchMembersForLookup().catch((error) => setFeedback(els.memberLookupFeedback, error.message, true));
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        clearMemberLookupState({ preserveQuery: false });
        setFeedback(els.memberLookupFeedback, 'Member lookup cleared.');
      }
    });
    els.memberLookupClear?.addEventListener('click', () => {
      clearMemberLookupState({ preserveQuery: false });
      setFeedback(els.memberLookupFeedback, 'Member lookup cleared.');
    });
    els.memberLookupResults?.addEventListener('click', (event) => {
      const trigger = event.target?.closest?.('[data-lookup-member-open]');
      const memberId = trigger?.getAttribute?.('data-lookup-member-open');
      if (!memberId) {
        return;
      }
      openMemberLookup(memberId).catch((error) => setFeedback(els.memberLookupFeedback, error.message, true));
    });
    els.memberLookupTour?.addEventListener('click', () => {
      openMemberLookupTour();
    });
    els.memberLookupHeading?.addEventListener('click', (event) => {
      event.preventDefault();
      setMemberLookupCollapsed(!state.memberLookupCollapsed);
    });
    els.memberLookupHeading?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        setMemberLookupCollapsed(!state.memberLookupCollapsed);
      }
    });

    els.ticketSubmit?.addEventListener('click', () => {
      submitTicketCheckin().catch(() => {});
    });

    els.ticketSubmitAll?.addEventListener('click', () => {
      submitTicketCheckin({ qtyMode: 'all_remaining' }).catch(() => {});
    });

    els.ticketScanCamera?.addEventListener('click', () => {
      clearTicketNotice();
      if (!requireConfirmedTicketEvent()) {
        return;
      }
      openScanner('ticket');
    });

    els.ticketScan?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        submitTicketCheckin().catch(() => {});
      }
    });
    els.ticketScan?.addEventListener('input', () => {
      clearTicketNotice();
      syncTicketSubmitAllButton();
    });

    els.idProcess?.addEventListener('click', () => {
      processIdPayload({ preserveProcessButton: true }).catch((error) => setFeedback(els.idFeedback, error.message, true));
    });

    els.idRetryLog?.addEventListener('click', () => {
      processIdPayload({ preserveProcessButton: true }).catch((error) => setFeedback(els.idFeedback, error.message, true));
    });

    els.idScanCamera?.addEventListener('click', () => {
      openScanner('id');
    });
    els.idResult?.addEventListener('click', async (event) => {
      const trigger = event.target?.closest?.('[data-member-delete]');
      const memberId = trigger?.getAttribute?.('data-member-delete');
      if (!trigger || !memberId) {
        return;
      }

      trigger.disabled = true;
      try {
        const deleted = await deleteMemberRecord(memberId, {
          memberName: trigger.getAttribute('data-member-name') || ''
        });
        if (!deleted) {
          return;
        }

        if (els.idResult) {
          els.idResult.textContent = '';
        }
        renderIdAgeCard(null);
        hideIdNotFoundPrompt();
        hideBannedOverlay();
        setFeedback(els.idFeedback, 'Member deleted. Scan again to retest add flow.');
        showGlobalFeedback('Member deleted.');
      } catch (error) {
        setFeedback(els.idFeedback, error.message, true);
      } finally {
        if (trigger && document.body.contains(trigger)) {
          trigger.disabled = false;
        }
      }
    });

    els.idAddMember?.addEventListener('click', () => {
      addMemberFromScanPrompt().catch((error) => setFeedback(els.idFeedback, error.message, true));
    });

    els.idNotFoundCancel?.addEventListener('click', () => {
      hideIdNotFoundPrompt();
      setFeedback(els.idFeedback, 'Scan cancelled.');
    });

    els.manualForm?.addEventListener('submit', (event) => {
      submitManualMember(event).catch((error) => setFeedback(els.idFeedback, error.message, true));
    });

    els.manualHeading?.addEventListener('click', (event) => {
      event.preventDefault();
      toggleManualMemberForm();
    });
    els.manualHeading?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        toggleManualMemberForm();
      }
    });

    els.ticketHeading?.addEventListener('click', (event) => {
      event.preventDefault();
      setTicketCollapsed(!state.ticketCollapsed);
    });
    els.ticketHeading?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        setTicketCollapsed(!state.ticketCollapsed);
      }
    });

    els.idHeading?.addEventListener('click', (event) => {
      event.preventDefault();
      setIdCollapsed(!state.idCollapsed);
    });
    els.idHeading?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        setIdCollapsed(!state.idCollapsed);
      }
    });

    els.alertPreset?.addEventListener('change', syncAlertComposerFromPreset);

    els.alertSend?.addEventListener('click', () => {
      sendAlert().catch((error) => setFeedback(els.alertFeedback, error.message, true));
    });

    els.callStaff?.addEventListener('click', () => {
      callStaffQuick().catch((error) => setFeedback(els.alertFeedback, error.message, true));
    });

    els.openPresence?.addEventListener('click', () => {
      if (!isLoginRequired() || state.presenceBusy) {
        return;
      }

      if (state.onDuty) {
        endShift().catch((error) => {
          setFeedback(els.presenceStatus, error.message, true);
          showGlobalFeedback(error.message, true);
        });
        return;
      }

      startShift().catch((error) => {
        setFeedback(els.presenceStatus, error.message, true);
        showGlobalFeedback(error.message, true);
      });
    });

    els.callModalClose?.addEventListener('click', closeCallModal);
    els.callModalCancel?.addEventListener('click', closeCallModal);
    els.callModalPreset?.addEventListener('change', syncCallModalFromPreset);
    els.callModalSend?.addEventListener('click', () => {
      sendCallModalAlert();
    });
    els.callModal?.addEventListener('click', (event) => {
      if (event.target === els.callModal) {
        closeCallModal();
      }
    });

    els.venueOverlaySelect?.addEventListener('change', () => {
      setVenueId(els.venueOverlaySelect.value);
      onVenueChanged().catch((error) => showGlobalFeedback(error.message, true));
    });

    els.venueOverlayContinue?.addEventListener('click', () => {
      onVenueChanged().catch((error) => showGlobalFeedback(error.message, true));
    });

    els.venueRetry?.addEventListener('click', () => {
      hydrateConsoleState({ maxAttempts: 3 }).catch((error) => showGlobalFeedback(error.message, true));
    });

    els.generateMemberNumber?.addEventListener('click', () => {
      if (!els.memberNumberInput) {
        return;
      }
      if (state.manualMemberNumberFromScan && String(els.memberNumberInput.value || '').trim() !== '') {
        const confirmed = window.confirm('Member ID was set from scanned ID. Overwrite anyway?');
        if (!confirmed) {
          return;
        }
      }
      const rand = Math.floor(Math.random() * 900000) + 100000;
      els.memberNumberInput.value = `M-${rand}`;
      state.manualMemberNumberFromScan = false;
    });

    els.venueSelect?.addEventListener('change', () => {
      onVenueChanged().catch((error) => showGlobalFeedback(error.message, true));
    });

    els.startShift?.addEventListener('click', () => {
      startShift().catch((error) => setFeedback(els.presenceStatus, error.message, true));
    });

    els.endShift?.addEventListener('click', () => {
      endShift().catch((error) => setFeedback(els.presenceStatus, error.message, true));
    });

    els.presenceHeading?.addEventListener('click', () => {
      setPresenceCollapsed(!state.presenceCollapsed);
    });
    els.presenceHeading?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        setPresenceCollapsed(!state.presenceCollapsed);
      }
    });

    els.bannedClear?.addEventListener('mousedown', startBannedHold);
    els.bannedClear?.addEventListener('touchstart', (event) => {
      event.preventDefault();
      startBannedHold();
    }, { passive: false });
    els.bannedClear?.addEventListener('mouseup', releaseBannedHold);
    els.bannedClear?.addEventListener('mouseleave', releaseBannedHold);
    els.bannedClear?.addEventListener('touchend', (event) => {
      event.preventDefault();
      releaseBannedHold();
    });
    els.bannedClear?.addEventListener('touchcancel', releaseBannedHold);

    els.scanClose?.addEventListener('click', closeScanner);
    els.scanCancel?.addEventListener('click', closeScanner);
    els.scanFlip?.addEventListener('click', () => {
      flipScannerCamera();
    });
    els.scanTorch?.addEventListener('click', () => {
      applyScannerTorchState(!state.scannerTorchOn);
    });
    els.scanZoomIn?.addEventListener('click', () => {
      bumpScannerZoom(1);
    });
    els.scanZoomOut?.addEventListener('click', () => {
      bumpScannerZoom(-1);
    });
    els.scanZoomReset?.addEventListener('click', () => {
      resetScannerZoom();
    });
    els.scanViewport?.addEventListener('pointerdown', (event) => {
      handleScannerViewportTap(event.clientX, event.clientY);
    });
    els.scanModal?.addEventListener('click', (event) => {
      if (event.target === els.scanModal) {
        closeScanner({ reason: 'USER_EXITED', source: 'manual_exit' });
      }
    });

    window.addEventListener('pagehide', clearScannerWarmStream);
    window.addEventListener('beforeunload', clearScannerWarmStream);

    window.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && memberLookupTourOverlay) {
        closeMemberLookupTour();
        return;
      }
      if (event.key === 'Escape' && !els.scanModal?.hidden) {
        closeScanner({ reason: 'USER_EXITED', source: 'manual_exit' });
      }
    });

    window.addEventListener('online', () => {
      syncTicketQueue();
      maybeScheduleSiteTimeSync('online', true);
      handleAttendeeAutoRefreshWake('online');
    });
  }

  function registerServiceWorker() {
    if (!('serviceWorker' in navigator) || !config.swUrl) {
      return;
    }

    let scopePath = '/vms-ops/';
    try {
      const shellUrl = new URL(config.shellUrl || '/vms-ops/', window.location.origin);
      scopePath = shellUrl.pathname.endsWith('/') ? shellUrl.pathname : `${shellUrl.pathname}/`;
    } catch (_error) {
      scopePath = '/vms-ops/';
    }

    navigator.serviceWorker.register(config.swUrl, { scope: scopePath }).catch(() => {});
  }

  function requestNotificationPermission() {
    if (!isAlertStaffEnabled() || !config.caps?.receiveAlerts) {
      return;
    }
    if (!('Notification' in window)) {
      return;
    }

    if (Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }

  function wait(ms) {
    return new Promise((resolve) => {
      window.setTimeout(resolve, Math.max(0, Number(ms) || 0));
    });
  }

  function bootstrapHasUsableVenueRows(data) {
    const venues = Array.isArray(data?.venues) ? data.venues : [];
    return venues.some((venue) => {
      const rawVenueId = venue && typeof venue === 'object'
        ? (venue.id ?? venue.venue_id ?? venue.post_id ?? venue.ID ?? 0)
        : 0;
      const venueId = Number.parseInt(String(rawVenueId || '0'), 10);
      return !Number.isNaN(venueId) && venueId > 0;
    });
  }

  async function loadBootstrapData(options = {}) {
    const maxAttempts = Math.max(1, Number.parseInt(String(options.maxAttempts || '3'), 10) || 3);

    state.bootstrapBusy = true;
    state.bootstrapFailed = false;
    state.bootstrapErrorMessage = '';
    state.venuesLoaded = false;
    resetVenueSelectors();
    setVenueId(0);
    if (els.app) {
      els.app.classList.add('is-venues-loading');
    }
    updateVenueOverlayState();
    setVenueGateOpen(true);

    let lastError = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
      try {
        const bootstrapData = await api('/bootstrap');
        if (!bootstrapHasUsableVenueRows(bootstrapData)) {
          const emptyError = new Error('Could not load venues. Retry or log out and back in.');
          emptyError.code = 'bootstrap_venues_empty';
          throw emptyError;
        }

        applyBootstrapData(bootstrapData);
        state.bootstrapBusy = false;
        state.bootstrapFailed = false;
        state.bootstrapErrorMessage = '';
        updateVenueOverlayState();
        return bootstrapData;
      } catch (error) {
        lastError = error;
        if (attempt < maxAttempts) {
          await wait(450 * attempt);
        }
      }
    }

    state.bootstrapBusy = false;
    state.bootstrapFailed = true;
    state.bootstrapErrorMessage = 'Could not load venues. Retry or log out and back in.';
    state.venuesLoaded = false;
    resetVenueSelectors();
    setVenueId(0);
    persistVenueId(0);
    updateVenueOverlayState();

    if (els.presenceStatus) {
      setFeedback(els.presenceStatus, state.bootstrapErrorMessage, true);
    }
    if (lastError) {
      showGlobalFeedback(state.bootstrapErrorMessage, true);
    }

    return null;
  }

  async function hydrateConsoleState(options = {}) {
    clearMemberLookupApiForbidden();
    await loadBootstrapData(options);
    const activeVenueId = enforceVenueGate();

    await loadPresenceStatus();
    applyCapabilityVisibility();
    applyLoginGateVisibility();

    const canLoadPanels = activeVenueId > 0 && (!isLoginRequired() || state.onDuty);

    if (canLoadPanels && config.caps?.scanTickets) {
      refreshEvents({ selectionMode: 'login-default' }).catch((error) => setTicketStatus(error.message, 'error'));
    }

    if (canLoadPanels && isAlertStaffEnabled() && (config.caps?.sendAlerts || config.caps?.receiveAlerts)) {
      loadAlertPresets().catch((error) => setFeedback(els.alertFeedback, error.message, true));
    }

    renderAttendeeLookup();
    scheduleAttendeeAutoRefresh('hydrate');
  }

  async function initialLoad() {
    await hydrateConsoleState({ maxAttempts: 3 });

    if (isAlertStaffEnabled() && config.caps?.receiveAlerts) {
      pollAlerts();
      setInterval(pollAlerts, 15000);
    }

    setInterval(heartbeat, 60000);
    setInterval(syncTicketQueue, 10000);
    scheduleAttendeeAutoRefresh('initial-load');
  }

  function init() {
    if (!config.restRoot || !config.nonce) {
      return;
    }

    hideBannedOverlay();
    hideIdNotFoundPrompt();
    closeMemberLookupTour();
    clearMemberLookupState({ preserveQuery: false });
    renderIdAgeCard(null);
    applySiteTimePayload(config);
    startSiteTimeClock();
    setIdProcessButtonVisible(false);
    setIdRetryLogVisible(false);
    setScannerStatus('SCANNING...');
    closeScanner({ reason: 'APP_RESET', source: 'app_init' });
    maybeResetSessionScopedVenueState();
    loadPersistedState();
    loadPersistedScannerPrefs();
    state.attendeeAutoRefreshJitterMs = computeDeviceJitterMs(30000);
    resetAttendeeAutoRefreshState();
    setPresenceCollapsed(false);
    setTicketCollapsed(state.ticketCollapsed, false);
    setIdCollapsed(state.idCollapsed, false);
    setMemberLookupCollapsed(state.memberLookupCollapsed, false);
    setManualFormVisible(false);
    syncManualMemberPhotoFields();
    setMode();
    updateVenueOverlayState();
    setVenueGateOpen(true);
    bindEvents();
    renderTicketMeta();
    syncPresenceActionAvailability();
    registerServiceWorker();
    requestNotificationPermission();
    initialLoad();
    maybeScheduleSiteTimeSync('load', true);
    if (!state.siteTimeSyncTimer) {
      state.siteTimeSyncTimer = window.setInterval(() => {
        maybeScheduleSiteTimeSync('interval');
      }, 10 * 60 * 1000);
    }

    if ((!isAlertStaffEnabled() || !config.caps?.sendAlerts) && els.callStaff) {
      els.callStaff.classList.add('is-disabled');
      els.callStaff.disabled = true;
    }
  }

  init();
})();
