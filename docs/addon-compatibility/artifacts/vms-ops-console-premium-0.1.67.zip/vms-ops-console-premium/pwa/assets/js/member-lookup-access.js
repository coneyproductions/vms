(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
    return;
  }

  root.VMS_OPS_MEMBER_LOOKUP_ACCESS = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  function asBool(value) {
    return value === true || value === 1 || value === '1';
  }

  function isFeatureEnabled(settings) {
    if (!settings || typeof settings !== 'object') {
      return true;
    }

    return settings.member_lookup_enabled !== false && settings.member_lookup_enabled !== 0 && settings.member_lookup_enabled !== '0';
  }

  function normalizeCaps(rawCaps) {
    const caps = rawCaps && typeof rawCaps === 'object' ? rawCaps : {};

    return {
      usePwa: asBool(caps.usePwa),
      memberLookup: asBool(caps.memberLookup),
      manageOptions: asBool(caps.manageOptions)
    };
  }

  function getMemberLookupAccessState(input) {
    const data = input && typeof input === 'object' ? input : {};
    const caps = normalizeCaps(data.caps);
    const permissionPayloadVersion = Number(data.permissionPayloadVersion || 0);
    const requiresPresence = !!data.requiresPresence;
    const onDuty = !!data.onDuty;
    const hasActiveVenue = !!data.hasActiveVenue;

    if (!isFeatureEnabled(data.settings)) {
      return {
        visible: false,
        allowed: false,
        reason: 'unknown',
        detail: 'feature_disabled'
      };
    }

    if (permissionPayloadVersion < 2) {
      return {
        visible: true,
        allowed: false,
        reason: 'stale_session_payload',
        detail: 'payload_version'
      };
    }

    if (!caps.usePwa && !caps.manageOptions) {
      return {
        visible: false,
        allowed: false,
        reason: 'missing_ops_access',
        detail: 'base_access_required'
      };
    }

    if (requiresPresence && !onDuty) {
      return {
        visible: true,
        allowed: false,
        reason: 'no_active_session',
        detail: 'presence_required'
      };
    }

    if (!hasActiveVenue) {
      return {
        visible: true,
        allowed: false,
        reason: 'unknown',
        detail: 'venue_required'
      };
    }

    if (caps.memberLookup || caps.manageOptions) {
      return {
        visible: true,
        allowed: true,
        reason: '',
        detail: ''
      };
    }

    return {
      visible: true,
      allowed: false,
      reason: 'missing_member_lookup_cap',
      detail: 'member_lookup_required'
    };
  }

  return {
    getMemberLookupAccessState: getMemberLookupAccessState
  };
});
