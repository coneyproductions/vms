(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
    return;
  }

  root.VMS_OPS_MEMBER_PHOTO_CAPTURE = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  function normalizeCaptureMode(value) {
    return String(value || '').trim().toLowerCase() === 'user' ? 'user' : 'environment';
  }

  function toggleCaptureMode(currentMode) {
    return normalizeCaptureMode(currentMode) === 'environment' ? 'user' : 'environment';
  }

  function cameraModeLabel(mode) {
    return normalizeCaptureMode(mode) === 'environment' ? 'Rear Camera' : 'Front Camera';
  }

  function applyCaptureMode(input, mode) {
    const nextMode = normalizeCaptureMode(mode);
    if (input && typeof input.setAttribute === 'function') {
      input.setAttribute('capture', nextMode);
      input.setAttribute('data-camera-preference', nextMode);
    }
    return nextMode;
  }

  return {
    applyCaptureMode,
    cameraModeLabel,
    normalizeCaptureMode,
    toggleCaptureMode
  };
});
