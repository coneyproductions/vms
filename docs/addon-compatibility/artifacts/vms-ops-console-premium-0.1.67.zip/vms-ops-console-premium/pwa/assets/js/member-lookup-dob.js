(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
    return;
  }

  root.VMS_OPS_MEMBER_LOOKUP_DOB = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  function pad2(value) {
    const number = Number.parseInt(String(value || ''), 10);
    if (!Number.isFinite(number)) {
      return '';
    }

    return String(number).padStart(2, '0');
  }

  function sanitizeDigits(value) {
    return String(value || '').replace(/\D+/g, '').slice(0, 8);
  }

  function formatDigitsAsDob(value) {
    const digits = sanitizeDigits(value);
    if (digits.length <= 2) {
      return digits;
    }
    if (digits.length <= 4) {
      return `${digits.slice(0, 2)}/${digits.slice(2)}`;
    }

    return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
  }

  function countDigitsBeforeCaret(value, caretIndex) {
    const raw = String(value || '');
    const safeIndex = Math.max(0, Math.min(raw.length, Number.isFinite(caretIndex) ? caretIndex : raw.length));
    return sanitizeDigits(raw.slice(0, safeIndex)).length;
  }

  function getCaretIndexForDigitCount(value, digitCount) {
    const formattedValue = String(value || '');
    const safeDigitCount = Math.max(0, Math.min(sanitizeDigits(formattedValue).length, Number.isFinite(digitCount) ? digitCount : 0));
    if (safeDigitCount <= 0) {
      return 0;
    }

    let seenDigits = 0;
    for (let index = 0; index < formattedValue.length; index += 1) {
      if (/\d/.test(formattedValue.charAt(index))) {
        seenDigits += 1;
        if (seenDigits >= safeDigitCount) {
          return index + 1;
        }
      }
    }

    return formattedValue.length;
  }

  function buildMaskedDobValue(rawDigits, nextDigitCaret) {
    const digits = sanitizeDigits(rawDigits);
    const formattedValue = formatDigitsAsDob(digits);
    const caretIndex = getCaretIndexForDigitCount(formattedValue, nextDigitCaret);

    return {
      handled: true,
      digits,
      formattedValue,
      selectionStart: caretIndex,
      selectionEnd: caretIndex
    };
  }

  function applyDobInputEdit(value, selectionStart, selectionEnd, inputType, inputData) {
    const rawValue = String(value || '');
    const type = String(inputType || '').trim();
    if (type === '') {
      return null;
    }

    const start = Math.max(0, Math.min(rawValue.length, Number.isFinite(selectionStart) ? selectionStart : rawValue.length));
    const end = Math.max(start, Math.min(rawValue.length, Number.isFinite(selectionEnd) ? selectionEnd : start));
    const digits = sanitizeDigits(rawValue);
    const startDigitIndex = countDigitsBeforeCaret(rawValue, start);
    const endDigitIndex = countDigitsBeforeCaret(rawValue, end);

    if (type === 'deleteContentBackward') {
      if (startDigitIndex !== endDigitIndex) {
        return buildMaskedDobValue(
          `${digits.slice(0, startDigitIndex)}${digits.slice(endDigitIndex)}`,
          startDigitIndex
        );
      }

      if (startDigitIndex <= 0) {
        return buildMaskedDobValue(digits, 0);
      }

      return buildMaskedDobValue(
        `${digits.slice(0, startDigitIndex - 1)}${digits.slice(endDigitIndex)}`,
        startDigitIndex - 1
      );
    }

    if (type === 'deleteContentForward') {
      if (startDigitIndex !== endDigitIndex) {
        return buildMaskedDobValue(
          `${digits.slice(0, startDigitIndex)}${digits.slice(endDigitIndex)}`,
          startDigitIndex
        );
      }

      if (startDigitIndex >= digits.length) {
        return buildMaskedDobValue(digits, startDigitIndex);
      }

      return buildMaskedDobValue(
        `${digits.slice(0, startDigitIndex)}${digits.slice(startDigitIndex + 1)}`,
        startDigitIndex
      );
    }

    if (type === 'deleteByCut') {
      return buildMaskedDobValue(
        `${digits.slice(0, startDigitIndex)}${digits.slice(endDigitIndex)}`,
        startDigitIndex
      );
    }

    if (
      type === 'insertText'
      || type === 'insertReplacementText'
      || type === 'insertCompositionText'
      || type === 'insertFromPaste'
    ) {
      const insertedDigits = sanitizeDigits(inputData);
      if (insertedDigits === '') {
        return null;
      }

      const prefix = digits.slice(0, startDigitIndex);
      const suffix = digits.slice(endDigitIndex);
      const remainingSpace = Math.max(0, 8 - prefix.length);
      const inserted = insertedDigits.slice(0, remainingSpace);
      const suffixSpace = Math.max(0, 8 - prefix.length - inserted.length);
      const nextDigits = `${prefix}${inserted}${suffix.slice(0, suffixSpace)}`;

      return buildMaskedDobValue(nextDigits, prefix.length + inserted.length);
    }

    return null;
  }

  function isPlausibleDate(year, month, day) {
    if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) {
      return false;
    }

    const date = new Date(year, month - 1, day);
    if (
      Number.isNaN(date.getTime())
      || date.getFullYear() !== year
      || (date.getMonth() + 1) !== month
      || date.getDate() !== day
    ) {
      return false;
    }

    const today = new Date();
    const oldest = new Date(today.getFullYear() - 130, today.getMonth(), today.getDate());
    if (date > today || date < oldest) {
      return false;
    }

    return year >= 1900;
  }

  function toIsoDate(year, month, day) {
    if (!isPlausibleDate(year, month, day)) {
      return '';
    }

    return `${String(year).padStart(4, '0')}-${pad2(month)}-${pad2(day)}`;
  }

  function normalizeDobInput(value) {
    const raw = String(value || '').trim();
    if (raw === '') {
      return '';
    }

    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
      const parts = raw.split('-');
      return toIsoDate(
        Number.parseInt(parts[0] || '', 10),
        Number.parseInt(parts[1] || '', 10),
        Number.parseInt(parts[2] || '', 10)
      );
    }

    const slashMatch = raw.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
    if (slashMatch) {
      return toIsoDate(
        Number.parseInt(slashMatch[3] || '', 10),
        Number.parseInt(slashMatch[1] || '', 10),
        Number.parseInt(slashMatch[2] || '', 10)
      );
    }

    const digits = sanitizeDigits(raw);
    if (digits.length === 8) {
      const monthFirst = toIsoDate(
        Number.parseInt(digits.slice(4) || '', 10),
        Number.parseInt(digits.slice(0, 2) || '', 10),
        Number.parseInt(digits.slice(2, 4) || '', 10)
      );
      if (monthFirst !== '') {
        return monthFirst;
      }

      return toIsoDate(
        Number.parseInt(digits.slice(0, 4) || '', 10),
        Number.parseInt(digits.slice(4, 6) || '', 10),
        Number.parseInt(digits.slice(6, 8) || '', 10)
      );
    }

    return '';
  }

  function autoFormatDobInput(value) {
    const raw = String(value || '');
    if (raw.trim() === '') {
      return '';
    }
    return formatDigitsAsDob(raw);
  }

  function getDobInputState(value) {
    const raw = String(value || '');
    const digits = sanitizeDigits(raw);
    const formattedValue = autoFormatDobInput(raw);
    const normalizedValue = normalizeDobInput(raw);
    const hasDelimiters = /[/-]/.test(raw);
    const isComplete = normalizedValue !== '';
    const isDigitsEntry = !hasDelimiters;
    const needsMoreDigits = !isComplete && isDigitsEntry && digits.length < 8;

    return {
      rawValue: raw,
      formattedValue,
      normalizedValue,
      digits,
      digitCount: digits.length,
      hasDelimiters,
      isDigitsEntry,
      isComplete,
      needsMoreDigits
    };
  }

  function getDobFeedbackMessage(value, options) {
    const state = getDobInputState(value);
    const settings = options && typeof options === 'object' ? options : {};
    if (!state.isComplete) {
      if (settings.optionalInput && state.digitCount === 0) {
        return '';
      }

      const invalidComplete = state.digitCount >= 8 && !state.needsMoreDigits;
      return invalidComplete ? 'Enter a valid DOB: MMDDYYYY' : '';
    }

    return '';
  }

  return {
    applyDobInputEdit,
    autoFormatDobInput,
    countDigitsBeforeCaret,
    formatDigitsAsDob,
    getCaretIndexForDigitCount,
    getDobFeedbackMessage,
    getDobInputState,
    normalizeDobInput,
    sanitizeDigits
  };
});
