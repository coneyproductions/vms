<?php

declare(strict_types=1);

define('ABSPATH', __DIR__);

if (!class_exists('WP_User')) {
    class WP_User
    {
        public int $ID;
        public array $caps;

        public function __construct(int $id = 0, array $caps = array())
        {
            $this->ID = $id;
            $this->caps = $caps;
        }
    }
}

if (!class_exists('WP_Error')) {
    class WP_Error
    {
        private string $code;
        private string $message;
        private array $data;

        public function __construct(string $code = '', string $message = '', $data = array())
        {
            $this->code = $code;
            $this->message = $message;
            $this->data = is_array($data) ? $data : array();
        }

        public function get_error_code(): string
        {
            return $this->code;
        }

        public function get_error_message(): string
        {
            return $this->message;
        }

        public function get_error_data(): array
        {
            return $this->data;
        }
    }
}

if (!class_exists('WP_REST_Request')) {
    class WP_REST_Request
    {
        private string $route;
        private array $params;

        public function __construct(string $route = '', array $params = array())
        {
            $this->route = $route;
            $this->params = $params;
        }

        public function get_route(): string
        {
            return $this->route;
        }

        public function get_param(string $key)
        {
            return $this->params[$key] ?? null;
        }
    }
}

if (!class_exists('WP_REST_Response')) {
    class WP_REST_Response
    {
        public array $data;
        public int $status;

        public function __construct($data = array(), int $status = 200)
        {
            $this->data = is_array($data) ? $data : array();
            $this->status = $status;
        }
    }
}

if (!class_exists('WP_REST_Server')) {
    class WP_REST_Server
    {
        public const READABLE = 'GET';
        public const CREATABLE = 'POST';
        public const EDITABLE = 'POST';
        public const DELETABLE = 'DELETE';
    }
}

$GLOBALS['vms_ops_test_user'] = new WP_User(77, array(
    'vms_ops_member_lookup' => true,
    'vms_ops_scan_ids' => true,
));
$GLOBALS['vms_ops_test_visit_mode'] = 'served';
$GLOBALS['vms_ops_test_visit_calls'] = array();
$GLOBALS['vms_ops_test_lookup_logs'] = array();
$GLOBALS['vms_ops_test_last_lookup_marks'] = array();
$GLOBALS['vms_ops_test_lookup_detail'] = array(
    'status' => 'active',
    'requires_confidence' => 1,
    'requires_dob_entry' => 1,
    'photo_match_available' => 0,
    'age_verified_at' => '2026-05-31 21:00:00',
    'blocking_reason' => '',
);

if (!function_exists('is_wp_error')) {
    function is_wp_error($value): bool
    {
        return $value instanceof WP_Error;
    }
}

if (!function_exists('sanitize_text_field')) {
    function sanitize_text_field(string $value): string
    {
        return trim($value);
    }
}

if (!function_exists('sanitize_key')) {
    function sanitize_key(string $value): string
    {
        return strtolower((string) preg_replace('/[^a-z0-9_\-]/', '', $value));
    }
}

if (!function_exists('absint')) {
    function absint($value): int
    {
        return abs((int) $value);
    }
}

if (!function_exists('__')) {
    function __(string $value, string $domain = ''): string
    {
        return $value;
    }
}

if (!function_exists('add_filter')) {
    function add_filter(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('add_action')) {
    function add_action(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('register_rest_route')) {
    function register_rest_route(string $namespace, string $route, array $args = array()): bool
    {
        return true;
    }
}

if (!function_exists('get_current_user_id')) {
    function get_current_user_id(): int
    {
        return $GLOBALS['vms_ops_test_user'] instanceof WP_User ? $GLOBALS['vms_ops_test_user']->ID : 0;
    }
}

if (!function_exists('wp_get_current_user')) {
    function wp_get_current_user()
    {
        return $GLOBALS['vms_ops_test_user'];
    }
}

if (!function_exists('get_user_by')) {
    function get_user_by(string $field, $value)
    {
        if ($field === 'id' && $GLOBALS['vms_ops_test_user'] instanceof WP_User && $GLOBALS['vms_ops_test_user']->ID === (int) $value) {
            return $GLOBALS['vms_ops_test_user'];
        }

        return null;
    }
}

if (!function_exists('user_can')) {
    function user_can($user, string $cap): bool
    {
        return $user instanceof WP_User && !empty($user->caps[$cap]);
    }
}

if (!function_exists('current_user_can')) {
    function current_user_can(string $cap): bool
    {
        return user_can(wp_get_current_user(), $cap);
    }
}

if (!function_exists('is_user_logged_in')) {
    function is_user_logged_in(): bool
    {
        return get_current_user_id() > 0;
    }
}

if (!function_exists('wp_verify_nonce')) {
    function wp_verify_nonce(string $nonce, string $action): int
    {
        return 1;
    }
}

if (!function_exists('wp_timezone_string')) {
    function wp_timezone_string(): string
    {
        return 'America/Chicago';
    }
}

if (!function_exists('wp_json_encode')) {
    function wp_json_encode($value): string
    {
        return json_encode($value, JSON_UNESCAPED_SLASHES) ?: '{}';
    }
}

if (!function_exists('vms_ops_log_diagnostic_event')) {
    function vms_ops_log_diagnostic_event(string $event, array $context = array()): void
    {
    }
}

if (!function_exists('vms_ops_rest_ok')) {
    function vms_ops_rest_ok(array $data = array(), int $status = 200): WP_REST_Response
    {
        return new WP_REST_Response($data, $status);
    }
}

if (!function_exists('vms_ops_rest_error')) {
    function vms_ops_rest_error(string $code, string $message, int $status = 400): WP_Error
    {
        return new WP_Error($code, $message, array('status' => $status));
    }
}

if (!function_exists('vms_ops_rest_error_from_wp_error')) {
    function vms_ops_rest_error_from_wp_error(WP_Error $error)
    {
        return $error;
    }
}

if (!function_exists('vms_ops_rest_member_lookup_require_enabled')) {
    function vms_ops_rest_member_lookup_require_enabled()
    {
        return true;
    }
}

if (!function_exists('vms_ops_rest_resolve_venue_id')) {
    function vms_ops_rest_resolve_venue_id(WP_REST_Request $request, bool $required = true)
    {
        return 1153;
    }
}

if (!function_exists('vms_ops_rest_member_lookup_find_member')) {
    function vms_ops_rest_member_lookup_find_member(int $member_id, int $venue_id)
    {
        return array(
            'id' => $member_id,
            'first_name' => 'Testy',
            'last_name' => 'Member',
            'member_number' => 'M-501',
            'status' => 'active',
            'date_of_birth' => '1990-01-02',
        );
    }
}

if (!function_exists('vms_ops_pc_lookup_member_detail')) {
    function vms_ops_pc_lookup_member_detail(array $member, int $venue_id, array $settings = array()): array
    {
        return $GLOBALS['vms_ops_test_lookup_detail'];
    }
}

if (!function_exists('vms_ops_pc_lookup_member_full_name')) {
    function vms_ops_pc_lookup_member_full_name(array $member): string
    {
        return trim((string) ($member['first_name'] ?? '') . ' ' . (string) ($member['last_name'] ?? ''));
    }
}

if (!function_exists('vms_ops_now_mysql')) {
    function vms_ops_now_mysql(): string
    {
        return '2026-06-01 18:05:00';
    }
}

if (!function_exists('vms_ops_pc_scan_log_format_datetime')) {
    function vms_ops_pc_scan_log_format_datetime(string $value): string
    {
        return $value;
    }
}

if (!function_exists('vms_ops_pc_lookup_mark_last_lookup')) {
    function vms_ops_pc_lookup_mark_last_lookup(int $member_id)
    {
        $GLOBALS['vms_ops_test_last_lookup_marks'][] = $member_id;
        return true;
    }
}

if (!function_exists('vms_ops_pc_member_lookup_log')) {
    function vms_ops_pc_member_lookup_log(int $venue_id, int $member_id, string $action, array $details = array())
    {
        $GLOBALS['vms_ops_test_lookup_logs'][] = array(
            'venue_id' => $venue_id,
            'member_id' => $member_id,
            'action' => $action,
            'details' => $details,
        );
        return true;
    }
}

if (!function_exists('vms_ops_pc_record_visit')) {
    function vms_ops_pc_record_visit(int $member_id, int $venue_id, string $source = 'id_scan', string $notes = '')
    {
        $GLOBALS['vms_ops_test_visit_calls'][] = array(
            'member_id' => $member_id,
            'venue_id' => $venue_id,
            'source' => $source,
            'notes' => $notes,
        );

        if ($GLOBALS['vms_ops_test_visit_mode'] === 'duplicate') {
            return array(
                'duplicate' => 1,
                'visit_id' => 901,
                'visit_date' => '2026-06-01',
                'checked_in_at' => '2026-06-01 17:59:00',
            );
        }

        return array(
            'duplicate' => 0,
            'visit_id' => 900,
            'visit_date' => '2026-06-01',
            'checked_in_at' => '2026-06-01 18:05:00',
        );
    }
}

if (!function_exists('vms_ops_pc_normalize_dob')) {
    function vms_ops_pc_normalize_dob(string $value): string
    {
        $raw = trim($value);
        if ($raw === '') {
            return '';
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw) === 1) {
            return $raw;
        }

        if (preg_match('/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/', $raw, $matches) === 1) {
            return sprintf('%04d-%02d-%02d', (int) $matches[3], (int) $matches[1], (int) $matches[2]);
        }

        $digits = preg_replace('/\D+/', '', $raw);
        if (is_string($digits) && strlen($digits) === 8) {
            return sprintf('%04d-%02d-%02d', (int) substr($digits, 4, 4), (int) substr($digits, 0, 2), (int) substr($digits, 2, 2));
        }

        return '';
    }
}

if (!function_exists('vms_ops_pc_lookup_compare_dob_input')) {
    function vms_ops_pc_lookup_compare_dob_input(string $member_dob, string $input): bool
    {
        return vms_ops_pc_normalize_dob($member_dob) === vms_ops_pc_normalize_dob($input);
    }
}

require_once dirname(__DIR__, 2) . '/includes/capabilities.php';
require_once dirname(__DIR__, 2) . '/includes/rest/routes.php';

function test_fail(string $message): void
{
    fwrite(STDERR, $message . PHP_EOL);
    exit(1);
}

function assert_true(bool $condition, string $label): void
{
    if (!$condition) {
        test_fail($label);
    }
}

function assert_same($expected, $actual, string $label): void
{
    if ($expected !== $actual) {
        test_fail($label . ' expected [' . var_export($expected, true) . '] but got [' . var_export($actual, true) . ']');
    }
}

function assert_wp_error($value, string $code, int $status, string $label): void
{
    assert_true($value instanceof WP_Error, $label . ' should return WP_Error');
    assert_same($code, $value->get_error_code(), $label . ' error code');
    assert_same($status, (int) ($value->get_error_data()['status'] ?? 0), $label . ' status');
}

function reset_lookup_test_state(): void
{
    $GLOBALS['vms_ops_test_visit_mode'] = 'served';
    $GLOBALS['vms_ops_test_visit_calls'] = array();
    $GLOBALS['vms_ops_test_lookup_logs'] = array();
    $GLOBALS['vms_ops_test_last_lookup_marks'] = array();
    $GLOBALS['vms_ops_test_lookup_detail'] = array(
        'status' => 'active',
        'requires_confidence' => 1,
        'requires_dob_entry' => 1,
        'photo_match_available' => 0,
        'age_verified_at' => '2026-05-31 21:00:00',
        'blocking_reason' => '',
    );
}

function run_lookup_decision(array $params)
{
    $request = new WP_REST_Request('/vms-ops/v1/member-lookup/501/decision', array_merge(array(
        'id' => 501,
        'decision' => 'serve',
        'search_term' => 'Testy Member',
        'dob_input' => '01021990',
        'confidence_ack' => 1,
        'reason_code' => '',
        'device_id' => 'scanner-ipad-1',
        'console_type' => 'ops',
        'event_id' => 44,
    ), $params));

    return vms_ops_rest_member_lookup_decision($request);
}

reset_lookup_test_state();
$served = run_lookup_decision(array());
assert_true($served instanceof WP_REST_Response, 'served response type');
assert_same(200, $served->status, 'served response status');
assert_same('served', $served->data['status'] ?? '', 'served response body status');
assert_same('Served via Verified Lookup', $served->data['message'] ?? '', 'served message');
assert_same('verified_lookup', $served->data['reason_code'] ?? '', 'served reason code');
assert_same(1, count($GLOBALS['vms_ops_test_visit_calls']), 'served visit call count');
assert_same('verified_lookup', $GLOBALS['vms_ops_test_visit_calls'][0]['source'] ?? '', 'served visit source');
assert_same('served_via_verified_lookup', $GLOBALS['vms_ops_test_lookup_logs'][0]['action'] ?? '', 'served audit action');
assert_same(77, $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['operator_user_id'] ?? 0, 'served audit operator');
assert_same('verified_lookup', $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['method'] ?? '', 'served audit method');
assert_same(1, $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['dob_confirmed'] ?? 0, 'served audit dob confirmed');
assert_same(1, $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['confidence_ack'] ?? 0, 'served audit confidence');
assert_same('ops', $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['console_type'] ?? '', 'served audit console type');
assert_same('scanner-ipad-1', $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['device_id'] ?? '', 'served audit device id');
assert_same(44, $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['event_id'] ?? 0, 'served audit event id');

reset_lookup_test_state();
$GLOBALS['vms_ops_test_lookup_detail'] = array(
    'status' => 'active',
    'requires_confidence' => 0,
    'requires_dob_entry' => 0,
    'photo_match_available' => 1,
    'age_verified_at' => '2026-05-31 21:00:00',
    'blocking_reason' => '',
);
$photoMatchServed = run_lookup_decision(array(
    'dob_input' => '',
    'confidence_ack' => 0,
    'photo_match_confirmed' => 1,
));
assert_true($photoMatchServed instanceof WP_REST_Response, 'photo match response type');
assert_same('served', $photoMatchServed->data['status'] ?? '', 'photo match status');
assert_same('verified_lookup_photo_match', $photoMatchServed->data['reason_code'] ?? '', 'photo match reason code');
assert_same('lookup_photo_match', $GLOBALS['vms_ops_test_visit_calls'][0]['source'] ?? '', 'photo match visit source');
assert_same('served_via_verified_lookup', $GLOBALS['vms_ops_test_lookup_logs'][0]['action'] ?? '', 'photo match audit action');
assert_same('verified_lookup_photo_match', $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['source'] ?? '', 'photo match audit source');
assert_same('lookup_photo_match', $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['visit_source'] ?? '', 'photo match audit visit source');
assert_same(0, $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['dob_required'] ?? 1, 'photo match audit dob required');
assert_same(0, $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['dob_input_present'] ?? 1, 'photo match audit dob input present');
assert_same('profile_photo_match', $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['dob_bypass_reason'] ?? '', 'photo match audit bypass reason');
assert_same(1, $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['photo_match_confirmed'] ?? 0, 'photo match audit confirmation');
assert_same('2026-05-31 21:00:00', $GLOBALS['vms_ops_test_lookup_logs'][0]['details']['age_verified_at'] ?? '', 'photo match audit age verification');

reset_lookup_test_state();
$GLOBALS['vms_ops_test_visit_mode'] = 'duplicate';
$duplicateResponse = run_lookup_decision(array());
assert_true($duplicateResponse instanceof WP_REST_Response, 'duplicate response type');
assert_same('duplicate', $duplicateResponse->data['status'] ?? '', 'duplicate status');
assert_same('already_served_today', $duplicateResponse->data['reason_code'] ?? '', 'duplicate reason code');
assert_same('verified_lookup_duplicate', $GLOBALS['vms_ops_test_lookup_logs'][0]['action'] ?? '', 'duplicate audit action');

reset_lookup_test_state();
$dobMismatch = run_lookup_decision(array(
    'dob_input' => '01031990',
));
assert_true($dobMismatch instanceof WP_REST_Response, 'dob mismatch response type');
assert_same('blocked', $dobMismatch->data['status'] ?? '', 'dob mismatch status');
assert_same('dob_mismatch', $dobMismatch->data['reason_code'] ?? '', 'dob mismatch reason code');
assert_same(0, count($GLOBALS['vms_ops_test_visit_calls']), 'dob mismatch should not log visit');
assert_same('dob_failed', $GLOBALS['vms_ops_test_lookup_logs'][0]['action'] ?? '', 'dob mismatch audit action');

reset_lookup_test_state();
$missingDob = run_lookup_decision(array(
    'dob_input' => '0102',
));
assert_wp_error($missingDob, 'lookup_dob_required', 400, 'incomplete dob is rejected');
assert_same(0, count($GLOBALS['vms_ops_test_visit_calls']), 'incomplete dob should not log visit');

reset_lookup_test_state();
$missingConfidence = run_lookup_decision(array(
    'confidence_ack' => 0,
));
assert_wp_error($missingConfidence, 'lookup_confidence_required', 400, 'confidence is required');
assert_same(0, count($GLOBALS['vms_ops_test_visit_calls']), 'missing confidence should not log visit');

reset_lookup_test_state();
$GLOBALS['vms_ops_test_lookup_detail'] = array(
    'status' => 'active',
    'requires_confidence' => 0,
    'requires_dob_entry' => 0,
    'photo_match_available' => 1,
    'age_verified_at' => '2026-05-31 21:00:00',
    'blocking_reason' => '',
);
$missingPhotoMatch = run_lookup_decision(array(
    'dob_input' => '',
    'confidence_ack' => 0,
    'photo_match_confirmed' => 0,
));
assert_wp_error($missingPhotoMatch, 'lookup_photo_match_required', 400, 'photo match confirmation is required when dob is omitted');
assert_same(0, count($GLOBALS['vms_ops_test_visit_calls']), 'missing photo match should not log visit');

reset_lookup_test_state();
$checkId = run_lookup_decision(array(
    'decision' => 'check_id_now',
    'dob_input' => '',
    'confidence_ack' => 0,
    'reason_code' => 'staff_selected_id_check',
));
assert_true($checkId instanceof WP_REST_Response, 'check id response type');
assert_same('redirected', $checkId->data['status'] ?? '', 'check id status');
assert_same('id_console', $checkId->data['next_action'] ?? '', 'check id next action');
assert_same('staff_selected_id_check', $checkId->data['reason_code'] ?? '', 'check id reason code');
assert_same(0, count($GLOBALS['vms_ops_test_visit_calls']), 'check id should not log visit');
assert_same('redirected_to_id_check', $GLOBALS['vms_ops_test_lookup_logs'][0]['action'] ?? '', 'check id audit action');

fwrite(STDOUT, "member lookup decision tests: PASS" . PHP_EOL);
