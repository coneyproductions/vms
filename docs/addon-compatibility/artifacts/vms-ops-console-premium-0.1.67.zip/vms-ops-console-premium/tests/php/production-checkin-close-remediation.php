<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    $candidates = array();
    $scan = __DIR__;
    for ($i = 0; $i < 8; $i++) {
        $candidates[] = $scan . '/wp-load.php';
        $scan = dirname($scan);
    }

    foreach ($candidates as $candidate) {
        if (is_string($candidate) && $candidate !== '' && file_exists($candidate)) {
            require_once $candidate;
            break;
        }
    }
}

if (!defined('ABSPATH')) {
    fwrite(STDERR, "Unable to locate wp-load.php\n");
    exit(1);
}

if (!function_exists('wp_timezone')) {
    function wp_timezone(): DateTimeZone
    {
        return new DateTimeZone('UTC');
    }
}

function remediation_maybe_require_plugin(string $relative_path): void
{
    $relative_path = trim($relative_path);
    if ($relative_path === '') {
        return;
    }

    $candidates = array();
    if (defined('WP_PLUGIN_DIR')) {
        $candidates[] = rtrim((string) WP_PLUGIN_DIR, '/\\') . '/' . ltrim($relative_path, '/\\');
    }

    $candidates[] = dirname(__DIR__, 3) . '/' . ltrim($relative_path, '/\\');

    foreach ($candidates as $candidate) {
        if (is_string($candidate) && $candidate !== '' && file_exists($candidate)) {
            require_once $candidate;
            return;
        }
    }
}

function remediation_ensure_runtime(): void
{
    if (!function_exists('vms_event_plan_checkin_close_meta_key')) {
        remediation_maybe_require_plugin('vms/vendor-management-system.php');
    }

    if (!function_exists('vms_ops_ticket_prepare_event')) {
        remediation_maybe_require_plugin('vms-ops-console-premium/vms-ops-console-premium.php');
    }
}

remediation_ensure_runtime();

function remediation_fail(string $message, int $code = 1): void
{
    fwrite(STDERR, $message . PHP_EOL);
    exit($code);
}

function remediation_parse_datetime(string $value): ?DateTimeImmutable
{
    $value = trim($value);
    if ($value === '') {
        return null;
    }

    try {
        return new DateTimeImmutable($value, wp_timezone());
    } catch (Exception $exception) {
        return null;
    }
}

function remediation_plan_schedule(int $post_id): array
{
    $start = remediation_parse_datetime((string) get_post_meta($post_id, '_vms_event_plan_start_datetime', true));
    $end = remediation_parse_datetime((string) get_post_meta($post_id, '_vms_event_plan_end_datetime', true));

    if (!($start instanceof DateTimeImmutable)) {
        $event_date = trim((string) get_post_meta($post_id, '_vms_event_date', true));
        $start_time = trim((string) get_post_meta($post_id, '_vms_start_time', true));
        if ($event_date !== '' && $start_time !== '') {
            if (preg_match('/^\d{2}:\d{2}$/', $start_time)) {
                $start_time .= ':00';
            }
            $start = remediation_parse_datetime($event_date . ' ' . $start_time);
        }
    }

    if (!($end instanceof DateTimeImmutable)) {
        $event_date = trim((string) get_post_meta($post_id, '_vms_event_date', true));
        $end_time = trim((string) get_post_meta($post_id, '_vms_end_time', true));
        if ($event_date !== '' && $end_time !== '') {
            if (preg_match('/^\d{2}:\d{2}$/', $end_time)) {
                $end_time .= ':00';
            }
            $end = remediation_parse_datetime($event_date . ' ' . $end_time);
            if ($start instanceof DateTimeImmutable && $end instanceof DateTimeImmutable && $end <= $start) {
                $end = $end->add(new DateInterval('P1D'));
            }
        }
    }

    return array(
        'showtime' => $start,
        'end_at' => $end,
    );
}

function remediation_tribe_schedule(int $post_id): array
{
    return array(
        'showtime' => remediation_parse_datetime((string) get_post_meta($post_id, '_EventStartDate', true)),
        'end_at' => remediation_parse_datetime((string) get_post_meta($post_id, '_EventEndDate', true)),
    );
}

function remediation_resolve_schedule(int $post_id, string $post_type): array
{
    return $post_type === 'vms_event_plan'
        ? remediation_plan_schedule($post_id)
        : remediation_tribe_schedule($post_id);
}

function remediation_expected_close(DateTimeImmutable $end_at): DateTimeImmutable
{
    $hours = 4;
    if (function_exists('vms_ops_ticket_post_show_scan_buffer_hours')) {
        $hours = max(0, min(12, (int) vms_ops_ticket_post_show_scan_buffer_hours()));
    } elseif (function_exists('get_option')) {
        $settings = get_option('vms_ops_settings', array());
        if (is_array($settings) && isset($settings['post_show_scan_buffer_hours'])) {
            $hours = max(0, min(12, (int) $settings['post_show_scan_buffer_hours']));
        }
    }

    if ($hours <= 0) {
        return $end_at;
    }

    return $end_at->add(new DateInterval('PT' . $hours . 'H'));
}

function remediation_meta_key_for_post_type(string $post_type): string
{
    if ($post_type === 'vms_event_plan' && function_exists('vms_event_plan_checkin_close_meta_key')) {
        return vms_event_plan_checkin_close_meta_key();
    }

    return '_checkin_close_at';
}

function remediation_pairing(int $post_id, string $post_type): array
{
    if ($post_type === 'vms_event_plan') {
        return array(
            'paired_tribe_event_id' => (int) get_post_meta($post_id, '_vms_tec_event_id', true),
            'paired_event_plan_id' => 0,
        );
    }

    $plan_id = function_exists('vms_get_event_plan_for_tec_event') ? (int) vms_get_event_plan_for_tec_event($post_id) : 0;
    return array(
        'paired_tribe_event_id' => 0,
        'paired_event_plan_id' => $plan_id,
    );
}

function remediation_row(array $record): array
{
    $post_id = (int) $record['id'];
    $expected_type = (string) $record['post_type'];
    $post = get_post($post_id);
    $actual_type = $post instanceof WP_Post ? (string) $post->post_type : '';
    $meta_key = remediation_meta_key_for_post_type($expected_type);
    $current_checkin_close = trim((string) get_post_meta($post_id, $meta_key, true));
    $schedule = remediation_resolve_schedule($post_id, $expected_type);
    $showtime = $schedule['showtime'] ?? null;
    $end_at = $schedule['end_at'] ?? null;

    $event_end_source = 'missing_end';
    $proposed = '';
    if ($showtime instanceof DateTimeImmutable && $end_at instanceof DateTimeImmutable && $end_at > $showtime) {
        $event_end_source = 'raw_end';
        $proposed = remediation_expected_close($end_at)->format('Y-m-d H:i:s');
    } elseif ($showtime instanceof DateTimeImmutable && $end_at instanceof DateTimeImmutable && $end_at <= $showtime) {
        $event_end_source = 'end_lte_showtime';
    }

    $pairing = remediation_pairing($post_id, $expected_type);
    $resolved_close = '';
    if (function_exists('vms_ops_ticket_prepare_event') && $post instanceof WP_Post) {
        $prepared = vms_ops_ticket_prepare_event($post);
        $resolved_close = trim((string) ($prepared['checkin_close_at'] ?? ''));
    }

    $reason = array('audited_missing_checkin_close_at');
    if ($current_checkin_close !== '') {
        $reason[] = 'already_populated';
    }
    if (!($end_at instanceof DateTimeImmutable)) {
        $reason[] = 'end_missing';
    } elseif (!($showtime instanceof DateTimeImmutable) || $end_at <= $showtime) {
        $reason[] = 'end_lte_showtime';
    }
    if ($proposed !== '' && $proposed !== (string) $record['audited_derived_close']) {
        $reason[] = 'proposed_close_mismatch';
    }
    if ($actual_type !== '' && $actual_type !== $expected_type) {
        $reason[] = 'post_type_mismatch';
    }

    return array_merge(
        $record,
        array(
            'current_post_type' => $actual_type,
            'current_title' => $post instanceof WP_Post ? (string) $post->post_title : '',
            'current_showtime' => $showtime instanceof DateTimeImmutable ? $showtime->format('Y-m-d H:i:s') : '',
            'current_end_at' => $end_at instanceof DateTimeImmutable ? $end_at->format('Y-m-d H:i:s') : '',
            'current_checkin_close_at' => $current_checkin_close,
            'proposed_checkin_close_at' => $proposed,
            'event_end_source' => $event_end_source,
            'resolved_checkin_close_at' => $resolved_close,
            'reason' => array_values($reason),
            'can_update' => $current_checkin_close === ''
                && $actual_type === $expected_type
                && $proposed !== ''
                && $proposed === (string) $record['audited_derived_close'],
        ),
        $pairing
    );
}

function remediation_targeted_audit(array $rows): array
{
    $missing = 0;
    $end_lte_showtime = 0;
    $fallback = 0;
    $resolved_matches = 0;
    $resolved_total = 0;

    foreach ($rows as $row) {
        if ((string) ($row['current_checkin_close_at'] ?? '') === '') {
            $missing++;
        }
        if ((string) ($row['event_end_source'] ?? '') === 'end_lte_showtime') {
            $end_lte_showtime++;
        }
        if ((string) ($row['event_end_source'] ?? '') !== 'raw_end') {
            $fallback++;
        }
        if ((string) ($row['resolved_checkin_close_at'] ?? '') !== '') {
            $resolved_total++;
            if ((string) ($row['resolved_checkin_close_at'] ?? '') === (string) ($row['audited_derived_close'] ?? '')) {
                $resolved_matches++;
            }
        }
    }

    return array(
        'missing_checkin_close_at' => $missing,
        'end_at_lte_showtime' => $end_lte_showtime,
        'fallback_derived_close_time' => $fallback,
        'resolved_close_matches_audited' => $resolved_matches,
        'resolved_close_rows' => $resolved_total,
    );
}

$mode = 'dry-run';
foreach ($argv as $arg) {
    if ($arg === '--execute') {
        $mode = 'execute';
    }
}

$site_url = function_exists('get_option') ? trim((string) get_option('siteurl')) : '';
if ($site_url !== 'https://serenaderange.com') {
    remediation_fail('Refusing to run outside https://serenaderange.com. Detected siteurl: ' . $site_url);
}

$records = array(
    array('id' => 5511, 'post_type' => 'vms_event_plan', 'title' => 'Jason Aldean tribute - My Kinda Party', 'audited_showtime' => '2026-06-06 19:00:00', 'audited_end_at' => '2026-06-06 21:00:00', 'audited_derived_close' => '2026-06-07 01:00:00', 'paired_record_id' => 5567),
    array('id' => 5567, 'post_type' => 'tribe_events', 'title' => 'Jason Aldean tribute - My Kinda Party', 'audited_showtime' => '2026-06-06 19:00:00', 'audited_end_at' => '2026-06-06 21:00:00', 'audited_derived_close' => '2026-06-07 01:00:00', 'paired_record_id' => 5511),
    array('id' => 2526, 'post_type' => 'vms_event_plan', 'title' => 'Lee Mathis & The Brutally Handsome', 'audited_showtime' => '2026-06-12 19:00:00', 'audited_end_at' => '2026-06-12 21:00:00', 'audited_derived_close' => '2026-06-13 01:00:00', 'paired_record_id' => 3923),
    array('id' => 3923, 'post_type' => 'tribe_events', 'title' => 'Lee Mathis & The Brutally Handsome', 'audited_showtime' => '2026-06-12 19:00:00', 'audited_end_at' => '2026-06-12 21:00:00', 'audited_derived_close' => '2026-06-13 01:00:00', 'paired_record_id' => 2526),
    array('id' => 2528, 'post_type' => 'vms_event_plan', 'title' => 'Double Vision HTX', 'audited_showtime' => '2026-06-13 19:00:00', 'audited_end_at' => '2026-06-13 21:00:00', 'audited_derived_close' => '2026-06-14 01:00:00', 'paired_record_id' => 3979),
    array('id' => 3979, 'post_type' => 'tribe_events', 'title' => 'Double Vision HTX', 'audited_showtime' => '2026-06-13 19:00:00', 'audited_end_at' => '2026-06-13 21:00:00', 'audited_derived_close' => '2026-06-14 01:00:00', 'paired_record_id' => 2528),
    array('id' => 2530, 'post_type' => 'vms_event_plan', 'title' => 'Women of Country Music', 'audited_showtime' => '2026-06-19 19:00:00', 'audited_end_at' => '2026-06-19 21:00:00', 'audited_derived_close' => '2026-06-20 01:00:00', 'paired_record_id' => 5382),
    array('id' => 5382, 'post_type' => 'tribe_events', 'title' => 'Women of Country Music', 'audited_showtime' => '2026-06-19 19:00:00', 'audited_end_at' => '2026-06-19 21:00:00', 'audited_derived_close' => '2026-06-20 01:00:00', 'paired_record_id' => 2530),
    array('id' => 4396, 'post_type' => 'vms_event_plan', 'title' => 'Piano Man – The Billy Joel Experience', 'audited_showtime' => '2026-06-20 19:00:00', 'audited_end_at' => '2026-06-20 21:00:00', 'audited_derived_close' => '2026-06-21 01:00:00', 'paired_record_id' => 4397),
    array('id' => 4397, 'post_type' => 'tribe_events', 'title' => 'Piano Man – The Billy Joel Experience', 'audited_showtime' => '2026-06-20 19:00:00', 'audited_end_at' => '2026-06-20 21:00:00', 'audited_derived_close' => '2026-06-21 01:00:00', 'paired_record_id' => 4396),
    array('id' => 2532, 'post_type' => 'vms_event_plan', 'title' => 'Kenny Chesney tribute: Barefoot Nation', 'audited_showtime' => '2026-06-26 19:00:00', 'audited_end_at' => '2026-06-26 21:00:00', 'audited_derived_close' => '2026-06-27 01:00:00', 'paired_record_id' => 5748),
    array('id' => 5748, 'post_type' => 'tribe_events', 'title' => 'Kenny Chesney tribute: Barefoot Nation', 'audited_showtime' => '2026-06-26 19:00:00', 'audited_end_at' => '2026-06-26 21:00:00', 'audited_derived_close' => '2026-06-27 01:00:00', 'paired_record_id' => 2532),
    array('id' => 5568, 'post_type' => 'vms_event_plan', 'title' => 'Taylor Swift tribute - Reputation', 'audited_showtime' => '2026-09-12 19:00:00', 'audited_end_at' => '2026-09-12 21:00:00', 'audited_derived_close' => '2026-09-13 01:00:00', 'paired_record_id' => 5569),
    array('id' => 5569, 'post_type' => 'tribe_events', 'title' => 'Taylor Swift tribute - Reputation', 'audited_showtime' => '2026-09-12 19:00:00', 'audited_end_at' => '2026-09-12 21:00:00', 'audited_derived_close' => '2026-09-13 01:00:00', 'paired_record_id' => 5568),
    array('id' => 2537, 'post_type' => 'vms_event_plan', 'title' => 'Super Trouper', 'audited_showtime' => '2026-10-03 19:00:00', 'audited_end_at' => '2026-10-03 21:00:00', 'audited_derived_close' => '2026-10-04 01:00:00', 'paired_record_id' => 4783),
    array('id' => 4783, 'post_type' => 'tribe_events', 'title' => 'Super Trouper', 'audited_showtime' => '2026-10-03 19:00:00', 'audited_end_at' => '2026-10-03 21:00:00', 'audited_derived_close' => '2026-10-04 01:00:00', 'paired_record_id' => 2537),
);

$preflight = array_map('remediation_row', $records);
$updates = array();

if ($mode === 'execute') {
    foreach ($preflight as $row) {
        if (empty($row['can_update'])) {
            continue;
        }

        $post_id = (int) $row['id'];
        $meta_key = remediation_meta_key_for_post_type((string) $row['post_type']);
        $proposed = (string) $row['proposed_checkin_close_at'];
        update_post_meta($post_id, $meta_key, $proposed);
        $updates[] = array(
            'id' => $post_id,
            'post_type' => (string) $row['post_type'],
            'updated_checkin_close_at' => $proposed,
        );
    }
}

$postflight = array_map('remediation_row', $records);

echo wp_json_encode(
    array(
        'site_url' => $site_url,
        'mode' => $mode,
        'preflight' => array(
            'exact_ids' => array_values(array_map(static function (array $record): int {
                return (int) $record['id'];
            }, $records)),
            'rows' => $preflight,
            'targeted_audit' => remediation_targeted_audit($preflight),
        ),
        'execution' => array(
            'updated_rows' => $updates,
            'updated_count' => count($updates),
        ),
        'postflight' => array(
            'rows' => $postflight,
            'targeted_audit' => remediation_targeted_audit($postflight),
        ),
    ),
    JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
) . PHP_EOL;
