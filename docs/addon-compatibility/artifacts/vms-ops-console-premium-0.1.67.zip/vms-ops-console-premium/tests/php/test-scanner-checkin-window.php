<?php

declare(strict_types=1);

define('ABSPATH', __DIR__);

if (!class_exists('WP_Error')) {
    class WP_Error
    {
        private string $code;
        private string $message;
        private array $data;

        public function __construct(string $code = '', string $message = '', $data = array())
        {
            $this->code = $code;
            $this->message = $message;
            $this->data = is_array($data) ? $data : array();
        }

        public function get_error_code(): string
        {
            return $this->code;
        }

        public function get_error_message(): string
        {
            return $this->message;
        }

        public function get_error_data(): array
        {
            return $this->data;
        }
    }
}

$GLOBALS['vms_ops_test_now'] = '2026-05-31 19:00:00';

if (!function_exists('apply_filters')) {
    function apply_filters(string $hook, $value, ...$args)
    {
        return $value;
    }
}

if (!function_exists('sanitize_text_field')) {
    function sanitize_text_field(string $value): string
    {
        return trim($value);
    }
}

if (!function_exists('sanitize_key')) {
    function sanitize_key(string $value): string
    {
        return strtolower(preg_replace('/[^a-z0-9_\-]/', '', $value));
    }
}

if (!function_exists('__')) {
    function __(string $value, string $domain = ''): string
    {
        return $value;
    }
}

if (!function_exists('get_current_user_id')) {
    function get_current_user_id(): int
    {
        return 42;
    }
}

if (!function_exists('get_user_meta')) {
    function get_user_meta(int $user_id, string $key, bool $single = false)
    {
        return 0;
    }
}

if (!function_exists('wp_json_encode')) {
    function wp_json_encode($value)
    {
        return json_encode($value);
    }
}

if (!function_exists('wp_parse_url')) {
    function wp_parse_url(string $url)
    {
        return parse_url($url);
    }
}

if (!function_exists('wp_timezone')) {
    function wp_timezone(): DateTimeZone
    {
        return new DateTimeZone('America/Chicago');
    }
}

if (!function_exists('vms_ops_parse_wp_datetime')) {
    function vms_ops_parse_wp_datetime(string $value): ?DateTimeImmutable
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $normalized = preg_replace('/\s+/', ' ', str_replace('T', ' ', $value));
        if (is_string($normalized)) {
            $value = trim($normalized);
        }

        try {
            return new DateTimeImmutable($value, wp_timezone());
        } catch (Exception $exception) {
            return null;
        }
    }
}

if (!function_exists('vms_ops_now_datetime')) {
    function vms_ops_now_datetime(): DateTimeImmutable
    {
        return vms_ops_parse_wp_datetime((string) $GLOBALS['vms_ops_test_now']);
    }
}

if (!function_exists('vms_ops_now_mysql')) {
    function vms_ops_now_mysql(): string
    {
        return vms_ops_now_datetime()->format('Y-m-d H:i:s');
    }
}

if (!function_exists('vms_ops_ticket_checkin_open_datetime')) {
    function vms_ops_ticket_checkin_open_datetime(DateTimeImmutable $start): DateTimeImmutable
    {
        return $start->sub(new DateInterval('PT60M'));
    }
}

if (!function_exists('vms_ops_ticket_post_show_scan_buffer_hours')) {
    function vms_ops_ticket_post_show_scan_buffer_hours(): int
    {
        return 0;
    }
}

if (!function_exists('vms_ops_ticket_apply_post_show_buffer')) {
    function vms_ops_ticket_apply_post_show_buffer(DateTimeImmutable $datetime): DateTimeImmutable
    {
        return $datetime->add(new DateInterval('PT' . vms_ops_ticket_post_show_scan_buffer_hours() . 'H'));
    }
}

if (!function_exists('vms_ops_ticket_apply_reopen_past_window')) {
    function vms_ops_ticket_apply_reopen_past_window(DateTimeImmutable $datetime): ?DateTimeImmutable
    {
        return null;
    }
}

if (!function_exists('vms_ops_ticket_format_console_datetime_label')) {
    function vms_ops_ticket_format_console_datetime_label(DateTimeInterface $datetime): string
    {
        return $datetime->format('Y-m-d H:i:s');
    }
}

require_once dirname(__DIR__, 2) . '/includes/ticket-console/eligibility.php';
require_once dirname(__DIR__, 2) . '/includes/ticket-console/checkin.php';

function test_fail(string $message): void
{
    fwrite(STDERR, $message . PHP_EOL);
    exit(1);
}

function assert_true(bool $condition, string $label): void
{
    if (!$condition) {
        test_fail($label);
    }
}

function assert_same($expected, $actual, string $label): void
{
    if ($expected !== $actual) {
        test_fail($label . ' expected [' . var_export($expected, true) . '] but got [' . var_export($actual, true) . ']');
    }
}

function assert_window_allows(string $now, array $event, string $label): void
{
    $GLOBALS['vms_ops_test_now'] = $now;
    $result = vms_ops_ticket_checkin_assert_window($event, 1207);
    assert_true($result === true, $label . ' should allow check-in');
}

function assert_window_blocks(string $now, array $event, string $expectedCode, string $label): void
{
    $GLOBALS['vms_ops_test_now'] = $now;
    $result = vms_ops_ticket_checkin_assert_window($event, 1207);
    assert_true($result instanceof WP_Error, $label . ' should return WP_Error');
    assert_same($expectedCode, $result->get_error_code(), $label . ' error code');
}

$collapsedEndEvent = array(
    'start_at' => '2026-05-31 20:00:00',
    'end_at' => '2026-05-31 20:00:00',
    'scan_state' => 'upcoming',
);

assert_window_allows('2026-05-31 19:59:59', $collapsedEndEvent, 'T-1s with collapsed end');

$collapsedEndEvent['scan_state'] = 'live';
assert_window_allows('2026-05-31 20:00:00', $collapsedEndEvent, 'T exact with collapsed end');

$collapsedEndEvent['scan_state'] = 'started';
assert_window_allows('2026-05-31 20:00:01', $collapsedEndEvent, 'T+1s with collapsed end');

$collapsedEndEvent['scan_state'] = 'in_progress';
assert_window_allows('2026-05-31 20:15:00', $collapsedEndEvent, 'T+15m with collapsed end');
assert_window_allows('2026-05-31 21:00:00', $collapsedEndEvent, 'T+60m with collapsed end');
assert_window_allows('2026-05-31 22:00:00', $collapsedEndEvent, 'check-in close boundary with collapsed end');
assert_window_blocks('2026-05-31 22:00:01', $collapsedEndEvent, 'checkin_closed', 'after derived check-in close with collapsed end');

$explicitCloseEvent = array(
    'start_at' => '2026-05-31 20:00:00',
    'end_at' => '2026-05-31 20:00:00',
    'checkin_close_at' => '2026-05-31 22:00:00',
    'scan_state' => 'live',
);

assert_window_allows('2026-05-31 20:00:00', $explicitCloseEvent, 'explicit close keeps scanner open at showtime');
assert_window_allows('2026-05-31 21:00:00', $explicitCloseEvent, 'explicit close keeps scanner open after showtime');
assert_window_blocks('2026-05-31 22:00:01', $explicitCloseEvent, 'checkin_closed', 'explicit close blocks after close');

fwrite(STDOUT, "scanner check-in window regression tests: PASS" . PHP_EOL);
