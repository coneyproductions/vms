<?php

declare(strict_types=1);

define('ABSPATH', __DIR__);

if (!function_exists('__')) {
    function __(string $value, string $domain = ''): string
    {
        return $value;
    }
}

if (!function_exists('sanitize_key')) {
    function sanitize_key(string $value): string
    {
        return strtolower((string) preg_replace('/[^a-z0-9_\-]/', '', $value));
    }
}

if (!function_exists('add_filter')) {
    function add_filter(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('add_action')) {
    function add_action(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('vms_ops_get_settings')) {
    function vms_ops_get_settings(): array
    {
        return array(
            'member_lookup_allow_profile_photo' => 1,
            'member_lookup_dob_policy' => 'no_photo',
            'member_lookup_require_confidence' => 1,
            'member_lookup_require_photo_recheck' => 0,
            'member_lookup_dob_display' => 'full',
            'member_lookup_freshness_days' => 365,
        );
    }
}

if (!function_exists('vms_ops_pc_member_effective_status')) {
    function vms_ops_pc_member_effective_status(array $member): string
    {
        return (string) ($member['status'] ?? 'active');
    }
}

if (!function_exists('vms_ops_pc_lookup_member_age_years')) {
    function vms_ops_pc_lookup_member_age_years(array $member): ?int
    {
        return isset($member['age_years']) ? (int) $member['age_years'] : null;
    }
}

if (!function_exists('vms_ops_pc_lookup_verification_stale')) {
    function vms_ops_pc_lookup_verification_stale(array $member, ?array $settings = null): bool
    {
        return !empty($member['verification_stale']);
    }
}

if (!function_exists('vms_ops_pc_lookup_member_photo_url')) {
    function vms_ops_pc_lookup_member_photo_url(array $member, ?array $settings = null): string
    {
        return !empty($member['photo_url']) ? (string) $member['photo_url'] : '';
    }
}

if (!function_exists('vms_ops_pc_lookup_member_full_name')) {
    function vms_ops_pc_lookup_member_full_name(array $member): string
    {
        return trim((string) ($member['first_name'] ?? '') . ' ' . (string) ($member['last_name'] ?? ''));
    }
}

if (!function_exists('vms_ops_pc_lookup_format_dob_display')) {
    function vms_ops_pc_lookup_format_dob_display(string $value, bool $mask = false): string
    {
        return $value;
    }
}

if (!function_exists('vms_ops_pc_lookup_member_initials')) {
    function vms_ops_pc_lookup_member_initials(array $member): string
    {
        return 'TM';
    }
}

require_once dirname(__DIR__, 2) . '/includes/private-club/member-lookup.php';

function test_fail(string $message): void
{
    fwrite(STDERR, $message . PHP_EOL);
    exit(1);
}

function assert_same($expected, $actual, string $label): void
{
    if ($expected !== $actual) {
        test_fail($label . ' expected [' . var_export($expected, true) . '] but got [' . var_export($actual, true) . ']');
    }
}

$baseMember = array(
    'first_name' => 'Testy',
    'last_name' => 'Member',
    'member_number' => 'M-501',
    'status' => 'active',
    'date_of_birth' => '1990-01-02',
    'age_years' => 36,
    'age_verified' => 1,
    'age_verified_at' => '2026-05-31 21:00:00',
    'last_lookup_at' => '2026-06-01 19:00:00',
    'last_visit_on' => '2026-06-01',
);

$photoMember = $baseMember;
$photoMember['photo_url'] = 'https://example.com/photo.jpg';
$photoCard = vms_ops_pc_lookup_member_card($photoMember, 1153);
assert_same('lookup_ok', $photoCard['lookup_status_key'] ?? '', 'photo member status key');
assert_same('Lookup OK', $photoCard['lookup_label'] ?? '', 'photo member label');
assert_same('ok', $photoCard['lookup_level'] ?? '', 'photo member level');
assert_same(1, $photoCard['photo_match_available'] ?? 0, 'photo member photo match');
assert_same(0, $photoCard['requires_dob_entry'] ?? 1, 'photo member dob requirement');
assert_same(0, $photoCard['requires_confidence'] ?? 1, 'photo member confidence requirement');

$dobMember = $baseMember;
$dobCard = vms_ops_pc_lookup_member_card($dobMember, 1153);
assert_same('dob_confirm', $dobCard['lookup_status_key'] ?? '', 'no-photo member status key');
assert_same('DOB Confirm', $dobCard['lookup_label'] ?? '', 'no-photo member label');
assert_same('caution', $dobCard['lookup_level'] ?? '', 'no-photo member level');
assert_same(0, $dobCard['photo_match_available'] ?? 1, 'no-photo member photo match');
assert_same(1, $dobCard['requires_dob_entry'] ?? 0, 'no-photo member dob requirement');
assert_same(1, $dobCard['requires_confidence'] ?? 0, 'no-photo member confidence requirement');

$duplicateMember = $photoMember;
$duplicateCard = vms_ops_pc_lookup_member_card($duplicateMember, 1153, null, 2);
assert_same('needs_caution', $duplicateCard['lookup_status_key'] ?? '', 'duplicate member status key');
assert_same('Needs Caution', $duplicateCard['lookup_label'] ?? '', 'duplicate member label');
assert_same('caution', $duplicateCard['lookup_level'] ?? '', 'duplicate member level');

$blockedMember = $baseMember;
$blockedMember['verification_stale'] = 1;
$blockedCard = vms_ops_pc_lookup_member_card($blockedMember, 1153);
assert_same('id_required', $blockedCard['lookup_status_key'] ?? '', 'blocked member status key');
assert_same('ID Required', $blockedCard['lookup_label'] ?? '', 'blocked member label');
assert_same('danger', $blockedCard['lookup_level'] ?? '', 'blocked member level');
assert_same(0, $blockedCard['allow_lookup'] ?? 1, 'blocked member allow lookup');

fwrite(STDOUT, "member lookup status tests: PASS\n");
