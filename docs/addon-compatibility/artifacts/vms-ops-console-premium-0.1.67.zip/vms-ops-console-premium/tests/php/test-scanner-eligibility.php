<?php

declare(strict_types=1);

define('ABSPATH', __DIR__);

if (!function_exists('apply_filters')) {
    function apply_filters(string $hook, $value)
    {
        return $value;
    }
}

if (!function_exists('wp_timezone')) {
    function wp_timezone(): DateTimeZone
    {
        return new DateTimeZone('America/Chicago');
    }
}

if (!function_exists('vms_ops_parse_wp_datetime')) {
    function vms_ops_parse_wp_datetime(string $value): ?DateTimeImmutable
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $normalized = preg_replace('/\s+/', ' ', str_replace('T', ' ', $value));
        if (is_string($normalized)) {
            $value = trim($normalized);
        }

        try {
            return new DateTimeImmutable($value, wp_timezone());
        } catch (Exception $exception) {
            return null;
        }
    }
}

require_once dirname(__DIR__, 2) . '/includes/ticket-console/eligibility.php';

function test_fail(string $message): void
{
    fwrite(STDERR, $message . PHP_EOL);
    exit(1);
}

function assert_same($expected, $actual, string $label): void
{
    if ($expected !== $actual) {
        test_fail($label . ' expected [' . var_export($expected, true) . '] but got [' . var_export($actual, true) . ']');
    }
}

function assert_true(bool $condition, string $label): void
{
    if (!$condition) {
        test_fail($label);
    }
}

function eligibility_case(array $overrides): array
{
    $base = array(
        'start_at' => '2026-05-31 20:00:00',
        'checkin_open_at' => '2026-05-31 19:00:00',
        'checkin_close_at' => '2026-05-31 22:00:00',
        'event_status' => 'upcoming',
        'operator_authorized' => true,
        'scanner_session_revoked' => false,
    );

    return vms_ops_ticket_get_scanner_eligibility(array_merge($base, $overrides));
}

$showtime = vms_ops_ticket_parse_datetime_like('2026-05-31 20:00:00');
$collapsed_end = vms_ops_ticket_parse_datetime_like('2026-05-31 20:00:00');
$resolved_end = vms_ops_ticket_resolve_operational_event_end($showtime, $collapsed_end, null);

assert_same('fallback_duration', $resolved_end['source'], 'collapsed showtime end uses fallback duration source');
assert_same('2026-05-31 22:00:00', $resolved_end['datetime'] instanceof DateTimeImmutable ? $resolved_end['datetime']->format('Y-m-d H:i:s') : '', 'collapsed showtime end resolves to +2h');

$matrix = array(
    'before_checkin_opens' => array(
        'input' => array('now' => '2026-05-31 18:30:00', 'event_status' => 'upcoming'),
        'allowed' => false,
        'reason' => 'CHECK_IN_NOT_OPEN_YET',
    ),
    'checkin_opens' => array(
        'input' => array('now' => '2026-05-31 19:00:00', 'event_status' => 'upcoming'),
        'allowed' => true,
        'reason' => 'ALLOWED',
    ),
    'before_showtime' => array(
        'input' => array('now' => '2026-05-31 19:45:00', 'event_status' => 'upcoming'),
        'allowed' => true,
        'reason' => 'ALLOWED',
    ),
    'one_second_before_showtime' => array(
        'input' => array('now' => '2026-05-31 19:59:59', 'event_status' => 'upcoming'),
        'allowed' => true,
        'reason' => 'ALLOWED',
    ),
    'exact_showtime_live' => array(
        'input' => array('now' => '2026-05-31 20:00:00', 'event_status' => 'live'),
        'allowed' => true,
        'reason' => 'ALLOWED',
    ),
    'one_second_after_showtime_started' => array(
        'input' => array('now' => '2026-05-31 20:00:01', 'event_status' => 'started'),
        'allowed' => true,
        'reason' => 'ALLOWED',
    ),
    'after_showtime_in_progress' => array(
        'input' => array('now' => '2026-05-31 20:15:00', 'event_status' => 'in_progress'),
        'allowed' => true,
        'reason' => 'ALLOWED',
    ),
    'later_during_event' => array(
        'input' => array('now' => '2026-05-31 21:00:00', 'event_status' => 'live'),
        'allowed' => true,
        'reason' => 'ALLOWED',
    ),
    'at_checkin_close' => array(
        'input' => array('now' => '2026-05-31 22:00:00', 'event_status' => 'live'),
        'allowed' => true,
        'reason' => 'ALLOWED',
    ),
    'after_checkin_close' => array(
        'input' => array('now' => '2026-05-31 22:00:01', 'event_status' => 'closed'),
        'allowed' => false,
        'reason' => 'CHECK_IN_CLOSED',
    ),
    'cancelled_event' => array(
        'input' => array('now' => '2026-05-31 20:15:00', 'event_status' => 'cancelled', 'event_cancelled' => true),
        'allowed' => false,
        'reason' => 'EVENT_CANCELLED',
    ),
    'deleted_event' => array(
        'input' => array('now' => '2026-05-31 20:15:00', 'event_status' => 'archived', 'event_archived' => true),
        'allowed' => false,
        'reason' => 'EVENT_DELETED',
    ),
    'unauthorized_operator' => array(
        'input' => array('now' => '2026-05-31 20:15:00', 'event_status' => 'live', 'operator_authorized' => false),
        'allowed' => false,
        'reason' => 'UNAUTHORIZED',
    ),
    'expired_scanner_session' => array(
        'input' => array(
            'now' => '2026-05-31 20:15:00',
            'event_status' => 'live',
            'scanner_session_expires_at' => '2026-05-31 20:00:00',
        ),
        'allowed' => false,
        'reason' => 'SCANNER_SESSION_EXPIRED',
    ),
    'revoked_scanner_session' => array(
        'input' => array('now' => '2026-05-31 20:15:00', 'event_status' => 'live', 'scanner_session_revoked' => true),
        'allowed' => false,
        'reason' => 'SCANNER_SESSION_REVOKED',
    ),
    'showtime_fallback_end_keeps_scanner_open' => array(
        'input' => array(
            'now' => '2026-05-31 21:00:00',
            'event_status' => 'live',
            'checkin_close_at' => $resolved_end['datetime'] instanceof DateTimeImmutable ? $resolved_end['datetime']->format('Y-m-d H:i:s') : '',
        ),
        'allowed' => true,
        'reason' => 'ALLOWED',
    ),
);

foreach ($matrix as $name => $case) {
    $result = eligibility_case($case['input']);
    assert_same($case['allowed'], $result['allowed'], $name . ' allowed');
    assert_same($case['reason'], $result['reason'], $name . ' reason');
}

$session_created_at_open = eligibility_case(array(
    'now' => '2026-05-31 21:00:00',
    'event_status' => 'live',
    'scanner_session_expires_at' => '2026-05-31 22:00:00',
));
assert_true($session_created_at_open['allowed'] === true, 'scanner session created at T-60 remains valid at T+60 while check-in is open');

fwrite(STDOUT, "scanner eligibility regression tests: PASS" . PHP_EOL);
