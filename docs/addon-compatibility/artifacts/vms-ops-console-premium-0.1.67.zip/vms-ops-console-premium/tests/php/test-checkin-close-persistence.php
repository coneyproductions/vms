<?php

declare(strict_types=1);

define('ABSPATH', __DIR__);

if (!class_exists('WP_Post')) {
    class WP_Post
    {
        public int $ID;
        public string $post_type;
        public string $post_status;
        public string $post_title;
        public string $post_date;

        public function __construct(array $data = array())
        {
            $this->ID = (int) ($data['ID'] ?? 0);
            $this->post_type = (string) ($data['post_type'] ?? 'post');
            $this->post_status = (string) ($data['post_status'] ?? 'publish');
            $this->post_title = (string) ($data['post_title'] ?? '');
            $this->post_date = (string) ($data['post_date'] ?? '2026-01-01 00:00:00');
        }
    }
}

if (!class_exists('WP_Error')) {
    class WP_Error
    {
        private string $code;
        private string $message;
        private array $data;

        public function __construct(string $code = '', string $message = '', $data = array())
        {
            $this->code = $code;
            $this->message = $message;
            $this->data = is_array($data) ? $data : array();
        }

        public function get_error_code(): string
        {
            return $this->code;
        }

        public function get_error_message(): string
        {
            return $this->message;
        }

        public function get_error_data(): array
        {
            return $this->data;
        }
    }
}

$GLOBALS['vms_ops_test_now'] = '2026-06-10 18:30:00';
$GLOBALS['vms_test_meta'] = array();
$GLOBALS['vms_test_posts'] = array();

if (!function_exists('absint')) {
    function absint($value): int
    {
        return abs((int) $value);
    }
}

if (!function_exists('apply_filters')) {
    function apply_filters(string $hook, $value, ...$args)
    {
        return $value;
    }
}

if (!function_exists('sanitize_key')) {
    function sanitize_key(string $value): string
    {
        return strtolower((string) preg_replace('/[^a-z0-9_\-]/', '', $value));
    }
}

if (!function_exists('sanitize_text_field')) {
    function sanitize_text_field(string $value): string
    {
        return trim($value);
    }
}

if (!function_exists('__')) {
    function __(string $value, string $domain = ''): string
    {
        return $value;
    }
}

if (!function_exists('wp_timezone')) {
    function wp_timezone(): DateTimeZone
    {
        return new DateTimeZone('America/Chicago');
    }
}

if (!function_exists('wp_date')) {
    function wp_date(string $format, int $timestamp, ?DateTimeZone $timezone = null): string
    {
        $timezone = $timezone ?: wp_timezone();
        $date = new DateTimeImmutable('@' . $timestamp);
        return $date->setTimezone($timezone)->format($format);
    }
}

if (!function_exists('get_option')) {
    function get_option(string $key, $default = false)
    {
        if ($key === 'vms_ops_settings') {
            return array('post_show_scan_buffer_hours' => 4);
        }
        if ($key === 'date_format') {
            return 'M j, Y';
        }
        if ($key === 'time_format') {
            return 'g:i A';
        }

        return $default;
    }
}

if (!function_exists('get_post_meta')) {
    function get_post_meta(int $post_id, string $key, bool $single = false)
    {
        $value = $GLOBALS['vms_test_meta'][$post_id][$key] ?? ($single ? '' : array());
        if ($single) {
            return is_array($value) ? ($value[0] ?? '') : $value;
        }

        return is_array($value) ? $value : array($value);
    }
}

if (!function_exists('update_post_meta')) {
    function update_post_meta(int $post_id, string $key, $value): bool
    {
        $GLOBALS['vms_test_meta'][$post_id][$key] = $value;
        return true;
    }
}

if (!function_exists('delete_post_meta')) {
    function delete_post_meta(int $post_id, string $key): bool
    {
        unset($GLOBALS['vms_test_meta'][$post_id][$key]);
        return true;
    }
}

if (!function_exists('get_post')) {
    function get_post(int $post_id): ?WP_Post
    {
        return $GLOBALS['vms_test_posts'][$post_id] ?? null;
    }
}

if (!function_exists('get_post_type')) {
    function get_post_type(int $post_id): string
    {
        $post = get_post($post_id);
        return $post instanceof WP_Post ? $post->post_type : '';
    }
}

if (!function_exists('wp_strip_all_tags')) {
    function wp_strip_all_tags(string $value): string
    {
        return strip_tags($value);
    }
}

if (!function_exists('get_bloginfo')) {
    function get_bloginfo(string $key): string
    {
        return $key === 'charset' ? 'UTF-8' : '';
    }
}

if (!function_exists('wp_json_encode')) {
    function wp_json_encode($value)
    {
        return json_encode($value);
    }
}

if (!function_exists('wp_parse_url')) {
    function wp_parse_url(string $url)
    {
        return parse_url($url);
    }
}

if (!function_exists('get_current_user_id')) {
    function get_current_user_id(): int
    {
        return 42;
    }
}

if (!function_exists('get_user_meta')) {
    function get_user_meta(int $user_id, string $key, bool $single = false)
    {
        return 0;
    }
}

if (!function_exists('vms_meta_key')) {
    function vms_meta_key(string $group, string $key): string
    {
        if ($group === 'event_plan' && $key === 'checkin_close_at') {
            return '_checkin_close_at';
        }
        if ($group === 'event_plan' && $key === 'tec_event_id') {
            return '_vms_tec_event_id';
        }

        return '';
    }
}

if (!function_exists('vms_get_event_plan_for_tec_event')) {
    function vms_get_event_plan_for_tec_event($tec_event_id)
    {
        foreach ($GLOBALS['vms_test_meta'] as $plan_id => $meta) {
            if ((int) ($meta['_vms_tec_event_id'] ?? 0) === (int) $tec_event_id) {
                return (int) $plan_id;
            }
        }

        return null;
    }
}

if (!function_exists('vms_ops_parse_wp_datetime')) {
    function vms_ops_parse_wp_datetime(string $value): ?DateTimeImmutable
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        try {
            return new DateTimeImmutable($value, wp_timezone());
        } catch (Exception $exception) {
            return null;
        }
    }
}

if (!function_exists('vms_ops_now_datetime')) {
    function vms_ops_now_datetime(): DateTimeImmutable
    {
        $now = vms_ops_parse_wp_datetime((string) $GLOBALS['vms_ops_test_now']);
        return $now instanceof DateTimeImmutable ? $now : new DateTimeImmutable('now', wp_timezone());
    }
}

if (!function_exists('vms_ops_now_mysql')) {
    function vms_ops_now_mysql(): string
    {
        return vms_ops_now_datetime()->format('Y-m-d H:i:s');
    }
}

require_once dirname(__DIR__, 3) . '/vms/includes/helpers/checkin-close.php';
require_once dirname(__DIR__, 2) . '/includes/ticket-console/eligibility.php';
require_once dirname(__DIR__, 2) . '/includes/ticket-console/events.php';
require_once dirname(__DIR__, 2) . '/includes/ticket-console/checkin.php';

function test_fail(string $message): void
{
    fwrite(STDERR, $message . PHP_EOL);
    exit(1);
}

function assert_same($expected, $actual, string $label): void
{
    if ($expected !== $actual) {
        test_fail($label . ' expected [' . var_export($expected, true) . '] but got [' . var_export($actual, true) . ']');
    }
}

function assert_true(bool $condition, string $label): void
{
    if (!$condition) {
        test_fail($label);
    }
}

function seed_post(int $post_id, string $post_type, string $title, string $post_date = '2026-06-10 19:00:00'): void
{
    $GLOBALS['vms_test_posts'][$post_id] = new WP_Post(array(
        'ID' => $post_id,
        'post_type' => $post_type,
        'post_status' => 'publish',
        'post_title' => $title,
        'post_date' => $post_date,
    ));
}

$plan_id = 7001;
$tec_id = 7002;

seed_post($plan_id, 'vms_event_plan', 'Persistence Fixture Plan');
seed_post($tec_id, 'tribe_events', 'Persistence Fixture TEC');

update_post_meta($plan_id, '_vms_event_date', '2026-06-10');
update_post_meta($plan_id, '_vms_start_time', '19:00');
update_post_meta($plan_id, '_vms_end_time', '21:00');
update_post_meta($plan_id, '_vms_tec_event_id', $tec_id);

update_post_meta($tec_id, '_EventStartDate', '2026-06-10 19:00:00');
update_post_meta($tec_id, '_EventEndDate', '2026-06-10 21:00:00');

$stored = vms_event_plan_store_checkin_close_meta($plan_id);
assert_same('stored', $stored['reason'], 'valid plan schedule stores explicit checkin close');
assert_same('2026-06-11 01:00:00', $stored['checkin_close_at'], 'plan explicit checkin close value');
assert_same('2026-06-11 01:00:00', (string) get_post_meta($plan_id, '_checkin_close_at', true), 'plan meta persisted');

$synced = vms_event_plan_sync_checkin_close_meta_to_tec($plan_id, $tec_id);
assert_same($tec_id, $synced['linked_tec_event_id'], 'tec sync tracks linked event id');
assert_same('2026-06-11 01:00:00', (string) get_post_meta($tec_id, '_checkin_close_at', true), 'tec meta persisted');

update_post_meta($tec_id, '_checkin_close_at', '2026-06-11 03:00:00');
$prepared = vms_ops_ticket_prepare_event(get_post($tec_id));
assert_same('2026-06-11 03:00:00', $prepared['checkin_close_at'], 'scanner payload prefers explicit checkin close');
assert_same('explicit_meta', $prepared['checkin_close_source'], 'scanner payload marks explicit checkin close source');

$GLOBALS['vms_ops_test_now'] = '2026-06-11 01:30:00';
$allowedWithExplicit = vms_ops_ticket_checkin_assert_window($prepared, $tec_id);
assert_true($allowedWithExplicit === true, 'check-in API gate honors explicit checkin close after derived window');

delete_post_meta($tec_id, '_checkin_close_at');
delete_post_meta($plan_id, '_checkin_close_at');
$preparedDerived = vms_ops_ticket_prepare_event(get_post($tec_id));
assert_same('2026-06-11 01:00:00', $preparedDerived['checkin_close_at'], 'scanner payload falls back to derived close when explicit meta missing');
assert_same('derived_event_end', $preparedDerived['checkin_close_source'], 'scanner payload marks derived close source');

$blockedWithoutExplicit = vms_ops_ticket_checkin_assert_window($preparedDerived, $tec_id);
assert_true($blockedWithoutExplicit instanceof WP_Error, 'derived close blocks once explicit meta is removed');
assert_same('checkin_closed', $blockedWithoutExplicit->get_error_code(), 'derived close failure reason');

fwrite(STDOUT, "checkin close persistence regression tests: PASS" . PHP_EOL);
