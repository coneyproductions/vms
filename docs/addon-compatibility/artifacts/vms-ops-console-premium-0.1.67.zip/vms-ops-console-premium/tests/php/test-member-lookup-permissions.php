<?php

declare(strict_types=1);

define('ABSPATH', __DIR__);

if (!class_exists('WP_User')) {
    class WP_User
    {
        public int $ID;
        public array $caps;

        public function __construct(int $id = 0, array $caps = array())
        {
            $this->ID = $id;
            $this->caps = $caps;
        }
    }
}

if (!class_exists('WP_Error')) {
    class WP_Error
    {
        private string $code;
        private string $message;
        private array $data;

        public function __construct(string $code = '', string $message = '', $data = array())
        {
            $this->code = $code;
            $this->message = $message;
            $this->data = is_array($data) ? $data : array();
        }

        public function get_error_code(): string
        {
            return $this->code;
        }

        public function get_error_message(): string
        {
            return $this->message;
        }

        public function get_error_data(): array
        {
            return $this->data;
        }
    }
}

if (!class_exists('WP_REST_Request')) {
    class WP_REST_Request
    {
        private string $route;
        private array $params;
        private array $headers;

        public function __construct(string $route = '', array $params = array(), array $headers = array())
        {
            $this->route = $route;
            $this->params = $params;
            $this->headers = array_change_key_case($headers, CASE_LOWER);
        }

        public function get_route(): string
        {
            return $this->route;
        }

        public function get_param(string $key)
        {
            return $this->params[$key] ?? null;
        }

        public function get_header(string $key): string
        {
            $normalized = strtolower(str_replace('_', '-', $key));
            return isset($this->headers[$normalized]) ? (string) $this->headers[$normalized] : '';
        }
    }
}

if (!class_exists('WP_REST_Response')) {
    class WP_REST_Response
    {
        public array $data;
        public int $status;

        public function __construct($data = array(), int $status = 200)
        {
            $this->data = is_array($data) ? $data : array();
            $this->status = $status;
        }
    }
}

if (!class_exists('WP_REST_Server')) {
    class WP_REST_Server
    {
        public const READABLE = 'GET';
        public const CREATABLE = 'POST';
        public const EDITABLE = 'POST';
        public const DELETABLE = 'DELETE';
    }
}

$GLOBALS['vms_ops_test_user'] = new WP_User(77, array());

if (!function_exists('sanitize_text_field')) {
    function sanitize_text_field(string $value): string
    {
        return trim($value);
    }
}

if (!function_exists('sanitize_key')) {
    function sanitize_key(string $value): string
    {
        return strtolower((string) preg_replace('/[^a-z0-9_\-]/', '', $value));
    }
}

if (!function_exists('absint')) {
    function absint($value): int
    {
        return abs((int) $value);
    }
}

if (!function_exists('__')) {
    function __(string $value, string $domain = ''): string
    {
        return $value;
    }
}

if (!function_exists('add_filter')) {
    function add_filter(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('add_action')) {
    function add_action(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('register_rest_route')) {
    function register_rest_route(string $namespace, string $route, array $args = array()): bool
    {
        return true;
    }
}

if (!function_exists('get_current_user_id')) {
    function get_current_user_id(): int
    {
        return $GLOBALS['vms_ops_test_user'] instanceof WP_User ? $GLOBALS['vms_ops_test_user']->ID : 0;
    }
}

if (!function_exists('wp_get_current_user')) {
    function wp_get_current_user()
    {
        return $GLOBALS['vms_ops_test_user'];
    }
}

if (!function_exists('get_user_by')) {
    function get_user_by(string $field, $value)
    {
        if ($field === 'id' && $GLOBALS['vms_ops_test_user'] instanceof WP_User && $GLOBALS['vms_ops_test_user']->ID === (int) $value) {
            return $GLOBALS['vms_ops_test_user'];
        }

        return null;
    }
}

if (!function_exists('user_can')) {
    function user_can($user, string $cap): bool
    {
        return $user instanceof WP_User && !empty($user->caps[$cap]);
    }
}

if (!function_exists('current_user_can')) {
    function current_user_can(string $cap): bool
    {
        return user_can(wp_get_current_user(), $cap);
    }
}

if (!function_exists('is_user_logged_in')) {
    function is_user_logged_in(): bool
    {
        return get_current_user_id() > 0;
    }
}

if (!function_exists('wp_verify_nonce')) {
    function wp_verify_nonce(string $nonce, string $action): int
    {
        return $nonce === 'valid' && $action === 'wp_rest' ? 1 : 0;
    }
}

if (!function_exists('get_user_meta')) {
    function get_user_meta(int $user_id, string $key, bool $single = false)
    {
        return array();
    }
}

if (!function_exists('update_user_meta')) {
    function update_user_meta(int $user_id, string $key, $value): bool
    {
        return true;
    }
}

if (!function_exists('delete_user_meta')) {
    function delete_user_meta(int $user_id, string $key): bool
    {
        return true;
    }
}

if (!function_exists('vms_ops_log_diagnostic_event')) {
    function vms_ops_log_diagnostic_event(string $event, array $context = array()): void
    {
    }
}

require_once dirname(__DIR__, 2) . '/includes/capabilities.php';
require_once dirname(__DIR__, 2) . '/includes/rest/routes.php';

function test_fail(string $message): void
{
    fwrite(STDERR, $message . PHP_EOL);
    exit(1);
}

function assert_true(bool $condition, string $label): void
{
    if (!$condition) {
        test_fail($label);
    }
}

function assert_same($expected, $actual, string $label): void
{
    if ($expected !== $actual) {
        test_fail($label . ' expected [' . var_export($expected, true) . '] but got [' . var_export($actual, true) . ']');
    }
}

function assert_wp_error($value, string $code, int $status, string $label): void
{
    assert_true($value instanceof WP_Error, $label . ' should return WP_Error');
    assert_same($code, $value->get_error_code(), $label . ' error code');
    $data = $value->get_error_data();
    assert_same($status, (int) ($data['status'] ?? 0), $label . ' status');
}

function run_permission_check(array $caps): mixed
{
    $GLOBALS['vms_ops_test_user'] = new WP_User(77, $caps);
    $callback = vms_ops_rest_permission_callback(array(vms_ops_capability_member_lookup()), array(
        'action' => 'member_lookup_search',
        'reason' => 'missing_member_lookup',
        'code' => 'missing_member_lookup_permission',
        'message' => 'Lookup not allowed.',
    ));

    return $callback(new WP_REST_Request('/vms-ops/v1/member-lookup/search', array(), array(
        'X-WP-Nonce' => 'valid',
    )));
}

function run_photo_permission_check(array $caps): mixed
{
    $GLOBALS['vms_ops_test_user'] = new WP_User(77, $caps);
    $callback = vms_ops_rest_permission_callback(array(vms_ops_capability_manage_members_lite(), vms_ops_capability_manage_members_admin()));

    return $callback(new WP_REST_Request('/vms-ops/v1/members/501/photo', array(), array(
        'X-WP-Nonce' => 'valid',
    )));
}

$adminAllowed = run_permission_check(array(
    'manage_options' => true,
));
if ($adminAllowed !== true) {
    test_fail('manage_options admin override allows member lookup route but got [' . (is_object($adminAllowed) ? get_class($adminAllowed) . ':' . ($adminAllowed instanceof WP_Error ? $adminAllowed->get_error_code() : 'object') : var_export($adminAllowed, true)) . ']');
}

$memberLookupAllowed = run_permission_check(array(
    vms_ops_capability_member_lookup() => true,
));
if ($memberLookupAllowed !== true) {
    test_fail('member lookup capability allows member lookup route but got [' . (is_object($memberLookupAllowed) ? get_class($memberLookupAllowed) . ':' . ($memberLookupAllowed instanceof WP_Error ? $memberLookupAllowed->get_error_code() : 'object') : var_export($memberLookupAllowed, true)) . ']');
}

$denied = run_permission_check(array(
    vms_ops_capability_use_pwa() => true,
));
assert_wp_error($denied, 'missing_member_lookup_permission', 403, 'ops user without member lookup capability is rejected');

$photoAdminAllowed = run_photo_permission_check(array(
    'manage_options' => true,
));
if ($photoAdminAllowed !== true) {
    test_fail('manage_options admin override allows member photo route but got [' . (is_object($photoAdminAllowed) ? get_class($photoAdminAllowed) . ':' . ($photoAdminAllowed instanceof WP_Error ? $photoAdminAllowed->get_error_code() : 'object') : var_export($photoAdminAllowed, true)) . ']');
}

$photoLiteAllowed = run_photo_permission_check(array(
    vms_ops_capability_manage_members_lite() => true,
));
if ($photoLiteAllowed !== true) {
    test_fail('manage lite capability allows member photo route but got [' . (is_object($photoLiteAllowed) ? get_class($photoLiteAllowed) . ':' . ($photoLiteAllowed instanceof WP_Error ? $photoLiteAllowed->get_error_code() : 'object') : var_export($photoLiteAllowed, true)) . ']');
}

$photoDenied = run_photo_permission_check(array(
    vms_ops_capability_member_lookup() => true,
));
assert_wp_error($photoDenied, 'forbidden', 403, 'lookup-only user is rejected from member photo route');

fwrite(STDOUT, "member lookup permission tests: PASS" . PHP_EOL);
