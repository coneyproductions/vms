<?php

declare(strict_types=1);

define('ABSPATH', __DIR__);

if (!class_exists('WP_User')) {
    class WP_User
    {
        public array $caps;

        public function __construct(array $caps = array())
        {
            $this->caps = $caps;
        }
    }
}

if (!function_exists('__')) {
    function __(string $value, string $domain = ''): string
    {
        return $value;
    }
}

if (!function_exists('add_filter')) {
    function add_filter(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('add_action')) {
    function add_action(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('sanitize_key')) {
    function sanitize_key(string $value): string
    {
        return strtolower((string) preg_replace('/[^a-z0-9_\-]/', '', $value));
    }
}

if (!function_exists('wp_get_current_user')) {
    function wp_get_current_user()
    {
        return $GLOBALS['vms_ops_test_user'] ?? new WP_User();
    }
}

if (!function_exists('user_can')) {
    function user_can($user, string $cap): bool
    {
        return $user instanceof WP_User && !empty($user->caps[$cap]);
    }
}

if (!function_exists('current_user_can')) {
    function current_user_can(string $cap): bool
    {
        return user_can(wp_get_current_user(), $cap);
    }
}

if (!function_exists('vms_ops_capability_manage_members_lite')) {
    function vms_ops_capability_manage_members_lite(): string
    {
        return 'vms_ops_manage_members_lite';
    }
}

if (!function_exists('vms_ops_capability_manage_members_admin')) {
    function vms_ops_capability_manage_members_admin(): string
    {
        return 'vms_ops_manage_members_admin';
    }
}

require_once dirname(__DIR__, 2) . '/includes/private-club/member-lookup.php';

function fail(string $message): void
{
    fwrite(STDERR, $message . PHP_EOL);
    exit(1);
}

function assert_same($expected, $actual, string $label): void
{
    if ($expected !== $actual) {
        fail($label . ' expected [' . var_export($expected, true) . '] but got [' . var_export($actual, true) . ']');
    }
}

$lookup_staff = new WP_User(array(
    'vms_ops_manage_members_lite' => true,
));
$manager_staff = new WP_User(array(
    'vms_ops_manage_members_admin' => true,
));
$site_admin = new WP_User(array(
    'manage_options' => true,
));

assert_same('enabled', vms_ops_member_lookup_profile_photo_upload_mode(array()), 'default upload mode');
assert_same('enabled', vms_ops_member_lookup_profile_photo_upload_mode(array(
    'member_lookup_profile_photo_upload_mode' => 'invalid-value',
)), 'invalid upload mode fallback');

assert_same(true, vms_ops_member_lookup_profile_photo_upload_allowed_for_user(array(
    'member_lookup_allow_profile_photo' => 1,
    'member_lookup_profile_photo_upload_mode' => 'enabled',
), $lookup_staff), 'lite member staff can upload when enabled');

assert_same(false, vms_ops_member_lookup_profile_photo_upload_allowed_for_user(array(
    'member_lookup_allow_profile_photo' => 1,
    'member_lookup_profile_photo_upload_mode' => 'managers_only',
), $lookup_staff), 'lite member staff blocked in managers only mode');

assert_same(true, vms_ops_member_lookup_profile_photo_upload_allowed_for_user(array(
    'member_lookup_allow_profile_photo' => 1,
    'member_lookup_profile_photo_upload_mode' => 'managers_only',
), $manager_staff), 'member admin can upload in managers only mode');

assert_same(true, vms_ops_member_lookup_profile_photo_upload_allowed_for_user(array(
    'member_lookup_allow_profile_photo' => 1,
    'member_lookup_profile_photo_upload_mode' => 'managers_only',
), $site_admin), 'site admin can upload in managers only mode');

assert_same(false, vms_ops_member_lookup_profile_photo_upload_allowed_for_user(array(
    'member_lookup_allow_profile_photo' => 1,
    'member_lookup_profile_photo_upload_mode' => 'disabled',
), $manager_staff), 'disabled mode blocks upload');

assert_same(false, vms_ops_member_lookup_profile_photo_upload_allowed_for_user(array(
    'member_lookup_allow_profile_photo' => 0,
    'member_lookup_profile_photo_upload_mode' => 'enabled',
), $manager_staff), 'global photo disable blocks upload');

assert_same('profile_photo_manager_only', vms_ops_member_lookup_profile_photo_upload_denied_code(array(
    'member_lookup_profile_photo_upload_mode' => 'managers_only',
)), 'manager only denied code');

assert_same('Only managers can upload profile photos right now.', vms_ops_member_lookup_profile_photo_upload_denied_message(array(
    'member_lookup_profile_photo_upload_mode' => 'managers_only',
)), 'manager only denied message');

fwrite(STDOUT, "member photo upload mode tests: PASS\n");
