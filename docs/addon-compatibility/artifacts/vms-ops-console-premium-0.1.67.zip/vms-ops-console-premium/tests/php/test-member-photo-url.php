<?php

declare(strict_types=1);

define('ABSPATH', __DIR__);

if (!function_exists('__')) {
    function __(string $value, string $domain = ''): string
    {
        return $value;
    }
}

if (!function_exists('add_filter')) {
    function add_filter(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('add_action')) {
    function add_action(string $hook, $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        return true;
    }
}

if (!function_exists('absint')) {
    function absint($value): int
    {
        return abs((int) $value);
    }
}

if (!function_exists('sanitize_key')) {
    function sanitize_key(string $value): string
    {
        return strtolower((string) preg_replace('/[^a-z0-9_\-]/', '', $value));
    }
}

if (!function_exists('home_url')) {
    function home_url(string $path = ''): string
    {
        $base = 'https://example.com';
        if ($path === '' || $path === '/') {
            return $base . '/';
        }

        return $base . '/' . ltrim($path, '/');
    }
}

if (!function_exists('add_query_arg')) {
    function add_query_arg(array $args, string $url): string
    {
        return rtrim($url, '?') . '?' . http_build_query($args, '', '&', PHP_QUERY_RFC3986);
    }
}

require_once dirname(__DIR__, 2) . '/includes/private-club/member-lookup.php';

function fail(string $message): void
{
    fwrite(STDERR, $message . PHP_EOL);
    exit(1);
}

function assert_same($expected, $actual, string $label): void
{
    if ($expected !== $actual) {
        fail($label . ' expected [' . var_export($expected, true) . '] but got [' . var_export($actual, true) . ']');
    }
}

$photo_url = vms_ops_pc_member_photo_stream_url(123, 'medium');
assert_same('https://example.com/?vms_ops_member_photo=123&size=medium', $photo_url, 'member photo url');
assert_same(false, strpos($photo_url, 'admin-post.php') !== false, 'member photo url should avoid admin-post');
assert_same('https://example.com/?vms_ops_member_photo=123&size=medium', vms_ops_pc_member_photo_stream_url(123, 'invalid-size'), 'invalid size fallback');
assert_same('', vms_ops_pc_member_photo_stream_url(0, 'medium'), 'missing attachment');

fwrite(STDOUT, "member photo url tests: PASS\n");
