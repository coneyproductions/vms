const path = require('path');

const access = require(path.resolve(__dirname, '../../pwa/assets/js/member-lookup-access.js'));

function fail(message) {
  process.stderr.write(`${message}\n`);
  process.exit(1);
}

function assertEqual(expected, actual, label) {
  if (expected !== actual) {
    fail(`${label} expected [${JSON.stringify(expected)}] but got [${JSON.stringify(actual)}]`);
  }
}

function assertState(input, expected, label) {
  const actual = access.getMemberLookupAccessState(input);
  Object.keys(expected).forEach((key) => {
    assertEqual(expected[key], actual[key], `${label} ${key}`);
  });
}

const base = {
  permissionPayloadVersion: 2,
  settings: {
    member_lookup_enabled: 1
  },
  requiresPresence: false,
  onDuty: false,
  hasActiveVenue: true
};

assertState({
  ...base,
  caps: {
    manageOptions: 1,
    usePwa: 1,
    memberLookup: 0
  }
}, {
  visible: true,
  allowed: true,
  reason: '',
  detail: ''
}, 'admin override');

assertState({
  ...base,
  caps: {
    manageOptions: 0,
    usePwa: 1,
    memberLookup: 1
  }
}, {
  visible: true,
  allowed: true,
  reason: '',
  detail: ''
}, 'manager with lookup cap');

assertState({
  ...base,
  caps: {
    manageOptions: 0,
    usePwa: 1,
    memberLookup: 1
  }
}, {
  visible: true,
  allowed: true,
  reason: '',
  detail: ''
}, 'bartender with lookup cap');

assertState({
  ...base,
  caps: {
    manageOptions: 0,
    usePwa: 1,
    memberLookup: 0
  }
}, {
  visible: true,
  allowed: false,
  reason: 'missing_member_lookup_cap',
  detail: 'member_lookup_required'
}, 'ops user without lookup cap');

assertState({
  ...base,
  caps: {
    manageOptions: 0,
    usePwa: 1,
    memberLookup: 1
  },
  requiresPresence: true,
  onDuty: false
}, {
  visible: true,
  allowed: false,
  reason: 'no_active_session',
  detail: 'presence_required'
}, 'presence login required');

assertState({
  ...base,
  caps: {
    manageOptions: 0,
    usePwa: 1,
    memberLookup: 1
  },
  hasActiveVenue: false
}, {
  visible: true,
  allowed: false,
  reason: 'unknown',
  detail: 'venue_required'
}, 'venue required');

assertState({
  ...base,
  permissionPayloadVersion: 1,
  caps: {
    manageOptions: 1,
    usePwa: 1,
    memberLookup: 0
  }
}, {
  visible: true,
  allowed: false,
  reason: 'stale_session_payload',
  detail: 'payload_version'
}, 'stale permission payload');

assertState({
  ...base,
  caps: {
    manageOptions: 0,
    usePwa: 0,
    memberLookup: 0
  }
}, {
  visible: false,
  allowed: false,
  reason: 'missing_ops_access',
  detail: 'base_access_required'
}, 'missing ops access');

process.stdout.write('member lookup access tests: PASS\n');
