const path = require('path');

const dob = require(path.resolve(__dirname, '../../pwa/assets/js/member-lookup-dob.js'));

function fail(message) {
  process.stderr.write(`${message}\n`);
  process.exit(1);
}

function assertEqual(expected, actual, label) {
  if (expected !== actual) {
    fail(`${label} expected [${JSON.stringify(expected)}] but got [${JSON.stringify(actual)}]`);
  }
}

function assertState(input, expected, label) {
  const actual = dob.getDobInputState(input);
  Object.keys(expected).forEach((key) => {
    assertEqual(expected[key], actual[key], `${label} ${key}`);
  });
}

function applyEditSequence(sequence, label) {
  return sequence.reduce((state, step, index) => {
    const result = dob.applyDobInputEdit(
      state.value,
      state.selectionStart,
      state.selectionEnd,
      step.inputType,
      step.data
    );

    if (!result) {
      fail(`${label} step ${index + 1} returned no edit result`);
    }

    return {
      value: result.formattedValue,
      selectionStart: result.selectionStart,
      selectionEnd: result.selectionEnd
    };
  }, {
    value: '',
    selectionStart: 0,
    selectionEnd: 0
  });
}

assertEqual('01/02/1990', dob.autoFormatDobInput('01021990'), 'digits autoformat');
assertEqual('01/02/1990', dob.autoFormatDobInput('01/02/1990'), 'slash autoformat');
assertEqual('01/02/1990', dob.autoFormatDobInput('010219909'), 'ninth digit ignored');
assertEqual('01/02/199', dob.autoFormatDobInput('01/02/199'), 'delete formatting');
assertEqual('1990-01-02', dob.normalizeDobInput('01021990'), 'digits normalize');
assertEqual('1990-01-02', dob.normalizeDobInput('01/02/1990'), 'slash normalize');
assertEqual('1990-01-02', dob.normalizeDobInput('1/2/1990'), 'single digit month/day normalize');
assertEqual('', dob.getDobFeedbackMessage(''), 'empty input keeps helper single-line');
assertEqual('', dob.getDobFeedbackMessage('0102'), 'partial digits keep helper single-line');
assertEqual('', dob.getDobFeedbackMessage('', { optionalInput: true }), 'optional empty input keeps helper single-line');
assertEqual('Enter a valid DOB: MMDDYYYY', dob.getDobFeedbackMessage('13321990'), 'invalid full dob feedback');

assertState('01021990', {
  formattedValue: '01/02/1990',
  normalizedValue: '1990-01-02',
  digitCount: 8,
  isComplete: true,
  needsMoreDigits: false
}, 'complete digits');

assertState('01/02/1990', {
  formattedValue: '01/02/1990',
  normalizedValue: '1990-01-02',
  hasDelimiters: true,
  isComplete: true
}, 'slash input');

assertState('010219909', {
  formattedValue: '01/02/1990',
  normalizedValue: '1990-01-02',
  digitCount: 8,
  isComplete: true
}, 'ninth digit rejected');

assertState('0102', {
  formattedValue: '01/02',
  normalizedValue: '',
  digitCount: 4,
  isComplete: false,
  needsMoreDigits: true
}, 'partial digits');

assertState('13321990', {
  formattedValue: '13/32/1990',
  normalizedValue: '',
  digitCount: 8,
  isComplete: false,
  needsMoreDigits: false
}, 'invalid date');

assertState('01/02/199', {
  formattedValue: '01/02/199',
  normalizedValue: '',
  digitCount: 7,
  hasDelimiters: true,
  isComplete: false
}, 'delete works naturally');

const quickDobEntry = applyEditSequence([
  { inputType: 'insertText', data: '1' },
  { inputType: 'insertText', data: '1' },
  { inputType: 'insertText', data: '2' },
  { inputType: 'insertText', data: '2' },
  { inputType: 'insertText', data: '1' },
  { inputType: 'insertText', data: '9' },
  { inputType: 'insertText', data: '7' },
  { inputType: 'insertText', data: '6' }
], 'sequential quick entry');
assertEqual('11/22/1976', quickDobEntry.value, 'sequential digits stay stable');

const secondSample = applyEditSequence([
  { inputType: 'insertText', data: '0' },
  { inputType: 'insertText', data: '9' },
  { inputType: 'insertText', data: '1' },
  { inputType: 'insertText', data: '6' },
  { inputType: 'insertText', data: '1' },
  { inputType: 'insertText', data: '9' },
  { inputType: 'insertText', data: '6' },
  { inputType: 'insertText', data: '5' }
], 'second sequential entry');
assertEqual('09/16/1965', secondSample.value, 'second sequential entry stays stable');

const cappedDigits = applyEditSequence([
  { inputType: 'insertText', data: '0' },
  { inputType: 'insertText', data: '1' },
  { inputType: 'insertText', data: '0' },
  { inputType: 'insertText', data: '2' },
  { inputType: 'insertText', data: '1' },
  { inputType: 'insertText', data: '9' },
  { inputType: 'insertText', data: '9' },
  { inputType: 'insertText', data: '0' },
  { inputType: 'insertText', data: '9' }
], 'ninth digit cap');
assertEqual('01/02/1990', cappedDigits.value, 'ninth digit is ignored during sequential input');

const deleteSequence = applyEditSequence([
  { inputType: 'insertText', data: '0' },
  { inputType: 'insertText', data: '1' },
  { inputType: 'insertText', data: '0' },
  { inputType: 'insertText', data: '2' },
  { inputType: 'insertText', data: '1' },
  { inputType: 'insertText', data: '9' },
  { inputType: 'insertText', data: '9' },
  { inputType: 'insertText', data: '0' },
  { inputType: 'deleteContentBackward' }
], 'delete sequence');
assertEqual('01/02/199', deleteSequence.value, 'backspace keeps formatting natural');

process.stdout.write('member lookup dob tests: PASS\n');
