const path = require('path');

const capture = require(path.resolve(__dirname, '../../pwa/assets/js/member-photo-capture.js'));

function fail(message) {
  process.stderr.write(`${message}\n`);
  process.exit(1);
}

function assertEqual(expected, actual, label) {
  if (expected !== actual) {
    fail(`${label} expected [${JSON.stringify(expected)}] but got [${JSON.stringify(actual)}]`);
  }
}

assertEqual('environment', capture.normalizeCaptureMode(''), 'default capture mode');
assertEqual('environment', capture.normalizeCaptureMode('environment'), 'environment remains environment');
assertEqual('user', capture.normalizeCaptureMode('user'), 'user remains user');
assertEqual('user', capture.toggleCaptureMode('environment'), 'toggle to front camera');
assertEqual('environment', capture.toggleCaptureMode('user'), 'toggle back to rear camera');
assertEqual('Rear Camera', capture.cameraModeLabel('environment'), 'rear camera label');
assertEqual('Front Camera', capture.cameraModeLabel('user'), 'front camera label');

process.stdout.write('member photo capture tests: PASS\n');
