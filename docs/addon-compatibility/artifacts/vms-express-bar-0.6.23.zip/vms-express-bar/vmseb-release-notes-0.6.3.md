# VMS Express Bar 0.6.3

- Age gate now persists for the browser session and is not re-asked after qty returns to 0.
- Pickup name is now required before Review Order / Checkout.
- Bucket-eligible items use a configurable emoji marker instead of repeated text.
- Stepper controls use stronger explicit styling for visibility.
