# VMS Express Bar 0.6.4 Test Plan

1. Verify pickup name prefills for logged-in user.
2. Verify eligible item emoji appears next to item name.
3. Verify price stays on same line as item name.
4. Verify quantity steppers are visible and usable on desktop and mobile.
5. Verify review/checkout still requires a pickup name if prefill is blank.
