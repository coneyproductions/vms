# VMS Express Bar 0.6.2

- removed Express Bar-side discount engine; pricing and discount logic now belongs to Woo / VMS Discounts
- category display now comes directly from Woo product categories instead of a hardwired Beer fallback
- Bar Menu no longer asks operators to manually maintain categories
- public builder messaging now points customers to cart/checkout for final pricing
