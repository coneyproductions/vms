VMS Express Bar standalone add-on for VMS + WooCommerce.
Dedicated public Express Bar page support, event-page CTA handoff, category accordions, one-shot Woo handoff, checkout-side bucket discounting, Ops queue support, browse-only menu mode outside the ordering window, and safer ordering-window copy that does not invent a midnight opening time.
