# VMS Express Bar 0.6.3 Test Plan

1. Add an age-gated item, pass birthday gate, reduce qty to 0, add again in same browser session: gate should not reappear.
2. Leave pickup name blank and try Review Order / Checkout: should block and prompt for name.
3. Confirm bucket-eligible items show emoji marker and summary note shows emoji.
4. Confirm qty stepper controls show visible plus/minus and counts on staging/public page.
