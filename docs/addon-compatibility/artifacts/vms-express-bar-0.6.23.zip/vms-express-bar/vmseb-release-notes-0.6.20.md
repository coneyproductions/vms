## VMS Express Bar 0.6.20

- Reduced the event reference on the dedicated Express Bar page from a banner-style card to a compact inline context link.
- Reordered the top-of-page layout so pickup, sticky order summary, status, and event context sit under the Express Bar intro instead of above it.
- Moved the sticky summary into a form-level layout column so it remains visible while browsing the menu on desktop and mobile.
- Kept the wrapped mobile product-row treatment from `0.6.19` and removed the old long-form pricing/ticketing helper copy from the customer view.
