# VMS Express Bar 0.6.23

- Restored event-page Express Bar CTAs with the public Backstage Venue Manager package by recognizing its `BVMGR_*` runtime identity.
- Added `bvmgr_get_event_plan_for_tec_event()` and `bvmgr_resolve_event_plan_for_tec_event()` support before the existing legacy VMS resolver fallbacks.
- Preserved the existing Event Plan post type, WooCommerce, ordering-window, menu, cart, checkout, order-meta, queue, and fulfillment behavior.
