# VMS Express Bar 0.6.2 Test Plan

1. Confirm Bar Menu shows Woo Category as read-only and no manual category input.
2. Confirm products no longer default to Beer when their Woo category differs or is blank.
3. Confirm public event page groups visible items by Woo product category.
4. Confirm public builder shows generic cart/checkout pricing note, not built-in bucket math.
5. Confirm cart/checkout receives Express Bar items normally and no Express Bar fee/discount is added.
