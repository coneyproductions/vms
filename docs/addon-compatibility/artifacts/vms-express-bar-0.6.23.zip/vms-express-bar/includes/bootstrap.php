<?php
defined('ABSPATH') || exit;

require_once VMSEB_PATH . 'includes/helpers.php';

if (is_admin()) {
    require_once VMSEB_PATH . 'includes/admin.php';
}

require_once VMSEB_PATH . 'includes/public.php';
