<?php
defined('ABSPATH') || exit;

add_action('admin_notices', 'vmseb_admin_notices');
add_action('add_meta_boxes_vms_event_plan', 'vmseb_add_metabox');
add_action('save_post_vms_event_plan', 'vmseb_save_metabox', 20, 2);
add_action('admin_menu', 'vmseb_admin_menu', 40);
add_filter('vms_admin_ui_nav_cluster_items', 'vmseb_register_planning_nav_items', 40, 3);
add_action('admin_post_vmseb_save_bar_menu', 'vmseb_handle_save_bar_menu');
add_action('admin_post_vmseb_update_order', 'vmseb_handle_order_update');
add_action('admin_post_vmseb_create_public_page', 'vmseb_handle_create_public_page');
add_action('admin_post_vmseb_refresh_catalog_registry', 'vmseb_handle_refresh_catalog_registry');
add_action('admin_enqueue_scripts', 'vmseb_admin_enqueue_assets');
add_action('wp_ajax_vmseb_save_bar_menu_row', 'vmseb_handle_save_bar_menu_row');

if (!function_exists('vmseb_admin_enqueue_assets')) {
    function vmseb_admin_enqueue_assets(string $hook_suffix): void
    {
        if (!in_array($hook_suffix, array('vms_page_vms-express-bar', 'vms_page_vms-bar-menu'), true)) {
            return;
        }
        wp_enqueue_style('vmseb-admin', VMSEB_URL . 'assets/css/admin.css', array(), VMSEB_VERSION);
        wp_enqueue_script('vmseb-admin', VMSEB_URL . 'assets/js/admin.js', array(), VMSEB_VERSION, true);
        wp_localize_script('vmseb-admin', 'vmsebAdmin', array(
            'ajaxUrl'      => admin_url('admin-ajax.php'),
            'rowSaveNonce' => wp_create_nonce('vmseb_save_bar_menu_row'),
            'messages'     => array(
                'saveRow'       => __('Save Row', 'vms-express-bar'),
                'savingRow'     => __('Saving...', 'vms-express-bar'),
                'rowSaved'      => __('Saved.', 'vms-express-bar'),
                'rowUnchanged'  => __('No unsaved changes.', 'vms-express-bar'),
                'rowSaveFailed' => __('Could not save this row.', 'vms-express-bar'),
            ),
        ));
    }
}

if (!function_exists('vmseb_admin_notices')) {
    function vmseb_admin_notices(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        if (!vmseb_is_vms_active()) {
            echo '<div class="notice notice-warning"><p>VMS Express Bar requires the VMS core plugin to be active.</p></div>';
            return;
        }
        if (!vmseb_is_woocommerce_active()) {
            echo '<div class="notice notice-warning"><p>VMS Express Bar requires WooCommerce to be active.</p></div>';
        }
    }
}

if (!function_exists('vmseb_add_metabox')) {
    function vmseb_add_metabox(): void
    {
        if (!vmseb_is_vms_active()) {
            return;
        }
        add_meta_box('vmseb_express_bar', __('Express Bar', 'vms-express-bar'), 'vmseb_render_metabox', 'vms_event_plan', 'side', 'default');
    }
}

if (!function_exists('vmseb_render_metabox')) {
    function vmseb_render_metabox(WP_Post $post): void
    {
        $cfg = vmseb_get_event_meta($post->ID);
        $shortcode = '[vms_express_bar_menu event_plan_id="' . (int) $post->ID . '"]';
        wp_nonce_field('vmseb_save_' . $post->ID, 'vmseb_nonce');
        ?>
        <div class="vmseb-metabox">
            <p><label><input type="checkbox" name="vms_express_bar_enabled" value="1" <?php checked(!empty($cfg['enabled'])); ?> /> <?php echo esc_html__('Enable Express Bar for this event.', 'vms-express-bar'); ?></label></p>
            <p><label><input type="checkbox" name="vmseb_auto_embed" value="1" <?php checked(!empty($cfg['auto_embed'])); ?> /> <?php echo esc_html__('Show an Express Bar link on the public event page when possible.', 'vms-express-bar'); ?></label></p>
            <p>
                <label for="vmseb_open_at"><strong><?php echo esc_html__('Ordering opens', 'vms-express-bar'); ?></strong></label><br />
                <input type="datetime-local" class="widefat" id="vmseb_open_at" name="vmseb_open_at" value="<?php echo esc_attr((string) $cfg['opens_at']); ?>" />
                <small><?php echo esc_html__('Leave blank to keep the public menu in browse-only mode until an opening time is set.', 'vms-express-bar'); ?></small>
            </p>
            <p>
                <label for="vmseb_close_at"><strong><?php echo esc_html__('Ordering closes', 'vms-express-bar'); ?></strong></label><br />
                <input type="datetime-local" class="widefat" id="vmseb_close_at" name="vmseb_close_at" value="<?php echo esc_attr((string) $cfg['closes_at']); ?>" />
                <small><?php echo esc_html__('Leave blank to close at the end of the event day once ordering has opened.', 'vms-express-bar'); ?></small>
            </p>
            <p>
                <label for="vms_express_bar_headline"><strong><?php echo esc_html__('Customer headline override', 'vms-express-bar'); ?></strong></label><br />
                <input type="text" class="widefat" id="vms_express_bar_headline" name="vms_express_bar_headline" value="<?php echo esc_attr((string) get_post_meta($post->ID, '_vms_express_bar_headline', true)); ?>" />
            </p>
            <p>
                <label for="vms_express_bar_pickup_instructions"><strong><?php echo esc_html__('Pickup / ID instructions override', 'vms-express-bar'); ?></strong></label><br />
                <textarea class="widefat" rows="4" id="vms_express_bar_pickup_instructions" name="vms_express_bar_pickup_instructions"><?php echo esc_textarea((string) get_post_meta($post->ID, '_vms_express_bar_pickup_instructions', true)); ?></textarea>
            </p>
            <p><strong><?php echo esc_html__('Shortcode', 'vms-express-bar'); ?></strong><br /><code><?php echo esc_html($shortcode); ?></code></p>
            <p><small><?php echo esc_html__('Menu items now come from VMS → Planning → Bar Menu. The public event page can show a compact link to the dedicated Express Bar page when enabled.', 'vms-express-bar'); ?></small></p>
        </div>
        <?php
    }
}

if (!function_exists('vmseb_save_metabox')) {
    function vmseb_save_metabox(int $post_id, WP_Post $post): void
    {
        if ($post->post_type !== 'vms_event_plan') {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        $nonce = isset($_POST['vmseb_nonce']) ? sanitize_text_field(wp_unslash($_POST['vmseb_nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'vmseb_save_' . $post_id)) {
            return;
        }

        update_post_meta($post_id, '_vms_express_bar_enabled', !empty($_POST['vms_express_bar_enabled']) ? '1' : '0');
        update_post_meta($post_id, '_vmseb_auto_embed', !empty($_POST['vmseb_auto_embed']) ? '1' : '0');
        update_post_meta($post_id, '_vmseb_open_at', isset($_POST['vmseb_open_at']) ? sanitize_text_field(wp_unslash($_POST['vmseb_open_at'])) : '');
        update_post_meta($post_id, '_vmseb_close_at', isset($_POST['vmseb_close_at']) ? sanitize_text_field(wp_unslash($_POST['vmseb_close_at'])) : '');
        update_post_meta($post_id, '_vms_express_bar_headline', isset($_POST['vms_express_bar_headline']) ? sanitize_text_field(wp_unslash($_POST['vms_express_bar_headline'])) : '');
        update_post_meta($post_id, '_vms_express_bar_pickup_instructions', isset($_POST['vms_express_bar_pickup_instructions']) ? sanitize_textarea_field(wp_unslash($_POST['vms_express_bar_pickup_instructions'])) : '');
    }
}

if (!function_exists('vmseb_admin_menu')) {
    function vmseb_admin_menu(): void
    {
        $parent = vmseb_parent_menu_slug();
        add_submenu_page($parent, __('Express Bar', 'vms-express-bar'), __('Express Bar', 'vms-express-bar'), 'manage_options', 'vms-express-bar', 'vmseb_render_queue_page');
        add_submenu_page($parent, __('Bar Menu', 'vms-express-bar'), __('Bar Menu', 'vms-express-bar'), 'manage_options', 'vms-bar-menu', 'vmseb_render_bar_menu_page');
    }
}

if (!function_exists('vmseb_register_planning_nav_items')) {
    function vmseb_register_planning_nav_items(array $items, string $cluster_key, array $cluster): array
    {
        unset($cluster);
        if ($cluster_key !== 'planning' || !vmseb_is_vms_active()) {
            return $items;
        }
        $adds = array(
            array('label' => 'Express Bar', 'url' => admin_url('admin.php?page=vms-express-bar')),
            array('label' => 'Bar Menu', 'url' => admin_url('admin.php?page=vms-bar-menu')),
        );
        $existing = array();
        foreach ($items as $item) {
            if (is_array($item) && !empty($item['url'])) {
                $existing[(string) $item['url']] = true;
            }
        }
        foreach ($adds as $item) {
            if (empty($existing[$item['url']])) {
                $items[] = $item;
            }
        }
        return $items;
    }
}

if (!function_exists('vmseb_log_bar_menu_save')) {
    function vmseb_log_bar_menu_save(string $event, array $context = array()): void
    {
        $payload = array_merge(array(
            'event' => $event,
            'time'  => gmdate('c'),
        ), $context);
        error_log('[VMSEB Bar Menu] ' . wp_json_encode($payload));
    }
}

if (!function_exists('vmseb_default_registry_row_for_candidate')) {
    function vmseb_default_registry_row_for_candidate(array $candidate): array
    {
        return array(
            'enabled'            => 0,
            'category'           => trim((string) ($candidate['default_category'] ?? '')),
            'sort'               => 0,
            'bucket_eligible'    => 0,
            'age_gate'           => vmseb_default_age_gate_for_candidate($candidate),
            'online_cap'         => 0,
            'bar_only_threshold' => 0,
        );
    }
}

if (!function_exists('vmseb_build_registry_identifier')) {
    function vmseb_build_registry_identifier(string $token, array $submitted_row = array(), ?array $candidate = null): array
    {
        $parsed = vmseb_parse_catalog_token($token);
        $product_id = isset($submitted_row['product_id']) ? absint($submitted_row['product_id']) : 0;
        $variation_id = isset($submitted_row['variation_id']) ? absint($submitted_row['variation_id']) : 0;

        if ($candidate) {
            $product_id = (int) ($candidate['product_id'] ?? $product_id);
            $variation_id = (int) ($candidate['variation_id'] ?? $variation_id);
        } elseif ($parsed) {
            if ($parsed['kind'] === 'product' && $product_id <= 0) {
                $product_id = (int) $parsed['id'];
            }
            if ($parsed['kind'] === 'variation' && $variation_id <= 0) {
                $variation_id = (int) $parsed['id'];
            }
        }

        return array(
            'token'        => $token,
            'product_id'   => $product_id,
            'variation_id' => $variation_id,
        );
    }
}

if (!function_exists('vmseb_merge_registry_row_payload')) {
    function vmseb_merge_registry_row_payload(array $base_row, array $submitted_row, array $candidate): array
    {
        $row = $base_row;
        $valid_fields = array();

        if (array_key_exists('enabled', $submitted_row)) {
            $row['enabled'] = !empty($submitted_row['enabled']) ? 1 : 0;
            $valid_fields[] = 'enabled';
        }
        if (array_key_exists('bucket_eligible', $submitted_row)) {
            $row['bucket_eligible'] = !empty($submitted_row['bucket_eligible']) ? 1 : 0;
            $valid_fields[] = 'bucket_eligible';
        }
        if (array_key_exists('age_gate', $submitted_row)) {
            $row['age_gate'] = !empty($submitted_row['age_gate']) ? 1 : 0;
            $valid_fields[] = 'age_gate';
        }
        if (array_key_exists('sort', $submitted_row)) {
            $row['sort'] = (int) $submitted_row['sort'];
            $valid_fields[] = 'sort';
        }
        if (array_key_exists('online_cap', $submitted_row)) {
            $row['online_cap'] = max(0, absint($submitted_row['online_cap']));
            $valid_fields[] = 'online_cap';
        }
        if (array_key_exists('bar_only_threshold', $submitted_row)) {
            $row['bar_only_threshold'] = max(0, absint($submitted_row['bar_only_threshold']));
            $valid_fields[] = 'bar_only_threshold';
        }
        if (trim((string) ($row['category'] ?? '')) === '') {
            $row['category'] = trim((string) ($candidate['default_category'] ?? ''));
        }

        return array(
            'row'          => $row,
            'valid_fields' => $valid_fields,
        );
    }
}

if (!function_exists('vmseb_decode_registry_changes_payload')) {
    function vmseb_decode_registry_changes_payload(string $raw_payload): array
    {
        $raw_payload = trim($raw_payload);
        if ($raw_payload === '') {
            return array(
                'rows'  => array(),
                'error' => '',
            );
        }

        $decoded = json_decode($raw_payload, true);
        if (!is_array($decoded)) {
            return array(
                'rows'  => array(),
                'error' => 'invalid_json',
            );
        }

        $rows = array();
        foreach ($decoded as $key => $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $token = isset($entry['token']) ? trim((string) $entry['token']) : '';
            if ($token === '' && is_string($key)) {
                $token = trim($key);
            }
            if ($token === '') {
                continue;
            }
            $entry['token'] = $token;
            $rows[$token] = $entry;
        }

        return array(
            'rows'  => $rows,
            'error' => '',
        );
    }
}

if (!function_exists('vmseb_save_bar_menu_settings_from_request')) {
    function vmseb_save_bar_menu_settings_from_request(array $request): void
    {
        $settings = vmseb_get_settings();
        $settings['headline'] = isset($request['headline']) ? sanitize_text_field(wp_unslash($request['headline'])) : $settings['headline'];
        $settings['pickup_instructions'] = isset($request['pickup_instructions']) ? sanitize_textarea_field(wp_unslash($request['pickup_instructions'])) : $settings['pickup_instructions'];
        $settings['bucket_discount_label'] = isset($request['bucket_discount_label']) ? sanitize_text_field(wp_unslash($request['bucket_discount_label'])) : $settings['bucket_discount_label'];
        $settings['bucket_emoji'] = isset($request['bucket_emoji']) ? sanitize_text_field(wp_unslash($request['bucket_emoji'])) : $settings['bucket_emoji'];
        $settings['age_gate_enabled'] = !empty($request['age_gate_enabled']) ? 1 : 0;
        $settings['age_gate_title'] = isset($request['age_gate_title']) ? sanitize_text_field(wp_unslash($request['age_gate_title'])) : $settings['age_gate_title'];
        $settings['age_gate_message'] = isset($request['age_gate_message']) ? sanitize_textarea_field(wp_unslash($request['age_gate_message'])) : $settings['age_gate_message'];
        $settings['age_gate_min_age'] = isset($request['age_gate_min_age']) ? max(1, min(99, absint($request['age_gate_min_age']) ?: 21)) : $settings['age_gate_min_age'];

        if (isset($request['public_page_id'])) {
            vmseb_set_public_page_id(absint($request['public_page_id']));
        }

        update_option('vmseb_settings', $settings, false);
    }
}

if (!function_exists('vmseb_save_registry_rows')) {
    function vmseb_save_registry_rows(array $submitted_rows, string $context = 'bulk'): array
    {
        $registry = vmseb_get_registry();
        $new_registry = $registry;
        $submitted = array();
        $saved = array();
        $skipped = array();
        $failures = array();
        $prepared_rows = array();
        $prepared_identifiers = array();

        foreach ($submitted_rows as $token => $submitted_row) {
            $token = trim((string) $token);
            $submitted_row = is_array($submitted_row) ? $submitted_row : array();
            $identifier = vmseb_build_registry_identifier($token, $submitted_row);
            $submitted[] = $identifier;

            $parsed = vmseb_parse_catalog_token($token);
            if (!$parsed) {
                $skipped[] = $identifier;
                $failures[] = array('token' => $token, 'reason' => 'invalid_token');
                continue;
            }

            if ($parsed['kind'] === 'product') {
                $submitted_product_id = absint($submitted_row['product_id'] ?? 0);
                if ($submitted_product_id > 0 && $submitted_product_id !== (int) $parsed['id']) {
                    $skipped[] = $identifier;
                    $failures[] = array('token' => $token, 'reason' => 'submitted_product_id_mismatch');
                    continue;
                }
            } else {
                $submitted_variation_id = absint($submitted_row['variation_id'] ?? 0);
                if ($submitted_variation_id > 0 && $submitted_variation_id !== (int) $parsed['id']) {
                    $skipped[] = $identifier;
                    $failures[] = array('token' => $token, 'reason' => 'submitted_variation_id_mismatch');
                    continue;
                }
            }

            $candidate = vmseb_get_candidate_by_token($token);
            if (!$candidate) {
                $skipped[] = $identifier;
                $failures[] = array('token' => $token, 'reason' => 'candidate_not_found');
                continue;
            }

            $identifier = vmseb_build_registry_identifier($token, $submitted_row, $candidate);
            if (!empty($submitted_row['product_id']) && (int) $submitted_row['product_id'] !== (int) ($candidate['product_id'] ?? 0)) {
                $skipped[] = $identifier;
                $failures[] = array('token' => $token, 'reason' => 'candidate_product_id_mismatch');
                continue;
            }
            if (!empty($submitted_row['variation_id']) && (int) ($candidate['variation_id'] ?? 0) > 0 && (int) $submitted_row['variation_id'] !== (int) ($candidate['variation_id'] ?? 0)) {
                $skipped[] = $identifier;
                $failures[] = array('token' => $token, 'reason' => 'candidate_variation_id_mismatch');
                continue;
            }

            $base_row = isset($new_registry[$token]) && is_array($new_registry[$token])
                ? $new_registry[$token]
                : vmseb_default_registry_row_for_candidate($candidate);
            $merged = vmseb_merge_registry_row_payload($base_row, $submitted_row, $candidate);
            if (empty($merged['valid_fields'])) {
                $skipped[] = $identifier;
                $failures[] = array('token' => $token, 'reason' => 'no_valid_fields_submitted');
                continue;
            }

            $new_registry[$token] = $merged['row'];
            $prepared_rows[$token] = $merged['row'];
            $prepared_identifiers[$token] = $identifier;
        }

        $persisted = true;
        $updated = false;
        if ($new_registry !== $registry) {
            $persisted = update_option('vmseb_catalog_registry', $new_registry, false);
            $updated = $persisted;
        }

        if ($persisted) {
            $saved = array_values($prepared_identifiers);
        } elseif (!empty($prepared_identifiers)) {
            foreach ($prepared_identifiers as $token => $identifier) {
                $failures[] = array('token' => $token, 'reason' => 'update_option_failed');
                $prepared_rows[$token] = array();
            }
        }

        $result = array(
            'submitted' => array_values($submitted),
            'saved'     => array_values($saved),
            'skipped'   => array_values($skipped),
            'failures'  => array_values($failures),
            'rows'      => $prepared_rows,
            'updated'   => $updated,
            'persisted' => $persisted,
        );

        vmseb_log_bar_menu_save('registry_save_' . $context, array(
            'submitted_product_ids' => $result['submitted'],
            'saved_product_ids'     => $result['saved'],
            'skipped_product_ids'   => $result['skipped'],
            'save_failures'         => $result['failures'],
        ));

        return $result;
    }
}

if (!function_exists('vmseb_render_bar_menu_page')) {
    function vmseb_render_bar_menu_page(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $settings = vmseb_get_settings();
        $items = vmseb_get_catalog_items(false);
        $public_page_id = vmseb_find_public_page_id(true);
        $public_page_url = $public_page_id > 0 ? get_permalink($public_page_id) : '';
        $public_page_has_shortcode = $public_page_id > 0 ? vmseb_page_contains_shortcode($public_page_id) : false;
        $page_choices = get_posts(array(
            'post_type'        => 'page',
            'post_status'      => array('publish', 'draft', 'pending', 'private', 'future'),
            'posts_per_page'   => 200,
            'orderby'          => 'title',
            'order'            => 'ASC',
            'suppress_filters' => false,
            'no_found_rows'    => true,
        ));
        $prune_report = vmseb_get_registry_prune_report();

        echo '<div class="wrap vmseb-admin-page">';
        echo '<h1>Bar Menu</h1>';
        echo '<p>Build the public Express Bar menu from your Woo catalog. Express Bar does not duplicate product names, prices, images, or categories. Product truth stays in Woo/Square; Express Bar only controls event-specific availability and operational flags.</p>';
        if (!empty($_GET['updated'])) {
            echo '<div class="notice notice-success is-dismissible"><p>Bar Menu settings saved.</p></div>';
        }
        if (!empty($_GET['vmseb_page_setup'])) {
            if (sanitize_key((string) $_GET['vmseb_page_setup']) === 'ready') {
                echo '<div class="notice notice-success is-dismissible"><p>Express Bar page is ready.</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>Express Bar page could not be created. Please create a page manually and add <code>[vms_express_bar_menu]</code>.</p></div>';
            }
        }
        if (!empty($_GET['vmseb_refreshed'])) {
            $removed = absint($_GET['vmseb_refreshed']);
            echo '<div class="notice notice-success is-dismissible"><p>Bar Menu registry refreshed. Removed ' . (int) $removed . ' deleted/unavailable item' . ($removed === 1 ? '' : 's') . '.</p></div>';
        }

        echo '<div class="vmseb-admin-card vmseb-public-page-card">';
        echo '<h2>Public Express Bar Page</h2>';
        if ($public_page_id > 0 && $public_page_url) {
            echo '<p><strong>Current page:</strong> <a href="' . esc_url($public_page_url) . '" target="_blank" rel="noopener">' . esc_html(get_the_title($public_page_id)) . '</a></p>';
            if ($public_page_has_shortcode) {
                echo '<p class="vmseb-good">Shortcode detected. This page is ready for the full Express Bar menu.</p>';
            } else {
                echo '<p class="vmseb-warn">Page found, but the shortcode <code>[vms_express_bar_menu]</code> was not detected. Add the shortcode to that page or choose another page below.</p>';
            }
        } else {
            echo '<p><strong>No Express Bar page is assigned yet.</strong> Create one automatically or choose an existing page below.</p>';
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            echo '<input type="hidden" name="action" value="vmseb_create_public_page" />';
            wp_nonce_field('vmseb_create_public_page', 'vmseb_create_public_page_nonce');
            submit_button('Create Express Bar Page', 'secondary', 'submit', false);
            echo '</form>';
        }
        echo '</div>';

        echo '<div class="vmseb-admin-card">';
        echo '<h2>Catalog Refresh</h2>';
        echo '<p>Use this after deleting or trashing Woo products. It removes dead Bar Menu registry rows so deleted products cannot keep showing on the public Express Bar page.</p>';
        echo '<p><strong>Registry rows:</strong> ' . (int) $prune_report['total'] . ' &nbsp; <strong>Deleted/unavailable:</strong> ' . (int) $prune_report['stale'] . '</p>';
        echo '<form class="vmseb-action-form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="vmseb_refresh_catalog_registry" />';
        wp_nonce_field('vmseb_refresh_catalog_registry');
        submit_button('Refresh Bar Menu Registry', 'secondary', 'submit', false);
        echo '</form>';
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-vmseb-bar-menu-form>';
        echo '<input type="hidden" name="action" value="vmseb_save_bar_menu" />';
        wp_nonce_field('vmseb_save_bar_menu', 'vmseb_bar_menu_nonce');
        echo '<input type="hidden" name="vmseb_registry_changes" value="" data-vmseb-registry-changes />';

        echo '<h2 class="title">Dedicated Page</h2>';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="vmseb_public_page_id">Express Bar page</label></th><td><select id="vmseb_public_page_id" name="public_page_id">';
        echo '<option value="0">Auto-detect / not assigned</option>';
        foreach ($page_choices as $page_choice) {
            if (!$page_choice instanceof WP_Post) {
                continue;
            }
            echo '<option value="' . (int) $page_choice->ID . '" ' . selected($public_page_id, (int) $page_choice->ID, false) . '>' . esc_html($page_choice->post_title . ' (' . $page_choice->post_status . ')') . '</option>';
        }
        echo '</select><p class="description">The selected page should contain <code>[vms_express_bar_menu]</code>. Event pages now point customers here instead of embedding the full menu inline.</p></td></tr>';
        echo '</table>';

        echo '<h2 class="title">Public Copy &amp; Messaging</h2>';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="vmseb_headline">Default headline</label></th><td><input type="text" class="regular-text" id="vmseb_headline" name="headline" value="' . esc_attr($settings['headline']) . '" /></td></tr>';
        echo '<tr><th scope="row"><label for="vmseb_pickup_instructions">Pickup / ID instructions</label></th><td><textarea class="large-text" rows="3" id="vmseb_pickup_instructions" name="pickup_instructions">' . esc_textarea($settings['pickup_instructions']) . '</textarea></td></tr>';
        echo '<tr><th scope="row"><label for="vmseb_discount_message">Checkout discount message</label></th><td><input type="text" class="regular-text" id="vmseb_discount_message" name="bucket_discount_label" value="' . esc_attr($settings['bucket_discount_label']) . '" /><p class="description">Shown on the public builder. Express Bar does not calculate discounts; Woo/VMS Discounts handles final pricing.</p></td></tr>';
        echo '<tr><th scope="row"><label for="vmseb_bucket_emoji">Bucket eligible emoji</label></th><td><input type="text" class="small-text" id="vmseb_bucket_emoji" name="bucket_emoji" value="' . esc_attr($settings['bucket_emoji']) . '" maxlength="8" /><p class="description">Shown next to bucket-eligible items and in the checkout note.</p></td></tr>';
        echo '<tr><th scope="row">Birthday gate</th><td><label><input type="checkbox" name="age_gate_enabled" value="1" ' . checked(!empty($settings['age_gate_enabled']), true, false) . ' /> Ask for birthday before customers can continue with age-gated items.</label><p class="description">This is a reminder and deterrent only. Staff still checks ID at pickup.</p></td></tr>';
        echo '<tr><th scope="row"><label for="vmseb_age_gate_title">Birthday gate title</label></th><td><input type="text" class="regular-text" id="vmseb_age_gate_title" name="age_gate_title" value="' . esc_attr($settings['age_gate_title']) . '" /></td></tr>';
        echo '<tr><th scope="row"><label for="vmseb_age_gate_message">Birthday gate message</label></th><td><textarea class="large-text" rows="2" id="vmseb_age_gate_message" name="age_gate_message">' . esc_textarea($settings['age_gate_message']) . '</textarea></td></tr>';
        echo '<tr><th scope="row"><label for="vmseb_age_gate_min_age">Minimum age</label></th><td><input type="number" min="1" max="99" step="1" id="vmseb_age_gate_min_age" name="age_gate_min_age" value="' . (int) $settings['age_gate_min_age'] . '" /></td></tr>';
        echo '</table>';

        echo '<h2 class="title">Item Registry</h2>';
        echo '<p>Only items checked <strong>Show</strong> will appear on the public Express Bar page. Category comes directly from the Woo product category so you do not have to maintain the same information in two places. Use Express Bar here only for operational flags like show/hide, bucket eligibility, age gate, sort, online caps, and low-stock bar-only thresholds.</p>';
        echo '<p class="description">Use <strong>Save Row</strong> to persist one product at a time. <strong>Save Bar Menu</strong> remains available as a fallback and only submits rows with unsaved changes.</p>';
        echo '<noscript><p class="vmseb-warn">JavaScript is required for row-level item saves and changed-row bulk submission.</p></noscript>';
        echo '<p><label for="vmseb-registry-search"><strong>Filter items</strong></label><br /><input type="search" id="vmseb-registry-search" class="regular-text" placeholder="Search catalog..." /></p>';
        echo '<div class="vmseb-registry-wrap">';
        echo '<table class="widefat striped vmseb-registry-table"><thead><tr><th>Show</th><th>Item</th><th>Woo Category</th><th>Bucket Eligible</th><th>Birthday Gate</th><th>Sort</th><th>Online Cap</th><th>Low Stock → Bar Only</th><th>Stock</th><th>Save</th></tr></thead><tbody>';

        foreach ($items as $token => $item) {
            $availability = vmseb_get_item_online_availability($item);
            echo '<tr class="vmseb-registry-row" data-vmseb-row data-token="' . esc_attr($token) . '" data-product-id="' . (int) ($item['product_id'] ?? 0) . '" data-variation-id="' . (int) ($item['variation_id'] ?? 0) . '" data-search="' . esc_attr(strtolower($item['title'] . ' ' . $item['source_label'] . ' ' . $item['category'])) . '">';
            echo '<td><label><input type="checkbox" value="1" data-vmseb-field="enabled" ' . checked(!empty($item['enabled']), true, false) . ' /> <span class="screen-reader-text">Show ' . esc_html($item['title']) . '</span></label></td>';
            echo '<td>';
            if (!empty($item['image_url'])) {
                echo '<img class="vmseb-thumb" src="' . esc_url($item['image_url']) . '" alt="" /> ';
            }
            echo '<div class="vmseb-item-title"><strong>' . esc_html($item['title']) . '</strong></div>';
            echo '<div class="vmseb-item-meta">' . esc_html($item['kind'] === 'variation' ? $item['source_label'] : 'Simple product') . ' • ' . wp_kses_post($item['price_html']) . '</div>';
            echo '</td>';
            echo '<td><span class="vmseb-category-pill">' . esc_html($item['default_category'] !== '' ? $item['default_category'] : '—') . '</span></td>';
            echo '<td><label><input type="checkbox" value="1" data-vmseb-field="bucket_eligible" ' . checked(!empty($item['bucket_eligible']), true, false) . ' /> <span>Yes</span></label></td>';
            echo '<td><label><input type="checkbox" value="1" data-vmseb-field="age_gate" ' . checked(!empty($item['age_gate']), true, false) . ' /> <span>Yes</span></label></td>';
            echo '<td><input type="number" class="small-text" value="' . (int) $item['sort'] . '" data-vmseb-field="sort" /></td>';
            echo '<td><input type="number" class="small-text" min="0" value="' . (int) $item['online_cap'] . '" data-vmseb-field="online_cap" /><div class="description">0 = no cap</div></td>';
            echo '<td><input type="number" class="small-text" min="0" value="' . (int) $item['bar_only_threshold'] . '" data-vmseb-field="bar_only_threshold" /><div class="description">0 = ignore</div></td>';
            echo '<td>';
            if ($item['manage_stock']) {
                echo '<span class="vmseb-stock-pill">' . ($availability['available'] === null ? '—' : (int) $availability['available']) . ' online</span>';
            } else {
                echo '<span class="vmseb-stock-pill">Not stock-managed</span>';
            }
            echo '</td>';
            echo '<td class="vmseb-row-actions"><button type="button" class="button button-secondary" data-vmseb-row-save disabled>Save Row</button><div class="vmseb-row-feedback" data-vmseb-row-feedback aria-live="polite"></div></td>';
            echo '</tr>';
        }

        echo '</tbody></table></div>';
        echo '<div class="vmseb-form-actions">';
        submit_button('Save Bar Menu', 'primary', 'submit', false);
        echo '<p class="description">This saves the page settings above and only the registry rows that still have unsaved changes.</p>';
        echo '</div>';
        echo '</form></div>';
    }
}

if (!function_exists('vmseb_handle_save_bar_menu')) {
    function vmseb_handle_save_bar_menu(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        $nonce = isset($_POST['vmseb_bar_menu_nonce']) ? sanitize_text_field(wp_unslash($_POST['vmseb_bar_menu_nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'vmseb_save_bar_menu')) {
            wp_die('Invalid request');
        }

        vmseb_save_bar_menu_settings_from_request($_POST);

        $submitted_rows = array();
        $raw_changes = isset($_POST['vmseb_registry_changes']) ? (string) wp_unslash($_POST['vmseb_registry_changes']) : '';
        $decoded_changes = vmseb_decode_registry_changes_payload($raw_changes);
        if ($decoded_changes['error'] !== '') {
            vmseb_log_bar_menu_save('registry_save_bulk_decode_error', array(
                'submitted_product_ids' => array(),
                'saved_product_ids'     => array(),
                'skipped_product_ids'   => array(),
                'save_failures'         => array(
                    array('reason' => $decoded_changes['error']),
                ),
            ));
        }
        if (!empty($decoded_changes['rows'])) {
            $submitted_rows = $decoded_changes['rows'];
        } elseif (isset($_POST['registry']) && is_array($_POST['registry'])) {
            foreach ((array) wp_unslash($_POST['registry']) as $token => $row) {
                if (!is_array($row)) {
                    continue;
                }
                $submitted_rows[(string) $token] = array(
                    'token'              => (string) $token,
                    'enabled'            => !empty($row['enabled']) ? 1 : 0,
                    'bucket_eligible'    => !empty($row['bucket_eligible']) ? 1 : 0,
                    'age_gate'           => !empty($row['age_gate']) ? 1 : 0,
                );
                if (isset($row['sort'])) {
                    $submitted_rows[(string) $token]['sort'] = (int) $row['sort'];
                }
                if (isset($row['online_cap'])) {
                    $submitted_rows[(string) $token]['online_cap'] = max(0, absint($row['online_cap']));
                }
                if (isset($row['bar_only_threshold'])) {
                    $submitted_rows[(string) $token]['bar_only_threshold'] = max(0, absint($row['bar_only_threshold']));
                }
            }
        }

        if (!empty($submitted_rows)) {
            vmseb_save_registry_rows($submitted_rows, 'bulk');
        } else {
            vmseb_log_bar_menu_save('registry_save_bulk', array(
                'submitted_product_ids' => array(),
                'saved_product_ids'     => array(),
                'skipped_product_ids'   => array(),
                'save_failures'         => array(),
            ));
        }

        wp_safe_redirect(admin_url('admin.php?page=vms-bar-menu&updated=1'));
        exit;
    }
}

if (!function_exists('vmseb_handle_save_bar_menu_row')) {
    function vmseb_handle_save_bar_menu_row(): void
    {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized.'), 403);
        }
        check_ajax_referer('vmseb_save_bar_menu_row', 'nonce');

        $token = isset($_POST['token']) ? trim(sanitize_text_field(wp_unslash($_POST['token']))) : '';
        $submitted_row = array(
            'token'              => $token,
            'product_id'         => isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0,
            'variation_id'       => isset($_POST['variation_id']) ? absint(wp_unslash($_POST['variation_id'])) : 0,
            'enabled'            => !empty($_POST['enabled']) ? 1 : 0,
            'bucket_eligible'    => !empty($_POST['bucket_eligible']) ? 1 : 0,
            'age_gate'           => !empty($_POST['age_gate']) ? 1 : 0,
            'sort'               => isset($_POST['sort']) ? (int) wp_unslash($_POST['sort']) : 0,
            'online_cap'         => isset($_POST['online_cap']) ? max(0, absint(wp_unslash($_POST['online_cap']))) : 0,
            'bar_only_threshold' => isset($_POST['bar_only_threshold']) ? max(0, absint(wp_unslash($_POST['bar_only_threshold']))) : 0,
        );
        $result = vmseb_save_registry_rows(array($token => $submitted_row), 'row');

        if (empty($result['persisted'])) {
            wp_send_json_error(array(
                'message'  => 'Could not save this row. Check the log for details.',
                'failures' => $result['failures'],
            ), 500);
        }
        if (count($result['saved']) < 1) {
            $message = !empty($result['failures']) ? 'This row could not be saved.' : 'No changes were submitted for this row.';
            wp_send_json_error(array(
                'message'  => $message,
                'failures' => $result['failures'],
                'skipped'  => $result['skipped'],
            ), 400);
        }

        $message = !empty($result['updated']) ? 'Row saved.' : 'Row already matched the saved values.';
        wp_send_json_success(array(
            'message' => $message,
            'saved'   => $result['saved'],
        ));
    }
}


if (!function_exists('vmseb_handle_refresh_catalog_registry')) {
    function vmseb_handle_refresh_catalog_registry(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('vmseb_refresh_catalog_registry');
        $result = vmseb_prune_catalog_registry();
        wp_safe_redirect(admin_url('admin.php?page=vms-bar-menu&vmseb_refreshed=' . absint($result['removed'] ?? 0)));
        exit;
    }
}

if (!function_exists('vmseb_handle_create_public_page')) {
    function vmseb_handle_create_public_page(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        $nonce = isset($_POST['vmseb_create_public_page_nonce']) ? sanitize_text_field(wp_unslash($_POST['vmseb_create_public_page_nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'vmseb_create_public_page')) {
            wp_die('Invalid request');
        }
        $page_id = vmseb_create_public_page();
        $args = array('page' => 'vms-bar-menu');
        $args['vmseb_page_setup'] = $page_id > 0 ? 'ready' : 'failed';
        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }
}

if (!function_exists('vmseb_render_queue_page')) {
    function vmseb_render_queue_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }
        $selected_event_id = isset($_GET['event_plan_id']) ? absint($_GET['event_plan_id']) : 0;
        $orders = wc_get_orders(array(
            'limit'      => 100,
            'orderby'    => 'date',
            'order'      => 'DESC',
            'type'       => 'shop_order',
            'status'     => array_keys(wc_get_order_statuses()),
            'meta_key'   => '_vms_express_bar_order',
            'meta_value' => '1',
        ));
        $event_options = array();
        foreach (get_posts(array('post_type' => 'vms_event_plan', 'post_status' => array('publish', 'draft', 'pending', 'future', 'private'), 'posts_per_page' => 200, 'orderby' => 'date', 'order' => 'DESC')) as $event_post) {
            $event_options[(int) $event_post->ID] = get_the_title($event_post->ID);
        }
        echo '<div class="wrap vmseb-admin-page"><h1>Express Bar Queue</h1>';
        echo '<form method="get" class="vmseb-filter-form">';
        echo '<input type="hidden" name="page" value="vms-express-bar" />';
        echo '<label for="vmseb_event_plan_id"><strong>Event Plan</strong></label> ';
        echo '<select id="vmseb_event_plan_id" name="event_plan_id"><option value="0">All Events</option>';
        foreach ($event_options as $event_id => $label) {
            echo '<option value="' . (int) $event_id . '" ' . selected($selected_event_id, $event_id, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select> ';
        submit_button(__('Filter', 'vms-express-bar'), 'secondary', '', false);
        echo '</form>';

        $movement = array();
        $rendered = 0;
        echo '<table class="widefat striped vmseb-table"><thead><tr><th>Order</th><th>Customer</th><th>Event</th><th>Items</th><th>Total</th><th>Status</th><th>ID Check</th><th>Actions</th></tr></thead><tbody>';
        foreach ($orders as $order) {
            if (!$order instanceof WC_Order) {
                continue;
            }
            $queue_status = vmseb_normalize_queue_status((string) $order->get_meta('_vms_express_bar_queue_status', true));
            $id_verified = (string) $order->get_meta('_vms_express_bar_id_verified', true) === '1';
            $item_lines = array();
            $event_names = array();
            $pickup_name = '';
            $matches_filter = $selected_event_id === 0;
            foreach ($order->get_items() as $item) {
                if ((string) $item->get_meta('_vms_express_bar', true) !== '1') {
                    continue;
                }
                $item_plan_id = absint($item->get_meta('_vms_express_bar_event_plan_id', true));
                if ($selected_event_id > 0 && $item_plan_id === $selected_event_id) {
                    $matches_filter = true;
                }
                $event_name = (string) $item->get_meta('_vms_express_bar_event_plan_title', true);
                if ($event_name !== '') {
                    $event_names[] = $event_name;
                }
                if ($pickup_name === '') {
                    $pickup_name = (string) $item->get_meta('_vms_express_bar_pickup_name', true);
                }
                $item_lines[] = $item->get_name() . ' × ' . $item->get_quantity();
            }
            if (!$matches_filter) {
                continue;
            }
            $summary = vmseb_get_item_movement_summary_for_order($order);
            foreach ($summary as $token => $entry) {
                if (!is_array($entry)) {
                    continue;
                }
                if (!isset($movement[$token])) {
                    $movement[$token] = array(
                        'label' => (string) ($entry['label'] ?? ''),
                        'qty'   => 0,
                    );
                }
                $movement[$token]['qty'] += absint($entry['qty'] ?? 0);
            }
            $rendered++;
            $customer = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
            if ($customer === '') {
                $customer = $order->get_billing_email();
            }
            echo '<tr>';
            echo '<td><a href="' . esc_url(admin_url('post.php?post=' . $order->get_id() . '&action=edit')) . '">#' . (int) $order->get_id() . '</a><br /><small>' . esc_html($order->get_date_created() ? $order->get_date_created()->date_i18n('Y-m-d g:i a') : '') . '</small></td>';
            echo '<td>' . esc_html($customer) . ($pickup_name !== '' ? '<br /><small>Pickup: ' . esc_html($pickup_name) . '</small>' : '') . '</td>';
            echo '<td>' . esc_html(implode(', ', array_values(array_unique(array_filter($event_names))))) . '</td>';
            echo '<td>' . esc_html(implode(' | ', $item_lines)) . '</td>';
            echo '<td>' . wp_kses_post($order->get_formatted_order_total()) . '</td>';
            echo '<td><span class="vmseb-status vmseb-status--' . esc_attr($queue_status) . '">' . esc_html(ucfirst($queue_status)) . '</span></td>';
            echo '<td>' . ($id_verified ? '<span class="vmseb-pill vmseb-pill--ok">Verified</span>' : '<span class="vmseb-pill">Pending</span>') . '</td>';
            echo '<td>' . vmseb_action_form($order->get_id(), 'ready', __('Mark Ready', 'vms-express-bar')) . ' ' . vmseb_action_form($order->get_id(), 'completed', __('Picked Up', 'vms-express-bar')) . ' ' . vmseb_action_form($order->get_id(), 'verify_id', $id_verified ? __('Undo ID', 'vms-express-bar') : __('ID Verified', 'vms-express-bar')) . '</td>';
            echo '</tr>';
        }
        if ($rendered === 0) {
            echo '<tr><td colspan="8">No Express Bar orders match this filter.</td></tr>';
        }
        echo '</tbody></table>';

        if (!empty($movement)) {
            uasort($movement, static function(array $a, array $b): int {
                return ($b['qty'] <=> $a['qty']);
            });
            echo '<h2>Item movement summary</h2>';
            echo '<table class="widefat striped vmseb-table"><thead><tr><th>Item</th><th>Qty</th></tr></thead><tbody>';
            foreach ($movement as $entry) {
                echo '<tr><td>' . esc_html($entry['label']) . '</td><td>' . (int) $entry['qty'] . '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';
    }
}

if (!function_exists('vmseb_action_form')) {
    function vmseb_action_form(int $order_id, string $action_name, string $label): string
    {
        ob_start();
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="vmseb-action-form">
            <input type="hidden" name="action" value="vmseb_update_order" />
            <input type="hidden" name="order_id" value="<?php echo (int) $order_id; ?>" />
            <input type="hidden" name="queue_action" value="<?php echo esc_attr($action_name); ?>" />
            <?php wp_nonce_field('vmseb_update_order_' . $order_id . '_' . $action_name, 'vmseb_order_nonce'); ?>
            <button type="submit" class="button button-small"><?php echo esc_html($label); ?></button>
        </form>
        <?php
        return (string) ob_get_clean();
    }
}

if (!function_exists('vmseb_handle_order_update')) {
    function vmseb_handle_order_update(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $queue_action = isset($_POST['queue_action']) ? sanitize_key(wp_unslash($_POST['queue_action'])) : '';
        $nonce = isset($_POST['vmseb_order_nonce']) ? sanitize_text_field(wp_unslash($_POST['vmseb_order_nonce'])) : '';
        if ($order_id <= 0 || !wp_verify_nonce($nonce, 'vmseb_update_order_' . $order_id . '_' . $queue_action)) {
            wp_die('Invalid request');
        }
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            wp_die('Order not found');
        }
        switch ($queue_action) {
            case 'ready':
                $order->update_meta_data('_vms_express_bar_queue_status', 'ready');
                break;
            case 'completed':
                $order->update_meta_data('_vms_express_bar_queue_status', 'completed');
                break;
            case 'verify_id':
                $current = (string) $order->get_meta('_vms_express_bar_id_verified', true) === '1';
                $order->update_meta_data('_vms_express_bar_id_verified', $current ? '0' : '1');
                break;
        }
        $order->save();
        wp_safe_redirect(admin_url('admin.php?page=vms-express-bar'));
        exit;
    }
}
