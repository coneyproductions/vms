# VMS Express Bar 0.6.4

- Prefill pickup name from logged-in user when available.
- Slimmer public item rows with inline price.
- Bucket emoji stays next to item name.
- Qty steppers refined to better match ticket/add-on controls and improve visibility.
