(function () {
    'use strict';

    var cfg = window.VMSXCheckoutPolicies || {};
    if (!cfg.ajaxUrl || !cfg.nonce) {
        return;
    }

    var state = {
        accepted: !!cfg.accepted,
        policyHash: cfg.policyHash || '',
        scopeHash: cfg.scopeHash || '',
        busy: false,
        blockPayload: ''
    };

    function setBodyState(accepted) {
        var body = document.body;
        if (!body) return;
        body.classList.add('vmsx-policy-event-checkout');
        body.classList.toggle('vmsx-policy-locked', !accepted);
    }

    function setClassicMirror(accepted) {
        var mirror = document.getElementById('vmsx-checkout-policies-form-accept');
        if (mirror) {
            mirror.value = accepted ? '1' : '0';
        }
    }

    function setBlockExtensionData(accepted) {
        try {
            if (!window.wp || !wp.data || !wp.data.dispatch) return;
            var dispatch = wp.data.dispatch('wc/store/checkout');
            if (!dispatch || typeof dispatch.setExtensionData !== 'function') return;
            var payload = {
                accepted: !!accepted,
                policy_hash: state.policyHash,
                scope_hash: state.scopeHash
            };
            var signature = JSON.stringify(payload);
            if (signature === state.blockPayload) return;
            state.blockPayload = signature;
            dispatch.setExtensionData(cfg.namespace || 'vmsx-checkout-policies', payload);
        } catch (e) {
            // Server validation remains authoritative if the Blocks store is
            // unavailable or changes; do not unlock express payment here.
        }
    }

    function setStatus(message, isError) {
        var el = document.getElementById('vmsx-checkout-policies-status');
        if (!el) return;
        el.textContent = message || '';
        el.classList.toggle('is-error', !!isError);
    }

    function setCheckbox(accepted) {
        var box = document.getElementById('vmsx-checkout-policies-accept');
        if (box) {
            box.checked = !!accepted;
            box.disabled = !!state.busy;
        }
    }

    function applyState(accepted) {
        state.accepted = !!accepted;
        setBodyState(state.accepted);
        setClassicMirror(state.accepted);
        setBlockExtensionData(state.accepted);
        setCheckbox(state.accepted);
    }

    function postState(intent, accepted) {
        var data = new URLSearchParams();
        data.set('action', 'vmsx_checkout_policy_toggle');
        data.set('nonce', cfg.nonce);
        data.set('intent', intent || 'set');
        data.set('accepted', accepted ? '1' : '0');

        return fetch(cfg.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: data.toString()
        }).then(function (response) {
            return response.json().then(function (json) {
                if (!response.ok || !json || !json.success) {
                    var message = json && json.data && json.data.message ? json.data.message : cfg.errorMessage;
                    throw new Error(message || 'Unable to save policy acceptance.');
                }
                return json.data || {};
            });
        });
    }

    function syncStatus() {
        return postState('status', false).then(function (data) {
            if (data.policy_hash) state.policyHash = data.policy_hash;
            if (data.scope_hash !== undefined) state.scopeHash = data.scope_hash;
            applyState(!!data.accepted);
            return data;
        }).catch(function () {
            // A status failure must not unlock payment.
            applyState(false);
        });
    }

    function onToggle(event) {
        var desired = !!event.target.checked;
        state.busy = true;
        setCheckbox(desired);
        setStatus('');

        // Revocation is immediate in the UI; acceptance unlocks only after the
        // server confirms the Woo session state.
        if (!desired) {
            applyState(false);
        } else {
            setBodyState(false);
            setClassicMirror(true);
        }

        postState('set', desired).then(function (data) {
            if (data.policy_hash) state.policyHash = data.policy_hash;
            if (data.scope_hash !== undefined) state.scopeHash = data.scope_hash;
            state.busy = false;
            applyState(!!data.accepted);
            if (desired && !data.accepted) {
                throw new Error(cfg.errorMessage || 'Policy acceptance was not saved.');
            }
        }).catch(function (error) {
            state.busy = false;
            applyState(false);
            setStatus(error && error.message ? error.message : cfg.errorMessage, true);
        });
    }

    function policyMarkup() {
        var section = document.createElement('section');
        section.id = 'vmsx-checkout-policies';
        section.className = 'vmsx-checkout-policies vmsx-checkout-policies--blocks';

        var details = document.createElement('details');
        details.className = 'vmsx-checkout-policies__details';
        details.open = !!cfg.openByDefault;

        var summary = document.createElement('summary');
        summary.textContent = cfg.summaryLabel || 'Event policies';
        details.appendChild(summary);

        var content = document.createElement('div');
        content.className = 'vmsx-checkout-policies__content';
        if (cfg.policyTitle) {
            var title = document.createElement('strong');
            title.className = 'vmsx-checkout-policies__title';
            title.textContent = cfg.policyTitle;
            content.appendChild(title);
        }
        var body = document.createElement('div');
        body.className = 'vmsx-checkout-policies__body';
        String(cfg.policyBody || '').split(/\n+/).forEach(function (line) {
            if (!line.trim()) return;
            var p = document.createElement('p');
            p.textContent = line;
            body.appendChild(p);
        });
        content.appendChild(body);
        if (cfg.policyVersion) {
            var version = document.createElement('small');
            version.className = 'vmsx-checkout-policies__version';
            version.textContent = 'Policy version ' + cfg.policyVersion;
            content.appendChild(version);
        }
        details.appendChild(content);
        section.appendChild(details);

        var label = document.createElement('label');
        label.className = 'vmsx-checkout-policies__accept';
        var checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = 'vmsx-checkout-policies-accept';
        checkbox.value = '1';
        checkbox.checked = !!state.accepted;
        var text = document.createElement('span');
        text.textContent = cfg.checkboxLabel || 'I have read and agree to the event policies.';
        label.appendChild(checkbox);
        label.appendChild(text);
        section.appendChild(label);

        var status = document.createElement('div');
        status.id = 'vmsx-checkout-policies-status';
        status.className = 'vmsx-checkout-policies__status';
        status.setAttribute('role', 'status');
        status.setAttribute('aria-live', 'polite');
        section.appendChild(status);
        return section;
    }

    function ensureBlocksPanel() {
        if (document.getElementById('vmsx-checkout-policies')) return;
        var checkout = document.querySelector('.wc-block-checkout, .wp-block-woocommerce-checkout');
        if (!checkout) return;

        var panel = policyMarkup();
        var express = checkout.querySelector('.wc-block-components-express-payment, .wp-block-woocommerce-checkout-express-payment-block');
        if (express && express.parentNode) {
            express.parentNode.insertBefore(panel, express);
            return;
        }

        var main = checkout.querySelector('.wc-block-checkout__main') || checkout;
        main.insertBefore(panel, main.firstChild);
    }

    function bind() {
        ensureBlocksPanel();
        var box = document.getElementById('vmsx-checkout-policies-accept');
        if (box && !box.dataset.vmsxBound) {
            box.dataset.vmsxBound = '1';
            box.addEventListener('change', onToggle);
        }
        applyState(state.accepted);
    }

    document.addEventListener('DOMContentLoaded', function () {
        bind();
        syncStatus().then(bind);

        var observer = new MutationObserver(function () {
            ensureBlocksPanel();
            bind();
        });
        observer.observe(document.body, { childList: true, subtree: true });

        // Classic checkout refreshes totals asynchronously. Re-check the
        // server scope after those updates so a changed event cart re-locks.
        if (window.jQuery) {
            window.jQuery(document.body).on('updated_checkout', function () {
                syncStatus().then(bind);
            });
        }
    });
})();
